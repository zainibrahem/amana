exports.ids = [1];
exports.modules = {

/***/ "./src/assets/icons/CloseIcon.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/CloseIcon.tsx ***!
  \****************************************/
/*! exports provided: CloseIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return CloseIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CloseIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/ShoppingBagAlt.tsx":
/*!*********************************************!*\
  !*** ./src/assets/icons/ShoppingBagAlt.tsx ***!
  \*********************************************/
/*! exports provided: ShoppingBagAlt */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShoppingBagAlt", function() { return ShoppingBagAlt; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\ShoppingBagAlt.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const ShoppingBagAlt = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20",
    height: "20",
    viewBox: "0 0 20 20"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "shopping-bag",
      d: "M5,4H19a1,1,0,0,1,1,1V19a1,1,0,0,1-1,1H5a1,1,0,0,1-1-1V5A1,1,0,0,1,5,4ZM2,5A3,3,0,0,1,5,2H19a3,3,0,0,1,3,3V19a3,3,0,0,1-3,3H5a3,3,0,0,1-3-3Zm10,7C9.239,12,7,9.314,7,6H9c0,2.566,1.669,4,3,4s3-1.434,3-4h2C17,9.314,14.761,12,12,12Z",
      transform: "translate(-2 -2)",
      fill: "currentColor",
      fillRule: "evenodd"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/demo-switcher/data.tsx":
/*!***********************************************!*\
  !*** ./src/components/demo-switcher/data.tsx ***!
  \***********************************************/
/*! exports provided: DemoData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoData", function() { return DemoData; });
/* harmony import */ var _image_grocery_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./image/grocery.png */ "./src/components/demo-switcher/image/grocery.png");
/* harmony import */ var _image_grocery_png__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_image_grocery_png__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _image_makeup_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./image/makeup.png */ "./src/components/demo-switcher/image/makeup.png");
/* harmony import */ var _image_makeup_png__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_image_makeup_png__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _image_bag_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./image/bag.png */ "./src/components/demo-switcher/image/bag.png");
/* harmony import */ var _image_bag_png__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_image_bag_png__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _image_clothing_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./image/clothing.png */ "./src/components/demo-switcher/image/clothing.png");
/* harmony import */ var _image_clothing_png__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_image_clothing_png__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _image_furniture_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./image/furniture.png */ "./src/components/demo-switcher/image/furniture.png");
/* harmony import */ var _image_furniture_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_image_furniture_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _image_book_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./image/book.png */ "./src/components/demo-switcher/image/book.png");
/* harmony import */ var _image_book_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_image_book_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _image_medicine_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./image/medicine.png */ "./src/components/demo-switcher/image/medicine.png");
/* harmony import */ var _image_medicine_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_image_medicine_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _image_restaurant_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./image/restaurant.png */ "./src/components/demo-switcher/image/restaurant.png");
/* harmony import */ var _image_restaurant_png__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_image_restaurant_png__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _image_bakery_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./image/bakery.png */ "./src/components/demo-switcher/image/bakery.png");
/* harmony import */ var _image_bakery_png__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_image_bakery_png__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _image_grocery_2_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./image/grocery-2.png */ "./src/components/demo-switcher/image/grocery-2.png");
/* harmony import */ var _image_grocery_2_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_image_grocery_2_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _image_furniture_2_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./image/furniture-2.png */ "./src/components/demo-switcher/image/furniture-2.png");
/* harmony import */ var _image_furniture_2_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_image_furniture_2_png__WEBPACK_IMPORTED_MODULE_10__);











const DemoData = [{
  image: _image_bakery_png__WEBPACK_IMPORTED_MODULE_8___default.a,
  title: 'Bakery',
  link: 'https://shop.redq.now.sh/bakery'
}, {
  image: _image_grocery_2_png__WEBPACK_IMPORTED_MODULE_9___default.a,
  title: 'Grocery Modern',
  link: 'https://shop.redq.now.sh/grocery-two'
}, {
  image: _image_furniture_2_png__WEBPACK_IMPORTED_MODULE_10___default.a,
  title: 'Furniture Modern',
  link: 'https://shop.redq.now.sh/furniture-two'
}, {
  image: _image_grocery_png__WEBPACK_IMPORTED_MODULE_0___default.a,
  title: 'Grocery',
  link: 'https://shop.redq.now.sh/grocery'
}, {
  image: _image_makeup_png__WEBPACK_IMPORTED_MODULE_1___default.a,
  title: 'Makeup',
  link: 'https://shop.redq.now.sh/makeup'
}, {
  image: _image_bag_png__WEBPACK_IMPORTED_MODULE_2___default.a,
  title: 'Bag',
  link: 'https://shop.redq.now.sh/bags'
}, {
  image: _image_clothing_png__WEBPACK_IMPORTED_MODULE_3___default.a,
  title: 'Clothing',
  link: 'https://shop.redq.now.sh/clothing'
}, {
  image: _image_furniture_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  title: 'Furniture',
  link: 'https://shop.redq.now.sh/furniture'
}, {
  image: _image_book_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  title: 'Book',
  link: 'https://shop.redq.now.sh/book'
}, {
  image: _image_medicine_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  title: 'Medicine',
  link: 'https://shop.redq.now.sh/medicine'
}, {
  image: _image_restaurant_png__WEBPACK_IMPORTED_MODULE_7___default.a,
  title: 'Restaurant',
  link: 'https://shop-restaurant.vercel.app'
}];

/***/ }),

/***/ "./src/components/demo-switcher/image/bag.png":
/*!****************************************************!*\
  !*** ./src/components/demo-switcher/image/bag.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bag-29362f82fb955a25b2ea7707d37a7e3f.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/bakery.png":
/*!*******************************************************!*\
  !*** ./src/components/demo-switcher/image/bakery.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bakery-069321af4233c2271e028921b402086d.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/book.png":
/*!*****************************************************!*\
  !*** ./src/components/demo-switcher/image/book.png ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/book-6d522e5f65990451d8f13d26daceaf68.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/clothing.png":
/*!*********************************************************!*\
  !*** ./src/components/demo-switcher/image/clothing.png ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/clothing-4b013b70efab8ae19dde3fb325d0765f.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/furniture-2.png":
/*!************************************************************!*\
  !*** ./src/components/demo-switcher/image/furniture-2.png ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/furniture-2-1e66df5d88b4a436ba304b7dae93263c.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/furniture.png":
/*!**********************************************************!*\
  !*** ./src/components/demo-switcher/image/furniture.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/furniture-b3a8dc77d51bbfae07955c057f47a6c2.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/grocery-2.png":
/*!**********************************************************!*\
  !*** ./src/components/demo-switcher/image/grocery-2.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/grocery-2-b9bc1409974c7f5b2d3339bf495f96ae.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/grocery.png":
/*!********************************************************!*\
  !*** ./src/components/demo-switcher/image/grocery.png ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/grocery-7ab037810b9da31666af384988e83966.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/makeup.png":
/*!*******************************************************!*\
  !*** ./src/components/demo-switcher/image/makeup.png ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/makeup-d6164bba6f7ffd3ee517bb28a3b5a483.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/medicine.png":
/*!*********************************************************!*\
  !*** ./src/components/demo-switcher/image/medicine.png ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/medicine-253ef6a75d070ec9bc88596046e39a56.png";

/***/ }),

/***/ "./src/components/demo-switcher/image/restaurant.png":
/*!***********************************************************!*\
  !*** ./src/components/demo-switcher/image/restaurant.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/restaurant-1cd3b06c8e556ab4d9106482b154ef8e.png";

/***/ }),

/***/ "./src/components/demo-switcher/switcher-btn.tsx":
/*!*******************************************************!*\
  !*** ./src/components/demo-switcher/switcher-btn.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_modal_fullscreen_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/modal/fullscreen-modal */ "./src/components/modal/fullscreen-modal.tsx");
/* harmony import */ var _switcher_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./switcher.style */ "./src/components/demo-switcher/switcher.style.tsx");
/* harmony import */ var assets_icons_ShoppingBagAlt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! assets/icons/ShoppingBagAlt */ "./src/assets/icons/ShoppingBagAlt.tsx");
/* harmony import */ var assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! assets/icons/CloseIcon */ "./src/assets/icons/CloseIcon.tsx");
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./data */ "./src/components/demo-switcher/data.tsx");


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\demo-switcher\\switcher-btn.tsx";








const DemoSwitcher = () => {
  const {
    0: isOpen,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["SwitcherWrapper"], {
      onClick: () => setOpen(true),
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["Switcher"], {
        children: "Demos"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_modal_fullscreen_modal__WEBPACK_IMPORTED_MODULE_2__["default"], {
      isOpen: isOpen,
      onRequestClose: () => setOpen(false),
      defaultClose: false,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["Header"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["PurchaseBtn"], {
          href: "https://1.envato.market/E1DxW",
          target: "_blank",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_ShoppingBagAlt__WEBPACK_IMPORTED_MODULE_4__["ShoppingBagAlt"], {
            style: {
              marginRight: '7px',
              width: '18px'
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 13
          }, undefined), ' ', "Purchase"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["ModalTitle"], {
          children: "Demos"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["CloseButton"], {
          onClick: () => setOpen(false),
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_5__["CloseIcon"], {
            style: {
              width: 14,
              height: 14
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["Body"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_6__["Scrollbar"], {
          style: {
            height: '100%',
            maxHeight: '100%'
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["Content"], {
            children: _data__WEBPACK_IMPORTED_MODULE_7__["DemoData"].map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["DemoCard"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["DemoImageWrapper"], {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["DemoImage"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    src: item.image,
                    alt: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 58,
                    columnNumber: 23
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["VisitBtn"], {
                    className: "demo-btn",
                    href: item.link,
                    target: "_blank",
                    children: "View Demo"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 59,
                    columnNumber: 23
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 57,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 19
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_switcher_style__WEBPACK_IMPORTED_MODULE_3__["DemoTitle"], {
                children: item.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 69,
                columnNumber: 19
              }, undefined)]
            }, index, true, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 17
            }, undefined))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ __webpack_exports__["default"] = (DemoSwitcher);

/***/ }),

/***/ "./src/components/demo-switcher/switcher.style.tsx":
/*!*********************************************************!*\
  !*** ./src/components/demo-switcher/switcher.style.tsx ***!
  \*********************************************************/
/*! exports provided: SwitcherWrapper, Switcher, Header, PurchaseBtn, ModalTitle, CloseButton, Body, Content, DemoCard, VisitBtn, DemoImageWrapper, DemoImage, DemoTitle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SwitcherWrapper", function() { return SwitcherWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Switcher", function() { return Switcher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseBtn", function() { return PurchaseBtn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalTitle", function() { return ModalTitle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseButton", function() { return CloseButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Body", function() { return Body; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Content", function() { return Content; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoCard", function() { return DemoCard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VisitBtn", function() { return VisitBtn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoImageWrapper", function() { return DemoImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoImage", function() { return DemoImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoTitle", function() { return DemoTitle; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);


const pulse = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["keyframes"])(["0%{-moz-box-shadow:0 0 0 0 rgba(52,143,80,0.4);box-shadow:0 0 0 0 rgba(52,143,80,0.4);}70%{-moz-box-shadow:0 0 0 10px rgba(52,143,80,0);box-shadow:0 0 0 10px rgba(52,143,80,0);}100%{-moz-box-shadow:0 0 0 0 rgba(52,143,80,0);box-shadow:0 0 0 0 rgba(52,143,80,0);}"]);
const SwitcherWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "switcherstyle__SwitcherWrapper",
  componentId: "hvceol-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: 'auto',
  height: 'auto',
  padding: '20px 15px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  borderRadius: '6px 0 0 6px',
  boxShadow: '0 0 0 rgba(52, 143, 80, 0.4)',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  position: 'fixed',
  bottom: '100px',
  right: 0,
  zIndex: 99,
  ':focus': {
    outline: 0
  },
  '@media only screen and (max-width: 580px)': {
    bottom: '38%',
    transform: 'translateY(50%)',
    padding: '15px 13px'
  }
}), Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["animation:", " 2s infinite;"], pulse));
const Switcher = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "switcherstyle__Switcher",
  componentId: "hvceol-1"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontSize: '14px',
  fontWeight: 'medium',
  lineHeight: 1,
  color: 'white',
  textTransform: 'uppercase',
  textOrientation: 'upright',
  // writingMode: 'tb',
  writingMode: 'vertical-lr',
  fontFeatureSettings: '"vkrn", "vpal"'
}));
const Header = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "switcherstyle__Header",
  componentId: "hvceol-2"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: '100%',
  height: 100,
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  backgroundColor: 'white',
  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.08)',
  position: 'relative',
  zIndex: 1,
  '@media only screen and (max-width: 767px)': {
    height: 80,
    padding: '0 20px'
  }
}));
const PurchaseBtn = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.a.withConfig({
  displayName: "switcherstyle__PurchaseBtn",
  componentId: "hvceol-3"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontFamily: 'Lato, sans-serif',
  width: 'auto',
  height: '48px',
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  boxShadow: '0 3px 6px rgba(0, 0, 0, 0.12)',
  borderRadius: '24px',
  fontSize: 'base',
  fontWeight: 'bold',
  lineHeight: 1,
  color: 'white',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  transition: 'all 0.3s',
  '@media only screen and (max-width: 767px)': {
    height: '44px'
  },
  ':hover': {
    backgroundColor: 'primary.hover'
  },
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}), Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["css"])(["animation:", " 2s infinite;"], pulse));
const ModalTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.h3.withConfig({
  displayName: "switcherstyle__ModalTitle",
  componentId: "hvceol-4"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontFamily: 'body',
  fontSize: '36px',
  fontWeight: 'bold',
  lineHeight: 1.5,
  color: 'text.bold',
  margin: 0,
  transform: 'translateX(-50%)',
  '@media only screen and (max-width: 767px)': {
    display: 'none'
  }
}));
const CloseButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "switcherstyle__CloseButton",
  componentId: "hvceol-5"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: 40,
  height: 40,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: '#ffffff',
  color: '#0D1136',
  border: 0,
  outline: 0,
  boxShadow: 'none',
  borderRadius: '50%',
  cursor: 'pointer',
  transition: 'all 0.3s',
  ':hover': {
    backgroundColor: 'gray.500'
  },
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}));
const Body = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "switcherstyle__Body",
  componentId: "hvceol-6"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: '100%',
  height: 'calc(100% - 100px)',
  backgroundColor: 'gray.200',
  '@media only screen and (max-width: 767px)': {
    height: 'calc(100% - 80px)'
  }
}));
const Content = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "switcherstyle__Content",
  componentId: "hvceol-7"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: '100%',
  padding: '50px 30px',
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  columnGap: '50px',
  '@media only screen and (min-width: 1600px)': {
    gridTemplateColumns: '1fr 1fr 1fr'
  },
  '@media only screen and (max-width: 767px)': {
    padding: '40px 15px',
    gridTemplateColumns: '1fr'
  }
}));
const DemoCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "switcherstyle__DemoCard",
  componentId: "hvceol-8"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  marginBottom: 50
}));
const VisitBtn = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.a.withConfig({
  displayName: "switcherstyle__VisitBtn",
  componentId: "hvceol-9"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: 'auto',
  height: '48px',
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  borderRadius: 'base',
  fontSize: 'base',
  fontWeight: 'bold',
  lineHeight: 1,
  color: 'white',
  boxShadow: '0 3px 6px rgba(0, 0, 0, 0.12)',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  marginTop: -24,
  position: 'absolute',
  top: '50%',
  left: '50%',
  opacity: 0,
  transform: 'translate(-50%, -30px)',
  transition: 'all 0.3s',
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}));
const DemoImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.a.withConfig({
  displayName: "switcherstyle__DemoImageWrapper",
  componentId: "hvceol-10"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: '100%',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  ':before': {
    content: '""',
    display: 'block',
    width: 'calc(100% - 30px)',
    height: 'calc(100% - 30px)',
    position: 'absolute',
    top: '25px',
    left: '15px',
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    filter: 'blur(15px)',
    WebkitTransform: 'translateZ(0)',
    WebkitBackfaceVisibility: 'hidden',
    WebkitPerspective: 1000
  }
}));
const DemoImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "switcherstyle__DemoImage",
  componentId: "hvceol-11"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  overflow: 'hidden',
  borderRadius: '10px',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  img: {
    maxWidth: '100%',
    height: 'auto',
    borderRadius: '10px'
  },
  ':after': {
    content: '""',
    display: 'block',
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'transparent',
    zIndex: 0,
    pointerEvents: 'none',
    borderRadius: '10px',
    transition: 'all 0.1s'
  },
  ':hover': {
    '.demo-btn': {
      opacity: 1,
      transform: 'translate3d(-50%, 0, 0)'
    },
    ':after': {
      backgroundColor: 'rgba(33, 33, 33, 0.09)'
    }
  }
}));
const DemoTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "switcherstyle__DemoTitle",
  componentId: "hvceol-12"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontSize: '24px',
  fontWeight: 'bold',
  lineHeight: 1.5,
  color: 'text.bold',
  margin: '30px 0 0',
  textAlign: 'center',
  width: '100%',
  '@media only screen and (max-width: 767px)': {
    fontSize: '18px'
  }
}));

/***/ }),

/***/ "./src/components/modal/fullscreen-modal.tsx":
/*!***************************************************!*\
  !*** ./src/components/modal/fullscreen-modal.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spring */ "react-spring");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spring-modal */ "react-spring-modal");
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! assets/icons/CloseIcon */ "./src/assets/icons/CloseIcon.tsx");
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\modal\\fullscreen-modal.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const SpringModal = ({
  isOpen,
  onRequestClose,
  children,
  defaultClose = true,
  style = {}
}) => {
  const transition = Object(react_spring__WEBPACK_IMPORTED_MODULE_2__["useTransition"])(isOpen, null, {
    from: {
      opacity: 0
    },
    enter: {
      opacity: 1
    },
    leave: {
      opacity: 0
    }
  });
  const staticStyles = {
    position: "absolute",
    bottom: 0,
    left: 0,
    padding: 0,
    width: "calc(100% + 1px)",
    height: "100%",
    maxHeight: "100vh",
    backgroundColor: "#ffffff",
    borderRadius: "0px",
    zIndex: 99999
  };
  const buttonStyle = {
    width: 40,
    height: 40,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    color: "#0D1136",
    border: 0,
    outline: 0,
    boxShadow: "none",
    borderRadius: "50%",
    position: "absolute",
    top: 20,
    right: 20,
    zIndex: 100000,
    cursor: "pointer",
    ":focus": {
      outline: 0,
      boxShadow: "none"
    }
  };
  const scrollbarStyle = {
    height: "100%",
    maxHeight: "100%"
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__["BaseModal"], {
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    children: transition.map(({
      item,
      key,
      props: transitionStyles
    }) => item && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring__WEBPACK_IMPORTED_MODULE_2__["animated"].div, {
      style: _objectSpread(_objectSpread(_objectSpread({}, transitionStyles), staticStyles), style),
      children: [defaultClose && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
        type: "button",
        onClick: onRequestClose,
        style: _objectSpread({}, buttonStyle),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__["CloseIcon"], {
          style: {
            width: 12,
            height: 12
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 19
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__["Scrollbar"], {
        style: _objectSpread({}, scrollbarStyle),
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 15
      }, undefined)]
    }, key, true, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 13
    }, undefined))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 71,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SpringModal);

/***/ }),

/***/ "./src/components/scrollbar/scrollbar.tsx":
/*!************************************************!*\
  !*** ./src/components/scrollbar/scrollbar.tsx ***!
  \************************************************/
/*! exports provided: Scrollbar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Scrollbar", function() { return Scrollbar; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! overlayscrollbars-react */ "overlayscrollbars-react");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\scrollbar\\scrollbar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0Nsb3NlSWNvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9TaG9wcGluZ0JhZ0FsdC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZGVtby1zd2l0Y2hlci9kYXRhLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kZW1vLXN3aXRjaGVyL2ltYWdlL2JhZy5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZGVtby1zd2l0Y2hlci9pbWFnZS9iYWtlcnkucG5nIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2RlbW8tc3dpdGNoZXIvaW1hZ2UvYm9vay5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZGVtby1zd2l0Y2hlci9pbWFnZS9jbG90aGluZy5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZGVtby1zd2l0Y2hlci9pbWFnZS9mdXJuaXR1cmUtMi5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZGVtby1zd2l0Y2hlci9pbWFnZS9mdXJuaXR1cmUucG5nIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2RlbW8tc3dpdGNoZXIvaW1hZ2UvZ3JvY2VyeS0yLnBuZyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kZW1vLXN3aXRjaGVyL2ltYWdlL2dyb2NlcnkucG5nIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2RlbW8tc3dpdGNoZXIvaW1hZ2UvbWFrZXVwLnBuZyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kZW1vLXN3aXRjaGVyL2ltYWdlL21lZGljaW5lLnBuZyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kZW1vLXN3aXRjaGVyL2ltYWdlL3Jlc3RhdXJhbnQucG5nIiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2RlbW8tc3dpdGNoZXIvc3dpdGNoZXItYnRuLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kZW1vLXN3aXRjaGVyL3N3aXRjaGVyLnN0eWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9tb2RhbC9mdWxsc2NyZWVuLW1vZGFsLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9zY3JvbGxiYXIvc2Nyb2xsYmFyLnRzeCJdLCJuYW1lcyI6WyJDbG9zZUljb24iLCJwcm9wcyIsIlNob3BwaW5nQmFnQWx0IiwiRGVtb0RhdGEiLCJpbWFnZSIsIkJha2VyeUltZyIsInRpdGxlIiwibGluayIsIkdyb2NlcnlUd29JbWciLCJGdXJuaXR1cmVUd29JbWciLCJHcm9jZXJ5SW1nIiwiTWFrZXVwSW1nIiwiQmFnSW1nIiwiQ2xvdGhpbmdJbWciLCJGdXJuaXR1cmVJbWciLCJCb29rSW1nIiwiTWVkaWNpbmVJbWciLCJSZXN0YXVyYW50SW1nIiwiRGVtb1N3aXRjaGVyIiwiaXNPcGVuIiwic2V0T3BlbiIsInVzZVN0YXRlIiwibWFyZ2luUmlnaHQiLCJ3aWR0aCIsImhlaWdodCIsIm1heEhlaWdodCIsIm1hcCIsIml0ZW0iLCJpbmRleCIsInB1bHNlIiwia2V5ZnJhbWVzIiwiU3dpdGNoZXJXcmFwcGVyIiwic3R5bGVkIiwiYnV0dG9uIiwiY3NzIiwicGFkZGluZyIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJib3JkZXIiLCJvdXRsaW5lIiwiY3Vyc29yIiwicG9zaXRpb24iLCJib3R0b20iLCJyaWdodCIsInpJbmRleCIsInRyYW5zZm9ybSIsInN0eWxlZGNzcyIsIlN3aXRjaGVyIiwic3BhbiIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImxpbmVIZWlnaHQiLCJjb2xvciIsInRleHRUcmFuc2Zvcm0iLCJ0ZXh0T3JpZW50YXRpb24iLCJ3cml0aW5nTW9kZSIsImZvbnRGZWF0dXJlU2V0dGluZ3MiLCJIZWFkZXIiLCJkaXYiLCJQdXJjaGFzZUJ0biIsImEiLCJmb250RmFtaWx5IiwidHJhbnNpdGlvbiIsIk1vZGFsVGl0bGUiLCJoMyIsIm1hcmdpbiIsIkNsb3NlQnV0dG9uIiwiQm9keSIsIkNvbnRlbnQiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiY29sdW1uR2FwIiwiRGVtb0NhcmQiLCJmbGV4RGlyZWN0aW9uIiwibWFyZ2luQm90dG9tIiwiVmlzaXRCdG4iLCJtYXJnaW5Ub3AiLCJ0b3AiLCJsZWZ0Iiwib3BhY2l0eSIsIkRlbW9JbWFnZVdyYXBwZXIiLCJjb250ZW50IiwiZmlsdGVyIiwiV2Via2l0VHJhbnNmb3JtIiwiV2Via2l0QmFja2ZhY2VWaXNpYmlsaXR5IiwiV2Via2l0UGVyc3BlY3RpdmUiLCJEZW1vSW1hZ2UiLCJvdmVyZmxvdyIsImltZyIsIm1heFdpZHRoIiwicG9pbnRlckV2ZW50cyIsIkRlbW9UaXRsZSIsInRleHRBbGlnbiIsIlNwcmluZ01vZGFsIiwib25SZXF1ZXN0Q2xvc2UiLCJjaGlsZHJlbiIsImRlZmF1bHRDbG9zZSIsInN0eWxlIiwidXNlVHJhbnNpdGlvbiIsImZyb20iLCJlbnRlciIsImxlYXZlIiwic3RhdGljU3R5bGVzIiwiYnV0dG9uU3R5bGUiLCJzY3JvbGxiYXJTdHlsZSIsImtleSIsInRyYW5zaXRpb25TdHlsZXMiLCJTY3JvbGxiYXIiLCJjbGFzc05hbWUiLCJvcHRpb25zIiwic2Nyb2xsYmFycyIsImF1dG9IaWRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ08sTUFBTUEsU0FBUyxHQUFJQyxLQUFELElBQVc7QUFDbEMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQ0UsbUJBQVUsNkJBRFo7QUFFRSxPQUFDLEVBQUMsbU5BRko7QUFHRSxlQUFTLEVBQUMsMkJBSFo7QUFJRSxVQUFJLEVBQUM7QUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0JELENBakJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTUMsY0FBYyxHQUFJRCxLQUFELElBQVc7QUFDdkMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsSUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQ0UsUUFBRSxFQUFDLGNBREw7QUFFRSxPQUFDLEVBQUMsc09BRko7QUFHRSxlQUFTLEVBQUMsa0JBSFo7QUFJRSxVQUFJLEVBQUMsY0FKUDtBQUtFLGNBQVEsRUFBQztBQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0FsQk0sQzs7Ozs7Ozs7Ozs7O0FDRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLE1BQU1FLFFBQVEsR0FBRyxDQUN0QjtBQUNFQyxPQUFLLEVBQUVDLHdEQURUO0FBRUVDLE9BQUssRUFBRSxRQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBRHNCLEVBTXRCO0FBQ0VILE9BQUssRUFBRUksMkRBRFQ7QUFFRUYsT0FBSyxFQUFFLGdCQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBTnNCLEVBV3RCO0FBQ0VILE9BQUssRUFBRUssOERBRFQ7QUFFRUgsT0FBSyxFQUFFLGtCQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBWHNCLEVBZ0J0QjtBQUNFSCxPQUFLLEVBQUVNLHlEQURUO0FBRUVKLE9BQUssRUFBRSxTQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBaEJzQixFQXFCdEI7QUFDRUgsT0FBSyxFQUFFTyx3REFEVDtBQUVFTCxPQUFLLEVBQUUsUUFGVDtBQUdFQyxNQUFJLEVBQUU7QUFIUixDQXJCc0IsRUEwQnRCO0FBQ0VILE9BQUssRUFBRVEscURBRFQ7QUFFRU4sT0FBSyxFQUFFLEtBRlQ7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0ExQnNCLEVBK0J0QjtBQUNFSCxPQUFLLEVBQUVTLDBEQURUO0FBRUVQLE9BQUssRUFBRSxVQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBL0JzQixFQW9DdEI7QUFDRUgsT0FBSyxFQUFFVSwyREFEVDtBQUVFUixPQUFLLEVBQUUsV0FGVDtBQUdFQyxNQUFJLEVBQUU7QUFIUixDQXBDc0IsRUF5Q3RCO0FBQ0VILE9BQUssRUFBRVcsc0RBRFQ7QUFFRVQsT0FBSyxFQUFFLE1BRlQ7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0F6Q3NCLEVBOEN0QjtBQUNFSCxPQUFLLEVBQUVZLDBEQURUO0FBRUVWLE9BQUssRUFBRSxVQUZUO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBOUNzQixFQW1EdEI7QUFDRUgsT0FBSyxFQUFFYSw0REFEVDtBQUVFWCxPQUFLLEVBQUUsWUFGVDtBQUdFQyxNQUFJLEVBQUU7QUFIUixDQW5Ec0IsQ0FBakIsQzs7Ozs7Ozs7Ozs7QUNaUCxpRjs7Ozs7Ozs7Ozs7QUNBQSxvRjs7Ozs7Ozs7Ozs7QUNBQSxrRjs7Ozs7Ozs7Ozs7QUNBQSxzRjs7Ozs7Ozs7Ozs7QUNBQSx5Rjs7Ozs7Ozs7Ozs7QUNBQSx1Rjs7Ozs7Ozs7Ozs7QUNBQSx1Rjs7Ozs7Ozs7Ozs7QUNBQSxxRjs7Ozs7Ozs7Ozs7QUNBQSxvRjs7Ozs7Ozs7Ozs7QUNBQSxzRjs7Ozs7Ozs7Ozs7QUNBQSx3Rjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFlQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQSxNQUFNVyxZQUFZLEdBQUcsTUFBTTtBQUN6QixRQUFNO0FBQUEsT0FBQ0MsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBb0JDLHNEQUFRLENBQUMsS0FBRCxDQUFsQztBQUVBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsK0RBQUQ7QUFBaUIsYUFBTyxFQUFFLE1BQU1ELE9BQU8sQ0FBQyxJQUFELENBQXZDO0FBQUEsNkJBQ0UscUVBQUMsd0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBS0UscUVBQUMseUVBQUQ7QUFDRSxZQUFNLEVBQUVELE1BRFY7QUFFRSxvQkFBYyxFQUFFLE1BQU1DLE9BQU8sQ0FBQyxLQUFELENBRi9CO0FBR0Usa0JBQVksRUFBRSxLQUhoQjtBQUFBLDhCQUtFLHFFQUFDLHNEQUFEO0FBQUEsZ0NBQ0UscUVBQUMsMkRBQUQ7QUFBYSxjQUFJLEVBQUMsK0JBQWxCO0FBQWtELGdCQUFNLEVBQUMsUUFBekQ7QUFBQSxrQ0FDRSxxRUFBQywwRUFBRDtBQUFnQixpQkFBSyxFQUFFO0FBQUVFLHlCQUFXLEVBQUUsS0FBZjtBQUFzQkMsbUJBQUssRUFBRTtBQUE3QjtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLEVBQ21FLEdBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQU1FLHFFQUFDLDBEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5GLGVBUUUscUVBQUMsMkRBQUQ7QUFBYSxpQkFBTyxFQUFFLE1BQU1ILE9BQU8sQ0FBQyxLQUFELENBQW5DO0FBQUEsaUNBQ0UscUVBQUMsZ0VBQUQ7QUFBVyxpQkFBSyxFQUFFO0FBQUVHLG1CQUFLLEVBQUUsRUFBVDtBQUFhQyxvQkFBTSxFQUFFO0FBQXJCO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQWtCRSxxRUFBQyxvREFBRDtBQUFBLCtCQUNFLHFFQUFDLHdFQUFEO0FBQVcsZUFBSyxFQUFFO0FBQUVBLGtCQUFNLEVBQUUsTUFBVjtBQUFrQkMscUJBQVMsRUFBRTtBQUE3QixXQUFsQjtBQUFBLGlDQUNFLHFFQUFDLHVEQUFEO0FBQUEsc0JBQ0d0Qiw4Q0FBUSxDQUFDdUIsR0FBVCxDQUFhLENBQUNDLElBQUQsRUFBT0MsS0FBUCxrQkFDWixxRUFBQyx3REFBRDtBQUFBLHNDQUNFLHFFQUFDLGdFQUFEO0FBQUEsdUNBQ0UscUVBQUMseURBQUQ7QUFBQSwwQ0FDRTtBQUFLLHVCQUFHLEVBQUVELElBQUksQ0FBQ3ZCLEtBQWY7QUFBc0IsdUJBQUcsRUFBRXVCLElBQUksQ0FBQ3JCO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsZUFFRSxxRUFBQyx3REFBRDtBQUNFLDZCQUFTLEVBQUMsVUFEWjtBQUVFLHdCQUFJLEVBQUVxQixJQUFJLENBQUNwQixJQUZiO0FBR0UsMEJBQU0sRUFBQyxRQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFjRSxxRUFBQyx5REFBRDtBQUFBLDBCQUFZb0IsSUFBSSxDQUFDckI7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFkRjtBQUFBLGVBQWVzQixLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREQ7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBLGtCQURGO0FBbURELENBdEREOztBQXdEZVYsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDL0VBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQSxNQUFNVyxLQUFLLEdBQUdDLG1FQUFILDRRQUFYO0FBZU8sTUFBTUMsZUFBZSxHQUFHQyx3REFBTSxDQUFDQyxNQUFWO0FBQUE7QUFBQTtBQUFBLEdBQzFCQyx5REFBRyxDQUFDO0FBQ0ZYLE9BQUssRUFBRSxNQURMO0FBRUZDLFFBQU0sRUFBRSxNQUZOO0FBR0ZXLFNBQU8sRUFBRSxXQUhQO0FBSUZDLFNBQU8sRUFBRSxNQUpQO0FBS0ZDLFlBQVUsRUFBRSxRQUxWO0FBTUZDLGdCQUFjLEVBQUUsUUFOZDtBQU9GQyxpQkFBZSxFQUFFLGlCQVBmO0FBUUZDLGlCQUFlLEVBQUUsMENBUmY7QUFTRkMsY0FBWSxFQUFFLGFBVFo7QUFVRkMsV0FBUyxFQUFFLDhCQVZUO0FBV0ZDLFFBQU0sRUFBRSxDQVhOO0FBWUZDLFNBQU8sRUFBRSxDQVpQO0FBYUZDLFFBQU0sRUFBRSxTQWJOO0FBY0ZDLFVBQVEsRUFBRSxPQWRSO0FBZUZDLFFBQU0sRUFBRSxPQWZOO0FBZ0JGQyxPQUFLLEVBQUUsQ0FoQkw7QUFpQkZDLFFBQU0sRUFBRSxFQWpCTjtBQW1CRixZQUFVO0FBQ1JMLFdBQU8sRUFBRTtBQURELEdBbkJSO0FBdUJGLCtDQUE2QztBQUMzQ0csVUFBTSxFQUFFLEtBRG1DO0FBRTNDRyxhQUFTLEVBQUUsaUJBRmdDO0FBSTNDZixXQUFPLEVBQUU7QUFKa0M7QUF2QjNDLENBQUQsQ0FEdUIsRUErQjFCZ0IsNkRBL0IwQixrQ0FnQ1h0QixLQWhDVyxFQUFyQjtBQW9DQSxNQUFNdUIsUUFBUSxHQUFHcEIsd0RBQU0sQ0FBQ3FCLElBQVY7QUFBQTtBQUFBO0FBQUEsR0FDbkJuQix5REFBRyxDQUFDO0FBQ0ZvQixVQUFRLEVBQUUsTUFEUjtBQUVGQyxZQUFVLEVBQUUsUUFGVjtBQUdGQyxZQUFVLEVBQUUsQ0FIVjtBQUlGQyxPQUFLLEVBQUUsT0FKTDtBQUtGQyxlQUFhLEVBQUUsV0FMYjtBQU1GQyxpQkFBZSxFQUFFLFNBTmY7QUFPRjtBQUNBQyxhQUFXLEVBQUUsYUFSWDtBQVNGQyxxQkFBbUIsRUFBRTtBQVRuQixDQUFELENBRGdCLENBQWQ7QUFjQSxNQUFNQyxNQUFNLEdBQUc5Qix3REFBTSxDQUFDK0IsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNqQjdCLHlEQUFHLENBQUM7QUFDRlgsT0FBSyxFQUFFLE1BREw7QUFFRkMsUUFBTSxFQUFFLEdBRk47QUFHRlcsU0FBTyxFQUFFLFFBSFA7QUFJRkMsU0FBTyxFQUFFLE1BSlA7QUFLRkMsWUFBVSxFQUFFLFFBTFY7QUFNRkMsZ0JBQWMsRUFBRSxlQU5kO0FBT0ZDLGlCQUFlLEVBQUUsT0FQZjtBQVFGRyxXQUFTLEVBQUUsK0JBUlQ7QUFTRkksVUFBUSxFQUFFLFVBVFI7QUFVRkcsUUFBTSxFQUFFLENBVk47QUFZRiwrQ0FBNkM7QUFDM0N6QixVQUFNLEVBQUUsRUFEbUM7QUFFM0NXLFdBQU8sRUFBRTtBQUZrQztBQVozQyxDQUFELENBRGMsQ0FBWjtBQW9CQSxNQUFNNkIsV0FBVyxHQUFHaEMsd0RBQU0sQ0FBQ2lDLENBQVY7QUFBQTtBQUFBO0FBQUEsR0FDdEIvQix5REFBRyxDQUFDO0FBQ0ZnQyxZQUFVLEVBQUUsa0JBRFY7QUFFRjNDLE9BQUssRUFBRSxNQUZMO0FBR0ZDLFFBQU0sRUFBRSxNQUhOO0FBSUZXLFNBQU8sRUFBRSxRQUpQO0FBS0ZDLFNBQU8sRUFBRSxNQUxQO0FBTUZDLFlBQVUsRUFBRSxRQU5WO0FBT0ZDLGdCQUFjLEVBQUUsUUFQZDtBQVFGQyxpQkFBZSxFQUFFLGlCQVJmO0FBU0ZDLGlCQUFlLEVBQUUsMENBVGY7QUFVRkUsV0FBUyxFQUFFLCtCQVZUO0FBV0ZELGNBQVksRUFBRSxNQVhaO0FBWUZhLFVBQVEsRUFBRSxNQVpSO0FBYUZDLFlBQVUsRUFBRSxNQWJWO0FBY0ZDLFlBQVUsRUFBRSxDQWRWO0FBZUZDLE9BQUssRUFBRSxPQWZMO0FBZ0JGZCxRQUFNLEVBQUUsQ0FoQk47QUFpQkZDLFNBQU8sRUFBRSxDQWpCUDtBQWtCRkMsUUFBTSxFQUFFLFNBbEJOO0FBbUJGc0IsWUFBVSxFQUFFLFVBbkJWO0FBcUJGLCtDQUE2QztBQUMzQzNDLFVBQU0sRUFBRTtBQURtQyxHQXJCM0M7QUF5QkYsWUFBVTtBQUNSZSxtQkFBZSxFQUFFO0FBRFQsR0F6QlI7QUE2QkYsWUFBVTtBQUNSSyxXQUFPLEVBQUUsQ0FERDtBQUVSRixhQUFTLEVBQUU7QUFGSDtBQTdCUixDQUFELENBRG1CLEVBbUN0QlMsNkRBbkNzQixrQ0FvQ1B0QixLQXBDTyxFQUFqQjtBQXdDQSxNQUFNdUMsVUFBVSxHQUFHcEMsd0RBQU0sQ0FBQ3FDLEVBQVY7QUFBQTtBQUFBO0FBQUEsR0FDckJuQyx5REFBRyxDQUFDO0FBQ0ZnQyxZQUFVLEVBQUUsTUFEVjtBQUVGWixVQUFRLEVBQUUsTUFGUjtBQUdGQyxZQUFVLEVBQUUsTUFIVjtBQUlGQyxZQUFVLEVBQUUsR0FKVjtBQUtGQyxPQUFLLEVBQUUsV0FMTDtBQU1GYSxRQUFNLEVBQUUsQ0FOTjtBQU9GcEIsV0FBUyxFQUFFLGtCQVBUO0FBU0YsK0NBQTZDO0FBQzNDZCxXQUFPLEVBQUU7QUFEa0M7QUFUM0MsQ0FBRCxDQURrQixDQUFoQjtBQWdCQSxNQUFNbUMsV0FBVyxHQUFHdkMsd0RBQU0sQ0FBQ0MsTUFBVjtBQUFBO0FBQUE7QUFBQSxHQUN0QkMseURBQUcsQ0FBQztBQUNGWCxPQUFLLEVBQUUsRUFETDtBQUVGQyxRQUFNLEVBQUUsRUFGTjtBQUdGWSxTQUFPLEVBQUUsTUFIUDtBQUlGQyxZQUFVLEVBQUUsUUFKVjtBQUtGQyxnQkFBYyxFQUFFLFFBTGQ7QUFNRkMsaUJBQWUsRUFBRSxTQU5mO0FBT0ZrQixPQUFLLEVBQUUsU0FQTDtBQVFGZCxRQUFNLEVBQUUsQ0FSTjtBQVNGQyxTQUFPLEVBQUUsQ0FUUDtBQVVGRixXQUFTLEVBQUUsTUFWVDtBQVdGRCxjQUFZLEVBQUUsS0FYWjtBQVlGSSxRQUFNLEVBQUUsU0FaTjtBQWFGc0IsWUFBVSxFQUFFLFVBYlY7QUFlRixZQUFVO0FBQ1I1QixtQkFBZSxFQUFFO0FBRFQsR0FmUjtBQW1CRixZQUFVO0FBQ1JLLFdBQU8sRUFBRSxDQUREO0FBRVJGLGFBQVMsRUFBRTtBQUZIO0FBbkJSLENBQUQsQ0FEbUIsQ0FBakI7QUEyQkEsTUFBTThCLElBQUksR0FBR3hDLHdEQUFNLENBQUMrQixHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ2Y3Qix5REFBRyxDQUFDO0FBQ0ZYLE9BQUssRUFBRSxNQURMO0FBRUZDLFFBQU0sRUFBRSxvQkFGTjtBQUdGZSxpQkFBZSxFQUFFLFVBSGY7QUFLRiwrQ0FBNkM7QUFDM0NmLFVBQU0sRUFBRTtBQURtQztBQUwzQyxDQUFELENBRFksQ0FBVjtBQVlBLE1BQU1pRCxPQUFPLEdBQUd6Qyx3REFBTSxDQUFDK0IsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNsQjdCLHlEQUFHLENBQUM7QUFDRlgsT0FBSyxFQUFFLE1BREw7QUFFRlksU0FBTyxFQUFFLFdBRlA7QUFHRkMsU0FBTyxFQUFFLE1BSFA7QUFJRnNDLHFCQUFtQixFQUFFLFNBSm5CO0FBS0ZDLFdBQVMsRUFBRSxNQUxUO0FBT0YsZ0RBQThDO0FBQzVDRCx1QkFBbUIsRUFBRTtBQUR1QixHQVA1QztBQVdGLCtDQUE2QztBQUMzQ3ZDLFdBQU8sRUFBRSxXQURrQztBQUUzQ3VDLHVCQUFtQixFQUFFO0FBRnNCO0FBWDNDLENBQUQsQ0FEZSxDQUFiO0FBbUJBLE1BQU1FLFFBQVEsR0FBRzVDLHdEQUFNLENBQUMrQixHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ25CN0IseURBQUcsQ0FBQztBQUNGWCxPQUFLLEVBQUUsTUFETDtBQUVGYSxTQUFPLEVBQUUsTUFGUDtBQUdGeUMsZUFBYSxFQUFFLFFBSGI7QUFJRkMsY0FBWSxFQUFFO0FBSlosQ0FBRCxDQURnQixDQUFkO0FBU0EsTUFBTUMsUUFBUSxHQUFHL0Msd0RBQU0sQ0FBQ2lDLENBQVY7QUFBQTtBQUFBO0FBQUEsR0FDbkIvQix5REFBRyxDQUFDO0FBQ0ZYLE9BQUssRUFBRSxNQURMO0FBRUZDLFFBQU0sRUFBRSxNQUZOO0FBR0ZXLFNBQU8sRUFBRSxRQUhQO0FBSUZDLFNBQU8sRUFBRSxNQUpQO0FBS0ZDLFlBQVUsRUFBRSxRQUxWO0FBTUZDLGdCQUFjLEVBQUUsUUFOZDtBQU9GQyxpQkFBZSxFQUFFLGlCQVBmO0FBUUZDLGlCQUFlLEVBQUUsMENBUmY7QUFTRkMsY0FBWSxFQUFFLE1BVFo7QUFVRmEsVUFBUSxFQUFFLE1BVlI7QUFXRkMsWUFBVSxFQUFFLE1BWFY7QUFZRkMsWUFBVSxFQUFFLENBWlY7QUFhRkMsT0FBSyxFQUFFLE9BYkw7QUFjRmYsV0FBUyxFQUFFLCtCQWRUO0FBZUZDLFFBQU0sRUFBRSxDQWZOO0FBZ0JGQyxTQUFPLEVBQUUsQ0FoQlA7QUFpQkZDLFFBQU0sRUFBRSxTQWpCTjtBQWtCRm1DLFdBQVMsRUFBRSxDQUFDLEVBbEJWO0FBbUJGbEMsVUFBUSxFQUFFLFVBbkJSO0FBb0JGbUMsS0FBRyxFQUFFLEtBcEJIO0FBcUJGQyxNQUFJLEVBQUUsS0FyQko7QUFzQkZDLFNBQU8sRUFBRSxDQXRCUDtBQXVCRmpDLFdBQVMsRUFBRSx3QkF2QlQ7QUF3QkZpQixZQUFVLEVBQUUsVUF4QlY7QUEwQkYsWUFBVTtBQUNSdkIsV0FBTyxFQUFFLENBREQ7QUFFUkYsYUFBUyxFQUFFO0FBRkg7QUExQlIsQ0FBRCxDQURnQixDQUFkO0FBa0NBLE1BQU0wQyxnQkFBZ0IsR0FBR3BELHdEQUFNLENBQUNpQyxDQUFWO0FBQUE7QUFBQTtBQUFBLEdBQzNCL0IseURBQUcsQ0FBQztBQUNGWCxPQUFLLEVBQUUsTUFETDtBQUVGdUIsVUFBUSxFQUFFLFVBRlI7QUFHRlYsU0FBTyxFQUFFLE1BSFA7QUFJRkMsWUFBVSxFQUFFLFFBSlY7QUFLRkMsZ0JBQWMsRUFBRSxRQUxkO0FBT0YsYUFBVztBQUNUK0MsV0FBTyxFQUFFLElBREE7QUFFVGpELFdBQU8sRUFBRSxPQUZBO0FBR1RiLFNBQUssRUFBRSxtQkFIRTtBQUlUQyxVQUFNLEVBQUUsbUJBSkM7QUFLVHNCLFlBQVEsRUFBRSxVQUxEO0FBTVRtQyxPQUFHLEVBQUUsTUFOSTtBQU9UQyxRQUFJLEVBQUUsTUFQRztBQVFUM0MsbUJBQWUsRUFBRSxvQkFSUjtBQVNUK0MsVUFBTSxFQUFFLFlBVEM7QUFVVEMsbUJBQWUsRUFBRSxlQVZSO0FBV1RDLDRCQUF3QixFQUFFLFFBWGpCO0FBWVRDLHFCQUFpQixFQUFFO0FBWlY7QUFQVCxDQUFELENBRHdCLENBQXRCO0FBeUJBLE1BQU1DLFNBQVMsR0FBRzFELHdEQUFNLENBQUMrQixHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3BCN0IseURBQUcsQ0FBQztBQUNGeUQsVUFBUSxFQUFFLFFBRFI7QUFFRmxELGNBQVksRUFBRSxNQUZaO0FBR0ZLLFVBQVEsRUFBRSxVQUhSO0FBSUZWLFNBQU8sRUFBRSxNQUpQO0FBS0ZDLFlBQVUsRUFBRSxRQUxWO0FBTUZDLGdCQUFjLEVBQUUsUUFOZDtBQVFGc0QsS0FBRyxFQUFFO0FBQ0hDLFlBQVEsRUFBRSxNQURQO0FBRUhyRSxVQUFNLEVBQUUsTUFGTDtBQUdIaUIsZ0JBQVksRUFBRTtBQUhYLEdBUkg7QUFjRixZQUFVO0FBQ1I0QyxXQUFPLEVBQUUsSUFERDtBQUVSakQsV0FBTyxFQUFFLE9BRkQ7QUFHUmIsU0FBSyxFQUFFLE1BSEM7QUFJUkMsVUFBTSxFQUFFLE1BSkE7QUFLUnNCLFlBQVEsRUFBRSxVQUxGO0FBTVJtQyxPQUFHLEVBQUUsQ0FORztBQU9SQyxRQUFJLEVBQUUsQ0FQRTtBQVFSM0MsbUJBQWUsRUFBRSxhQVJUO0FBU1JVLFVBQU0sRUFBRSxDQVRBO0FBVVI2QyxpQkFBYSxFQUFFLE1BVlA7QUFXUnJELGdCQUFZLEVBQUUsTUFYTjtBQVlSMEIsY0FBVSxFQUFFO0FBWkosR0FkUjtBQTZCRixZQUFVO0FBQ1IsaUJBQWE7QUFDWGdCLGFBQU8sRUFBRSxDQURFO0FBRVhqQyxlQUFTLEVBQUU7QUFGQSxLQURMO0FBTVIsY0FBVTtBQUNSWCxxQkFBZSxFQUFFO0FBRFQ7QUFORjtBQTdCUixDQUFELENBRGlCLENBQWY7QUEyQ0EsTUFBTXdELFNBQVMsR0FBRy9ELHdEQUFNLENBQUNxQixJQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3BCbkIseURBQUcsQ0FBQztBQUNGb0IsVUFBUSxFQUFFLE1BRFI7QUFFRkMsWUFBVSxFQUFFLE1BRlY7QUFHRkMsWUFBVSxFQUFFLEdBSFY7QUFJRkMsT0FBSyxFQUFFLFdBSkw7QUFLRmEsUUFBTSxFQUFFLFVBTE47QUFNRjBCLFdBQVMsRUFBRSxRQU5UO0FBT0Z6RSxPQUFLLEVBQUUsTUFQTDtBQVNGLCtDQUE2QztBQUMzQytCLFlBQVEsRUFBRTtBQURpQztBQVQzQyxDQUFELENBRGlCLENBQWYsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6VFA7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFVQSxNQUFNMkMsV0FBdUMsR0FBRyxDQUFDO0FBQy9DOUUsUUFEK0M7QUFFL0MrRSxnQkFGK0M7QUFHL0NDLFVBSCtDO0FBSS9DQyxjQUFZLEdBQUcsSUFKZ0M7QUFLL0NDLE9BQUssR0FBRztBQUx1QyxDQUFELEtBTTFDO0FBQ0osUUFBTWxDLFVBQVUsR0FBR21DLGtFQUFhLENBQUNuRixNQUFELEVBQVMsSUFBVCxFQUFlO0FBQzdDb0YsUUFBSSxFQUFFO0FBQUVwQixhQUFPLEVBQUU7QUFBWCxLQUR1QztBQUU3Q3FCLFNBQUssRUFBRTtBQUFFckIsYUFBTyxFQUFFO0FBQVgsS0FGc0M7QUFHN0NzQixTQUFLLEVBQUU7QUFBRXRCLGFBQU8sRUFBRTtBQUFYO0FBSHNDLEdBQWYsQ0FBaEM7QUFNQSxRQUFNdUIsWUFBWSxHQUFHO0FBQ25CNUQsWUFBUSxFQUFFLFVBRFM7QUFFbkJDLFVBQU0sRUFBRSxDQUZXO0FBR25CbUMsUUFBSSxFQUFFLENBSGE7QUFJbkIvQyxXQUFPLEVBQUUsQ0FKVTtBQUtuQlosU0FBSyxFQUFFLGtCQUxZO0FBTW5CQyxVQUFNLEVBQUUsTUFOVztBQU9uQkMsYUFBUyxFQUFFLE9BUFE7QUFRbkJjLG1CQUFlLEVBQUUsU0FSRTtBQVNuQkUsZ0JBQVksRUFBRSxLQVRLO0FBVW5CUSxVQUFNLEVBQUU7QUFWVyxHQUFyQjtBQWFBLFFBQU0wRCxXQUFXLEdBQUc7QUFDbEJwRixTQUFLLEVBQUUsRUFEVztBQUVsQkMsVUFBTSxFQUFFLEVBRlU7QUFHbEJZLFdBQU8sRUFBRSxNQUhTO0FBSWxCQyxjQUFVLEVBQUUsUUFKTTtBQUtsQkMsa0JBQWMsRUFBRSxRQUxFO0FBTWxCQyxtQkFBZSxFQUFFLFNBTkM7QUFPbEJrQixTQUFLLEVBQUUsU0FQVztBQVFsQmQsVUFBTSxFQUFFLENBUlU7QUFTbEJDLFdBQU8sRUFBRSxDQVRTO0FBVWxCRixhQUFTLEVBQUUsTUFWTztBQVdsQkQsZ0JBQVksRUFBRSxLQVhJO0FBWWxCSyxZQUFRLEVBQUUsVUFaUTtBQWFsQm1DLE9BQUcsRUFBRSxFQWJhO0FBY2xCakMsU0FBSyxFQUFFLEVBZFc7QUFlbEJDLFVBQU0sRUFBRSxNQWZVO0FBZ0JsQkosVUFBTSxFQUFFLFNBaEJVO0FBa0JsQixjQUFVO0FBQ1JELGFBQU8sRUFBRSxDQUREO0FBRVJGLGVBQVMsRUFBRTtBQUZIO0FBbEJRLEdBQXBCO0FBd0JBLFFBQU1rRSxjQUFjLEdBQUc7QUFDckJwRixVQUFNLEVBQUUsTUFEYTtBQUVyQkMsYUFBUyxFQUFFO0FBRlUsR0FBdkI7QUFLQSxzQkFDRSxxRUFBQyw0REFBRDtBQUFXLFVBQU0sRUFBRU4sTUFBbkI7QUFBMkIsa0JBQWMsRUFBRStFLGNBQTNDO0FBQUEsY0FDRy9CLFVBQVUsQ0FBQ3pDLEdBQVgsQ0FDQyxDQUFDO0FBQUVDLFVBQUY7QUFBUWtGLFNBQVI7QUFBYTVHLFdBQUssRUFBRTZHO0FBQXBCLEtBQUQsS0FDRW5GLElBQUksaUJBQ0YscUVBQUMscURBQUQsQ0FBVSxHQUFWO0FBRUUsV0FBSyxnREFBT21GLGdCQUFQLEdBQTRCSixZQUE1QixHQUE2Q0wsS0FBN0MsQ0FGUDtBQUFBLGlCQUlHRCxZQUFZLGlCQUNYO0FBQ0UsWUFBSSxFQUFDLFFBRFA7QUFFRSxlQUFPLEVBQUVGLGNBRlg7QUFHRSxhQUFLLG9CQUFPUyxXQUFQLENBSFA7QUFBQSwrQkFLRSxxRUFBQyxnRUFBRDtBQUFXLGVBQUssRUFBRTtBQUFFcEYsaUJBQUssRUFBRSxFQUFUO0FBQWFDLGtCQUFNLEVBQUU7QUFBckI7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEosZUFhRSxxRUFBQyx3RUFBRDtBQUFXLGFBQUssb0JBQU9vRixjQUFQLENBQWhCO0FBQUEsa0JBQTBDVDtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGO0FBQUEsT0FDT1UsR0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhMO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBd0JELENBL0VEOztBQWlGZVosMEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9GQTtBQVNPLE1BQU1jLFNBQW1DLEdBQUcsVUFNN0M7QUFBQSxNQU44QztBQUNsRFosWUFEa0Q7QUFFbERhLGFBRmtEO0FBR2xEQyxXQUhrRDtBQUlsRFo7QUFKa0QsR0FNOUM7QUFBQSxNQUREcEcsS0FDQzs7QUFDSixzQkFDRSxxRUFBQyxrRkFBRDtBQUNFLFdBQU87QUFDTCtHLGVBQVMsRUFBRyxHQUFFQSxTQUFVLGdCQURuQjtBQUVMRSxnQkFBVSxFQUFFO0FBQ1ZDLGdCQUFRLEVBQUU7QUFEQTtBQUZQLE9BS0ZGLE9BTEUsQ0FEVDtBQVFFLFNBQUssRUFBRVo7QUFSVCxLQVNNcEcsS0FUTjtBQUFBLGNBV0drRztBQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBdEJNLEMiLCJmaWxlIjoiMS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ2xvc2VJY29uID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9JzEwLjAwMydcbiAgICAgIGhlaWdodD0nMTAnXG4gICAgICB2aWV3Qm94PScwIDAgMTAuMDAzIDEwJ1xuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxwYXRoXG4gICAgICAgIGRhdGEtbmFtZT0nX2lvbmljb25zX3N2Z19pb3MtY2xvc2UgKDUpJ1xuICAgICAgICBkPSdNMTY2LjY4NiwxNjUuNTVsMy41NzMtMy41NzNhLjgzNy44MzcsMCwwLDAtMS4xODQtMS4xODRsLTMuNTczLDMuNTczLTMuNTczLTMuNTczYS44MzcuODM3LDAsMSwwLTEuMTg0LDEuMTg0bDMuNTczLDMuNTczLTMuNTczLDMuNTczYS44MzcuODM3LDAsMCwwLDEuMTg0LDEuMTg0bDMuNTczLTMuNTczLDMuNTczLDMuNTczYS44MzcuODM3LDAsMCwwLDEuMTg0LTEuMTg0WidcbiAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTE2MC41IC0xNjAuNTUpJ1xuICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgU2hvcHBpbmdCYWdBbHQgPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD0nMjAnXG4gICAgICBoZWlnaHQ9JzIwJ1xuICAgICAgdmlld0JveD0nMCAwIDIwIDIwJ1xuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxwYXRoXG4gICAgICAgIGlkPSdzaG9wcGluZy1iYWcnXG4gICAgICAgIGQ9J001LDRIMTlhMSwxLDAsMCwxLDEsMVYxOWExLDEsMCwwLDEtMSwxSDVhMSwxLDAsMCwxLTEtMVY1QTEsMSwwLDAsMSw1LDRaTTIsNUEzLDMsMCwwLDEsNSwySDE5YTMsMywwLDAsMSwzLDNWMTlhMywzLDAsMCwxLTMsM0g1YTMsMywwLDAsMS0zLTNabTEwLDdDOS4yMzksMTIsNyw5LjMxNCw3LDZIOWMwLDIuNTY2LDEuNjY5LDQsMyw0czMtMS40MzQsMy00aDJDMTcsOS4zMTQsMTQuNzYxLDEyLDEyLDEyWidcbiAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTIgLTIpJ1xuICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgIGZpbGxSdWxlPSdldmVub2RkJ1xuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgR3JvY2VyeUltZyBmcm9tICcuL2ltYWdlL2dyb2NlcnkucG5nJztcbmltcG9ydCBNYWtldXBJbWcgZnJvbSAnLi9pbWFnZS9tYWtldXAucG5nJztcbmltcG9ydCBCYWdJbWcgZnJvbSAnLi9pbWFnZS9iYWcucG5nJztcbmltcG9ydCBDbG90aGluZ0ltZyBmcm9tICcuL2ltYWdlL2Nsb3RoaW5nLnBuZyc7XG5pbXBvcnQgRnVybml0dXJlSW1nIGZyb20gJy4vaW1hZ2UvZnVybml0dXJlLnBuZyc7XG5pbXBvcnQgQm9va0ltZyBmcm9tICcuL2ltYWdlL2Jvb2sucG5nJztcbmltcG9ydCBNZWRpY2luZUltZyBmcm9tICcuL2ltYWdlL21lZGljaW5lLnBuZyc7XG5pbXBvcnQgUmVzdGF1cmFudEltZyBmcm9tICcuL2ltYWdlL3Jlc3RhdXJhbnQucG5nJztcbmltcG9ydCBCYWtlcnlJbWcgZnJvbSAnLi9pbWFnZS9iYWtlcnkucG5nJztcbmltcG9ydCBHcm9jZXJ5VHdvSW1nIGZyb20gJy4vaW1hZ2UvZ3JvY2VyeS0yLnBuZyc7XG5pbXBvcnQgRnVybml0dXJlVHdvSW1nIGZyb20gJy4vaW1hZ2UvZnVybml0dXJlLTIucG5nJztcblxuZXhwb3J0IGNvbnN0IERlbW9EYXRhID0gW1xuICB7XG4gICAgaW1hZ2U6IEJha2VyeUltZyxcbiAgICB0aXRsZTogJ0Jha2VyeScsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9iYWtlcnknLFxuICB9LFxuICB7XG4gICAgaW1hZ2U6IEdyb2NlcnlUd29JbWcsXG4gICAgdGl0bGU6ICdHcm9jZXJ5IE1vZGVybicsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9ncm9jZXJ5LXR3bycsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogRnVybml0dXJlVHdvSW1nLFxuICAgIHRpdGxlOiAnRnVybml0dXJlIE1vZGVybicsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9mdXJuaXR1cmUtdHdvJyxcbiAgfSxcbiAge1xuICAgIGltYWdlOiBHcm9jZXJ5SW1nLFxuICAgIHRpdGxlOiAnR3JvY2VyeScsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9ncm9jZXJ5JyxcbiAgfSxcbiAge1xuICAgIGltYWdlOiBNYWtldXBJbWcsXG4gICAgdGl0bGU6ICdNYWtldXAnLFxuICAgIGxpbms6ICdodHRwczovL3Nob3AucmVkcS5ub3cuc2gvbWFrZXVwJyxcbiAgfSxcbiAge1xuICAgIGltYWdlOiBCYWdJbWcsXG4gICAgdGl0bGU6ICdCYWcnLFxuICAgIGxpbms6ICdodHRwczovL3Nob3AucmVkcS5ub3cuc2gvYmFncycsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogQ2xvdGhpbmdJbWcsXG4gICAgdGl0bGU6ICdDbG90aGluZycsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9jbG90aGluZycsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogRnVybml0dXJlSW1nLFxuICAgIHRpdGxlOiAnRnVybml0dXJlJyxcbiAgICBsaW5rOiAnaHR0cHM6Ly9zaG9wLnJlZHEubm93LnNoL2Z1cm5pdHVyZScsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogQm9va0ltZyxcbiAgICB0aXRsZTogJ0Jvb2snLFxuICAgIGxpbms6ICdodHRwczovL3Nob3AucmVkcS5ub3cuc2gvYm9vaycsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogTWVkaWNpbmVJbWcsXG4gICAgdGl0bGU6ICdNZWRpY2luZScsXG4gICAgbGluazogJ2h0dHBzOi8vc2hvcC5yZWRxLm5vdy5zaC9tZWRpY2luZScsXG4gIH0sXG4gIHtcbiAgICBpbWFnZTogUmVzdGF1cmFudEltZyxcbiAgICB0aXRsZTogJ1Jlc3RhdXJhbnQnLFxuICAgIGxpbms6ICdodHRwczovL3Nob3AtcmVzdGF1cmFudC52ZXJjZWwuYXBwJyxcbiAgfSxcbl07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IFwiL19uZXh0L3N0YXRpYy9pbWFnZXMvYmFnLTI5MzYyZjgyZmI5NTVhMjViMmVhNzcwN2QzN2E3ZTNmLnBuZ1wiOyIsIm1vZHVsZS5leHBvcnRzID0gXCIvX25leHQvc3RhdGljL2ltYWdlcy9iYWtlcnktMDY5MzIxYWY0MjMzYzIyNzFlMDI4OTIxYjQwMjA4NmQucG5nXCI7IiwibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL2Jvb2stNmQ1MjJlNWY2NTk5MDQ1MWQ4ZjEzZDI2ZGFjZWFmNjgucG5nXCI7IiwibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL2Nsb3RoaW5nLTRiMDEzYjcwZWZhYjhhZTE5ZGRlM2ZiMzI1ZDA3NjVmLnBuZ1wiOyIsIm1vZHVsZS5leHBvcnRzID0gXCIvX25leHQvc3RhdGljL2ltYWdlcy9mdXJuaXR1cmUtMi0xZTY2ZGY1ZDg4YjRhNDM2YmEzMDRiN2RhZTkzMjYzYy5wbmdcIjsiLCJtb2R1bGUuZXhwb3J0cyA9IFwiL19uZXh0L3N0YXRpYy9pbWFnZXMvZnVybml0dXJlLWIzYThkYzc3ZDUxYmJmYWUwNzk1NWMwNTdmNDdhNmMyLnBuZ1wiOyIsIm1vZHVsZS5leHBvcnRzID0gXCIvX25leHQvc3RhdGljL2ltYWdlcy9ncm9jZXJ5LTItYjliYzE0MDk5NzRjN2Y1YjJkMzMzOWJmNDk1Zjk2YWUucG5nXCI7IiwibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL2dyb2NlcnktN2FiMDM3ODEwYjlkYTMxNjY2YWYzODQ5ODhlODM5NjYucG5nXCI7IiwibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL21ha2V1cC1kNjE2NGJiYTZmN2ZmZDNlZTUxN2JiMjhhM2I1YTQ4My5wbmdcIjsiLCJtb2R1bGUuZXhwb3J0cyA9IFwiL19uZXh0L3N0YXRpYy9pbWFnZXMvbWVkaWNpbmUtMjUzZWY2YTc1ZDA3MGVjOWJjODg1OTYwNDZlMzlhNTYucG5nXCI7IiwibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL3Jlc3RhdXJhbnQtMWNkM2IwNmM4ZTU1NmFiNGQ5MTA2NDgyYjE1NGVmOGUucG5nXCI7IiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IEZ1bGxTY3JlZW5Nb2RhbCBmcm9tICdjb21wb25lbnRzL21vZGFsL2Z1bGxzY3JlZW4tbW9kYWwnO1xuaW1wb3J0IHtcbiAgU3dpdGNoZXJXcmFwcGVyLFxuICBTd2l0Y2hlcixcbiAgSGVhZGVyLFxuICBQdXJjaGFzZUJ0bixcbiAgTW9kYWxUaXRsZSxcbiAgQ2xvc2VCdXR0b24sXG4gIEJvZHksXG4gIENvbnRlbnQsXG4gIERlbW9DYXJkLFxuICBEZW1vSW1hZ2VXcmFwcGVyLFxuICBEZW1vSW1hZ2UsXG4gIFZpc2l0QnRuLFxuICBEZW1vVGl0bGUsXG59IGZyb20gJy4vc3dpdGNoZXIuc3R5bGUnO1xuaW1wb3J0IHsgU2hvcHBpbmdCYWdBbHQgfSBmcm9tICdhc3NldHMvaWNvbnMvU2hvcHBpbmdCYWdBbHQnO1xuaW1wb3J0IHsgQ2xvc2VJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL0Nsb3NlSWNvbic7XG5pbXBvcnQgeyBTY3JvbGxiYXIgfSBmcm9tICdjb21wb25lbnRzL3Njcm9sbGJhci9zY3JvbGxiYXInO1xuXG5pbXBvcnQgeyBEZW1vRGF0YSB9IGZyb20gJy4vZGF0YSc7XG5cbmNvbnN0IERlbW9Td2l0Y2hlciA9ICgpID0+IHtcbiAgY29uc3QgW2lzT3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFN3aXRjaGVyV3JhcHBlciBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5cbiAgICAgICAgPFN3aXRjaGVyPkRlbW9zPC9Td2l0Y2hlcj5cbiAgICAgIDwvU3dpdGNoZXJXcmFwcGVyPlxuXG4gICAgICA8RnVsbFNjcmVlbk1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNPcGVufVxuICAgICAgICBvblJlcXVlc3RDbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9XG4gICAgICAgIGRlZmF1bHRDbG9zZT17ZmFsc2V9XG4gICAgICA+XG4gICAgICAgIDxIZWFkZXI+XG4gICAgICAgICAgPFB1cmNoYXNlQnRuIGhyZWY9XCJodHRwczovLzEuZW52YXRvLm1hcmtldC9FMUR4V1wiIHRhcmdldD1cIl9ibGFua1wiPlxuICAgICAgICAgICAgPFNob3BwaW5nQmFnQWx0IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAnN3B4Jywgd2lkdGg6ICcxOHB4JyB9fSAvPnsnICd9XG4gICAgICAgICAgICBQdXJjaGFzZVxuICAgICAgICAgIDwvUHVyY2hhc2VCdG4+XG5cbiAgICAgICAgICA8TW9kYWxUaXRsZT5EZW1vczwvTW9kYWxUaXRsZT5cblxuICAgICAgICAgIDxDbG9zZUJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICA8Q2xvc2VJY29uIHN0eWxlPXt7IHdpZHRoOiAxNCwgaGVpZ2h0OiAxNCB9fSAvPlxuICAgICAgICAgIDwvQ2xvc2VCdXR0b24+XG4gICAgICAgIDwvSGVhZGVyPlxuXG4gICAgICAgIDxCb2R5PlxuICAgICAgICAgIDxTY3JvbGxiYXIgc3R5bGU9e3sgaGVpZ2h0OiAnMTAwJScsIG1heEhlaWdodDogJzEwMCUnIH19PlxuICAgICAgICAgICAgPENvbnRlbnQ+XG4gICAgICAgICAgICAgIHtEZW1vRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgPERlbW9DYXJkIGtleT17aW5kZXh9PlxuICAgICAgICAgICAgICAgICAgPERlbW9JbWFnZVdyYXBwZXI+XG4gICAgICAgICAgICAgICAgICAgIDxEZW1vSW1hZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2l0ZW0uaW1hZ2V9IGFsdD17aXRlbS50aXRsZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8VmlzaXRCdG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRlbW8tYnRuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e2l0ZW0ubGlua31cbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBEZW1vXG4gICAgICAgICAgICAgICAgICAgICAgPC9WaXNpdEJ0bj5cbiAgICAgICAgICAgICAgICAgICAgPC9EZW1vSW1hZ2U+XG4gICAgICAgICAgICAgICAgICA8L0RlbW9JbWFnZVdyYXBwZXI+XG5cbiAgICAgICAgICAgICAgICAgIDxEZW1vVGl0bGU+e2l0ZW0udGl0bGV9PC9EZW1vVGl0bGU+XG4gICAgICAgICAgICAgICAgPC9EZW1vQ2FyZD5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L0NvbnRlbnQ+XG4gICAgICAgICAgPC9TY3JvbGxiYXI+XG4gICAgICAgIDwvQm9keT5cbiAgICAgIDwvRnVsbFNjcmVlbk1vZGFsPlxuICAgIDwvPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRGVtb1N3aXRjaGVyO1xuIiwiaW1wb3J0IHN0eWxlZCwgeyBrZXlmcmFtZXMsIGNzcyBhcyBzdHlsZWRjc3MgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgY3NzIGZyb20gJ0BzdHlsZWQtc3lzdGVtL2Nzcyc7XG5cbmNvbnN0IHB1bHNlID0ga2V5ZnJhbWVzYFxuICAwJSB7XG4gICAgLW1vei1ib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoNTIsIDE0MywgODAsIDAuNCk7XG4gICAgYm94LXNoYWRvdzogMCAwIDAgMCByZ2JhKDUyLCAxNDMsIDgwLCAwLjQpO1xuICB9XG4gIDcwJSB7XG4gICAgICAtbW96LWJveC1zaGFkb3c6IDAgMCAwIDEwcHggcmdiYSg1MiwgMTQzLCA4MCwgMCk7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAxMHB4IHJnYmEoNTIsIDE0MywgODAsIDApO1xuICB9XG4gIDEwMCUge1xuICAgICAgLW1vei1ib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoNTIsIDE0MywgODAsIDApO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCByZ2JhKDUyLCAxNDMsIDgwLCAwKTtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFN3aXRjaGVyV3JhcHBlciA9IHN0eWxlZC5idXR0b248YW55PihcbiAgY3NzKHtcbiAgICB3aWR0aDogJ2F1dG8nLFxuICAgIGhlaWdodDogJ2F1dG8nLFxuICAgIHBhZGRpbmc6ICcyMHB4IDE1cHgnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgYmFja2dyb3VuZENvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICBiYWNrZ3JvdW5kSW1hZ2U6ICdsaW5lYXItZ3JhZGllbnQoLTYwZGVnLCMzNDhmNTAsICM1NmI0ZDMpJyxcbiAgICBib3JkZXJSYWRpdXM6ICc2cHggMCAwIDZweCcsXG4gICAgYm94U2hhZG93OiAnMCAwIDAgcmdiYSg1MiwgMTQzLCA4MCwgMC40KScsXG4gICAgYm9yZGVyOiAwLFxuICAgIG91dGxpbmU6IDAsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgcG9zaXRpb246ICdmaXhlZCcsXG4gICAgYm90dG9tOiAnMTAwcHgnLFxuICAgIHJpZ2h0OiAwLFxuICAgIHpJbmRleDogOTksXG5cbiAgICAnOmZvY3VzJzoge1xuICAgICAgb3V0bGluZTogMCxcbiAgICB9LFxuXG4gICAgJ0BtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTgwcHgpJzoge1xuICAgICAgYm90dG9tOiAnMzglJyxcbiAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoNTAlKScsXG5cbiAgICAgIHBhZGRpbmc6ICcxNXB4IDEzcHgnLFxuICAgIH0sXG4gIH0pLFxuICBzdHlsZWRjc3NgXG4gICAgYW5pbWF0aW9uOiAke3B1bHNlfSAycyBpbmZpbml0ZTtcbiAgYFxuKTtcblxuZXhwb3J0IGNvbnN0IFN3aXRjaGVyID0gc3R5bGVkLnNwYW48YW55PihcbiAgY3NzKHtcbiAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgIGZvbnRXZWlnaHQ6ICdtZWRpdW0nLFxuICAgIGxpbmVIZWlnaHQ6IDEsXG4gICAgY29sb3I6ICd3aGl0ZScsXG4gICAgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsXG4gICAgdGV4dE9yaWVudGF0aW9uOiAndXByaWdodCcsXG4gICAgLy8gd3JpdGluZ01vZGU6ICd0YicsXG4gICAgd3JpdGluZ01vZGU6ICd2ZXJ0aWNhbC1scicsXG4gICAgZm9udEZlYXR1cmVTZXR0aW5nczogJ1widmtyblwiLCBcInZwYWxcIicsXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgSGVhZGVyID0gc3R5bGVkLmRpdjxhbnk+KFxuICBjc3Moe1xuICAgIHdpZHRoOiAnMTAwJScsXG4gICAgaGVpZ2h0OiAxMDAsXG4gICAgcGFkZGluZzogJzAgMzBweCcsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnd2hpdGUnLFxuICAgIGJveFNoYWRvdzogJzAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDgpJyxcbiAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICB6SW5kZXg6IDEsXG5cbiAgICAnQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjdweCknOiB7XG4gICAgICBoZWlnaHQ6IDgwLFxuICAgICAgcGFkZGluZzogJzAgMjBweCcsXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBQdXJjaGFzZUJ0biA9IHN0eWxlZC5hPGFueT4oXG4gIGNzcyh7XG4gICAgZm9udEZhbWlseTogJ0xhdG8sIHNhbnMtc2VyaWYnLFxuICAgIHdpZHRoOiAnYXV0bycsXG4gICAgaGVpZ2h0OiAnNDhweCcsXG4gICAgcGFkZGluZzogJzAgMzBweCcsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgIGJhY2tncm91bmRJbWFnZTogJ2xpbmVhci1ncmFkaWVudCgtNjBkZWcsIzM0OGY1MCwgIzU2YjRkMyknLFxuICAgIGJveFNoYWRvdzogJzAgM3B4IDZweCByZ2JhKDAsIDAsIDAsIDAuMTIpJyxcbiAgICBib3JkZXJSYWRpdXM6ICcyNHB4JyxcbiAgICBmb250U2l6ZTogJ2Jhc2UnLFxuICAgIGZvbnRXZWlnaHQ6ICdib2xkJyxcbiAgICBsaW5lSGVpZ2h0OiAxLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGJvcmRlcjogMCxcbiAgICBvdXRsaW5lOiAwLFxuICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgIHRyYW5zaXRpb246ICdhbGwgMC4zcycsXG5cbiAgICAnQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjdweCknOiB7XG4gICAgICBoZWlnaHQ6ICc0NHB4JyxcbiAgICB9LFxuXG4gICAgJzpob3Zlcic6IHtcbiAgICAgIGJhY2tncm91bmRDb2xvcjogJ3ByaW1hcnkuaG92ZXInLFxuICAgIH0sXG5cbiAgICAnOmZvY3VzJzoge1xuICAgICAgb3V0bGluZTogMCxcbiAgICAgIGJveFNoYWRvdzogJ25vbmUnLFxuICAgIH0sXG4gIH0pLFxuICBzdHlsZWRjc3NgXG4gICAgYW5pbWF0aW9uOiAke3B1bHNlfSAycyBpbmZpbml0ZTtcbiAgYFxuKTtcblxuZXhwb3J0IGNvbnN0IE1vZGFsVGl0bGUgPSBzdHlsZWQuaDM8YW55PihcbiAgY3NzKHtcbiAgICBmb250RmFtaWx5OiAnYm9keScsXG4gICAgZm9udFNpemU6ICczNnB4JyxcbiAgICBmb250V2VpZ2h0OiAnYm9sZCcsXG4gICAgbGluZUhlaWdodDogMS41LFxuICAgIGNvbG9yOiAndGV4dC5ib2xkJyxcbiAgICBtYXJnaW46IDAsXG4gICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlWCgtNTAlKScsXG5cbiAgICAnQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjdweCknOiB7XG4gICAgICBkaXNwbGF5OiAnbm9uZScsXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBDbG9zZUJ1dHRvbiA9IHN0eWxlZC5idXR0b248YW55PihcbiAgY3NzKHtcbiAgICB3aWR0aDogNDAsXG4gICAgaGVpZ2h0OiA0MCxcbiAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLFxuICAgIGNvbG9yOiAnIzBEMTEzNicsXG4gICAgYm9yZGVyOiAwLFxuICAgIG91dGxpbmU6IDAsXG4gICAgYm94U2hhZG93OiAnbm9uZScsXG4gICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICB0cmFuc2l0aW9uOiAnYWxsIDAuM3MnLFxuXG4gICAgJzpob3Zlcic6IHtcbiAgICAgIGJhY2tncm91bmRDb2xvcjogJ2dyYXkuNTAwJyxcbiAgICB9LFxuXG4gICAgJzpmb2N1cyc6IHtcbiAgICAgIG91dGxpbmU6IDAsXG4gICAgICBib3hTaGFkb3c6ICdub25lJyxcbiAgICB9LFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IEJvZHkgPSBzdHlsZWQuZGl2PGFueT4oXG4gIGNzcyh7XG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgICBoZWlnaHQ6ICdjYWxjKDEwMCUgLSAxMDBweCknLFxuICAgIGJhY2tncm91bmRDb2xvcjogJ2dyYXkuMjAwJyxcblxuICAgICdAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSc6IHtcbiAgICAgIGhlaWdodDogJ2NhbGMoMTAwJSAtIDgwcHgpJyxcbiAgICB9LFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IENvbnRlbnQgPSBzdHlsZWQuZGl2PGFueT4oXG4gIGNzcyh7XG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgICBwYWRkaW5nOiAnNTBweCAzMHB4JyxcbiAgICBkaXNwbGF5OiAnZ3JpZCcsXG4gICAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzFmciAxZnInLFxuICAgIGNvbHVtbkdhcDogJzUwcHgnLFxuXG4gICAgJ0BtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTYwMHB4KSc6IHtcbiAgICAgIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMWZyIDFmcicsXG4gICAgfSxcblxuICAgICdAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSc6IHtcbiAgICAgIHBhZGRpbmc6ICc0MHB4IDE1cHgnLFxuICAgICAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzFmcicsXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBEZW1vQ2FyZCA9IHN0eWxlZC5kaXY8YW55PihcbiAgY3NzKHtcbiAgICB3aWR0aDogJzEwMCUnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcbiAgICBtYXJnaW5Cb3R0b206IDUwLFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IFZpc2l0QnRuID0gc3R5bGVkLmE8YW55PihcbiAgY3NzKHtcbiAgICB3aWR0aDogJ2F1dG8nLFxuICAgIGhlaWdodDogJzQ4cHgnLFxuICAgIHBhZGRpbmc6ICcwIDMwcHgnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgYmFja2dyb3VuZENvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICBiYWNrZ3JvdW5kSW1hZ2U6ICdsaW5lYXItZ3JhZGllbnQoLTYwZGVnLCMzNDhmNTAsICM1NmI0ZDMpJyxcbiAgICBib3JkZXJSYWRpdXM6ICdiYXNlJyxcbiAgICBmb250U2l6ZTogJ2Jhc2UnLFxuICAgIGZvbnRXZWlnaHQ6ICdib2xkJyxcbiAgICBsaW5lSGVpZ2h0OiAxLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGJveFNoYWRvdzogJzAgM3B4IDZweCByZ2JhKDAsIDAsIDAsIDAuMTIpJyxcbiAgICBib3JkZXI6IDAsXG4gICAgb3V0bGluZTogMCxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICBtYXJnaW5Ub3A6IC0yNCxcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB0b3A6ICc1MCUnLFxuICAgIGxlZnQ6ICc1MCUnLFxuICAgIG9wYWNpdHk6IDAsXG4gICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKC01MCUsIC0zMHB4KScsXG4gICAgdHJhbnNpdGlvbjogJ2FsbCAwLjNzJyxcblxuICAgICc6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAwLFxuICAgICAgYm94U2hhZG93OiAnbm9uZScsXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBEZW1vSW1hZ2VXcmFwcGVyID0gc3R5bGVkLmE8YW55PihcbiAgY3NzKHtcbiAgICB3aWR0aDogJzEwMCUnLFxuICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG5cbiAgICAnOmJlZm9yZSc6IHtcbiAgICAgIGNvbnRlbnQ6ICdcIlwiJyxcbiAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICB3aWR0aDogJ2NhbGMoMTAwJSAtIDMwcHgpJyxcbiAgICAgIGhlaWdodDogJ2NhbGMoMTAwJSAtIDMwcHgpJyxcbiAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgdG9wOiAnMjVweCcsXG4gICAgICBsZWZ0OiAnMTVweCcsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDAsIDAsIDAsIDAuMiknLFxuICAgICAgZmlsdGVyOiAnYmx1cigxNXB4KScsXG4gICAgICBXZWJraXRUcmFuc2Zvcm06ICd0cmFuc2xhdGVaKDApJyxcbiAgICAgIFdlYmtpdEJhY2tmYWNlVmlzaWJpbGl0eTogJ2hpZGRlbicsXG4gICAgICBXZWJraXRQZXJzcGVjdGl2ZTogMTAwMCxcbiAgICB9LFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IERlbW9JbWFnZSA9IHN0eWxlZC5kaXY8YW55PihcbiAgY3NzKHtcbiAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcblxuICAgIGltZzoge1xuICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgIGhlaWdodDogJ2F1dG8nLFxuICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgfSxcblxuICAgICc6YWZ0ZXInOiB7XG4gICAgICBjb250ZW50OiAnXCJcIicsXG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgIGhlaWdodDogJzEwMCUnLFxuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICB0b3A6IDAsXG4gICAgICBsZWZ0OiAwLFxuICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgekluZGV4OiAwLFxuICAgICAgcG9pbnRlckV2ZW50czogJ25vbmUnLFxuICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgICB0cmFuc2l0aW9uOiAnYWxsIDAuMXMnLFxuICAgIH0sXG5cbiAgICAnOmhvdmVyJzoge1xuICAgICAgJy5kZW1vLWJ0bic6IHtcbiAgICAgICAgb3BhY2l0eTogMSxcbiAgICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlM2QoLTUwJSwgMCwgMCknLFxuICAgICAgfSxcblxuICAgICAgJzphZnRlcic6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSgzMywgMzMsIDMzLCAwLjA5KScsXG4gICAgICB9LFxuICAgIH0sXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgRGVtb1RpdGxlID0gc3R5bGVkLnNwYW48YW55PihcbiAgY3NzKHtcbiAgICBmb250U2l6ZTogJzI0cHgnLFxuICAgIGZvbnRXZWlnaHQ6ICdib2xkJyxcbiAgICBsaW5lSGVpZ2h0OiAxLjUsXG4gICAgY29sb3I6ICd0ZXh0LmJvbGQnLFxuICAgIG1hcmdpbjogJzMwcHggMCAwJyxcbiAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgIHdpZHRoOiAnMTAwJScsXG5cbiAgICAnQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3NjdweCknOiB7XG4gICAgICBmb250U2l6ZTogJzE4cHgnLFxuICAgIH0sXG4gIH0pXG4pO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlVHJhbnNpdGlvbiwgYW5pbWF0ZWQgfSBmcm9tIFwicmVhY3Qtc3ByaW5nXCI7XG5pbXBvcnQgeyBCYXNlTW9kYWwgfSBmcm9tIFwicmVhY3Qtc3ByaW5nLW1vZGFsXCI7XG5pbXBvcnQgeyBDbG9zZUljb24gfSBmcm9tIFwiYXNzZXRzL2ljb25zL0Nsb3NlSWNvblwiO1xuaW1wb3J0IHsgU2Nyb2xsYmFyIH0gZnJvbSBcImNvbXBvbmVudHMvc2Nyb2xsYmFyL3Njcm9sbGJhclwiO1xuXG50eXBlIFNwcmluZ01vZGFsUHJvcHMgPSB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25SZXF1ZXN0Q2xvc2U6ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIHN0eWxlPzogYW55O1xuICBkZWZhdWx0Q2xvc2U/OiBib29sZWFuO1xufTtcblxuY29uc3QgU3ByaW5nTW9kYWw6IFJlYWN0LkZDPFNwcmluZ01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvblJlcXVlc3RDbG9zZSxcbiAgY2hpbGRyZW4sXG4gIGRlZmF1bHRDbG9zZSA9IHRydWUsXG4gIHN0eWxlID0ge30sXG59KSA9PiB7XG4gIGNvbnN0IHRyYW5zaXRpb24gPSB1c2VUcmFuc2l0aW9uKGlzT3BlbiwgbnVsbCwge1xuICAgIGZyb206IHsgb3BhY2l0eTogMCB9LFxuICAgIGVudGVyOiB7IG9wYWNpdHk6IDEgfSxcbiAgICBsZWF2ZTogeyBvcGFjaXR5OiAwIH0sXG4gIH0pO1xuXG4gIGNvbnN0IHN0YXRpY1N0eWxlcyA9IHtcbiAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgIGJvdHRvbTogMCxcbiAgICBsZWZ0OiAwLFxuICAgIHBhZGRpbmc6IDAsXG4gICAgd2lkdGg6IFwiY2FsYygxMDAlICsgMXB4KVwiLFxuICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgbWF4SGVpZ2h0OiBcIjEwMHZoXCIsXG4gICAgYmFja2dyb3VuZENvbG9yOiBcIiNmZmZmZmZcIixcbiAgICBib3JkZXJSYWRpdXM6IFwiMHB4XCIsXG4gICAgekluZGV4OiA5OTk5OSxcbiAgfTtcblxuICBjb25zdCBidXR0b25TdHlsZSA9IHtcbiAgICB3aWR0aDogNDAsXG4gICAgaGVpZ2h0OiA0MCxcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmZmZmXCIsXG4gICAgY29sb3I6IFwiIzBEMTEzNlwiLFxuICAgIGJvcmRlcjogMCxcbiAgICBvdXRsaW5lOiAwLFxuICAgIGJveFNoYWRvdzogXCJub25lXCIsXG4gICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIgYXMgXCJhYnNvbHV0ZVwiLFxuICAgIHRvcDogMjAsXG4gICAgcmlnaHQ6IDIwLFxuICAgIHpJbmRleDogMTAwMDAwLFxuICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG5cbiAgICBcIjpmb2N1c1wiOiB7XG4gICAgICBvdXRsaW5lOiAwLFxuICAgICAgYm94U2hhZG93OiBcIm5vbmVcIixcbiAgICB9LFxuICB9O1xuXG4gIGNvbnN0IHNjcm9sbGJhclN0eWxlID0ge1xuICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgbWF4SGVpZ2h0OiBcIjEwMCVcIixcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxCYXNlTW9kYWwgaXNPcGVuPXtpc09wZW59IG9uUmVxdWVzdENsb3NlPXtvblJlcXVlc3RDbG9zZX0+XG4gICAgICB7dHJhbnNpdGlvbi5tYXAoXG4gICAgICAgICh7IGl0ZW0sIGtleSwgcHJvcHM6IHRyYW5zaXRpb25TdHlsZXMgfSkgPT5cbiAgICAgICAgICBpdGVtICYmIChcbiAgICAgICAgICAgIDxhbmltYXRlZC5kaXZcbiAgICAgICAgICAgICAga2V5PXtrZXl9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IC4uLnRyYW5zaXRpb25TdHlsZXMsIC4uLnN0YXRpY1N0eWxlcywgLi4uc3R5bGUgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2RlZmF1bHRDbG9zZSAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblJlcXVlc3RDbG9zZX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IC4uLmJ1dHRvblN0eWxlIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENsb3NlSWNvbiBzdHlsZT17eyB3aWR0aDogMTIsIGhlaWdodDogMTIgfX0gLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPFNjcm9sbGJhciBzdHlsZT17eyAuLi5zY3JvbGxiYXJTdHlsZSB9fT57Y2hpbGRyZW59PC9TY3JvbGxiYXI+XG4gICAgICAgICAgICA8L2FuaW1hdGVkLmRpdj5cbiAgICAgICAgICApXG4gICAgICApfVxuICAgIDwvQmFzZU1vZGFsPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU3ByaW5nTW9kYWw7XG4iLCJpbXBvcnQgeyBPdmVybGF5U2Nyb2xsYmFyc0NvbXBvbmVudCB9IGZyb20gJ292ZXJsYXlzY3JvbGxiYXJzLXJlYWN0JztcblxudHlwZSBTY3JvbGxiYXJQcm9wcyA9IHtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICBvcHRpb25zPzogYW55O1xuICBzdHlsZT86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBTY3JvbGxiYXI6IFJlYWN0LkZDPFNjcm9sbGJhclByb3BzPiA9ICh7XG4gIGNoaWxkcmVuLFxuICBjbGFzc05hbWUsXG4gIG9wdGlvbnMsXG4gIHN0eWxlLFxuICAuLi5wcm9wc1xufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxPdmVybGF5U2Nyb2xsYmFyc0NvbXBvbmVudFxuICAgICAgb3B0aW9ucz17e1xuICAgICAgICBjbGFzc05hbWU6IGAke2NsYXNzTmFtZX0gb3MtdGhlbWUtdGhpbmAsXG4gICAgICAgIHNjcm9sbGJhcnM6IHtcbiAgICAgICAgICBhdXRvSGlkZTogJ2xlYXZlJyxcbiAgICAgICAgfSxcbiAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIH19XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvT3ZlcmxheVNjcm9sbGJhcnNDb21wb25lbnQ+XG4gICk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==