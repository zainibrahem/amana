exports.ids = [10];
exports.modules = {

/***/ "./src/assets/icons/CartIcon.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/CartIcon.tsx ***!
  \***************************************/
/*! exports provided: CartIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartIcon", function() { return CartIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/svg */ "./src/components/svg.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CartIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CartIcon = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_svg__WEBPACK_IMPORTED_MODULE_1__["Svg"], _objectSpread(_objectSpread({}, props), {}, {
  width: "14.4px",
  height: "12px",
  viewBox: "0 0 14.4 12",
  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
    "data-name": "Group 120",
    transform: "translate(-288 -413.89)",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "Path 154",
      fill: "currentColor",
      d: "M298.7,418.289l-2.906-4.148a.835.835,0,0,0-.528-.251.607.607,0,0,0-.529.251l-2.905,4.148h-3.17a.609.609,0,0,0-.661.625v.191l1.651,5.84a1.336,1.336,0,0,0,1.255.945h8.588a1.261,1.261,0,0,0,1.254-.945l1.651-5.84v-.191a.609.609,0,0,0-.661-.625Zm-5.419,0,1.984-2.767,1.98,2.767Zm1.984,5.024a1.258,1.258,0,1,1,1.319-1.258,1.3,1.3,0,0,1-1.319,1.258Zm0,0"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined)
}), void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 3,
  columnNumber: 3
}, undefined);

/***/ }),

/***/ "./src/assets/icons/PlusMinus.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/PlusMinus.tsx ***!
  \****************************************/
/*! exports provided: Plus, Minus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Plus", function() { return Plus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Minus", function() { return Minus; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\PlusMinus.tsx";
 // SVG plus icon

const Plus = ({
  color = 'currentColor',
  width = '12px',
  height = '12px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 12",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Group_3351",
      "data-name": "Group 3351",
      transform: "translate(-1367 -190)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 520",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1367 195)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 521",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1374 190) rotate(90)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
}; // SVG minus icon

const Minus = ({
  color = 'currentColor',
  width = '12px',
  height = '2px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 2",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
      "data-name": "Rectangle 522",
      width: "12",
      height: "2",
      rx: "1",
      fill: color
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/box.tsx":
/*!********************************!*\
  !*** ./src/components/box.tsx ***!
  \********************************/
/*! exports provided: Box */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Box", function() { return Box; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


const Box = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "box__Box",
  componentId: "sc-5533u7-0"
})({
  boxSizing: 'border-box',
  minWidth: 0,
  margin: 0
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["compose"])(styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["layout"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexbox"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"]));

/***/ }),

/***/ "./src/components/counter/counter.style.tsx":
/*!**************************************************!*\
  !*** ./src/components/counter/counter.style.tsx ***!
  \**************************************************/
/*! exports provided: CounterBox, CounterButton, CounterValue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterBox", function() { return CounterBox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterButton", function() { return CounterButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterValue", function() { return CounterValue; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_2__);



const CounterBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "counterstyle__CounterBox",
  componentId: "sc-8iu0h2-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  backgroundColor: 'primary.regular',
  color: 'white',
  fontSize: 'base',
  fontWeight: 'bold'
}), {
  borderRadius: 200,
  justifyContent: 'space-between',
  alignItems: 'center',
  overflow: 'hidden',
  flexShrink: 0,
  '&:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    horizontal: {
      width: 104,
      height: 36
    },
    vertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse'
    },
    lightHorizontal: {
      width: 104,
      height: 36,
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    lightVertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    altHorizontal: {
      width: 104,
      height: 36,
      borderRadius: '6px'
    },
    altVertical: {
      width: 30,
      height: 90,
      borderRadius: '6px'
    },
    full: {
      width: '100%',
      height: 36,
      borderRadius: '6px'
    }
  }
}));
const CounterButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "counterstyle__CounterButton",
  componentId: "sc-8iu0h2-1"
})({
  border: 'none',
  backgroundColor: 'transparent',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  padding: 10,
  cursor: 'pointer',
  '&:hover, &:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    lightHorizontal: {
      color: 'text.regular'
    },
    lightVertical: {
      color: 'text.regular'
    }
  }
}));
const CounterValue = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "counterstyle__CounterValue",
  componentId: "sc-8iu0h2-2"
})({
  pointerEvents: 'none'
});
CounterValue.displayName = 'CounterValue';
CounterButton.displayName = 'CounterButton';
CounterBox.displayName = 'CounterBox';
CounterBox.defaultProps = {
  variant: 'horizontal'
};

/***/ }),

/***/ "./src/components/counter/counter.tsx":
/*!********************************************!*\
  !*** ./src/components/counter/counter.tsx ***!
  \********************************************/
/*! exports provided: Counter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Counter", function() { return Counter; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! assets/icons/PlusMinus */ "./src/assets/icons/PlusMinus.tsx");
/* harmony import */ var _counter_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./counter.style */ "./src/components/counter/counter.style.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\counter\\counter.tsx";



const Counter = ({
  onDecrement,
  onIncrement,
  value,
  variant,
  className
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterBox"], {
    variant: variant,
    className: className,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onDecrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Minus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterValue"], {
      children: value
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onIncrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Plus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/multi-carousel/multi-carousel.tsx":
/*!**********************************************************!*\
  !*** ./src/components/multi-carousel/multi-carousel.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-multi-carousel */ "react-multi-carousel");
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\multi-carousel\\multi-carousel.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const SingleItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default.a.li.withConfig({
  displayName: "multi-carousel__SingleItem",
  componentId: "sc-1is9f8u-0"
})(["border:1px solid ", ";border-radius:", ";margin-right:20px;padding:0;outline:none;width:70px;height:auto;overflow:hidden;&:last-child{margin-right:0;}&.custom-dot--active{border:2px solid ", ";}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('colors.gray.500', '#f1f1f1'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('colors.primary.regular', '#F39C12'));
const responsive = {
  desktop: {
    breakpoint: {
      max: 3000,
      min: 1024
    },
    items: 1
  },
  mobile: {
    breakpoint: {
      max: 464,
      min: 0
    },
    items: 1
  },
  tablet: {
    breakpoint: {
      max: 1024,
      min: 200
    },
    items: 1
  }
};

const CarouselWithCustomDots = (_ref) => {
  let {
    items = [],
    title,
    deviceType: {
      mobile,
      tablet,
      desktop
    }
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["items", "title", "deviceType"]);

  const children = items.slice(0, 6).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: item.url,
    alt: title,
    style: {
      minWidth: 'auto',
      height: 'auto',
      position: 'relative',
      margin: 'auto'
    },
    className: "product-image"
  }, index, false, {
    fileName: _jsxFileName,
    lineNumber: 55,
    columnNumber: 5
  }, undefined));
  const images = items.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: item.url,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      position: 'relative'
    }
  }, index, false, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 5
  }, undefined));

  const CustomDot = ({
    index,
    onClick,
    active
  }) => {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(SingleItem, {
      "data-index": index,
      onClick: () => onClick(),
      className: `custom-dot ${active && 'custom-dot--active'}`,
      children: react__WEBPACK_IMPORTED_MODULE_1___default.a.Children.toArray(images)[index]
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, undefined);
  };

  let deviceType = 'desktop';

  if (mobile) {
    deviceType = 'mobile';
  }

  if (tablet) {
    deviceType = 'tablet';
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_multi_carousel__WEBPACK_IMPORTED_MODULE_3___default.a, _objectSpread(_objectSpread({
    showDots: true,
    ssr: true,
    infinite: true,
    slidesToSlide: 1,
    containerClass: "carousel-with-custom-dots",
    responsive: responsive,
    deviceType: deviceType,
    autoPlay: false,
    arrows: false,
    customDot: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CustomDot, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 18
    }, undefined)
  }, rest), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 102,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (CarouselWithCustomDots);

/***/ }),

/***/ "./src/components/svg.tsx":
/*!********************************!*\
  !*** ./src/components/svg.tsx ***!
  \********************************/
/*! exports provided: Svg */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Svg", function() { return Svg; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./box */ "./src/components/box.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\svg.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Svg = (_ref) => {
  let {
    size = 18
  } = _ref,
      props = _objectWithoutProperties(_ref, ["size"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_box__WEBPACK_IMPORTED_MODULE_1__["Box"], _objectSpread({
    as: "svg",
    xmlns: "http://www.w3.org/2000/svg",
    width: size + '',
    height: size + '',
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 3
  }, undefined);
};

/***/ }),

/***/ "./src/components/truncate/truncate.tsx":
/*!**********************************************!*\
  !*** ./src/components/truncate/truncate.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\truncate\\truncate.tsx";


const ReadMore = ({
  children,
  more,
  less,
  character
}) => {
  const {
    0: expanded,
    1: setExpanded
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);

  const toggleLines = event => {
    event.preventDefault();
    setExpanded(!expanded);
  };

  if (!children) return null;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [children && children.length < character || expanded ? children : children.substring(0, character), children && children.length > character && !expanded && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "#",
          onClick: toggleLines,
          style: {
            color: '#F39C12',
            fontWeight: 700
          },
          children: more
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 11
      }, undefined)]
    }, void 0, true), children && children.length > character && expanded && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "#",
          onClick: toggleLines,
          style: {
            color: '#F39C12',
            fontWeight: 700
          },
          children: less
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 11
      }, undefined)]
    }, void 0, true)]
  }, void 0, true);
};

ReadMore.defaultProps = {
  character: 150,
  more: 'Read more',
  less: 'less'
};
/* harmony default export */ __webpack_exports__["default"] = (ReadMore);

/***/ }),

/***/ "./src/features/quick-view/quick-view-mobile.tsx":
/*!*******************************************************!*\
  !*** ./src/features/quick-view/quick-view-mobile.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var _quick_view_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./quick-view.style */ "./src/features/quick-view/quick-view.style.tsx");
/* harmony import */ var assets_icons_CartIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! assets/icons/CartIcon */ "./src/assets/icons/CartIcon.tsx");
/* harmony import */ var utils_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! utils/constant */ "./src/utils/constant.ts");
/* harmony import */ var components_truncate_truncate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/truncate/truncate */ "./src/components/truncate/truncate.tsx");
/* harmony import */ var components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/multi-carousel/multi-carousel */ "./src/components/multi-carousel/multi-carousel.tsx");
/* harmony import */ var contexts_language_language_provider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! contexts/language/language.provider */ "./src/contexts/language/language.provider.tsx");
/* harmony import */ var contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! contexts/cart/use-cart */ "./src/contexts/cart/use-cart.tsx");
/* harmony import */ var components_counter_counter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/counter/counter */ "./src/components/counter/counter.tsx");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_12__);


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\features\\quick-view\\quick-view-mobile.tsx";

 // import { closeModal } from '@redq/reuse-modal';












const QuickViewMobile = ({
  modalProps,
  onModalClose,
  hideModal,
  deviceType
}) => {
  const {
    addItem,
    removeItem,
    isInCart,
    getItem
  } = Object(contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_10__["useCart"])();
  const {
    id,
    type,
    title,
    unit,
    price,
    discountInPercent,
    salePrice,
    description,
    gallery,
    categories
  } = modalProps;
  const {
    isRtl
  } = Object(contexts_language_language_provider__WEBPACK_IMPORTED_MODULE_9__["useLocale"])();

  const handleAddClick = e => {
    e.stopPropagation();
    addItem(modalProps);
  };

  const handleRemoveClick = e => {
    e.stopPropagation();
    removeItem(modalProps);
  };

  function onCategoryClick(slug) {
    next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push({
      pathname: `/${type.toLowerCase()}`,
      query: {
        category: slug
      }
    }).then(() => window.scrollTo(0, 0));
    hideModal();
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["QuickViewWrapper"], {
      className: "quick-view-mobile-wrapper",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductDetailsWrapper"], {
        className: "product-card",
        dir: "ltr",
        children: [!isRtl && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPreview"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
            items: gallery,
            deviceType: deviceType
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 15
          }, undefined), !!discountInPercent && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["DiscountPercent"], {
            children: [discountInPercent, "%"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 95,
            columnNumber: 17
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductInfoWrapper"], {
          dir: isRtl ? 'rtl' : 'ltr',
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductInfo"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductTitlePriceWrapper"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductTitle"], {
                children: title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 101,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductWeight"], {
              children: unit
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 105,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductDescription"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_truncate_truncate__WEBPACK_IMPORTED_MODULE_7__["default"], {
                character: 600,
                children: description
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 107,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 106,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductMeta"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["MetaSingle"], {
                children: categories ? categories.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["MetaItem"], {
                  onClick: () => onCategoryClick(item.slug),
                  children: item.title
                }, item.id, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 25
                }, undefined)) : ''
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 110,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductCartWrapper"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPriceWrapper"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPrice"], {
                  children: [utils_constant__WEBPACK_IMPORTED_MODULE_6__["CURRENCY"], salePrice ? salePrice : price]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 127,
                  columnNumber: 19
                }, undefined), discountInPercent ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["SalePrice"], {
                  children: [utils_constant__WEBPACK_IMPORTED_MODULE_6__["CURRENCY"], price]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 133,
                  columnNumber: 21
                }, undefined) : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 126,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductCartBtn"], {
                children: !isInCart(id) ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                  className: "cart-button",
                  variant: "secondary",
                  borderRadius: 100,
                  onClick: handleAddClick,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CartIcon__WEBPACK_IMPORTED_MODULE_5__["CartIcon"], {
                    mr: 2
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 148,
                    columnNumber: 23
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ButtonText"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_12__["FormattedMessage"], {
                      id: "addCartButton",
                      defaultMessage: "Cart"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 150,
                      columnNumber: 25
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 149,
                    columnNumber: 23
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 142,
                  columnNumber: 21
                }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_counter_counter__WEBPACK_IMPORTED_MODULE_11__["Counter"], {
                  value: getItem(id).quantity,
                  onDecrement: handleRemoveClick,
                  onIncrement: handleAddClick
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 157,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 100,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 99,
          columnNumber: 11
        }, undefined), isRtl && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPreview"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
            items: gallery,
            deviceType: deviceType
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 15
          }, undefined), !!discountInPercent && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["DiscountPercent"], {
            children: [discountInPercent, "%"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 172,
            columnNumber: 17
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 169,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 89,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ __webpack_exports__["default"] = (QuickViewMobile);

/***/ }),

/***/ "./src/features/quick-view/quick-view.style.tsx":
/*!******************************************************!*\
  !*** ./src/features/quick-view/quick-view.style.tsx ***!
  \******************************************************/
/*! exports provided: ProductDetailsWrapper, ProductPreview, SaleTag, DiscountPercent, ProductInfoWrapper, ProductInfo, ProductTitlePriceWrapper, ProductTitle, ProductPriceWrapper, ProductPrice, SalePrice, ProductWeight, ProductDescription, ProductCartBtn, ButtonText, ProductCartWrapper, ProductMeta, MetaSingle, MetaItem, ModalClose, QuickViewWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsWrapper", function() { return ProductDetailsWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPreview", function() { return ProductPreview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleTag", function() { return SaleTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPercent", function() { return DiscountPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfoWrapper", function() { return ProductInfoWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfo", function() { return ProductInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductTitlePriceWrapper", function() { return ProductTitlePriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductTitle", function() { return ProductTitle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPriceWrapper", function() { return ProductPriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPrice", function() { return ProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalePrice", function() { return SalePrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductWeight", function() { return ProductWeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDescription", function() { return ProductDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCartBtn", function() { return ProductCartBtn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonText", function() { return ButtonText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCartWrapper", function() { return ProductCartWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductMeta", function() { return ProductMeta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetaSingle", function() { return MetaSingle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetaItem", function() { return MetaItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalClose", function() { return ModalClose; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuickViewWrapper", function() { return QuickViewWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const ProductDetailsWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductDetailsWrapper",
  componentId: "d67ysb-0"
})(["background-color:", ";position:relative;display:flex;flex-wrap:wrap;align-items:stretch;min-height:100%;border-radius:", ";overflow:hidden;box-sizing:border-box;@media (max-width:767px){box-shadow:none;}*{box-sizing:border-box;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const ProductPreview = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPreview",
  componentId: "d67ysb-1"
})(["width:50%;max-width:50%;padding:30px 60px;display:flex;align-items:center;justify-content:center;position:relative;@media (max-width:767px){width:100%;max-width:100%;padding:20px 0px;order:0;}img{width:100%;@media (max-width:767px){min-width:auto !important;}}"]);
const SaleTag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__SaleTag",
  componentId: "d67ysb-2"
})(["font-size:", "px;font-weight:", ";color:", ";background-color:", ";padding:0 10px;line-height:24px;border-radius:", ";display:inline-block;position:absolute;top:40px;right:30px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const DiscountPercent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__DiscountPercent",
  componentId: "d67ysb-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:24px;background-color:", ";padding-left:10px;padding-right:10px;position:relative;display:inline-block;position:absolute;top:30px;right:30px;border-radius:", ";-webkit-transform:translate3d(0,0,1px);transform:translate3d(0,0,1px);"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const ProductInfoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductInfoWrapper",
  componentId: "d67ysb-4"
})(["width:50%;max-width:50%;border-left:1px solid ", ";@media (max-width:767px){width:100%;max-width:100%;padding:30px 0 0;order:1;border:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.lightMediumColor', '#f3f3f3'));
const ProductInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductInfo",
  componentId: "d67ysb-5"
})(["padding:50px;@media (max-width:767px){padding:0;}"]);
const ProductTitlePriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductTitlePriceWrapper",
  componentId: "d67ysb-6"
})(["width:100%;display:flex;align-items:flex-start;justify-content:flex-start;margin-bottom:10px;"]);
const ProductTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.h1.withConfig({
  displayName: "quick-viewstyle__ProductTitle",
  componentId: "d67ysb-7"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1.5;display:flex;@media (max-width:767px){word-break:break-word;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.heading', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.semiBold', '600'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const ProductPriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPriceWrapper",
  componentId: "d67ysb-8"
})(["display:flex;align-items:center;flex-shrink:0;margin-left:25px;line-height:31px;@media (max-width:767px){margin-left:15px;}"]);
const ProductPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPrice",
  componentId: "d67ysb-9"
})(["font-family:", ";font-size:calc(", "px + 1px);font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const SalePrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__SalePrice",
  componentId: "d67ysb-10"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;overflow:hidden;position:relative;margin-left:10px;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'));
const ProductWeight = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductWeight",
  componentId: "d67ysb-11"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const ProductDescription = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.p.withConfig({
  displayName: "quick-viewstyle__ProductDescription",
  componentId: "d67ysb-12"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:2;margin-top:30px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.medium', '#424561'));
const ProductCartBtn = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductCartBtn",
  componentId: "d67ysb-13"
})(["margin-top:60px;@media (max-width:767px){margin-top:40px;}.cart-button{font-family:", ";font-size:", "px;font-weight:", ";color:", ";height:36px;border-radius:4rem;.btn-icon{margin-right:5px;}&:hover{color:", ";background-color:", ";border-color:", ";}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__ButtonText",
  componentId: "d67ysb-14"
})([""]);
const ProductCartWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductCartWrapper",
  componentId: "d67ysb-15"
})(["display:flex;flex-direction:column;"]);
const ProductMeta = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductMeta",
  componentId: "d67ysb-16"
})(["margin-top:30px;"]);
const MetaSingle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__MetaSingle",
  componentId: "d67ysb-17"
})(["display:flex;flex-wrap:wrap;align-items:center;margin-bottom:10px;&:last-child{margin-bottom:0;}"]);
const MetaItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__MetaItem",
  componentId: "d67ysb-18"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin-right:10px;margin-bottom:10px;background-color:", ";padding:0 15px;border-radius:", ";cursor:pointer;height:30px;display:flex;align-items:center;justify-content:center;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.200', '#f7f7f7'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const ModalClose = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "quick-viewstyle__ModalClose",
  componentId: "d67ysb-19"
})(["position:fixed;top:20px;right:15px;padding:10px 15px;z-index:1;cursor:pointer;display:block;color:rgba(0,0,0,0.5);background:transparent;border:0;outline:none;display:inline-block;svg{width:12px;height:12px;}@media (max-width:767px){top:5px;right:0;}"]);
const QuickViewWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__QuickViewWrapper",
  componentId: "d67ysb-20"
})(["width:1020px;max-width:100%;height:100%;&.quick-view-mobile-wrapper{", "{display:flex;flex-direction:row;justify-content:space-between;margin-top:30px;margin-bottom:15px;}", "{font-size:", "px;}", "{font-size:", "px;}", "{margin-top:0px;@media (max-width:767px){margin-top:0px;}}", "{font-size:", "px;}", "{margin-left:0;@media (max-width:767px){margin-left:0;}}}"], ProductCartWrapper, SalePrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), ProductPrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), ProductCartBtn, ProductPrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), ProductPriceWrapper);

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0NhcnRJY29uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1BsdXNNaW51cy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvYm94LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jb3VudGVyL2NvdW50ZXIuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NvdW50ZXIvY291bnRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbXVsdGktY2Fyb3VzZWwvbXVsdGktY2Fyb3VzZWwudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3N2Zy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvdHJ1bmNhdGUvdHJ1bmNhdGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9mZWF0dXJlcy9xdWljay12aWV3L3F1aWNrLXZpZXctbW9iaWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvZmVhdHVyZXMvcXVpY2stdmlldy9xdWljay12aWV3LnN0eWxlLnRzeCJdLCJuYW1lcyI6WyJDYXJ0SWNvbiIsInByb3BzIiwiUGx1cyIsImNvbG9yIiwid2lkdGgiLCJoZWlnaHQiLCJNaW51cyIsIkJveCIsInN0eWxlZCIsImRpdiIsImJveFNpemluZyIsIm1pbldpZHRoIiwibWFyZ2luIiwiY29tcG9zZSIsInNwYWNlIiwibGF5b3V0IiwiZmxleGJveCIsInBvc2l0aW9uIiwiQ291bnRlckJveCIsImNzcyIsImRpc3BsYXkiLCJiYWNrZ3JvdW5kQ29sb3IiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJvdmVyZmxvdyIsImZsZXhTaHJpbmsiLCJvdXRsaW5lIiwidmFyaWFudCIsInZhcmlhbnRzIiwiaG9yaXpvbnRhbCIsInZlcnRpY2FsIiwiZmxleERpcmVjdGlvbiIsImxpZ2h0SG9yaXpvbnRhbCIsImxpZ2h0VmVydGljYWwiLCJhbHRIb3Jpem9udGFsIiwiYWx0VmVydGljYWwiLCJmdWxsIiwiQ291bnRlckJ1dHRvbiIsImJ1dHRvbiIsImJvcmRlciIsInBhZGRpbmciLCJjdXJzb3IiLCJDb3VudGVyVmFsdWUiLCJzcGFuIiwicG9pbnRlckV2ZW50cyIsImRpc3BsYXlOYW1lIiwiZGVmYXVsdFByb3BzIiwiQ291bnRlciIsIm9uRGVjcmVtZW50Iiwib25JbmNyZW1lbnQiLCJ2YWx1ZSIsImNsYXNzTmFtZSIsIlNpbmdsZUl0ZW0iLCJsaSIsInRoZW1lR2V0IiwicmVzcG9uc2l2ZSIsImRlc2t0b3AiLCJicmVha3BvaW50IiwibWF4IiwibWluIiwiaXRlbXMiLCJtb2JpbGUiLCJ0YWJsZXQiLCJDYXJvdXNlbFdpdGhDdXN0b21Eb3RzIiwidGl0bGUiLCJkZXZpY2VUeXBlIiwicmVzdCIsImNoaWxkcmVuIiwic2xpY2UiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ1cmwiLCJpbWFnZXMiLCJDdXN0b21Eb3QiLCJvbkNsaWNrIiwiYWN0aXZlIiwiUmVhY3QiLCJDaGlsZHJlbiIsInRvQXJyYXkiLCJTdmciLCJzaXplIiwiUmVhZE1vcmUiLCJtb3JlIiwibGVzcyIsImNoYXJhY3RlciIsImV4cGFuZGVkIiwic2V0RXhwYW5kZWQiLCJ1c2VTdGF0ZSIsInRvZ2dsZUxpbmVzIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxlbmd0aCIsInN1YnN0cmluZyIsIlF1aWNrVmlld01vYmlsZSIsIm1vZGFsUHJvcHMiLCJvbk1vZGFsQ2xvc2UiLCJoaWRlTW9kYWwiLCJhZGRJdGVtIiwicmVtb3ZlSXRlbSIsImlzSW5DYXJ0IiwiZ2V0SXRlbSIsInVzZUNhcnQiLCJpZCIsInR5cGUiLCJ1bml0IiwicHJpY2UiLCJkaXNjb3VudEluUGVyY2VudCIsInNhbGVQcmljZSIsImRlc2NyaXB0aW9uIiwiZ2FsbGVyeSIsImNhdGVnb3JpZXMiLCJpc1J0bCIsInVzZUxvY2FsZSIsImhhbmRsZUFkZENsaWNrIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsImhhbmRsZVJlbW92ZUNsaWNrIiwib25DYXRlZ29yeUNsaWNrIiwic2x1ZyIsIlJvdXRlciIsInB1c2giLCJwYXRobmFtZSIsInRvTG93ZXJDYXNlIiwicXVlcnkiLCJjYXRlZ29yeSIsInRoZW4iLCJ3aW5kb3ciLCJzY3JvbGxUbyIsIkNVUlJFTkNZIiwicXVhbnRpdHkiLCJQcm9kdWN0RGV0YWlsc1dyYXBwZXIiLCJQcm9kdWN0UHJldmlldyIsIlNhbGVUYWciLCJEaXNjb3VudFBlcmNlbnQiLCJQcm9kdWN0SW5mb1dyYXBwZXIiLCJQcm9kdWN0SW5mbyIsIlByb2R1Y3RUaXRsZVByaWNlV3JhcHBlciIsIlByb2R1Y3RUaXRsZSIsImgxIiwiUHJvZHVjdFByaWNlV3JhcHBlciIsIlByb2R1Y3RQcmljZSIsIlNhbGVQcmljZSIsIlByb2R1Y3RXZWlnaHQiLCJQcm9kdWN0RGVzY3JpcHRpb24iLCJwIiwiUHJvZHVjdENhcnRCdG4iLCJCdXR0b25UZXh0IiwiUHJvZHVjdENhcnRXcmFwcGVyIiwiUHJvZHVjdE1ldGEiLCJNZXRhU2luZ2xlIiwiTWV0YUl0ZW0iLCJNb2RhbENsb3NlIiwiUXVpY2tWaWV3V3JhcHBlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ08sTUFBTUEsUUFBUSxHQUFJQyxLQUFELGlCQUN0QixxRUFBQyxrREFBRCxrQ0FBU0EsS0FBVDtBQUFnQixPQUFLLEVBQUMsUUFBdEI7QUFBK0IsUUFBTSxFQUFDLE1BQXRDO0FBQTZDLFNBQU8sRUFBQyxhQUFyRDtBQUFBLHlCQUNFO0FBQUcsaUJBQVUsV0FBYjtBQUF5QixhQUFTLEVBQUMseUJBQW5DO0FBQUEsMkJBQ0U7QUFDRSxtQkFBVSxVQURaO0FBRUUsVUFBSSxFQUFDLGNBRlA7QUFHRSxPQUFDLEVBQUM7QUFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0NBUDs7QUFDTyxNQUFNQyxJQUFJLEdBQUcsQ0FBQztBQUNuQkMsT0FBSyxHQUFHLGNBRFc7QUFFbkJDLE9BQUssR0FBRyxNQUZXO0FBR25CQyxRQUFNLEdBQUc7QUFIVSxDQUFELEtBSWQ7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsWUFETDtBQUVFLG1CQUFVLFlBRlo7QUFHRSxlQUFTLEVBQUMsdUJBSFo7QUFBQSw4QkFLRTtBQUNFLHFCQUFVLGVBRFo7QUFFRSxhQUFLLEVBQUMsSUFGUjtBQUdFLGNBQU0sRUFBQyxHQUhUO0FBSUUsVUFBRSxFQUFDLEdBSkw7QUFLRSxpQkFBUyxFQUFDLHFCQUxaO0FBTUUsWUFBSSxFQUFFRjtBQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFhRTtBQUNFLHFCQUFVLGVBRFo7QUFFRSxhQUFLLEVBQUMsSUFGUjtBQUdFLGNBQU0sRUFBQyxHQUhUO0FBSUUsVUFBRSxFQUFDLEdBSkw7QUFLRSxpQkFBUyxFQUFDLGdDQUxaO0FBTUUsWUFBSSxFQUFFQTtBQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBK0JELENBcENNLEMsQ0FzQ1A7O0FBQ08sTUFBTUcsS0FBSyxHQUFHLENBQUM7QUFDcEJILE9BQUssR0FBRyxjQURZO0FBRXBCQyxPQUFLLEdBQUcsTUFGWTtBQUdwQkMsUUFBTSxHQUFHO0FBSFcsQ0FBRCxLQUlmO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsVUFKVjtBQUFBLDJCQU1FO0FBQ0UsbUJBQVUsZUFEWjtBQUVFLFdBQUssRUFBQyxJQUZSO0FBR0UsWUFBTSxFQUFDLEdBSFQ7QUFJRSxRQUFFLEVBQUMsR0FKTDtBQUtFLFVBQUksRUFBRUY7QUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0JELENBckJNLEM7Ozs7Ozs7Ozs7OztBQ3pDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBU08sTUFBTUksR0FBRyxHQUFHQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ2Q7QUFDRUMsV0FBUyxFQUFFLFlBRGI7QUFFRUMsVUFBUSxFQUFFLENBRlo7QUFHRUMsUUFBTSxFQUFFO0FBSFYsQ0FEYyxFQU1kQyw2REFBTyxDQUFDQyxtREFBRCxFQUFRWCxtREFBUixFQUFlWSxvREFBZixFQUF1QkMscURBQXZCLEVBQWdDQyxzREFBaEMsQ0FOTyxDQUFULEM7Ozs7Ozs7Ozs7OztBQ1ZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ08sTUFBTUMsVUFBVSxHQUFHVix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3JCVSx5REFBRyxDQUFDO0FBQ0ZDLFNBQU8sRUFBRSxNQURQO0FBRUZDLGlCQUFlLEVBQUUsaUJBRmY7QUFHRmxCLE9BQUssRUFBRSxPQUhMO0FBSUZtQixVQUFRLEVBQUUsTUFKUjtBQUtGQyxZQUFVLEVBQUU7QUFMVixDQUFELENBRGtCLEVBUXJCO0FBQ0VDLGNBQVksRUFBRSxHQURoQjtBQUVFQyxnQkFBYyxFQUFFLGVBRmxCO0FBR0VDLFlBQVUsRUFBRSxRQUhkO0FBSUVDLFVBQVEsRUFBRSxRQUpaO0FBS0VDLFlBQVUsRUFBRSxDQUxkO0FBTUUsYUFBVztBQUNUQyxXQUFPLEVBQUU7QUFEQTtBQU5iLENBUnFCLEVBa0JyQkMsNkRBQU8sQ0FBQztBQUNOQyxVQUFRLEVBQUU7QUFDUkMsY0FBVSxFQUFFO0FBQ1Y1QixXQUFLLEVBQUUsR0FERztBQUVWQyxZQUFNLEVBQUU7QUFGRSxLQURKO0FBS1I0QixZQUFRLEVBQUU7QUFDUjdCLFdBQUssRUFBRSxFQURDO0FBRVJDLFlBQU0sRUFBRSxFQUZBO0FBR1I2QixtQkFBYSxFQUFFO0FBSFAsS0FMRjtBQVVSQyxtQkFBZSxFQUFFO0FBQ2YvQixXQUFLLEVBQUUsR0FEUTtBQUVmQyxZQUFNLEVBQUUsRUFGTztBQUdmZ0IscUJBQWUsRUFBRSxVQUhGO0FBSWZsQixXQUFLLEVBQUU7QUFKUSxLQVZUO0FBZ0JSaUMsaUJBQWEsRUFBRTtBQUNiaEMsV0FBSyxFQUFFLEVBRE07QUFFYkMsWUFBTSxFQUFFLEVBRks7QUFHYjZCLG1CQUFhLEVBQUUsZ0JBSEY7QUFJYmIscUJBQWUsRUFBRSxVQUpKO0FBS2JsQixXQUFLLEVBQUU7QUFMTSxLQWhCUDtBQXVCUmtDLGlCQUFhLEVBQUU7QUFDYmpDLFdBQUssRUFBRSxHQURNO0FBRWJDLFlBQU0sRUFBRSxFQUZLO0FBR2JtQixrQkFBWSxFQUFFO0FBSEQsS0F2QlA7QUE0QlJjLGVBQVcsRUFBRTtBQUNYbEMsV0FBSyxFQUFFLEVBREk7QUFFWEMsWUFBTSxFQUFFLEVBRkc7QUFHWG1CLGtCQUFZLEVBQUU7QUFISCxLQTVCTDtBQWlDUmUsUUFBSSxFQUFFO0FBQ0puQyxXQUFLLEVBQUUsTUFESDtBQUVKQyxZQUFNLEVBQUUsRUFGSjtBQUdKbUIsa0JBQVksRUFBRTtBQUhWO0FBakNFO0FBREosQ0FBRCxDQWxCYyxDQUFoQjtBQTZEQSxNQUFNZ0IsYUFBYSxHQUFHaEMsd0RBQU0sQ0FBQ2lDLE1BQVY7QUFBQTtBQUFBO0FBQUEsR0FDeEI7QUFDRUMsUUFBTSxFQUFFLE1BRFY7QUFFRXJCLGlCQUFlLEVBQUUsYUFGbkI7QUFHRWxCLE9BQUssRUFBRSxPQUhUO0FBSUVpQixTQUFPLEVBQUUsTUFKWDtBQUtFTSxZQUFVLEVBQUUsUUFMZDtBQU1FRCxnQkFBYyxFQUFFLFFBTmxCO0FBT0VwQixRQUFNLEVBQUUsTUFQVjtBQVFFc0MsU0FBTyxFQUFFLEVBUlg7QUFTRUMsUUFBTSxFQUFFLFNBVFY7QUFVRSxzQkFBb0I7QUFDbEJmLFdBQU8sRUFBRTtBQURTO0FBVnRCLENBRHdCLEVBZXhCQyw2REFBTyxDQUFDO0FBQ05DLFVBQVEsRUFBRTtBQUNSSSxtQkFBZSxFQUFFO0FBQ2ZoQyxXQUFLLEVBQUU7QUFEUSxLQURUO0FBSVJpQyxpQkFBYSxFQUFFO0FBQ2JqQyxXQUFLLEVBQUU7QUFETTtBQUpQO0FBREosQ0FBRCxDQWZpQixDQUFuQjtBQTJCQSxNQUFNMEMsWUFBWSxHQUFHckMsd0RBQU0sQ0FBQ3NDLElBQVY7QUFBQTtBQUFBO0FBQUEsR0FBZTtBQUN0Q0MsZUFBYSxFQUFFO0FBRHVCLENBQWYsQ0FBbEI7QUFHUEYsWUFBWSxDQUFDRyxXQUFiLEdBQTJCLGNBQTNCO0FBQ0FSLGFBQWEsQ0FBQ1EsV0FBZCxHQUE0QixlQUE1QjtBQUNBOUIsVUFBVSxDQUFDOEIsV0FBWCxHQUF5QixZQUF6QjtBQUNBOUIsVUFBVSxDQUFDK0IsWUFBWCxHQUEwQjtBQUN4Qm5CLFNBQU8sRUFBRTtBQURlLENBQTFCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqR0E7QUFDQTtBQUNBO0FBU08sTUFBTW9CLE9BQXdCLEdBQUcsQ0FBQztBQUN2Q0MsYUFEdUM7QUFFdkNDLGFBRnVDO0FBR3ZDQyxPQUh1QztBQUl2Q3ZCLFNBSnVDO0FBS3ZDd0I7QUFMdUMsQ0FBRCxLQU1sQztBQUNKLHNCQUNFLHFFQUFDLHlEQUFEO0FBQVksV0FBTyxFQUFFeEIsT0FBckI7QUFBOEIsYUFBUyxFQUFFd0IsU0FBekM7QUFBQSw0QkFDRSxxRUFBQyw0REFBRDtBQUNFLGFBQU8sRUFBRUgsV0FEWDtBQUVFLGFBQU8sRUFBRXJCLE9BRlg7QUFHRSxlQUFTLEVBQUMsZ0JBSFo7QUFBQSw2QkFLRSxxRUFBQyw0REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVFFLHFFQUFDLDJEQUFEO0FBQUEsZ0JBQWV1QjtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkYsZUFTRSxxRUFBQyw0REFBRDtBQUNFLGFBQU8sRUFBRUQsV0FEWDtBQUVFLGFBQU8sRUFBRXRCLE9BRlg7QUFHRSxlQUFTLEVBQUMsZ0JBSFo7QUFBQSw2QkFLRSxxRUFBQywyREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQTFCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYUDtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU15QixVQUFVLEdBQUcvQyx3REFBTSxDQUFDZ0QsRUFBVjtBQUFBO0FBQUE7QUFBQSwyTUFDTUMseUVBQVEsQ0FBQyxpQkFBRCxFQUFvQixTQUFwQixDQURkLEVBRUdBLHlFQUFRLENBQUMsWUFBRCxFQUFlLEtBQWYsQ0FGWCxFQWVRQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBZmhCLENBQWhCO0FBa0JBLE1BQU1DLFVBQVUsR0FBRztBQUNqQkMsU0FBTyxFQUFFO0FBQ1BDLGNBQVUsRUFBRTtBQUNWQyxTQUFHLEVBQUUsSUFESztBQUVWQyxTQUFHLEVBQUU7QUFGSyxLQURMO0FBS1BDLFNBQUssRUFBRTtBQUxBLEdBRFE7QUFRakJDLFFBQU0sRUFBRTtBQUNOSixjQUFVLEVBQUU7QUFDVkMsU0FBRyxFQUFFLEdBREs7QUFFVkMsU0FBRyxFQUFFO0FBRkssS0FETjtBQUtOQyxTQUFLLEVBQUU7QUFMRCxHQVJTO0FBZWpCRSxRQUFNLEVBQUU7QUFDTkwsY0FBVSxFQUFFO0FBQ1ZDLFNBQUcsRUFBRSxJQURLO0FBRVZDLFNBQUcsRUFBRTtBQUZLLEtBRE47QUFLTkMsU0FBSyxFQUFFO0FBTEQ7QUFmUyxDQUFuQjs7QUF3QkEsTUFBTUcsc0JBQXNCLEdBQUcsVUFLcEI7QUFBQSxNQUxxQjtBQUM5QkgsU0FBSyxHQUFHLEVBRHNCO0FBRTlCSSxTQUY4QjtBQUc5QkMsY0FBVSxFQUFFO0FBQUVKLFlBQUY7QUFBVUMsWUFBVjtBQUFrQk47QUFBbEI7QUFIa0IsR0FLckI7QUFBQSxNQUROVSxJQUNNOztBQUNULFFBQU1DLFFBQVEsR0FBR1AsS0FBSyxDQUFDUSxLQUFOLENBQVksQ0FBWixFQUFlLENBQWYsRUFBa0JDLEdBQWxCLENBQXNCLENBQUNDLElBQUQsRUFBWUMsS0FBWixrQkFDckM7QUFDRSxPQUFHLEVBQUVELElBQUksQ0FBQ0UsR0FEWjtBQUdFLE9BQUcsRUFBRVIsS0FIUDtBQUlFLFNBQUssRUFBRTtBQUNMeEQsY0FBUSxFQUFFLE1BREw7QUFFTE4sWUFBTSxFQUFFLE1BRkg7QUFHTFksY0FBUSxFQUFFLFVBSEw7QUFJTEwsWUFBTSxFQUFFO0FBSkgsS0FKVDtBQVVFLGFBQVMsRUFBQztBQVZaLEtBRU84RCxLQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEZSxDQUFqQjtBQWNBLFFBQU1FLE1BQU0sR0FBR2IsS0FBSyxDQUFDUyxHQUFOLENBQVUsQ0FBQ0MsSUFBRCxFQUFZQyxLQUFaLGtCQUN2QjtBQUNFLE9BQUcsRUFBRUQsSUFBSSxDQUFDRSxHQURaO0FBR0UsT0FBRyxFQUFFUixLQUhQO0FBSUUsU0FBSyxFQUFFO0FBQUUvRCxXQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBTSxFQUFFLE1BQXpCO0FBQWlDWSxjQUFRLEVBQUU7QUFBM0M7QUFKVCxLQUVPeUQsS0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRGEsQ0FBZjs7QUFRQSxRQUFNRyxTQUFTLEdBQUcsQ0FBQztBQUNqQkgsU0FEaUI7QUFFakJJLFdBRmlCO0FBR2pCQztBQUhpQixHQUFELEtBS1Y7QUFDTix3QkFDRSxxRUFBQyxVQUFEO0FBQ0Usb0JBQVlMLEtBRGQ7QUFHRSxhQUFPLEVBQUUsTUFBTUksT0FBTyxFQUh4QjtBQUlFLGVBQVMsRUFBRyxjQUFhQyxNQUFNLElBQUksb0JBQXFCLEVBSjFEO0FBQUEsZ0JBTUdDLDRDQUFLLENBQUNDLFFBQU4sQ0FBZUMsT0FBZixDQUF1Qk4sTUFBdkIsRUFBK0JGLEtBQS9CO0FBTkgsT0FFT0EsS0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBVUQsR0FoQkQ7O0FBa0JBLE1BQUlOLFVBQVUsR0FBRyxTQUFqQjs7QUFDQSxNQUFJSixNQUFKLEVBQVk7QUFDVkksY0FBVSxHQUFHLFFBQWI7QUFDRDs7QUFDRCxNQUFJSCxNQUFKLEVBQVk7QUFDVkcsY0FBVSxHQUFHLFFBQWI7QUFDRDs7QUFDRCxzQkFDRSxxRUFBQywyREFBRDtBQUNFLFlBQVEsTUFEVjtBQUVFLE9BQUcsTUFGTDtBQUdFLFlBQVEsRUFBRSxJQUhaO0FBSUUsaUJBQWEsRUFBRSxDQUpqQjtBQUtFLGtCQUFjLEVBQUMsMkJBTGpCO0FBTUUsY0FBVSxFQUFFVixVQU5kO0FBT0UsY0FBVSxFQUFFVSxVQVBkO0FBUUUsWUFBUSxFQUFFLEtBUlo7QUFTRSxVQUFNLEVBQUUsS0FUVjtBQVVFLGFBQVMsZUFBRSxxRUFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFWYixLQVdNQyxJQVhOO0FBQUEsY0FhR0M7QUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0F0RUQ7O0FBd0VlSixxRkFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2SEE7QUFFTyxNQUFNaUIsR0FBRyxHQUFHO0FBQUEsTUFBQztBQUFFQyxRQUFJLEdBQUc7QUFBVCxHQUFEO0FBQUEsTUFBaUJuRixLQUFqQjs7QUFBQSxzQkFDakIscUVBQUMsd0NBQUQ7QUFDRSxNQUFFLEVBQUMsS0FETDtBQUVFLFNBQUssRUFBQyw0QkFGUjtBQUdFLFNBQUssRUFBRW1GLElBQUksR0FBRyxFQUhoQjtBQUlFLFVBQU0sRUFBRUEsSUFBSSxHQUFHLEVBSmpCO0FBS0UsV0FBTyxFQUFDLFdBTFY7QUFNRSxRQUFJLEVBQUM7QUFOUCxLQU9NbkYsS0FQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRGlCO0FBQUEsQ0FBWixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQOztBQVFBLE1BQU1vRixRQUFRLEdBQUcsQ0FBQztBQUFFZixVQUFGO0FBQVlnQixNQUFaO0FBQWtCQyxNQUFsQjtBQUF3QkM7QUFBeEIsQ0FBRCxLQUF5QztBQUN4RCxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJDLHNEQUFRLENBQUMsS0FBRCxDQUF4Qzs7QUFFQSxRQUFNQyxXQUFXLEdBQUdDLEtBQUssSUFBSTtBQUMzQkEsU0FBSyxDQUFDQyxjQUFOO0FBQ0FKLGVBQVcsQ0FBQyxDQUFDRCxRQUFGLENBQVg7QUFDRCxHQUhEOztBQUtBLE1BQUksQ0FBQ25CLFFBQUwsRUFBZSxPQUFPLElBQVA7QUFFZixzQkFDRTtBQUFBLGVBQ0lBLFFBQVEsSUFBSUEsUUFBUSxDQUFDeUIsTUFBVCxHQUFrQlAsU0FBL0IsSUFBNkNDLFFBQTdDLEdBQ0duQixRQURILEdBRUdBLFFBQVEsQ0FBQzBCLFNBQVQsQ0FBbUIsQ0FBbkIsRUFBc0JSLFNBQXRCLENBSE4sRUFJR2xCLFFBQVEsSUFBSUEsUUFBUSxDQUFDeUIsTUFBVCxHQUFrQlAsU0FBOUIsSUFBMkMsQ0FBQ0MsUUFBNUMsaUJBQ0M7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQSwrQkFDRTtBQUNFLGNBQUksRUFBQyxHQURQO0FBRUUsaUJBQU8sRUFBRUcsV0FGWDtBQUdFLGVBQUssRUFBRTtBQUFFekYsaUJBQUssRUFBRSxTQUFUO0FBQW9Cb0Isc0JBQVUsRUFBRTtBQUFoQyxXQUhUO0FBQUEsb0JBS0crRDtBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUEsb0JBTEosRUFrQkdoQixRQUFRLElBQUlBLFFBQVEsQ0FBQ3lCLE1BQVQsR0FBa0JQLFNBQTlCLElBQTJDQyxRQUEzQyxpQkFDQztBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFBLCtCQUNFO0FBQ0UsY0FBSSxFQUFDLEdBRFA7QUFFRSxpQkFBTyxFQUFFRyxXQUZYO0FBR0UsZUFBSyxFQUFFO0FBQUV6RixpQkFBSyxFQUFFLFNBQVQ7QUFBb0JvQixzQkFBVSxFQUFFO0FBQWhDLFdBSFQ7QUFBQSxvQkFLR2dFO0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQSxvQkFuQko7QUFBQSxrQkFERjtBQW1DRCxDQTdDRDs7QUErQ0FGLFFBQVEsQ0FBQ3BDLFlBQVQsR0FBd0I7QUFDdEJ1QyxXQUFTLEVBQUUsR0FEVztBQUV0QkYsTUFBSSxFQUFFLFdBRmdCO0FBR3RCQyxNQUFJLEVBQUU7QUFIZ0IsQ0FBeEI7QUFNZUYsdUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0RBO0NBRUE7O0FBQ0E7QUFDQTtBQXVCQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVNBLE1BQU1ZLGVBQXdELEdBQUcsQ0FBQztBQUNoRUMsWUFEZ0U7QUFFaEVDLGNBRmdFO0FBR2hFQyxXQUhnRTtBQUloRWhDO0FBSmdFLENBQUQsS0FLM0Q7QUFDSixRQUFNO0FBQUVpQyxXQUFGO0FBQVdDLGNBQVg7QUFBdUJDLFlBQXZCO0FBQWlDQztBQUFqQyxNQUE2Q0MsdUVBQU8sRUFBMUQ7QUFDQSxRQUFNO0FBQ0pDLE1BREk7QUFFSkMsUUFGSTtBQUdKeEMsU0FISTtBQUlKeUMsUUFKSTtBQUtKQyxTQUxJO0FBTUpDLHFCQU5JO0FBT0pDLGFBUEk7QUFRSkMsZUFSSTtBQVNKQyxXQVRJO0FBVUpDO0FBVkksTUFXRmhCLFVBWEo7QUFhQSxRQUFNO0FBQUVpQjtBQUFGLE1BQVlDLHFGQUFTLEVBQTNCOztBQUVBLFFBQU1DLGNBQWMsR0FBSUMsQ0FBRCxJQUFZO0FBQ2pDQSxLQUFDLENBQUNDLGVBQUY7QUFDQWxCLFdBQU8sQ0FBQ0gsVUFBRCxDQUFQO0FBQ0QsR0FIRDs7QUFLQSxRQUFNc0IsaUJBQWlCLEdBQUlGLENBQUQsSUFBWTtBQUNwQ0EsS0FBQyxDQUFDQyxlQUFGO0FBQ0FqQixjQUFVLENBQUNKLFVBQUQsQ0FBVjtBQUNELEdBSEQ7O0FBSUEsV0FBU3VCLGVBQVQsQ0FBeUJDLElBQXpCLEVBQStCO0FBQzdCQyxzREFBTSxDQUFDQyxJQUFQLENBQVk7QUFDVkMsY0FBUSxFQUFHLElBQUdsQixJQUFJLENBQUNtQixXQUFMLEVBQW1CLEVBRHZCO0FBRVZDLFdBQUssRUFBRTtBQUFFQyxnQkFBUSxFQUFFTjtBQUFaO0FBRkcsS0FBWixFQUdHTyxJQUhILENBR1EsTUFBTUMsTUFBTSxDQUFDQyxRQUFQLENBQWdCLENBQWhCLEVBQW1CLENBQW5CLENBSGQ7QUFJQS9CLGFBQVM7QUFDVjs7QUFFRCxzQkFDRTtBQUFBLDJCQUlFLHFFQUFDLGtFQUFEO0FBQWtCLGVBQVMsRUFBQywyQkFBNUI7QUFBQSw2QkFDRSxxRUFBQyx1RUFBRDtBQUF1QixpQkFBUyxFQUFDLGNBQWpDO0FBQWdELFdBQUcsRUFBQyxLQUFwRDtBQUFBLG1CQUNHLENBQUNlLEtBQUQsaUJBQ0MscUVBQUMsZ0VBQUQ7QUFBQSxrQ0FDRSxxRUFBQyxnRkFBRDtBQUF3QixpQkFBSyxFQUFFRixPQUEvQjtBQUF3QyxzQkFBVSxFQUFFN0M7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixFQUVHLENBQUMsQ0FBQzBDLGlCQUFGLGlCQUNDLHFFQUFDLGlFQUFEO0FBQUEsdUJBQWtCQSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGSixlQVNFLHFFQUFDLG9FQUFEO0FBQW9CLGFBQUcsRUFBRUssS0FBSyxHQUFHLEtBQUgsR0FBVyxLQUF6QztBQUFBLGlDQUNFLHFFQUFDLDZEQUFEO0FBQUEsb0NBQ0UscUVBQUMsMEVBQUQ7QUFBQSxxQ0FDRSxxRUFBQyw4REFBRDtBQUFBLDBCQUFlaEQ7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUtFLHFFQUFDLCtEQUFEO0FBQUEsd0JBQWdCeUM7QUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFMRixlQU1FLHFFQUFDLG9FQUFEO0FBQUEscUNBQ0UscUVBQUMsb0VBQUQ7QUFBVSx5QkFBUyxFQUFFLEdBQXJCO0FBQUEsMEJBQTJCSTtBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORixlQVVFLHFFQUFDLDZEQUFEO0FBQUEscUNBQ0UscUVBQUMsNERBQUQ7QUFBQSwwQkFDR0UsVUFBVSxHQUNQQSxVQUFVLENBQUMxQyxHQUFYLENBQWdCQyxJQUFELGlCQUNiLHFFQUFDLDBEQUFEO0FBQ0UseUJBQU8sRUFBRSxNQUFNZ0QsZUFBZSxDQUFDaEQsSUFBSSxDQUFDaUQsSUFBTixDQURoQztBQUFBLDRCQUlHakQsSUFBSSxDQUFDTjtBQUpSLG1CQUVPTSxJQUFJLENBQUNpQyxFQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsQ0FETyxHQVNQO0FBVk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVkYsZUF5QkUscUVBQUMsb0VBQUQ7QUFBQSxzQ0FDRSxxRUFBQyxxRUFBRDtBQUFBLHdDQUNFLHFFQUFDLDhEQUFEO0FBQUEsNkJBQ0cwQix1REFESCxFQUVHckIsU0FBUyxHQUFHQSxTQUFILEdBQWVGLEtBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixFQU1HQyxpQkFBaUIsZ0JBQ2hCLHFFQUFDLDJEQUFEO0FBQUEsNkJBQ0dzQix1REFESCxFQUVHdkIsS0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRGdCLEdBS2QsSUFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFlRSxxRUFBQyxnRUFBRDtBQUFBLDBCQUNHLENBQUNOLFFBQVEsQ0FBQ0csRUFBRCxDQUFULGdCQUNDLHFFQUFDLCtEQUFEO0FBQ0UsMkJBQVMsRUFBQyxhQURaO0FBRUUseUJBQU8sRUFBQyxXQUZWO0FBR0UsOEJBQVksRUFBRSxHQUhoQjtBQUlFLHlCQUFPLEVBQUVXLGNBSlg7QUFBQSwwQ0FNRSxxRUFBQyw4REFBRDtBQUFVLHNCQUFFLEVBQUU7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQU5GLGVBT0UscUVBQUMsNERBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw0REFBRDtBQUNFLHdCQUFFLEVBQUMsZUFETDtBQUVFLG9DQUFjLEVBQUM7QUFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURELGdCQWdCQyxxRUFBQyxtRUFBRDtBQUNFLHVCQUFLLEVBQUViLE9BQU8sQ0FBQ0UsRUFBRCxDQUFQLENBQVkyQixRQURyQjtBQUVFLDZCQUFXLEVBQUViLGlCQUZmO0FBR0UsNkJBQVcsRUFBRUg7QUFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVRGLEVBOEVHRixLQUFLLGlCQUNKLHFFQUFDLGdFQUFEO0FBQUEsa0NBQ0UscUVBQUMsZ0ZBQUQ7QUFBd0IsaUJBQUssRUFBRUYsT0FBL0I7QUFBd0Msc0JBQVUsRUFBRTdDO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsRUFFRyxDQUFDLENBQUMwQyxpQkFBRixpQkFDQyxxRUFBQyxpRUFBRDtBQUFBLHVCQUFrQkEsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBL0VKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRixtQkFERjtBQWdHRCxDQXZJRDs7QUF5SWViLDhFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3JMQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVPLE1BQU1xQyxxQkFBcUIsR0FBRzlILHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsNk9BQ1pnRCx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FESSxFQU9mQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBUE8sQ0FBM0I7QUFxQkEsTUFBTThFLGNBQWMsR0FBRy9ILHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsNFFBQXBCO0FBeUJBLE1BQU0rSCxPQUFPLEdBQUdoSSx3REFBTSxDQUFDc0MsSUFBVjtBQUFBO0FBQUE7QUFBQSwwTEFDTFcseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBREgsRUFFSEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUZMLEVBR1RBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUhDLEVBSUVBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FKVixFQU9EQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FQUCxDQUFiO0FBY0EsTUFBTWdGLGVBQWUsR0FBR2pJLHdEQUFNLENBQUNzQyxJQUFWO0FBQUE7QUFBQTtBQUFBLHlUQUNYVyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBREcsRUFFYkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkssRUFHWEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhHLEVBSWpCQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKUyxFQU1OQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBTkYsRUFjVEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLE1BQWpCLENBZEMsQ0FBckI7QUFtQkEsTUFBTWlGLGtCQUFrQixHQUFHbEksd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxrSkFHSmdELHlFQUFRLENBQUMseUJBQUQsRUFBNEIsU0FBNUIsQ0FISixDQUF4QjtBQWNBLE1BQU1rRixXQUFXLEdBQUduSSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHlEQUFqQjtBQVFBLE1BQU1tSSx3QkFBd0IsR0FBR3BJLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEscUdBQTlCO0FBUUEsTUFBTW9JLFlBQVksR0FBR3JJLHdEQUFNLENBQUNzSSxFQUFWO0FBQUE7QUFBQTtBQUFBLG9KQUNSckYseUVBQVEsQ0FBQyxlQUFELEVBQWtCLFlBQWxCLENBREEsRUFFVkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkUsRUFHUkEseUVBQVEsQ0FBQyxzQkFBRCxFQUF5QixLQUF6QixDQUhBLEVBSWRBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FKTSxDQUFsQjtBQWFBLE1BQU1zRixtQkFBbUIsR0FBR3ZJLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsbUlBQXpCO0FBWUEsTUFBTXVJLFlBQVksR0FBR3hJLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsbUZBQ1JnRCx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBREEsRUFFTEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZILEVBR1JBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIQSxFQUlkQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBSk0sQ0FBbEI7QUFPQSxNQUFNd0YsU0FBUyxHQUFHekksd0RBQU0sQ0FBQ3NDLElBQVY7QUFBQTtBQUFBO0FBQUEsaVJBQ0xXLHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FESCxFQUVQQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRCxFQUdMQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEgsRUFJWEEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpHLEVBZ0JFQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBaEJWLENBQWY7QUF1QkEsTUFBTXlGLGFBQWEsR0FBRzFJLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsdUVBQ1RnRCx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBREMsRUFFWEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkcsRUFHVEEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixLQUF4QixDQUhDLEVBSWZBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FKTyxDQUFuQjtBQU9BLE1BQU0wRixrQkFBa0IsR0FBRzNJLHdEQUFNLENBQUM0SSxDQUFWO0FBQUE7QUFBQTtBQUFBLHFHQUNkM0YseUVBQVEsQ0FBQyxZQUFELEVBQWUsTUFBZixDQURNLEVBRWhCQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBRlEsRUFHZEEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixLQUF4QixDQUhNLEVBSXBCQSx5RUFBUSxDQUFDLG9CQUFELEVBQXVCLFNBQXZCLENBSlksQ0FBeEI7QUFTQSxNQUFNNEYsY0FBYyxHQUFHN0ksd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxzUUFRUmdELHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FSQSxFQVNWQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBVEUsRUFVUkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQVZBLEVBV2RBLHlFQUFRLENBQUMsd0JBQUQsRUFBMkIsU0FBM0IsQ0FYTSxFQW9CWkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBcEJJLEVBcUJEQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBckJQLEVBc0JMQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBdEJILENBQXBCO0FBMkJBLE1BQU02RixVQUFVLEdBQUc5SSx3REFBTSxDQUFDc0MsSUFBVjtBQUFBO0FBQUE7QUFBQSxRQUFoQjtBQU1BLE1BQU15RyxrQkFBa0IsR0FBRy9JLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsMkNBQXhCO0FBS0EsTUFBTStJLFdBQVcsR0FBR2hKLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsd0JBQWpCO0FBSUEsTUFBTWdKLFVBQVUsR0FBR2pKLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsd0dBQWhCO0FBVUEsTUFBTWlKLFFBQVEsR0FBR2xKLHdEQUFNLENBQUNzQyxJQUFWO0FBQUE7QUFBQTtBQUFBLHNQQUNKVyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBREosRUFFTkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkYsRUFHSkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhKLEVBSVZBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FKRSxFQU9DQSx5RUFBUSxDQUFDLGlCQUFELEVBQW9CLFNBQXBCLENBUFQsRUFTRkEseUVBQVEsQ0FBQyxZQUFELEVBQWUsS0FBZixDQVROLENBQWQ7QUFpQkEsTUFBTWtHLFVBQVUsR0FBR25KLHdEQUFNLENBQUNpQyxNQUFWO0FBQUE7QUFBQTtBQUFBLGtRQUFoQjtBQXdCQSxNQUFNbUgsZ0JBQWdCLEdBQUdwSix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLG9YQU12QjhJLGtCQU51QixFQWN2Qk4sU0FkdUIsRUFlVnhGLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FmRSxFQWtCdkJ1RixZQWxCdUIsRUFtQlZ2Rix5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FuQkUsRUFzQnZCNEYsY0F0QnVCLEVBOEJ2QkwsWUE5QnVCLEVBK0JWdkYseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBL0JFLEVBa0N2QnNGLG1CQWxDdUIsQ0FBdEIsQyIsImZpbGUiOiIxMC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN2ZyB9IGZyb20gJ2NvbXBvbmVudHMvc3ZnJztcbmV4cG9ydCBjb25zdCBDYXJ0SWNvbiA9IChwcm9wcykgPT4gKFxuICA8U3ZnIHsuLi5wcm9wc30gd2lkdGg9JzE0LjRweCcgaGVpZ2h0PScxMnB4JyB2aWV3Qm94PScwIDAgMTQuNCAxMic+XG4gICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxMjAnIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0yODggLTQxMy44OSknPlxuICAgICAgPHBhdGhcbiAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE1NCdcbiAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICBkPSdNMjk4LjcsNDE4LjI4OWwtMi45MDYtNC4xNDhhLjgzNS44MzUsMCwwLDAtLjUyOC0uMjUxLjYwNy42MDcsMCwwLDAtLjUyOS4yNTFsLTIuOTA1LDQuMTQ4aC0zLjE3YS42MDkuNjA5LDAsMCwwLS42NjEuNjI1di4xOTFsMS42NTEsNS44NGExLjMzNiwxLjMzNiwwLDAsMCwxLjI1NS45NDVoOC41ODhhMS4yNjEsMS4yNjEsMCwwLDAsMS4yNTQtLjk0NWwxLjY1MS01Ljg0di0uMTkxYS42MDkuNjA5LDAsMCwwLS42NjEtLjYyNVptLTUuNDE5LDAsMS45ODQtMi43NjcsMS45OCwyLjc2N1ptMS45ODQsNS4wMjRhMS4yNTgsMS4yNTgsMCwxLDEsMS4zMTktMS4yNTgsMS4zLDEuMywwLDAsMS0xLjMxOSwxLjI1OFptMCwwJ1xuICAgICAgLz5cbiAgICA8L2c+XG4gIDwvU3ZnPlxuKTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG4vLyBTVkcgcGx1cyBpY29uXG5leHBvcnQgY29uc3QgUGx1cyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzEycHgnLFxuICBoZWlnaHQgPSAnMTJweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9XCIwIDAgMTIgMTJcIlxuICAgID5cbiAgICAgIDxnXG4gICAgICAgIGlkPVwiR3JvdXBfMzM1MVwiXG4gICAgICAgIGRhdGEtbmFtZT1cIkdyb3VwIDMzNTFcIlxuICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTEzNjcgLTE5MClcIlxuICAgICAgPlxuICAgICAgICA8cmVjdFxuICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSA1MjBcIlxuICAgICAgICAgIHdpZHRoPVwiMTJcIlxuICAgICAgICAgIGhlaWdodD1cIjJcIlxuICAgICAgICAgIHJ4PVwiMVwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDEzNjcgMTk1KVwiXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDUyMVwiXG4gICAgICAgICAgd2lkdGg9XCIxMlwiXG4gICAgICAgICAgaGVpZ2h0PVwiMlwiXG4gICAgICAgICAgcng9XCIxXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMTM3NCAxOTApIHJvdGF0ZSg5MClcIlxuICAgICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcblxuLy8gU1ZHIG1pbnVzIGljb25cbmV4cG9ydCBjb25zdCBNaW51cyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzEycHgnLFxuICBoZWlnaHQgPSAnMnB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD1cIjAgMCAxMiAyXCJcbiAgICA+XG4gICAgICA8cmVjdFxuICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgNTIyXCJcbiAgICAgICAgd2lkdGg9XCIxMlwiXG4gICAgICAgIGhlaWdodD1cIjJcIlxuICAgICAgICByeD1cIjFcIlxuICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQge1xuICBjb21wb3NlLFxuICBzcGFjZSxcbiAgY29sb3IsXG4gIGxheW91dCxcbiAgZmxleGJveCxcbiAgcG9zaXRpb24sXG59IGZyb20gJ3N0eWxlZC1zeXN0ZW0nO1xuXG5leHBvcnQgY29uc3QgQm94ID0gc3R5bGVkLmRpdjxhbnk+KFxuICB7XG4gICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgbWluV2lkdGg6IDAsXG4gICAgbWFyZ2luOiAwLFxuICB9LFxuICBjb21wb3NlKHNwYWNlLCBjb2xvciwgbGF5b3V0LCBmbGV4Ym94LCBwb3NpdGlvbilcbik7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCBjc3MgZnJvbSAnQHN0eWxlZC1zeXN0ZW0vY3NzJztcbmltcG9ydCB7IHZhcmlhbnQgfSBmcm9tICdzdHlsZWQtc3lzdGVtJztcbmV4cG9ydCBjb25zdCBDb3VudGVyQm94ID0gc3R5bGVkLmRpdjxhbnk+KFxuICBjc3Moe1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGZvbnRTaXplOiAnYmFzZScsXG4gICAgZm9udFdlaWdodDogJ2JvbGQnLFxuICB9KSxcbiAge1xuICAgIGJvcmRlclJhZGl1czogMjAwLFxuICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgIGZsZXhTaHJpbms6IDAsXG4gICAgJyY6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAnbm9uZScsXG4gICAgfSxcbiAgfSxcbiAgdmFyaWFudCh7XG4gICAgdmFyaWFudHM6IHtcbiAgICAgIGhvcml6b250YWw6IHtcbiAgICAgICAgd2lkdGg6IDEwNCxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgIH0sXG4gICAgICB2ZXJ0aWNhbDoge1xuICAgICAgICB3aWR0aDogMzAsXG4gICAgICAgIGhlaWdodDogOTAsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4tcmV2ZXJzZScsXG4gICAgICB9LFxuICAgICAgbGlnaHRIb3Jpem9udGFsOiB7XG4gICAgICAgIHdpZHRoOiAxMDQsXG4gICAgICAgIGhlaWdodDogMzYsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ2dyYXkuMjAwJyxcbiAgICAgICAgY29sb3I6ICd0ZXh0LmJvbGQnLFxuICAgICAgfSxcbiAgICAgIGxpZ2h0VmVydGljYWw6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uLXJldmVyc2UnLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdncmF5LjIwMCcsXG4gICAgICAgIGNvbG9yOiAndGV4dC5ib2xkJyxcbiAgICAgIH0sXG4gICAgICBhbHRIb3Jpem9udGFsOiB7XG4gICAgICAgIHdpZHRoOiAxMDQsXG4gICAgICAgIGhlaWdodDogMzYsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzZweCcsXG4gICAgICB9LFxuICAgICAgYWx0VmVydGljYWw6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxuICAgICAgfSxcbiAgICAgIGZ1bGw6IHtcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBDb3VudGVyQnV0dG9uID0gc3R5bGVkLmJ1dHRvbjxhbnk+KFxuICB7XG4gICAgYm9yZGVyOiAnbm9uZScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgcGFkZGluZzogMTAsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgJyY6aG92ZXIsICY6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAnbm9uZScsXG4gICAgfSxcbiAgfSxcbiAgdmFyaWFudCh7XG4gICAgdmFyaWFudHM6IHtcbiAgICAgIGxpZ2h0SG9yaXpvbnRhbDoge1xuICAgICAgICBjb2xvcjogJ3RleHQucmVndWxhcicsXG4gICAgICB9LFxuICAgICAgbGlnaHRWZXJ0aWNhbDoge1xuICAgICAgICBjb2xvcjogJ3RleHQucmVndWxhcicsXG4gICAgICB9LFxuICAgIH0sXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgQ291bnRlclZhbHVlID0gc3R5bGVkLnNwYW4oe1xuICBwb2ludGVyRXZlbnRzOiAnbm9uZScsXG59KTtcbkNvdW50ZXJWYWx1ZS5kaXNwbGF5TmFtZSA9ICdDb3VudGVyVmFsdWUnO1xuQ291bnRlckJ1dHRvbi5kaXNwbGF5TmFtZSA9ICdDb3VudGVyQnV0dG9uJztcbkNvdW50ZXJCb3guZGlzcGxheU5hbWUgPSAnQ291bnRlckJveCc7XG5Db3VudGVyQm94LmRlZmF1bHRQcm9wcyA9IHtcbiAgdmFyaWFudDogJ2hvcml6b250YWwnLFxufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBQbHVzLCBNaW51cyB9IGZyb20gJ2Fzc2V0cy9pY29ucy9QbHVzTWludXMnO1xuaW1wb3J0IHsgQ291bnRlckJveCwgQ291bnRlckJ1dHRvbiwgQ291bnRlclZhbHVlIH0gZnJvbSAnLi9jb3VudGVyLnN0eWxlJztcbmludGVyZmFjZSBQcm9wcyB7XG4gIG9uRGVjcmVtZW50OiAoZTogRXZlbnQpID0+IHZvaWQ7XG4gIG9uSW5jcmVtZW50OiAoZTogRXZlbnQpID0+IHZvaWQ7XG4gIHZhbHVlOiBudW1iZXI7XG4gIHZhcmlhbnQ/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IENvdW50ZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7XG4gIG9uRGVjcmVtZW50LFxuICBvbkluY3JlbWVudCxcbiAgdmFsdWUsXG4gIHZhcmlhbnQsXG4gIGNsYXNzTmFtZSxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q291bnRlckJveCB2YXJpYW50PXt2YXJpYW50fSBjbGFzc05hbWU9e2NsYXNzTmFtZX0+XG4gICAgICA8Q291bnRlckJ1dHRvblxuICAgICAgICBvbkNsaWNrPXtvbkRlY3JlbWVudH1cbiAgICAgICAgdmFyaWFudD17dmFyaWFudH1cbiAgICAgICAgY2xhc3NOYW1lPSdjb250cm9sLWJ1dHRvbidcbiAgICAgID5cbiAgICAgICAgPE1pbnVzIC8+XG4gICAgICA8L0NvdW50ZXJCdXR0b24+XG4gICAgICA8Q291bnRlclZhbHVlPnt2YWx1ZX08L0NvdW50ZXJWYWx1ZT5cbiAgICAgIDxDb3VudGVyQnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9e29uSW5jcmVtZW50fVxuICAgICAgICB2YXJpYW50PXt2YXJpYW50fVxuICAgICAgICBjbGFzc05hbWU9J2NvbnRyb2wtYnV0dG9uJ1xuICAgICAgPlxuICAgICAgICA8UGx1cyAvPlxuICAgICAgPC9Db3VudGVyQnV0dG9uPlxuICAgIDwvQ291bnRlckJveD5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdGhlbWVHZXQgfSBmcm9tICdAc3R5bGVkLXN5c3RlbS90aGVtZS1nZXQnO1xuaW1wb3J0IENhcm91c2VsIGZyb20gJ3JlYWN0LW11bHRpLWNhcm91c2VsJztcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xuXG5jb25zdCBTaW5nbGVJdGVtID0gc3R5bGVkLmxpYFxuICBib3JkZXI6IDFweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMuZ3JheS41MDAnLCAnI2YxZjFmMScpfTtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgcGFkZGluZzogMDtcbiAgb3V0bGluZTogbm9uZTtcbiAgd2lkdGg6IDcwcHg7XG4gIGhlaWdodDogYXV0bztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAmOmxhc3QtY2hpbGQge1xuICAgIG1hcmdpbi1yaWdodDogMDtcbiAgfVxuXG4gICYuY3VzdG9tLWRvdC0tYWN0aXZlIHtcbiAgICBib3JkZXI6IDJweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gIH1cbmA7XG5jb25zdCByZXNwb25zaXZlID0ge1xuICBkZXNrdG9wOiB7XG4gICAgYnJlYWtwb2ludDoge1xuICAgICAgbWF4OiAzMDAwLFxuICAgICAgbWluOiAxMDI0LFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG4gIG1vYmlsZToge1xuICAgIGJyZWFrcG9pbnQ6IHtcbiAgICAgIG1heDogNDY0LFxuICAgICAgbWluOiAwLFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG4gIHRhYmxldDoge1xuICAgIGJyZWFrcG9pbnQ6IHtcbiAgICAgIG1heDogMTAyNCxcbiAgICAgIG1pbjogMjAwLFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG59O1xuXG5jb25zdCBDYXJvdXNlbFdpdGhDdXN0b21Eb3RzID0gKHtcbiAgaXRlbXMgPSBbXSxcbiAgdGl0bGUsXG4gIGRldmljZVR5cGU6IHsgbW9iaWxlLCB0YWJsZXQsIGRlc2t0b3AgfSxcbiAgLi4ucmVzdFxufTogYW55KSA9PiB7XG4gIGNvbnN0IGNoaWxkcmVuID0gaXRlbXMuc2xpY2UoMCwgNikubWFwKChpdGVtOiBhbnksIGluZGV4OiBudW1iZXIpID0+IChcbiAgICA8aW1nXG4gICAgICBzcmM9e2l0ZW0udXJsfVxuICAgICAga2V5PXtpbmRleH1cbiAgICAgIGFsdD17dGl0bGV9XG4gICAgICBzdHlsZT17e1xuICAgICAgICBtaW5XaWR0aDogJ2F1dG8nLFxuICAgICAgICBoZWlnaHQ6ICdhdXRvJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgIG1hcmdpbjogJ2F1dG8nLFxuICAgICAgfX1cbiAgICAgIGNsYXNzTmFtZT1cInByb2R1Y3QtaW1hZ2VcIlxuICAgIC8+XG4gICkpO1xuICBjb25zdCBpbWFnZXMgPSBpdGVtcy5tYXAoKGl0ZW06IGFueSwgaW5kZXg6IG51bWJlcikgPT4gKFxuICAgIDxpbWdcbiAgICAgIHNyYz17aXRlbS51cmx9XG4gICAgICBrZXk9e2luZGV4fVxuICAgICAgYWx0PXt0aXRsZX1cbiAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScsIGhlaWdodDogJzEwMCUnLCBwb3NpdGlvbjogJ3JlbGF0aXZlJyB9fVxuICAgIC8+XG4gICkpO1xuICBjb25zdCBDdXN0b21Eb3QgPSAoe1xuICAgIGluZGV4LFxuICAgIG9uQ2xpY2ssXG4gICAgYWN0aXZlLFxuICB9OiAvLyBjYXJvdXNlbFN0YXRlOiB7IGN1cnJlbnRTbGlkZSwgZGV2aWNlVHlwZSB9LFxuICBhbnkpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPFNpbmdsZUl0ZW1cbiAgICAgICAgZGF0YS1pbmRleD17aW5kZXh9XG4gICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2xpY2soKX1cbiAgICAgICAgY2xhc3NOYW1lPXtgY3VzdG9tLWRvdCAke2FjdGl2ZSAmJiAnY3VzdG9tLWRvdC0tYWN0aXZlJ31gfVxuICAgICAgPlxuICAgICAgICB7UmVhY3QuQ2hpbGRyZW4udG9BcnJheShpbWFnZXMpW2luZGV4XX1cbiAgICAgIDwvU2luZ2xlSXRlbT5cbiAgICApO1xuICB9O1xuXG4gIGxldCBkZXZpY2VUeXBlID0gJ2Rlc2t0b3AnO1xuICBpZiAobW9iaWxlKSB7XG4gICAgZGV2aWNlVHlwZSA9ICdtb2JpbGUnO1xuICB9XG4gIGlmICh0YWJsZXQpIHtcbiAgICBkZXZpY2VUeXBlID0gJ3RhYmxldCc7XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8Q2Fyb3VzZWxcbiAgICAgIHNob3dEb3RzXG4gICAgICBzc3JcbiAgICAgIGluZmluaXRlPXt0cnVlfVxuICAgICAgc2xpZGVzVG9TbGlkZT17MX1cbiAgICAgIGNvbnRhaW5lckNsYXNzPVwiY2Fyb3VzZWwtd2l0aC1jdXN0b20tZG90c1wiXG4gICAgICByZXNwb25zaXZlPXtyZXNwb25zaXZlfVxuICAgICAgZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX1cbiAgICAgIGF1dG9QbGF5PXtmYWxzZX1cbiAgICAgIGFycm93cz17ZmFsc2V9XG4gICAgICBjdXN0b21Eb3Q9ezxDdXN0b21Eb3QgLz59XG4gICAgICB7Li4ucmVzdH1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9DYXJvdXNlbD5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENhcm91c2VsV2l0aEN1c3RvbURvdHM7XG4iLCJpbXBvcnQgeyBCb3ggfSBmcm9tICcuL2JveCc7XG5cbmV4cG9ydCBjb25zdCBTdmcgPSAoeyBzaXplID0gMTgsIC4uLnByb3BzIH0pID0+IChcbiAgPEJveFxuICAgIGFzPVwic3ZnXCJcbiAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICB3aWR0aD17c2l6ZSArICcnfVxuICAgIGhlaWdodD17c2l6ZSArICcnfVxuICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuICAgIHsuLi5wcm9wc31cbiAgLz5cbik7XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbnR5cGUgUmVhZE1vcmVQcm9wcyA9IHtcbiAgbW9yZT86IHN0cmluZztcbiAgbGVzcz86IHN0cmluZztcbiAgY2hhcmFjdGVyPzogbnVtYmVyO1xufTtcblxuY29uc3QgUmVhZE1vcmUgPSAoeyBjaGlsZHJlbiwgbW9yZSwgbGVzcywgY2hhcmFjdGVyIH0pID0+IHtcbiAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgdG9nZ2xlTGluZXMgPSBldmVudCA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFeHBhbmRlZCghZXhwYW5kZWQpO1xuICB9O1xuXG4gIGlmICghY2hpbGRyZW4pIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsoY2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoIDwgY2hhcmFjdGVyKSB8fCBleHBhbmRlZFxuICAgICAgICA/IGNoaWxkcmVuXG4gICAgICAgIDogY2hpbGRyZW4uc3Vic3RyaW5nKDAsIGNoYXJhY3Rlcil9XG4gICAgICB7Y2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID4gY2hhcmFjdGVyICYmICFleHBhbmRlZCAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPVwiI1wiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUxpbmVzfVxuICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogJyNGMzlDMTInLCBmb250V2VpZ2h0OiA3MDAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge21vcmV9XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgICB7Y2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID4gY2hhcmFjdGVyICYmIGV4cGFuZGVkICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9XCIjXCJcbiAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlTGluZXN9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiAnI0YzOUMxMicsIGZvbnRXZWlnaHQ6IDcwMCB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bGVzc31cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn07XG5cblJlYWRNb3JlLmRlZmF1bHRQcm9wcyA9IHtcbiAgY2hhcmFjdGVyOiAxNTAsXG4gIG1vcmU6ICdSZWFkIG1vcmUnLFxuICBsZXNzOiAnbGVzcycsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBSZWFkTW9yZTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcbi8vIGltcG9ydCB7IGNsb3NlTW9kYWwgfSBmcm9tICdAcmVkcS9yZXVzZS1tb2RhbCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdjb21wb25lbnRzL2J1dHRvbi9idXR0b24nO1xuaW1wb3J0IHtcbiAgUXVpY2tWaWV3V3JhcHBlcixcbiAgUHJvZHVjdERldGFpbHNXcmFwcGVyLFxuICBQcm9kdWN0UHJldmlldyxcbiAgRGlzY291bnRQZXJjZW50LFxuICBQcm9kdWN0SW5mb1dyYXBwZXIsXG4gIFByb2R1Y3RJbmZvLFxuICBQcm9kdWN0VGl0bGVQcmljZVdyYXBwZXIsXG4gIFByb2R1Y3RUaXRsZSxcbiAgUHJvZHVjdFdlaWdodCxcbiAgUHJvZHVjdERlc2NyaXB0aW9uLFxuICBCdXR0b25UZXh0LFxuICBQcm9kdWN0TWV0YSxcbiAgUHJvZHVjdENhcnRXcmFwcGVyLFxuICBQcm9kdWN0UHJpY2VXcmFwcGVyLFxuICBQcm9kdWN0UHJpY2UsXG4gIFNhbGVQcmljZSxcbiAgUHJvZHVjdENhcnRCdG4sXG4gIE1ldGFTaW5nbGUsXG4gIE1ldGFJdGVtLFxuICBNb2RhbENsb3NlLFxufSBmcm9tICcuL3F1aWNrLXZpZXcuc3R5bGUnO1xuaW1wb3J0IHsgQ2xvc2VJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL0Nsb3NlSWNvbic7XG5pbXBvcnQgeyBDYXJ0SWNvbiB9IGZyb20gJ2Fzc2V0cy9pY29ucy9DYXJ0SWNvbic7XG5pbXBvcnQgeyBDVVJSRU5DWSB9IGZyb20gJ3V0aWxzL2NvbnN0YW50JztcblxuaW1wb3J0IFJlYWRNb3JlIGZyb20gJ2NvbXBvbmVudHMvdHJ1bmNhdGUvdHJ1bmNhdGUnO1xuaW1wb3J0IENhcm91c2VsV2l0aEN1c3RvbURvdHMgZnJvbSAnY29tcG9uZW50cy9tdWx0aS1jYXJvdXNlbC9tdWx0aS1jYXJvdXNlbCc7XG5pbXBvcnQgeyB1c2VMb2NhbGUgfSBmcm9tICdjb250ZXh0cy9sYW5ndWFnZS9sYW5ndWFnZS5wcm92aWRlcic7XG5pbXBvcnQgeyB1c2VDYXJ0IH0gZnJvbSAnY29udGV4dHMvY2FydC91c2UtY2FydCc7XG5pbXBvcnQgeyBDb3VudGVyIH0gZnJvbSAnY29tcG9uZW50cy9jb3VudGVyL2NvdW50ZXInO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuXG50eXBlIFF1aWNrVmlld1Byb3BzID0ge1xuICBtb2RhbFByb3BzOiBhbnk7XG4gIG9uTW9kYWxDbG9zZT86IGFueTtcbiAgaGlkZU1vZGFsOiAoKSA9PiB2b2lkO1xuICBkZXZpY2VUeXBlOiBhbnk7XG59O1xuXG5jb25zdCBRdWlja1ZpZXdNb2JpbGU6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PFF1aWNrVmlld1Byb3BzPiA9ICh7XG4gIG1vZGFsUHJvcHMsXG4gIG9uTW9kYWxDbG9zZSxcbiAgaGlkZU1vZGFsLFxuICBkZXZpY2VUeXBlLFxufSkgPT4ge1xuICBjb25zdCB7IGFkZEl0ZW0sIHJlbW92ZUl0ZW0sIGlzSW5DYXJ0LCBnZXRJdGVtIH0gPSB1c2VDYXJ0KCk7XG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICB0eXBlLFxuICAgIHRpdGxlLFxuICAgIHVuaXQsXG4gICAgcHJpY2UsXG4gICAgZGlzY291bnRJblBlcmNlbnQsXG4gICAgc2FsZVByaWNlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGdhbGxlcnksXG4gICAgY2F0ZWdvcmllcyxcbiAgfSA9IG1vZGFsUHJvcHM7XG5cbiAgY29uc3QgeyBpc1J0bCB9ID0gdXNlTG9jYWxlKCk7XG5cbiAgY29uc3QgaGFuZGxlQWRkQ2xpY2sgPSAoZTogYW55KSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBhZGRJdGVtKG1vZGFsUHJvcHMpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUNsaWNrID0gKGU6IGFueSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgcmVtb3ZlSXRlbShtb2RhbFByb3BzKTtcbiAgfTtcbiAgZnVuY3Rpb24gb25DYXRlZ29yeUNsaWNrKHNsdWcpIHtcbiAgICBSb3V0ZXIucHVzaCh7XG4gICAgICBwYXRobmFtZTogYC8ke3R5cGUudG9Mb3dlckNhc2UoKX1gLFxuICAgICAgcXVlcnk6IHsgY2F0ZWdvcnk6IHNsdWcgfSxcbiAgICB9KS50aGVuKCgpID0+IHdpbmRvdy5zY3JvbGxUbygwLCAwKSk7XG4gICAgaGlkZU1vZGFsKCk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogPE1vZGFsQ2xvc2Ugb25DbGljaz17b25Nb2RhbENsb3NlfT5cbiAgICAgICAgPENsb3NlSWNvbiAvPlxuICAgICAgPC9Nb2RhbENsb3NlPiAqL31cbiAgICAgIDxRdWlja1ZpZXdXcmFwcGVyIGNsYXNzTmFtZT0ncXVpY2stdmlldy1tb2JpbGUtd3JhcHBlcic+XG4gICAgICAgIDxQcm9kdWN0RGV0YWlsc1dyYXBwZXIgY2xhc3NOYW1lPSdwcm9kdWN0LWNhcmQnIGRpcj0nbHRyJz5cbiAgICAgICAgICB7IWlzUnRsICYmIChcbiAgICAgICAgICAgIDxQcm9kdWN0UHJldmlldz5cbiAgICAgICAgICAgICAgPENhcm91c2VsV2l0aEN1c3RvbURvdHMgaXRlbXM9e2dhbGxlcnl9IGRldmljZVR5cGU9e2RldmljZVR5cGV9IC8+XG4gICAgICAgICAgICAgIHshIWRpc2NvdW50SW5QZXJjZW50ICYmIChcbiAgICAgICAgICAgICAgICA8RGlzY291bnRQZXJjZW50PntkaXNjb3VudEluUGVyY2VudH0lPC9EaXNjb3VudFBlcmNlbnQ+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L1Byb2R1Y3RQcmV2aWV3PlxuICAgICAgICAgICl9XG4gICAgICAgICAgPFByb2R1Y3RJbmZvV3JhcHBlciBkaXI9e2lzUnRsID8gJ3J0bCcgOiAnbHRyJ30+XG4gICAgICAgICAgICA8UHJvZHVjdEluZm8+XG4gICAgICAgICAgICAgIDxQcm9kdWN0VGl0bGVQcmljZVdyYXBwZXI+XG4gICAgICAgICAgICAgICAgPFByb2R1Y3RUaXRsZT57dGl0bGV9PC9Qcm9kdWN0VGl0bGU+XG4gICAgICAgICAgICAgIDwvUHJvZHVjdFRpdGxlUHJpY2VXcmFwcGVyPlxuXG4gICAgICAgICAgICAgIDxQcm9kdWN0V2VpZ2h0Pnt1bml0fTwvUHJvZHVjdFdlaWdodD5cbiAgICAgICAgICAgICAgPFByb2R1Y3REZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICA8UmVhZE1vcmUgY2hhcmFjdGVyPXs2MDB9PntkZXNjcmlwdGlvbn08L1JlYWRNb3JlPlxuICAgICAgICAgICAgICA8L1Byb2R1Y3REZXNjcmlwdGlvbj5cblxuICAgICAgICAgICAgICA8UHJvZHVjdE1ldGE+XG4gICAgICAgICAgICAgICAgPE1ldGFTaW5nbGU+XG4gICAgICAgICAgICAgICAgICB7Y2F0ZWdvcmllc1xuICAgICAgICAgICAgICAgICAgICA/IGNhdGVnb3JpZXMubWFwKChpdGVtOiBhbnkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZXRhSXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNhdGVnb3J5Q2xpY2soaXRlbS5zbHVnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTWV0YUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgOiAnJ31cbiAgICAgICAgICAgICAgICA8L01ldGFTaW5nbGU+XG4gICAgICAgICAgICAgIDwvUHJvZHVjdE1ldGE+XG5cbiAgICAgICAgICAgICAgPFByb2R1Y3RDYXJ0V3JhcHBlcj5cbiAgICAgICAgICAgICAgICA8UHJvZHVjdFByaWNlV3JhcHBlcj5cbiAgICAgICAgICAgICAgICAgIDxQcm9kdWN0UHJpY2U+XG4gICAgICAgICAgICAgICAgICAgIHtDVVJSRU5DWX1cbiAgICAgICAgICAgICAgICAgICAge3NhbGVQcmljZSA/IHNhbGVQcmljZSA6IHByaWNlfVxuICAgICAgICAgICAgICAgICAgPC9Qcm9kdWN0UHJpY2U+XG5cbiAgICAgICAgICAgICAgICAgIHtkaXNjb3VudEluUGVyY2VudCA/IChcbiAgICAgICAgICAgICAgICAgICAgPFNhbGVQcmljZT5cbiAgICAgICAgICAgICAgICAgICAgICB7Q1VSUkVOQ1l9XG4gICAgICAgICAgICAgICAgICAgICAge3ByaWNlfVxuICAgICAgICAgICAgICAgICAgICA8L1NhbGVQcmljZT5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgIDwvUHJvZHVjdFByaWNlV3JhcHBlcj5cblxuICAgICAgICAgICAgICAgIDxQcm9kdWN0Q2FydEJ0bj5cbiAgICAgICAgICAgICAgICAgIHshaXNJbkNhcnQoaWQpID8gKFxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdjYXJ0LWJ1dHRvbidcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PSdzZWNvbmRhcnknXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPXsxMDB9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkQ2xpY2t9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FydEljb24gbXI9ezJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD0nYWRkQ2FydEJ1dHRvbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdE1lc3NhZ2U9J0NhcnQnXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uVGV4dD5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8Q291bnRlclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXRJdGVtKGlkKS5xdWFudGl0eX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkRlY3JlbWVudD17aGFuZGxlUmVtb3ZlQ2xpY2t9XG4gICAgICAgICAgICAgICAgICAgICAgb25JbmNyZW1lbnQ9e2hhbmRsZUFkZENsaWNrfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L1Byb2R1Y3RDYXJ0QnRuPlxuICAgICAgICAgICAgICA8L1Byb2R1Y3RDYXJ0V3JhcHBlcj5cbiAgICAgICAgICAgIDwvUHJvZHVjdEluZm8+XG4gICAgICAgICAgPC9Qcm9kdWN0SW5mb1dyYXBwZXI+XG5cbiAgICAgICAgICB7aXNSdGwgJiYgKFxuICAgICAgICAgICAgPFByb2R1Y3RQcmV2aWV3PlxuICAgICAgICAgICAgICA8Q2Fyb3VzZWxXaXRoQ3VzdG9tRG90cyBpdGVtcz17Z2FsbGVyeX0gZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX0gLz5cbiAgICAgICAgICAgICAgeyEhZGlzY291bnRJblBlcmNlbnQgJiYgKFxuICAgICAgICAgICAgICAgIDxEaXNjb3VudFBlcmNlbnQ+e2Rpc2NvdW50SW5QZXJjZW50fSU8L0Rpc2NvdW50UGVyY2VudD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvUHJvZHVjdFByZXZpZXc+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9Qcm9kdWN0RGV0YWlsc1dyYXBwZXI+XG4gICAgICA8L1F1aWNrVmlld1dyYXBwZXI+XG4gICAgPC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBRdWlja1ZpZXdNb2JpbGU7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCB7IHRoZW1lR2V0IH0gZnJvbSAnQHN0eWxlZC1zeXN0ZW0vdGhlbWUtZ2V0JztcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3REZXRhaWxzV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XG4gIG1pbi1oZWlnaHQ6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAvKiBib3gtc2hhZG93OiAwIDEwcHggNDBweCByZ2JhKDAsIDAsIDAsIDAuMTYpOyAqL1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gIH1cblxuICAqIHtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFByZXZpZXcgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogNTAlO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgcGFkZGluZzogMzBweCA2MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAyMHB4IDBweDtcbiAgICBvcmRlcjogMDtcbiAgfVxuXG4gIGltZyB7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgIG1pbi13aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFNhbGVUYWcgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMueHMnLCAnMTInKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cuaG92ZXInLCAnI0ZCQjk3OScpfTtcbiAgcGFkZGluZzogMCAxMHB4O1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkubWVkaXVtJywgJzEycHgnKX07XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDQwcHg7XG4gIHJpZ2h0OiAzMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IERpc2NvdW50UGVyY2VudCA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdMYXRvJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cuaG92ZXInLCAnI0ZCQjk3OScpfTtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDMwcHg7XG4gIHJpZ2h0OiAzMHB4O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5tZWRpdW0nLCAnMTJweCcpfTtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDFweCk7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMXB4KTtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mb1dyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogNTAlO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMubGlnaHRNZWRpdW1Db2xvcicsICcjZjNmM2YzJyl9O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAzMHB4IDAgMDtcbiAgICBvcmRlcjogMTtcbiAgICBib3JkZXI6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mbyA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDUwcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RUaXRsZVByaWNlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RUaXRsZSA9IHN0eWxlZC5oMWBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmhlYWRpbmcnLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMubGcnLCAnMjEnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnNlbWlCb2xkJywgJzYwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LmJvbGQnLCAnIzBEMTEzNicpfTtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgZGlzcGxheTogZmxleDtcblxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFByaWNlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtc2hyaW5rOiAwO1xuICBtYXJnaW4tbGVmdDogMjVweDtcbiAgbGluZS1oZWlnaHQ6IDMxcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0UHJpY2UgPSBzdHlsZWQuZGl2YFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdMYXRvJyl9O1xuICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCArIDFweCk7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBTYWxlUHJpY2UgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIHBhZGRpbmc6IDAgNXB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuXG4gICY6YmVmb3JlIHtcbiAgICBjb250ZW50OiAnJztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDFweDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDUwJTtcbiAgICBsZWZ0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFdlaWdodCA9IHN0eWxlZC5kaXZgXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ0xhdG8nKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0RGVzY3JpcHRpb24gPSBzdHlsZWQucGBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5tZWRpdW0nLCAnIzQyNDU2MScpfTtcbiAgbGluZS1oZWlnaHQ6IDI7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdENhcnRCdG4gPSBzdHlsZWQuZGl2YFxuICBtYXJnaW4tdG9wOiA2MHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIG1hcmdpbi10b3A6IDQwcHg7XG4gIH1cblxuICAuY2FydC1idXR0b24ge1xuICAgIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ0xhdG8nKX07XG4gICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgIGhlaWdodDogMzZweDtcbiAgICBib3JkZXItcmFkaXVzOiA0cmVtO1xuXG4gICAgLmJ0bi1pY29uIHtcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgIH1cblxuICAgICY6aG92ZXIge1xuICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgICAgYm9yZGVyLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gICAgfVxuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQnV0dG9uVGV4dCA9IHN0eWxlZC5zcGFuYFxuICAvKiBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdENhcnRXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0TWV0YSA9IHN0eWxlZC5kaXZgXG4gIG1hcmdpbi10b3A6IDMwcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgTWV0YVNpbmdsZSA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgJjpsYXN0LWNoaWxkIHtcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgTWV0YUl0ZW0gPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQuYm9sZCcsICcjMEQxMTM2Jyl9O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5ncmF5LjIwMCcsICcjZjdmN2Y3Jyl9O1xuICBwYWRkaW5nOiAwIDE1cHg7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGhlaWdodDogMzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5gO1xuXG5leHBvcnQgY29uc3QgTW9kYWxDbG9zZSA9IHN0eWxlZC5idXR0b25gXG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiAyMHB4O1xuICByaWdodDogMTVweDtcbiAgcGFkZGluZzogMTBweCAxNXB4O1xuICB6LWluZGV4OiAxO1xuXG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDA7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgc3ZnIHtcbiAgICB3aWR0aDogMTJweDtcbiAgICBoZWlnaHQ6IDEycHg7XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgdG9wOiA1cHg7XG4gICAgcmlnaHQ6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBRdWlja1ZpZXdXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgd2lkdGg6IDEwMjBweDtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG5cbiAgJi5xdWljay12aWV3LW1vYmlsZS13cmFwcGVyIHtcbiAgICAke1Byb2R1Y3RDYXJ0V3JhcHBlcn0ge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG5cbiAgICAke1NhbGVQcmljZX0ge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICAgIH1cblxuICAgICR7UHJvZHVjdFByaWNlfSB7XG4gICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5sZycsICcyMScpfXB4O1xuICAgIH1cblxuICAgICR7UHJvZHVjdENhcnRCdG59IHtcbiAgICAgIG1hcmdpbi10b3A6IDBweDtcblxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAke1Byb2R1Y3RQcmljZX0ge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMubGcnLCAnMjEnKX1weDtcbiAgICB9XG5cbiAgICAke1Byb2R1Y3RQcmljZVdyYXBwZXJ9IHtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwO1xuXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICB9XG4gICAgfVxuICB9XG5gO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==