exports.ids = [11];
exports.modules = {

/***/ "./src/components/image/image.tsx":
/*!****************************************!*\
  !*** ./src/components/image/image.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image */ "react-image");
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-placeholder.png */ "./src/components/image/product-placeholder.png");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\image\\image.tsx";




const Placeholder = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
  src: _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__["default"],
  alt: "product img loader"
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 27
}, undefined);

function Image({
  url,
  alt = "placeholder",
  unloader,
  loader,
  className,
  style
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_image__WEBPACK_IMPORTED_MODULE_2__["Img"], {
    draggable: false,
    style: style,
    src: url,
    alt: alt,
    loader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 15
    }, this),
    unloader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 17
    }, this),
    className: className
  }, url, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./src/components/image/product-placeholder.png":
/*!******************************************************!*\
  !*** ./src/components/image/product-placeholder.png ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAADwCAYAAADxXop4AAAHPElEQVR4Xu3d23La2BaGUREOPpTf/0mNwYCsvthFtoMdix+WxBIZ46qrsjpxutpfNOXlmVnXdV0DEPjVdwDglHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcQWfQco53A4/P7n+XzezGazH89DrYRjQF3XNbvdrtntdk3btl9+fD6fN4vFonl8fBQRJmXWdV3Xd4jcfr9v3t7emnP+885ms+bh4aF5fHzsOwpVEI4BbDab5v39ve/YF8vlsnl+fvb0QfW8HC3s0mg0n55SoHbCUdB+v784Gkf7/b7Zbrd9x+CmhKOgzWbTd+Qs7+/vZ70bgVsRjkJ2u13z8fHRd+wsXdd56qBqwlHIfr/vOxIp/fNBScJRSOlP9I+PD+MK1RKOin13aQxqIBwFeDL40+er9dwn4SjAha3/a9u2Wa/X7qPcOeEoZIh4zOfzviNV6bru9zX74/focJ+Eo5Dlctl3JDLF755dr9d/vJd5e3szttwp4SikdDhWq1XfkapsNptvI7Fer4vdb6EewlHIcrksNlrMZrNJhWO32/31qn3Xdc16vfYC+c4IR0FPT099R87y9PQ0mTGlbdveq/bnnGFahKOgxWLRPD8/9x370Wq1mszTRtd1zevr61lPE7vdzjX6OyIcha1Wq4vj8fDwcPG/ewvnRuNou90Wv2HLbVjkM5DD4dBsNpuzbn/++vWreXp6Kv6CdUhvb28Xfbl1Nps1Ly8vxd4HcRvCMbDdbtccDodmv99/+dN5uVw2y+VyMqPJ0W63u+qC13w+b15eXibzHoevhGNkbdtO+k/bw+HQvL6+9h3rtVgsmpeXl75jVMo7jpFNORofHx/Ner3uO3aW4yjHNAkHZxniPsb7+/tF70m4PeGoWMlP0mud+6I3NdTPy7CEo1Kl3iWUsN1uB3sySO6CUA/hqNDxu0zbtr35pakxtq4f48F0CEeFttvt728M2263N3uUb9v2qi+7Jsb8tbiecFTmcDh8+YaxW3xCfd6tMRY7PKZDOCpy/GQ9dYuR5XS3xljs8JgG4ajI5xHlux8b6xP5b7s1xmKHR/2EoxLfjSinxhhZftqtMZYh7oxQlnBU4G8jyqmhR5aa9mbU9LHwlXBU4KcR5dRQI0uN9yns8KiXcNzYOSPKqXOeTlK1RePIDo86CccNnTuinCo9shwvm9Wq9o/vXyQcN5SMKKdKjSxTuDtxizsl/Ew4buSSEeXUJU8rnx0Oh6t/jrEc/4Y46iAcN3DpiHLqmpGl5G6NsdjhUQ/huIFrRpRTl4wsU74nYYdHHYRjZCVGlFPp08vUd2BM/eO/B8IxolIjyqlkZBlyt8ZYarxz8q8RjhGVHFFOnTOyjLFbYyx2eNyWcIykbdviI8qpn55m7nHfxT3+nqZCOEYyxv/gfxtZ7vkexBTuodwj4RjBOWNEKd/9WrfarTEWOzzGJxwDS15clvL56ebWuzXGYofHuIRjYGOMKKeOsapht8ZYpnw3ZYr8FZAD2m63oz9tfDabzf65T6TVatU8Pz/3HeNKnjgGcosR5dS/Fo3GDo/RCMdAbjGi8D92eAxPOAYw5ldR+J4dHsMSjsJqGFG477srNRCOwowo9bDDYzjCUZARpT52eAxDOAoxotTLDo/yhKMQI0rd7PAoSzgKMKLUzw6PsoTjSkaU6bDDoxzhuJIRZVrs8ChDOK5gRJkmOzyuJxwXMqJMmx0e1xGOC3ncnT47PC4nHBcwotwHOzwuJxwhI8p9advWzdILCEfIiHJ/7PDICUfAiHK/7PDILPoO8KfHx8e+I0yUF6Xns3MUiBlVgJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOI/Qe0gyoTzEMWZQAAAABJRU5ErkJggg==");

/***/ }),

/***/ "./src/components/product-card/product-card-one/product-card-one.tsx":
/*!***************************************************************************!*\
  !*** ./src/components/product-card/product-card-one/product-card-one.tsx ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_image_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/image/image */ "./src/components/image/image.tsx");
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var _product_card_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../product-card.style */ "./src/components/product-card/product-card.style.tsx");
/* harmony import */ var contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! contexts/cart/use-cart */ "./src/contexts/cart/use-cart.tsx");
/* harmony import */ var utils_cart_animation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! utils/cart-animation */ "./src/utils/cart-animation.ts");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var contexts_modal_use_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! contexts/modal/use-modal */ "./src/contexts/modal/use-modal.ts");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\product-card\\product-card-one\\product-card-one.tsx";

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

// product card for general










const QuickViewMobile = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(() => __webpack_require__.e(/*! import() */ 10).then(__webpack_require__.bind(null, /*! features/quick-view/quick-view-mobile */ "./src/features/quick-view/quick-view-mobile.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! features/quick-view/quick-view-mobile */ "./src/features/quick-view/quick-view-mobile.tsx")],
    modules: ['features/quick-view/quick-view-mobile']
  }
});

const ProductCard = (_ref) => {
  let {
    title,
    image,
    weight,
    price,
    salePrice,
    discountInPercent,
    cartProducts,
    addToCart,
    updateCart,
    value,
    currency,
    onChange,
    increment,
    decrement,
    data,
    deviceType
  } = _ref,
      props = _objectWithoutProperties(_ref, ["title", "image", "weight", "price", "salePrice", "discountInPercent", "cartProducts", "addToCart", "updateCart", "value", "currency", "onChange", "increment", "decrement", "data", "deviceType"]);

  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_10__["useRouter"])();
  const [showModal, hideModal] = Object(contexts_modal_use_modal__WEBPACK_IMPORTED_MODULE_9__["useModal"])(() => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(QuickViewMobile, {
    modalProps: data,
    hideModal: hideModal,
    deviceType: deviceType
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 66,
    columnNumber: 7
  }, undefined), {
    onClose: () => {
      const {
        pathname,
        query,
        asPath
      } = router;
      const as = asPath;
      router.push({
        pathname,
        query
      }, as, {
        shallow: true
      });
    }
  });
  const {
    addItem,
    removeItem,
    getItem,
    isInCart
  } = Object(contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_6__["useCart"])();

  const handleAddClick = e => {
    e.stopPropagation();
    addItem(data);

    if (!isInCart(data.id)) {
      Object(utils_cart_animation__WEBPACK_IMPORTED_MODULE_7__["cartAnimation"])(e);
    }
  };

  const handleRemoveClick = e => {
    e.stopPropagation();
    removeItem(data);
  };

  const handleQuickViewModal = () => {
    const {
      pathname,
      query
    } = router;
    const as = `/product/${data.slug}`;

    if (pathname === '/product/[slug]') {
      router.push(pathname, as);

      if (false) {}

      return;
    }

    showModal();
    router.push({
      pathname,
      query
    }, {
      pathname: as
    }, {
      shallow: true
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_5__["ProductCardWrapper"], {
    onClick: handleQuickViewModal,
    className: "product-card",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_5__["ProductImageWrapper"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_image_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
        url: image,
        className: "product-image",
        style: {
          position: 'relative'
        },
        alt: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 129,
        columnNumber: 9
      }, undefined), discountInPercent ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_5__["DiscountPercent"], {
        children: [discountInPercent, "%"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 136,
        columnNumber: 11
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 128,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_5__["ProductInfo"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        className: "product-title",
        style: {
          fontSize: '1.3rem'
        },
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 140,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        style: {
          fontSize: '1rem'
        },
        children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut qui soluta mollitia cumque hic ea,"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        className: "product-title",
        style: {
          fontSize: '1.1rem',
          marginTop: '5px'
        },
        children: [currency, price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 142,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "product-weight",
        children: [currency, price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 147,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "product-meta",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "productPriceWrapper",
          style: {
            justifyContent: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "onhover",
            style: {
              fontSize: ".8rem",
              textAlign: "center"
            },
            children: "Lorem ipsum dolor sit amet, consetetur"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 153,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_4__["Button"], {
            className: "hidd",
            variant: "secondary",
            borderRadius: 100,
            onClick: handleAddClick,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_5__["ButtonText"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_8__["FormattedMessage"], {
                id: "addCartButton",
                defaultMessage: "+ Add To Cart"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 164,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 163,
              columnNumber: 16
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 157,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 152,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 151,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 139,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 127,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ProductCard);

/***/ }),

/***/ "./src/components/product-card/product-card.style.tsx":
/*!************************************************************!*\
  !*** ./src/components/product-card/product-card.style.tsx ***!
  \************************************************************/
/*! exports provided: ProductCardWrapper, ProductImageWrapper, SaleTag, DiscountPercent, ProductInfo, ButtonText, BookImageWrapper, BookInfo, ProductName, AuthorInfo, PriceWrapper, Price, DiscountedPrice, BookCardWrapper, FoodCardWrapper, FoodImageWrapper, ProductMeta, DeliveryOpt, Category, Duration */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardWrapper", function() { return ProductCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductImageWrapper", function() { return ProductImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleTag", function() { return SaleTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPercent", function() { return DiscountPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfo", function() { return ProductInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonText", function() { return ButtonText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookImageWrapper", function() { return BookImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookInfo", function() { return BookInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductName", function() { return ProductName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorInfo", function() { return AuthorInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PriceWrapper", function() { return PriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Price", function() { return Price; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountedPrice", function() { return DiscountedPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookCardWrapper", function() { return BookCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodCardWrapper", function() { return FoodCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodImageWrapper", function() { return FoodImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductMeta", function() { return ProductMeta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryOpt", function() { return DeliveryOpt; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return Category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Duration", function() { return Duration; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_2__);



const StyledBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__StyledBox",
  componentId: "sc-1j4qmg9-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  py: [30, 50],
  px: ['1rem', 0]
}), {
  width: '100%'
});
const ProductCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductCardWrapper",
  componentId: "sc-1j4qmg9-1"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  height: '100%',
  width: '100%',
  backgroundColor: 'white',
  position: 'relative',
  fontFamily: 'inherit',
  borderRadius: 'base',
  cursor: 'pointer',
  ':hover .hidd': {
    opacity: '1 !important'
  },
  ':hover .onhover': {
    display: 'none !important'
  },
  '.hidd': {
    width: '100%',
    borderRadius: '15px',
    padding: '5px',
    background: '#F39C12',
    border: '0px solid',
    marginTop: '5px'
  },
  '.card-counter': {
    '@media (max-width: 767px)': {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      position: 'absolute',
      bottom: 0,
      right: 0
    }
  }
}));
const ProductImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductImageWrapper",
  componentId: "sc-1j4qmg9-2"
})(["height:240px;padding:5px;position:relative;text-align:center;display:flex;overflow:hidden;align-items:center;justify-content:center;img{max-width:170%;max-height:100%;display:inline-block;}@media (max-width:640px){height:145px;}"]);
const SaleTag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__SaleTag",
  componentId: "sc-1j4qmg9-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";padding:0 10px;line-height:24px;border-radius:", ";display:inline-block;position:absolute;top:10px;right:10px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const DiscountPercent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountPercent",
  componentId: "sc-1j4qmg9-4"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:24px;background-color:", ";padding-left:10px;padding-right:10px;position:relative;display:inline-block;position:absolute;top:15px;right:15px;border-radius:", ";z-index:2;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const ProductInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductInfo",
  componentId: "sc-1j4qmg9-5"
})(["padding:20px 25px 30px;@media (max-width:990px){padding:15px 20px;min-height:123px;}.product-title{font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;@media (max-width:767px){font-size:14px;margin:0 0 5px 0;}}.product-weight{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}}.product-meta{margin-top:30px;display:flex;align-items:center;justify-content:space-between;position:relative;@media (max-width:767px){min-height:36px;}.productPriceWrapper{position:relative;display:flex;width:100%;flex-direction:column;align-items:flex-start;.hidd{color:", ";opacity:0;.btn-text{padding:0 0 0 6px;@media (max-width:767px){display:none;}}&:hover{color:", ";background-color:", ";border-color:", ";}}.product-price{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}}.discountedPrice{font-family:", ";font-size:", "px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;position:absolute;top:-20px;left:-4px;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}}}}@media (max-width:767px){.quantity{width:32px;height:90px;display:block;flex-shrink:0;position:absolute;bottom:15px;right:15px;z-index:1;box-shadow:0 10px 20px rgba(0,0,0,0.16);}button{width:100%;height:27px;}.incBtn{top:0;justify-content:center;}.decBtn{top:auto;bottom:0;justify-content:center;}input[type='number']{left:0;font-size:calc(", "px - 1px);height:calc(100% - 54px);position:absolute;top:27px;width:100%;color:", ";}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ButtonText",
  componentId: "sc-1j4qmg9-6"
})(["@media (max-width:767px){display:none;}"]);
const BookImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookImageWrapper",
  componentId: "sc-1j4qmg9-7"
})(["height:275px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;margin-bottom:15px;img{max-width:100%;max-height:100%;display:inline-block;}@media (max-width:767px){height:215px;}", "{top:0;right:0;}"], DiscountPercent);
const BookInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookInfo",
  componentId: "sc-1j4qmg9-8"
})(["padding:0;width:100%;display:flex;flex-direction:column;align-items:center;@media (max-width:767px){padding:15px 0px 0px;}"]);
const ProductName = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ProductName",
  componentId: "sc-1j4qmg9-9"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center;display:block;&:only-child{margin:0;}@media (max-width:767px){font-size:calc(", "px - 1px);margin:0 0 5px 0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const AuthorInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__AuthorInfo",
  componentId: "sc-1j4qmg9-10"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13')); // export const AddCartBox = styled.div`
//   width: calc(100% - 40px);
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: center;
//   padding: 20px;
//   border-radius: 6px;
//   background-color: #ffffff;
//   box-shadow: 0 10px 20px rgba(0, 0, 0, 0.16);
//   position: absolute;
//   top: 50%;
//   left: 50%;
//   opacity: 0;
//   transition: all 0.3s;
//   .cart-button {
//     border-radius: 18px;
//     height: 36px;
//     padding-left: 17px;
//     padding-right: 17px;
//     font-size: ${themeGet('fontSizes.1', '13')} px;
//     font-weight: ${themeGet('fontWeights.bold', '700')};
//     @media (max-width: 767px) {
//       width: 32px;
//       height: 32px;
//       padding: 0;
//       border-radius: 50%;
//     }
//     .btn-text {
//       padding: 0 0 0 6px;
//       @media (max-width: 767px) {
//         display: none;
//       }
//     }
//     &:hover {
//       color: #fff;
//       background-color: ${themeGet('colors.primary.regular', '#F39C12')};
//       border-color: #F39C12;
//     }
//     svg {
//       fill: currentColor;
//     }
//   }
// `;

const PriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__PriceWrapper",
  componentId: "sc-1j4qmg9-11"
})(["position:relative;display:flex;flex-direction:column;align-items:flex-start;margin-bottom:15px;"]);
const Price = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Price",
  componentId: "sc-1j4qmg9-12"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const DiscountedPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountedPrice",
  componentId: "sc-1j4qmg9-13"
})(["font-family:", ";font-size:", " px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;margin-bottom:5px;margin-left:-4px;z-index:2;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'));
const BookCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookCardWrapper",
  componentId: "sc-1j4qmg9-14"
})(["height:100%;width:100%;padding:30px;background-color:", ";position:relative;font-family:", ";border-radius:", ";cursor:pointer;@media (max-width:767px){padding:15px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodCardWrapper",
  componentId: "sc-1j4qmg9-15"
})(["height:100%;width:100%;padding:0;background-color:", ";position:relative;font-family:", ";border-radius:", ";overflow:hidden;cursor:pointer;display:flex;flex-direction:column;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodImageWrapper",
  componentId: "sc-1j4qmg9-16"
})(["height:230px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;flex-shrink:0;img{width:100%;height:100%;object-fit:cover;}&:after{content:'';width:100%;height:100%;display:flex;background-color:rgba(0,0,0,0.1);position:absolute;top:0;left:0;z-index:1;}@media (max-width:767px){height:145px;}"]);
const ProductMeta = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductMeta",
  componentId: "sc-1j4qmg9-17"
})(["margin-top:20px;display:flex;align-items:center;justify-content:space-between;"]);
const DeliveryOpt = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DeliveryOpt",
  componentId: "sc-1j4qmg9-18"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";white-space:nowrap;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const Category = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Category",
  componentId: "sc-1j4qmg9-19"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const Duration = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Duration",
  componentId: "sc-1j4qmg9-20"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";border-radius:", ";padding-top:0;padding-bottom:0;padding-left:20px;padding-right:20px;height:36px;width:auto;border:0;display:flex;align-items:center;justify-content:center;white-space:nowrap;@media (max-width:600px){padding-left:10px;padding-right:10px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.big', '18px'));

/***/ }),

/***/ "./src/contexts/cart/cart.reducer.tsx":
/*!********************************************!*\
  !*** ./src/contexts/cart/cart.reducer.tsx ***!
  \********************************************/
/*! exports provided: cartItemsTotalPrice, reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartItemsTotalPrice", function() { return cartItemsTotalPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// export const cartItemsTotalPrice = (items, { discountInPercent = 0 } = {}) => {
const cartItemsTotalPrice = (items, coupon = null) => {
  if (items === null || items.length === 0) return 0;
  const itemCost = items.reduce((total, item) => {
    if (item.salePrice) {
      return total + item.salePrice * item.quantity;
    }

    return total + item.price * item.quantity;
  }, 0); // const discountRate = 1 - discountInPercent;

  const discount = coupon ? itemCost * Number(coupon.discountInPercent) / 100 : 0; // itemCost * discountRate * TAX_RATE + shipping;
  // return itemCost * discountRate;

  return itemCost - discount;
}; // cartItems, cartItemToAdd

const addItemToCart = (state, action) => {
  const existingCartItemIndex = state.items.findIndex(item => item.id === action.payload.id);

  if (existingCartItemIndex > -1) {
    const newState = [...state.items];
    newState[existingCartItemIndex].quantity += action.payload.quantity;
    return newState;
  }

  return [...state.items, action.payload];
}; // cartItems, cartItemToRemove


const removeItemFromCart = (state, action) => {
  return state.items.reduce((acc, item) => {
    if (item.id === action.payload.id) {
      const newQuantity = item.quantity - action.payload.quantity;
      return newQuantity > 0 ? [...acc, _objectSpread(_objectSpread({}, item), {}, {
        quantity: newQuantity
      })] : [...acc];
    }

    return [...acc, item];
  }, []);
};

const clearItemFromCart = (state, action) => {
  return state.items.filter(item => item.id !== action.payload.id);
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'REHYDRATE':
      return _objectSpread(_objectSpread({}, state), action.payload);

    case 'TOGGLE_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        isOpen: !state.isOpen
      });

    case 'ADD_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: addItemToCart(state, action)
      });

    case 'REMOVE_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: removeItemFromCart(state, action)
      });

    case 'CLEAR_ITEM_FROM_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: clearItemFromCart(state, action)
      });

    case 'CLEAR_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: []
      });

    case 'APPLY_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: action.payload
      });

    case 'REMOVE_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: null
      });

    case 'TOGGLE_RESTAURANT':
      return _objectSpread(_objectSpread({}, state), {}, {
        isRestaurant: !state.isRestaurant
      });

    default:
      throw new Error(`Unknown action: ${action.type}`);
  }
};

/***/ }),

/***/ "./src/contexts/cart/use-cart.tsx":
/*!****************************************!*\
  !*** ./src/contexts/cart/use-cart.tsx ***!
  \****************************************/
/*! exports provided: CartProvider, useCart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartProvider", function() { return CartProvider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useCart", function() { return useCart; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _cart_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cart.reducer */ "./src/contexts/cart/cart.reducer.tsx");
/* harmony import */ var utils_use_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! utils/use-storage */ "./src/utils/use-storage.ts");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\contexts\\cart\\use-cart.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const CartContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])({});
const INITIAL_STATE = {
  isOpen: false,
  items: [],
  isRestaurant: false,
  coupon: null
};

const useCartActions = (initialCart = INITIAL_STATE) => {
  var _state$items3;

  const {
    0: state,
    1: dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useReducer"])(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["reducer"], initialCart);

  const addItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const removeItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'REMOVE_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const clearItemFromCartHandler = item => {
    dispatch({
      type: 'CLEAR_ITEM_FROM_CART',
      payload: item
    });
  };

  const clearCartHandler = () => {
    dispatch({
      type: 'CLEAR_CART'
    });
  };

  const toggleCartHandler = () => {
    dispatch({
      type: 'TOGGLE_CART'
    });
  };

  const couponHandler = coupon => {
    dispatch({
      type: 'APPLY_COUPON',
      payload: coupon
    });
  };

  const removeCouponHandler = () => {
    dispatch({
      type: 'REMOVE_COUPON'
    });
  };

  const rehydrateLocalState = payload => {
    dispatch({
      type: 'REHYDRATE',
      payload
    });
  };

  const toggleRestaurant = () => {
    dispatch({
      type: 'TOGGLE_RESTAURANT'
    });
  };

  const isInCartHandler = id => {
    var _state$items;

    return (_state$items = state.items) === null || _state$items === void 0 ? void 0 : _state$items.some(item => item.id === id);
  };

  const getItemHandler = id => {
    var _state$items2;

    return (_state$items2 = state.items) === null || _state$items2 === void 0 ? void 0 : _state$items2.find(item => item.id === id);
  };

  const getCartItemsPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items).toFixed(2);

  const getCartItemsTotalPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items, state.coupon).toFixed(2);

  const getDiscount = () => {
    var _state$coupon;

    const total = Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items);
    const discount = state.coupon ? total * Number((_state$coupon = state.coupon) === null || _state$coupon === void 0 ? void 0 : _state$coupon.discountInPercent) / 100 : 0;
    return discount.toFixed(2);
  };

  const getItemsCount = (_state$items3 = state.items) === null || _state$items3 === void 0 ? void 0 : _state$items3.reduce((acc, item) => acc + item.quantity, 0);
  return {
    state,
    getItemsCount,
    rehydrateLocalState,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    getCartItemsPrice,
    couponHandler,
    removeCouponHandler,
    getDiscount,
    toggleRestaurant
  };
};

const CartProvider = ({
  children
}) => {
  var _state$items4;

  const {
    state,
    rehydrateLocalState,
    getItemsCount,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    couponHandler,
    removeCouponHandler,
    getCartItemsPrice,
    getDiscount,
    toggleRestaurant
  } = useCartActions();
  const {
    rehydrated,
    error
  } = Object(utils_use_storage__WEBPACK_IMPORTED_MODULE_3__["useStorage"])(state, rehydrateLocalState);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CartContext.Provider, {
    value: {
      isOpen: state.isOpen,
      items: state.items,
      coupon: state.coupon,
      isRestaurant: state.isRestaurant,
      cartItemsCount: (_state$items4 = state.items) === null || _state$items4 === void 0 ? void 0 : _state$items4.length,
      itemsCount: getItemsCount,
      addItem: addItemHandler,
      removeItem: removeItemHandler,
      removeItemFromCart: clearItemFromCartHandler,
      clearCart: clearCartHandler,
      isInCart: isInCartHandler,
      getItem: getItemHandler,
      toggleCart: toggleCartHandler,
      calculatePrice: getCartItemsTotalPrice,
      calculateSubTotalPrice: getCartItemsPrice,
      applyCoupon: couponHandler,
      removeCoupon: removeCouponHandler,
      calculateDiscount: getDiscount,
      toggleRestaurant
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 108,
    columnNumber: 5
  }, undefined);
};
const useCart = () => Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(CartContext);

/***/ }),

/***/ "./src/contexts/modal/use-modal.ts":
/*!*****************************************!*\
  !*** ./src/contexts/modal/use-modal.ts ***!
  \*****************************************/
/*! exports provided: useModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useModal", function() { return useModal; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modal_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal.context */ "./src/contexts/modal/modal.context.ts");


/**
 * Callback types provided for descriptive type-hints
 */

/**
 * Utility function to generate unique number per component instance
 */
const generateModalKey = (() => {
  let count = 0;
  return () => `${++count}`;
})();
/**
 * Check whether the argument is a stateless component.
 *
 * We take advantage of the stateless nature of functional components to be
 * inline the rendering of the modal component as part of another immutable
 * component.
 *
 * This is necessary for allowing the modal to update based on the inputs passed
 * as the second argument to useModal without unmounting the previous version of
 * the modal component.
 */


const isFunctionalComponent = Component => {
  const prototype = Component.prototype;
  return !prototype || !prototype.isReactComponent;
};
/**
 * React hook for showing modal windows
 */


const useModal = (component, options = {}) => {
  if (!isFunctionalComponent(component)) {
    throw new Error('Only stateless components can be used as an argument to useModal. You have probably passed a class component where a function was expected.');
  }

  const key = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(generateModalKey, []);
  const modal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(() => component, options.inputs);
  const context = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_modal_context__WEBPACK_IMPORTED_MODULE_1__["ModalContext"]);
  const showModal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => context.showModal(key, modal, options), [context.showModal]);
  const hideModal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => context.hideModal(key), [context.hideModal, key]); // const [isShown, setShown] = useState<boolean>(false);
  // const showModal = useCallback(() => setShown(true), []);
  // const hideModal = useCallback(() => setShown(false), []);
  // useEffect(() => {
  //   if (isShown) {
  //     context.showModal(key, modal);
  //   } else {
  //     context.hideModal(key);
  //   }
  //   // Hide modal when parent component unmounts
  //   return () => context.hideModal(key);
  // }, [modal, isShown]);

  return [showModal, hideModal];
}; // export default useModal;
/// uses
// import useModal from "use-modal";
// import ModalProvider from "modal.provider";
// import Modal from "react-modal"; // It can be any modal
// const MyModal = memo(
//   ({ isOpen, onClose, title, description, closeBtnLabel }) => (
//     <Modal isOpen={isOpen} onRequestClose={onClose}>
//       <h2>{title}</h2>
//       <div>{description}</div>
//       <button onClick={onClose}>{closeBtnLabel}</button>
//     </Modal>
//   )
// );
// const SomePage = memo(() => {
//   const [showModal, hideModal] = useModal(MyModal, {
//     title: "My Test Modal",
//     description: "I Like React Hooks",
//     closeBtnLabel: "Close"
//   });
//   return (
//     <>
//       <h1>Test Page</h1>
//       <button onClick={showModal}>Show Modal</button>
//     </>
//   );
// });
// const App = () => (
//   <ModalProvider>
//     <SomePage />
//   </ModalProvider>
// );
// useModal(<ModalComponent: Function|>, <modalProps: Object>, <onClose: Function>): [showModal: Function, hideModal: Function]
// Param	Type	Description
// ModalComponent	Function	It can be any react component that you want to use for show modal
// modalProps	Object	Props that you want to pass to your modal component
// showModal	Function	It is function for show your modal, you can pass any dynamic props to this function
// hideModal	Function	It is function for hide your modal, you can pass any dynamic props to this function
// onClose	Function	It callback will be triggered after modal window closes
// showModal(dynamicModalProps: Object)
// Param	Type	Description
// dynamicModalProps	Object	Dynamic props that you want to pass to your modal component

/***/ }),

/***/ "./src/utils/cart-animation.ts":
/*!*************************************!*\
  !*** ./src/utils/cart-animation.ts ***!
  \*************************************/
/*! exports provided: cartAnimation */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartAnimation", function() { return cartAnimation; });
const cartAnimation = event => {
  const getClosest = function (elem, selector) {
    for (; elem && elem !== document; elem = elem.parentNode) {
      if (elem.matches(selector)) return elem;
    }

    return null;
  }; // start animation block


  let imgToDrag = getClosest(event.target, '.product-card');
  let viewCart = document.getElementsByClassName('product-cart')[0];
  let imgToDragImage = imgToDrag.querySelector('.product-image');
  let disLeft = imgToDrag.getBoundingClientRect().left;
  let disTop = imgToDrag.getBoundingClientRect().top;
  let cartLeft = viewCart.getBoundingClientRect().left;
  let cartTop = viewCart.getBoundingClientRect().top;
  let image = imgToDragImage.cloneNode(true);
  image.style = 'z-index: 11111; width: 100px;opacity:1; position:fixed; top:' + disTop + 'px;left:' + disLeft + 'px;transition: left 1s, top 1s, width 1s, opacity 1s cubic-bezier(1, 1, 1, 1);border-radius: 50px; overflow: hidden; box-shadow: 0 21px 36px rgba(0,0,0,0.1)';
  var reChange = document.body.appendChild(image);
  setTimeout(function () {
    image.style.left = cartLeft + 'px';
    image.style.top = cartTop + 'px';
    image.style.width = '40px';
    image.style.opacity = '0';
  }, 200);
  setTimeout(function () {
    reChange.parentNode.removeChild(reChange);
  }, 1000); // End Animation Block
};

/***/ }),

/***/ "./src/utils/use-storage.ts":
/*!**********************************!*\
  !*** ./src/utils/use-storage.ts ***!
  \**********************************/
/*! exports provided: useStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useStorage", function() { return useStorage; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! localforage */ "localforage");
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(localforage__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const isObjectLiked = value => value.constructor.name === 'Array' || value.constructor.name === 'Object';

const rehydrate = (value, defaultValue) => {
  if (!value) return defaultValue; // if (value === 'false') str = false;
  // if (value === 'true') str = true;
  // if (!isObjectLiked(value)) {
  //   return value;
  // }

  try {
    const parse = JSON.parse(value);
    return parse;
  } catch (err) {
    return defaultValue;
  }
};

const hydrate = value => {
  if (!isObjectLiked(value)) {
    return value;
  }

  return JSON.stringify(value);
};

const createMigration = (opts, data) => {
  return new Promise((resolve, reject) => {
    const key = `${opts.key}-version`;
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(key, (err, version) => {
      if (version !== opts.version) {
        data = opts.migrate(data);
        localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(opts.key, rehydrate(data), err => {
          if (err) return reject(err);
          localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(key, opts.version, err => {
            if (err) return reject(err);
            return resolve(data);
          });
        });
      } else {
        resolve(data);
      }
    });
  });
};

const config = {
  key: '@session',
  version: 1,
  migrate: state => {
    return _objectSpread({}, state);
  }
};
const useStorage = (state, setState) => {
  const {
    0: rehydrated,
    1: setRehydrated
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const {
    0: error,
    1: setError
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function init() {
      await localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(config.key, (err, value) => {
        if (err) {
          setRehydrated(true);
          return setError(err);
        } // Migrate persisted data


        const restoredValue = rehydrate(value);

        if (typeof config.migrate === 'function') {
          createMigration(config, restoredValue).then(data => setState(data)).then(() => setRehydrated(true));
        } else {
          setState(restoredValue);
          setRehydrated(true);
        }
      });
    }

    init();
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    // if (isNil(state) || isEmpty(state)) {
    //   localForage.removeItem(config.key);
    // }
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(config.key, hydrate(state));
  }, [state]);
  return {
    rehydrated,
    error
  };
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbWFnZS9pbWFnZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvaW1hZ2UvcHJvZHVjdC1wbGFjZWhvbGRlci5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC1vbmUvcHJvZHVjdC1jYXJkLW9uZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC5zdHlsZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRleHRzL2NhcnQvY2FydC5yZWR1Y2VyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGV4dHMvY2FydC91c2UtY2FydC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRleHRzL21vZGFsL3VzZS1tb2RhbC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvY2FydC1hbmltYXRpb24udHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3V0aWxzL3VzZS1zdG9yYWdlLnRzIl0sIm5hbWVzIjpbIlBsYWNlaG9sZGVyIiwicGxhY2Vob2xkZXIiLCJJbWFnZSIsInVybCIsImFsdCIsInVubG9hZGVyIiwibG9hZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJRdWlja1ZpZXdNb2JpbGUiLCJkeW5hbWljIiwiUHJvZHVjdENhcmQiLCJ0aXRsZSIsImltYWdlIiwid2VpZ2h0IiwicHJpY2UiLCJzYWxlUHJpY2UiLCJkaXNjb3VudEluUGVyY2VudCIsImNhcnRQcm9kdWN0cyIsImFkZFRvQ2FydCIsInVwZGF0ZUNhcnQiLCJ2YWx1ZSIsImN1cnJlbmN5Iiwib25DaGFuZ2UiLCJpbmNyZW1lbnQiLCJkZWNyZW1lbnQiLCJkYXRhIiwiZGV2aWNlVHlwZSIsInByb3BzIiwicm91dGVyIiwidXNlUm91dGVyIiwic2hvd01vZGFsIiwiaGlkZU1vZGFsIiwidXNlTW9kYWwiLCJvbkNsb3NlIiwicGF0aG5hbWUiLCJxdWVyeSIsImFzUGF0aCIsImFzIiwicHVzaCIsInNoYWxsb3ciLCJhZGRJdGVtIiwicmVtb3ZlSXRlbSIsImdldEl0ZW0iLCJpc0luQ2FydCIsInVzZUNhcnQiLCJoYW5kbGVBZGRDbGljayIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJpZCIsImNhcnRBbmltYXRpb24iLCJoYW5kbGVSZW1vdmVDbGljayIsImhhbmRsZVF1aWNrVmlld01vZGFsIiwic2x1ZyIsInBvc2l0aW9uIiwiZm9udFNpemUiLCJtYXJnaW5Ub3AiLCJqdXN0aWZ5Q29udGVudCIsInRleHRBbGlnbiIsIlN0eWxlZEJveCIsInN0eWxlZCIsImRpdiIsImNzcyIsInB5IiwicHgiLCJ3aWR0aCIsIlByb2R1Y3RDYXJkV3JhcHBlciIsImhlaWdodCIsImJhY2tncm91bmRDb2xvciIsImZvbnRGYW1pbHkiLCJib3JkZXJSYWRpdXMiLCJjdXJzb3IiLCJvcGFjaXR5IiwiZGlzcGxheSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiZmxleERpcmVjdGlvbiIsImJvdHRvbSIsInJpZ2h0IiwiUHJvZHVjdEltYWdlV3JhcHBlciIsIlNhbGVUYWciLCJzcGFuIiwidGhlbWVHZXQiLCJEaXNjb3VudFBlcmNlbnQiLCJQcm9kdWN0SW5mbyIsIkJ1dHRvblRleHQiLCJCb29rSW1hZ2VXcmFwcGVyIiwiQm9va0luZm8iLCJQcm9kdWN0TmFtZSIsIkF1dGhvckluZm8iLCJQcmljZVdyYXBwZXIiLCJQcmljZSIsIkRpc2NvdW50ZWRQcmljZSIsIkJvb2tDYXJkV3JhcHBlciIsIkZvb2RDYXJkV3JhcHBlciIsIkZvb2RJbWFnZVdyYXBwZXIiLCJQcm9kdWN0TWV0YSIsIkRlbGl2ZXJ5T3B0IiwiQ2F0ZWdvcnkiLCJEdXJhdGlvbiIsImNhcnRJdGVtc1RvdGFsUHJpY2UiLCJpdGVtcyIsImNvdXBvbiIsImxlbmd0aCIsIml0ZW1Db3N0IiwicmVkdWNlIiwidG90YWwiLCJpdGVtIiwicXVhbnRpdHkiLCJkaXNjb3VudCIsIk51bWJlciIsImFkZEl0ZW1Ub0NhcnQiLCJzdGF0ZSIsImFjdGlvbiIsImV4aXN0aW5nQ2FydEl0ZW1JbmRleCIsImZpbmRJbmRleCIsInBheWxvYWQiLCJuZXdTdGF0ZSIsInJlbW92ZUl0ZW1Gcm9tQ2FydCIsImFjYyIsIm5ld1F1YW50aXR5IiwiY2xlYXJJdGVtRnJvbUNhcnQiLCJmaWx0ZXIiLCJyZWR1Y2VyIiwidHlwZSIsImlzT3BlbiIsImlzUmVzdGF1cmFudCIsIkVycm9yIiwiQ2FydENvbnRleHQiLCJjcmVhdGVDb250ZXh0IiwiSU5JVElBTF9TVEFURSIsInVzZUNhcnRBY3Rpb25zIiwiaW5pdGlhbENhcnQiLCJkaXNwYXRjaCIsInVzZVJlZHVjZXIiLCJhZGRJdGVtSGFuZGxlciIsInJlbW92ZUl0ZW1IYW5kbGVyIiwiY2xlYXJJdGVtRnJvbUNhcnRIYW5kbGVyIiwiY2xlYXJDYXJ0SGFuZGxlciIsInRvZ2dsZUNhcnRIYW5kbGVyIiwiY291cG9uSGFuZGxlciIsInJlbW92ZUNvdXBvbkhhbmRsZXIiLCJyZWh5ZHJhdGVMb2NhbFN0YXRlIiwidG9nZ2xlUmVzdGF1cmFudCIsImlzSW5DYXJ0SGFuZGxlciIsInNvbWUiLCJnZXRJdGVtSGFuZGxlciIsImZpbmQiLCJnZXRDYXJ0SXRlbXNQcmljZSIsInRvRml4ZWQiLCJnZXRDYXJ0SXRlbXNUb3RhbFByaWNlIiwiZ2V0RGlzY291bnQiLCJnZXRJdGVtc0NvdW50IiwiQ2FydFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJyZWh5ZHJhdGVkIiwiZXJyb3IiLCJ1c2VTdG9yYWdlIiwiY2FydEl0ZW1zQ291bnQiLCJpdGVtc0NvdW50IiwiY2xlYXJDYXJ0IiwidG9nZ2xlQ2FydCIsImNhbGN1bGF0ZVByaWNlIiwiY2FsY3VsYXRlU3ViVG90YWxQcmljZSIsImFwcGx5Q291cG9uIiwicmVtb3ZlQ291cG9uIiwiY2FsY3VsYXRlRGlzY291bnQiLCJ1c2VDb250ZXh0IiwiZ2VuZXJhdGVNb2RhbEtleSIsImNvdW50IiwiaXNGdW5jdGlvbmFsQ29tcG9uZW50IiwiQ29tcG9uZW50IiwicHJvdG90eXBlIiwiaXNSZWFjdENvbXBvbmVudCIsImNvbXBvbmVudCIsIm9wdGlvbnMiLCJrZXkiLCJ1c2VNZW1vIiwibW9kYWwiLCJpbnB1dHMiLCJjb250ZXh0IiwiTW9kYWxDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJldmVudCIsImdldENsb3Nlc3QiLCJlbGVtIiwic2VsZWN0b3IiLCJkb2N1bWVudCIsInBhcmVudE5vZGUiLCJtYXRjaGVzIiwiaW1nVG9EcmFnIiwidGFyZ2V0Iiwidmlld0NhcnQiLCJnZXRFbGVtZW50c0J5Q2xhc3NOYW1lIiwiaW1nVG9EcmFnSW1hZ2UiLCJxdWVyeVNlbGVjdG9yIiwiZGlzTGVmdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImxlZnQiLCJkaXNUb3AiLCJ0b3AiLCJjYXJ0TGVmdCIsImNhcnRUb3AiLCJjbG9uZU5vZGUiLCJyZUNoYW5nZSIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInNldFRpbWVvdXQiLCJyZW1vdmVDaGlsZCIsImlzT2JqZWN0TGlrZWQiLCJjb25zdHJ1Y3RvciIsIm5hbWUiLCJyZWh5ZHJhdGUiLCJkZWZhdWx0VmFsdWUiLCJwYXJzZSIsIkpTT04iLCJlcnIiLCJoeWRyYXRlIiwic3RyaW5naWZ5IiwiY3JlYXRlTWlncmF0aW9uIiwib3B0cyIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwibG9jYWxGb3JhZ2UiLCJ2ZXJzaW9uIiwibWlncmF0ZSIsInNldEl0ZW0iLCJjb25maWciLCJzZXRTdGF0ZSIsInNldFJlaHlkcmF0ZWQiLCJ1c2VTdGF0ZSIsInNldEVycm9yIiwidXNlRWZmZWN0IiwiaW5pdCIsInJlc3RvcmVkVmFsdWUiLCJ0aGVuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOztBQUNBLE1BQU1BLFdBQVcsR0FBRyxtQkFBTTtBQUFLLEtBQUcsRUFBRUMsZ0VBQVY7QUFBdUIsS0FBRyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMUI7O0FBQ2UsU0FBU0MsS0FBVCxDQUFlO0FBQzVCQyxLQUQ0QjtBQUU1QkMsS0FBRyxHQUFHLGFBRnNCO0FBRzVCQyxVQUg0QjtBQUk1QkMsUUFKNEI7QUFLNUJDLFdBTDRCO0FBTTVCQztBQU40QixDQUFmLEVBY1o7QUFDRCxzQkFDRSxxRUFBQywrQ0FBRDtBQUNFLGFBQVMsRUFBRSxLQURiO0FBRUUsU0FBSyxFQUFFQSxLQUZUO0FBR0UsT0FBRyxFQUFFTCxHQUhQO0FBS0UsT0FBRyxFQUFFQyxHQUxQO0FBTUUsVUFBTSxlQUFFLHFFQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5WO0FBT0UsWUFBUSxlQUFFLHFFQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVBaO0FBUUUsYUFBUyxFQUFFRztBQVJiLEtBSU9KLEdBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBWUQsQzs7Ozs7Ozs7Ozs7O0FDL0JEO0FBQWUsK0VBQWdCLDQvRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQS9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU9BO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQSxNQUFNTSxlQUFlLEdBQUdDLG1EQUFPLENBQzdCLE1BQU0sOEtBRHVCO0FBQUE7QUFBQSx3Q0FDaEIsOEZBRGdCO0FBQUEsY0FDaEIsdUNBRGdCO0FBQUE7QUFBQSxFQUEvQjs7QUF3QkEsTUFBTUMsV0FBdUMsR0FBRyxVQWtCMUM7QUFBQSxNQWxCMkM7QUFDL0NDLFNBRCtDO0FBRS9DQyxTQUYrQztBQUcvQ0MsVUFIK0M7QUFJL0NDLFNBSitDO0FBSy9DQyxhQUwrQztBQU0vQ0MscUJBTitDO0FBTy9DQyxnQkFQK0M7QUFRL0NDLGFBUitDO0FBUy9DQyxjQVQrQztBQVUvQ0MsU0FWK0M7QUFXL0NDLFlBWCtDO0FBWS9DQyxZQVorQztBQWEvQ0MsYUFiK0M7QUFjL0NDLGFBZCtDO0FBZS9DQyxRQWYrQztBQWdCL0NDO0FBaEIrQyxHQWtCM0M7QUFBQSxNQUREQyxLQUNDOztBQUNKLFFBQU1DLE1BQU0sR0FBR0MsOERBQVMsRUFBeEI7QUFDQSxRQUFNLENBQUNDLFNBQUQsRUFBWUMsU0FBWixJQUF5QkMseUVBQVEsQ0FDckMsbUJBQ0UscUVBQUMsZUFBRDtBQUNFLGNBQVUsRUFBRVAsSUFEZDtBQUVFLGFBQVMsRUFBRU0sU0FGYjtBQUdFLGNBQVUsRUFBRUw7QUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRm1DLEVBUXJDO0FBQ0VPLFdBQU8sRUFBRSxNQUFNO0FBQ2IsWUFBTTtBQUFFQyxnQkFBRjtBQUFZQyxhQUFaO0FBQW1CQztBQUFuQixVQUE4QlIsTUFBcEM7QUFDQSxZQUFNUyxFQUFFLEdBQUdELE1BQVg7QUFDQVIsWUFBTSxDQUFDVSxJQUFQLENBQ0U7QUFDRUosZ0JBREY7QUFFRUM7QUFGRixPQURGLEVBS0VFLEVBTEYsRUFNRTtBQUNFRSxlQUFPLEVBQUU7QUFEWCxPQU5GO0FBVUQ7QUFkSCxHQVJxQyxDQUF2QztBQXlCQSxRQUFNO0FBQUVDLFdBQUY7QUFBV0MsY0FBWDtBQUF1QkMsV0FBdkI7QUFBZ0NDO0FBQWhDLE1BQTZDQyxzRUFBTyxFQUExRDs7QUFDQSxRQUFNQyxjQUFjLEdBQUlDLENBQUQsSUFBTztBQUM1QkEsS0FBQyxDQUFDQyxlQUFGO0FBQ0FQLFdBQU8sQ0FBQ2YsSUFBRCxDQUFQOztBQUNBLFFBQUksQ0FBQ2tCLFFBQVEsQ0FBQ2xCLElBQUksQ0FBQ3VCLEVBQU4sQ0FBYixFQUF3QjtBQUN0QkMsZ0ZBQWEsQ0FBQ0gsQ0FBRCxDQUFiO0FBQ0Q7QUFDRixHQU5EOztBQU9BLFFBQU1JLGlCQUFpQixHQUFJSixDQUFELElBQU87QUFDL0JBLEtBQUMsQ0FBQ0MsZUFBRjtBQUNBTixjQUFVLENBQUNoQixJQUFELENBQVY7QUFDRCxHQUhEOztBQUlBLFFBQU0wQixvQkFBb0IsR0FBRyxNQUFNO0FBQ2pDLFVBQU07QUFBRWpCLGNBQUY7QUFBWUM7QUFBWixRQUFzQlAsTUFBNUI7QUFDQSxVQUFNUyxFQUFFLEdBQUksWUFBV1osSUFBSSxDQUFDMkIsSUFBSyxFQUFqQzs7QUFDQSxRQUFJbEIsUUFBUSxLQUFLLGlCQUFqQixFQUFvQztBQUNsQ04sWUFBTSxDQUFDVSxJQUFQLENBQVlKLFFBQVosRUFBc0JHLEVBQXRCOztBQUNBLGlCQUFtQyxFQUVsQzs7QUFDRDtBQUNEOztBQUNEUCxhQUFTO0FBQ1RGLFVBQU0sQ0FBQ1UsSUFBUCxDQUNFO0FBQ0VKLGNBREY7QUFFRUM7QUFGRixLQURGLEVBS0U7QUFDRUQsY0FBUSxFQUFFRztBQURaLEtBTEYsRUFRRTtBQUNFRSxhQUFPLEVBQUU7QUFEWCxLQVJGO0FBWUQsR0F2QkQ7O0FBeUJBLHNCQUNFLHFFQUFDLHNFQUFEO0FBQW9CLFdBQU8sRUFBRVksb0JBQTdCO0FBQW1ELGFBQVMsRUFBQyxjQUE3RDtBQUFBLDRCQUNFLHFFQUFDLHVFQUFEO0FBQUEsOEJBQ0UscUVBQUMsOERBQUQ7QUFDRSxXQUFHLEVBQUV2QyxLQURQO0FBRUUsaUJBQVMsRUFBQyxlQUZaO0FBR0UsYUFBSyxFQUFFO0FBQUV5QyxrQkFBUSxFQUFFO0FBQVosU0FIVDtBQUlFLFdBQUcsRUFBRTFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQU9HSyxpQkFBaUIsZ0JBQ2hCLHFFQUFDLG1FQUFEO0FBQUEsbUJBQWtCQSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURnQixHQUVkLElBVE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBWUUscUVBQUMsK0RBQUQ7QUFBQSw4QkFDRTtBQUFJLGlCQUFTLEVBQUMsZUFBZDtBQUE4QixhQUFLLEVBQUU7QUFBQ3NDLGtCQUFRLEVBQUM7QUFBVixTQUFyQztBQUFBLGtCQUE0RDNDO0FBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFHLGFBQUssRUFBRTtBQUFDMkMsa0JBQVEsRUFBQztBQUFWLFNBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFHRTtBQUFJLGlCQUFTLEVBQUMsZUFBZDtBQUE4QixhQUFLLEVBQUU7QUFBQ0Esa0JBQVEsRUFBQyxRQUFWO0FBQW1CQyxtQkFBUyxFQUFDO0FBQTdCLFNBQXJDO0FBQUEsbUJBQ0dsQyxRQURILEVBRUdQLEtBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVFFO0FBQU0saUJBQVMsRUFBQyxnQkFBaEI7QUFBQSxtQkFDR08sUUFESCxFQUVHUCxLQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQVlFO0FBQUssaUJBQVMsRUFBQyxjQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLHFCQUFmO0FBQXFDLGVBQUssRUFBRTtBQUFDMEMsMEJBQWMsRUFBQztBQUFoQixXQUE1QztBQUFBLGtDQUNFO0FBQU0scUJBQVMsRUFBQyxTQUFoQjtBQUEwQixpQkFBSyxFQUFFO0FBQUNGLHNCQUFRLEVBQUMsT0FBVjtBQUFrQkcsdUJBQVMsRUFBQztBQUE1QixhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUtFLHFFQUFDLCtEQUFEO0FBQ0UscUJBQVMsRUFBQyxNQURaO0FBRUUsbUJBQU8sRUFBQyxXQUZWO0FBR0Usd0JBQVksRUFBRSxHQUhoQjtBQUlFLG1CQUFPLEVBQUVaLGNBSlg7QUFBQSxtQ0FNRyxxRUFBQyw4REFBRDtBQUFBLHFDQUNDLHFFQUFDLDJEQUFEO0FBQWtCLGtCQUFFLEVBQUMsZUFBckI7QUFBcUMsOEJBQWMsRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnRkQsQ0FsS0Q7O0FBb0tlbkMsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDL01BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBLE1BQU1nRCxTQUFTLEdBQUdDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsR0FDYkMseURBQUcsQ0FBQztBQUNGQyxJQUFFLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQURGO0FBRUZDLElBQUUsRUFBRSxDQUFDLE1BQUQsRUFBUyxDQUFUO0FBRkYsQ0FBRCxDQURVLEVBS2I7QUFDRUMsT0FBSyxFQUFFO0FBRFQsQ0FMYSxDQUFmO0FBVU8sTUFBTUMsa0JBQWtCLEdBQUdOLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsR0FDN0JDLHlEQUFHLENBQUM7QUFDRkssUUFBTSxFQUFFLE1BRE47QUFFRkYsT0FBSyxFQUFFLE1BRkw7QUFHRkcsaUJBQWUsRUFBRSxPQUhmO0FBSUZkLFVBQVEsRUFBRSxVQUpSO0FBS0ZlLFlBQVUsRUFBRSxTQUxWO0FBTUZDLGNBQVksRUFBRSxNQU5aO0FBT0ZDLFFBQU0sRUFBRSxTQVBOO0FBUUYsa0JBQWU7QUFDYkMsV0FBTyxFQUFDO0FBREssR0FSYjtBQVdGLHFCQUFrQjtBQUNoQkMsV0FBTyxFQUFDO0FBRFEsR0FYaEI7QUFlRixXQUFRO0FBQ05SLFNBQUssRUFBQyxNQURBO0FBRU5LLGdCQUFZLEVBQUMsTUFGUDtBQUdOSSxXQUFPLEVBQUMsS0FIRjtBQUlOQyxjQUFVLEVBQUMsU0FKTDtBQUtOQyxVQUFNLEVBQUMsV0FMRDtBQU1OcEIsYUFBUyxFQUFDO0FBTkosR0FmTjtBQXVCRixtQkFBaUI7QUFDZixpQ0FBNkI7QUFDM0JTLFdBQUssRUFBRSxFQURvQjtBQUUzQkUsWUFBTSxFQUFFLEVBRm1CO0FBRzNCVSxtQkFBYSxFQUFFLGdCQUhZO0FBSTNCdkIsY0FBUSxFQUFFLFVBSmlCO0FBSzNCd0IsWUFBTSxFQUFFLENBTG1CO0FBTTNCQyxXQUFLLEVBQUU7QUFOb0I7QUFEZDtBQXZCZixDQUFELENBRDBCLENBQXhCO0FBeUNBLE1BQU1DLG1CQUFtQixHQUFHcEIsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0T0FBekI7QUFtQkEsTUFBTW9CLE9BQU8sR0FBR3JCLHdEQUFNLENBQUNzQixJQUFWO0FBQUE7QUFBQTtBQUFBLDJNQUNIQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREwsRUFFTEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkgsRUFHSEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhMLEVBSVRBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpDLEVBS0VBLHlFQUFRLENBQUMsdUJBQUQsRUFBMEIsU0FBMUIsQ0FMVixFQVFEQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FSUCxDQUFiO0FBZUEsTUFBTUMsZUFBZSxHQUFHeEIsd0RBQU0sQ0FBQ3NCLElBQVY7QUFBQTtBQUFBO0FBQUEsNlBBQ1hDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERyxFQUViQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGSyxFQUdYQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEcsRUFJakJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpTLEVBTU5BLHlFQUFRLENBQUMsdUJBQUQsRUFBMEIsU0FBMUIsQ0FORixFQWNUQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FkQyxDQUFyQjtBQWtCQSxNQUFNRSxXQUFXLEdBQUd6Qix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLDByREFRTHNCLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FSSCxFQVNQQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBVEQsRUFVTEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQVZILEVBV1hBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FYRyxFQXVCTEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQXZCSCxFQXdCUEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBeEJELEVBeUJMQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBekJILEVBMEJYQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBMUJHLEVBNEJMQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0E1QkgsRUFnRFBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixNQUFqQixDQWhERCxFQXlETEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLE1BQWpCLENBekRILEVBMERNQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBMURkLEVBMkRFQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBM0RWLEVBK0REQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBL0RQLEVBZ0VIQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBaEVMLEVBaUVEQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBakVQLEVBa0VQQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBbEVELEVBb0VJQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBcEVaLEVBd0VEQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBeEVQLEVBeUVIQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0F6RUwsRUEwRURBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0ExRVAsRUEyRVBBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0EzRUQsRUF3Rk1BLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0F4RmQsRUE0SEVBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0E1SFYsRUFpSVBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQWpJRCxDQUFqQjtBQXVJQSxNQUFNRyxVQUFVLEdBQUcxQix3REFBTSxDQUFDc0IsSUFBVjtBQUFBO0FBQUE7QUFBQSwrQ0FBaEI7QUFNQSxNQUFNSyxnQkFBZ0IsR0FBRzNCLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsa1FBaUJ6QnVCLGVBakJ5QixDQUF0QjtBQXVCQSxNQUFNSSxRQUFRLEdBQUc1Qix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLGtJQUFkO0FBV0EsTUFBTTRCLFdBQVcsR0FBRzdCLHdEQUFNLENBQUNzQixJQUFWO0FBQUE7QUFBQTtBQUFBLDRSQUNQQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREQsRUFFVEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZDLEVBR1BBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIRCxFQUliQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBSkssRUFnQkZBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FoQk4sQ0FBakI7QUFxQkEsTUFBTU8sVUFBVSxHQUFHOUIsd0RBQU0sQ0FBQ3NCLElBQVY7QUFBQTtBQUFBO0FBQUEsa0hBQ05DLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERixFQUVSQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGQSxFQUdOQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEYsRUFJWkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpJLEVBTU5BLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQU5GLENBQWhCLEMsQ0FVUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPLE1BQU1RLFlBQVksR0FBRy9CLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsdUdBQWxCO0FBUUEsTUFBTStCLEtBQUssR0FBR2hDLHdEQUFNLENBQUNzQixJQUFWO0FBQUE7QUFBQTtBQUFBLDhIQUNEQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBRFAsRUFFSEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZMLEVBR0RBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIUCxFQUlQQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBSkQsRUFNSUEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQU5aLENBQVg7QUFVQSxNQUFNVSxlQUFlLEdBQUdqQyx3REFBTSxDQUFDc0IsSUFBVjtBQUFBO0FBQUE7QUFBQSw4U0FDWEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURHLEVBRWJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZLLEVBR1hBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0FIRyxFQUlqQkEseUVBQVEsQ0FBQyx1QkFBRCxFQUEwQixTQUExQixDQUpTLEVBaUJKQSx5RUFBUSxDQUFDLHVCQUFELEVBQTBCLFNBQTFCLENBakJKLENBQXJCO0FBd0JBLE1BQU1XLGVBQWUsR0FBR2xDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsK0tBSU5zQix5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKRixFQU1YQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBTkcsRUFPVEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsS0FBZixDQVBDLENBQXJCO0FBY0EsTUFBTVksZUFBZSxHQUFHbkMsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSx3TEFJTnNCLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpGLEVBTVhBLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FORyxFQU9UQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBUEMsQ0FBckI7QUFjQSxNQUFNYSxnQkFBZ0IsR0FBR3BDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsOFZBQXRCO0FBOEJBLE1BQU1vQyxXQUFXLEdBQUdyQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHNGQUFqQjtBQU9BLE1BQU1xQyxXQUFXLEdBQUd0Qyx3REFBTSxDQUFDc0IsSUFBVjtBQUFBO0FBQUE7QUFBQSwwRkFDUEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURELEVBRVRBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZDLEVBR1BBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIRCxFQUliQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBSkssQ0FBakI7QUFRQSxNQUFNZ0IsUUFBUSxHQUFHdkMsd0RBQU0sQ0FBQ3NCLElBQVY7QUFBQTtBQUFBO0FBQUEsdUVBQ0pDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FESixFQUVOQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRixFQUdKQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEosRUFJVkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpFLENBQWQ7QUFPQSxNQUFNaUIsUUFBUSxHQUFHeEMsd0RBQU0sQ0FBQ3NCLElBQVY7QUFBQTtBQUFBO0FBQUEsNlZBQ0pDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FESixFQUVOQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRixFQUdKQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEosRUFJVkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBSkUsRUFLQ0EseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQUxULEVBTUZBLHlFQUFRLENBQUMsV0FBRCxFQUFjLE1BQWQsQ0FOTixDQUFkLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2plUDtBQUNPLE1BQU1rQixtQkFBbUIsR0FBRyxDQUFDQyxLQUFELEVBQVFDLE1BQU0sR0FBRyxJQUFqQixLQUEwQjtBQUMzRCxNQUFJRCxLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxDQUFDRSxNQUFOLEtBQWlCLENBQXZDLEVBQTBDLE9BQU8sQ0FBUDtBQUMxQyxRQUFNQyxRQUFRLEdBQUdILEtBQUssQ0FBQ0ksTUFBTixDQUFhLENBQUNDLEtBQUQsRUFBUUMsSUFBUixLQUFpQjtBQUM3QyxRQUFJQSxJQUFJLENBQUM1RixTQUFULEVBQW9CO0FBQ2xCLGFBQU8yRixLQUFLLEdBQUdDLElBQUksQ0FBQzVGLFNBQUwsR0FBaUI0RixJQUFJLENBQUNDLFFBQXJDO0FBQ0Q7O0FBQ0QsV0FBT0YsS0FBSyxHQUFHQyxJQUFJLENBQUM3RixLQUFMLEdBQWE2RixJQUFJLENBQUNDLFFBQWpDO0FBQ0QsR0FMZ0IsRUFLZCxDQUxjLENBQWpCLENBRjJELENBUTNEOztBQUNBLFFBQU1DLFFBQVEsR0FBR1AsTUFBTSxHQUNsQkUsUUFBUSxHQUFHTSxNQUFNLENBQUNSLE1BQU0sQ0FBQ3RGLGlCQUFSLENBQWxCLEdBQWdELEdBRDdCLEdBRW5CLENBRkosQ0FUMkQsQ0FZM0Q7QUFDQTs7QUFDQSxTQUFPd0YsUUFBUSxHQUFHSyxRQUFsQjtBQUNELENBZk0sQyxDQWdCUDs7QUFDQSxNQUFNRSxhQUFhLEdBQUcsQ0FBQ0MsS0FBRCxFQUFRQyxNQUFSLEtBQW1CO0FBQ3ZDLFFBQU1DLHFCQUFxQixHQUFHRixLQUFLLENBQUNYLEtBQU4sQ0FBWWMsU0FBWixDQUMzQlIsSUFBRCxJQUFVQSxJQUFJLENBQUMzRCxFQUFMLEtBQVlpRSxNQUFNLENBQUNHLE9BQVAsQ0FBZXBFLEVBRFQsQ0FBOUI7O0FBSUEsTUFBSWtFLHFCQUFxQixHQUFHLENBQUMsQ0FBN0IsRUFBZ0M7QUFDOUIsVUFBTUcsUUFBUSxHQUFHLENBQUMsR0FBR0wsS0FBSyxDQUFDWCxLQUFWLENBQWpCO0FBQ0FnQixZQUFRLENBQUNILHFCQUFELENBQVIsQ0FBZ0NOLFFBQWhDLElBQTRDSyxNQUFNLENBQUNHLE9BQVAsQ0FBZVIsUUFBM0Q7QUFDQSxXQUFPUyxRQUFQO0FBQ0Q7O0FBQ0QsU0FBTyxDQUFDLEdBQUdMLEtBQUssQ0FBQ1gsS0FBVixFQUFpQlksTUFBTSxDQUFDRyxPQUF4QixDQUFQO0FBQ0QsQ0FYRCxDLENBYUE7OztBQUNBLE1BQU1FLGtCQUFrQixHQUFHLENBQUNOLEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUM1QyxTQUFPRCxLQUFLLENBQUNYLEtBQU4sQ0FBWUksTUFBWixDQUFtQixDQUFDYyxHQUFELEVBQU1aLElBQU4sS0FBZTtBQUN2QyxRQUFJQSxJQUFJLENBQUMzRCxFQUFMLEtBQVlpRSxNQUFNLENBQUNHLE9BQVAsQ0FBZXBFLEVBQS9CLEVBQW1DO0FBQ2pDLFlBQU13RSxXQUFXLEdBQUdiLElBQUksQ0FBQ0MsUUFBTCxHQUFnQkssTUFBTSxDQUFDRyxPQUFQLENBQWVSLFFBQW5EO0FBRUEsYUFBT1ksV0FBVyxHQUFHLENBQWQsR0FDSCxDQUFDLEdBQUdELEdBQUosa0NBQWNaLElBQWQ7QUFBb0JDLGdCQUFRLEVBQUVZO0FBQTlCLFNBREcsR0FFSCxDQUFDLEdBQUdELEdBQUosQ0FGSjtBQUdEOztBQUNELFdBQU8sQ0FBQyxHQUFHQSxHQUFKLEVBQVNaLElBQVQsQ0FBUDtBQUNELEdBVE0sRUFTSixFQVRJLENBQVA7QUFVRCxDQVhEOztBQWFBLE1BQU1jLGlCQUFpQixHQUFHLENBQUNULEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUMzQyxTQUFPRCxLQUFLLENBQUNYLEtBQU4sQ0FBWXFCLE1BQVosQ0FBb0JmLElBQUQsSUFBVUEsSUFBSSxDQUFDM0QsRUFBTCxLQUFZaUUsTUFBTSxDQUFDRyxPQUFQLENBQWVwRSxFQUF4RCxDQUFQO0FBQ0QsQ0FGRDs7QUFJTyxNQUFNMkUsT0FBTyxHQUFHLENBQUNYLEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUN4QyxVQUFRQSxNQUFNLENBQUNXLElBQWY7QUFDRSxTQUFLLFdBQUw7QUFDRSw2Q0FBWVosS0FBWixHQUFzQkMsTUFBTSxDQUFDRyxPQUE3Qjs7QUFDRixTQUFLLGFBQUw7QUFDRSw2Q0FBWUosS0FBWjtBQUFtQmEsY0FBTSxFQUFFLENBQUNiLEtBQUssQ0FBQ2E7QUFBbEM7O0FBQ0YsU0FBSyxVQUFMO0FBQ0UsNkNBQVliLEtBQVo7QUFBbUJYLGFBQUssRUFBRVUsYUFBYSxDQUFDQyxLQUFELEVBQVFDLE1BQVI7QUFBdkM7O0FBQ0YsU0FBSyxhQUFMO0FBQ0UsNkNBQVlELEtBQVo7QUFBbUJYLGFBQUssRUFBRWlCLGtCQUFrQixDQUFDTixLQUFELEVBQVFDLE1BQVI7QUFBNUM7O0FBQ0YsU0FBSyxzQkFBTDtBQUNFLDZDQUFZRCxLQUFaO0FBQW1CWCxhQUFLLEVBQUVvQixpQkFBaUIsQ0FBQ1QsS0FBRCxFQUFRQyxNQUFSO0FBQTNDOztBQUNGLFNBQUssWUFBTDtBQUNFLDZDQUFZRCxLQUFaO0FBQW1CWCxhQUFLLEVBQUU7QUFBMUI7O0FBQ0YsU0FBSyxjQUFMO0FBQ0UsNkNBQVlXLEtBQVo7QUFBbUJWLGNBQU0sRUFBRVcsTUFBTSxDQUFDRztBQUFsQzs7QUFDRixTQUFLLGVBQUw7QUFDRSw2Q0FBWUosS0FBWjtBQUFtQlYsY0FBTSxFQUFFO0FBQTNCOztBQUNGLFNBQUssbUJBQUw7QUFDRSw2Q0FBWVUsS0FBWjtBQUFtQmMsb0JBQVksRUFBRSxDQUFDZCxLQUFLLENBQUNjO0FBQXhDOztBQUNGO0FBQ0UsWUFBTSxJQUFJQyxLQUFKLENBQVcsbUJBQWtCZCxNQUFNLENBQUNXLElBQUssRUFBekMsQ0FBTjtBQXBCSjtBQXNCRCxDQXZCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRFA7QUFDQTtBQUNBO0FBQ0EsTUFBTUksV0FBVyxnQkFBR0MsMkRBQWEsQ0FBQyxFQUFELENBQWpDO0FBQ0EsTUFBTUMsYUFBYSxHQUFHO0FBQ3BCTCxRQUFNLEVBQUUsS0FEWTtBQUVwQnhCLE9BQUssRUFBRSxFQUZhO0FBR3BCeUIsY0FBWSxFQUFFLEtBSE07QUFJcEJ4QixRQUFNLEVBQUU7QUFKWSxDQUF0Qjs7QUFPQSxNQUFNNkIsY0FBYyxHQUFHLENBQUNDLFdBQVcsR0FBR0YsYUFBZixLQUFpQztBQUFBOztBQUN0RCxRQUFNO0FBQUEsT0FBQ2xCLEtBQUQ7QUFBQSxPQUFRcUI7QUFBUixNQUFvQkMsd0RBQVUsQ0FBQ1gscURBQUQsRUFBVVMsV0FBVixDQUFwQzs7QUFFQSxRQUFNRyxjQUFjLEdBQUcsQ0FBQzVCLElBQUQsRUFBT0MsUUFBUSxHQUFHLENBQWxCLEtBQXdCO0FBQzdDeUIsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRSxVQUFSO0FBQW9CUixhQUFPLGtDQUFPVCxJQUFQO0FBQWFDO0FBQWI7QUFBM0IsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFJQSxRQUFNNEIsaUJBQWlCLEdBQUcsQ0FBQzdCLElBQUQsRUFBT0MsUUFBUSxHQUFHLENBQWxCLEtBQXdCO0FBQ2hEeUIsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRSxhQUFSO0FBQXVCUixhQUFPLGtDQUFPVCxJQUFQO0FBQWFDO0FBQWI7QUFBOUIsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFJQSxRQUFNNkIsd0JBQXdCLEdBQUk5QixJQUFELElBQVU7QUFDekMwQixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLHNCQUFSO0FBQWdDUixhQUFPLEVBQUVUO0FBQXpDLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBSUEsUUFBTStCLGdCQUFnQixHQUFHLE1BQU07QUFDN0JMLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUU7QUFBUixLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU1lLGlCQUFpQixHQUFHLE1BQU07QUFDOUJOLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUU7QUFBUixLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU1nQixhQUFhLEdBQUl0QyxNQUFELElBQVk7QUFDaEMrQixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLGNBQVI7QUFBd0JSLGFBQU8sRUFBRWQ7QUFBakMsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNdUMsbUJBQW1CLEdBQUcsTUFBTTtBQUNoQ1IsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWtCLG1CQUFtQixHQUFJMUIsT0FBRCxJQUFhO0FBQ3ZDaUIsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRSxXQUFSO0FBQXFCUjtBQUFyQixLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU0yQixnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCVixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFO0FBQVIsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNb0IsZUFBZSxHQUFJaEcsRUFBRCxJQUFRO0FBQUE7O0FBQzlCLDJCQUFPZ0UsS0FBSyxDQUFDWCxLQUFiLGlEQUFPLGFBQWE0QyxJQUFiLENBQW1CdEMsSUFBRCxJQUFVQSxJQUFJLENBQUMzRCxFQUFMLEtBQVlBLEVBQXhDLENBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU1rRyxjQUFjLEdBQUlsRyxFQUFELElBQVE7QUFBQTs7QUFDN0IsNEJBQU9nRSxLQUFLLENBQUNYLEtBQWIsa0RBQU8sY0FBYThDLElBQWIsQ0FBbUJ4QyxJQUFELElBQVVBLElBQUksQ0FBQzNELEVBQUwsS0FBWUEsRUFBeEMsQ0FBUDtBQUNELEdBRkQ7O0FBR0EsUUFBTW9HLGlCQUFpQixHQUFHLE1BQU1oRCx5RUFBbUIsQ0FBQ1ksS0FBSyxDQUFDWCxLQUFQLENBQW5CLENBQWlDZ0QsT0FBakMsQ0FBeUMsQ0FBekMsQ0FBaEM7O0FBQ0EsUUFBTUMsc0JBQXNCLEdBQUcsTUFDN0JsRCx5RUFBbUIsQ0FBQ1ksS0FBSyxDQUFDWCxLQUFQLEVBQWNXLEtBQUssQ0FBQ1YsTUFBcEIsQ0FBbkIsQ0FBK0MrQyxPQUEvQyxDQUF1RCxDQUF2RCxDQURGOztBQUdBLFFBQU1FLFdBQVcsR0FBRyxNQUFNO0FBQUE7O0FBQ3hCLFVBQU03QyxLQUFLLEdBQUdOLHlFQUFtQixDQUFDWSxLQUFLLENBQUNYLEtBQVAsQ0FBakM7QUFDQSxVQUFNUSxRQUFRLEdBQUdHLEtBQUssQ0FBQ1YsTUFBTixHQUNaSSxLQUFLLEdBQUdJLE1BQU0sa0JBQUNFLEtBQUssQ0FBQ1YsTUFBUCxrREFBQyxjQUFjdEYsaUJBQWYsQ0FBZixHQUFvRCxHQUR2QyxHQUViLENBRko7QUFHQSxXQUFPNkYsUUFBUSxDQUFDd0MsT0FBVCxDQUFpQixDQUFqQixDQUFQO0FBQ0QsR0FORDs7QUFPQSxRQUFNRyxhQUFhLG9CQUFHeEMsS0FBSyxDQUFDWCxLQUFULGtEQUFHLGNBQWFJLE1BQWIsQ0FDcEIsQ0FBQ2MsR0FBRCxFQUFNWixJQUFOLEtBQWVZLEdBQUcsR0FBR1osSUFBSSxDQUFDQyxRQUROLEVBRXBCLENBRm9CLENBQXRCO0FBSUEsU0FBTztBQUNMSSxTQURLO0FBRUx3QyxpQkFGSztBQUdMVix1QkFISztBQUlMUCxrQkFKSztBQUtMQyxxQkFMSztBQU1MQyw0QkFOSztBQU9MQyxvQkFQSztBQVFMTSxtQkFSSztBQVNMRSxrQkFUSztBQVVMUCxxQkFWSztBQVdMVywwQkFYSztBQVlMRixxQkFaSztBQWFMUixpQkFiSztBQWNMQyx1QkFkSztBQWVMVSxlQWZLO0FBZ0JMUjtBQWhCSyxHQUFQO0FBa0JELENBeEVEOztBQTBFTyxNQUFNVSxZQUFZLEdBQUcsQ0FBQztBQUFFQztBQUFGLENBQUQsS0FBa0I7QUFBQTs7QUFDNUMsUUFBTTtBQUNKMUMsU0FESTtBQUVKOEIsdUJBRkk7QUFHSlUsaUJBSEk7QUFJSmpCLGtCQUpJO0FBS0pDLHFCQUxJO0FBTUpDLDRCQU5JO0FBT0pDLG9CQVBJO0FBUUpNLG1CQVJJO0FBU0pFLGtCQVRJO0FBVUpQLHFCQVZJO0FBV0pXLDBCQVhJO0FBWUpWLGlCQVpJO0FBYUpDLHVCQWJJO0FBY0pPLHFCQWRJO0FBZUpHLGVBZkk7QUFnQkpSO0FBaEJJLE1BaUJGWixjQUFjLEVBakJsQjtBQWtCQSxRQUFNO0FBQUV3QixjQUFGO0FBQWNDO0FBQWQsTUFBd0JDLG9FQUFVLENBQUM3QyxLQUFELEVBQVE4QixtQkFBUixDQUF4QztBQUVBLHNCQUNFLHFFQUFDLFdBQUQsQ0FBYSxRQUFiO0FBQ0UsU0FBSyxFQUFFO0FBQ0xqQixZQUFNLEVBQUViLEtBQUssQ0FBQ2EsTUFEVDtBQUVMeEIsV0FBSyxFQUFFVyxLQUFLLENBQUNYLEtBRlI7QUFHTEMsWUFBTSxFQUFFVSxLQUFLLENBQUNWLE1BSFQ7QUFJTHdCLGtCQUFZLEVBQUVkLEtBQUssQ0FBQ2MsWUFKZjtBQUtMZ0Msb0JBQWMsbUJBQUU5QyxLQUFLLENBQUNYLEtBQVIsa0RBQUUsY0FBYUUsTUFMeEI7QUFNTHdELGdCQUFVLEVBQUVQLGFBTlA7QUFPTGhILGFBQU8sRUFBRStGLGNBUEo7QUFRTDlGLGdCQUFVLEVBQUUrRixpQkFSUDtBQVNMbEIsd0JBQWtCLEVBQUVtQix3QkFUZjtBQVVMdUIsZUFBUyxFQUFFdEIsZ0JBVk47QUFXTC9GLGNBQVEsRUFBRXFHLGVBWEw7QUFZTHRHLGFBQU8sRUFBRXdHLGNBWko7QUFhTGUsZ0JBQVUsRUFBRXRCLGlCQWJQO0FBY0x1QixvQkFBYyxFQUFFWixzQkFkWDtBQWVMYSw0QkFBc0IsRUFBRWYsaUJBZm5CO0FBZ0JMZ0IsaUJBQVcsRUFBRXhCLGFBaEJSO0FBaUJMeUIsa0JBQVksRUFBRXhCLG1CQWpCVDtBQWtCTHlCLHVCQUFpQixFQUFFZixXQWxCZDtBQW1CTFI7QUFuQkssS0FEVDtBQUFBLGNBdUJHVztBQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyQkQsQ0FoRE07QUFrREEsTUFBTTlHLE9BQU8sR0FBRyxNQUFNMkgsd0RBQVUsQ0FBQ3ZDLFdBQUQsQ0FBaEMsQzs7Ozs7Ozs7Ozs7O0FDdklQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTtBQUNBLE1BQU13QyxnQkFBZ0IsR0FBRyxDQUFDLE1BQU07QUFDOUIsTUFBSUMsS0FBSyxHQUFHLENBQVo7QUFFQSxTQUFPLE1BQU8sR0FBRSxFQUFFQSxLQUFNLEVBQXhCO0FBQ0QsQ0FKd0IsR0FBekI7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNQyxxQkFBcUIsR0FBSUMsU0FBRCxJQUF5QjtBQUNyRCxRQUFNQyxTQUFTLEdBQUdELFNBQVMsQ0FBQ0MsU0FBNUI7QUFFQSxTQUFPLENBQUNBLFNBQUQsSUFBYyxDQUFDQSxTQUFTLENBQUNDLGdCQUFoQztBQUNELENBSkQ7QUFNQTtBQUNBO0FBQ0E7OztBQUNPLE1BQU03SSxRQUFRLEdBQUcsQ0FDdEI4SSxTQURzQixFQUV0QkMsT0FBWSxHQUFHLEVBRk8sS0FHSztBQUMzQixNQUFJLENBQUNMLHFCQUFxQixDQUFDSSxTQUFELENBQTFCLEVBQXVDO0FBQ3JDLFVBQU0sSUFBSS9DLEtBQUosQ0FDSiw2SUFESSxDQUFOO0FBR0Q7O0FBRUQsUUFBTWlELEdBQUcsR0FBR0MscURBQU8sQ0FBQ1QsZ0JBQUQsRUFBbUIsRUFBbkIsQ0FBbkI7QUFDQSxRQUFNVSxLQUFLLEdBQUdELHFEQUFPLENBQUMsTUFBTUgsU0FBUCxFQUFrQkMsT0FBTyxDQUFDSSxNQUExQixDQUFyQjtBQUNBLFFBQU1DLE9BQU8sR0FBR2Isd0RBQVUsQ0FBQ2MsMkRBQUQsQ0FBMUI7QUFDQSxRQUFNdkosU0FBUyxHQUFHd0oseURBQVcsQ0FBQyxNQUFNRixPQUFPLENBQUN0SixTQUFSLENBQWtCa0osR0FBbEIsRUFBdUJFLEtBQXZCLEVBQThCSCxPQUE5QixDQUFQLEVBQStDLENBQzFFSyxPQUFPLENBQUN0SixTQURrRSxDQUEvQyxDQUE3QjtBQUdBLFFBQU1DLFNBQVMsR0FBR3VKLHlEQUFXLENBQUMsTUFBTUYsT0FBTyxDQUFDckosU0FBUixDQUFrQmlKLEdBQWxCLENBQVAsRUFBK0IsQ0FDMURJLE9BQU8sQ0FBQ3JKLFNBRGtELEVBRTFEaUosR0FGMEQsQ0FBL0IsQ0FBN0IsQ0FiMkIsQ0FpQjNCO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQSxTQUFPLENBQUNsSixTQUFELEVBQVlDLFNBQVosQ0FBUDtBQUNELENBcENNLEMsQ0FzQ1A7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVGOzs7Ozs7Ozs7Ozs7QUMzSEE7QUFBQTtBQUFPLE1BQU1rQixhQUFhLEdBQUlzSSxLQUFELElBQVc7QUFDdEMsUUFBTUMsVUFBVSxHQUFHLFVBQVVDLElBQVYsRUFBZ0JDLFFBQWhCLEVBQTBCO0FBQzNDLFdBQU9ELElBQUksSUFBSUEsSUFBSSxLQUFLRSxRQUF4QixFQUFrQ0YsSUFBSSxHQUFHQSxJQUFJLENBQUNHLFVBQTlDLEVBQTBEO0FBQ3hELFVBQUlILElBQUksQ0FBQ0ksT0FBTCxDQUFhSCxRQUFiLENBQUosRUFBNEIsT0FBT0QsSUFBUDtBQUM3Qjs7QUFDRCxXQUFPLElBQVA7QUFDRCxHQUxELENBRHNDLENBUXRDOzs7QUFDQSxNQUFJSyxTQUFTLEdBQUdOLFVBQVUsQ0FBQ0QsS0FBSyxDQUFDUSxNQUFQLEVBQWUsZUFBZixDQUExQjtBQUNBLE1BQUlDLFFBQVEsR0FBR0wsUUFBUSxDQUFDTSxzQkFBVCxDQUFnQyxjQUFoQyxFQUFnRCxDQUFoRCxDQUFmO0FBQ0EsTUFBSUMsY0FBYyxHQUFHSixTQUFTLENBQUNLLGFBQVYsQ0FBd0IsZ0JBQXhCLENBQXJCO0FBRUEsTUFBSUMsT0FBTyxHQUFHTixTQUFTLENBQUNPLHFCQUFWLEdBQWtDQyxJQUFoRDtBQUNBLE1BQUlDLE1BQU0sR0FBR1QsU0FBUyxDQUFDTyxxQkFBVixHQUFrQ0csR0FBL0M7QUFDQSxNQUFJQyxRQUFRLEdBQUdULFFBQVEsQ0FBQ0sscUJBQVQsR0FBaUNDLElBQWhEO0FBQ0EsTUFBSUksT0FBTyxHQUFHVixRQUFRLENBQUNLLHFCQUFULEdBQWlDRyxHQUEvQztBQUNBLE1BQUk1TCxLQUFLLEdBQUdzTCxjQUFjLENBQUNTLFNBQWYsQ0FBeUIsSUFBekIsQ0FBWjtBQUNBL0wsT0FBSyxDQUFDTCxLQUFOLEdBQ0UsaUVBQ0FnTSxNQURBLEdBRUEsVUFGQSxHQUdBSCxPQUhBLEdBSUEsOEpBTEY7QUFNQSxNQUFJUSxRQUFRLEdBQUdqQixRQUFRLENBQUNrQixJQUFULENBQWNDLFdBQWQsQ0FBMEJsTSxLQUExQixDQUFmO0FBQ0FtTSxZQUFVLENBQUMsWUFBWTtBQUNyQm5NLFNBQUssQ0FBQ0wsS0FBTixDQUFZK0wsSUFBWixHQUFtQkcsUUFBUSxHQUFHLElBQTlCO0FBQ0E3TCxTQUFLLENBQUNMLEtBQU4sQ0FBWWlNLEdBQVosR0FBa0JFLE9BQU8sR0FBRyxJQUE1QjtBQUNBOUwsU0FBSyxDQUFDTCxLQUFOLENBQVl5RCxLQUFaLEdBQW9CLE1BQXBCO0FBQ0FwRCxTQUFLLENBQUNMLEtBQU4sQ0FBWWdFLE9BQVosR0FBc0IsR0FBdEI7QUFDRCxHQUxTLEVBS1AsR0FMTyxDQUFWO0FBTUF3SSxZQUFVLENBQUMsWUFBWTtBQUNyQkgsWUFBUSxDQUFDaEIsVUFBVCxDQUFvQm9CLFdBQXBCLENBQWdDSixRQUFoQztBQUNELEdBRlMsRUFFUCxJQUZPLENBQVYsQ0EvQnNDLENBa0N0QztBQUNELENBbkNNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FQO0FBQ0E7O0FBQ0EsTUFBTUssYUFBYSxHQUFJN0wsS0FBRCxJQUNwQkEsS0FBSyxDQUFDOEwsV0FBTixDQUFrQkMsSUFBbEIsS0FBMkIsT0FBM0IsSUFBc0MvTCxLQUFLLENBQUM4TCxXQUFOLENBQWtCQyxJQUFsQixLQUEyQixRQURuRTs7QUFHQSxNQUFNQyxTQUFTLEdBQUcsQ0FBQ2hNLEtBQUQsRUFBYWlNLFlBQWIsS0FBb0M7QUFDcEQsTUFBSSxDQUFDak0sS0FBTCxFQUFZLE9BQU9pTSxZQUFQLENBRHdDLENBRXBEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsTUFBSTtBQUNGLFVBQU1DLEtBQUssR0FBR0MsSUFBSSxDQUFDRCxLQUFMLENBQVdsTSxLQUFYLENBQWQ7QUFDQSxXQUFPa00sS0FBUDtBQUNELEdBSEQsQ0FHRSxPQUFPRSxHQUFQLEVBQVk7QUFDWixXQUFPSCxZQUFQO0FBQ0Q7QUFDRixDQWJEOztBQWVBLE1BQU1JLE9BQU8sR0FBSXJNLEtBQUQsSUFBVztBQUN6QixNQUFJLENBQUM2TCxhQUFhLENBQUM3TCxLQUFELENBQWxCLEVBQTJCO0FBQ3pCLFdBQU9BLEtBQVA7QUFDRDs7QUFDRCxTQUFPbU0sSUFBSSxDQUFDRyxTQUFMLENBQWV0TSxLQUFmLENBQVA7QUFDRCxDQUxEOztBQU1BLE1BQU11TSxlQUFlLEdBQUcsQ0FBQ0MsSUFBRCxFQUFPbk0sSUFBUCxLQUFnQjtBQUN0QyxTQUFPLElBQUlvTSxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3RDLFVBQU0vQyxHQUFHLEdBQUksR0FBRTRDLElBQUksQ0FBQzVDLEdBQUksVUFBeEI7QUFDQWdELHNEQUFXLENBQUN0TCxPQUFaLENBQW9Cc0ksR0FBcEIsRUFBeUIsQ0FBQ3dDLEdBQUQsRUFBTVMsT0FBTixLQUFrQjtBQUN6QyxVQUFJQSxPQUFPLEtBQUtMLElBQUksQ0FBQ0ssT0FBckIsRUFBOEI7QUFDNUJ4TSxZQUFJLEdBQUdtTSxJQUFJLENBQUNNLE9BQUwsQ0FBYXpNLElBQWIsQ0FBUDtBQUNBdU0sMERBQVcsQ0FBQ0csT0FBWixDQUFvQlAsSUFBSSxDQUFDNUMsR0FBekIsRUFBOEJvQyxTQUFTLENBQUMzTCxJQUFELENBQXZDLEVBQWdEK0wsR0FBRCxJQUFTO0FBQ3RELGNBQUlBLEdBQUosRUFBUyxPQUFPTyxNQUFNLENBQUNQLEdBQUQsQ0FBYjtBQUNUUSw0REFBVyxDQUFDRyxPQUFaLENBQW9CbkQsR0FBcEIsRUFBeUI0QyxJQUFJLENBQUNLLE9BQTlCLEVBQXdDVCxHQUFELElBQVM7QUFDOUMsZ0JBQUlBLEdBQUosRUFBUyxPQUFPTyxNQUFNLENBQUNQLEdBQUQsQ0FBYjtBQUNULG1CQUFPTSxPQUFPLENBQUNyTSxJQUFELENBQWQ7QUFDRCxXQUhEO0FBSUQsU0FORDtBQU9ELE9BVEQsTUFTTztBQUNMcU0sZUFBTyxDQUFDck0sSUFBRCxDQUFQO0FBQ0Q7QUFDRixLQWJEO0FBY0QsR0FoQk0sQ0FBUDtBQWlCRCxDQWxCRDs7QUFvQkEsTUFBTTJNLE1BQU0sR0FBRztBQUNicEQsS0FBRyxFQUFFLFVBRFE7QUFFYmlELFNBQU8sRUFBRSxDQUZJO0FBR2JDLFNBQU8sRUFBR2xILEtBQUQsSUFBVztBQUNsQiw2QkFBWUEsS0FBWjtBQUNEO0FBTFksQ0FBZjtBQVFPLE1BQU02QyxVQUFVLEdBQUcsQ0FBQzdDLEtBQUQsRUFBUXFILFFBQVIsS0FBcUI7QUFDN0MsUUFBTTtBQUFBLE9BQUMxRSxVQUFEO0FBQUEsT0FBYTJFO0FBQWIsTUFBOEJDLHNEQUFRLENBQUMsS0FBRCxDQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDM0UsS0FBRDtBQUFBLE9BQVE0RTtBQUFSLE1BQW9CRCxzREFBUSxDQUFDLElBQUQsQ0FBbEM7QUFFQUUseURBQVMsQ0FBQyxNQUFNO0FBQ2QsbUJBQWVDLElBQWYsR0FBc0I7QUFDcEIsWUFBTVYsa0RBQVcsQ0FBQ3RMLE9BQVosQ0FBb0IwTCxNQUFNLENBQUNwRCxHQUEzQixFQUFnQyxDQUFDd0MsR0FBRCxFQUFNcE0sS0FBTixLQUFnQjtBQUNwRCxZQUFJb00sR0FBSixFQUFTO0FBQ1BjLHVCQUFhLENBQUMsSUFBRCxDQUFiO0FBQ0EsaUJBQU9FLFFBQVEsQ0FBQ2hCLEdBQUQsQ0FBZjtBQUNELFNBSm1ELENBS3BEOzs7QUFDQSxjQUFNbUIsYUFBYSxHQUFHdkIsU0FBUyxDQUFDaE0sS0FBRCxDQUEvQjs7QUFDQSxZQUFJLE9BQU9nTixNQUFNLENBQUNGLE9BQWQsS0FBMEIsVUFBOUIsRUFBMEM7QUFDeENQLHlCQUFlLENBQUNTLE1BQUQsRUFBU08sYUFBVCxDQUFmLENBQ0dDLElBREgsQ0FDU25OLElBQUQsSUFBVTRNLFFBQVEsQ0FBQzVNLElBQUQsQ0FEMUIsRUFFR21OLElBRkgsQ0FFUSxNQUFNTixhQUFhLENBQUMsSUFBRCxDQUYzQjtBQUdELFNBSkQsTUFJTztBQUNMRCxrQkFBUSxDQUFDTSxhQUFELENBQVI7QUFDQUwsdUJBQWEsQ0FBQyxJQUFELENBQWI7QUFDRDtBQUNGLE9BZkssQ0FBTjtBQWdCRDs7QUFDREksUUFBSTtBQUNMLEdBcEJRLEVBb0JOLEVBcEJNLENBQVQ7QUFzQkFELHlEQUFTLENBQUMsTUFBTTtBQUNkO0FBQ0E7QUFDQTtBQUNBVCxzREFBVyxDQUFDRyxPQUFaLENBQW9CQyxNQUFNLENBQUNwRCxHQUEzQixFQUFnQ3lDLE9BQU8sQ0FBQ3pHLEtBQUQsQ0FBdkM7QUFDRCxHQUxRLEVBS04sQ0FBQ0EsS0FBRCxDQUxNLENBQVQ7QUFPQSxTQUFPO0FBQ0wyQyxjQURLO0FBRUxDO0FBRkssR0FBUDtBQUlELENBckNNLEMiLCJmaWxlIjoiMTEuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWcgfSBmcm9tIFwicmVhY3QtaW1hZ2VcIjtcbmltcG9ydCBwbGFjZWhvbGRlciBmcm9tIFwiLi9wcm9kdWN0LXBsYWNlaG9sZGVyLnBuZ1wiO1xuY29uc3QgUGxhY2Vob2xkZXIgPSAoKSA9PiA8aW1nIHNyYz17cGxhY2Vob2xkZXJ9IGFsdD1cInByb2R1Y3QgaW1nIGxvYWRlclwiIC8+O1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW1hZ2Uoe1xuICB1cmwsXG4gIGFsdCA9IFwicGxhY2Vob2xkZXJcIixcbiAgdW5sb2FkZXIsXG4gIGxvYWRlcixcbiAgY2xhc3NOYW1lLFxuICBzdHlsZSxcbn06IHtcbiAgdXJsPzogc3RyaW5nO1xuICBhbHQ/OiBzdHJpbmc7XG4gIHVubG9hZGVyPzogc3RyaW5nO1xuICBsb2FkZXI/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPEltZ1xuICAgICAgZHJhZ2dhYmxlPXtmYWxzZX1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICAgIHNyYz17dXJsfVxuICAgICAga2V5PXt1cmx9XG4gICAgICBhbHQ9e2FsdH1cbiAgICAgIGxvYWRlcj17PFBsYWNlaG9sZGVyIC8+fVxuICAgICAgdW5sb2FkZXI9ezxQbGFjZWhvbGRlciAvPn1cbiAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgIC8+XG4gICk7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBcImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBUTRBQUFEd0NBWUFBQUR4WG9wNEFBQUhQRWxFUVZSNFh1M2QyM0xhMkJhR1VSRU9QcFRmLzBtTndZQ3N2dGhGdG9NZGl4K1d4QklaNDZxcnNqcHh1dHBmTk9YbG1WblhkVjBERVBqVmR3RGdsSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjUVdmUWNvNTNBNC9QN24rWHplekdhekg4OURyWVJqUUYzWE5idmRydG50ZGszYnRsOStmRDZmTjR2Rm9ubDhmQlFSSm1YV2RWM1hkNGpjZnI5djN0N2VtblArODg1bXMrYmg0YUY1Zkh6c093cFZFSTRCYkRhYjV2Mzl2ZS9ZRjh2bHNubCtmdmIwUWZXOEhDM3MwbWcwbjU1U29IYkNVZEIrdjc4NEdrZjcvYjdaYnJkOXgrQ21oS09neldiVGQrUXM3Ky92WjcwYmdWc1Jqa0oydTEzejhmSFJkK3dzWGRkNTZxQnF3bEhJZnIvdk94SXAvZk5CU2NKUlNPbFA5SStQRCtNSzFSS09pbjEzYVF4cUlCd0ZlREw0MCtlcjlkd240U2pBaGEzL2E5dTJXYS9YN3FQY09lRW9aSWg0ek9menZpTlY2YnJ1OXpYNzQvZm9jSitFbzVEbGN0bDNKRExGNzU1ZHI5ZC92SmQ1ZTNzenR0d3A0U2lrZERoV3ExWGZrYXBzTnB0dkk3RmVyNHZkYjZFZXdsSEljcmtzTmxyTVpyTkpoV08zMi8zMXFuM1hkYzE2dmZZQytjNElSMEZQVDA5OVI4N3k5UFEwbVRHbGJkdmVxL2JubkdGYWhLT2d4V0xSUEQ4Lzl4MzcwV3ExbXN6VFJ0ZDF6ZXZyNjFsUEU3dmR6alg2T3lJY2hhMVdxNHZqOGZEd2NQRy9ld3ZuUnVOb3U5MFd2MkhMYlZqa001REQ0ZEJzTnB1emJuLysrdldyZVhwNkt2NkNkVWh2YjI4WGZibDFOcHMxTHk4dnhkNEhjUnZDTWJEZGJ0Y2NEb2Rtdjk5LytkTjV1VncyeStWeU1xUEowVzYzdStxQzEzdytiMTVlWGliekhvZXZoR05rYmR0TytrL2J3K0hRdkw2KzloM3J0VmdzbXBlWGw3NWpWTW83anBGTk9Sb2ZIeC9OZXIzdU8zYVc0eWpITkFrSFp4bmlQc2I3Ky90RjcwbTRQZUdvV01sUDBtdWQrNkkzTmRUUHk3Q0VvMUtsM2lXVXNOMXVCM3N5U082Q1VBL2hxTkR4dTB6YnRyMzVwYWt4dHE0ZjQ4RjBDRWVGdHR2dDcyOE0yMjYzTjN1VWI5djJxaSs3SnNiOHRiaWVjRlRtY0RoOCtZYXhXM3hDZmQ2dE1SWTdQS1pET0NweS9HUTlkWXVSNVhTM3hsanM4SmdHNGFqSTV4SGx1eDhiNnhQNWI3czF4bUtIUi8yRW94TGZqU2lueGhoWmZ0cXRNWlloN294UWxuQlU0RzhqeXFtaFI1YWE5bWJVOUxId2xYQlU0S2NSNWRSUUkwdU45eW5zOEtpWGNOellPU1BLcVhPZVRsSzFSZVBJRG84NkNjY05uVHVpbkNvOXNod3ZtOVdxOW8vdlh5UWNONVNNS0tkS2pTeFR1RHR4aXpzbC9FdzRidVNTRWVYVUpVOHJueDBPaDZ0L2pyRWMvNFk0NmlBY04zRHBpSExxbXBHbDVHNk5zZGpoVVEvaHVJRnJScFJUbDR3c1U3NG5ZWWRISFlSalpDVkdsRlBwMDh2VWQyQk0vZU8vQjhJeG9sSWp5cWxrWkJseXQ4Wllhcnh6OHE4UmpoR1ZIRkZPblRPeWpMRmJZeXgyZU55V2NJeWtiZHZpSThxcG41NW03bkhmeFQzK25xWkNPRVl5eHYvZ2Z4dFo3dmtleEJUdW9kd2o0UmpCT1dORUtkLzlXcmZhclRFV096ekdKeHdEUzE1Y2x2TDU2ZWJXdXpYR1lvZkh1SVJqWUdPTUtLZU9zYXBodDhaWXBudzNaWXI4RlpBRDJtNjNvejl0ZkRhYnpmNjVUNlRWYXRVOFB6LzNIZU5LbmpnR2Nvc1I1ZFMvRm8zR0RvL1JDTWRBYmpHaThEOTJlQXhQT0FZdzVsZFIrSjRkSHNNU2pzSnFHRkc0Nzdzck5SQ093b3dvOWJERFl6akNVWkFScFQ1MmVBeERPQW94b3RUTERvL3loS01RSTByZDdQQW9TemdLTUtMVXp3NlBzb1RqU2thVTZiRERveHpodUpJUlpWcnM4Q2hET0s1Z1JKa21Penl1Snh3WE1xSk1teDBlMXhHT0MzbmNuVDQ3UEM0bkhCY3dvdHdIT3p3dUp4d2hJOHA5YWR2V3pkSUxDRWZJaUhKLzdQRElDVWZBaUhLLzdQRElMUG9POEtmSHg4ZStJMHlVRjZYbnMzTVVpQmxWZ0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSS9RZTBneW9UekVNV1pRQUFBQUJKUlU1RXJrSmdnZz09XCIiLCIvLyBwcm9kdWN0IGNhcmQgZm9yIGdlbmVyYWxcbmltcG9ydCBkeW5hbWljIGZyb20gJ25leHQvZHluYW1pYyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IEltYWdlIGZyb20gJ2NvbXBvbmVudHMvaW1hZ2UvaW1hZ2UnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnY29tcG9uZW50cy9idXR0b24vYnV0dG9uJztcbmltcG9ydCB7XG4gIFByb2R1Y3RDYXJkV3JhcHBlcixcbiAgUHJvZHVjdEltYWdlV3JhcHBlcixcbiAgUHJvZHVjdEluZm8sXG4gIERpc2NvdW50UGVyY2VudCxcbiAgQnV0dG9uVGV4dCxcbn0gZnJvbSAnLi4vcHJvZHVjdC1jYXJkLnN0eWxlJztcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICdjb250ZXh0cy9jYXJ0L3VzZS1jYXJ0JztcbmltcG9ydCB7IENvdW50ZXIgfSBmcm9tICdjb21wb25lbnRzL2NvdW50ZXIvY291bnRlcic7XG5pbXBvcnQgeyBjYXJ0QW5pbWF0aW9uIH0gZnJvbSAndXRpbHMvY2FydC1hbmltYXRpb24nO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuaW1wb3J0IHsgQ2FydEljb24gfSBmcm9tICdhc3NldHMvaWNvbnMvQ2FydEljb24nO1xuaW1wb3J0IHsgdXNlTW9kYWwgfSBmcm9tICdjb250ZXh0cy9tb2RhbC91c2UtbW9kYWwnO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuY29uc3QgUXVpY2tWaWV3TW9iaWxlID0gZHluYW1pYyhcbiAgKCkgPT4gaW1wb3J0KCdmZWF0dXJlcy9xdWljay12aWV3L3F1aWNrLXZpZXctbW9iaWxlJylcbik7XG5cbnR5cGUgUHJvZHVjdENhcmRQcm9wcyA9IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgaW1hZ2U6IGFueTtcbiAgd2VpZ2h0OiBzdHJpbmc7XG4gIGN1cnJlbmN5OiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIHByaWNlOiBudW1iZXI7XG4gIHNhbGVQcmljZT86IG51bWJlcjtcbiAgZGlzY291bnRJblBlcmNlbnQ/OiBudW1iZXI7XG4gIGRhdGE6IGFueTtcbiAgb25DaGFuZ2U/OiAoZTogYW55KSA9PiB2b2lkO1xuICBpbmNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBkZWNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBjYXJ0UHJvZHVjdHM/OiBhbnk7XG4gIGFkZFRvQ2FydD86IGFueTtcbiAgdXBkYXRlQ2FydD86IGFueTtcbiAgdmFsdWU/OiBhbnk7XG4gIGRldmljZVR5cGU/OiBhbnk7XG59O1xuXG5jb25zdCBQcm9kdWN0Q2FyZDogUmVhY3QuRkM8UHJvZHVjdENhcmRQcm9wcz4gPSAoe1xuICB0aXRsZSxcbiAgaW1hZ2UsXG4gIHdlaWdodCxcbiAgcHJpY2UsXG4gIHNhbGVQcmljZSxcbiAgZGlzY291bnRJblBlcmNlbnQsXG4gIGNhcnRQcm9kdWN0cyxcbiAgYWRkVG9DYXJ0LFxuICB1cGRhdGVDYXJ0LFxuICB2YWx1ZSxcbiAgY3VycmVuY3ksXG4gIG9uQ2hhbmdlLFxuICBpbmNyZW1lbnQsXG4gIGRlY3JlbWVudCxcbiAgZGF0YSxcbiAgZGV2aWNlVHlwZSxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IFtzaG93TW9kYWwsIGhpZGVNb2RhbF0gPSB1c2VNb2RhbChcbiAgICAoKSA9PiAoXG4gICAgICA8UXVpY2tWaWV3TW9iaWxlXG4gICAgICAgIG1vZGFsUHJvcHM9e2RhdGF9XG4gICAgICAgIGhpZGVNb2RhbD17aGlkZU1vZGFsfVxuICAgICAgICBkZXZpY2VUeXBlPXtkZXZpY2VUeXBlfVxuICAgICAgLz5cbiAgICApLFxuICAgIHtcbiAgICAgIG9uQ2xvc2U6ICgpID0+IHtcbiAgICAgICAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnksIGFzUGF0aCB9ID0gcm91dGVyO1xuICAgICAgICBjb25zdCBhcyA9IGFzUGF0aDtcbiAgICAgICAgcm91dGVyLnB1c2goXG4gICAgICAgICAge1xuICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFzLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHNoYWxsb3c6IHRydWUsXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfSxcbiAgICB9XG4gICk7XG4gIGNvbnN0IHsgYWRkSXRlbSwgcmVtb3ZlSXRlbSwgZ2V0SXRlbSwgaXNJbkNhcnQgfSA9IHVzZUNhcnQoKTtcbiAgY29uc3QgaGFuZGxlQWRkQ2xpY2sgPSAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgYWRkSXRlbShkYXRhKTtcbiAgICBpZiAoIWlzSW5DYXJ0KGRhdGEuaWQpKSB7XG4gICAgICBjYXJ0QW5pbWF0aW9uKGUpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgaGFuZGxlUmVtb3ZlQ2xpY2sgPSAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgcmVtb3ZlSXRlbShkYXRhKTtcbiAgfTtcbiAgY29uc3QgaGFuZGxlUXVpY2tWaWV3TW9kYWwgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnkgfSA9IHJvdXRlcjtcbiAgICBjb25zdCBhcyA9IGAvcHJvZHVjdC8ke2RhdGEuc2x1Z31gO1xuICAgIGlmIChwYXRobmFtZSA9PT0gJy9wcm9kdWN0L1tzbHVnXScpIHtcbiAgICAgIHJvdXRlci5wdXNoKHBhdGhuYW1lLCBhcyk7XG4gICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzaG93TW9kYWwoKTtcbiAgICByb3V0ZXIucHVzaChcbiAgICAgIHtcbiAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgIHF1ZXJ5LFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgcGF0aG5hbWU6IGFzLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgc2hhbGxvdzogdHJ1ZSxcbiAgICAgIH1cbiAgICApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPFByb2R1Y3RDYXJkV3JhcHBlciBvbkNsaWNrPXtoYW5kbGVRdWlja1ZpZXdNb2RhbH0gY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkXCI+XG4gICAgICA8UHJvZHVjdEltYWdlV3JhcHBlcj5cbiAgICAgICAgPEltYWdlXG4gICAgICAgICAgdXJsPXtpbWFnZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJwcm9kdWN0LWltYWdlXCJcbiAgICAgICAgICBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJyB9fVxuICAgICAgICAgIGFsdD17dGl0bGV9XG4gICAgICAgIC8+XG4gICAgICAgIHtkaXNjb3VudEluUGVyY2VudCA/IChcbiAgICAgICAgICA8RGlzY291bnRQZXJjZW50PntkaXNjb3VudEluUGVyY2VudH0lPC9EaXNjb3VudFBlcmNlbnQ+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9Qcm9kdWN0SW1hZ2VXcmFwcGVyPlxuICAgICAgPFByb2R1Y3RJbmZvPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwicHJvZHVjdC10aXRsZVwiIHN0eWxlPXt7Zm9udFNpemU6JzEuM3JlbSd9fSA+e3RpdGxlfTwvaDM+XG4gICAgICAgIDxwIHN0eWxlPXt7Zm9udFNpemU6JzFyZW0nfX0+TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQgY29uc2VjdGV0dXIgYWRpcGlzaWNpbmcgZWxpdC4gQXV0IHF1aSBzb2x1dGEgbW9sbGl0aWEgY3VtcXVlIGhpYyBlYSw8L3A+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJwcm9kdWN0LXRpdGxlXCIgc3R5bGU9e3tmb250U2l6ZTonMS4xcmVtJyxtYXJnaW5Ub3A6JzVweCd9fSA+XG4gICAgICAgICAge2N1cnJlbmN5fVxuICAgICAgICAgIHtwcmljZX1cbiAgICAgICAgPC9oMz5cbiAgICAgICAgPHA+PC9wPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9kdWN0LXdlaWdodFwiPlxuICAgICAgICAgIHtjdXJyZW5jeX1cbiAgICAgICAgICB7cHJpY2V9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LW1ldGFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3RQcmljZVdyYXBwZXJcIiBzdHlsZT17e2p1c3RpZnlDb250ZW50OlwiY2VudGVyXCJ9fT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm9uaG92ZXJcIiBzdHlsZT17e2ZvbnRTaXplOlwiLjhyZW1cIix0ZXh0QWxpZ246XCJjZW50ZXJcIn19PlxuICAgICAgICAgICAgICAgIExvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZXRldHVyXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZFwiXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9ezEwMH1cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkQ2xpY2t9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICA8QnV0dG9uVGV4dD5cbiAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZSBpZD1cImFkZENhcnRCdXR0b25cIiBkZWZhdWx0TWVzc2FnZT1cIisgQWRkIFRvIENhcnRcIiAvPlxuICAgICAgICAgICAgICA8L0J1dHRvblRleHQ+XG4gICAgICAgICAgICAgXG4gICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgey8qIHtkaXNjb3VudEluUGVyY2VudCA/IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGlzY291bnRlZFByaWNlXCI+XG4gICAgICAgICAgICAgICAge2N1cnJlbmN5fVxuICAgICAgICAgICAgICAgIHtwcmljZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSA6IG51bGx9XG5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj5cbiAgICAgICAgICAgICAge2N1cnJlbmN5fVxuICAgICAgICAgICAgICB7c2FsZVByaWNlID8gc2FsZVByaWNlIDogcHJpY2V9XG4gICAgICAgICAgICA8L3NwYW4+ICovfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIHshaXNJbkNhcnQoZGF0YS5pZCkgPyAoXG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcnQtYnV0dG9uXCJcbiAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1cz17MTAwfVxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRDbGlja31cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENhcnRJY29uIG1yPXsyfSAvPlxuICAgICAgICAgICAgICA8QnV0dG9uVGV4dD5cbiAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZSBpZD1cImFkZENhcnRCdXR0b25cIiBkZWZhdWx0TWVzc2FnZT1cIkNhcnRcIiAvPlxuICAgICAgICAgICAgICA8L0J1dHRvblRleHQ+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPENvdW50ZXJcbiAgICAgICAgICAgICAgdmFsdWU9e2dldEl0ZW0oZGF0YS5pZCkucXVhbnRpdHl9XG4gICAgICAgICAgICAgIG9uRGVjcmVtZW50PXtoYW5kbGVSZW1vdmVDbGlja31cbiAgICAgICAgICAgICAgb25JbmNyZW1lbnQ9e2hhbmRsZUFkZENsaWNrfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYXJkLWNvdW50ZXJcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfSAqL31cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1Byb2R1Y3RJbmZvPlxuICAgIDwvUHJvZHVjdENhcmRXcmFwcGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvZHVjdENhcmQ7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCB7IHRoZW1lR2V0IH0gZnJvbSAnQHN0eWxlZC1zeXN0ZW0vdGhlbWUtZ2V0JztcbmltcG9ydCBjc3MgZnJvbSAnQHN0eWxlZC1zeXN0ZW0vY3NzJztcblxuY29uc3QgU3R5bGVkQm94ID0gc3R5bGVkLmRpdihcbiAgY3NzKHtcbiAgICBweTogWzMwLCA1MF0sXG4gICAgcHg6IFsnMXJlbScsIDBdLFxuICB9KSxcbiAge1xuICAgIHdpZHRoOiAnMTAwJScsXG4gIH1cbik7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0Q2FyZFdyYXBwZXIgPSBzdHlsZWQuZGl2KFxuICBjc3Moe1xuICAgIGhlaWdodDogJzEwMCUnLFxuICAgIHdpZHRoOiAnMTAwJScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnd2hpdGUnLFxuICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgIGZvbnRGYW1pbHk6ICdpbmhlcml0JyxcbiAgICBib3JkZXJSYWRpdXM6ICdiYXNlJyxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAnOmhvdmVyIC5oaWRkJzp7XG4gICAgICBvcGFjaXR5OicxICFpbXBvcnRhbnQnLFxuICAgIH0sXG4gICAgJzpob3ZlciAub25ob3Zlcic6e1xuICAgICAgZGlzcGxheTonbm9uZSAhaW1wb3J0YW50JyxcbiAgICB9LFxuICAgIFxuICAgICcuaGlkZCc6e1xuICAgICAgd2lkdGg6JzEwMCUnLFxuICAgICAgYm9yZGVyUmFkaXVzOicxNXB4JyxcbiAgICAgIHBhZGRpbmc6JzVweCcsXG4gICAgICBiYWNrZ3JvdW5kOicjRjM5QzEyJyxcbiAgICAgIGJvcmRlcjonMHB4IHNvbGlkJyxcbiAgICAgIG1hcmdpblRvcDonNXB4J1xuICAgIH0sXG4gICAgJy5jYXJkLWNvdW50ZXInOiB7XG4gICAgICAnQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSc6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uLXJldmVyc2UnLFxuICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgYm90dG9tOiAwLFxuICAgICAgICByaWdodDogMCxcbiAgICAgIH0sXG4gICAgfSxcbiAgXG4gICAgXG4gICAgIFxuICAgIFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RJbWFnZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDI0MHB4O1xuICBwYWRkaW5nOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBvdmVyZmxvdzpoaWRkZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBpbWcge1xuICAgIG1heC13aWR0aDogMTcwJTtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNjQwcHgpIHtcbiAgICBoZWlnaHQ6IDE0NXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgU2FsZVRhZyA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5yZWd1bGFyJywgJyNGRkFENUUnKX07XG4gIHBhZGRpbmc6IDAgMTBweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLm1lZGl1bScsICcxMnB4Jyl9O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICByaWdodDogMTBweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBEaXNjb3VudFBlcmNlbnQgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LnJlZ3VsYXInLCAnI0ZGQUQ1RScpfTtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE1cHg7XG4gIHJpZ2h0OiAxNXB4O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5tZWRpdW0nLCAnMTJweCcpfTtcbiAgei1pbmRleDogMjtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mbyA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDIwcHggMjVweCAzMHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgIHBhZGRpbmc6IDE1cHggMjBweDtcbiAgICBtaW4taGVpZ2h0OiAxMjNweDtcbiAgfVxuICAucHJvZHVjdC10aXRsZSB7XG4gICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gICAgbWFyZ2luOiAwIDAgN3B4IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbWFyZ2luOiAwIDAgNXB4IDA7XG4gICAgfVxuICB9XG4gIC5wcm9kdWN0LXdlaWdodCB7XG4gICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQucmVndWxhcicsICcjNzc3OThjJyl9O1xuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMueHMnLCAnMTInKX1weDtcbiAgICB9XG4gIH1cbiAgLnByb2R1Y3QtbWV0YSB7XG4gICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgbWluLWhlaWdodDogMzZweDtcbiAgICB9XG4gICAgLnByb2R1Y3RQcmljZVdyYXBwZXIge1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIHdpZHRoOjEwMCU7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAgICAuaGlkZHtcbiAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjMDAwJyl9O1xuICAgICAgICBvcGFjaXR5OjA7XG4gICAgICAgIC5idG4tdGV4dCB7XG4gICAgICAgICAgcGFkZGluZzogMCAwIDAgNnB4O1xuICAgICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjMDAwJyl9O1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgICBib3JkZXItY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLnByb2R1Y3QtcHJpY2Uge1xuICAgICAgICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICAgICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICAgICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAuZGlzY291bnRlZFByaWNlIHtcbiAgICAgICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgICAgICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICAgICAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgICAgIHBhZGRpbmc6IDAgNXB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAtMjBweDtcbiAgICAgICAgbGVmdDogLTRweDtcbiAgICAgICAgJjpiZWZvcmUge1xuICAgICAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIGhlaWdodDogMXB4O1xuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LmhvdmVyJywgJyNGQkI5NzknKX07XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIFxuICAgIH1cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgIC5xdWFudGl0eSB7XG4gICAgICAgIHdpZHRoOiAzMnB4O1xuICAgICAgICBoZWlnaHQ6IDkwcHg7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBmbGV4LXNocmluazogMDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBib3R0b206IDE1cHg7XG4gICAgICAgIHJpZ2h0OiAxNXB4O1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBib3gtc2hhZG93OiAwIDEwcHggMjBweCByZ2JhKDAsIDAsIDAsIDAuMTYpO1xuICAgICAgfVxuICAgICAgYnV0dG9uIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMjdweDtcbiAgICAgIH1cbiAgICAgIC5pbmNCdG4ge1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgfVxuICAgICAgLmRlY0J0biB7XG4gICAgICAgIHRvcDogYXV0bztcbiAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIH1cbiAgICAgIGlucHV0W3R5cGU9J251bWJlciddIHtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDU0cHgpO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogMjdweDtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCdXR0b25UZXh0ID0gc3R5bGVkLnNwYW5gXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCb29rSW1hZ2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAyNzVweDtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICBpbWcge1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBoZWlnaHQ6IDIxNXB4O1xuICB9XG4gICR7RGlzY291bnRQZXJjZW50fSB7XG4gICAgdG9wOiAwO1xuICAgIHJpZ2h0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQm9va0luZm8gPSBzdHlsZWQuZGl2YFxuICBwYWRkaW5nOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMTVweCAwcHggMHB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdE5hbWUgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gIG1hcmdpbjogMCAwIDdweCAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogYmxvY2s7XG4gICY6b25seS1jaGlsZCB7XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGZvbnQtc2l6ZTogY2FsYygke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4IC0gMXB4KTtcbiAgICBtYXJnaW46IDAgMCA1cHggMDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEF1dGhvckluZm8gPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQucmVndWxhcicsICcjNzc3OThjJyl9O1xuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICB9XG5gO1xuXG4vLyBleHBvcnQgY29uc3QgQWRkQ2FydEJveCA9IHN0eWxlZC5kaXZgXG4vLyAgIHdpZHRoOiBjYWxjKDEwMCUgLSA0MHB4KTtcbi8vICAgZGlzcGxheTogZmxleDtcbi8vICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbi8vICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbi8vICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4vLyAgIHBhZGRpbmc6IDIwcHg7XG4vLyAgIGJvcmRlci1yYWRpdXM6IDZweDtcbi8vICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbi8vICAgYm94LXNoYWRvdzogMCAxMHB4IDIwcHggcmdiYSgwLCAwLCAwLCAwLjE2KTtcbi8vICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICB0b3A6IDUwJTtcbi8vICAgbGVmdDogNTAlO1xuLy8gICBvcGFjaXR5OiAwO1xuLy8gICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcblxuLy8gICAuY2FydC1idXR0b24ge1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDE4cHg7XG4vLyAgICAgaGVpZ2h0OiAzNnB4O1xuLy8gICAgIHBhZGRpbmctbGVmdDogMTdweDtcbi8vICAgICBwYWRkaW5nLXJpZ2h0OiAxN3B4O1xuLy8gICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLjEnLCAnMTMnKX0gcHg7XG4vLyAgICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuLy8gICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuLy8gICAgICAgd2lkdGg6IDMycHg7XG4vLyAgICAgICBoZWlnaHQ6IDMycHg7XG4vLyAgICAgICBwYWRkaW5nOiAwO1xuLy8gICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuLy8gICAgIH1cbi8vICAgICAuYnRuLXRleHQge1xuLy8gICAgICAgcGFkZGluZzogMCAwIDAgNnB4O1xuLy8gICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4vLyAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4vLyAgICAgICB9XG4vLyAgICAgfVxuLy8gICAgICY6aG92ZXIge1xuLy8gICAgICAgY29sb3I6ICNmZmY7XG4vLyAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4vLyAgICAgICBib3JkZXItY29sb3I6ICNGMzlDMTI7XG4vLyAgICAgfVxuLy8gICAgIHN2ZyB7XG4vLyAgICAgICBmaWxsOiBjdXJyZW50Q29sb3I7XG4vLyAgICAgfVxuLy8gICB9XG4vLyBgO1xuXG5leHBvcnQgY29uc3QgUHJpY2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcmljZSA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgRGlzY291bnRlZFByaWNlID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9IHB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LnJlZ3VsYXInLCAnI0ZGQUQ1RScpfTtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBwYWRkaW5nOiAwIDVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiAtNHB4O1xuICB6LWluZGV4OiAyO1xuICAmOmJlZm9yZSB7XG4gICAgY29udGVudDogJyc7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxcHg7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cucmVndWxhcicsICcjRkZBRDVFJyl9O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDUwJTtcbiAgICBsZWZ0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQm9va0NhcmRXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMzBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMTVweDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEZvb2RDYXJkV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5gO1xuXG5leHBvcnQgY29uc3QgRm9vZEltYWdlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMjMwcHg7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZmxleC1zaHJpbms6IDA7XG4gIGltZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICB9XG4gICY6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6ICcnO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgei1pbmRleDogMTtcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBoZWlnaHQ6IDE0NXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdE1ldGEgPSBzdHlsZWQuZGl2YFxuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5gO1xuXG5leHBvcnQgY29uc3QgRGVsaXZlcnlPcHQgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQuYm9sZCcsICcjMEQxMTM2Jyl9O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuYDtcblxuZXhwb3J0IGNvbnN0IENhdGVnb3J5ID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBEdXJhdGlvbiA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5iaWcnLCAnMThweCcpfTtcbiAgcGFkZGluZy10b3A6IDA7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XG4gIGhlaWdodDogMzZweDtcbiAgd2lkdGg6IGF1dG87XG4gIGJvcmRlcjogMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDYwMHB4KSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIH1cbmA7XG4iLCIvLyBleHBvcnQgY29uc3QgY2FydEl0ZW1zVG90YWxQcmljZSA9IChpdGVtcywgeyBkaXNjb3VudEluUGVyY2VudCA9IDAgfSA9IHt9KSA9PiB7XG5leHBvcnQgY29uc3QgY2FydEl0ZW1zVG90YWxQcmljZSA9IChpdGVtcywgY291cG9uID0gbnVsbCkgPT4ge1xuICBpZiAoaXRlbXMgPT09IG51bGwgfHwgaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgY29uc3QgaXRlbUNvc3QgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0uc2FsZVByaWNlKSB7XG4gICAgICByZXR1cm4gdG90YWwgKyBpdGVtLnNhbGVQcmljZSAqIGl0ZW0ucXVhbnRpdHk7XG4gICAgfVxuICAgIHJldHVybiB0b3RhbCArIGl0ZW0ucHJpY2UgKiBpdGVtLnF1YW50aXR5O1xuICB9LCAwKTtcbiAgLy8gY29uc3QgZGlzY291bnRSYXRlID0gMSAtIGRpc2NvdW50SW5QZXJjZW50O1xuICBjb25zdCBkaXNjb3VudCA9IGNvdXBvblxuICAgID8gKGl0ZW1Db3N0ICogTnVtYmVyKGNvdXBvbi5kaXNjb3VudEluUGVyY2VudCkpIC8gMTAwXG4gICAgOiAwO1xuICAvLyBpdGVtQ29zdCAqIGRpc2NvdW50UmF0ZSAqIFRBWF9SQVRFICsgc2hpcHBpbmc7XG4gIC8vIHJldHVybiBpdGVtQ29zdCAqIGRpc2NvdW50UmF0ZTtcbiAgcmV0dXJuIGl0ZW1Db3N0IC0gZGlzY291bnQ7XG59O1xuLy8gY2FydEl0ZW1zLCBjYXJ0SXRlbVRvQWRkXG5jb25zdCBhZGRJdGVtVG9DYXJ0ID0gKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgY29uc3QgZXhpc3RpbmdDYXJ0SXRlbUluZGV4ID0gc3RhdGUuaXRlbXMuZmluZEluZGV4KFxuICAgIChpdGVtKSA9PiBpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZC5pZFxuICApO1xuXG4gIGlmIChleGlzdGluZ0NhcnRJdGVtSW5kZXggPiAtMSkge1xuICAgIGNvbnN0IG5ld1N0YXRlID0gWy4uLnN0YXRlLml0ZW1zXTtcbiAgICBuZXdTdGF0ZVtleGlzdGluZ0NhcnRJdGVtSW5kZXhdLnF1YW50aXR5ICs9IGFjdGlvbi5wYXlsb2FkLnF1YW50aXR5O1xuICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgfVxuICByZXR1cm4gWy4uLnN0YXRlLml0ZW1zLCBhY3Rpb24ucGF5bG9hZF07XG59O1xuXG4vLyBjYXJ0SXRlbXMsIGNhcnRJdGVtVG9SZW1vdmVcbmNvbnN0IHJlbW92ZUl0ZW1Gcm9tQ2FydCA9IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gIHJldHVybiBzdGF0ZS5pdGVtcy5yZWR1Y2UoKGFjYywgaXRlbSkgPT4ge1xuICAgIGlmIChpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZC5pZCkge1xuICAgICAgY29uc3QgbmV3UXVhbnRpdHkgPSBpdGVtLnF1YW50aXR5IC0gYWN0aW9uLnBheWxvYWQucXVhbnRpdHk7XG5cbiAgICAgIHJldHVybiBuZXdRdWFudGl0eSA+IDBcbiAgICAgICAgPyBbLi4uYWNjLCB7IC4uLml0ZW0sIHF1YW50aXR5OiBuZXdRdWFudGl0eSB9XVxuICAgICAgICA6IFsuLi5hY2NdO1xuICAgIH1cbiAgICByZXR1cm4gWy4uLmFjYywgaXRlbV07XG4gIH0sIFtdKTtcbn07XG5cbmNvbnN0IGNsZWFySXRlbUZyb21DYXJ0ID0gKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgcmV0dXJuIHN0YXRlLml0ZW1zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gYWN0aW9uLnBheWxvYWQuaWQpO1xufTtcblxuZXhwb3J0IGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgY2FzZSAnUkVIWURSQVRFJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCAuLi5hY3Rpb24ucGF5bG9hZCB9O1xuICAgIGNhc2UgJ1RPR0dMRV9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpc09wZW46ICFzdGF0ZS5pc09wZW4gfTtcbiAgICBjYXNlICdBRERfSVRFTSc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXRlbXM6IGFkZEl0ZW1Ub0NhcnQoc3RhdGUsIGFjdGlvbikgfTtcbiAgICBjYXNlICdSRU1PVkVfSVRFTSc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXRlbXM6IHJlbW92ZUl0ZW1Gcm9tQ2FydChzdGF0ZSwgYWN0aW9uKSB9O1xuICAgIGNhc2UgJ0NMRUFSX0lURU1fRlJPTV9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogY2xlYXJJdGVtRnJvbUNhcnQoc3RhdGUsIGFjdGlvbikgfTtcbiAgICBjYXNlICdDTEVBUl9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogW10gfTtcbiAgICBjYXNlICdBUFBMWV9DT1VQT04nOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGNvdXBvbjogYWN0aW9uLnBheWxvYWQgfTtcbiAgICBjYXNlICdSRU1PVkVfQ09VUE9OJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjb3Vwb246IG51bGwgfTtcbiAgICBjYXNlICdUT0dHTEVfUkVTVEFVUkFOVCc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXNSZXN0YXVyYW50OiAhc3RhdGUuaXNSZXN0YXVyYW50IH07XG4gICAgZGVmYXVsdDpcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3Rpb246ICR7YWN0aW9uLnR5cGV9YCk7XG4gIH1cbn07XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlUmVkdWNlciwgdXNlQ29udGV4dCwgY3JlYXRlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHJlZHVjZXIsIGNhcnRJdGVtc1RvdGFsUHJpY2UgfSBmcm9tICcuL2NhcnQucmVkdWNlcic7XG5pbXBvcnQgeyB1c2VTdG9yYWdlIH0gZnJvbSAndXRpbHMvdXNlLXN0b3JhZ2UnO1xuY29uc3QgQ2FydENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9IGFzIGFueSk7XG5jb25zdCBJTklUSUFMX1NUQVRFID0ge1xuICBpc09wZW46IGZhbHNlLFxuICBpdGVtczogW10sXG4gIGlzUmVzdGF1cmFudDogZmFsc2UsXG4gIGNvdXBvbjogbnVsbCxcbn07XG5cbmNvbnN0IHVzZUNhcnRBY3Rpb25zID0gKGluaXRpYWxDYXJ0ID0gSU5JVElBTF9TVEFURSkgPT4ge1xuICBjb25zdCBbc3RhdGUsIGRpc3BhdGNoXSA9IHVzZVJlZHVjZXIocmVkdWNlciwgaW5pdGlhbENhcnQpO1xuXG4gIGNvbnN0IGFkZEl0ZW1IYW5kbGVyID0gKGl0ZW0sIHF1YW50aXR5ID0gMSkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ0FERF9JVEVNJywgcGF5bG9hZDogeyAuLi5pdGVtLCBxdWFudGl0eSB9IH0pO1xuICB9O1xuXG4gIGNvbnN0IHJlbW92ZUl0ZW1IYW5kbGVyID0gKGl0ZW0sIHF1YW50aXR5ID0gMSkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1JFTU9WRV9JVEVNJywgcGF5bG9hZDogeyAuLi5pdGVtLCBxdWFudGl0eSB9IH0pO1xuICB9O1xuXG4gIGNvbnN0IGNsZWFySXRlbUZyb21DYXJ0SGFuZGxlciA9IChpdGVtKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnQ0xFQVJfSVRFTV9GUk9NX0NBUlQnLCBwYXlsb2FkOiBpdGVtIH0pO1xuICB9O1xuXG4gIGNvbnN0IGNsZWFyQ2FydEhhbmRsZXIgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnQ0xFQVJfQ0FSVCcgfSk7XG4gIH07XG4gIGNvbnN0IHRvZ2dsZUNhcnRIYW5kbGVyID0gKCkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1RPR0dMRV9DQVJUJyB9KTtcbiAgfTtcbiAgY29uc3QgY291cG9uSGFuZGxlciA9IChjb3Vwb24pID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdBUFBMWV9DT1VQT04nLCBwYXlsb2FkOiBjb3Vwb24gfSk7XG4gIH07XG4gIGNvbnN0IHJlbW92ZUNvdXBvbkhhbmRsZXIgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnUkVNT1ZFX0NPVVBPTicgfSk7XG4gIH07XG4gIGNvbnN0IHJlaHlkcmF0ZUxvY2FsU3RhdGUgPSAocGF5bG9hZCkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1JFSFlEUkFURScsIHBheWxvYWQgfSk7XG4gIH07XG4gIGNvbnN0IHRvZ2dsZVJlc3RhdXJhbnQgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnVE9HR0xFX1JFU1RBVVJBTlQnIH0pO1xuICB9O1xuICBjb25zdCBpc0luQ2FydEhhbmRsZXIgPSAoaWQpID0+IHtcbiAgICByZXR1cm4gc3RhdGUuaXRlbXM/LnNvbWUoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGlkKTtcbiAgfTtcbiAgY29uc3QgZ2V0SXRlbUhhbmRsZXIgPSAoaWQpID0+IHtcbiAgICByZXR1cm4gc3RhdGUuaXRlbXM/LmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGlkKTtcbiAgfTtcbiAgY29uc3QgZ2V0Q2FydEl0ZW1zUHJpY2UgPSAoKSA9PiBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zKS50b0ZpeGVkKDIpO1xuICBjb25zdCBnZXRDYXJ0SXRlbXNUb3RhbFByaWNlID0gKCkgPT5cbiAgICBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zLCBzdGF0ZS5jb3Vwb24pLnRvRml4ZWQoMik7XG5cbiAgY29uc3QgZ2V0RGlzY291bnQgPSAoKSA9PiB7XG4gICAgY29uc3QgdG90YWwgPSBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zKTtcbiAgICBjb25zdCBkaXNjb3VudCA9IHN0YXRlLmNvdXBvblxuICAgICAgPyAodG90YWwgKiBOdW1iZXIoc3RhdGUuY291cG9uPy5kaXNjb3VudEluUGVyY2VudCkpIC8gMTAwXG4gICAgICA6IDA7XG4gICAgcmV0dXJuIGRpc2NvdW50LnRvRml4ZWQoMik7XG4gIH07XG4gIGNvbnN0IGdldEl0ZW1zQ291bnQgPSBzdGF0ZS5pdGVtcz8ucmVkdWNlKFxuICAgIChhY2MsIGl0ZW0pID0+IGFjYyArIGl0ZW0ucXVhbnRpdHksXG4gICAgMFxuICApO1xuICByZXR1cm4ge1xuICAgIHN0YXRlLFxuICAgIGdldEl0ZW1zQ291bnQsXG4gICAgcmVoeWRyYXRlTG9jYWxTdGF0ZSxcbiAgICBhZGRJdGVtSGFuZGxlcixcbiAgICByZW1vdmVJdGVtSGFuZGxlcixcbiAgICBjbGVhckl0ZW1Gcm9tQ2FydEhhbmRsZXIsXG4gICAgY2xlYXJDYXJ0SGFuZGxlcixcbiAgICBpc0luQ2FydEhhbmRsZXIsXG4gICAgZ2V0SXRlbUhhbmRsZXIsXG4gICAgdG9nZ2xlQ2FydEhhbmRsZXIsXG4gICAgZ2V0Q2FydEl0ZW1zVG90YWxQcmljZSxcbiAgICBnZXRDYXJ0SXRlbXNQcmljZSxcbiAgICBjb3Vwb25IYW5kbGVyLFxuICAgIHJlbW92ZUNvdXBvbkhhbmRsZXIsXG4gICAgZ2V0RGlzY291bnQsXG4gICAgdG9nZ2xlUmVzdGF1cmFudCxcbiAgfTtcbn07XG5cbmV4cG9ydCBjb25zdCBDYXJ0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IHtcbiAgICBzdGF0ZSxcbiAgICByZWh5ZHJhdGVMb2NhbFN0YXRlLFxuICAgIGdldEl0ZW1zQ291bnQsXG4gICAgYWRkSXRlbUhhbmRsZXIsXG4gICAgcmVtb3ZlSXRlbUhhbmRsZXIsXG4gICAgY2xlYXJJdGVtRnJvbUNhcnRIYW5kbGVyLFxuICAgIGNsZWFyQ2FydEhhbmRsZXIsXG4gICAgaXNJbkNhcnRIYW5kbGVyLFxuICAgIGdldEl0ZW1IYW5kbGVyLFxuICAgIHRvZ2dsZUNhcnRIYW5kbGVyLFxuICAgIGdldENhcnRJdGVtc1RvdGFsUHJpY2UsXG4gICAgY291cG9uSGFuZGxlcixcbiAgICByZW1vdmVDb3Vwb25IYW5kbGVyLFxuICAgIGdldENhcnRJdGVtc1ByaWNlLFxuICAgIGdldERpc2NvdW50LFxuICAgIHRvZ2dsZVJlc3RhdXJhbnQsXG4gIH0gPSB1c2VDYXJ0QWN0aW9ucygpO1xuICBjb25zdCB7IHJlaHlkcmF0ZWQsIGVycm9yIH0gPSB1c2VTdG9yYWdlKHN0YXRlLCByZWh5ZHJhdGVMb2NhbFN0YXRlKTtcblxuICByZXR1cm4gKFxuICAgIDxDYXJ0Q29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgaXNPcGVuOiBzdGF0ZS5pc09wZW4sXG4gICAgICAgIGl0ZW1zOiBzdGF0ZS5pdGVtcyxcbiAgICAgICAgY291cG9uOiBzdGF0ZS5jb3Vwb24sXG4gICAgICAgIGlzUmVzdGF1cmFudDogc3RhdGUuaXNSZXN0YXVyYW50LFxuICAgICAgICBjYXJ0SXRlbXNDb3VudDogc3RhdGUuaXRlbXM/Lmxlbmd0aCxcbiAgICAgICAgaXRlbXNDb3VudDogZ2V0SXRlbXNDb3VudCxcbiAgICAgICAgYWRkSXRlbTogYWRkSXRlbUhhbmRsZXIsXG4gICAgICAgIHJlbW92ZUl0ZW06IHJlbW92ZUl0ZW1IYW5kbGVyLFxuICAgICAgICByZW1vdmVJdGVtRnJvbUNhcnQ6IGNsZWFySXRlbUZyb21DYXJ0SGFuZGxlcixcbiAgICAgICAgY2xlYXJDYXJ0OiBjbGVhckNhcnRIYW5kbGVyLFxuICAgICAgICBpc0luQ2FydDogaXNJbkNhcnRIYW5kbGVyLFxuICAgICAgICBnZXRJdGVtOiBnZXRJdGVtSGFuZGxlcixcbiAgICAgICAgdG9nZ2xlQ2FydDogdG9nZ2xlQ2FydEhhbmRsZXIsXG4gICAgICAgIGNhbGN1bGF0ZVByaWNlOiBnZXRDYXJ0SXRlbXNUb3RhbFByaWNlLFxuICAgICAgICBjYWxjdWxhdGVTdWJUb3RhbFByaWNlOiBnZXRDYXJ0SXRlbXNQcmljZSxcbiAgICAgICAgYXBwbHlDb3Vwb246IGNvdXBvbkhhbmRsZXIsXG4gICAgICAgIHJlbW92ZUNvdXBvbjogcmVtb3ZlQ291cG9uSGFuZGxlcixcbiAgICAgICAgY2FsY3VsYXRlRGlzY291bnQ6IGdldERpc2NvdW50LFxuICAgICAgICB0b2dnbGVSZXN0YXVyYW50LFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9DYXJ0Q29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCB1c2VDYXJ0ID0gKCkgPT4gdXNlQ29udGV4dChDYXJ0Q29udGV4dCk7XG4iLCJpbXBvcnQgeyB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1vZGFsQ29udGV4dCwgTW9kYWxUeXBlIH0gZnJvbSAnLi9tb2RhbC5jb250ZXh0JztcblxuLyoqXG4gKiBDYWxsYmFjayB0eXBlcyBwcm92aWRlZCBmb3IgZGVzY3JpcHRpdmUgdHlwZS1oaW50c1xuICovXG50eXBlIFNob3dNb2RhbCA9ICgpID0+IHZvaWQ7XG50eXBlIEhpZGVNb2RhbCA9ICgpID0+IHZvaWQ7XG5cbi8qKlxuICogVXRpbGl0eSBmdW5jdGlvbiB0byBnZW5lcmF0ZSB1bmlxdWUgbnVtYmVyIHBlciBjb21wb25lbnQgaW5zdGFuY2VcbiAqL1xuY29uc3QgZ2VuZXJhdGVNb2RhbEtleSA9ICgoKSA9PiB7XG4gIGxldCBjb3VudCA9IDA7XG5cbiAgcmV0dXJuICgpID0+IGAkeysrY291bnR9YDtcbn0pKCk7XG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgYXJndW1lbnQgaXMgYSBzdGF0ZWxlc3MgY29tcG9uZW50LlxuICpcbiAqIFdlIHRha2UgYWR2YW50YWdlIG9mIHRoZSBzdGF0ZWxlc3MgbmF0dXJlIG9mIGZ1bmN0aW9uYWwgY29tcG9uZW50cyB0byBiZVxuICogaW5saW5lIHRoZSByZW5kZXJpbmcgb2YgdGhlIG1vZGFsIGNvbXBvbmVudCBhcyBwYXJ0IG9mIGFub3RoZXIgaW1tdXRhYmxlXG4gKiBjb21wb25lbnQuXG4gKlxuICogVGhpcyBpcyBuZWNlc3NhcnkgZm9yIGFsbG93aW5nIHRoZSBtb2RhbCB0byB1cGRhdGUgYmFzZWQgb24gdGhlIGlucHV0cyBwYXNzZWRcbiAqIGFzIHRoZSBzZWNvbmQgYXJndW1lbnQgdG8gdXNlTW9kYWwgd2l0aG91dCB1bm1vdW50aW5nIHRoZSBwcmV2aW91cyB2ZXJzaW9uIG9mXG4gKiB0aGUgbW9kYWwgY29tcG9uZW50LlxuICovXG5jb25zdCBpc0Z1bmN0aW9uYWxDb21wb25lbnQgPSAoQ29tcG9uZW50OiBGdW5jdGlvbikgPT4ge1xuICBjb25zdCBwcm90b3R5cGUgPSBDb21wb25lbnQucHJvdG90eXBlO1xuXG4gIHJldHVybiAhcHJvdG90eXBlIHx8ICFwcm90b3R5cGUuaXNSZWFjdENvbXBvbmVudDtcbn07XG5cbi8qKlxuICogUmVhY3QgaG9vayBmb3Igc2hvd2luZyBtb2RhbCB3aW5kb3dzXG4gKi9cbmV4cG9ydCBjb25zdCB1c2VNb2RhbCA9IChcbiAgY29tcG9uZW50OiBNb2RhbFR5cGUsXG4gIG9wdGlvbnM6IGFueSA9IHt9XG4pOiBbU2hvd01vZGFsLCBIaWRlTW9kYWxdID0+IHtcbiAgaWYgKCFpc0Z1bmN0aW9uYWxDb21wb25lbnQoY29tcG9uZW50KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdPbmx5IHN0YXRlbGVzcyBjb21wb25lbnRzIGNhbiBiZSB1c2VkIGFzIGFuIGFyZ3VtZW50IHRvIHVzZU1vZGFsLiBZb3UgaGF2ZSBwcm9iYWJseSBwYXNzZWQgYSBjbGFzcyBjb21wb25lbnQgd2hlcmUgYSBmdW5jdGlvbiB3YXMgZXhwZWN0ZWQuJ1xuICAgICk7XG4gIH1cblxuICBjb25zdCBrZXkgPSB1c2VNZW1vKGdlbmVyYXRlTW9kYWxLZXksIFtdKTtcbiAgY29uc3QgbW9kYWwgPSB1c2VNZW1vKCgpID0+IGNvbXBvbmVudCwgb3B0aW9ucy5pbnB1dHMpO1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChNb2RhbENvbnRleHQpO1xuICBjb25zdCBzaG93TW9kYWwgPSB1c2VDYWxsYmFjaygoKSA9PiBjb250ZXh0LnNob3dNb2RhbChrZXksIG1vZGFsLCBvcHRpb25zKSwgW1xuICAgIGNvbnRleHQuc2hvd01vZGFsLFxuICBdKTtcbiAgY29uc3QgaGlkZU1vZGFsID0gdXNlQ2FsbGJhY2soKCkgPT4gY29udGV4dC5oaWRlTW9kYWwoa2V5KSwgW1xuICAgIGNvbnRleHQuaGlkZU1vZGFsLFxuICAgIGtleSxcbiAgXSk7XG4gIC8vIGNvbnN0IFtpc1Nob3duLCBzZXRTaG93bl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIC8vIGNvbnN0IHNob3dNb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFNob3duKHRydWUpLCBbXSk7XG4gIC8vIGNvbnN0IGhpZGVNb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFNob3duKGZhbHNlKSwgW10pO1xuXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XG4gIC8vICAgaWYgKGlzU2hvd24pIHtcbiAgLy8gICAgIGNvbnRleHQuc2hvd01vZGFsKGtleSwgbW9kYWwpO1xuICAvLyAgIH0gZWxzZSB7XG4gIC8vICAgICBjb250ZXh0LmhpZGVNb2RhbChrZXkpO1xuICAvLyAgIH1cblxuICAvLyAgIC8vIEhpZGUgbW9kYWwgd2hlbiBwYXJlbnQgY29tcG9uZW50IHVubW91bnRzXG4gIC8vICAgcmV0dXJuICgpID0+IGNvbnRleHQuaGlkZU1vZGFsKGtleSk7XG4gIC8vIH0sIFttb2RhbCwgaXNTaG93bl0pO1xuXG4gIHJldHVybiBbc2hvd01vZGFsLCBoaWRlTW9kYWxdO1xufTtcblxuLy8gZXhwb3J0IGRlZmF1bHQgdXNlTW9kYWw7XG5cbi8vLyB1c2VzXG4vLyBpbXBvcnQgdXNlTW9kYWwgZnJvbSBcInVzZS1tb2RhbFwiO1xuLy8gaW1wb3J0IE1vZGFsUHJvdmlkZXIgZnJvbSBcIm1vZGFsLnByb3ZpZGVyXCI7XG4vLyBpbXBvcnQgTW9kYWwgZnJvbSBcInJlYWN0LW1vZGFsXCI7IC8vIEl0IGNhbiBiZSBhbnkgbW9kYWxcblxuLy8gY29uc3QgTXlNb2RhbCA9IG1lbW8oXG4vLyAgICh7IGlzT3Blbiwgb25DbG9zZSwgdGl0bGUsIGRlc2NyaXB0aW9uLCBjbG9zZUJ0bkxhYmVsIH0pID0+IChcbi8vICAgICA8TW9kYWwgaXNPcGVuPXtpc09wZW59IG9uUmVxdWVzdENsb3NlPXtvbkNsb3NlfT5cbi8vICAgICAgIDxoMj57dGl0bGV9PC9oMj5cbi8vICAgICAgIDxkaXY+e2Rlc2NyaXB0aW9ufTwvZGl2PlxuLy8gICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsb3NlfT57Y2xvc2VCdG5MYWJlbH08L2J1dHRvbj5cbi8vICAgICA8L01vZGFsPlxuLy8gICApXG4vLyApO1xuXG4vLyBjb25zdCBTb21lUGFnZSA9IG1lbW8oKCkgPT4ge1xuLy8gICBjb25zdCBbc2hvd01vZGFsLCBoaWRlTW9kYWxdID0gdXNlTW9kYWwoTXlNb2RhbCwge1xuLy8gICAgIHRpdGxlOiBcIk15IFRlc3QgTW9kYWxcIixcbi8vICAgICBkZXNjcmlwdGlvbjogXCJJIExpa2UgUmVhY3QgSG9va3NcIixcbi8vICAgICBjbG9zZUJ0bkxhYmVsOiBcIkNsb3NlXCJcbi8vICAgfSk7XG5cbi8vICAgcmV0dXJuIChcbi8vICAgICA8PlxuLy8gICAgICAgPGgxPlRlc3QgUGFnZTwvaDE+XG4vLyAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3Nob3dNb2RhbH0+U2hvdyBNb2RhbDwvYnV0dG9uPlxuLy8gICAgIDwvPlxuLy8gICApO1xuLy8gfSk7XG5cbi8vIGNvbnN0IEFwcCA9ICgpID0+IChcbi8vICAgPE1vZGFsUHJvdmlkZXI+XG4vLyAgICAgPFNvbWVQYWdlIC8+XG4vLyAgIDwvTW9kYWxQcm92aWRlcj5cbi8vICk7XG5cbi8vIHVzZU1vZGFsKDxNb2RhbENvbXBvbmVudDogRnVuY3Rpb258PiwgPG1vZGFsUHJvcHM6IE9iamVjdD4sIDxvbkNsb3NlOiBGdW5jdGlvbj4pOiBbc2hvd01vZGFsOiBGdW5jdGlvbiwgaGlkZU1vZGFsOiBGdW5jdGlvbl1cbi8vIFBhcmFtXHRUeXBlXHREZXNjcmlwdGlvblxuLy8gTW9kYWxDb21wb25lbnRcdEZ1bmN0aW9uXHRJdCBjYW4gYmUgYW55IHJlYWN0IGNvbXBvbmVudCB0aGF0IHlvdSB3YW50IHRvIHVzZSBmb3Igc2hvdyBtb2RhbFxuLy8gbW9kYWxQcm9wc1x0T2JqZWN0XHRQcm9wcyB0aGF0IHlvdSB3YW50IHRvIHBhc3MgdG8geW91ciBtb2RhbCBjb21wb25lbnRcbi8vIHNob3dNb2RhbFx0RnVuY3Rpb25cdEl0IGlzIGZ1bmN0aW9uIGZvciBzaG93IHlvdXIgbW9kYWwsIHlvdSBjYW4gcGFzcyBhbnkgZHluYW1pYyBwcm9wcyB0byB0aGlzIGZ1bmN0aW9uXG4vLyBoaWRlTW9kYWxcdEZ1bmN0aW9uXHRJdCBpcyBmdW5jdGlvbiBmb3IgaGlkZSB5b3VyIG1vZGFsLCB5b3UgY2FuIHBhc3MgYW55IGR5bmFtaWMgcHJvcHMgdG8gdGhpcyBmdW5jdGlvblxuLy8gb25DbG9zZVx0RnVuY3Rpb25cdEl0IGNhbGxiYWNrIHdpbGwgYmUgdHJpZ2dlcmVkIGFmdGVyIG1vZGFsIHdpbmRvdyBjbG9zZXNcbi8vIHNob3dNb2RhbChkeW5hbWljTW9kYWxQcm9wczogT2JqZWN0KVxuLy8gUGFyYW1cdFR5cGVcdERlc2NyaXB0aW9uXG4vLyBkeW5hbWljTW9kYWxQcm9wc1x0T2JqZWN0XHREeW5hbWljIHByb3BzIHRoYXQgeW91IHdhbnQgdG8gcGFzcyB0byB5b3VyIG1vZGFsIGNvbXBvbmVudFxuIiwiZXhwb3J0IGNvbnN0IGNhcnRBbmltYXRpb24gPSAoZXZlbnQpID0+IHtcbiAgY29uc3QgZ2V0Q2xvc2VzdCA9IGZ1bmN0aW9uIChlbGVtLCBzZWxlY3Rvcikge1xuICAgIGZvciAoOyBlbGVtICYmIGVsZW0gIT09IGRvY3VtZW50OyBlbGVtID0gZWxlbS5wYXJlbnROb2RlKSB7XG4gICAgICBpZiAoZWxlbS5tYXRjaGVzKHNlbGVjdG9yKSkgcmV0dXJuIGVsZW07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9O1xuXG4gIC8vIHN0YXJ0IGFuaW1hdGlvbiBibG9ja1xuICBsZXQgaW1nVG9EcmFnID0gZ2V0Q2xvc2VzdChldmVudC50YXJnZXQsICcucHJvZHVjdC1jYXJkJyk7XG4gIGxldCB2aWV3Q2FydCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ3Byb2R1Y3QtY2FydCcpWzBdO1xuICBsZXQgaW1nVG9EcmFnSW1hZ2UgPSBpbWdUb0RyYWcucXVlcnlTZWxlY3RvcignLnByb2R1Y3QtaW1hZ2UnKTtcblxuICBsZXQgZGlzTGVmdCA9IGltZ1RvRHJhZy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0O1xuICBsZXQgZGlzVG9wID0gaW1nVG9EcmFnLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnRvcDtcbiAgbGV0IGNhcnRMZWZ0ID0gdmlld0NhcnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdDtcbiAgbGV0IGNhcnRUb3AgPSB2aWV3Q2FydC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3A7XG4gIGxldCBpbWFnZSA9IGltZ1RvRHJhZ0ltYWdlLmNsb25lTm9kZSh0cnVlKTtcbiAgaW1hZ2Uuc3R5bGUgPVxuICAgICd6LWluZGV4OiAxMTExMTsgd2lkdGg6IDEwMHB4O29wYWNpdHk6MTsgcG9zaXRpb246Zml4ZWQ7IHRvcDonICtcbiAgICBkaXNUb3AgK1xuICAgICdweDtsZWZ0OicgK1xuICAgIGRpc0xlZnQgK1xuICAgICdweDt0cmFuc2l0aW9uOiBsZWZ0IDFzLCB0b3AgMXMsIHdpZHRoIDFzLCBvcGFjaXR5IDFzIGN1YmljLWJlemllcigxLCAxLCAxLCAxKTtib3JkZXItcmFkaXVzOiA1MHB4OyBvdmVyZmxvdzogaGlkZGVuOyBib3gtc2hhZG93OiAwIDIxcHggMzZweCByZ2JhKDAsMCwwLDAuMSknO1xuICB2YXIgcmVDaGFuZ2UgPSBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGltYWdlKTtcbiAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgaW1hZ2Uuc3R5bGUubGVmdCA9IGNhcnRMZWZ0ICsgJ3B4JztcbiAgICBpbWFnZS5zdHlsZS50b3AgPSBjYXJ0VG9wICsgJ3B4JztcbiAgICBpbWFnZS5zdHlsZS53aWR0aCA9ICc0MHB4JztcbiAgICBpbWFnZS5zdHlsZS5vcGFjaXR5ID0gJzAnO1xuICB9LCAyMDApO1xuICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICByZUNoYW5nZS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHJlQ2hhbmdlKTtcbiAgfSwgMTAwMCk7XG4gIC8vIEVuZCBBbmltYXRpb24gQmxvY2tcbn07XG4iLCJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGxvY2FsRm9yYWdlIGZyb20gJ2xvY2FsZm9yYWdlJztcbmNvbnN0IGlzT2JqZWN0TGlrZWQgPSAodmFsdWUpID0+XG4gIHZhbHVlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdBcnJheScgfHwgdmFsdWUuY29uc3RydWN0b3IubmFtZSA9PT0gJ09iamVjdCc7XG5cbmNvbnN0IHJlaHlkcmF0ZSA9ICh2YWx1ZTogYW55LCBkZWZhdWx0VmFsdWU/OiBhbnkpID0+IHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgLy8gaWYgKHZhbHVlID09PSAnZmFsc2UnKSBzdHIgPSBmYWxzZTtcbiAgLy8gaWYgKHZhbHVlID09PSAndHJ1ZScpIHN0ciA9IHRydWU7XG4gIC8vIGlmICghaXNPYmplY3RMaWtlZCh2YWx1ZSkpIHtcbiAgLy8gICByZXR1cm4gdmFsdWU7XG4gIC8vIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZSA9IEpTT04ucGFyc2UodmFsdWUpO1xuICAgIHJldHVybiBwYXJzZTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgfVxufTtcblxuY29uc3QgaHlkcmF0ZSA9ICh2YWx1ZSkgPT4ge1xuICBpZiAoIWlzT2JqZWN0TGlrZWQodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG59O1xuY29uc3QgY3JlYXRlTWlncmF0aW9uID0gKG9wdHMsIGRhdGEpID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBrZXkgPSBgJHtvcHRzLmtleX0tdmVyc2lvbmA7XG4gICAgbG9jYWxGb3JhZ2UuZ2V0SXRlbShrZXksIChlcnIsIHZlcnNpb24pID0+IHtcbiAgICAgIGlmICh2ZXJzaW9uICE9PSBvcHRzLnZlcnNpb24pIHtcbiAgICAgICAgZGF0YSA9IG9wdHMubWlncmF0ZShkYXRhKTtcbiAgICAgICAgbG9jYWxGb3JhZ2Uuc2V0SXRlbShvcHRzLmtleSwgcmVoeWRyYXRlKGRhdGEpLCAoZXJyKSA9PiB7XG4gICAgICAgICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgICAgICAgIGxvY2FsRm9yYWdlLnNldEl0ZW0oa2V5LCBvcHRzLnZlcnNpb24sIChlcnIpID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICAgIHJldHVybiByZXNvbHZlKGRhdGEpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmUoZGF0YSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xufTtcblxuY29uc3QgY29uZmlnID0ge1xuICBrZXk6ICdAc2Vzc2lvbicsXG4gIHZlcnNpb246IDEsXG4gIG1pZ3JhdGU6IChzdGF0ZSkgPT4ge1xuICAgIHJldHVybiB7IC4uLnN0YXRlIH07XG4gIH0sXG59O1xuXG5leHBvcnQgY29uc3QgdXNlU3RvcmFnZSA9IChzdGF0ZSwgc2V0U3RhdGUpID0+IHtcbiAgY29uc3QgW3JlaHlkcmF0ZWQsIHNldFJlaHlkcmF0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgIGF3YWl0IGxvY2FsRm9yYWdlLmdldEl0ZW0oY29uZmlnLmtleSwgKGVyciwgdmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIHNldFJlaHlkcmF0ZWQodHJ1ZSk7XG4gICAgICAgICAgcmV0dXJuIHNldEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gTWlncmF0ZSBwZXJzaXN0ZWQgZGF0YVxuICAgICAgICBjb25zdCByZXN0b3JlZFZhbHVlID0gcmVoeWRyYXRlKHZhbHVlKTtcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcubWlncmF0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIGNyZWF0ZU1pZ3JhdGlvbihjb25maWcsIHJlc3RvcmVkVmFsdWUpXG4gICAgICAgICAgICAudGhlbigoZGF0YSkgPT4gc2V0U3RhdGUoZGF0YSkpXG4gICAgICAgICAgICAudGhlbigoKSA9PiBzZXRSZWh5ZHJhdGVkKHRydWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRTdGF0ZShyZXN0b3JlZFZhbHVlKTtcbiAgICAgICAgICBzZXRSZWh5ZHJhdGVkKHRydWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgaW5pdCgpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBpZiAoaXNOaWwoc3RhdGUpIHx8IGlzRW1wdHkoc3RhdGUpKSB7XG4gICAgLy8gICBsb2NhbEZvcmFnZS5yZW1vdmVJdGVtKGNvbmZpZy5rZXkpO1xuICAgIC8vIH1cbiAgICBsb2NhbEZvcmFnZS5zZXRJdGVtKGNvbmZpZy5rZXksIGh5ZHJhdGUoc3RhdGUpKTtcbiAgfSwgW3N0YXRlXSk7XG5cbiAgcmV0dXJuIHtcbiAgICByZWh5ZHJhdGVkLFxuICAgIGVycm9yLFxuICB9O1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=