exports.ids = [12];
exports.modules = {

/***/ "./src/components/button/loadmore-button.tsx":
/*!***************************************************!*\
  !*** ./src/components/button/loadmore-button.tsx ***!
  \***************************************************/
/*! exports provided: StyledButton, Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StyledButton", function() { return StyledButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\button\\loadmore-button.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const StyledButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.div.withConfig({
  displayName: "loadmore-button__StyledButton",
  componentId: "defczs-0"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default()({
  px: '15px',
  py: 0,
  fontSize: ['base'],
  fontWeight: 'bold',
  cursor: props.disabled ? 'not-allowed' : 'pointer',
  color: props.disabled ? 'text.light' : 'white',
  bg: props.disabled ? 'gray.500' : 'primary.regular',
  transition: 'all 0.3s ease',
  borderRadius: 'base',
  '&:hover': {
    color: props.disabled ? 'text.light' : 'white',
    bg: props.disabled ? 'gray.500' : 'primary.hover'
  }
}), {
  appearance: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flexShrink: 0,
  textAlign: 'center',
  height: '38px',
  textDecoration: 'none',
  fontFamily: 'inherit',
  border: 0,
  '&:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["variant"])({
  variants: {
    outlined: {
      color: 'primary.regular',
      bg: 'white',
      border: '1px solid',
      borderColor: 'gray.500',
      '&:hover': {
        borderColor: 'primary.regular',
        color: 'primary.regular',
        bg: 'white'
      }
    },
    primary: {
      color: 'white',
      bg: 'primary.regular',
      '&:hover': {
        bg: 'primary.hover'
      }
    },
    secondary: {
      color: 'primary.regular',
      bg: 'white',
      border: '2px solid',
      borderColor: 'gray.500',
      '&:hover': {
        color: 'white',
        bg: 'primary.regular',
        borderColor: 'primary.regular'
      }
    },
    text: {
      color: 'primary.regular',
      bg: 'transparent',
      '&:hover': {
        bg: 'transparent',
        color: 'primary.hover'
      }
    },
    select: {
      width: 26,
      height: 26,
      lineHeight: 1,
      flexShrink: 0,
      border: '1px solid',
      borderColor: 'text.regular',
      borderRadius: 13,
      padding: 0,
      color: 'text.bold',
      bg: 'transparent',
      '&.selected': {
        bg: 'primary.regular',
        color: 'white',
        borderColor: 'primary.regular'
      },
      '&:hover:not(.selected)': {
        bg: 'transparent',
        color: 'primary.regular',
        borderColor: 'primary.regular'
      }
    }
  }
}), Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["variant"])({
  prop: 'size',
  variants: {
    big: {
      height: '48px',
      px: 30
    },
    small: {
      height: '30px',
      fontSize: 14
    }
  }
}), Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["compose"])(styled_system__WEBPACK_IMPORTED_MODULE_4__["border"], styled_system__WEBPACK_IMPORTED_MODULE_4__["space"], styled_system__WEBPACK_IMPORTED_MODULE_4__["layout"]));
const rotate = Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["keyframes"])(["from{transform:rotate(0deg);}to{transform:rotate(360deg);}"]);
const Spinner = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.div.withConfig({
  displayName: "loadmore-button__Spinner",
  componentId: "defczs-1"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default()({
  width: 18,
  height: 18,
  marginLeft: 10,
  border: '3px solid white',
  borderTop: `3px solid ${props.color ? props.color : 'primary.regular'}`,
  borderRadius: '50%',
  transitionProperty: 'transform'
}), Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["css"])(["animation:", " 1.2s infinite linear;"], rotate));
const Button = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.forwardRef((_ref, ref) => {
  let {
    children,
    disabled,
    loading = false
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "disabled", "loading"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(StyledButton, _objectSpread(_objectSpread({
    ref: ref
  }, props), {}, {
    disabled: disabled,
    role: "button",
    children: [children, loading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Spinner, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 151,
      columnNumber: 19
    }, undefined)]
  }), void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 149,
    columnNumber: 5
  }, undefined);
});

/***/ }),

/***/ "./src/components/no-result/no-result.style.tsx":
/*!******************************************************!*\
  !*** ./src/components/no-result/no-result.style.tsx ***!
  \******************************************************/
/*! exports provided: NoResultWrapper, ImageWrapper, ButtonWrapper, Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoResultWrapper", function() { return NoResultWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageWrapper", function() { return ImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const NoResultWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "no-resultstyle__NoResultWrapper",
  componentId: "ny7l1y-0"
})(["width:100%;display:flex;flex-direction:column;align-items:center;padding:50px 20px;h3{font-size:", "px;font-weight:", ";color:", ";margin:0 0 15px;}p{font-size:calc(", "px + 1px);font-weight:", ";color:", ";margin:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xl', '24'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798C'));
const ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "no-resultstyle__ImageWrapper",
  componentId: "ny7l1y-1"
})(["margin-top:50px;width:100%;max-width:600px;display:flex;align-items:center;justify-content:center;img{max-width:100%;}"]);
const ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "no-resultstyle__ButtonWrapper",
  componentId: "ny7l1y-2"
})(["width:100%;display:flex;justify-content:center;margin-top:70px;"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "no-resultstyle__Button",
  componentId: "ny7l1y-3"
})(["cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:", ";background-color:", ";height:50px;border-radius:", ";font-family:", ";font-size:calc(", "px + 1px);font-weight:", ";text-decoration:none;text-transform:capitalize;padding:0 30px;border:0;transition:all 0.3s ease;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'));

/***/ }),

/***/ "./src/components/no-result/no-result.svg":
/*!************************************************!*\
  !*** ./src/components/no-result/no-result.svg ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/no-result-81838a48ea52c12f67fffac82b8b1087.svg";

/***/ }),

/***/ "./src/components/no-result/no-result.tsx":
/*!************************************************!*\
  !*** ./src/components/no-result/no-result.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _no_result_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./no-result.svg */ "./src/components/no-result/no-result.svg");
/* harmony import */ var _no_result_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_no_result_svg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _no_result_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./no-result.style */ "./src/components/no-result/no-result.style.tsx");
/* harmony import */ var assets_icons_ArrowPrev__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! assets/icons/ArrowPrev */ "./src/assets/icons/ArrowPrev.tsx");
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_7__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\no-result\\no-result.tsx";





 // import { SearchContext } from 'contexts/search/search.context';



const NoResultFound = ({
  id
}) => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])(); // const { dispatch } = React.useContext(SearchContext);

  function onClickButton() {
    // dispatch({
    //   type: 'RESET',
    // });
    const href = router.pathname;
    router.push(href, href, {
      shallow: true
    });
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_no_result_style__WEBPACK_IMPORTED_MODULE_4__["NoResultWrapper"], {
    id: id,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_7__["FormattedMessage"], {
        id: "noResultFound",
        defaultMessage: "Sorry, No result found :("
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_no_result_style__WEBPACK_IMPORTED_MODULE_4__["ImageWrapper"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: _no_result_svg__WEBPACK_IMPORTED_MODULE_3___default.a,
        alt: "No Result"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_no_result_style__WEBPACK_IMPORTED_MODULE_4__["ButtonWrapper"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        onClick: onClickButton,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_6__["Button"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_ArrowPrev__WEBPACK_IMPORTED_MODULE_5__["ArrowPrev"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, undefined), " Go Back"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 31,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (NoResultFound);

/***/ }),

/***/ "./src/components/placeholder/placeholder.tsx":
/*!****************************************************!*\
  !*** ./src/components/placeholder/placeholder.tsx ***!
  \****************************************************/
/*! exports provided: SidebarMobileLoader, SidebarLoader, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarMobileLoader", function() { return SidebarMobileLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarLoader", function() { return SidebarLoader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-content-loader */ "react-content-loader");
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\placeholder\\placeholder.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const PostLoader = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({
  height: 350,
  width: 245,
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb"
}, props), {}, {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "2",
    y: "2",
    rx: "0",
    ry: "0",
    width: "240",
    height: "197"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "220",
    rx: "0",
    ry: "0",
    width: "140",
    height: "25"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "254",
    rx: "0",
    ry: "0",
    width: "65",
    height: "15"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "300",
    rx: "0",
    ry: "0",
    width: "67",
    height: "20"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "170",
    y: "300",
    rx: "0",
    ry: "0",
    width: "60",
    height: "20"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, undefined)]
}), void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 5,
  columnNumber: 3
}, undefined);

const SidebarMobileLoader = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, {
  height: 46,
  width: 400,
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "58",
    y: "10",
    rx: "0",
    ry: "0",
    width: "287",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "364",
    y: "10",
    rx: "0",
    ry: "0",
    width: "26",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "16",
    y: "10",
    rx: "0",
    ry: "0",
    width: "26",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, undefined)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 21,
  columnNumber: 3
}, undefined);
const SidebarLoader = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({
  height: 400,
  width: "calc(100% - 30px)",
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb"
}, props), {}, {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "376",
    y: "22",
    rx: "0",
    ry: "0",
    width: "0",
    height: "0"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "50",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 44,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "50",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "89",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 47,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "89",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "128",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "128",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "167",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "167",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 54,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "206",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 56,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "206",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 57,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "245",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "245",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 60,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "284",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 62,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "284",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "323",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 65,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "323",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 66,
    columnNumber: 5
  }, undefined)]
}), void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 35,
  columnNumber: 3
}, undefined);
/* harmony default export */ __webpack_exports__["default"] = (PostLoader);

/***/ }),

/***/ "./src/components/product-grid/product-list/product-list.style.tsx":
/*!*************************************************************************!*\
  !*** ./src/components/product-grid/product-list/product-list.style.tsx ***!
  \*************************************************************************/
/*! exports provided: ProductsRow, ButtonWrapper, NoResult, LoaderWrapper, LoaderItem, ProductCardWrapper, ProductsCol, MedicineCol */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsRow", function() { return ProductsRow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonWrapper", function() { return ButtonWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoResult", function() { return NoResult; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderWrapper", function() { return LoaderWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderItem", function() { return LoaderItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardWrapper", function() { return ProductCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsCol", function() { return ProductsCol; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MedicineCol", function() { return MedicineCol; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const ProductsRow = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__ProductsRow",
  componentId: "sc-1xqoa71-0"
})(["display:flex;justify-content:center;flex-wrap:wrap;margin-top:25px;background-color:", ";position:relative;z-index:1;margin:0 -15px;@media (max-width:990px){margin-left:0px;margin-right:0px;margin-top:0;background-color:", ";}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.200', '#f7f7f7'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const ButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__ButtonWrapper",
  componentId: "sc-1xqoa71-1"
})(["display:flex;justify-content:center;margin-top:30px;"]);
const NoResult = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__NoResult",
  componentId: "sc-1xqoa71-2"
})(["width:100%;padding:100px 30px;display:flex;justify-content:center;align-items:center;font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const LoaderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__LoaderWrapper",
  componentId: "sc-1xqoa71-3"
})(["width:100%;height:100vh;display:flex;flex-wrap:wrap;"]);
const LoaderItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__LoaderItem",
  componentId: "sc-1xqoa71-4"
})(["width:25%;padding:0 15px;margin-bottom:30px;svg{width:100%;}"]);
const ProductCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__ProductCardWrapper",
  componentId: "sc-1xqoa71-5"
})(["height:100%;> div{height:100%;}"]);
const ProductsCol = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__ProductsCol",
  componentId: "sc-1xqoa71-6"
})(["flex:0 0 20%;max-width:16%;padding-left:15px;padding-right:15px;margin-bottom:30px;.book-card{border-radius:0;}&.food-col{flex:0 0 25%;max-width:16%;}@media (min-width:1501px){&:nth-child(5n + 1){.book-card{border-radius:6px 0 0 6px;}}&:nth-child(5n){.book-card{border-radius:0 6px 6px 0;}}}@media (min-width:1301px) and (max-width:1500px){flex:0 0 19%;max-width:25%;&.food-col{flex:0 0 33.333%;max-width:33.333%;}&:nth-child(4n + 1){.book-card{border-radius:6px 0 0 6px;}}&:nth-child(4n){.book-card{border-radius:0 6px 6px 0;}}}@media (min-width:768px) and (max-width:1300px){flex:0 0 33.3333333%;max-width:33.3333333%;&.food-col{flex:0 0 33.3333333%;max-width:33.3333333%;padding-left:7.5px;padding-right:7.5px;margin-bottom:15px;border:0;", "{border:1px solid #f1f1f1;}}&:nth-child(3n + 1){.book-card{border-radius:6px 0 0 6px;}}&:nth-child(3n){.book-card{border-radius:0 6px 6px 0;}}}@media (max-width:1199px) and (min-width:991px){padding-left:10px;padding-right:10px;margin-bottom:20px;&.food-col{flex:0 0 50%;max-width:50%;}}@media (max-width:990px){padding-left:0;padding-right:0;margin-bottom:-1px;margin-right:-1px;border:1px solid #f1f1f1;}@media (max-width:767px){flex:0 0 50%;max-width:50%;&.food-col{flex:0 0 50%;max-width:50%;}&:nth-child(2n + 1){.book-card{border-radius:6px 0 0 6px;}}&:nth-child(2n){.book-card{border-radius:0 6px 6px 0;}}}"], ProductCardWrapper);
const MedicineCol = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-liststyle__MedicineCol",
  componentId: "sc-1xqoa71-7"
})(["flex:0 0 20%;max-width:20%;padding-left:15px;padding-right:15px;margin-bottom:30px;@media (max-width:1300px){flex:0 0 25%;max-width:25%;padding-left:10px;padding-right:10px;}@media (max-width:1099px) and (min-width:1025px){flex:0 0 33.333%;max-width:33.333%;}@media (max-width:767px){flex:0 0 33.333%;max-width:33.333%;padding-left:10px;padding-right:10px;margin-bottom:30px;}@media (max-width:560px){flex:0 0 50%;max-width:50%;padding-left:7.5px;padding-right:7.5px;margin-bottom:20px;}"]);

/***/ }),

/***/ "./src/components/product-grid/product-list/product-list.tsx":
/*!*******************************************************************!*\
  !*** ./src/components/product-grid/product-list/product-list.tsx ***!
  \*******************************************************************/
/*! exports provided: Products, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Products", function() { return Products; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _product_list_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./product-list.style */ "./src/components/product-grid/product-list/product-list.style.tsx");
/* harmony import */ var utils_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! utils/constant */ "./src/utils/constant.ts");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/placeholder/placeholder */ "./src/components/placeholder/placeholder.tsx");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-reveal/Fade */ "react-reveal/Fade");
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var components_no_result_no_result__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/no-result/no-result */ "./src/components/no-result/no-result.tsx");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var components_button_loadmore_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/button/loadmore-button */ "./src/components/button/loadmore-button.tsx");
/* harmony import */ var graphql_query_products_query__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! graphql/query/products.query */ "./src/graphql/query/products.query.ts");


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\product-grid\\product-list\\product-list.tsx";












const ErrorMessage = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(() => __webpack_require__.e(/*! import() */ 16).then(__webpack_require__.bind(null, /*! components/error-message/error-message */ "./src/components/error-message/error-message.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! components/error-message/error-message */ "./src/components/error-message/error-message.tsx")],
    modules: ['components/error-message/error-message']
  }
});
const GeneralCard = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(() => __webpack_require__.e(/*! import() */ 11).then(__webpack_require__.bind(null, /*! components/product-card/product-card-one/product-card-one */ "./src/components/product-card/product-card-one/product-card-one.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! components/product-card/product-card-one/product-card-one */ "./src/components/product-card/product-card-one/product-card-one.tsx")],
    modules: ['components/product-card/product-card-one/product-card-one']
  }
});
const BookCard = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(() => __webpack_require__.e(/*! import() */ 14).then(__webpack_require__.bind(null, /*! components/product-card/product-card-two/product-card-two */ "./src/components/product-card/product-card-two/product-card-two.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! components/product-card/product-card-two/product-card-two */ "./src/components/product-card/product-card-two/product-card-two.tsx")],
    modules: ['components/product-card/product-card-two/product-card-two']
  }
});
const FurnitureCard = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(() => __webpack_require__.e(/*! import() */ 13).then(__webpack_require__.bind(null, /*! components/product-card/product-card-three/product-card-three */ "./src/components/product-card/product-card-three/product-card-three.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! components/product-card/product-card-three/product-card-three */ "./src/components/product-card/product-card-three/product-card-three.tsx")],
    modules: ['components/product-card/product-card-three/product-card-three']
  }
});
const MedicineCard = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(() => __webpack_require__.e(/*! import() */ 9).then(__webpack_require__.bind(null, /*! components/product-card/product-card-five/product-card-five */ "./src/components/product-card/product-card-five/product-card-five.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! components/product-card/product-card-five/product-card-five */ "./src/components/product-card/product-card-five/product-card-five.tsx")],
    modules: ['components/product-card/product-card-five/product-card-five']
  }
});
const Products = ({
  deviceType,
  fetchLimit = 18,
  loadMore = true,
  type
}) => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  const {
    data,
    error,
    loading,
    fetchMore,
    networkStatus
  } = Object(_apollo_client__WEBPACK_IMPORTED_MODULE_6__["useQuery"])(graphql_query_products_query__WEBPACK_IMPORTED_MODULE_12__["GET_PRODUCTS"], {
    variables: {
      type: type,
      text: router.query.text,
      category: router.query.category,
      offset: 0,
      limit: fetchLimit
    },
    notifyOnNetworkStatusChange: true
  });
  const loadingMore = networkStatus === _apollo_client__WEBPACK_IMPORTED_MODULE_6__["NetworkStatus"].fetchMore;
  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(ErrorMessage, {
    message: error.message
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 70,
    columnNumber: 21
  }, undefined);

  if (loading && !loadingMore) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["LoaderWrapper"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["LoaderItem"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_7__["default"], {
          uniqueKey: "1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["LoaderItem"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_7__["default"], {
          uniqueKey: "2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["LoaderItem"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_7__["default"], {
          uniqueKey: "3"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, undefined);
  }

  if (!data || !data.products || data.products.items.length === 0) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_no_result_no_result__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 88,
      columnNumber: 12
    }, undefined);
  }

  const handleLoadMore = () => {
    fetchMore({
      variables: {
        offset: Number(data.products.items.length),
        limit: fetchLimit
      }
    });
  };

  const renderCard = (productType, props) => {
    var _props$author;

    switch (productType) {
      case 'book':
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BookCard, {
          title: props.title,
          image: props.image,
          name: props === null || props === void 0 ? void 0 : (_props$author = props.author) === null || _props$author === void 0 ? void 0 : _props$author.name,
          data: props,
          deviceType: deviceType,
          onClick: () => {
            router.push('/product/[slug]', `/product/${props.slug}`);

            if (false) {}
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 103,
          columnNumber: 11
        }, undefined);

      case 'medicine':
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(MedicineCard, {
          title: props.title,
          currency: utils_constant__WEBPACK_IMPORTED_MODULE_5__["CURRENCY"],
          image: props.image,
          price: props.price,
          weight: props.unit,
          data: props
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 119,
          columnNumber: 11
        }, undefined);

      case 'furniture':
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(FurnitureCard, {
          title: props.title,
          image: props.gallery[0].url,
          discountInPercent: props.discountInPercent,
          data: props,
          deviceType: deviceType
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 130,
          columnNumber: 11
        }, undefined);

      default:
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(GeneralCard, {
          title: props.title,
          description: props.description,
          image: props.image,
          weight: props.unit,
          currency: utils_constant__WEBPACK_IMPORTED_MODULE_5__["CURRENCY"],
          price: props.price,
          salePrice: props.salePrice,
          discountInPercent: props.discountInPercent,
          data: props,
          deviceType: deviceType
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 140,
          columnNumber: 11
        }, undefined);
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["ProductsRow"], {
      children: data.products.items.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["ProductsCol"], {
        style: type === 'grocery' ? {
          paddingLeft: 0,
          paddingRight: 1,
          marginRight: 6
        } : {},
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["ProductCardWrapper"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_8___default.a, {
            duration: 800,
            delay: index * 10,
            style: {
              height: '100%'
            },
            children: renderCard(type, item)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 164,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 163,
          columnNumber: 13
        }, undefined)
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 11
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 157,
      columnNumber: 7
    }, undefined), loadMore && data.products.hasMore && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_list_style__WEBPACK_IMPORTED_MODULE_4__["ButtonWrapper"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_loadmore_button__WEBPACK_IMPORTED_MODULE_11__["Button"], {
        onClick: handleLoadMore,
        loading: loadingMore,
        variant: "secondary",
        style: {
          fontSize: 14
        },
        border: "1px solid #f1f1f1",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_10__["FormattedMessage"], {
          id: "loadMoreButton",
          defaultMessage: "Load More"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 186,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 176,
      columnNumber: 9
    }, undefined)]
  }, void 0, true);
};
/* harmony default export */ __webpack_exports__["default"] = (Products);

/***/ }),

/***/ "./src/utils/constant.ts":
/*!*******************************!*\
  !*** ./src/utils/constant.ts ***!
  \*******************************/
/*! exports provided: CURRENCY */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CURRENCY", function() { return CURRENCY; });
/************ CONSTANTS ***********/
const CURRENCY = '$';

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9idXR0b24vbG9hZG1vcmUtYnV0dG9uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9uby1yZXN1bHQvbm8tcmVzdWx0LnN0eWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9uby1yZXN1bHQvbm8tcmVzdWx0LnN2ZyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9uby1yZXN1bHQvbm8tcmVzdWx0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wbGFjZWhvbGRlci9wbGFjZWhvbGRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1ncmlkL3Byb2R1Y3QtbGlzdC9wcm9kdWN0LWxpc3Quc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3Byb2R1Y3QtZ3JpZC9wcm9kdWN0LWxpc3QvcHJvZHVjdC1saXN0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvY29uc3RhbnQudHMiXSwibmFtZXMiOlsiU3R5bGVkQnV0dG9uIiwic3R5bGVkIiwiZGl2IiwicHJvcHMiLCJzeXN0ZW1Dc3MiLCJweCIsInB5IiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiY3Vyc29yIiwiZGlzYWJsZWQiLCJjb2xvciIsImJnIiwidHJhbnNpdGlvbiIsImJvcmRlclJhZGl1cyIsImFwcGVhcmFuY2UiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZmxleFNocmluayIsInRleHRBbGlnbiIsImhlaWdodCIsInRleHREZWNvcmF0aW9uIiwiZm9udEZhbWlseSIsImJvcmRlciIsIm91dGxpbmUiLCJ2YXJpYW50IiwidmFyaWFudHMiLCJvdXRsaW5lZCIsImJvcmRlckNvbG9yIiwicHJpbWFyeSIsInNlY29uZGFyeSIsInRleHQiLCJzZWxlY3QiLCJ3aWR0aCIsImxpbmVIZWlnaHQiLCJwYWRkaW5nIiwicHJvcCIsImJpZyIsInNtYWxsIiwiY29tcG9zZSIsInNwYWNlIiwibGF5b3V0Iiwicm90YXRlIiwia2V5ZnJhbWVzIiwiU3Bpbm5lciIsIm1hcmdpbkxlZnQiLCJib3JkZXJUb3AiLCJ0cmFuc2l0aW9uUHJvcGVydHkiLCJjc3MiLCJCdXR0b24iLCJSZWFjdCIsImZvcndhcmRSZWYiLCJyZWYiLCJjaGlsZHJlbiIsImxvYWRpbmciLCJOb1Jlc3VsdFdyYXBwZXIiLCJ0aGVtZUdldCIsIkltYWdlV3JhcHBlciIsIkJ1dHRvbldyYXBwZXIiLCJidXR0b24iLCJOb1Jlc3VsdEZvdW5kIiwiaWQiLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJvbkNsaWNrQnV0dG9uIiwiaHJlZiIsInBhdGhuYW1lIiwicHVzaCIsInNoYWxsb3ciLCJOb1Jlc3VsdFN2ZyIsIlBvc3RMb2FkZXIiLCJTaWRlYmFyTW9iaWxlTG9hZGVyIiwiU2lkZWJhckxvYWRlciIsIlByb2R1Y3RzUm93IiwiTm9SZXN1bHQiLCJMb2FkZXJXcmFwcGVyIiwiTG9hZGVySXRlbSIsIlByb2R1Y3RDYXJkV3JhcHBlciIsIlByb2R1Y3RzQ29sIiwiTWVkaWNpbmVDb2wiLCJFcnJvck1lc3NhZ2UiLCJkeW5hbWljIiwiR2VuZXJhbENhcmQiLCJCb29rQ2FyZCIsIkZ1cm5pdHVyZUNhcmQiLCJNZWRpY2luZUNhcmQiLCJQcm9kdWN0cyIsImRldmljZVR5cGUiLCJmZXRjaExpbWl0IiwibG9hZE1vcmUiLCJ0eXBlIiwiZGF0YSIsImVycm9yIiwiZmV0Y2hNb3JlIiwibmV0d29ya1N0YXR1cyIsInVzZVF1ZXJ5IiwiR0VUX1BST0RVQ1RTIiwidmFyaWFibGVzIiwicXVlcnkiLCJjYXRlZ29yeSIsIm9mZnNldCIsImxpbWl0Iiwibm90aWZ5T25OZXR3b3JrU3RhdHVzQ2hhbmdlIiwibG9hZGluZ01vcmUiLCJOZXR3b3JrU3RhdHVzIiwibWVzc2FnZSIsInByb2R1Y3RzIiwiaXRlbXMiLCJsZW5ndGgiLCJoYW5kbGVMb2FkTW9yZSIsIk51bWJlciIsInJlbmRlckNhcmQiLCJwcm9kdWN0VHlwZSIsInRpdGxlIiwiaW1hZ2UiLCJhdXRob3IiLCJuYW1lIiwic2x1ZyIsIkNVUlJFTkNZIiwicHJpY2UiLCJ1bml0IiwiZ2FsbGVyeSIsInVybCIsImRpc2NvdW50SW5QZXJjZW50IiwiZGVzY3JpcHRpb24iLCJzYWxlUHJpY2UiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJwYWRkaW5nTGVmdCIsInBhZGRpbmdSaWdodCIsIm1hcmdpblJpZ2h0IiwiaGFzTW9yZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTUEsWUFBWSxHQUFHQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3RCQyxLQUFELElBQ0VDLHlEQUFTLENBQUM7QUFDUkMsSUFBRSxFQUFFLE1BREk7QUFFUkMsSUFBRSxFQUFFLENBRkk7QUFHUkMsVUFBUSxFQUFFLENBQUMsTUFBRCxDQUhGO0FBSVJDLFlBQVUsRUFBRSxNQUpKO0FBS1JDLFFBQU0sRUFBRU4sS0FBSyxDQUFDTyxRQUFOLEdBQWlCLGFBQWpCLEdBQWlDLFNBTGpDO0FBTVJDLE9BQUssRUFBRVIsS0FBSyxDQUFDTyxRQUFOLEdBQWlCLFlBQWpCLEdBQWdDLE9BTi9CO0FBT1JFLElBQUUsRUFBRVQsS0FBSyxDQUFDTyxRQUFOLEdBQWlCLFVBQWpCLEdBQThCLGlCQVAxQjtBQVFSRyxZQUFVLEVBQUUsZUFSSjtBQVNSQyxjQUFZLEVBQUUsTUFUTjtBQVdSLGFBQVc7QUFDVEgsU0FBSyxFQUFFUixLQUFLLENBQUNPLFFBQU4sR0FBaUIsWUFBakIsR0FBZ0MsT0FEOUI7QUFFVEUsTUFBRSxFQUFFVCxLQUFLLENBQUNPLFFBQU4sR0FBaUIsVUFBakIsR0FBOEI7QUFGekI7QUFYSCxDQUFELENBRlksRUFrQnZCO0FBQ0VLLFlBQVUsRUFBRSxNQURkO0FBRUVDLFNBQU8sRUFBRSxNQUZYO0FBR0VDLFlBQVUsRUFBRSxRQUhkO0FBSUVDLGdCQUFjLEVBQUUsUUFKbEI7QUFLRUMsWUFBVSxFQUFFLENBTGQ7QUFNRUMsV0FBUyxFQUFFLFFBTmI7QUFPRUMsUUFBTSxFQUFFLE1BUFY7QUFRRUMsZ0JBQWMsRUFBRSxNQVJsQjtBQVNFQyxZQUFVLEVBQUUsU0FUZDtBQVVFQyxRQUFNLEVBQUUsQ0FWVjtBQVlFLGFBQVc7QUFDVEMsV0FBTyxFQUFFO0FBREE7QUFaYixDQWxCdUIsRUFrQ3ZCQyw2REFBTyxDQUFDO0FBQ05DLFVBQVEsRUFBRTtBQUNSQyxZQUFRLEVBQUU7QUFDUmpCLFdBQUssRUFBRSxpQkFEQztBQUVSQyxRQUFFLEVBQUUsT0FGSTtBQUdSWSxZQUFNLEVBQUUsV0FIQTtBQUlSSyxpQkFBVyxFQUFFLFVBSkw7QUFLUixpQkFBVztBQUNUQSxtQkFBVyxFQUFFLGlCQURKO0FBRVRsQixhQUFLLEVBQUUsaUJBRkU7QUFHVEMsVUFBRSxFQUFFO0FBSEs7QUFMSCxLQURGO0FBWVJrQixXQUFPLEVBQUU7QUFDUG5CLFdBQUssRUFBRSxPQURBO0FBRVBDLFFBQUUsRUFBRSxpQkFGRztBQUdQLGlCQUFXO0FBQ1RBLFVBQUUsRUFBRTtBQURLO0FBSEosS0FaRDtBQW1CUm1CLGFBQVMsRUFBRTtBQUNUcEIsV0FBSyxFQUFFLGlCQURFO0FBRVRDLFFBQUUsRUFBRSxPQUZLO0FBR1RZLFlBQU0sRUFBRSxXQUhDO0FBSVRLLGlCQUFXLEVBQUUsVUFKSjtBQUtULGlCQUFXO0FBQ1RsQixhQUFLLEVBQUUsT0FERTtBQUVUQyxVQUFFLEVBQUUsaUJBRks7QUFHVGlCLG1CQUFXLEVBQUU7QUFISjtBQUxGLEtBbkJIO0FBOEJSRyxRQUFJLEVBQUU7QUFDSnJCLFdBQUssRUFBRSxpQkFESDtBQUVKQyxRQUFFLEVBQUUsYUFGQTtBQUdKLGlCQUFXO0FBQ1RBLFVBQUUsRUFBRSxhQURLO0FBRVRELGFBQUssRUFBRTtBQUZFO0FBSFAsS0E5QkU7QUFzQ1JzQixVQUFNLEVBQUU7QUFDTkMsV0FBSyxFQUFFLEVBREQ7QUFFTmIsWUFBTSxFQUFFLEVBRkY7QUFHTmMsZ0JBQVUsRUFBRSxDQUhOO0FBSU5oQixnQkFBVSxFQUFFLENBSk47QUFLTkssWUFBTSxFQUFFLFdBTEY7QUFNTkssaUJBQVcsRUFBRSxjQU5QO0FBT05mLGtCQUFZLEVBQUUsRUFQUjtBQVFOc0IsYUFBTyxFQUFFLENBUkg7QUFTTnpCLFdBQUssRUFBRSxXQVREO0FBVU5DLFFBQUUsRUFBRSxhQVZFO0FBV04sb0JBQWM7QUFDWkEsVUFBRSxFQUFFLGlCQURRO0FBRVpELGFBQUssRUFBRSxPQUZLO0FBR1prQixtQkFBVyxFQUFFO0FBSEQsT0FYUjtBQWdCTixnQ0FBMEI7QUFDeEJqQixVQUFFLEVBQUUsYUFEb0I7QUFFeEJELGFBQUssRUFBRSxpQkFGaUI7QUFHeEJrQixtQkFBVyxFQUFFO0FBSFc7QUFoQnBCO0FBdENBO0FBREosQ0FBRCxDQWxDZ0IsRUFpR3ZCSCw2REFBTyxDQUFDO0FBQ05XLE1BQUksRUFBRSxNQURBO0FBRU5WLFVBQVEsRUFBRTtBQUNSVyxPQUFHLEVBQUU7QUFDSGpCLFlBQU0sRUFBRSxNQURMO0FBRUhoQixRQUFFLEVBQUU7QUFGRCxLQURHO0FBS1JrQyxTQUFLLEVBQUU7QUFDTGxCLFlBQU0sRUFBRSxNQURIO0FBRUxkLGNBQVEsRUFBRTtBQUZMO0FBTEM7QUFGSixDQUFELENBakdnQixFQThHdkJpQyw2REFBTyxDQUFDaEIsb0RBQUQsRUFBU2lCLG1EQUFULEVBQWdCQyxvREFBaEIsQ0E5R2dCLENBQWxCO0FBZ0hQLE1BQU1DLE1BQU0sR0FBR0MsbUVBQUgsZ0VBQVo7QUFLQSxNQUFNQyxPQUFPLEdBQUc1Qyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ1ZDLEtBQUQsSUFDRUMseURBQVMsQ0FBQztBQUNSOEIsT0FBSyxFQUFFLEVBREM7QUFFUmIsUUFBTSxFQUFFLEVBRkE7QUFHUnlCLFlBQVUsRUFBRSxFQUhKO0FBSVJ0QixRQUFNLEVBQUUsaUJBSkE7QUFLUnVCLFdBQVMsRUFBRyxhQUFZNUMsS0FBSyxDQUFDUSxLQUFOLEdBQWNSLEtBQUssQ0FBQ1EsS0FBcEIsR0FBNEIsaUJBQWtCLEVBTDlEO0FBTVJHLGNBQVksRUFBRSxLQU5OO0FBT1JrQyxvQkFBa0IsRUFBRTtBQVBaLENBQUQsQ0FGQSxFQVdYQyw2REFYVywyQ0FZSU4sTUFaSixFQUFiO0FBd0JPLE1BQU1PLE1BQU0sZ0JBQUdDLDRDQUFLLENBQUNDLFVBQU4sQ0FDcEIsT0FBb0RDLEdBQXBEO0FBQUEsTUFBQztBQUFFQyxZQUFGO0FBQVk1QyxZQUFaO0FBQXNCNkMsV0FBTyxHQUFHO0FBQWhDLEdBQUQ7QUFBQSxNQUEyQ3BELEtBQTNDOztBQUFBLHNCQUNFLHFFQUFDLFlBQUQ7QUFBYyxPQUFHLEVBQUVrRDtBQUFuQixLQUE0QmxELEtBQTVCO0FBQW1DLFlBQVEsRUFBRU8sUUFBN0M7QUFBdUQsUUFBSSxFQUFDLFFBQTVEO0FBQUEsZUFDRzRDLFFBREgsRUFFR0MsT0FBTyxpQkFBSSxxRUFBQyxPQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFBQSxDQURvQixDQUFmLEM7Ozs7Ozs7Ozs7OztBQ2xKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRU8sTUFBTUMsZUFBZSxHQUFHdkQsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxrT0FRWHVELHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQVJHLEVBU1RBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FUQyxFQVVmQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBVk8sRUFlTkEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQWZGLEVBZ0JUQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBaEJDLEVBaUJmQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBakJPLENBQXJCO0FBc0JBLE1BQU1DLFlBQVksR0FBR3pELHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsOEhBQWxCO0FBYUEsTUFBTXlELGFBQWEsR0FBRzFELHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsdUVBQW5CO0FBT0EsTUFBTWdELE1BQU0sR0FBR2pELHdEQUFNLENBQUMyRCxNQUFWO0FBQUE7QUFBQTtBQUFBLHFUQUtSSCx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FMQSxFQU1HQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBTlgsRUFRQUEseUVBQVEsQ0FBQyxZQUFELEVBQWUsS0FBZixDQVJSLEVBU0ZBLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FUTixFQVVDQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBVlQsRUFXRkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQVhOLENBQVosQzs7Ozs7Ozs7Ozs7QUM3Q1AsdUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUtBO0NBRUE7O0FBQ0E7O0FBTUEsTUFBTUksYUFBMkMsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFZO0FBQzlELFFBQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEIsQ0FEOEQsQ0FFOUQ7O0FBRUEsV0FBU0MsYUFBVCxHQUF5QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQSxVQUFNQyxJQUFJLEdBQUdILE1BQU0sQ0FBQ0ksUUFBcEI7QUFFQUosVUFBTSxDQUFDSyxJQUFQLENBQVlGLElBQVosRUFBa0JBLElBQWxCLEVBQXdCO0FBQUVHLGFBQU8sRUFBRTtBQUFYLEtBQXhCO0FBQ0Q7O0FBQ0Qsc0JBQ0UscUVBQUMsZ0VBQUQ7QUFBaUIsTUFBRSxFQUFFUCxFQUFyQjtBQUFBLDRCQUNFO0FBQUEsNkJBQ0UscUVBQUMsMkRBQUQ7QUFDRSxVQUFFLEVBQUMsZUFETDtBQUVFLHNCQUFjLEVBQUM7QUFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFRRSxxRUFBQyw2REFBRDtBQUFBLDZCQUNFO0FBQUssV0FBRyxFQUFFUSxxREFBVjtBQUF1QixXQUFHLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkYsZUFZRSxxRUFBQyw4REFBRDtBQUFBLDZCQUNFO0FBQUssZUFBTyxFQUFFTCxhQUFkO0FBQUEsK0JBQ0UscUVBQUMsK0RBQUQ7QUFBQSxrQ0FDRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBc0JELENBbENEOztBQW9DZUosNEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckRBO0FBQ0E7O0FBRUEsTUFBTVUsVUFBVSxHQUFJcEUsS0FBRCxpQkFDakIscUVBQUMsMkRBQUQ7QUFDRSxRQUFNLEVBQUUsR0FEVjtBQUVFLE9BQUssRUFBRSxHQUZUO0FBR0UsT0FBSyxFQUFFLENBSFQ7QUFJRSxpQkFBZSxFQUFDLFNBSmxCO0FBS0UsaUJBQWUsRUFBQztBQUxsQixHQU1NQSxLQU5OO0FBQUEsMEJBUUU7QUFBTSxLQUFDLEVBQUMsR0FBUjtBQUFZLEtBQUMsRUFBQyxHQUFkO0FBQWtCLE1BQUUsRUFBQyxHQUFyQjtBQUF5QixNQUFFLEVBQUMsR0FBNUI7QUFBZ0MsU0FBSyxFQUFDLEtBQXRDO0FBQTRDLFVBQU0sRUFBQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUkYsZUFTRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsS0FBekM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURixlQVVFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVZGLGVBV0U7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWEYsZUFZRTtBQUFNLEtBQUMsRUFBQyxLQUFSO0FBQWMsS0FBQyxFQUFDLEtBQWhCO0FBQXNCLE1BQUUsRUFBQyxHQUF6QjtBQUE2QixNQUFFLEVBQUMsR0FBaEM7QUFBb0MsU0FBSyxFQUFDLElBQTFDO0FBQStDLFVBQU0sRUFBQztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREY7O0FBZ0JPLE1BQU1xRSxtQkFBbUIsR0FBRyxtQkFDakMscUVBQUMsMkRBQUQ7QUFDRSxRQUFNLEVBQUUsRUFEVjtBQUVFLE9BQUssRUFBRSxHQUZUO0FBR0UsT0FBSyxFQUFFLENBSFQ7QUFJRSxpQkFBZSxFQUFDLFNBSmxCO0FBS0UsaUJBQWUsRUFBQyxTQUxsQjtBQUFBLDBCQU9FO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsSUFBZjtBQUFvQixNQUFFLEVBQUMsR0FBdkI7QUFBMkIsTUFBRSxFQUFDLEdBQTlCO0FBQWtDLFNBQUssRUFBQyxLQUF4QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVBGLGVBUUU7QUFBTSxLQUFDLEVBQUMsS0FBUjtBQUFjLEtBQUMsRUFBQyxJQUFoQjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVJGLGVBU0U7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxJQUFmO0FBQW9CLE1BQUUsRUFBQyxHQUF2QjtBQUEyQixNQUFFLEVBQUMsR0FBOUI7QUFBa0MsU0FBSyxFQUFDLElBQXhDO0FBQTZDLFVBQU0sRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREs7QUFjQSxNQUFNQyxhQUFhLEdBQUl0RSxLQUFELGlCQUMzQixxRUFBQywyREFBRDtBQUNFLFFBQU0sRUFBRSxHQURWO0FBRUUsT0FBSyxFQUFDLG1CQUZSO0FBR0UsT0FBSyxFQUFFLENBSFQ7QUFJRSxpQkFBZSxFQUFDLFNBSmxCO0FBS0UsaUJBQWUsRUFBQztBQUxsQixHQU1NQSxLQU5OO0FBQUEsMEJBUUU7QUFBTSxLQUFDLEVBQUMsS0FBUjtBQUFjLEtBQUMsRUFBQyxJQUFoQjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxHQUF6QztBQUE2QyxVQUFNLEVBQUM7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVJGLGVBU0U7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxJQUFmO0FBQW9CLE1BQUUsRUFBQyxHQUF2QjtBQUEyQixNQUFFLEVBQUMsR0FBOUI7QUFBa0MsU0FBSyxFQUFDLElBQXhDO0FBQTZDLFVBQU0sRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVEYsZUFVRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLElBQWY7QUFBb0IsTUFBRSxFQUFDLEdBQXZCO0FBQTJCLE1BQUUsRUFBQyxHQUE5QjtBQUFrQyxTQUFLLEVBQUMsS0FBeEM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFWRixlQVlFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsSUFBZjtBQUFvQixNQUFFLEVBQUMsR0FBdkI7QUFBMkIsTUFBRSxFQUFDLEdBQTlCO0FBQWtDLFNBQUssRUFBQyxJQUF4QztBQUE2QyxVQUFNLEVBQUM7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVpGLGVBYUU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxJQUFmO0FBQW9CLE1BQUUsRUFBQyxHQUF2QjtBQUEyQixNQUFFLEVBQUMsR0FBOUI7QUFBa0MsU0FBSyxFQUFDLEtBQXhDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYkYsZUFlRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFmRixlQWdCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsS0FBekM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFoQkYsZUFrQkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbEJGLGVBbUJFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxLQUF6QztBQUErQyxVQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW5CRixlQXFCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFyQkYsZUFzQkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLEtBQXpDO0FBQStDLFVBQU0sRUFBQztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdEJGLGVBd0JFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXhCRixlQXlCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsS0FBekM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF6QkYsZUEyQkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBM0JGLGVBNEJFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxLQUF6QztBQUErQyxVQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTVCRixlQThCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE5QkYsZUErQkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLEtBQXpDO0FBQStDLFVBQU0sRUFBQztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURLO0FBbUNRb0UseUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDcEVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVPLE1BQU1HLFdBQVcsR0FBR3pFLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsMk9BS0Z1RCx5RUFBUSxDQUFDLGlCQUFELEVBQW9CLFNBQXBCLENBTE4sRUFhQUEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBYlIsQ0FBakI7QUFpQkEsTUFBTUUsYUFBYSxHQUFHMUQsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0REFBbkI7QUFNQSxNQUFNeUUsUUFBUSxHQUFHMUUsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0SkFNSnVELHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FOSixFQU9OQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FQRixFQVFKQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBUkosRUFTVkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixTQUFyQixDQVRFLENBQWQ7QUFZQSxNQUFNbUIsYUFBYSxHQUFHM0Usd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0REFBbkI7QUFPQSxNQUFNMkUsVUFBVSxHQUFHNUUsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxvRUFBaEI7QUFVQSxNQUFNNEUsa0JBQWtCLEdBQUc3RSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHVDQUF4QjtBQU9BLE1BQU02RSxXQUFXLEdBQUc5RSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHMxQ0FzRGhCNEUsa0JBdERnQixDQUFqQjtBQTBHQSxNQUFNRSxXQUFXLEdBQUcvRSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLCtlQUFqQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEtQO0FBQ0E7QUFDQTtBQUNBO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU0rRSxZQUFZLEdBQUdDLG1EQUFPLENBQUMsTUFDM0IsZ0xBRDBCO0FBQUE7QUFBQSx3Q0FDbkIsZ0dBRG1CO0FBQUEsY0FDbkIsd0NBRG1CO0FBQUE7QUFBQSxFQUE1QjtBQUlBLE1BQU1DLFdBQVcsR0FBR0QsbURBQU8sT0FDekIsc05BRHlCO0FBQUE7QUFBQSx3Q0FDbEIsc0lBRGtCO0FBQUEsY0FDbEIsMkRBRGtCO0FBQUE7QUFBQSxFQUEzQjtBQUdBLE1BQU1FLFFBQVEsR0FBR0YsbURBQU8sT0FDdEIsc05BRHNCO0FBQUE7QUFBQSx3Q0FDZixzSUFEZTtBQUFBLGNBQ2YsMkRBRGU7QUFBQTtBQUFBLEVBQXhCO0FBR0EsTUFBTUcsYUFBYSxHQUFHSCxtREFBTyxPQUMzQiw4TkFEMkI7QUFBQTtBQUFBLHdDQUNwQiw4SUFEb0I7QUFBQSxjQUNwQiwrREFEb0I7QUFBQTtBQUFBLEVBQTdCO0FBR0EsTUFBTUksWUFBWSxHQUFHSixtREFBTyxPQUMxQix5TkFEMEI7QUFBQTtBQUFBLHdDQUNuQiwwSUFEbUI7QUFBQSxjQUNuQiw2REFEbUI7QUFBQTtBQUFBLEVBQTVCO0FBY08sTUFBTUssUUFBaUMsR0FBRyxDQUFDO0FBQ2hEQyxZQURnRDtBQUVoREMsWUFBVSxHQUFHLEVBRm1DO0FBR2hEQyxVQUFRLEdBQUcsSUFIcUM7QUFJaERDO0FBSmdELENBQUQsS0FLM0M7QUFDSixRQUFNNUIsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQUNBLFFBQU07QUFBRTRCLFFBQUY7QUFBUUMsU0FBUjtBQUFldEMsV0FBZjtBQUF3QnVDLGFBQXhCO0FBQW1DQztBQUFuQyxNQUFxREMsK0RBQVEsQ0FDakVDLDBFQURpRSxFQUVqRTtBQUNFQyxhQUFTLEVBQUU7QUFDVFAsVUFBSSxFQUFFQSxJQURHO0FBRVQzRCxVQUFJLEVBQUUrQixNQUFNLENBQUNvQyxLQUFQLENBQWFuRSxJQUZWO0FBR1RvRSxjQUFRLEVBQUVyQyxNQUFNLENBQUNvQyxLQUFQLENBQWFDLFFBSGQ7QUFJVEMsWUFBTSxFQUFFLENBSkM7QUFLVEMsV0FBSyxFQUFFYjtBQUxFLEtBRGI7QUFRRWMsK0JBQTJCLEVBQUU7QUFSL0IsR0FGaUUsQ0FBbkU7QUFhQSxRQUFNQyxXQUFXLEdBQUdULGFBQWEsS0FBS1UsNERBQWEsQ0FBQ1gsU0FBcEQ7QUFFQSxNQUFJRCxLQUFKLEVBQVcsb0JBQU8scUVBQUMsWUFBRDtBQUFjLFdBQU8sRUFBRUEsS0FBSyxDQUFDYTtBQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVA7O0FBQ1gsTUFBSW5ELE9BQU8sSUFBSSxDQUFDaUQsV0FBaEIsRUFBNkI7QUFDM0Isd0JBQ0UscUVBQUMsaUVBQUQ7QUFBQSw4QkFDRSxxRUFBQyw4REFBRDtBQUFBLCtCQUNFLHFFQUFDLDBFQUFEO0FBQWEsbUJBQVMsRUFBQztBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFLHFFQUFDLDhEQUFEO0FBQUEsK0JBQ0UscUVBQUMsMEVBQUQ7QUFBYSxtQkFBUyxFQUFDO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBT0UscUVBQUMsOERBQUQ7QUFBQSwrQkFDRSxxRUFBQywwRUFBRDtBQUFhLG1CQUFTLEVBQUM7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBYUQ7O0FBRUQsTUFBSSxDQUFDWixJQUFELElBQVMsQ0FBQ0EsSUFBSSxDQUFDZSxRQUFmLElBQTJCZixJQUFJLENBQUNlLFFBQUwsQ0FBY0MsS0FBZCxDQUFvQkMsTUFBcEIsS0FBK0IsQ0FBOUQsRUFBaUU7QUFDL0Qsd0JBQU8scUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUDtBQUNEOztBQUNELFFBQU1DLGNBQWMsR0FBRyxNQUFNO0FBQzNCaEIsYUFBUyxDQUFDO0FBQ1JJLGVBQVMsRUFBRTtBQUNURyxjQUFNLEVBQUVVLE1BQU0sQ0FBQ25CLElBQUksQ0FBQ2UsUUFBTCxDQUFjQyxLQUFkLENBQW9CQyxNQUFyQixDQURMO0FBRVRQLGFBQUssRUFBRWI7QUFGRTtBQURILEtBQUQsQ0FBVDtBQU1ELEdBUEQ7O0FBU0EsUUFBTXVCLFVBQVUsR0FBRyxDQUFDQyxXQUFELEVBQWM5RyxLQUFkLEtBQXdCO0FBQUE7O0FBQ3pDLFlBQVE4RyxXQUFSO0FBQ0UsV0FBSyxNQUFMO0FBQ0UsNEJBQ0UscUVBQUMsUUFBRDtBQUNFLGVBQUssRUFBRTlHLEtBQUssQ0FBQytHLEtBRGY7QUFFRSxlQUFLLEVBQUUvRyxLQUFLLENBQUNnSCxLQUZmO0FBR0UsY0FBSSxFQUFFaEgsS0FBRixhQUFFQSxLQUFGLHdDQUFFQSxLQUFLLENBQUVpSCxNQUFULGtEQUFFLGNBQWVDLElBSHZCO0FBSUUsY0FBSSxFQUFFbEgsS0FKUjtBQUtFLG9CQUFVLEVBQUVxRixVQUxkO0FBTUUsaUJBQU8sRUFBRSxNQUFNO0FBQ2J6QixrQkFBTSxDQUFDSyxJQUFQLENBQVksaUJBQVosRUFBZ0MsWUFBV2pFLEtBQUssQ0FBQ21ILElBQUssRUFBdEQ7O0FBQ0EsdUJBQW1DLEVBRWxDO0FBQ0Y7QUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGOztBQWVGLFdBQUssVUFBTDtBQUNFLDRCQUNFLHFFQUFDLFlBQUQ7QUFDRSxlQUFLLEVBQUVuSCxLQUFLLENBQUMrRyxLQURmO0FBRUUsa0JBQVEsRUFBRUssdURBRlo7QUFHRSxlQUFLLEVBQUVwSCxLQUFLLENBQUNnSCxLQUhmO0FBSUUsZUFBSyxFQUFFaEgsS0FBSyxDQUFDcUgsS0FKZjtBQUtFLGdCQUFNLEVBQUVySCxLQUFLLENBQUNzSCxJQUxoQjtBQU1FLGNBQUksRUFBRXRIO0FBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjs7QUFVRixXQUFLLFdBQUw7QUFDRSw0QkFDRSxxRUFBQyxhQUFEO0FBQ0UsZUFBSyxFQUFFQSxLQUFLLENBQUMrRyxLQURmO0FBRUUsZUFBSyxFQUFFL0csS0FBSyxDQUFDdUgsT0FBTixDQUFjLENBQWQsRUFBaUJDLEdBRjFCO0FBR0UsMkJBQWlCLEVBQUV4SCxLQUFLLENBQUN5SCxpQkFIM0I7QUFJRSxjQUFJLEVBQUV6SCxLQUpSO0FBS0Usb0JBQVUsRUFBRXFGO0FBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjs7QUFTRjtBQUNFLDRCQUNFLHFFQUFDLFdBQUQ7QUFDRSxlQUFLLEVBQUVyRixLQUFLLENBQUMrRyxLQURmO0FBRUUscUJBQVcsRUFBRS9HLEtBQUssQ0FBQzBILFdBRnJCO0FBR0UsZUFBSyxFQUFFMUgsS0FBSyxDQUFDZ0gsS0FIZjtBQUlFLGdCQUFNLEVBQUVoSCxLQUFLLENBQUNzSCxJQUpoQjtBQUtFLGtCQUFRLEVBQUVGLHVEQUxaO0FBTUUsZUFBSyxFQUFFcEgsS0FBSyxDQUFDcUgsS0FOZjtBQU9FLG1CQUFTLEVBQUVySCxLQUFLLENBQUMySCxTQVBuQjtBQVFFLDJCQUFpQixFQUFFM0gsS0FBSyxDQUFDeUgsaUJBUjNCO0FBU0UsY0FBSSxFQUFFekgsS0FUUjtBQVVFLG9CQUFVLEVBQUVxRjtBQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUF2Q0o7QUFzREQsR0F2REQ7O0FBd0RBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsK0RBQUQ7QUFBQSxnQkFDR0ksSUFBSSxDQUFDZSxRQUFMLENBQWNDLEtBQWQsQ0FBb0JtQixHQUFwQixDQUF3QixDQUFDQyxJQUFELEVBQVlDLEtBQVosa0JBQ3ZCLHFFQUFDLCtEQUFEO0FBRUUsYUFBSyxFQUFFdEMsSUFBSSxLQUFLLFNBQVQsR0FBcUI7QUFBRXVDLHFCQUFXLEVBQUUsQ0FBZjtBQUFrQkMsc0JBQVksRUFBRSxDQUFoQztBQUFrQ0MscUJBQVcsRUFBQztBQUE5QyxTQUFyQixHQUF5RSxFQUZsRjtBQUFBLCtCQUlFLHFFQUFDLHNFQUFEO0FBQUEsaUNBQ0UscUVBQUMsd0RBQUQ7QUFDRSxvQkFBUSxFQUFFLEdBRFo7QUFFRSxpQkFBSyxFQUFFSCxLQUFLLEdBQUcsRUFGakI7QUFHRSxpQkFBSyxFQUFFO0FBQUU1RyxvQkFBTSxFQUFFO0FBQVYsYUFIVDtBQUFBLHNCQUtHMkYsVUFBVSxDQUFDckIsSUFBRCxFQUFPcUMsSUFBUDtBQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkYsU0FDT0MsS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixFQW1CR3ZDLFFBQVEsSUFBSUUsSUFBSSxDQUFDZSxRQUFMLENBQWMwQixPQUExQixpQkFDQyxxRUFBQyxpRUFBRDtBQUFBLDZCQUNFLHFFQUFDLHlFQUFEO0FBQ0UsZUFBTyxFQUFFdkIsY0FEWDtBQUVFLGVBQU8sRUFBRU4sV0FGWDtBQUdFLGVBQU8sRUFBQyxXQUhWO0FBSUUsYUFBSyxFQUFFO0FBQ0xqRyxrQkFBUSxFQUFFO0FBREwsU0FKVDtBQU9FLGNBQU0sRUFBQyxtQkFQVDtBQUFBLCtCQVNFLHFFQUFDLDREQUFEO0FBQWtCLFlBQUUsRUFBQyxnQkFBckI7QUFBc0Msd0JBQWMsRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcEJKO0FBQUEsa0JBREY7QUFxQ0QsQ0FoSk07QUFpSlFnRix1RUFBZixFOzs7Ozs7Ozs7Ozs7QUNoTUE7QUFBQTtBQUFBO0FBQ08sTUFBTWdDLFFBQVEsR0FBRyxHQUFqQixDIiwiZmlsZSI6IjEyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBzdHlsZWQsIHsga2V5ZnJhbWVzLCBjc3MgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgc3lzdGVtQ3NzIGZyb20gJ0BzdHlsZWQtc3lzdGVtL2Nzcyc7XG5pbXBvcnQgeyBjb21wb3NlLCB2YXJpYW50LCBib3JkZXIsIHNwYWNlLCBsYXlvdXQgfSBmcm9tICdzdHlsZWQtc3lzdGVtJztcblxuZXhwb3J0IGNvbnN0IFN0eWxlZEJ1dHRvbiA9IHN0eWxlZC5kaXY8YW55PihcbiAgKHByb3BzKSA9PlxuICAgIHN5c3RlbUNzcyh7XG4gICAgICBweDogJzE1cHgnLFxuICAgICAgcHk6IDAsXG4gICAgICBmb250U2l6ZTogWydiYXNlJ10sXG4gICAgICBmb250V2VpZ2h0OiAnYm9sZCcsXG4gICAgICBjdXJzb3I6IHByb3BzLmRpc2FibGVkID8gJ25vdC1hbGxvd2VkJyA6ICdwb2ludGVyJyxcbiAgICAgIGNvbG9yOiBwcm9wcy5kaXNhYmxlZCA/ICd0ZXh0LmxpZ2h0JyA6ICd3aGl0ZScsXG4gICAgICBiZzogcHJvcHMuZGlzYWJsZWQgPyAnZ3JheS41MDAnIDogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICB0cmFuc2l0aW9uOiAnYWxsIDAuM3MgZWFzZScsXG4gICAgICBib3JkZXJSYWRpdXM6ICdiYXNlJyxcblxuICAgICAgJyY6aG92ZXInOiB7XG4gICAgICAgIGNvbG9yOiBwcm9wcy5kaXNhYmxlZCA/ICd0ZXh0LmxpZ2h0JyA6ICd3aGl0ZScsXG4gICAgICAgIGJnOiBwcm9wcy5kaXNhYmxlZCA/ICdncmF5LjUwMCcgOiAncHJpbWFyeS5ob3ZlcicsXG4gICAgICB9LFxuICAgIH0pLFxuICB7XG4gICAgYXBwZWFyYW5jZTogJ25vbmUnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgZmxleFNocmluazogMCxcbiAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgIGhlaWdodDogJzM4cHgnLFxuICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXG4gICAgZm9udEZhbWlseTogJ2luaGVyaXQnLFxuICAgIGJvcmRlcjogMCxcblxuICAgICcmOmZvY3VzJzoge1xuICAgICAgb3V0bGluZTogJ25vbmUnLFxuICAgIH0sXG4gIH0sXG4gIHZhcmlhbnQoe1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICBvdXRsaW5lZDoge1xuICAgICAgICBjb2xvcjogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICAgIGJnOiAnd2hpdGUnLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ2dyYXkuNTAwJyxcbiAgICAgICAgJyY6aG92ZXInOiB7XG4gICAgICAgICAgYm9yZGVyQ29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgICAgICAgIGNvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICAgICAgICBiZzogJ3doaXRlJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBwcmltYXJ5OiB7XG4gICAgICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgICAgICBiZzogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICAgICcmOmhvdmVyJzoge1xuICAgICAgICAgIGJnOiAncHJpbWFyeS5ob3ZlcicsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgc2Vjb25kYXJ5OiB7XG4gICAgICAgIGNvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICAgICAgYmc6ICd3aGl0ZScsXG4gICAgICAgIGJvcmRlcjogJzJweCBzb2xpZCcsXG4gICAgICAgIGJvcmRlckNvbG9yOiAnZ3JheS41MDAnLFxuICAgICAgICAnJjpob3Zlcic6IHtcbiAgICAgICAgICBjb2xvcjogJ3doaXRlJyxcbiAgICAgICAgICBiZzogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICAgICAgYm9yZGVyQ29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHRleHQ6IHtcbiAgICAgICAgY29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgICAgICBiZzogJ3RyYW5zcGFyZW50JyxcbiAgICAgICAgJyY6aG92ZXInOiB7XG4gICAgICAgICAgYmc6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgICAgY29sb3I6ICdwcmltYXJ5LmhvdmVyJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBzZWxlY3Q6IHtcbiAgICAgICAgd2lkdGg6IDI2LFxuICAgICAgICBoZWlnaHQ6IDI2LFxuICAgICAgICBsaW5lSGVpZ2h0OiAxLFxuICAgICAgICBmbGV4U2hyaW5rOiAwLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ3RleHQucmVndWxhcicsXG4gICAgICAgIGJvcmRlclJhZGl1czogMTMsXG4gICAgICAgIHBhZGRpbmc6IDAsXG4gICAgICAgIGNvbG9yOiAndGV4dC5ib2xkJyxcbiAgICAgICAgYmc6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgICcmLnNlbGVjdGVkJzoge1xuICAgICAgICAgIGJnOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICAgICAgICBjb2xvcjogJ3doaXRlJyxcbiAgICAgICAgICBib3JkZXJDb2xvcjogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICAgIH0sXG4gICAgICAgICcmOmhvdmVyOm5vdCguc2VsZWN0ZWQpJzoge1xuICAgICAgICAgIGJnOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgIGNvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICAgICAgICBib3JkZXJDb2xvcjogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0pLFxuICB2YXJpYW50KHtcbiAgICBwcm9wOiAnc2l6ZScsXG4gICAgdmFyaWFudHM6IHtcbiAgICAgIGJpZzoge1xuICAgICAgICBoZWlnaHQ6ICc0OHB4JyxcbiAgICAgICAgcHg6IDMwLFxuICAgICAgfSxcbiAgICAgIHNtYWxsOiB7XG4gICAgICAgIGhlaWdodDogJzMwcHgnLFxuICAgICAgICBmb250U2l6ZTogMTQsXG4gICAgICB9LFxuICAgIH0sXG4gIH0pLFxuICBjb21wb3NlKGJvcmRlciwgc3BhY2UsIGxheW91dClcbik7XG5jb25zdCByb3RhdGUgPSBrZXlmcmFtZXNgXG4gIGZyb20ge3RyYW5zZm9ybTogcm90YXRlKDBkZWcpO31cbiAgdG8ge3RyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7fVxuYDtcblxuY29uc3QgU3Bpbm5lciA9IHN0eWxlZC5kaXYoXG4gIChwcm9wcykgPT5cbiAgICBzeXN0ZW1Dc3Moe1xuICAgICAgd2lkdGg6IDE4LFxuICAgICAgaGVpZ2h0OiAxOCxcbiAgICAgIG1hcmdpbkxlZnQ6IDEwLFxuICAgICAgYm9yZGVyOiAnM3B4IHNvbGlkIHdoaXRlJyxcbiAgICAgIGJvcmRlclRvcDogYDNweCBzb2xpZCAke3Byb3BzLmNvbG9yID8gcHJvcHMuY29sb3IgOiAncHJpbWFyeS5yZWd1bGFyJ31gLFxuICAgICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcbiAgICAgIHRyYW5zaXRpb25Qcm9wZXJ0eTogJ3RyYW5zZm9ybScsXG4gICAgfSksXG4gIGNzc2BcbiAgICBhbmltYXRpb246ICR7cm90YXRlfSAxLjJzIGluZmluaXRlIGxpbmVhcjtcbiAgYFxuKTtcblxudHlwZSBQcm9wcyA9IHtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbiAgbG9hZGluZz86IGJvb2xlYW47XG4gIGRpc2FibGVkPzogYm9vbGVhbjtcbiAgdHlwZTogJ3N1Ym1pdCcgfCAnYnV0dG9uJztcbiAgW2tleTogc3RyaW5nXTogdW5rbm93bjtcbn07XG5leHBvcnQgdHlwZSBSZWYgPSBIVE1MRGl2RWxlbWVudDtcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBSZWFjdC5mb3J3YXJkUmVmPFJlZiwgUHJvcHM+KFxuICAoeyBjaGlsZHJlbiwgZGlzYWJsZWQsIGxvYWRpbmcgPSBmYWxzZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gICAgPFN0eWxlZEJ1dHRvbiByZWY9e3JlZn0gey4uLnByb3BzfSBkaXNhYmxlZD17ZGlzYWJsZWR9IHJvbGU9XCJidXR0b25cIj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIHtsb2FkaW5nICYmIDxTcGlubmVyIC8+fVxuICAgIDwvU3R5bGVkQnV0dG9uPlxuICApXG4pO1xuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgeyB0aGVtZUdldCB9IGZyb20gJ0BzdHlsZWQtc3lzdGVtL3RoZW1lLWdldCc7XG5cbmV4cG9ydCBjb25zdCBOb1Jlc3VsdFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogNTBweCAyMHB4O1xuXG4gIGgzIHtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy54bCcsICcyNCcpfXB4O1xuICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQuYm9sZCcsICcjMEQxMTM2Jyl9O1xuICAgIG1hcmdpbjogMCAwIDE1cHg7XG4gIH1cblxuICBwIHtcbiAgICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCArIDFweCk7XG4gICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5yZWd1bGFyJywgJyM3Nzc5OEMnKX07XG4gICAgbWFyZ2luOiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgSW1hZ2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgbWFyZ2luLXRvcDogNTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIG1heC13aWR0aDogNjAwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQnV0dG9uV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogNzBweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gIGhlaWdodDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogY2FsYygke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4ICsgMXB4KTtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICBwYWRkaW5nOiAwIDMwcHg7XG4gIGJvcmRlcjogMDtcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcbmA7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IFwiL19uZXh0L3N0YXRpYy9pbWFnZXMvbm8tcmVzdWx0LTgxODM4YTQ4ZWE1MmMxMmY2N2ZmZmFjODJiOGIxMDg3LnN2Z1wiOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XG5pbXBvcnQgTm9SZXN1bHRTdmcgZnJvbSAnLi9uby1yZXN1bHQuc3ZnJztcbmltcG9ydCB7XG4gIE5vUmVzdWx0V3JhcHBlcixcbiAgSW1hZ2VXcmFwcGVyLFxuICBCdXR0b25XcmFwcGVyLFxufSBmcm9tICcuL25vLXJlc3VsdC5zdHlsZSc7XG5pbXBvcnQgeyBBcnJvd1ByZXYgfSBmcm9tICdhc3NldHMvaWNvbnMvQXJyb3dQcmV2JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ2NvbXBvbmVudHMvYnV0dG9uL2J1dHRvbic7XG4vLyBpbXBvcnQgeyBTZWFyY2hDb250ZXh0IH0gZnJvbSAnY29udGV4dHMvc2VhcmNoL3NlYXJjaC5jb250ZXh0JztcbmltcG9ydCB7IEZvcm1hdHRlZE1lc3NhZ2UgfSBmcm9tICdyZWFjdC1pbnRsJztcblxudHlwZSBOb1Jlc3VsdEZvdW5kUHJvcHMgPSB7XG4gIGlkPzogc3RyaW5nO1xufTtcblxuY29uc3QgTm9SZXN1bHRGb3VuZDogUmVhY3QuRkM8Tm9SZXN1bHRGb3VuZFByb3BzPiA9ICh7IGlkIH0pID0+IHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIC8vIGNvbnN0IHsgZGlzcGF0Y2ggfSA9IFJlYWN0LnVzZUNvbnRleHQoU2VhcmNoQ29udGV4dCk7XG5cbiAgZnVuY3Rpb24gb25DbGlja0J1dHRvbigpIHtcbiAgICAvLyBkaXNwYXRjaCh7XG4gICAgLy8gICB0eXBlOiAnUkVTRVQnLFxuICAgIC8vIH0pO1xuICAgIGNvbnN0IGhyZWYgPSByb3V0ZXIucGF0aG5hbWU7XG5cbiAgICByb3V0ZXIucHVzaChocmVmLCBocmVmLCB7IHNoYWxsb3c6IHRydWUgfSk7XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8Tm9SZXN1bHRXcmFwcGVyIGlkPXtpZH0+XG4gICAgICA8aDM+XG4gICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlXG4gICAgICAgICAgaWQ9XCJub1Jlc3VsdEZvdW5kXCJcbiAgICAgICAgICBkZWZhdWx0TWVzc2FnZT1cIlNvcnJ5LCBObyByZXN1bHQgZm91bmQgOihcIlxuICAgICAgICAvPlxuICAgICAgPC9oMz5cblxuICAgICAgPEltYWdlV3JhcHBlcj5cbiAgICAgICAgPGltZyBzcmM9e05vUmVzdWx0U3ZnfSBhbHQ9XCJObyBSZXN1bHRcIiAvPlxuICAgICAgPC9JbWFnZVdyYXBwZXI+XG5cbiAgICAgIDxCdXR0b25XcmFwcGVyPlxuICAgICAgICA8ZGl2IG9uQ2xpY2s9e29uQ2xpY2tCdXR0b259PlxuICAgICAgICAgIDxCdXR0b24+XG4gICAgICAgICAgICA8QXJyb3dQcmV2IC8+IEdvIEJhY2tcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0J1dHRvbldyYXBwZXI+XG4gICAgPC9Ob1Jlc3VsdFdyYXBwZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBOb1Jlc3VsdEZvdW5kO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBDb250ZW50TG9hZGVyIGZyb20gJ3JlYWN0LWNvbnRlbnQtbG9hZGVyJztcblxuY29uc3QgUG9zdExvYWRlciA9IChwcm9wcykgPT4gKFxuICA8Q29udGVudExvYWRlclxuICAgIGhlaWdodD17MzUwfVxuICAgIHdpZHRoPXsyNDV9XG4gICAgc3BlZWQ9ezJ9XG4gICAgYmFja2dyb3VuZENvbG9yPVwiI2YzZjNmM1wiXG4gICAgZm9yZWdyb3VuZENvbG9yPVwiI2VjZWJlYlwiXG4gICAgey4uLnByb3BzfVxuICA+XG4gICAgPHJlY3QgeD1cIjJcIiB5PVwiMlwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjQwXCIgaGVpZ2h0PVwiMTk3XCIgLz5cbiAgICA8cmVjdCB4PVwiMTVcIiB5PVwiMjIwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIxNDBcIiBoZWlnaHQ9XCIyNVwiIC8+XG4gICAgPHJlY3QgeD1cIjE1XCIgeT1cIjI1NFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiNjVcIiBoZWlnaHQ9XCIxNVwiIC8+XG4gICAgPHJlY3QgeD1cIjE1XCIgeT1cIjMwMFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiNjdcIiBoZWlnaHQ9XCIyMFwiIC8+XG4gICAgPHJlY3QgeD1cIjE3MFwiIHk9XCIzMDBcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjYwXCIgaGVpZ2h0PVwiMjBcIiAvPlxuICA8L0NvbnRlbnRMb2FkZXI+XG4pO1xuZXhwb3J0IGNvbnN0IFNpZGViYXJNb2JpbGVMb2FkZXIgPSAoKSA9PiAoXG4gIDxDb250ZW50TG9hZGVyXG4gICAgaGVpZ2h0PXs0Nn1cbiAgICB3aWR0aD17NDAwfVxuICAgIHNwZWVkPXsyfVxuICAgIGJhY2tncm91bmRDb2xvcj1cIiNmM2YzZjNcIlxuICAgIGZvcmVncm91bmRDb2xvcj1cIiNlY2ViZWJcIlxuICA+XG4gICAgPHJlY3QgeD1cIjU4XCIgeT1cIjEwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyODdcIiBoZWlnaHQ9XCIyNlwiIC8+XG4gICAgPHJlY3QgeD1cIjM2NFwiIHk9XCIxMFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjZcIiBoZWlnaHQ9XCIyNlwiIC8+XG4gICAgPHJlY3QgeD1cIjE2XCIgeT1cIjEwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNlwiIGhlaWdodD1cIjI2XCIgLz5cbiAgPC9Db250ZW50TG9hZGVyPlxuKTtcblxuZXhwb3J0IGNvbnN0IFNpZGViYXJMb2FkZXIgPSAocHJvcHMpID0+IChcbiAgPENvbnRlbnRMb2FkZXJcbiAgICBoZWlnaHQ9ezQwMH1cbiAgICB3aWR0aD1cImNhbGMoMTAwJSAtIDMwcHgpXCJcbiAgICBzcGVlZD17Mn1cbiAgICBiYWNrZ3JvdW5kQ29sb3I9XCIjZjNmM2YzXCJcbiAgICBmb3JlZ3JvdW5kQ29sb3I9XCIjZWNlYmViXCJcbiAgICB7Li4ucHJvcHN9XG4gID5cbiAgICA8cmVjdCB4PVwiMzc2XCIgeT1cIjIyXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIwXCIgaGVpZ2h0PVwiMFwiIC8+XG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjUwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiNTBcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjI2MFwiIGhlaWdodD1cIjI0XCIgLz5cblxuICAgIDxyZWN0IHg9XCIyN1wiIHk9XCI4OVwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjg5XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMTI4XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMTI4XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMTY3XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMTY3XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMjA2XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMjA2XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMjQ1XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMjQ1XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMjg0XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMjg0XCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiMzIzXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgLz5cbiAgICA8cmVjdCB4PVwiNjlcIiB5PVwiMzIzXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gIDwvQ29udGVudExvYWRlcj5cbik7XG5leHBvcnQgZGVmYXVsdCBQb3N0TG9hZGVyO1xuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgeyB0aGVtZUdldCB9IGZyb20gJ0BzdHlsZWQtc3lzdGVtL3RoZW1lLWdldCc7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0c1JvdyA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDpjZW50ZXI7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgbWFyZ2luLXRvcDogMjVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLmdyYXkuMjAwJywgJyNmN2Y3ZjcnKX07XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTtcbiAgbWFyZ2luOiAwIC0xNXB4O1xuICBAbWVkaWEgKG1heC13aWR0aDogOTkwcHgpIHtcbiAgICBtYXJnaW4tbGVmdDogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMHB4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCdXR0b25XcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgTm9SZXN1bHQgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMTAwcHggMzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ0xhdG8nKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLmxnJywgJzIxJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LmJvbGQnLCAnIzBEMTEzNicpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBMb2FkZXJXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwdmg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbmA7XG5cbmV4cG9ydCBjb25zdCBMb2FkZXJJdGVtID0gc3R5bGVkLmRpdmBcbiAgd2lkdGg6IDI1JTtcbiAgcGFkZGluZzogMCAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuXG4gIHN2ZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0Q2FyZFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDEwMCU7XG4gID4gZGl2IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0c0NvbCA9IHN0eWxlZC5kaXZgXG4gIGZsZXg6IDAgMCAyMCU7XG4gIG1heC13aWR0aDogMTYlO1xuICBwYWRkaW5nLWxlZnQ6IDE1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIC5ib29rLWNhcmQge1xuICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gIH1cbiAgJi5mb29kLWNvbCB7XG4gICAgZmxleDogMCAwIDI1JTtcbiAgICBtYXgtd2lkdGg6IDE2JTtcbiAgfVxuICBAbWVkaWEgKG1pbi13aWR0aDogMTUwMXB4KSB7XG4gICAgJjpudGgtY2hpbGQoNW4gKyAxKSB7XG4gICAgICAuYm9vay1jYXJkIHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNnB4IDAgMCA2cHg7XG4gICAgICB9XG4gICAgfVxuICAgICY6bnRoLWNoaWxkKDVuKSB7XG4gICAgICAuYm9vay1jYXJkIHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMCA2cHggNnB4IDA7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIEBtZWRpYSAobWluLXdpZHRoOiAxMzAxcHgpIGFuZCAobWF4LXdpZHRoOiAxNTAwcHgpIHtcbiAgICBmbGV4OiAwIDAgMTklO1xuICAgIG1heC13aWR0aDogMjUlO1xuICAgICYuZm9vZC1jb2wge1xuICAgICAgZmxleDogMCAwIDMzLjMzMyU7XG4gICAgICBtYXgtd2lkdGg6IDMzLjMzMyU7XG4gICAgfVxuICAgICY6bnRoLWNoaWxkKDRuICsgMSkge1xuICAgICAgLmJvb2stY2FyZCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweCAwIDAgNnB4O1xuICAgICAgfVxuICAgIH1cbiAgICAmOm50aC1jaGlsZCg0bikge1xuICAgICAgLmJvb2stY2FyZCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDAgNnB4IDZweCAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBAbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpIGFuZCAobWF4LXdpZHRoOiAxMzAwcHgpIHtcbiAgICBmbGV4OiAwIDAgMzMuMzMzMzMzMyU7XG4gICAgbWF4LXdpZHRoOiAzMy4zMzMzMzMzJTtcbiAgICAmLmZvb2QtY29sIHtcbiAgICAgIGZsZXg6IDAgMCAzMy4zMzMzMzMzJTtcbiAgICAgIG1heC13aWR0aDogMzMuMzMzMzMzMyU7XG4gICAgICBwYWRkaW5nLWxlZnQ6IDcuNXB4O1xuICAgICAgcGFkZGluZy1yaWdodDogNy41cHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgICAgYm9yZGVyOiAwO1xuXG4gICAgICAke1Byb2R1Y3RDYXJkV3JhcHBlcn0ge1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZjFmMWYxO1xuICAgICAgfVxuICAgIH1cbiAgICAmOm50aC1jaGlsZCgzbiArIDEpIHtcbiAgICAgIC5ib29rLWNhcmQge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHggMCAwIDZweDtcbiAgICAgIH1cbiAgICB9XG4gICAgJjpudGgtY2hpbGQoM24pIHtcbiAgICAgIC5ib29rLWNhcmQge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAwIDZweCA2cHggMDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExOTlweCkgYW5kIChtaW4td2lkdGg6IDk5MXB4KSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAmLmZvb2QtY29sIHtcbiAgICAgIGZsZXg6IDAgMCA1MCU7XG4gICAgICBtYXgtd2lkdGg6IDUwJTtcbiAgICB9XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MHB4KSB7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgbWFyZ2luLWJvdHRvbTogLTFweDtcbiAgICBtYXJnaW4tcmlnaHQ6IC0xcHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2YxZjFmMTtcbiAgfVxuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGZsZXg6IDAgMCA1MCU7XG4gICAgbWF4LXdpZHRoOiA1MCU7XG4gICAgJi5mb29kLWNvbCB7XG4gICAgICBmbGV4OiAwIDAgNTAlO1xuICAgICAgbWF4LXdpZHRoOiA1MCU7XG4gICAgfVxuICAgICY6bnRoLWNoaWxkKDJuICsgMSkge1xuICAgICAgLmJvb2stY2FyZCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweCAwIDAgNnB4O1xuICAgICAgfVxuICAgIH1cbiAgICAmOm50aC1jaGlsZCgybikge1xuICAgICAgLmJvb2stY2FyZCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDAgNnB4IDZweCAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IE1lZGljaW5lQ29sID0gc3R5bGVkLmRpdmBcbiAgZmxleDogMCAwIDIwJTtcbiAgbWF4LXdpZHRoOiAyMCU7XG4gIHBhZGRpbmctbGVmdDogMTVweDtcbiAgcGFkZGluZy1yaWdodDogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEzMDBweCkge1xuICAgIGZsZXg6IDAgMCAyNSU7XG4gICAgbWF4LXdpZHRoOiAyNSU7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwOTlweCkgYW5kIChtaW4td2lkdGg6IDEwMjVweCkge1xuICAgIGZsZXg6IDAgMCAzMy4zMzMlO1xuICAgIG1heC13aWR0aDogMzMuMzMzJTtcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmbGV4OiAwIDAgMzMuMzMzJTtcbiAgICBtYXgtd2lkdGg6IDMzLjMzMyU7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNTYwcHgpIHtcbiAgICBmbGV4OiAwIDAgNTAlO1xuICAgIG1heC13aWR0aDogNTAlO1xuICAgIHBhZGRpbmctbGVmdDogNy41cHg7XG4gICAgcGFkZGluZy1yaWdodDogNy41cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxuYDtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XG5pbXBvcnQgZHluYW1pYyBmcm9tICduZXh0L2R5bmFtaWMnO1xuaW1wb3J0IHtcbiAgUHJvZHVjdHNSb3csXG4gIFByb2R1Y3RzQ29sLFxuICBCdXR0b25XcmFwcGVyLFxuICBMb2FkZXJXcmFwcGVyLFxuICBMb2FkZXJJdGVtLFxuICBQcm9kdWN0Q2FyZFdyYXBwZXIsXG59IGZyb20gJy4vcHJvZHVjdC1saXN0LnN0eWxlJztcbmltcG9ydCB7IENVUlJFTkNZIH0gZnJvbSAndXRpbHMvY29uc3RhbnQnO1xuaW1wb3J0IHsgdXNlUXVlcnksIE5ldHdvcmtTdGF0dXMgfSBmcm9tICdAYXBvbGxvL2NsaWVudCc7XG5pbXBvcnQgUGxhY2Vob2xkZXIgZnJvbSAnY29tcG9uZW50cy9wbGFjZWhvbGRlci9wbGFjZWhvbGRlcic7XG5pbXBvcnQgRmFkZSBmcm9tICdyZWFjdC1yZXZlYWwvRmFkZSc7XG5pbXBvcnQgTm9SZXN1bHRGb3VuZCBmcm9tICdjb21wb25lbnRzL25vLXJlc3VsdC9uby1yZXN1bHQnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnY29tcG9uZW50cy9idXR0b24vbG9hZG1vcmUtYnV0dG9uJztcbmltcG9ydCB7IEdFVF9QUk9EVUNUUyB9IGZyb20gJ2dyYXBocWwvcXVlcnkvcHJvZHVjdHMucXVlcnknO1xuXG5jb25zdCBFcnJvck1lc3NhZ2UgPSBkeW5hbWljKCgpID0+XG4gIGltcG9ydCgnY29tcG9uZW50cy9lcnJvci1tZXNzYWdlL2Vycm9yLW1lc3NhZ2UnKVxuKTtcblxuY29uc3QgR2VuZXJhbENhcmQgPSBkeW5hbWljKFxuICBpbXBvcnQoJ2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC1vbmUvcHJvZHVjdC1jYXJkLW9uZScpXG4pO1xuY29uc3QgQm9va0NhcmQgPSBkeW5hbWljKFxuICBpbXBvcnQoJ2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC10d28vcHJvZHVjdC1jYXJkLXR3bycpXG4pO1xuY29uc3QgRnVybml0dXJlQ2FyZCA9IGR5bmFtaWMoXG4gIGltcG9ydCgnY29tcG9uZW50cy9wcm9kdWN0LWNhcmQvcHJvZHVjdC1jYXJkLXRocmVlL3Byb2R1Y3QtY2FyZC10aHJlZScpXG4pO1xuY29uc3QgTWVkaWNpbmVDYXJkID0gZHluYW1pYyhcbiAgaW1wb3J0KCdjb21wb25lbnRzL3Byb2R1Y3QtY2FyZC9wcm9kdWN0LWNhcmQtZml2ZS9wcm9kdWN0LWNhcmQtZml2ZScpXG4pO1xuXG50eXBlIFByb2R1Y3RzUHJvcHMgPSB7XG4gIGRldmljZVR5cGU/OiB7XG4gICAgbW9iaWxlOiBib29sZWFuO1xuICAgIHRhYmxldDogYm9vbGVhbjtcbiAgICBkZXNrdG9wOiBib29sZWFuO1xuICB9O1xuICBmZXRjaExpbWl0PzogbnVtYmVyO1xuICBsb2FkTW9yZT86IGJvb2xlYW47XG4gIHR5cGU/OiBzdHJpbmc7XG59O1xuZXhwb3J0IGNvbnN0IFByb2R1Y3RzOiBSZWFjdC5GQzxQcm9kdWN0c1Byb3BzPiA9ICh7XG4gIGRldmljZVR5cGUsXG4gIGZldGNoTGltaXQgPSAxOCxcbiAgbG9hZE1vcmUgPSB0cnVlLFxuICB0eXBlLFxufSkgPT4ge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgY29uc3QgeyBkYXRhLCBlcnJvciwgbG9hZGluZywgZmV0Y2hNb3JlLCBuZXR3b3JrU3RhdHVzIH0gPSB1c2VRdWVyeShcbiAgICBHRVRfUFJPRFVDVFMsXG4gICAge1xuICAgICAgdmFyaWFibGVzOiB7XG4gICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgIHRleHQ6IHJvdXRlci5xdWVyeS50ZXh0LFxuICAgICAgICBjYXRlZ29yeTogcm91dGVyLnF1ZXJ5LmNhdGVnb3J5LFxuICAgICAgICBvZmZzZXQ6IDAsXG4gICAgICAgIGxpbWl0OiBmZXRjaExpbWl0LFxuICAgICAgfSxcbiAgICAgIG5vdGlmeU9uTmV0d29ya1N0YXR1c0NoYW5nZTogdHJ1ZSxcbiAgICB9XG4gICk7XG4gIGNvbnN0IGxvYWRpbmdNb3JlID0gbmV0d29ya1N0YXR1cyA9PT0gTmV0d29ya1N0YXR1cy5mZXRjaE1vcmU7XG5cbiAgaWYgKGVycm9yKSByZXR1cm4gPEVycm9yTWVzc2FnZSBtZXNzYWdlPXtlcnJvci5tZXNzYWdlfSAvPjtcbiAgaWYgKGxvYWRpbmcgJiYgIWxvYWRpbmdNb3JlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxMb2FkZXJXcmFwcGVyPlxuICAgICAgICA8TG9hZGVySXRlbT5cbiAgICAgICAgICA8UGxhY2Vob2xkZXIgdW5pcXVlS2V5PVwiMVwiIC8+XG4gICAgICAgIDwvTG9hZGVySXRlbT5cbiAgICAgICAgPExvYWRlckl0ZW0+XG4gICAgICAgICAgPFBsYWNlaG9sZGVyIHVuaXF1ZUtleT1cIjJcIiAvPlxuICAgICAgICA8L0xvYWRlckl0ZW0+XG4gICAgICAgIDxMb2FkZXJJdGVtPlxuICAgICAgICAgIDxQbGFjZWhvbGRlciB1bmlxdWVLZXk9XCIzXCIgLz5cbiAgICAgICAgPC9Mb2FkZXJJdGVtPlxuICAgICAgPC9Mb2FkZXJXcmFwcGVyPlxuICAgICk7XG4gIH1cblxuICBpZiAoIWRhdGEgfHwgIWRhdGEucHJvZHVjdHMgfHwgZGF0YS5wcm9kdWN0cy5pdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gPE5vUmVzdWx0Rm91bmQgLz47XG4gIH1cbiAgY29uc3QgaGFuZGxlTG9hZE1vcmUgPSAoKSA9PiB7XG4gICAgZmV0Y2hNb3JlKHtcbiAgICAgIHZhcmlhYmxlczoge1xuICAgICAgICBvZmZzZXQ6IE51bWJlcihkYXRhLnByb2R1Y3RzLml0ZW1zLmxlbmd0aCksXG4gICAgICAgIGxpbWl0OiBmZXRjaExpbWl0LFxuICAgICAgfSxcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCByZW5kZXJDYXJkID0gKHByb2R1Y3RUeXBlLCBwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvZHVjdFR5cGUpIHtcbiAgICAgIGNhc2UgJ2Jvb2snOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxCb29rQ2FyZFxuICAgICAgICAgICAgdGl0bGU9e3Byb3BzLnRpdGxlfVxuICAgICAgICAgICAgaW1hZ2U9e3Byb3BzLmltYWdlfVxuICAgICAgICAgICAgbmFtZT17cHJvcHM/LmF1dGhvcj8ubmFtZX1cbiAgICAgICAgICAgIGRhdGE9e3Byb3BzfVxuICAgICAgICAgICAgZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgcm91dGVyLnB1c2goJy9wcm9kdWN0L1tzbHVnXScsIGAvcHJvZHVjdC8ke3Byb3BzLnNsdWd9YCk7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgY2FzZSAnbWVkaWNpbmUnOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxNZWRpY2luZUNhcmRcbiAgICAgICAgICAgIHRpdGxlPXtwcm9wcy50aXRsZX1cbiAgICAgICAgICAgIGN1cnJlbmN5PXtDVVJSRU5DWX1cbiAgICAgICAgICAgIGltYWdlPXtwcm9wcy5pbWFnZX1cbiAgICAgICAgICAgIHByaWNlPXtwcm9wcy5wcmljZX1cbiAgICAgICAgICAgIHdlaWdodD17cHJvcHMudW5pdH1cbiAgICAgICAgICAgIGRhdGE9e3Byb3BzfVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdmdXJuaXR1cmUnOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxGdXJuaXR1cmVDYXJkXG4gICAgICAgICAgICB0aXRsZT17cHJvcHMudGl0bGV9XG4gICAgICAgICAgICBpbWFnZT17cHJvcHMuZ2FsbGVyeVswXS51cmx9XG4gICAgICAgICAgICBkaXNjb3VudEluUGVyY2VudD17cHJvcHMuZGlzY291bnRJblBlcmNlbnR9XG4gICAgICAgICAgICBkYXRhPXtwcm9wc31cbiAgICAgICAgICAgIGRldmljZVR5cGU9e2RldmljZVR5cGV9XG4gICAgICAgICAgLz5cbiAgICAgICAgKTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPEdlbmVyYWxDYXJkXG4gICAgICAgICAgICB0aXRsZT17cHJvcHMudGl0bGV9XG4gICAgICAgICAgICBkZXNjcmlwdGlvbj17cHJvcHMuZGVzY3JpcHRpb259XG4gICAgICAgICAgICBpbWFnZT17cHJvcHMuaW1hZ2V9XG4gICAgICAgICAgICB3ZWlnaHQ9e3Byb3BzLnVuaXR9XG4gICAgICAgICAgICBjdXJyZW5jeT17Q1VSUkVOQ1l9XG4gICAgICAgICAgICBwcmljZT17cHJvcHMucHJpY2V9XG4gICAgICAgICAgICBzYWxlUHJpY2U9e3Byb3BzLnNhbGVQcmljZX1cbiAgICAgICAgICAgIGRpc2NvdW50SW5QZXJjZW50PXtwcm9wcy5kaXNjb3VudEluUGVyY2VudH1cbiAgICAgICAgICAgIGRhdGE9e3Byb3BzfVxuICAgICAgICAgICAgZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFByb2R1Y3RzUm93PlxuICAgICAgICB7ZGF0YS5wcm9kdWN0cy5pdGVtcy5tYXAoKGl0ZW06IGFueSwgaW5kZXg6IG51bWJlcikgPT4gKFxuICAgICAgICAgIDxQcm9kdWN0c0NvbFxuICAgICAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgICAgIHN0eWxlPXt0eXBlID09PSAnZ3JvY2VyeScgPyB7IHBhZGRpbmdMZWZ0OiAwLCBwYWRkaW5nUmlnaHQ6IDEsbWFyZ2luUmlnaHQ6NiB9IDoge319XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByb2R1Y3RDYXJkV3JhcHBlcj5cbiAgICAgICAgICAgICAgPEZhZGVcbiAgICAgICAgICAgICAgICBkdXJhdGlvbj17ODAwfVxuICAgICAgICAgICAgICAgIGRlbGF5PXtpbmRleCAqIDEwfVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogJzEwMCUnIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7cmVuZGVyQ2FyZCh0eXBlLCBpdGVtKX1cbiAgICAgICAgICAgICAgPC9GYWRlPlxuICAgICAgICAgICAgPC9Qcm9kdWN0Q2FyZFdyYXBwZXI+XG4gICAgICAgICAgPC9Qcm9kdWN0c0NvbD5cbiAgICAgICAgKSl9XG4gICAgICA8L1Byb2R1Y3RzUm93PlxuICAgICAge2xvYWRNb3JlICYmIGRhdGEucHJvZHVjdHMuaGFzTW9yZSAmJiAoXG4gICAgICAgIDxCdXR0b25XcmFwcGVyPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ01vcmV9XG4gICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGZvbnRTaXplOiAxNCxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBib3JkZXI9XCIxcHggc29saWQgI2YxZjFmMVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2UgaWQ9XCJsb2FkTW9yZUJ1dHRvblwiIGRlZmF1bHRNZXNzYWdlPVwiTG9hZCBNb3JlXCIgLz5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9CdXR0b25XcmFwcGVyPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn07XG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0cztcbiIsIi8qKioqKioqKioqKiogQ09OU1RBTlRTICoqKioqKioqKioqL1xuZXhwb3J0IGNvbnN0IENVUlJFTkNZID0gJyQnO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==