exports.ids = [13];
exports.modules = {

/***/ "./src/components/image/image.tsx":
/*!****************************************!*\
  !*** ./src/components/image/image.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image */ "react-image");
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-placeholder.png */ "./src/components/image/product-placeholder.png");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\image\\image.tsx";




const Placeholder = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
  src: _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__["default"],
  alt: "product img loader"
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 27
}, undefined);

function Image({
  url,
  alt = "placeholder",
  unloader,
  loader,
  className,
  style
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_image__WEBPACK_IMPORTED_MODULE_2__["Img"], {
    draggable: false,
    style: style,
    src: url,
    alt: alt,
    loader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 15
    }, this),
    unloader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 17
    }, this),
    className: className
  }, url, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./src/components/image/product-placeholder.png":
/*!******************************************************!*\
  !*** ./src/components/image/product-placeholder.png ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAADwCAYAAADxXop4AAAHPElEQVR4Xu3d23La2BaGUREOPpTf/0mNwYCsvthFtoMdix+WxBIZ46qrsjpxutpfNOXlmVnXdV0DEPjVdwDglHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcQWfQco53A4/P7n+XzezGazH89DrYRjQF3XNbvdrtntdk3btl9+fD6fN4vFonl8fBQRJmXWdV3Xd4jcfr9v3t7emnP+885ms+bh4aF5fHzsOwpVEI4BbDab5v39ve/YF8vlsnl+fvb0QfW8HC3s0mg0n55SoHbCUdB+v784Gkf7/b7Zbrd9x+CmhKOgzWbTd+Qs7+/vZ70bgVsRjkJ2u13z8fHRd+wsXdd56qBqwlHIfr/vOxIp/fNBScJRSOlP9I+PD+MK1RKOin13aQxqIBwFeDL40+er9dwn4SjAha3/a9u2Wa/X7qPcOeEoZIh4zOfzviNV6bru9zX74/focJ+Eo5Dlctl3JDLF755dr9d/vJd5e3szttwp4SikdDhWq1XfkapsNptvI7Fer4vdb6EewlHIcrksNlrMZrNJhWO32/31qn3Xdc16vfYC+c4IR0FPT099R87y9PQ0mTGlbdveq/bnnGFahKOgxWLRPD8/9x370Wq1mszTRtd1zevr61lPE7vdzjX6OyIcha1Wq4vj8fDwcPG/ewvnRuNou90Wv2HLbVjkM5DD4dBsNpuzbn/++vWreXp6Kv6CdUhvb28Xfbl1Nps1Ly8vxd4HcRvCMbDdbtccDodmv99/+dN5uVw2y+VyMqPJ0W63u+qC13w+b15eXibzHoevhGNkbdtO+k/bw+HQvL6+9h3rtVgsmpeXl75jVMo7jpFNORofHx/Ner3uO3aW4yjHNAkHZxniPsb7+/tF70m4PeGoWMlP0mud+6I3NdTPy7CEo1Kl3iWUsN1uB3sySO6CUA/hqNDxu0zbtr35pakxtq4f48F0CEeFttvt728M2263N3uUb9v2qi+7Jsb8tbiecFTmcDh8+YaxW3xCfd6tMRY7PKZDOCpy/GQ9dYuR5XS3xljs8JgG4ajI5xHlux8b6xP5b7s1xmKHR/2EoxLfjSinxhhZftqtMZYh7oxQlnBU4G8jyqmhR5aa9mbU9LHwlXBU4KcR5dRQI0uN9yns8KiXcNzYOSPKqXOeTlK1RePIDo86CccNnTuinCo9shwvm9Wq9o/vXyQcN5SMKKdKjSxTuDtxizsl/Ew4buSSEeXUJU8rnx0Oh6t/jrEc/4Y46iAcN3DpiHLqmpGl5G6NsdjhUQ/huIFrRpRTl4wsU74nYYdHHYRjZCVGlFPp08vUd2BM/eO/B8IxolIjyqlkZBlyt8ZYarxz8q8RjhGVHFFOnTOyjLFbYyx2eNyWcIykbdviI8qpn55m7nHfxT3+nqZCOEYyxv/gfxtZ7vkexBTuodwj4RjBOWNEKd/9WrfarTEWOzzGJxwDS15clvL56ebWuzXGYofHuIRjYGOMKKeOsapht8ZYpnw3ZYr8FZAD2m63oz9tfDabzf65T6TVatU8Pz/3HeNKnjgGcosR5dS/Fo3GDo/RCMdAbjGi8D92eAxPOAYw5ldR+J4dHsMSjsJqGFG477srNRCOwowo9bDDYzjCUZARpT52eAxDOAoxotTLDo/yhKMQI0rd7PAoSzgKMKLUzw6PsoTjSkaU6bDDoxzhuJIRZVrs8ChDOK5gRJkmOzyuJxwXMqJMmx0e1xGOC3ncnT47PC4nHBcwotwHOzwuJxwhI8p9advWzdILCEfIiHJ/7PDICUfAiHK/7PDILPoO8KfHx8e+I0yUF6Xns3MUiBlVgJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOI/Qe0gyoTzEMWZQAAAABJRU5ErkJggg==");

/***/ }),

/***/ "./src/components/product-card/product-card-three/product-card-three.tsx":
/*!*******************************************************************************!*\
  !*** ./src/components/product-card/product-card-three/product-card-three.tsx ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_image_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/image/image */ "./src/components/image/image.tsx");
/* harmony import */ var _product_card_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../product-card.style */ "./src/components/product-card/product-card.style.tsx");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_modal_use_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! contexts/modal/use-modal */ "./src/contexts/modal/use-modal.ts");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_6__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\product-card\\product-card-three\\product-card-three.tsx";
// product card for furniture






const QuickViewMobile = next_dynamic__WEBPACK_IMPORTED_MODULE_6___default()(() => __webpack_require__.e(/*! import() */ 8).then(__webpack_require__.bind(null, /*! features/quick-view/quick-view-mobile */ "./src/features/quick-view/quick-view-mobile.tsx")), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! features/quick-view/quick-view-mobile */ "./src/features/quick-view/quick-view-mobile.tsx")],
    modules: ['features/quick-view/quick-view-mobile']
  }
});

const ProductCard = ({
  title,
  image,
  discountInPercent,
  data,
  deviceType
}) => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_4__["useRouter"])();
  const [showModal, hideModal] = Object(contexts_modal_use_modal__WEBPACK_IMPORTED_MODULE_5__["useModal"])(() => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(QuickViewMobile, {
    modalProps: data,
    hideModal: hideModal,
    deviceType: deviceType
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 7
  }, undefined), {
    onClose: () => {
      const {
        pathname,
        query,
        asPath
      } = router;
      const as = asPath;
      router.push({
        pathname,
        query
      }, as, {
        shallow: true
      });
    }
  });

  const handleQuickViewModal = () => {
    const {
      pathname,
      query
    } = router;
    const as = `/product/${data.slug}`;

    if (pathname === '/product/[slug]') {
      router.push(pathname, as);

      if (false) {}

      return;
    }

    showModal();
    router.push({
      pathname,
      query
    }, {
      pathname: as
    }, {
      shallow: true
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_3__["ProductCardWrapper"], {
    onClick: handleQuickViewModal,
    className: "furniture-card",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_3__["ProductImageWrapper"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_image_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
        url: image,
        className: "product-image",
        style: {
          position: 'relative'
        },
        alt: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 9
      }, undefined), discountInPercent ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_3__["DiscountPercent"], {
        children: [discountInPercent, "%"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 11
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_3__["ProductInfo"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_3__["ProductName"], {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 98,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ProductCard);

/***/ }),

/***/ "./src/components/product-card/product-card.style.tsx":
/*!************************************************************!*\
  !*** ./src/components/product-card/product-card.style.tsx ***!
  \************************************************************/
/*! exports provided: ProductCardWrapper, ProductImageWrapper, SaleTag, DiscountPercent, ProductInfo, ButtonText, BookImageWrapper, BookInfo, ProductName, AuthorInfo, PriceWrapper, Price, DiscountedPrice, BookCardWrapper, FoodCardWrapper, FoodImageWrapper, ProductMeta, DeliveryOpt, Category, Duration */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardWrapper", function() { return ProductCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductImageWrapper", function() { return ProductImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleTag", function() { return SaleTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPercent", function() { return DiscountPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfo", function() { return ProductInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonText", function() { return ButtonText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookImageWrapper", function() { return BookImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookInfo", function() { return BookInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductName", function() { return ProductName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorInfo", function() { return AuthorInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PriceWrapper", function() { return PriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Price", function() { return Price; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountedPrice", function() { return DiscountedPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookCardWrapper", function() { return BookCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodCardWrapper", function() { return FoodCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodImageWrapper", function() { return FoodImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductMeta", function() { return ProductMeta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryOpt", function() { return DeliveryOpt; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return Category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Duration", function() { return Duration; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_2__);



const StyledBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__StyledBox",
  componentId: "sc-1j4qmg9-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  py: [30, 50],
  px: ['1rem', 0]
}), {
  width: '100%'
});
const ProductCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductCardWrapper",
  componentId: "sc-1j4qmg9-1"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  height: '100%',
  width: '100%',
  backgroundColor: 'white',
  position: 'relative',
  fontFamily: 'inherit',
  borderRadius: 'base',
  cursor: 'pointer',
  ':hover .hidd': {
    opacity: '1 !important'
  },
  ':hover .onhover': {
    display: 'none !important'
  },
  '.hidd': {
    width: '100%',
    borderRadius: '15px',
    padding: '5px',
    background: '#F39C12',
    border: '0px solid',
    marginTop: '5px'
  },
  '.card-counter': {
    '@media (max-width: 767px)': {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      position: 'absolute',
      bottom: 0,
      right: 0
    }
  }
}));
const ProductImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductImageWrapper",
  componentId: "sc-1j4qmg9-2"
})(["height:240px;padding:5px;position:relative;text-align:center;display:flex;overflow:hidden;align-items:center;justify-content:center;img{max-width:170%;max-height:100%;display:inline-block;}@media (max-width:640px){height:145px;}"]);
const SaleTag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__SaleTag",
  componentId: "sc-1j4qmg9-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";padding:0 10px;line-height:24px;border-radius:", ";display:inline-block;position:absolute;top:10px;right:10px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const DiscountPercent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountPercent",
  componentId: "sc-1j4qmg9-4"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:24px;background-color:", ";padding-left:10px;padding-right:10px;position:relative;display:inline-block;position:absolute;top:15px;right:15px;border-radius:", ";z-index:2;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const ProductInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductInfo",
  componentId: "sc-1j4qmg9-5"
})(["padding:20px 25px 30px;@media (max-width:990px){padding:15px 20px;min-height:123px;}.product-title{font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;@media (max-width:767px){font-size:14px;margin:0 0 5px 0;}}.product-weight{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}}.product-meta{margin-top:30px;display:flex;align-items:center;justify-content:space-between;position:relative;@media (max-width:767px){min-height:36px;}.productPriceWrapper{position:relative;display:flex;width:100%;flex-direction:column;align-items:flex-start;.hidd{color:", ";opacity:0;.btn-text{padding:0 0 0 6px;@media (max-width:767px){display:none;}}&:hover{color:", ";background-color:", ";border-color:", ";}}.product-price{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}}.discountedPrice{font-family:", ";font-size:", "px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;position:absolute;top:-20px;left:-4px;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}}}}@media (max-width:767px){.quantity{width:32px;height:90px;display:block;flex-shrink:0;position:absolute;bottom:15px;right:15px;z-index:1;box-shadow:0 10px 20px rgba(0,0,0,0.16);}button{width:100%;height:27px;}.incBtn{top:0;justify-content:center;}.decBtn{top:auto;bottom:0;justify-content:center;}input[type='number']{left:0;font-size:calc(", "px - 1px);height:calc(100% - 54px);position:absolute;top:27px;width:100%;color:", ";}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ButtonText",
  componentId: "sc-1j4qmg9-6"
})(["@media (max-width:767px){display:none;}"]);
const BookImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookImageWrapper",
  componentId: "sc-1j4qmg9-7"
})(["height:275px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;margin-bottom:15px;img{max-width:100%;max-height:100%;display:inline-block;}@media (max-width:767px){height:215px;}", "{top:0;right:0;}"], DiscountPercent);
const BookInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookInfo",
  componentId: "sc-1j4qmg9-8"
})(["padding:0;width:100%;display:flex;flex-direction:column;align-items:center;@media (max-width:767px){padding:15px 0px 0px;}"]);
const ProductName = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ProductName",
  componentId: "sc-1j4qmg9-9"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center;display:block;&:only-child{margin:0;}@media (max-width:767px){font-size:calc(", "px - 1px);margin:0 0 5px 0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const AuthorInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__AuthorInfo",
  componentId: "sc-1j4qmg9-10"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13')); // export const AddCartBox = styled.div`
//   width: calc(100% - 40px);
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: center;
//   padding: 20px;
//   border-radius: 6px;
//   background-color: #ffffff;
//   box-shadow: 0 10px 20px rgba(0, 0, 0, 0.16);
//   position: absolute;
//   top: 50%;
//   left: 50%;
//   opacity: 0;
//   transition: all 0.3s;
//   .cart-button {
//     border-radius: 18px;
//     height: 36px;
//     padding-left: 17px;
//     padding-right: 17px;
//     font-size: ${themeGet('fontSizes.1', '13')} px;
//     font-weight: ${themeGet('fontWeights.bold', '700')};
//     @media (max-width: 767px) {
//       width: 32px;
//       height: 32px;
//       padding: 0;
//       border-radius: 50%;
//     }
//     .btn-text {
//       padding: 0 0 0 6px;
//       @media (max-width: 767px) {
//         display: none;
//       }
//     }
//     &:hover {
//       color: #fff;
//       background-color: ${themeGet('colors.primary.regular', '#F39C12')};
//       border-color: #F39C12;
//     }
//     svg {
//       fill: currentColor;
//     }
//   }
// `;

const PriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__PriceWrapper",
  componentId: "sc-1j4qmg9-11"
})(["position:relative;display:flex;flex-direction:column;align-items:flex-start;margin-bottom:15px;"]);
const Price = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Price",
  componentId: "sc-1j4qmg9-12"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const DiscountedPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountedPrice",
  componentId: "sc-1j4qmg9-13"
})(["font-family:", ";font-size:", " px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;margin-bottom:5px;margin-left:-4px;z-index:2;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'));
const BookCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookCardWrapper",
  componentId: "sc-1j4qmg9-14"
})(["height:100%;width:100%;padding:30px;background-color:", ";position:relative;font-family:", ";border-radius:", ";cursor:pointer;@media (max-width:767px){padding:15px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodCardWrapper",
  componentId: "sc-1j4qmg9-15"
})(["height:100%;width:100%;padding:0;background-color:", ";position:relative;font-family:", ";border-radius:", ";overflow:hidden;cursor:pointer;display:flex;flex-direction:column;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodImageWrapper",
  componentId: "sc-1j4qmg9-16"
})(["height:230px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;flex-shrink:0;img{width:100%;height:100%;object-fit:cover;}&:after{content:'';width:100%;height:100%;display:flex;background-color:rgba(0,0,0,0.1);position:absolute;top:0;left:0;z-index:1;}@media (max-width:767px){height:145px;}"]);
const ProductMeta = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductMeta",
  componentId: "sc-1j4qmg9-17"
})(["margin-top:20px;display:flex;align-items:center;justify-content:space-between;"]);
const DeliveryOpt = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DeliveryOpt",
  componentId: "sc-1j4qmg9-18"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";white-space:nowrap;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const Category = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Category",
  componentId: "sc-1j4qmg9-19"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const Duration = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Duration",
  componentId: "sc-1j4qmg9-20"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";border-radius:", ";padding-top:0;padding-bottom:0;padding-left:20px;padding-right:20px;height:36px;width:auto;border:0;display:flex;align-items:center;justify-content:center;white-space:nowrap;@media (max-width:600px){padding-left:10px;padding-right:10px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.big', '18px'));

/***/ }),

/***/ "./src/contexts/modal/use-modal.ts":
/*!*****************************************!*\
  !*** ./src/contexts/modal/use-modal.ts ***!
  \*****************************************/
/*! exports provided: useModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useModal", function() { return useModal; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modal_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal.context */ "./src/contexts/modal/modal.context.ts");


/**
 * Callback types provided for descriptive type-hints
 */

/**
 * Utility function to generate unique number per component instance
 */
const generateModalKey = (() => {
  let count = 0;
  return () => `${++count}`;
})();
/**
 * Check whether the argument is a stateless component.
 *
 * We take advantage of the stateless nature of functional components to be
 * inline the rendering of the modal component as part of another immutable
 * component.
 *
 * This is necessary for allowing the modal to update based on the inputs passed
 * as the second argument to useModal without unmounting the previous version of
 * the modal component.
 */


const isFunctionalComponent = Component => {
  const prototype = Component.prototype;
  return !prototype || !prototype.isReactComponent;
};
/**
 * React hook for showing modal windows
 */


const useModal = (component, options = {}) => {
  if (!isFunctionalComponent(component)) {
    throw new Error('Only stateless components can be used as an argument to useModal. You have probably passed a class component where a function was expected.');
  }

  const key = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(generateModalKey, []);
  const modal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(() => component, options.inputs);
  const context = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_modal_context__WEBPACK_IMPORTED_MODULE_1__["ModalContext"]);
  const showModal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => context.showModal(key, modal, options), [context.showModal]);
  const hideModal = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => context.hideModal(key), [context.hideModal, key]); // const [isShown, setShown] = useState<boolean>(false);
  // const showModal = useCallback(() => setShown(true), []);
  // const hideModal = useCallback(() => setShown(false), []);
  // useEffect(() => {
  //   if (isShown) {
  //     context.showModal(key, modal);
  //   } else {
  //     context.hideModal(key);
  //   }
  //   // Hide modal when parent component unmounts
  //   return () => context.hideModal(key);
  // }, [modal, isShown]);

  return [showModal, hideModal];
}; // export default useModal;
/// uses
// import useModal from "use-modal";
// import ModalProvider from "modal.provider";
// import Modal from "react-modal"; // It can be any modal
// const MyModal = memo(
//   ({ isOpen, onClose, title, description, closeBtnLabel }) => (
//     <Modal isOpen={isOpen} onRequestClose={onClose}>
//       <h2>{title}</h2>
//       <div>{description}</div>
//       <button onClick={onClose}>{closeBtnLabel}</button>
//     </Modal>
//   )
// );
// const SomePage = memo(() => {
//   const [showModal, hideModal] = useModal(MyModal, {
//     title: "My Test Modal",
//     description: "I Like React Hooks",
//     closeBtnLabel: "Close"
//   });
//   return (
//     <>
//       <h1>Test Page</h1>
//       <button onClick={showModal}>Show Modal</button>
//     </>
//   );
// });
// const App = () => (
//   <ModalProvider>
//     <SomePage />
//   </ModalProvider>
// );
// useModal(<ModalComponent: Function|>, <modalProps: Object>, <onClose: Function>): [showModal: Function, hideModal: Function]
// Param	Type	Description
// ModalComponent	Function	It can be any react component that you want to use for show modal
// modalProps	Object	Props that you want to pass to your modal component
// showModal	Function	It is function for show your modal, you can pass any dynamic props to this function
// hideModal	Function	It is function for hide your modal, you can pass any dynamic props to this function
// onClose	Function	It callback will be triggered after modal window closes
// showModal(dynamicModalProps: Object)
// Param	Type	Description
// dynamicModalProps	Object	Dynamic props that you want to pass to your modal component

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbWFnZS9pbWFnZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvaW1hZ2UvcHJvZHVjdC1wbGFjZWhvbGRlci5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC10aHJlZS9wcm9kdWN0LWNhcmQtdGhyZWUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3Byb2R1Y3QtY2FyZC9wcm9kdWN0LWNhcmQuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb250ZXh0cy9tb2RhbC91c2UtbW9kYWwudHMiXSwibmFtZXMiOlsiUGxhY2Vob2xkZXIiLCJwbGFjZWhvbGRlciIsIkltYWdlIiwidXJsIiwiYWx0IiwidW5sb2FkZXIiLCJsb2FkZXIiLCJjbGFzc05hbWUiLCJzdHlsZSIsIlF1aWNrVmlld01vYmlsZSIsImR5bmFtaWMiLCJQcm9kdWN0Q2FyZCIsInRpdGxlIiwiaW1hZ2UiLCJkaXNjb3VudEluUGVyY2VudCIsImRhdGEiLCJkZXZpY2VUeXBlIiwicm91dGVyIiwidXNlUm91dGVyIiwic2hvd01vZGFsIiwiaGlkZU1vZGFsIiwidXNlTW9kYWwiLCJvbkNsb3NlIiwicGF0aG5hbWUiLCJxdWVyeSIsImFzUGF0aCIsImFzIiwicHVzaCIsInNoYWxsb3ciLCJoYW5kbGVRdWlja1ZpZXdNb2RhbCIsInNsdWciLCJwb3NpdGlvbiIsIlN0eWxlZEJveCIsInN0eWxlZCIsImRpdiIsImNzcyIsInB5IiwicHgiLCJ3aWR0aCIsIlByb2R1Y3RDYXJkV3JhcHBlciIsImhlaWdodCIsImJhY2tncm91bmRDb2xvciIsImZvbnRGYW1pbHkiLCJib3JkZXJSYWRpdXMiLCJjdXJzb3IiLCJvcGFjaXR5IiwiZGlzcGxheSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwibWFyZ2luVG9wIiwiZmxleERpcmVjdGlvbiIsImJvdHRvbSIsInJpZ2h0IiwiUHJvZHVjdEltYWdlV3JhcHBlciIsIlNhbGVUYWciLCJzcGFuIiwidGhlbWVHZXQiLCJEaXNjb3VudFBlcmNlbnQiLCJQcm9kdWN0SW5mbyIsIkJ1dHRvblRleHQiLCJCb29rSW1hZ2VXcmFwcGVyIiwiQm9va0luZm8iLCJQcm9kdWN0TmFtZSIsIkF1dGhvckluZm8iLCJQcmljZVdyYXBwZXIiLCJQcmljZSIsIkRpc2NvdW50ZWRQcmljZSIsIkJvb2tDYXJkV3JhcHBlciIsIkZvb2RDYXJkV3JhcHBlciIsIkZvb2RJbWFnZVdyYXBwZXIiLCJQcm9kdWN0TWV0YSIsIkRlbGl2ZXJ5T3B0IiwiQ2F0ZWdvcnkiLCJEdXJhdGlvbiIsImdlbmVyYXRlTW9kYWxLZXkiLCJjb3VudCIsImlzRnVuY3Rpb25hbENvbXBvbmVudCIsIkNvbXBvbmVudCIsInByb3RvdHlwZSIsImlzUmVhY3RDb21wb25lbnQiLCJjb21wb25lbnQiLCJvcHRpb25zIiwiRXJyb3IiLCJrZXkiLCJ1c2VNZW1vIiwibW9kYWwiLCJpbnB1dHMiLCJjb250ZXh0IiwidXNlQ29udGV4dCIsIk1vZGFsQ29udGV4dCIsInVzZUNhbGxiYWNrIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOztBQUNBLE1BQU1BLFdBQVcsR0FBRyxtQkFBTTtBQUFLLEtBQUcsRUFBRUMsZ0VBQVY7QUFBdUIsS0FBRyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMUI7O0FBQ2UsU0FBU0MsS0FBVCxDQUFlO0FBQzVCQyxLQUQ0QjtBQUU1QkMsS0FBRyxHQUFHLGFBRnNCO0FBRzVCQyxVQUg0QjtBQUk1QkMsUUFKNEI7QUFLNUJDLFdBTDRCO0FBTTVCQztBQU40QixDQUFmLEVBY1o7QUFDRCxzQkFDRSxxRUFBQywrQ0FBRDtBQUNFLGFBQVMsRUFBRSxLQURiO0FBRUUsU0FBSyxFQUFFQSxLQUZUO0FBR0UsT0FBRyxFQUFFTCxHQUhQO0FBS0UsT0FBRyxFQUFFQyxHQUxQO0FBTUUsVUFBTSxlQUFFLHFFQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5WO0FBT0UsWUFBUSxlQUFFLHFFQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVBaO0FBUUUsYUFBUyxFQUFFRztBQVJiLEtBSU9KLEdBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBWUQsQzs7Ozs7Ozs7Ozs7O0FDL0JEO0FBQWUsK0VBQWdCLDQvRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBL0I7QUFDQTtBQUNBO0FBQ0E7QUFPQTtBQUNBO0FBQ0E7QUFDQSxNQUFNTSxlQUFlLEdBQUdDLG1EQUFPLENBQUMsTUFDOUIsNktBRDZCO0FBQUE7QUFBQSx3Q0FDdEIsOEZBRHNCO0FBQUEsY0FDdEIsdUNBRHNCO0FBQUE7QUFBQSxFQUEvQjs7QUFXQSxNQUFNQyxXQUF1QyxHQUFHLENBQUM7QUFDL0NDLE9BRCtDO0FBRS9DQyxPQUYrQztBQUcvQ0MsbUJBSCtDO0FBSS9DQyxNQUorQztBQUsvQ0M7QUFMK0MsQ0FBRCxLQU0xQztBQUNKLFFBQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxRQUFNLENBQUNDLFNBQUQsRUFBWUMsU0FBWixJQUF5QkMseUVBQVEsQ0FDckMsbUJBQ0UscUVBQUMsZUFBRDtBQUNFLGNBQVUsRUFBRU4sSUFEZDtBQUVFLGFBQVMsRUFBRUssU0FGYjtBQUdFLGNBQVUsRUFBRUo7QUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRm1DLEVBUXJDO0FBQ0VNLFdBQU8sRUFBRSxNQUFNO0FBQ2IsWUFBTTtBQUFFQyxnQkFBRjtBQUFZQyxhQUFaO0FBQW1CQztBQUFuQixVQUE4QlIsTUFBcEM7QUFDQSxZQUFNUyxFQUFFLEdBQUdELE1BQVg7QUFDQVIsWUFBTSxDQUFDVSxJQUFQLENBQ0U7QUFDRUosZ0JBREY7QUFFRUM7QUFGRixPQURGLEVBS0VFLEVBTEYsRUFNRTtBQUNFRSxlQUFPLEVBQUU7QUFEWCxPQU5GO0FBVUQ7QUFkSCxHQVJxQyxDQUF2Qzs7QUF5QkEsUUFBTUMsb0JBQW9CLEdBQUcsTUFBTTtBQUNqQyxVQUFNO0FBQUVOLGNBQUY7QUFBWUM7QUFBWixRQUFzQlAsTUFBNUI7QUFDQSxVQUFNUyxFQUFFLEdBQUksWUFBV1gsSUFBSSxDQUFDZSxJQUFLLEVBQWpDOztBQUNBLFFBQUlQLFFBQVEsS0FBSyxpQkFBakIsRUFBb0M7QUFDbENOLFlBQU0sQ0FBQ1UsSUFBUCxDQUFZSixRQUFaLEVBQXNCRyxFQUF0Qjs7QUFDQSxpQkFBbUMsRUFFbEM7O0FBQ0Q7QUFDRDs7QUFDRFAsYUFBUztBQUNURixVQUFNLENBQUNVLElBQVAsQ0FDRTtBQUNFSixjQURGO0FBRUVDO0FBRkYsS0FERixFQUtFO0FBQ0VELGNBQVEsRUFBRUc7QUFEWixLQUxGLEVBUUU7QUFDRUUsYUFBTyxFQUFFO0FBRFgsS0FSRjtBQVlELEdBdkJEOztBQXdCQSxzQkFDRSxxRUFBQyxzRUFBRDtBQUNFLFdBQU8sRUFBRUMsb0JBRFg7QUFFRSxhQUFTLEVBQUMsZ0JBRlo7QUFBQSw0QkFJRSxxRUFBQyx1RUFBRDtBQUFBLDhCQUNFLHFFQUFDLDhEQUFEO0FBQ0UsV0FBRyxFQUFFaEIsS0FEUDtBQUVFLGlCQUFTLEVBQUMsZUFGWjtBQUdFLGFBQUssRUFBRTtBQUFFa0Isa0JBQVEsRUFBRTtBQUFaLFNBSFQ7QUFJRSxXQUFHLEVBQUVuQjtBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFPR0UsaUJBQWlCLGdCQUNoQixxRUFBQyxtRUFBRDtBQUFBLG1CQUFrQkEsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFEZ0IsR0FFZCxJQVROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQWVFLHFFQUFDLCtEQUFEO0FBQUEsNkJBQ0UscUVBQUMsK0RBQUQ7QUFBQSxrQkFBY0Y7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFCRCxDQTlFRDs7QUFnRmVELDBFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3hHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQSxNQUFNcUIsU0FBUyxHQUFHQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ2JDLHlEQUFHLENBQUM7QUFDRkMsSUFBRSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FERjtBQUVGQyxJQUFFLEVBQUUsQ0FBQyxNQUFELEVBQVMsQ0FBVDtBQUZGLENBQUQsQ0FEVSxFQUtiO0FBQ0VDLE9BQUssRUFBRTtBQURULENBTGEsQ0FBZjtBQVVPLE1BQU1DLGtCQUFrQixHQUFHTix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQzdCQyx5REFBRyxDQUFDO0FBQ0ZLLFFBQU0sRUFBRSxNQUROO0FBRUZGLE9BQUssRUFBRSxNQUZMO0FBR0ZHLGlCQUFlLEVBQUUsT0FIZjtBQUlGVixVQUFRLEVBQUUsVUFKUjtBQUtGVyxZQUFVLEVBQUUsU0FMVjtBQU1GQyxjQUFZLEVBQUUsTUFOWjtBQU9GQyxRQUFNLEVBQUUsU0FQTjtBQVFGLGtCQUFlO0FBQ2JDLFdBQU8sRUFBQztBQURLLEdBUmI7QUFXRixxQkFBa0I7QUFDaEJDLFdBQU8sRUFBQztBQURRLEdBWGhCO0FBZUYsV0FBUTtBQUNOUixTQUFLLEVBQUMsTUFEQTtBQUVOSyxnQkFBWSxFQUFDLE1BRlA7QUFHTkksV0FBTyxFQUFDLEtBSEY7QUFJTkMsY0FBVSxFQUFDLFNBSkw7QUFLTkMsVUFBTSxFQUFDLFdBTEQ7QUFNTkMsYUFBUyxFQUFDO0FBTkosR0FmTjtBQXVCRixtQkFBaUI7QUFDZixpQ0FBNkI7QUFDM0JaLFdBQUssRUFBRSxFQURvQjtBQUUzQkUsWUFBTSxFQUFFLEVBRm1CO0FBRzNCVyxtQkFBYSxFQUFFLGdCQUhZO0FBSTNCcEIsY0FBUSxFQUFFLFVBSmlCO0FBSzNCcUIsWUFBTSxFQUFFLENBTG1CO0FBTTNCQyxXQUFLLEVBQUU7QUFOb0I7QUFEZDtBQXZCZixDQUFELENBRDBCLENBQXhCO0FBeUNBLE1BQU1DLG1CQUFtQixHQUFHckIsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0T0FBekI7QUFtQkEsTUFBTXFCLE9BQU8sR0FBR3RCLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLDJNQUNIQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREwsRUFFTEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkgsRUFHSEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhMLEVBSVRBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpDLEVBS0VBLHlFQUFRLENBQUMsdUJBQUQsRUFBMEIsU0FBMUIsQ0FMVixFQVFEQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FSUCxDQUFiO0FBZUEsTUFBTUMsZUFBZSxHQUFHekIsd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsNlBBQ1hDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERyxFQUViQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGSyxFQUdYQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEcsRUFJakJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpTLEVBTU5BLHlFQUFRLENBQUMsdUJBQUQsRUFBMEIsU0FBMUIsQ0FORixFQWNUQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FkQyxDQUFyQjtBQWtCQSxNQUFNRSxXQUFXLEdBQUcxQix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLDByREFRTHVCLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FSSCxFQVNQQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBVEQsRUFVTEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQVZILEVBV1hBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FYRyxFQXVCTEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQXZCSCxFQXdCUEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBeEJELEVBeUJMQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBekJILEVBMEJYQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBMUJHLEVBNEJMQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0E1QkgsRUFnRFBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixNQUFqQixDQWhERCxFQXlETEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLE1BQWpCLENBekRILEVBMERNQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBMURkLEVBMkRFQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBM0RWLEVBK0REQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBL0RQLEVBZ0VIQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBaEVMLEVBaUVEQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBakVQLEVBa0VQQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBbEVELEVBb0VJQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBcEVaLEVBd0VEQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBeEVQLEVBeUVIQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0F6RUwsRUEwRURBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0ExRVAsRUEyRVBBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0EzRUQsRUF3Rk1BLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0F4RmQsRUE0SEVBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0E1SFYsRUFpSVBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQWpJRCxDQUFqQjtBQXVJQSxNQUFNRyxVQUFVLEdBQUczQix3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSwrQ0FBaEI7QUFNQSxNQUFNSyxnQkFBZ0IsR0FBRzVCLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsa1FBaUJ6QndCLGVBakJ5QixDQUF0QjtBQXVCQSxNQUFNSSxRQUFRLEdBQUc3Qix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLGtJQUFkO0FBV0EsTUFBTTZCLFdBQVcsR0FBRzlCLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLDRSQUNQQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREQsRUFFVEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZDLEVBR1BBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIRCxFQUliQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBSkssRUFnQkZBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FoQk4sQ0FBakI7QUFxQkEsTUFBTU8sVUFBVSxHQUFHL0Isd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsa0hBQ05DLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERixFQUVSQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGQSxFQUdOQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEYsRUFJWkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpJLEVBTU5BLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQU5GLENBQWhCLEMsQ0FVUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPLE1BQU1RLFlBQVksR0FBR2hDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsdUdBQWxCO0FBUUEsTUFBTWdDLEtBQUssR0FBR2pDLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLDhIQUNEQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBRFAsRUFFSEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZMLEVBR0RBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIUCxFQUlQQSx5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBSkQsRUFNSUEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQU5aLENBQVg7QUFVQSxNQUFNVSxlQUFlLEdBQUdsQyx3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSw4U0FDWEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURHLEVBRWJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZLLEVBR1hBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0FIRyxFQUlqQkEseUVBQVEsQ0FBQyx1QkFBRCxFQUEwQixTQUExQixDQUpTLEVBaUJKQSx5RUFBUSxDQUFDLHVCQUFELEVBQTBCLFNBQTFCLENBakJKLENBQXJCO0FBd0JBLE1BQU1XLGVBQWUsR0FBR25DLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsK0tBSU51Qix5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKRixFQU1YQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBTkcsRUFPVEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsS0FBZixDQVBDLENBQXJCO0FBY0EsTUFBTVksZUFBZSxHQUFHcEMsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSx3TEFJTnVCLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpGLEVBTVhBLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FORyxFQU9UQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBUEMsQ0FBckI7QUFjQSxNQUFNYSxnQkFBZ0IsR0FBR3JDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsOFZBQXRCO0FBOEJBLE1BQU1xQyxXQUFXLEdBQUd0Qyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHNGQUFqQjtBQU9BLE1BQU1zQyxXQUFXLEdBQUd2Qyx3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSwwRkFDUEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURELEVBRVRBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZDLEVBR1BBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FIRCxFQUliQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBSkssQ0FBakI7QUFRQSxNQUFNZ0IsUUFBUSxHQUFHeEMsd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsdUVBQ0pDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FESixFQUVOQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRixFQUdKQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEosRUFJVkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpFLENBQWQ7QUFPQSxNQUFNaUIsUUFBUSxHQUFHekMsd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsNlZBQ0pDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FESixFQUVOQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRixFQUdKQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEosRUFJVkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBSkUsRUFLQ0EseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQUxULEVBTUZBLHlFQUFRLENBQUMsV0FBRCxFQUFjLE1BQWQsQ0FOTixDQUFkLEM7Ozs7Ozs7Ozs7OztBQ2plUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFJQTtBQUNBO0FBQ0E7QUFDQSxNQUFNa0IsZ0JBQWdCLEdBQUcsQ0FBQyxNQUFNO0FBQzlCLE1BQUlDLEtBQUssR0FBRyxDQUFaO0FBRUEsU0FBTyxNQUFPLEdBQUUsRUFBRUEsS0FBTSxFQUF4QjtBQUNELENBSndCLEdBQXpCO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUMscUJBQXFCLEdBQUlDLFNBQUQsSUFBeUI7QUFDckQsUUFBTUMsU0FBUyxHQUFHRCxTQUFTLENBQUNDLFNBQTVCO0FBRUEsU0FBTyxDQUFDQSxTQUFELElBQWMsQ0FBQ0EsU0FBUyxDQUFDQyxnQkFBaEM7QUFDRCxDQUpEO0FBTUE7QUFDQTtBQUNBOzs7QUFDTyxNQUFNM0QsUUFBUSxHQUFHLENBQ3RCNEQsU0FEc0IsRUFFdEJDLE9BQVksR0FBRyxFQUZPLEtBR0s7QUFDM0IsTUFBSSxDQUFDTCxxQkFBcUIsQ0FBQ0ksU0FBRCxDQUExQixFQUF1QztBQUNyQyxVQUFNLElBQUlFLEtBQUosQ0FDSiw2SUFESSxDQUFOO0FBR0Q7O0FBRUQsUUFBTUMsR0FBRyxHQUFHQyxxREFBTyxDQUFDVixnQkFBRCxFQUFtQixFQUFuQixDQUFuQjtBQUNBLFFBQU1XLEtBQUssR0FBR0QscURBQU8sQ0FBQyxNQUFNSixTQUFQLEVBQWtCQyxPQUFPLENBQUNLLE1BQTFCLENBQXJCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHQyx3REFBVSxDQUFDQywyREFBRCxDQUExQjtBQUNBLFFBQU12RSxTQUFTLEdBQUd3RSx5REFBVyxDQUFDLE1BQU1ILE9BQU8sQ0FBQ3JFLFNBQVIsQ0FBa0JpRSxHQUFsQixFQUF1QkUsS0FBdkIsRUFBOEJKLE9BQTlCLENBQVAsRUFBK0MsQ0FDMUVNLE9BQU8sQ0FBQ3JFLFNBRGtFLENBQS9DLENBQTdCO0FBR0EsUUFBTUMsU0FBUyxHQUFHdUUseURBQVcsQ0FBQyxNQUFNSCxPQUFPLENBQUNwRSxTQUFSLENBQWtCZ0UsR0FBbEIsQ0FBUCxFQUErQixDQUMxREksT0FBTyxDQUFDcEUsU0FEa0QsRUFFMURnRSxHQUYwRCxDQUEvQixDQUE3QixDQWIyQixDQWlCM0I7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBLFNBQU8sQ0FBQ2pFLFNBQUQsRUFBWUMsU0FBWixDQUFQO0FBQ0QsQ0FwQ00sQyxDQXNDUDtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUYiLCJmaWxlIjoiMTMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWcgfSBmcm9tIFwicmVhY3QtaW1hZ2VcIjtcbmltcG9ydCBwbGFjZWhvbGRlciBmcm9tIFwiLi9wcm9kdWN0LXBsYWNlaG9sZGVyLnBuZ1wiO1xuY29uc3QgUGxhY2Vob2xkZXIgPSAoKSA9PiA8aW1nIHNyYz17cGxhY2Vob2xkZXJ9IGFsdD1cInByb2R1Y3QgaW1nIGxvYWRlclwiIC8+O1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW1hZ2Uoe1xuICB1cmwsXG4gIGFsdCA9IFwicGxhY2Vob2xkZXJcIixcbiAgdW5sb2FkZXIsXG4gIGxvYWRlcixcbiAgY2xhc3NOYW1lLFxuICBzdHlsZSxcbn06IHtcbiAgdXJsPzogc3RyaW5nO1xuICBhbHQ/OiBzdHJpbmc7XG4gIHVubG9hZGVyPzogc3RyaW5nO1xuICBsb2FkZXI/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPEltZ1xuICAgICAgZHJhZ2dhYmxlPXtmYWxzZX1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICAgIHNyYz17dXJsfVxuICAgICAga2V5PXt1cmx9XG4gICAgICBhbHQ9e2FsdH1cbiAgICAgIGxvYWRlcj17PFBsYWNlaG9sZGVyIC8+fVxuICAgICAgdW5sb2FkZXI9ezxQbGFjZWhvbGRlciAvPn1cbiAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgIC8+XG4gICk7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBcImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBUTRBQUFEd0NBWUFBQUR4WG9wNEFBQUhQRWxFUVZSNFh1M2QyM0xhMkJhR1VSRU9QcFRmLzBtTndZQ3N2dGhGdG9NZGl4K1d4QklaNDZxcnNqcHh1dHBmTk9YbG1WblhkVjBERVBqVmR3RGdsSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjUVdmUWNvNTNBNC9QN24rWHplekdhekg4OURyWVJqUUYzWE5idmRydG50ZGszYnRsOStmRDZmTjR2Rm9ubDhmQlFSSm1YV2RWM1hkNGpjZnI5djN0N2VtblArODg1bXMrYmg0YUY1Zkh6c093cFZFSTRCYkRhYjV2Mzl2ZS9ZRjh2bHNubCtmdmIwUWZXOEhDM3MwbWcwbjU1U29IYkNVZEIrdjc4NEdrZjcvYjdaYnJkOXgrQ21oS09neldiVGQrUXM3Ky92WjcwYmdWc1Jqa0oydTEzejhmSFJkK3dzWGRkNTZxQnF3bEhJZnIvdk94SXAvZk5CU2NKUlNPbFA5SStQRCtNSzFSS09pbjEzYVF4cUlCd0ZlREw0MCtlcjlkd240U2pBaGEzL2E5dTJXYS9YN3FQY09lRW9aSWg0ek9menZpTlY2YnJ1OXpYNzQvZm9jSitFbzVEbGN0bDNKRExGNzU1ZHI5ZC92SmQ1ZTNzenR0d3A0U2lrZERoV3ExWGZrYXBzTnB0dkk3RmVyNHZkYjZFZXdsSEljcmtzTmxyTVpyTkpoV08zMi8zMXFuM1hkYzE2dmZZQytjNElSMEZQVDA5OVI4N3k5UFEwbVRHbGJkdmVxL2JubkdGYWhLT2d4V0xSUEQ4Lzl4MzcwV3ExbXN6VFJ0ZDF6ZXZyNjFsUEU3dmR6alg2T3lJY2hhMVdxNHZqOGZEd2NQRy9ld3ZuUnVOb3U5MFd2MkhMYlZqa001REQ0ZEJzTnB1emJuLysrdldyZVhwNkt2NkNkVWh2YjI4WGZibDFOcHMxTHk4dnhkNEhjUnZDTWJEZGJ0Y2NEb2Rtdjk5LytkTjV1VncyeStWeU1xUEowVzYzdStxQzEzdytiMTVlWGliekhvZXZoR05rYmR0TytrL2J3K0hRdkw2KzloM3J0VmdzbXBlWGw3NWpWTW83anBGTk9Sb2ZIeC9OZXIzdU8zYVc0eWpITkFrSFp4bmlQc2I3Ky90RjcwbTRQZUdvV01sUDBtdWQrNkkzTmRUUHk3Q0VvMUtsM2lXVXNOMXVCM3N5U082Q1VBL2hxTkR4dTB6YnRyMzVwYWt4dHE0ZjQ4RjBDRWVGdHR2dDcyOE0yMjYzTjN1VWI5djJxaSs3SnNiOHRiaWVjRlRtY0RoOCtZYXhXM3hDZmQ2dE1SWTdQS1pET0NweS9HUTlkWXVSNVhTM3hsanM4SmdHNGFqSTV4SGx1eDhiNnhQNWI3czF4bUtIUi8yRW94TGZqU2lueGhoWmZ0cXRNWlloN294UWxuQlU0RzhqeXFtaFI1YWE5bWJVOUxId2xYQlU0S2NSNWRSUUkwdU45eW5zOEtpWGNOellPU1BLcVhPZVRsSzFSZVBJRG84NkNjY05uVHVpbkNvOXNod3ZtOVdxOW8vdlh5UWNONVNNS0tkS2pTeFR1RHR4aXpzbC9FdzRidVNTRWVYVUpVOHJueDBPaDZ0L2pyRWMvNFk0NmlBY04zRHBpSExxbXBHbDVHNk5zZGpoVVEvaHVJRnJScFJUbDR3c1U3NG5ZWWRISFlSalpDVkdsRlBwMDh2VWQyQk0vZU8vQjhJeG9sSWp5cWxrWkJseXQ4Wllhcnh6OHE4UmpoR1ZIRkZPblRPeWpMRmJZeXgyZU55V2NJeWtiZHZpSThxcG41NW03bkhmeFQzK25xWkNPRVl5eHYvZ2Z4dFo3dmtleEJUdW9kd2o0UmpCT1dORUtkLzlXcmZhclRFV096ekdKeHdEUzE1Y2x2TDU2ZWJXdXpYR1lvZkh1SVJqWUdPTUtLZU9zYXBodDhaWXBudzNaWXI4RlpBRDJtNjNvejl0ZkRhYnpmNjVUNlRWYXRVOFB6LzNIZU5LbmpnR2Nvc1I1ZFMvRm8zR0RvL1JDTWRBYmpHaThEOTJlQXhQT0FZdzVsZFIrSjRkSHNNU2pzSnFHRkc0Nzdzck5SQ093b3dvOWJERFl6akNVWkFScFQ1MmVBeERPQW94b3RUTERvL3loS01RSTByZDdQQW9TemdLTUtMVXp3NlBzb1RqU2thVTZiRERveHpodUpJUlpWcnM4Q2hET0s1Z1JKa21Penl1Snh3WE1xSk1teDBlMXhHT0MzbmNuVDQ3UEM0bkhCY3dvdHdIT3p3dUp4d2hJOHA5YWR2V3pkSUxDRWZJaUhKLzdQRElDVWZBaUhLLzdQRElMUG9POEtmSHg4ZStJMHlVRjZYbnMzTVVpQmxWZ0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSS9RZTBneW9UekVNV1pRQUFBQUJKUlU1RXJrSmdnZz09XCIiLCIvLyBwcm9kdWN0IGNhcmQgZm9yIGZ1cm5pdHVyZVxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBJbWFnZSBmcm9tICdjb21wb25lbnRzL2ltYWdlL2ltYWdlJztcbmltcG9ydCB7XG4gIFByb2R1Y3ROYW1lLFxuICBEaXNjb3VudFBlcmNlbnQsXG4gIFByb2R1Y3RDYXJkV3JhcHBlcixcbiAgUHJvZHVjdEltYWdlV3JhcHBlcixcbiAgUHJvZHVjdEluZm8sXG59IGZyb20gJy4uL3Byb2R1Y3QtY2FyZC5zdHlsZSc7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XG5pbXBvcnQgeyB1c2VNb2RhbCB9IGZyb20gJ2NvbnRleHRzL21vZGFsL3VzZS1tb2RhbCc7XG5pbXBvcnQgZHluYW1pYyBmcm9tICduZXh0L2R5bmFtaWMnO1xuY29uc3QgUXVpY2tWaWV3TW9iaWxlID0gZHluYW1pYygoKSA9PlxuICBpbXBvcnQoJ2ZlYXR1cmVzL3F1aWNrLXZpZXcvcXVpY2stdmlldy1tb2JpbGUnKVxuKTtcbnR5cGUgUHJvZHVjdENhcmRQcm9wcyA9IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgaW1hZ2U6IGFueTtcbiAgZGlzY291bnRJblBlcmNlbnQ/OiBudW1iZXI7XG4gIGRhdGE6IGFueTtcbiAgZGV2aWNlVHlwZTogYW55O1xufTtcblxuY29uc3QgUHJvZHVjdENhcmQ6IFJlYWN0LkZDPFByb2R1Y3RDYXJkUHJvcHM+ID0gKHtcbiAgdGl0bGUsXG4gIGltYWdlLFxuICBkaXNjb3VudEluUGVyY2VudCxcbiAgZGF0YSxcbiAgZGV2aWNlVHlwZSxcbn0pID0+IHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IFtzaG93TW9kYWwsIGhpZGVNb2RhbF0gPSB1c2VNb2RhbChcbiAgICAoKSA9PiAoXG4gICAgICA8UXVpY2tWaWV3TW9iaWxlXG4gICAgICAgIG1vZGFsUHJvcHM9e2RhdGF9XG4gICAgICAgIGhpZGVNb2RhbD17aGlkZU1vZGFsfVxuICAgICAgICBkZXZpY2VUeXBlPXtkZXZpY2VUeXBlfVxuICAgICAgLz5cbiAgICApLFxuICAgIHtcbiAgICAgIG9uQ2xvc2U6ICgpID0+IHtcbiAgICAgICAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnksIGFzUGF0aCB9ID0gcm91dGVyO1xuICAgICAgICBjb25zdCBhcyA9IGFzUGF0aDtcbiAgICAgICAgcm91dGVyLnB1c2goXG4gICAgICAgICAge1xuICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFzLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHNoYWxsb3c6IHRydWUsXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfSxcbiAgICB9XG4gICk7XG4gIGNvbnN0IGhhbmRsZVF1aWNrVmlld01vZGFsID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgcGF0aG5hbWUsIHF1ZXJ5IH0gPSByb3V0ZXI7XG4gICAgY29uc3QgYXMgPSBgL3Byb2R1Y3QvJHtkYXRhLnNsdWd9YDtcbiAgICBpZiAocGF0aG5hbWUgPT09ICcvcHJvZHVjdC9bc2x1Z10nKSB7XG4gICAgICByb3V0ZXIucHVzaChwYXRobmFtZSwgYXMpO1xuICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2hvd01vZGFsKCk7XG4gICAgcm91dGVyLnB1c2goXG4gICAgICB7XG4gICAgICAgIHBhdGhuYW1lLFxuICAgICAgICBxdWVyeSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHBhdGhuYW1lOiBhcyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHNoYWxsb3c6IHRydWUsXG4gICAgICB9XG4gICAgKTtcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8UHJvZHVjdENhcmRXcmFwcGVyXG4gICAgICBvbkNsaWNrPXtoYW5kbGVRdWlja1ZpZXdNb2RhbH1cbiAgICAgIGNsYXNzTmFtZT1cImZ1cm5pdHVyZS1jYXJkXCJcbiAgICA+XG4gICAgICA8UHJvZHVjdEltYWdlV3JhcHBlcj5cbiAgICAgICAgPEltYWdlXG4gICAgICAgICAgdXJsPXtpbWFnZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJwcm9kdWN0LWltYWdlXCJcbiAgICAgICAgICBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJyB9fVxuICAgICAgICAgIGFsdD17dGl0bGV9XG4gICAgICAgIC8+XG4gICAgICAgIHtkaXNjb3VudEluUGVyY2VudCA/IChcbiAgICAgICAgICA8RGlzY291bnRQZXJjZW50PntkaXNjb3VudEluUGVyY2VudH0lPC9EaXNjb3VudFBlcmNlbnQ+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9Qcm9kdWN0SW1hZ2VXcmFwcGVyPlxuICAgICAgPFByb2R1Y3RJbmZvPlxuICAgICAgICA8UHJvZHVjdE5hbWU+e3RpdGxlfTwvUHJvZHVjdE5hbWU+XG4gICAgICA8L1Byb2R1Y3RJbmZvPlxuICAgIDwvUHJvZHVjdENhcmRXcmFwcGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvZHVjdENhcmQ7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCB7IHRoZW1lR2V0IH0gZnJvbSAnQHN0eWxlZC1zeXN0ZW0vdGhlbWUtZ2V0JztcbmltcG9ydCBjc3MgZnJvbSAnQHN0eWxlZC1zeXN0ZW0vY3NzJztcblxuY29uc3QgU3R5bGVkQm94ID0gc3R5bGVkLmRpdihcbiAgY3NzKHtcbiAgICBweTogWzMwLCA1MF0sXG4gICAgcHg6IFsnMXJlbScsIDBdLFxuICB9KSxcbiAge1xuICAgIHdpZHRoOiAnMTAwJScsXG4gIH1cbik7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0Q2FyZFdyYXBwZXIgPSBzdHlsZWQuZGl2KFxuICBjc3Moe1xuICAgIGhlaWdodDogJzEwMCUnLFxuICAgIHdpZHRoOiAnMTAwJScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnd2hpdGUnLFxuICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgIGZvbnRGYW1pbHk6ICdpbmhlcml0JyxcbiAgICBib3JkZXJSYWRpdXM6ICdiYXNlJyxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAnOmhvdmVyIC5oaWRkJzp7XG4gICAgICBvcGFjaXR5OicxICFpbXBvcnRhbnQnLFxuICAgIH0sXG4gICAgJzpob3ZlciAub25ob3Zlcic6e1xuICAgICAgZGlzcGxheTonbm9uZSAhaW1wb3J0YW50JyxcbiAgICB9LFxuICAgIFxuICAgICcuaGlkZCc6e1xuICAgICAgd2lkdGg6JzEwMCUnLFxuICAgICAgYm9yZGVyUmFkaXVzOicxNXB4JyxcbiAgICAgIHBhZGRpbmc6JzVweCcsXG4gICAgICBiYWNrZ3JvdW5kOicjRjM5QzEyJyxcbiAgICAgIGJvcmRlcjonMHB4IHNvbGlkJyxcbiAgICAgIG1hcmdpblRvcDonNXB4J1xuICAgIH0sXG4gICAgJy5jYXJkLWNvdW50ZXInOiB7XG4gICAgICAnQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSc6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uLXJldmVyc2UnLFxuICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgYm90dG9tOiAwLFxuICAgICAgICByaWdodDogMCxcbiAgICAgIH0sXG4gICAgfSxcbiAgXG4gICAgXG4gICAgIFxuICAgIFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RJbWFnZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDI0MHB4O1xuICBwYWRkaW5nOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBvdmVyZmxvdzpoaWRkZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBpbWcge1xuICAgIG1heC13aWR0aDogMTcwJTtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNjQwcHgpIHtcbiAgICBoZWlnaHQ6IDE0NXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgU2FsZVRhZyA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5yZWd1bGFyJywgJyNGRkFENUUnKX07XG4gIHBhZGRpbmc6IDAgMTBweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLm1lZGl1bScsICcxMnB4Jyl9O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICByaWdodDogMTBweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBEaXNjb3VudFBlcmNlbnQgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LnJlZ3VsYXInLCAnI0ZGQUQ1RScpfTtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE1cHg7XG4gIHJpZ2h0OiAxNXB4O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5tZWRpdW0nLCAnMTJweCcpfTtcbiAgei1pbmRleDogMjtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mbyA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDIwcHggMjVweCAzMHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgIHBhZGRpbmc6IDE1cHggMjBweDtcbiAgICBtaW4taGVpZ2h0OiAxMjNweDtcbiAgfVxuICAucHJvZHVjdC10aXRsZSB7XG4gICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gICAgbWFyZ2luOiAwIDAgN3B4IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbWFyZ2luOiAwIDAgNXB4IDA7XG4gICAgfVxuICB9XG4gIC5wcm9kdWN0LXdlaWdodCB7XG4gICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQucmVndWxhcicsICcjNzc3OThjJyl9O1xuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMueHMnLCAnMTInKX1weDtcbiAgICB9XG4gIH1cbiAgLnByb2R1Y3QtbWV0YSB7XG4gICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgbWluLWhlaWdodDogMzZweDtcbiAgICB9XG4gICAgLnByb2R1Y3RQcmljZVdyYXBwZXIge1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIHdpZHRoOjEwMCU7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAgICAuaGlkZHtcbiAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjMDAwJyl9O1xuICAgICAgICBvcGFjaXR5OjA7XG4gICAgICAgIC5idG4tdGV4dCB7XG4gICAgICAgICAgcGFkZGluZzogMCAwIDAgNnB4O1xuICAgICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjMDAwJyl9O1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgICBib3JkZXItY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLnByb2R1Y3QtcHJpY2Uge1xuICAgICAgICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICAgICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICAgICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAuZGlzY291bnRlZFByaWNlIHtcbiAgICAgICAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgICAgICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICAgICAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgICAgIHBhZGRpbmc6IDAgNXB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAtMjBweDtcbiAgICAgICAgbGVmdDogLTRweDtcbiAgICAgICAgJjpiZWZvcmUge1xuICAgICAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIGhlaWdodDogMXB4O1xuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LmhvdmVyJywgJyNGQkI5NzknKX07XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIFxuICAgIH1cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgIC5xdWFudGl0eSB7XG4gICAgICAgIHdpZHRoOiAzMnB4O1xuICAgICAgICBoZWlnaHQ6IDkwcHg7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBmbGV4LXNocmluazogMDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBib3R0b206IDE1cHg7XG4gICAgICAgIHJpZ2h0OiAxNXB4O1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBib3gtc2hhZG93OiAwIDEwcHggMjBweCByZ2JhKDAsIDAsIDAsIDAuMTYpO1xuICAgICAgfVxuICAgICAgYnV0dG9uIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMjdweDtcbiAgICAgIH1cbiAgICAgIC5pbmNCdG4ge1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgfVxuICAgICAgLmRlY0J0biB7XG4gICAgICAgIHRvcDogYXV0bztcbiAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIH1cbiAgICAgIGlucHV0W3R5cGU9J251bWJlciddIHtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDU0cHgpO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogMjdweDtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCdXR0b25UZXh0ID0gc3R5bGVkLnNwYW5gXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCb29rSW1hZ2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAyNzVweDtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICBpbWcge1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBoZWlnaHQ6IDIxNXB4O1xuICB9XG4gICR7RGlzY291bnRQZXJjZW50fSB7XG4gICAgdG9wOiAwO1xuICAgIHJpZ2h0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQm9va0luZm8gPSBzdHlsZWQuZGl2YFxuICBwYWRkaW5nOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMTVweCAwcHggMHB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdE5hbWUgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gIG1hcmdpbjogMCAwIDdweCAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogYmxvY2s7XG4gICY6b25seS1jaGlsZCB7XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGZvbnQtc2l6ZTogY2FsYygke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4IC0gMXB4KTtcbiAgICBtYXJnaW46IDAgMCA1cHggMDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEF1dGhvckluZm8gPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQucmVndWxhcicsICcjNzc3OThjJyl9O1xuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICB9XG5gO1xuXG4vLyBleHBvcnQgY29uc3QgQWRkQ2FydEJveCA9IHN0eWxlZC5kaXZgXG4vLyAgIHdpZHRoOiBjYWxjKDEwMCUgLSA0MHB4KTtcbi8vICAgZGlzcGxheTogZmxleDtcbi8vICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbi8vICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbi8vICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4vLyAgIHBhZGRpbmc6IDIwcHg7XG4vLyAgIGJvcmRlci1yYWRpdXM6IDZweDtcbi8vICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbi8vICAgYm94LXNoYWRvdzogMCAxMHB4IDIwcHggcmdiYSgwLCAwLCAwLCAwLjE2KTtcbi8vICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICB0b3A6IDUwJTtcbi8vICAgbGVmdDogNTAlO1xuLy8gICBvcGFjaXR5OiAwO1xuLy8gICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcblxuLy8gICAuY2FydC1idXR0b24ge1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDE4cHg7XG4vLyAgICAgaGVpZ2h0OiAzNnB4O1xuLy8gICAgIHBhZGRpbmctbGVmdDogMTdweDtcbi8vICAgICBwYWRkaW5nLXJpZ2h0OiAxN3B4O1xuLy8gICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLjEnLCAnMTMnKX0gcHg7XG4vLyAgICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuLy8gICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuLy8gICAgICAgd2lkdGg6IDMycHg7XG4vLyAgICAgICBoZWlnaHQ6IDMycHg7XG4vLyAgICAgICBwYWRkaW5nOiAwO1xuLy8gICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuLy8gICAgIH1cbi8vICAgICAuYnRuLXRleHQge1xuLy8gICAgICAgcGFkZGluZzogMCAwIDAgNnB4O1xuLy8gICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4vLyAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4vLyAgICAgICB9XG4vLyAgICAgfVxuLy8gICAgICY6aG92ZXIge1xuLy8gICAgICAgY29sb3I6ICNmZmY7XG4vLyAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4vLyAgICAgICBib3JkZXItY29sb3I6ICNGMzlDMTI7XG4vLyAgICAgfVxuLy8gICAgIHN2ZyB7XG4vLyAgICAgICBmaWxsOiBjdXJyZW50Q29sb3I7XG4vLyAgICAgfVxuLy8gICB9XG4vLyBgO1xuXG5leHBvcnQgY29uc3QgUHJpY2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcmljZSA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgRGlzY291bnRlZFByaWNlID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9IHB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LnJlZ3VsYXInLCAnI0ZGQUQ1RScpfTtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBwYWRkaW5nOiAwIDVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiAtNHB4O1xuICB6LWluZGV4OiAyO1xuICAmOmJlZm9yZSB7XG4gICAgY29udGVudDogJyc7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxcHg7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cucmVndWxhcicsICcjRkZBRDVFJyl9O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDUwJTtcbiAgICBsZWZ0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQm9va0NhcmRXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMzBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMTVweDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEZvb2RDYXJkV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5gO1xuXG5leHBvcnQgY29uc3QgRm9vZEltYWdlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMjMwcHg7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZmxleC1zaHJpbms6IDA7XG4gIGltZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICB9XG4gICY6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6ICcnO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgei1pbmRleDogMTtcbiAgfVxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBoZWlnaHQ6IDE0NXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdE1ldGEgPSBzdHlsZWQuZGl2YFxuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5gO1xuXG5leHBvcnQgY29uc3QgRGVsaXZlcnlPcHQgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQuYm9sZCcsICcjMEQxMTM2Jyl9O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuYDtcblxuZXhwb3J0IGNvbnN0IENhdGVnb3J5ID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBEdXJhdGlvbiA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5iaWcnLCAnMThweCcpfTtcbiAgcGFkZGluZy10b3A6IDA7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XG4gIGhlaWdodDogMzZweDtcbiAgd2lkdGg6IGF1dG87XG4gIGJvcmRlcjogMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDYwMHB4KSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIH1cbmA7XG4iLCJpbXBvcnQgeyB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1vZGFsQ29udGV4dCwgTW9kYWxUeXBlIH0gZnJvbSAnLi9tb2RhbC5jb250ZXh0JztcblxuLyoqXG4gKiBDYWxsYmFjayB0eXBlcyBwcm92aWRlZCBmb3IgZGVzY3JpcHRpdmUgdHlwZS1oaW50c1xuICovXG50eXBlIFNob3dNb2RhbCA9ICgpID0+IHZvaWQ7XG50eXBlIEhpZGVNb2RhbCA9ICgpID0+IHZvaWQ7XG5cbi8qKlxuICogVXRpbGl0eSBmdW5jdGlvbiB0byBnZW5lcmF0ZSB1bmlxdWUgbnVtYmVyIHBlciBjb21wb25lbnQgaW5zdGFuY2VcbiAqL1xuY29uc3QgZ2VuZXJhdGVNb2RhbEtleSA9ICgoKSA9PiB7XG4gIGxldCBjb3VudCA9IDA7XG5cbiAgcmV0dXJuICgpID0+IGAkeysrY291bnR9YDtcbn0pKCk7XG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgYXJndW1lbnQgaXMgYSBzdGF0ZWxlc3MgY29tcG9uZW50LlxuICpcbiAqIFdlIHRha2UgYWR2YW50YWdlIG9mIHRoZSBzdGF0ZWxlc3MgbmF0dXJlIG9mIGZ1bmN0aW9uYWwgY29tcG9uZW50cyB0byBiZVxuICogaW5saW5lIHRoZSByZW5kZXJpbmcgb2YgdGhlIG1vZGFsIGNvbXBvbmVudCBhcyBwYXJ0IG9mIGFub3RoZXIgaW1tdXRhYmxlXG4gKiBjb21wb25lbnQuXG4gKlxuICogVGhpcyBpcyBuZWNlc3NhcnkgZm9yIGFsbG93aW5nIHRoZSBtb2RhbCB0byB1cGRhdGUgYmFzZWQgb24gdGhlIGlucHV0cyBwYXNzZWRcbiAqIGFzIHRoZSBzZWNvbmQgYXJndW1lbnQgdG8gdXNlTW9kYWwgd2l0aG91dCB1bm1vdW50aW5nIHRoZSBwcmV2aW91cyB2ZXJzaW9uIG9mXG4gKiB0aGUgbW9kYWwgY29tcG9uZW50LlxuICovXG5jb25zdCBpc0Z1bmN0aW9uYWxDb21wb25lbnQgPSAoQ29tcG9uZW50OiBGdW5jdGlvbikgPT4ge1xuICBjb25zdCBwcm90b3R5cGUgPSBDb21wb25lbnQucHJvdG90eXBlO1xuXG4gIHJldHVybiAhcHJvdG90eXBlIHx8ICFwcm90b3R5cGUuaXNSZWFjdENvbXBvbmVudDtcbn07XG5cbi8qKlxuICogUmVhY3QgaG9vayBmb3Igc2hvd2luZyBtb2RhbCB3aW5kb3dzXG4gKi9cbmV4cG9ydCBjb25zdCB1c2VNb2RhbCA9IChcbiAgY29tcG9uZW50OiBNb2RhbFR5cGUsXG4gIG9wdGlvbnM6IGFueSA9IHt9XG4pOiBbU2hvd01vZGFsLCBIaWRlTW9kYWxdID0+IHtcbiAgaWYgKCFpc0Z1bmN0aW9uYWxDb21wb25lbnQoY29tcG9uZW50KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdPbmx5IHN0YXRlbGVzcyBjb21wb25lbnRzIGNhbiBiZSB1c2VkIGFzIGFuIGFyZ3VtZW50IHRvIHVzZU1vZGFsLiBZb3UgaGF2ZSBwcm9iYWJseSBwYXNzZWQgYSBjbGFzcyBjb21wb25lbnQgd2hlcmUgYSBmdW5jdGlvbiB3YXMgZXhwZWN0ZWQuJ1xuICAgICk7XG4gIH1cblxuICBjb25zdCBrZXkgPSB1c2VNZW1vKGdlbmVyYXRlTW9kYWxLZXksIFtdKTtcbiAgY29uc3QgbW9kYWwgPSB1c2VNZW1vKCgpID0+IGNvbXBvbmVudCwgb3B0aW9ucy5pbnB1dHMpO1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChNb2RhbENvbnRleHQpO1xuICBjb25zdCBzaG93TW9kYWwgPSB1c2VDYWxsYmFjaygoKSA9PiBjb250ZXh0LnNob3dNb2RhbChrZXksIG1vZGFsLCBvcHRpb25zKSwgW1xuICAgIGNvbnRleHQuc2hvd01vZGFsLFxuICBdKTtcbiAgY29uc3QgaGlkZU1vZGFsID0gdXNlQ2FsbGJhY2soKCkgPT4gY29udGV4dC5oaWRlTW9kYWwoa2V5KSwgW1xuICAgIGNvbnRleHQuaGlkZU1vZGFsLFxuICAgIGtleSxcbiAgXSk7XG4gIC8vIGNvbnN0IFtpc1Nob3duLCBzZXRTaG93bl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIC8vIGNvbnN0IHNob3dNb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFNob3duKHRydWUpLCBbXSk7XG4gIC8vIGNvbnN0IGhpZGVNb2RhbCA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFNob3duKGZhbHNlKSwgW10pO1xuXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XG4gIC8vICAgaWYgKGlzU2hvd24pIHtcbiAgLy8gICAgIGNvbnRleHQuc2hvd01vZGFsKGtleSwgbW9kYWwpO1xuICAvLyAgIH0gZWxzZSB7XG4gIC8vICAgICBjb250ZXh0LmhpZGVNb2RhbChrZXkpO1xuICAvLyAgIH1cblxuICAvLyAgIC8vIEhpZGUgbW9kYWwgd2hlbiBwYXJlbnQgY29tcG9uZW50IHVubW91bnRzXG4gIC8vICAgcmV0dXJuICgpID0+IGNvbnRleHQuaGlkZU1vZGFsKGtleSk7XG4gIC8vIH0sIFttb2RhbCwgaXNTaG93bl0pO1xuXG4gIHJldHVybiBbc2hvd01vZGFsLCBoaWRlTW9kYWxdO1xufTtcblxuLy8gZXhwb3J0IGRlZmF1bHQgdXNlTW9kYWw7XG5cbi8vLyB1c2VzXG4vLyBpbXBvcnQgdXNlTW9kYWwgZnJvbSBcInVzZS1tb2RhbFwiO1xuLy8gaW1wb3J0IE1vZGFsUHJvdmlkZXIgZnJvbSBcIm1vZGFsLnByb3ZpZGVyXCI7XG4vLyBpbXBvcnQgTW9kYWwgZnJvbSBcInJlYWN0LW1vZGFsXCI7IC8vIEl0IGNhbiBiZSBhbnkgbW9kYWxcblxuLy8gY29uc3QgTXlNb2RhbCA9IG1lbW8oXG4vLyAgICh7IGlzT3Blbiwgb25DbG9zZSwgdGl0bGUsIGRlc2NyaXB0aW9uLCBjbG9zZUJ0bkxhYmVsIH0pID0+IChcbi8vICAgICA8TW9kYWwgaXNPcGVuPXtpc09wZW59IG9uUmVxdWVzdENsb3NlPXtvbkNsb3NlfT5cbi8vICAgICAgIDxoMj57dGl0bGV9PC9oMj5cbi8vICAgICAgIDxkaXY+e2Rlc2NyaXB0aW9ufTwvZGl2PlxuLy8gICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsb3NlfT57Y2xvc2VCdG5MYWJlbH08L2J1dHRvbj5cbi8vICAgICA8L01vZGFsPlxuLy8gICApXG4vLyApO1xuXG4vLyBjb25zdCBTb21lUGFnZSA9IG1lbW8oKCkgPT4ge1xuLy8gICBjb25zdCBbc2hvd01vZGFsLCBoaWRlTW9kYWxdID0gdXNlTW9kYWwoTXlNb2RhbCwge1xuLy8gICAgIHRpdGxlOiBcIk15IFRlc3QgTW9kYWxcIixcbi8vICAgICBkZXNjcmlwdGlvbjogXCJJIExpa2UgUmVhY3QgSG9va3NcIixcbi8vICAgICBjbG9zZUJ0bkxhYmVsOiBcIkNsb3NlXCJcbi8vICAgfSk7XG5cbi8vICAgcmV0dXJuIChcbi8vICAgICA8PlxuLy8gICAgICAgPGgxPlRlc3QgUGFnZTwvaDE+XG4vLyAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3Nob3dNb2RhbH0+U2hvdyBNb2RhbDwvYnV0dG9uPlxuLy8gICAgIDwvPlxuLy8gICApO1xuLy8gfSk7XG5cbi8vIGNvbnN0IEFwcCA9ICgpID0+IChcbi8vICAgPE1vZGFsUHJvdmlkZXI+XG4vLyAgICAgPFNvbWVQYWdlIC8+XG4vLyAgIDwvTW9kYWxQcm92aWRlcj5cbi8vICk7XG5cbi8vIHVzZU1vZGFsKDxNb2RhbENvbXBvbmVudDogRnVuY3Rpb258PiwgPG1vZGFsUHJvcHM6IE9iamVjdD4sIDxvbkNsb3NlOiBGdW5jdGlvbj4pOiBbc2hvd01vZGFsOiBGdW5jdGlvbiwgaGlkZU1vZGFsOiBGdW5jdGlvbl1cbi8vIFBhcmFtXHRUeXBlXHREZXNjcmlwdGlvblxuLy8gTW9kYWxDb21wb25lbnRcdEZ1bmN0aW9uXHRJdCBjYW4gYmUgYW55IHJlYWN0IGNvbXBvbmVudCB0aGF0IHlvdSB3YW50IHRvIHVzZSBmb3Igc2hvdyBtb2RhbFxuLy8gbW9kYWxQcm9wc1x0T2JqZWN0XHRQcm9wcyB0aGF0IHlvdSB3YW50IHRvIHBhc3MgdG8geW91ciBtb2RhbCBjb21wb25lbnRcbi8vIHNob3dNb2RhbFx0RnVuY3Rpb25cdEl0IGlzIGZ1bmN0aW9uIGZvciBzaG93IHlvdXIgbW9kYWwsIHlvdSBjYW4gcGFzcyBhbnkgZHluYW1pYyBwcm9wcyB0byB0aGlzIGZ1bmN0aW9uXG4vLyBoaWRlTW9kYWxcdEZ1bmN0aW9uXHRJdCBpcyBmdW5jdGlvbiBmb3IgaGlkZSB5b3VyIG1vZGFsLCB5b3UgY2FuIHBhc3MgYW55IGR5bmFtaWMgcHJvcHMgdG8gdGhpcyBmdW5jdGlvblxuLy8gb25DbG9zZVx0RnVuY3Rpb25cdEl0IGNhbGxiYWNrIHdpbGwgYmUgdHJpZ2dlcmVkIGFmdGVyIG1vZGFsIHdpbmRvdyBjbG9zZXNcbi8vIHNob3dNb2RhbChkeW5hbWljTW9kYWxQcm9wczogT2JqZWN0KVxuLy8gUGFyYW1cdFR5cGVcdERlc2NyaXB0aW9uXG4vLyBkeW5hbWljTW9kYWxQcm9wc1x0T2JqZWN0XHREeW5hbWljIHByb3BzIHRoYXQgeW91IHdhbnQgdG8gcGFzcyB0byB5b3VyIG1vZGFsIGNvbXBvbmVudFxuIl0sInNvdXJjZVJvb3QiOiIifQ==