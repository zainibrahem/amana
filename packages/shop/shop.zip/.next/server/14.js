exports.ids = [14];
exports.modules = {

/***/ "./src/components/image/image.tsx":
/*!****************************************!*\
  !*** ./src/components/image/image.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image */ "react-image");
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-placeholder.png */ "./src/components/image/product-placeholder.png");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\image\\image.tsx";




const Placeholder = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
  src: _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__["default"],
  alt: "product img loader"
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 27
}, undefined);

function Image({
  url,
  alt = "placeholder",
  unloader,
  loader,
  className,
  style
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_image__WEBPACK_IMPORTED_MODULE_2__["Img"], {
    draggable: false,
    style: style,
    src: url,
    alt: alt,
    loader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 15
    }, this),
    unloader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 17
    }, this),
    className: className
  }, url, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./src/components/image/product-placeholder.png":
/*!******************************************************!*\
  !*** ./src/components/image/product-placeholder.png ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAADwCAYAAADxXop4AAAHPElEQVR4Xu3d23La2BaGUREOPpTf/0mNwYCsvthFtoMdix+WxBIZ46qrsjpxutpfNOXlmVnXdV0DEPjVdwDglHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcQWfQco53A4/P7n+XzezGazH89DrYRjQF3XNbvdrtntdk3btl9+fD6fN4vFonl8fBQRJmXWdV3Xd4jcfr9v3t7emnP+885ms+bh4aF5fHzsOwpVEI4BbDab5v39ve/YF8vlsnl+fvb0QfW8HC3s0mg0n55SoHbCUdB+v784Gkf7/b7Zbrd9x+CmhKOgzWbTd+Qs7+/vZ70bgVsRjkJ2u13z8fHRd+wsXdd56qBqwlHIfr/vOxIp/fNBScJRSOlP9I+PD+MK1RKOin13aQxqIBwFeDL40+er9dwn4SjAha3/a9u2Wa/X7qPcOeEoZIh4zOfzviNV6bru9zX74/focJ+Eo5Dlctl3JDLF755dr9d/vJd5e3szttwp4SikdDhWq1XfkapsNptvI7Fer4vdb6EewlHIcrksNlrMZrNJhWO32/31qn3Xdc16vfYC+c4IR0FPT099R87y9PQ0mTGlbdveq/bnnGFahKOgxWLRPD8/9x370Wq1mszTRtd1zevr61lPE7vdzjX6OyIcha1Wq4vj8fDwcPG/ewvnRuNou90Wv2HLbVjkM5DD4dBsNpuzbn/++vWreXp6Kv6CdUhvb28Xfbl1Nps1Ly8vxd4HcRvCMbDdbtccDodmv99/+dN5uVw2y+VyMqPJ0W63u+qC13w+b15eXibzHoevhGNkbdtO+k/bw+HQvL6+9h3rtVgsmpeXl75jVMo7jpFNORofHx/Ner3uO3aW4yjHNAkHZxniPsb7+/tF70m4PeGoWMlP0mud+6I3NdTPy7CEo1Kl3iWUsN1uB3sySO6CUA/hqNDxu0zbtr35pakxtq4f48F0CEeFttvt728M2263N3uUb9v2qi+7Jsb8tbiecFTmcDh8+YaxW3xCfd6tMRY7PKZDOCpy/GQ9dYuR5XS3xljs8JgG4ajI5xHlux8b6xP5b7s1xmKHR/2EoxLfjSinxhhZftqtMZYh7oxQlnBU4G8jyqmhR5aa9mbU9LHwlXBU4KcR5dRQI0uN9yns8KiXcNzYOSPKqXOeTlK1RePIDo86CccNnTuinCo9shwvm9Wq9o/vXyQcN5SMKKdKjSxTuDtxizsl/Ew4buSSEeXUJU8rnx0Oh6t/jrEc/4Y46iAcN3DpiHLqmpGl5G6NsdjhUQ/huIFrRpRTl4wsU74nYYdHHYRjZCVGlFPp08vUd2BM/eO/B8IxolIjyqlkZBlyt8ZYarxz8q8RjhGVHFFOnTOyjLFbYyx2eNyWcIykbdviI8qpn55m7nHfxT3+nqZCOEYyxv/gfxtZ7vkexBTuodwj4RjBOWNEKd/9WrfarTEWOzzGJxwDS15clvL56ebWuzXGYofHuIRjYGOMKKeOsapht8ZYpnw3ZYr8FZAD2m63oz9tfDabzf65T6TVatU8Pz/3HeNKnjgGcosR5dS/Fo3GDo/RCMdAbjGi8D92eAxPOAYw5ldR+J4dHsMSjsJqGFG477srNRCOwowo9bDDYzjCUZARpT52eAxDOAoxotTLDo/yhKMQI0rd7PAoSzgKMKLUzw6PsoTjSkaU6bDDoxzhuJIRZVrs8ChDOK5gRJkmOzyuJxwXMqJMmx0e1xGOC3ncnT47PC4nHBcwotwHOzwuJxwhI8p9advWzdILCEfIiHJ/7PDICUfAiHK/7PDILPoO8KfHx8e+I0yUF6Xns3MUiBlVgJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOI/Qe0gyoTzEMWZQAAAABJRU5ErkJggg==");

/***/ }),

/***/ "./src/components/product-card/product-card-two/product-card-two.tsx":
/*!***************************************************************************!*\
  !*** ./src/components/product-card/product-card-two/product-card-two.tsx ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_image_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/image/image */ "./src/components/image/image.tsx");
/* harmony import */ var _product_card_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../product-card.style */ "./src/components/product-card/product-card.style.tsx");


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\product-card\\product-card-two\\product-card-two.tsx";

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

// product card for book





const ProductCard = (_ref) => {
  let {
    title,
    image,
    name,
    discountInPercent,
    onChange,
    increment,
    decrement,
    data,
    deviceType,
    onClick
  } = _ref,
      props = _objectWithoutProperties(_ref, ["title", "image", "name", "discountInPercent", "onChange", "increment", "decrement", "data", "deviceType", "onClick"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["BookCardWrapper"], {
    onClick: onClick,
    className: "book-card",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["BookImageWrapper"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_image_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
        url: image,
        className: "product-image",
        style: {
          position: 'relative'
        },
        alt: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, undefined), discountInPercent ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["DiscountPercent"], {
          children: [discountInPercent, "%"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 55,
          columnNumber: 13
        }, undefined)
      }, void 0, false) : '']
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["BookInfo"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["ProductName"], {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_style__WEBPACK_IMPORTED_MODULE_4__["AuthorInfo"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_2__["FormattedMessage"], {
          id: "intlTextBy",
          defaultMessage: "by"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined), " ", name]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ProductCard);

/***/ }),

/***/ "./src/components/product-card/product-card.style.tsx":
/*!************************************************************!*\
  !*** ./src/components/product-card/product-card.style.tsx ***!
  \************************************************************/
/*! exports provided: ProductCardWrapper, ProductImageWrapper, SaleTag, DiscountPercent, ProductInfo, ButtonText, BookImageWrapper, BookInfo, ProductName, AuthorInfo, PriceWrapper, Price, DiscountedPrice, BookCardWrapper, FoodCardWrapper, FoodImageWrapper, ProductMeta, DeliveryOpt, Category, Duration */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardWrapper", function() { return ProductCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductImageWrapper", function() { return ProductImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleTag", function() { return SaleTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPercent", function() { return DiscountPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfo", function() { return ProductInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonText", function() { return ButtonText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookImageWrapper", function() { return BookImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookInfo", function() { return BookInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductName", function() { return ProductName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorInfo", function() { return AuthorInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PriceWrapper", function() { return PriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Price", function() { return Price; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountedPrice", function() { return DiscountedPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookCardWrapper", function() { return BookCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodCardWrapper", function() { return FoodCardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FoodImageWrapper", function() { return FoodImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductMeta", function() { return ProductMeta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryOpt", function() { return DeliveryOpt; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return Category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Duration", function() { return Duration; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_2__);



const StyledBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__StyledBox",
  componentId: "sc-1j4qmg9-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  py: [30, 50],
  px: ['1rem', 0]
}), {
  width: '100%'
});
const ProductCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductCardWrapper",
  componentId: "sc-1j4qmg9-1"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_2___default()({
  height: '100%',
  width: '100%',
  backgroundColor: 'white',
  position: 'relative',
  fontFamily: 'inherit',
  borderRadius: 'base',
  cursor: 'pointer',
  ':hover .hidd': {
    opacity: '1 !important'
  },
  ':hover .onhover': {
    display: 'none !important'
  },
  '.hidd': {
    width: '100%',
    borderRadius: '15px',
    padding: '5px',
    background: '#F39C12',
    border: '0px solid',
    marginTop: '5px'
  },
  '.card-counter': {
    '@media (max-width: 767px)': {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      position: 'absolute',
      bottom: 0,
      right: 0
    }
  }
}));
const ProductImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductImageWrapper",
  componentId: "sc-1j4qmg9-2"
})(["height:240px;padding:5px;position:relative;text-align:center;display:flex;overflow:hidden;align-items:center;justify-content:center;img{max-width:170%;max-height:100%;display:inline-block;}@media (max-width:640px){height:145px;}"]);
const SaleTag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__SaleTag",
  componentId: "sc-1j4qmg9-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";padding:0 10px;line-height:24px;border-radius:", ";display:inline-block;position:absolute;top:10px;right:10px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const DiscountPercent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountPercent",
  componentId: "sc-1j4qmg9-4"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:24px;background-color:", ";padding-left:10px;padding-right:10px;position:relative;display:inline-block;position:absolute;top:15px;right:15px;border-radius:", ";z-index:2;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const ProductInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductInfo",
  componentId: "sc-1j4qmg9-5"
})(["padding:20px 25px 30px;@media (max-width:990px){padding:15px 20px;min-height:123px;}.product-title{font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;@media (max-width:767px){font-size:14px;margin:0 0 5px 0;}}.product-weight{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}}.product-meta{margin-top:30px;display:flex;align-items:center;justify-content:space-between;position:relative;@media (max-width:767px){min-height:36px;}.productPriceWrapper{position:relative;display:flex;width:100%;flex-direction:column;align-items:flex-start;.hidd{color:", ";opacity:0;.btn-text{padding:0 0 0 6px;@media (max-width:767px){display:none;}}&:hover{color:", ";background-color:", ";border-color:", ";}}.product-price{font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}}.discountedPrice{font-family:", ";font-size:", "px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;position:absolute;top:-20px;left:-4px;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}}}}@media (max-width:767px){.quantity{width:32px;height:90px;display:block;flex-shrink:0;position:absolute;bottom:15px;right:15px;z-index:1;box-shadow:0 10px 20px rgba(0,0,0,0.16);}button{width:100%;height:27px;}.incBtn{top:0;justify-content:center;}.decBtn{top:auto;bottom:0;justify-content:center;}input[type='number']{left:0;font-size:calc(", "px - 1px);height:calc(100% - 54px);position:absolute;top:27px;width:100%;color:", ";}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#000'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ButtonText",
  componentId: "sc-1j4qmg9-6"
})(["@media (max-width:767px){display:none;}"]);
const BookImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookImageWrapper",
  componentId: "sc-1j4qmg9-7"
})(["height:275px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;margin-bottom:15px;img{max-width:100%;max-height:100%;display:inline-block;}@media (max-width:767px){height:215px;}", "{top:0;right:0;}"], DiscountPercent);
const BookInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookInfo",
  componentId: "sc-1j4qmg9-8"
})(["padding:0;width:100%;display:flex;flex-direction:column;align-items:center;@media (max-width:767px){padding:15px 0px 0px;}"]);
const ProductName = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__ProductName",
  componentId: "sc-1j4qmg9-9"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 7px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center;display:block;&:only-child{margin:0;}@media (max-width:767px){font-size:calc(", "px - 1px);margin:0 0 5px 0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const AuthorInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__AuthorInfo",
  componentId: "sc-1j4qmg9-10"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13')); // export const AddCartBox = styled.div`
//   width: calc(100% - 40px);
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: center;
//   padding: 20px;
//   border-radius: 6px;
//   background-color: #ffffff;
//   box-shadow: 0 10px 20px rgba(0, 0, 0, 0.16);
//   position: absolute;
//   top: 50%;
//   left: 50%;
//   opacity: 0;
//   transition: all 0.3s;
//   .cart-button {
//     border-radius: 18px;
//     height: 36px;
//     padding-left: 17px;
//     padding-right: 17px;
//     font-size: ${themeGet('fontSizes.1', '13')} px;
//     font-weight: ${themeGet('fontWeights.bold', '700')};
//     @media (max-width: 767px) {
//       width: 32px;
//       height: 32px;
//       padding: 0;
//       border-radius: 50%;
//     }
//     .btn-text {
//       padding: 0 0 0 6px;
//       @media (max-width: 767px) {
//         display: none;
//       }
//     }
//     &:hover {
//       color: #fff;
//       background-color: ${themeGet('colors.primary.regular', '#F39C12')};
//       border-color: #F39C12;
//     }
//     svg {
//       fill: currentColor;
//     }
//   }
// `;

const PriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__PriceWrapper",
  componentId: "sc-1j4qmg9-11"
})(["position:relative;display:flex;flex-direction:column;align-items:flex-start;margin-bottom:15px;"]);
const Price = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Price",
  componentId: "sc-1j4qmg9-12"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:calc(", "px - 1px);}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const DiscountedPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DiscountedPrice",
  componentId: "sc-1j4qmg9-13"
})(["font-family:", ";font-size:", " px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;position:relative;overflow:hidden;margin-bottom:5px;margin-left:-4px;z-index:2;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.regular', '#FFAD5E'));
const BookCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__BookCardWrapper",
  componentId: "sc-1j4qmg9-14"
})(["height:100%;width:100%;padding:30px;background-color:", ";position:relative;font-family:", ";border-radius:", ";cursor:pointer;@media (max-width:767px){padding:15px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodCardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodCardWrapper",
  componentId: "sc-1j4qmg9-15"
})(["height:100%;width:100%;padding:0;background-color:", ";position:relative;font-family:", ";border-radius:", ";overflow:hidden;cursor:pointer;display:flex;flex-direction:column;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const FoodImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__FoodImageWrapper",
  componentId: "sc-1j4qmg9-16"
})(["height:230px;padding:0;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;flex-shrink:0;img{width:100%;height:100%;object-fit:cover;}&:after{content:'';width:100%;height:100%;display:flex;background-color:rgba(0,0,0,0.1);position:absolute;top:0;left:0;z-index:1;}@media (max-width:767px){height:145px;}"]);
const ProductMeta = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-cardstyle__ProductMeta",
  componentId: "sc-1j4qmg9-17"
})(["margin-top:20px;display:flex;align-items:center;justify-content:space-between;"]);
const DeliveryOpt = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__DeliveryOpt",
  componentId: "sc-1j4qmg9-18"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";white-space:nowrap;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const Category = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Category",
  componentId: "sc-1j4qmg9-19"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const Duration = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-cardstyle__Duration",
  componentId: "sc-1j4qmg9-20"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";background-color:", ";border-radius:", ";padding-top:0;padding-bottom:0;padding-left:20px;padding-right:20px;height:36px;width:auto;border:0;display:flex;align-items:center;justify-content:center;white-space:nowrap;@media (max-width:600px){padding-left:10px;padding-right:10px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.big', '18px'));

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbWFnZS9pbWFnZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvaW1hZ2UvcHJvZHVjdC1wbGFjZWhvbGRlci5wbmciLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC10d28vcHJvZHVjdC1jYXJkLXR3by50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC5zdHlsZS50c3giXSwibmFtZXMiOlsiUGxhY2Vob2xkZXIiLCJwbGFjZWhvbGRlciIsIkltYWdlIiwidXJsIiwiYWx0IiwidW5sb2FkZXIiLCJsb2FkZXIiLCJjbGFzc05hbWUiLCJzdHlsZSIsIlByb2R1Y3RDYXJkIiwidGl0bGUiLCJpbWFnZSIsIm5hbWUiLCJkaXNjb3VudEluUGVyY2VudCIsIm9uQ2hhbmdlIiwiaW5jcmVtZW50IiwiZGVjcmVtZW50IiwiZGF0YSIsImRldmljZVR5cGUiLCJvbkNsaWNrIiwicHJvcHMiLCJwb3NpdGlvbiIsIlN0eWxlZEJveCIsInN0eWxlZCIsImRpdiIsImNzcyIsInB5IiwicHgiLCJ3aWR0aCIsIlByb2R1Y3RDYXJkV3JhcHBlciIsImhlaWdodCIsImJhY2tncm91bmRDb2xvciIsImZvbnRGYW1pbHkiLCJib3JkZXJSYWRpdXMiLCJjdXJzb3IiLCJvcGFjaXR5IiwiZGlzcGxheSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwibWFyZ2luVG9wIiwiZmxleERpcmVjdGlvbiIsImJvdHRvbSIsInJpZ2h0IiwiUHJvZHVjdEltYWdlV3JhcHBlciIsIlNhbGVUYWciLCJzcGFuIiwidGhlbWVHZXQiLCJEaXNjb3VudFBlcmNlbnQiLCJQcm9kdWN0SW5mbyIsIkJ1dHRvblRleHQiLCJCb29rSW1hZ2VXcmFwcGVyIiwiQm9va0luZm8iLCJQcm9kdWN0TmFtZSIsIkF1dGhvckluZm8iLCJQcmljZVdyYXBwZXIiLCJQcmljZSIsIkRpc2NvdW50ZWRQcmljZSIsIkJvb2tDYXJkV3JhcHBlciIsIkZvb2RDYXJkV3JhcHBlciIsIkZvb2RJbWFnZVdyYXBwZXIiLCJQcm9kdWN0TWV0YSIsIkRlbGl2ZXJ5T3B0IiwiQ2F0ZWdvcnkiLCJEdXJhdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNQSxXQUFXLEdBQUcsbUJBQU07QUFBSyxLQUFHLEVBQUVDLGdFQUFWO0FBQXVCLEtBQUcsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTFCOztBQUNlLFNBQVNDLEtBQVQsQ0FBZTtBQUM1QkMsS0FENEI7QUFFNUJDLEtBQUcsR0FBRyxhQUZzQjtBQUc1QkMsVUFINEI7QUFJNUJDLFFBSjRCO0FBSzVCQyxXQUw0QjtBQU01QkM7QUFONEIsQ0FBZixFQWNaO0FBQ0Qsc0JBQ0UscUVBQUMsK0NBQUQ7QUFDRSxhQUFTLEVBQUUsS0FEYjtBQUVFLFNBQUssRUFBRUEsS0FGVDtBQUdFLE9BQUcsRUFBRUwsR0FIUDtBQUtFLE9BQUcsRUFBRUMsR0FMUDtBQU1FLFVBQU0sZUFBRSxxRUFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFOVjtBQU9FLFlBQVEsZUFBRSxxRUFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFQWjtBQVFFLGFBQVMsRUFBRUc7QUFSYixLQUlPSixHQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVlELEM7Ozs7Ozs7Ozs7OztBQy9CRDtBQUFlLCtFQUFnQiw0L0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQS9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBMEJBLE1BQU1NLFdBQXVDLEdBQUcsVUFZMUM7QUFBQSxNQVoyQztBQUMvQ0MsU0FEK0M7QUFFL0NDLFNBRitDO0FBRy9DQyxRQUgrQztBQUkvQ0MscUJBSitDO0FBSy9DQyxZQUwrQztBQU0vQ0MsYUFOK0M7QUFPL0NDLGFBUCtDO0FBUS9DQyxRQVIrQztBQVMvQ0MsY0FUK0M7QUFVL0NDO0FBVitDLEdBWTNDO0FBQUEsTUFEREMsS0FDQzs7QUFDSixzQkFDRSxxRUFBQyxtRUFBRDtBQUFpQixXQUFPLEVBQUVELE9BQTFCO0FBQW1DLGFBQVMsRUFBQyxXQUE3QztBQUFBLDRCQUNFLHFFQUFDLG9FQUFEO0FBQUEsOEJBQ0UscUVBQUMsOERBQUQ7QUFDRSxXQUFHLEVBQUVSLEtBRFA7QUFFRSxpQkFBUyxFQUFDLGVBRlo7QUFHRSxhQUFLLEVBQUU7QUFBRVUsa0JBQVEsRUFBRTtBQUFaLFNBSFQ7QUFJRSxXQUFHLEVBQUVYO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQU9HRyxpQkFBaUIsZ0JBQ2hCO0FBQUEsK0JBQ0UscUVBQUMsbUVBQUQ7QUFBQSxxQkFBa0JBLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERix1QkFEZ0IsR0FLaEIsRUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFnQkUscUVBQUMsNERBQUQ7QUFBQSw4QkFDRSxxRUFBQywrREFBRDtBQUFBLGtCQUFjSDtBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRSxxRUFBQyw4REFBRDtBQUFBLGdDQUNFLHFFQUFDLDJEQUFEO0FBQWtCLFlBQUUsRUFBQyxZQUFyQjtBQUFrQyx3QkFBYyxFQUFDO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsT0FDNERFLElBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBeUJELENBdENEOztBQXdDZUgsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDdEVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBLE1BQU1hLFNBQVMsR0FBR0Msd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNiQyx5REFBRyxDQUFDO0FBQ0ZDLElBQUUsRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLENBREY7QUFFRkMsSUFBRSxFQUFFLENBQUMsTUFBRCxFQUFTLENBQVQ7QUFGRixDQUFELENBRFUsRUFLYjtBQUNFQyxPQUFLLEVBQUU7QUFEVCxDQUxhLENBQWY7QUFVTyxNQUFNQyxrQkFBa0IsR0FBR04sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUM3QkMseURBQUcsQ0FBQztBQUNGSyxRQUFNLEVBQUUsTUFETjtBQUVGRixPQUFLLEVBQUUsTUFGTDtBQUdGRyxpQkFBZSxFQUFFLE9BSGY7QUFJRlYsVUFBUSxFQUFFLFVBSlI7QUFLRlcsWUFBVSxFQUFFLFNBTFY7QUFNRkMsY0FBWSxFQUFFLE1BTlo7QUFPRkMsUUFBTSxFQUFFLFNBUE47QUFRRixrQkFBZTtBQUNiQyxXQUFPLEVBQUM7QUFESyxHQVJiO0FBV0YscUJBQWtCO0FBQ2hCQyxXQUFPLEVBQUM7QUFEUSxHQVhoQjtBQWVGLFdBQVE7QUFDTlIsU0FBSyxFQUFDLE1BREE7QUFFTkssZ0JBQVksRUFBQyxNQUZQO0FBR05JLFdBQU8sRUFBQyxLQUhGO0FBSU5DLGNBQVUsRUFBQyxTQUpMO0FBS05DLFVBQU0sRUFBQyxXQUxEO0FBTU5DLGFBQVMsRUFBQztBQU5KLEdBZk47QUF1QkYsbUJBQWlCO0FBQ2YsaUNBQTZCO0FBQzNCWixXQUFLLEVBQUUsRUFEb0I7QUFFM0JFLFlBQU0sRUFBRSxFQUZtQjtBQUczQlcsbUJBQWEsRUFBRSxnQkFIWTtBQUkzQnBCLGNBQVEsRUFBRSxVQUppQjtBQUszQnFCLFlBQU0sRUFBRSxDQUxtQjtBQU0zQkMsV0FBSyxFQUFFO0FBTm9CO0FBRGQ7QUF2QmYsQ0FBRCxDQUQwQixDQUF4QjtBQXlDQSxNQUFNQyxtQkFBbUIsR0FBR3JCLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsNE9BQXpCO0FBbUJBLE1BQU1xQixPQUFPLEdBQUd0Qix3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSwyTUFDSEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURMLEVBRUxBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZILEVBR0hBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FITCxFQUlUQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKQyxFQUtFQSx5RUFBUSxDQUFDLHVCQUFELEVBQTBCLFNBQTFCLENBTFYsRUFRREEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLE1BQWpCLENBUlAsQ0FBYjtBQWVBLE1BQU1DLGVBQWUsR0FBR3pCLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLDZQQUNYQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREcsRUFFYkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkssRUFHWEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhHLEVBSWpCQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKUyxFQU1OQSx5RUFBUSxDQUFDLHVCQUFELEVBQTBCLFNBQTFCLENBTkYsRUFjVEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLE1BQWpCLENBZEMsQ0FBckI7QUFrQkEsTUFBTUUsV0FBVyxHQUFHMUIsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSwwckRBUUx1Qix5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBUkgsRUFTUEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQVRELEVBVUxBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FWSCxFQVdYQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLFNBQXJCLENBWEcsRUF1QkxBLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0F2QkgsRUF3QlBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQXhCRCxFQXlCTEEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixLQUF4QixDQXpCSCxFQTBCWEEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQTFCRyxFQTRCTEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBNUJILEVBZ0RQQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FoREQsRUF5RExBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixNQUFqQixDQXpESCxFQTBETUEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQTFEZCxFQTJERUEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQTNEVixFQStEREEseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQS9EUCxFQWdFSEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQWhFTCxFQWlFREEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQWpFUCxFQWtFUEEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQWxFRCxFQW9FSUEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQXBFWixFQXdFREEseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQXhFUCxFQXlFSEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBekVMLEVBMEVEQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBMUVQLEVBMkVQQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBM0VELEVBd0ZNQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBeEZkLEVBNEhFQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBNUhWLEVBaUlQQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FqSUQsQ0FBakI7QUF1SUEsTUFBTUcsVUFBVSxHQUFHM0Isd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsK0NBQWhCO0FBTUEsTUFBTUssZ0JBQWdCLEdBQUc1Qix3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLGtRQWlCekJ3QixlQWpCeUIsQ0FBdEI7QUF1QkEsTUFBTUksUUFBUSxHQUFHN0Isd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxrSUFBZDtBQVdBLE1BQU02QixXQUFXLEdBQUc5Qix3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSw0UkFDUEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURELEVBRVRBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FGQyxFQUdQQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEQsRUFJYkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixTQUFyQixDQUpLLEVBZ0JGQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBaEJOLENBQWpCO0FBcUJBLE1BQU1PLFVBQVUsR0FBRy9CLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLGtIQUNOQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREYsRUFFUkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkEsRUFHTkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixLQUF4QixDQUhGLEVBSVpBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FKSSxFQU1OQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FORixDQUFoQixDLENBVVA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTyxNQUFNUSxZQUFZLEdBQUdoQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHVHQUFsQjtBQVFBLE1BQU1nQyxLQUFLLEdBQUdqQyx3REFBTSxDQUFDdUIsSUFBVjtBQUFBO0FBQUE7QUFBQSw4SEFDREMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQURQLEVBRUhBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FGTCxFQUdEQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSFAsRUFJUEEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQUpELEVBTUlBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FOWixDQUFYO0FBVUEsTUFBTVUsZUFBZSxHQUFHbEMsd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsOFNBQ1hDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERyxFQUViQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGSyxFQUdYQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEcsRUFJakJBLHlFQUFRLENBQUMsdUJBQUQsRUFBMEIsU0FBMUIsQ0FKUyxFQWlCSkEseUVBQVEsQ0FBQyx1QkFBRCxFQUEwQixTQUExQixDQWpCSixDQUFyQjtBQXdCQSxNQUFNVyxlQUFlLEdBQUduQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLCtLQUlOdUIseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBSkYsRUFNWEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsTUFBZixDQU5HLEVBT1RBLHlFQUFRLENBQUMsWUFBRCxFQUFlLEtBQWYsQ0FQQyxDQUFyQjtBQWNBLE1BQU1ZLGVBQWUsR0FBR3BDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsd0xBSU51Qix5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FKRixFQU1YQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBTkcsRUFPVEEseUVBQVEsQ0FBQyxZQUFELEVBQWUsS0FBZixDQVBDLENBQXJCO0FBY0EsTUFBTWEsZ0JBQWdCLEdBQUdyQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLDhWQUF0QjtBQThCQSxNQUFNcUMsV0FBVyxHQUFHdEMsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxzRkFBakI7QUFPQSxNQUFNc0MsV0FBVyxHQUFHdkMsd0RBQU0sQ0FBQ3VCLElBQVY7QUFBQTtBQUFBO0FBQUEsMEZBQ1BDLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FERCxFQUVUQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGQyxFQUdQQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEQsRUFJYkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixTQUFyQixDQUpLLENBQWpCO0FBUUEsTUFBTWdCLFFBQVEsR0FBR3hDLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLHVFQUNKQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREosRUFFTkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkYsRUFHSkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhKLEVBSVZBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FKRSxDQUFkO0FBT0EsTUFBTWlCLFFBQVEsR0FBR3pDLHdEQUFNLENBQUN1QixJQUFWO0FBQUE7QUFBQTtBQUFBLDZWQUNKQyx5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBREosRUFFTkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLElBQWpCLENBRkYsRUFHSkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixLQUF4QixDQUhKLEVBSVZBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpFLEVBS0NBLHlFQUFRLENBQUMsd0JBQUQsRUFBMkIsU0FBM0IsQ0FMVCxFQU1GQSx5RUFBUSxDQUFDLFdBQUQsRUFBYyxNQUFkLENBTk4sQ0FBZCxDIiwiZmlsZSI6IjE0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1nIH0gZnJvbSBcInJlYWN0LWltYWdlXCI7XG5pbXBvcnQgcGxhY2Vob2xkZXIgZnJvbSBcIi4vcHJvZHVjdC1wbGFjZWhvbGRlci5wbmdcIjtcbmNvbnN0IFBsYWNlaG9sZGVyID0gKCkgPT4gPGltZyBzcmM9e3BsYWNlaG9sZGVyfSBhbHQ9XCJwcm9kdWN0IGltZyBsb2FkZXJcIiAvPjtcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEltYWdlKHtcbiAgdXJsLFxuICBhbHQgPSBcInBsYWNlaG9sZGVyXCIsXG4gIHVubG9hZGVyLFxuICBsb2FkZXIsXG4gIGNsYXNzTmFtZSxcbiAgc3R5bGUsXG59OiB7XG4gIHVybD86IHN0cmluZztcbiAgYWx0Pzogc3RyaW5nO1xuICB1bmxvYWRlcj86IHN0cmluZztcbiAgbG9hZGVyPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufSkge1xuICByZXR1cm4gKFxuICAgIDxJbWdcbiAgICAgIGRyYWdnYWJsZT17ZmFsc2V9XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgICBzcmM9e3VybH1cbiAgICAgIGtleT17dXJsfVxuICAgICAgYWx0PXthbHR9XG4gICAgICBsb2FkZXI9ezxQbGFjZWhvbGRlciAvPn1cbiAgICAgIHVubG9hZGVyPXs8UGxhY2Vob2xkZXIgLz59XG4gICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cbiAgICAvPlxuICApO1xufVxuIiwiZXhwb3J0IGRlZmF1bHQgXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQVE0QUFBRHdDQVlBQUFEeFhvcDRBQUFIUEVsRVFWUjRYdTNkMjNMYTJCYUdVUkVPUHBUZi8wbU53WUNzdnRoRnRvTWRpeCtXeEJJWjQ2cXJzanB4dXRwZk5PWGxtVm5YZFYwREVQalZkd0RnbEhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1FXZlFjbzUzQTQvUDduK1h6ZXpHYXpIODlEcllSalFGM1hOYnZkcnRudGRrM2J0bDkrZkQ2Zk40dkZvbmw4ZkJRUkptWFdkVjNYZDRqY2ZyOXYzdDdlbW5QKzg4NW1zK2JoNGFGNWZIenNPd3BWRUk0QmJEYWI1djM5dmUvWUY4dmxzbmwrZnZiMFFmVzhIQzNzMG1nMG41NVNvSGJDVWRCK3Y3ODRHa2Y3L2I3WmJyZDl4K0NtaEtPZ3pXYlRkK1FzNysvdlo3MGJnVnNSamtKMnUxM3o4ZkhSZCt3c1hkZDU2cUJxd2xISWZyL3ZPeElwL2ZOQlNjSlJTT2xQOUkrUEQrTUsxUktPaW4xM2FReHFJQndGZURMNDArZXI5ZHduNFNqQWhhMy9hOXUyV2EvWDdxUGNPZUVvWkloNHpPZnp2aU5WNmJydTl6WDc0L2ZvY0orRW81RGxjdGwzSkRMRjc1NWRyOWQvdkpkNWUzc3p0dHdwNFNpa2REaFdxMVhma2Fwc05wdHZJN0ZlcjR2ZGI2RWV3bEhJY3Jrc05sck1ack5KaFdPMzIvMzFxbjNYZGMxNnZmWUMrYzRJUjBGUFQwOTlSODd5OVBRMG1UR2xiZHZlcS9ibm5HRmFoS09neFdMUlBEOC85eDM3MFdxMW1zelRSdGQxemV2cjYxbFBFN3ZkempYNk95SWNoYTFXcTR2ajhmRHdjUEcvZXd2blJ1Tm91OTBXdjJITGJWamtNNURENGRCc05wdXpibi8rK3ZXcmVYcDZLdjZDZFVodmIyOFhmYmwxTnBzMUx5OHZ4ZDRIY1J2Q01iRGRidGNjRG9kbXY5OS8rZE41dVZ3MnkrVnlNcVBKMFc2M3UrcUMxM3crYjE1ZVhpYnpIb2V2aEdOa2JkdE8ray9idytIUXZMNis5aDNydFZnc21wZVhsNzVqVk1vN2pwRk5PUm9mSHgvTmVyM3VPM2FXNHlqSE5Ba0haeG5pUHNiNysvdEY3MG00UGVHb1dNbFAwbXVkKzZJM05kVFB5N0NFbzFLbDNpV1VzTjF1QjNzeVNPNkNVQS9ocU5EeHUwemJ0cjM1cGFreHRxNGY0OEYwQ0VlRnR0dnQ3MjhNMjI2M04zdVViOXYycWkrN0pzYjh0YmllY0ZUbWNEaDgrWWF4VzN4Q2ZkNnRNUlk3UEtaRE9DcHkvR1E5ZFl1UjVYUzN4bGpzOEpnRzRhakk1eEhsdXg4YjZ4UDViN3MxeG1LSFIvMkVveExmalNpbnhoaFpmdHF0TVpZaDdveFFsbkJVNEc4anlxbWhSNWFhOW1iVTlMSHdsWEJVNEtjUjVkUlFJMHVOOXluczhLaVhjTnpZT1NQS3FYT2VUbEsxUmVQSURvODZDY2NOblR1aW5DbzlzaHd2bTlXcTlvL3ZYeVFjTjVTTUtLZEtqU3hUdUR0eGl6c2wvRXc0YnVTU0VlWFVKVThybngwT2g2dC9qckVjLzRZNDZpQWNOM0RwaUhMcW1wR2w1RzZOc2RqaFVRL2h1SUZyUnBSVGw0d3NVNzRuWVlkSEhZUmpaQ1ZHbEZQcDA4dlVkMkJNL2VPL0I4SXhvbElqeXFsa1pCbHl0OFpZYXJ4ejhxOFJqaEdWSEZGT25UT3lqTEZiWXl4MmVOeVdjSXlrYmR2aUk4cXBuNTVtN25IZnhUMytucVpDT0VZeXh2L2dmeHRaN3ZrZXhCVHVvZHdqNFJqQk9XTkVLZC85V3JmYXJURVdPenpHSnh3RFMxNWNsdkw1NmViV3V6WEdZb2ZIdUlSallHT01LS2VPc2FwaHQ4WllwbnczWllyOEZaQUQybTYzb3o5dGZEYWJ6ZjY1VDZUVmF0VThQei8zSGVOS25qZ0djb3NSNWRTL0ZvM0dEby9SQ01kQWJqR2k4RDkyZUF4UE9BWXc1bGRSK0o0ZEhzTVNqc0pxR0ZHNDc3c3JOUkNPd293bzliRERZempDVVpBUnBUNTJlQXhET0FveG90VExEby95aEtNUUkwcmQ3UEFvU3pnS01LTFV6dzZQc29UalNrYVU2YkREb3h6aHVKSVJaVnJzOENoRE9LNWdSSmttT3p5dUp4d1hNcUpNbXgwZTF4R09DM25jblQ0N1BDNG5IQmN3b3R3SE96d3VKeHdoSThwOWFkdld6ZElMQ0VmSWlISi83UERJQ1VmQWlISy83UERJTFBvTzhLZkh4OGUrSTB5VUY2WG5zM01VaUJsVmdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0kvUWUwZ3lvVHpFTVdaUUFBQUFCSlJVNUVya0pnZ2c9PVwiIiwiLy8gcHJvZHVjdCBjYXJkIGZvciBib29rXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuaW1wb3J0IEltYWdlIGZyb20gJ2NvbXBvbmVudHMvaW1hZ2UvaW1hZ2UnO1xuaW1wb3J0IHtcbiAgQm9va0NhcmRXcmFwcGVyLFxuICBCb29rSW1hZ2VXcmFwcGVyLFxuICBCb29rSW5mbyxcbiAgUHJvZHVjdE5hbWUsXG4gIEF1dGhvckluZm8sXG4gIERpc2NvdW50UGVyY2VudCxcbn0gZnJvbSAnLi4vcHJvZHVjdC1jYXJkLnN0eWxlJztcblxudHlwZSBQcm9kdWN0Q2FyZFByb3BzID0ge1xuICB0aXRsZTogc3RyaW5nO1xuICBpbWFnZTogYW55O1xuICBuYW1lPzogc3RyaW5nO1xuICBkaXNjb3VudEluUGVyY2VudD86IG51bWJlcjtcbiAgZGF0YTogYW55O1xuICBvbkNsaWNrPzogKGU6IGFueSkgPT4gdm9pZDtcbiAgb25DaGFuZ2U/OiAoZTogYW55KSA9PiB2b2lkO1xuICBpbmNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBkZWNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBjYXJ0UHJvZHVjdHM/OiBhbnk7XG4gIGFkZFRvQ2FydD86IGFueTtcbiAgdXBkYXRlQ2FydD86IGFueTtcbiAgdmFsdWU/OiBhbnk7XG4gIGRldmljZVR5cGU/OiBhbnk7XG59O1xuXG5jb25zdCBQcm9kdWN0Q2FyZDogUmVhY3QuRkM8UHJvZHVjdENhcmRQcm9wcz4gPSAoe1xuICB0aXRsZSxcbiAgaW1hZ2UsXG4gIG5hbWUsXG4gIGRpc2NvdW50SW5QZXJjZW50LFxuICBvbkNoYW5nZSxcbiAgaW5jcmVtZW50LFxuICBkZWNyZW1lbnQsXG4gIGRhdGEsXG4gIGRldmljZVR5cGUsXG4gIG9uQ2xpY2ssXG4gIC4uLnByb3BzXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEJvb2tDYXJkV3JhcHBlciBvbkNsaWNrPXtvbkNsaWNrfSBjbGFzc05hbWU9XCJib29rLWNhcmRcIj5cbiAgICAgIDxCb29rSW1hZ2VXcmFwcGVyPlxuICAgICAgICA8SW1hZ2VcbiAgICAgICAgICB1cmw9e2ltYWdlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInByb2R1Y3QtaW1hZ2VcIlxuICAgICAgICAgIHN0eWxlPXt7IHBvc2l0aW9uOiAncmVsYXRpdmUnIH19XG4gICAgICAgICAgYWx0PXt0aXRsZX1cbiAgICAgICAgLz5cbiAgICAgICAge2Rpc2NvdW50SW5QZXJjZW50ID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8RGlzY291bnRQZXJjZW50PntkaXNjb3VudEluUGVyY2VudH0lPC9EaXNjb3VudFBlcmNlbnQ+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgJydcbiAgICAgICAgKX1cbiAgICAgIDwvQm9va0ltYWdlV3JhcHBlcj5cbiAgICAgIDxCb29rSW5mbz5cbiAgICAgICAgPFByb2R1Y3ROYW1lPnt0aXRsZX08L1Byb2R1Y3ROYW1lPlxuICAgICAgICA8QXV0aG9ySW5mbz5cbiAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZSBpZD1cImludGxUZXh0QnlcIiBkZWZhdWx0TWVzc2FnZT1cImJ5XCIgLz4ge25hbWV9XG4gICAgICAgIDwvQXV0aG9ySW5mbz5cbiAgICAgIDwvQm9va0luZm8+XG4gICAgPC9Cb29rQ2FyZFdyYXBwZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0Q2FyZDtcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xuaW1wb3J0IHsgdGhlbWVHZXQgfSBmcm9tICdAc3R5bGVkLXN5c3RlbS90aGVtZS1nZXQnO1xuaW1wb3J0IGNzcyBmcm9tICdAc3R5bGVkLXN5c3RlbS9jc3MnO1xuXG5jb25zdCBTdHlsZWRCb3ggPSBzdHlsZWQuZGl2KFxuICBjc3Moe1xuICAgIHB5OiBbMzAsIDUwXSxcbiAgICBweDogWycxcmVtJywgMF0sXG4gIH0pLFxuICB7XG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgfVxuKTtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RDYXJkV3JhcHBlciA9IHN0eWxlZC5kaXYoXG4gIGNzcyh7XG4gICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICd3aGl0ZScsXG4gICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgZm9udEZhbWlseTogJ2luaGVyaXQnLFxuICAgIGJvcmRlclJhZGl1czogJ2Jhc2UnLFxuICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICc6aG92ZXIgLmhpZGQnOntcbiAgICAgIG9wYWNpdHk6JzEgIWltcG9ydGFudCcsXG4gICAgfSxcbiAgICAnOmhvdmVyIC5vbmhvdmVyJzp7XG4gICAgICBkaXNwbGF5Oidub25lICFpbXBvcnRhbnQnLFxuICAgIH0sXG4gICAgXG4gICAgJy5oaWRkJzp7XG4gICAgICB3aWR0aDonMTAwJScsXG4gICAgICBib3JkZXJSYWRpdXM6JzE1cHgnLFxuICAgICAgcGFkZGluZzonNXB4JyxcbiAgICAgIGJhY2tncm91bmQ6JyNGMzlDMTInLFxuICAgICAgYm9yZGVyOicwcHggc29saWQnLFxuICAgICAgbWFyZ2luVG9wOic1cHgnXG4gICAgfSxcbiAgICAnLmNhcmQtY291bnRlcic6IHtcbiAgICAgICdAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpJzoge1xuICAgICAgICB3aWR0aDogMzAsXG4gICAgICAgIGhlaWdodDogOTAsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4tcmV2ZXJzZScsXG4gICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICBib3R0b206IDAsXG4gICAgICAgIHJpZ2h0OiAwLFxuICAgICAgfSxcbiAgICB9LFxuICBcbiAgICBcbiAgICAgXG4gICAgXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdEltYWdlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMjQwcHg7XG4gIHBhZGRpbmc6IDVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG92ZXJmbG93OmhpZGRlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOiAxNzAlO1xuICAgIG1heC1oZWlnaHQ6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB9XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2NDBweCkge1xuICAgIGhlaWdodDogMTQ1cHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBTYWxlVGFnID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LnJlZ3VsYXInLCAnI0ZGQUQ1RScpfTtcbiAgcGFkZGluZzogMCAxMHB4O1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkubWVkaXVtJywgJzEycHgnKX07XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwcHg7XG4gIHJpZ2h0OiAxMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IERpc2NvdW50UGVyY2VudCA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cucmVndWxhcicsICcjRkZBRDVFJyl9O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTVweDtcbiAgcmlnaHQ6IDE1cHg7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLm1lZGl1bScsICcxMnB4Jyl9O1xuICB6LWluZGV4OiAyO1xuYDtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RJbmZvID0gc3R5bGVkLmRpdmBcbiAgcGFkZGluZzogMjBweCAyNXB4IDMwcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MHB4KSB7XG4gICAgcGFkZGluZzogMTVweCAyMHB4O1xuICAgIG1pbi1oZWlnaHQ6IDEyM3B4O1xuICB9XG4gIC5wcm9kdWN0LXRpdGxlIHtcbiAgICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weDtcbiAgICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LmJvbGQnLCAnIzBEMTEzNicpfTtcbiAgICBtYXJnaW46IDAgMCA3cHggMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBtYXJnaW46IDAgMCA1cHggMDtcbiAgICB9XG4gIH1cbiAgLnByb2R1Y3Qtd2VpZ2h0IHtcbiAgICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5yZWd1bGFyJywgJyM3Nzc5OGMnKX07XG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy54cycsICcxMicpfXB4O1xuICAgIH1cbiAgfVxuICAucHJvZHVjdC1tZXRhIHtcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICBtaW4taGVpZ2h0OiAzNnB4O1xuICAgIH1cbiAgICAucHJvZHVjdFByaWNlV3JhcHBlciB7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgd2lkdGg6MTAwJTtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgICAgIC5oaWRke1xuICAgICAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyMwMDAnKX07XG4gICAgICAgIG9wYWNpdHk6MDtcbiAgICAgICAgLmJ0bi10ZXh0IHtcbiAgICAgICAgICBwYWRkaW5nOiAwIDAgMCA2cHg7XG4gICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyMwMDAnKX07XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgICAgICAgIGJvcmRlci1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAucHJvZHVjdC1wcmljZSB7XG4gICAgICAgIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gICAgICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weDtcbiAgICAgICAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICAgICAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgICAgICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCAtIDFweCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC5kaXNjb3VudGVkUHJpY2Uge1xuICAgICAgICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICAgICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICAgICAgICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gICAgICAgIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMueWVsbG93LmhvdmVyJywgJyNGQkI5NzknKX07XG4gICAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICAgICAgcGFkZGluZzogMCA1cHg7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IC0yMHB4O1xuICAgICAgICBsZWZ0OiAtNHB4O1xuICAgICAgICAmOmJlZm9yZSB7XG4gICAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgaGVpZ2h0OiAxcHg7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cuaG92ZXInLCAnI0ZCQjk3OScpfTtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgXG4gICAgfVxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgICAgLnF1YW50aXR5IHtcbiAgICAgICAgd2lkdGg6IDMycHg7XG4gICAgICAgIGhlaWdodDogOTBweDtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGJvdHRvbTogMTVweDtcbiAgICAgICAgcmlnaHQ6IDE1cHg7XG4gICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgIGJveC1zaGFkb3c6IDAgMTBweCAyMHB4IHJnYmEoMCwgMCwgMCwgMC4xNik7XG4gICAgICB9XG4gICAgICBidXR0b24ge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiAyN3B4O1xuICAgICAgfVxuICAgICAgLmluY0J0biB7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICB9XG4gICAgICAuZGVjQnRuIHtcbiAgICAgICAgdG9wOiBhdXRvO1xuICAgICAgICBib3R0b206IDA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgfVxuICAgICAgaW5wdXRbdHlwZT0nbnVtYmVyJ10ge1xuICAgICAgICBsZWZ0OiAwO1xuICAgICAgICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCAtIDFweCk7XG4gICAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gNTRweCk7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAyN3B4O1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICAgICAgfVxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEJ1dHRvblRleHQgPSBzdHlsZWQuc3BhbmBcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IEJvb2tJbWFnZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDI3NXB4O1xuICBwYWRkaW5nOiAwO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIG1heC1oZWlnaHQ6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB9XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGhlaWdodDogMjE1cHg7XG4gIH1cbiAgJHtEaXNjb3VudFBlcmNlbnR9IHtcbiAgICB0b3A6IDA7XG4gICAgcmlnaHQ6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCb29rSW5mbyA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBwYWRkaW5nOiAxNXB4IDBweCAwcHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0TmFtZSA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LmJvbGQnLCAnIzBEMTEzNicpfTtcbiAgbWFyZ2luOiAwIDAgN3B4IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBibG9jaztcbiAgJjpvbmx5LWNoaWxkIHtcbiAgICBtYXJnaW46IDA7XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICAgIG1hcmdpbjogMCAwIDVweCAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQXV0aG9ySW5mbyA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5yZWd1bGFyJywgJyM3Nzc5OGMnKX07XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIH1cbmA7XG5cbi8vIGV4cG9ydCBjb25zdCBBZGRDYXJ0Qm94ID0gc3R5bGVkLmRpdmBcbi8vICAgd2lkdGg6IGNhbGMoMTAwJSAtIDQwcHgpO1xuLy8gICBkaXNwbGF5OiBmbGV4O1xuLy8gICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuLy8gICBhbGlnbi1pdGVtczogY2VudGVyO1xuLy8gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbi8vICAgcGFkZGluZzogMjBweDtcbi8vICAgYm9yZGVyLXJhZGl1czogNnB4O1xuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuLy8gICBib3gtc2hhZG93OiAwIDEwcHggMjBweCByZ2JhKDAsIDAsIDAsIDAuMTYpO1xuLy8gICBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgIHRvcDogNTAlO1xuLy8gICBsZWZ0OiA1MCU7XG4vLyAgIG9wYWNpdHk6IDA7XG4vLyAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xuXG4vLyAgIC5jYXJ0LWJ1dHRvbiB7XG4vLyAgICAgYm9yZGVyLXJhZGl1czogMThweDtcbi8vICAgICBoZWlnaHQ6IDM2cHg7XG4vLyAgICAgcGFkZGluZy1sZWZ0OiAxN3B4O1xuLy8gICAgIHBhZGRpbmctcmlnaHQ6IDE3cHg7XG4vLyAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuMScsICcxMycpfSBweDtcbi8vICAgICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4vLyAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4vLyAgICAgICB3aWR0aDogMzJweDtcbi8vICAgICAgIGhlaWdodDogMzJweDtcbi8vICAgICAgIHBhZGRpbmc6IDA7XG4vLyAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4vLyAgICAgfVxuLy8gICAgIC5idG4tdGV4dCB7XG4vLyAgICAgICBwYWRkaW5nOiAwIDAgMCA2cHg7XG4vLyAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbi8vICAgICAgICAgZGlzcGxheTogbm9uZTtcbi8vICAgICAgIH1cbi8vICAgICB9XG4vLyAgICAgJjpob3ZlciB7XG4vLyAgICAgICBjb2xvcjogI2ZmZjtcbi8vICAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbi8vICAgICAgIGJvcmRlci1jb2xvcjogI0YzOUMxMjtcbi8vICAgICB9XG4vLyAgICAgc3ZnIHtcbi8vICAgICAgIGZpbGw6IGN1cnJlbnRDb2xvcjtcbi8vICAgICB9XG4vLyAgIH1cbi8vIGA7XG5cbmV4cG9ydCBjb25zdCBQcmljZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IFByaWNlID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCAtIDFweCk7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBEaXNjb3VudGVkUHJpY2UgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX0gcHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cucmVndWxhcicsICcjRkZBRDVFJyl9O1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIHBhZGRpbmc6IDAgNXB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgbWFyZ2luLWxlZnQ6IC00cHg7XG4gIHotaW5kZXg6IDI7XG4gICY6YmVmb3JlIHtcbiAgICBjb250ZW50OiAnJztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDFweDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5yZWd1bGFyJywgJyNGRkFENUUnKX07XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogNTAlO1xuICAgIGxlZnQ6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBCb29rQ2FyZFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiAzMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdMYXRvJyl9O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5iYXNlJywgJzZweCcpfTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBwYWRkaW5nOiAxNXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgRm9vZENhcmRXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMDtcbiAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbmA7XG5cbmV4cG9ydCBjb25zdCBGb29kSW1hZ2VXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAyMzBweDtcbiAgcGFkZGluZzogMDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmbGV4LXNocmluazogMDtcbiAgaW1nIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gIH1cbiAgJjphZnRlciB7XG4gICAgY29udGVudDogJyc7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjEpO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICB6LWluZGV4OiAxO1xuICB9XG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGhlaWdodDogMTQ1cHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0TWV0YSA9IHN0eWxlZC5kaXZgXG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbmA7XG5cbmV4cG9ydCBjb25zdCBEZWxpdmVyeU9wdCA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG5gO1xuXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnkgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNDAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQucmVndWxhcicsICcjNzc3OThjJyl9O1xuYDtcblxuZXhwb3J0IGNvbnN0IER1cmF0aW9uID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJpZycsICcxOHB4Jyl9O1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbiAgcGFkZGluZy1yaWdodDogMjBweDtcbiAgaGVpZ2h0OiAzNnB4O1xuICB3aWR0aDogYXV0bztcbiAgYm9yZGVyOiAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcblxuICBAbWVkaWEgKG1heC13aWR0aDogNjAwcHgpIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgfVxuYDtcbiJdLCJzb3VyY2VSb290IjoiIn0=