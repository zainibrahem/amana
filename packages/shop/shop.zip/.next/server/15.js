exports.ids = [15];
exports.modules = {

/***/ "./src/assets/icons/CloseIcon.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/CloseIcon.tsx ***!
  \****************************************/
/*! exports provided: CloseIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return CloseIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CloseIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/modal/center-modal.tsx":
/*!***********************************************!*\
  !*** ./src/components/modal/center-modal.tsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spring */ "react-spring");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spring-modal */ "react-spring-modal");
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! assets/icons/CloseIcon */ "./src/assets/icons/CloseIcon.tsx");
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\modal\\center-modal.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const CenterModal = ({
  isOpen,
  onRequestClose,
  children,
  style = {}
}) => {
  const transition = Object(react_spring__WEBPACK_IMPORTED_MODULE_2__["useTransition"])(isOpen, null, {
    from: {
      opacity: 0
    },
    enter: {
      opacity: 1
    },
    leave: {
      opacity: 0
    }
  });
  const staticStyles = {
    padding: 0,
    maxWidth: 'calc(100% - 30px)',
    height: 'auto',
    maxHeight: 'calc(100vh - 30px)',
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    display: 'flex',
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    zIndex: 99999
  };
  const buttonStyle = {
    width: 35,
    height: 35,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    color: '#0D1136',
    border: 0,
    outline: 0,
    boxShadow: 'none',
    borderRadius: '50%',
    position: 'fixed',
    top: '20px',
    right: '20px',
    zIndex: 100000,
    cursor: 'pointer',
    ':focus': {
      outline: 0,
      boxShadow: 'none'
    }
  };
  const scrollbarStyle = {
    height: '100%',
    width: '100%' // maxHeight: 'calc(100vh - 30px)',

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__["BaseModal"], {
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    children: transition.map(({
      item,
      key,
      props: transitionStyles
    }) => item && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring__WEBPACK_IMPORTED_MODULE_2__["animated"].div, {
        style: _objectSpread({}, transitionStyles),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
          type: "button",
          onClick: onRequestClose,
          style: _objectSpread({}, buttonStyle),
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__["CloseIcon"], {
            style: {
              width: 11,
              height: 11
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 83,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 15
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring__WEBPACK_IMPORTED_MODULE_2__["animated"].div, {
        style: _objectSpread(_objectSpread(_objectSpread({}, transitionStyles), staticStyles), style),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__["Scrollbar"], {
          style: _objectSpread({}, scrollbarStyle),
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 17
        }, undefined)
      }, key, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 15
      }, undefined)]
    }, key, true, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 13
    }, undefined))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (CenterModal);

/***/ }),

/***/ "./src/components/scrollbar/scrollbar.tsx":
/*!************************************************!*\
  !*** ./src/components/scrollbar/scrollbar.tsx ***!
  \************************************************/
/*! exports provided: Scrollbar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Scrollbar", function() { return Scrollbar; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! overlayscrollbars-react */ "overlayscrollbars-react");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\scrollbar\\scrollbar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0Nsb3NlSWNvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbW9kYWwvY2VudGVyLW1vZGFsLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9zY3JvbGxiYXIvc2Nyb2xsYmFyLnRzeCJdLCJuYW1lcyI6WyJDbG9zZUljb24iLCJwcm9wcyIsIkNlbnRlck1vZGFsIiwiaXNPcGVuIiwib25SZXF1ZXN0Q2xvc2UiLCJjaGlsZHJlbiIsInN0eWxlIiwidHJhbnNpdGlvbiIsInVzZVRyYW5zaXRpb24iLCJmcm9tIiwib3BhY2l0eSIsImVudGVyIiwibGVhdmUiLCJzdGF0aWNTdHlsZXMiLCJwYWRkaW5nIiwibWF4V2lkdGgiLCJoZWlnaHQiLCJtYXhIZWlnaHQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJkaXNwbGF5IiwicG9zaXRpb24iLCJ0b3AiLCJsZWZ0IiwidHJhbnNmb3JtIiwiekluZGV4IiwiYnV0dG9uU3R5bGUiLCJ3aWR0aCIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImNvbG9yIiwiYm9yZGVyIiwib3V0bGluZSIsImJveFNoYWRvdyIsInJpZ2h0IiwiY3Vyc29yIiwic2Nyb2xsYmFyU3R5bGUiLCJtYXAiLCJpdGVtIiwia2V5IiwidHJhbnNpdGlvblN0eWxlcyIsIlNjcm9sbGJhciIsImNsYXNzTmFtZSIsIm9wdGlvbnMiLCJzY3JvbGxiYXJzIiwiYXV0b0hpZGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDTyxNQUFNQSxTQUFTLEdBQUlDLEtBQUQsSUFBVztBQUNsQyxzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxRQUZSO0FBR0UsVUFBTSxFQUFDLElBSFQ7QUFJRSxXQUFPLEVBQUM7QUFKVixLQUtNQSxLQUxOO0FBQUEsMkJBT0U7QUFDRSxtQkFBVSw2QkFEWjtBQUVFLE9BQUMsRUFBQyxtTkFGSjtBQUdFLGVBQVMsRUFBQywyQkFIWjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnQkQsQ0FqQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVNBLE1BQU1DLFdBQXVDLEdBQUcsQ0FBQztBQUMvQ0MsUUFEK0M7QUFFL0NDLGdCQUYrQztBQUcvQ0MsVUFIK0M7QUFJL0NDLE9BQUssR0FBRztBQUp1QyxDQUFELEtBSzFDO0FBQ0osUUFBTUMsVUFBVSxHQUFHQyxrRUFBYSxDQUFDTCxNQUFELEVBQVMsSUFBVCxFQUFlO0FBQzdDTSxRQUFJLEVBQUU7QUFBRUMsYUFBTyxFQUFFO0FBQVgsS0FEdUM7QUFFN0NDLFNBQUssRUFBRTtBQUFFRCxhQUFPLEVBQUU7QUFBWCxLQUZzQztBQUc3Q0UsU0FBSyxFQUFFO0FBQUVGLGFBQU8sRUFBRTtBQUFYO0FBSHNDLEdBQWYsQ0FBaEM7QUFNQSxRQUFNRyxZQUFZLEdBQUc7QUFDbkJDLFdBQU8sRUFBRSxDQURVO0FBRW5CQyxZQUFRLEVBQUUsbUJBRlM7QUFHbkJDLFVBQU0sRUFBRSxNQUhXO0FBSW5CQyxhQUFTLEVBQUUsb0JBSlE7QUFLbkJDLG1CQUFlLEVBQUUsU0FMRTtBQU1uQkMsZ0JBQVksRUFBRSxNQU5LO0FBT25CQyxXQUFPLEVBQUUsTUFQVTtBQVFuQkMsWUFBUSxFQUFFLFVBUlM7QUFTbkJDLE9BQUcsRUFBRSxLQVRjO0FBVW5CQyxRQUFJLEVBQUUsS0FWYTtBQVduQkMsYUFBUyxFQUFFLHVCQVhRO0FBWW5CQyxVQUFNLEVBQUU7QUFaVyxHQUFyQjtBQWVBLFFBQU1DLFdBQVcsR0FBRztBQUNsQkMsU0FBSyxFQUFFLEVBRFc7QUFFbEJYLFVBQU0sRUFBRSxFQUZVO0FBR2xCSSxXQUFPLEVBQUUsTUFIUztBQUlsQlEsY0FBVSxFQUFFLFFBSk07QUFLbEJDLGtCQUFjLEVBQUUsUUFMRTtBQU1sQlgsbUJBQWUsRUFBRSxTQU5DO0FBT2xCWSxTQUFLLEVBQUUsU0FQVztBQVFsQkMsVUFBTSxFQUFFLENBUlU7QUFTbEJDLFdBQU8sRUFBRSxDQVRTO0FBVWxCQyxhQUFTLEVBQUUsTUFWTztBQVdsQmQsZ0JBQVksRUFBRSxLQVhJO0FBWWxCRSxZQUFRLEVBQUUsT0FaUTtBQWFsQkMsT0FBRyxFQUFFLE1BYmE7QUFjbEJZLFNBQUssRUFBRSxNQWRXO0FBZWxCVCxVQUFNLEVBQUUsTUFmVTtBQWdCbEJVLFVBQU0sRUFBRSxTQWhCVTtBQWtCbEIsY0FBVTtBQUNSSCxhQUFPLEVBQUUsQ0FERDtBQUVSQyxlQUFTLEVBQUU7QUFGSDtBQWxCUSxHQUFwQjtBQXdCQSxRQUFNRyxjQUFjLEdBQUc7QUFDckJwQixVQUFNLEVBQUUsTUFEYTtBQUVyQlcsU0FBSyxFQUFFLE1BRmMsQ0FHckI7O0FBSHFCLEdBQXZCO0FBTUEsc0JBQ0UscUVBQUMsNERBQUQ7QUFBVyxVQUFNLEVBQUV4QixNQUFuQjtBQUEyQixrQkFBYyxFQUFFQyxjQUEzQztBQUFBLGNBQ0dHLFVBQVUsQ0FBQzhCLEdBQVgsQ0FDQyxDQUFDO0FBQUVDLFVBQUY7QUFBUUMsU0FBUjtBQUFhdEMsV0FBSyxFQUFFdUM7QUFBcEIsS0FBRCxLQUNFRixJQUFJLGlCQUNGLHFFQUFDLDhDQUFEO0FBQUEsOEJBQ0UscUVBQUMscURBQUQsQ0FBVSxHQUFWO0FBQWMsYUFBSyxvQkFBT0UsZ0JBQVAsQ0FBbkI7QUFBQSwrQkFDRTtBQUNFLGNBQUksRUFBQyxRQURQO0FBRUUsaUJBQU8sRUFBRXBDLGNBRlg7QUFHRSxlQUFLLG9CQUFPc0IsV0FBUCxDQUhQO0FBQUEsaUNBS0UscUVBQUMsZ0VBQUQ7QUFBVyxpQkFBSyxFQUFFO0FBQUVDLG1CQUFLLEVBQUUsRUFBVDtBQUFhWCxvQkFBTSxFQUFFO0FBQXJCO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVdFLHFFQUFDLHFEQUFELENBQVUsR0FBVjtBQUVFLGFBQUssZ0RBQU93QixnQkFBUCxHQUE0QjNCLFlBQTVCLEdBQTZDUCxLQUE3QyxDQUZQO0FBQUEsK0JBSUUscUVBQUMsd0VBQUQ7QUFBVyxlQUFLLG9CQUFPOEIsY0FBUCxDQUFoQjtBQUFBLG9CQUEwQy9CO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRixTQUNPa0MsR0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGO0FBQUEsT0FBZUEsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhMO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBMkJELENBcEZEOztBQXNGZXJDLDBFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuR0E7QUFTTyxNQUFNdUMsU0FBbUMsR0FBRyxVQU03QztBQUFBLE1BTjhDO0FBQ2xEcEMsWUFEa0Q7QUFFbERxQyxhQUZrRDtBQUdsREMsV0FIa0Q7QUFJbERyQztBQUprRCxHQU05QztBQUFBLE1BRERMLEtBQ0M7O0FBQ0osc0JBQ0UscUVBQUMsa0ZBQUQ7QUFDRSxXQUFPO0FBQ0x5QyxlQUFTLEVBQUcsR0FBRUEsU0FBVSxnQkFEbkI7QUFFTEUsZ0JBQVUsRUFBRTtBQUNWQyxnQkFBUSxFQUFFO0FBREE7QUFGUCxPQUtGRixPQUxFLENBRFQ7QUFRRSxTQUFLLEVBQUVyQztBQVJULEtBU01MLEtBVE47QUFBQSxjQVdHSTtBQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBdEJNLEMiLCJmaWxlIjoiMTUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENsb3NlSWNvbiA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScxMC4wMDMnXG4gICAgICBoZWlnaHQ9JzEwJ1xuICAgICAgdmlld0JveD0nMCAwIDEwLjAwMyAxMCdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBkYXRhLW5hbWU9J19pb25pY29uc19zdmdfaW9zLWNsb3NlICg1KSdcbiAgICAgICAgZD0nTTE2Ni42ODYsMTY1LjU1bDMuNTczLTMuNTczYS44MzcuODM3LDAsMCwwLTEuMTg0LTEuMTg0bC0zLjU3MywzLjU3My0zLjU3My0zLjU3M2EuODM3LjgzNywwLDEsMC0xLjE4NCwxLjE4NGwzLjU3MywzLjU3My0zLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NCwxLjE4NGwzLjU3My0zLjU3MywzLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NC0xLjE4NFonXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xNjAuNSAtMTYwLjU1KSdcbiAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QsIHsgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2l0aW9uLCBhbmltYXRlZCB9IGZyb20gJ3JlYWN0LXNwcmluZyc7XG5pbXBvcnQgeyBCYXNlTW9kYWwgfSBmcm9tICdyZWFjdC1zcHJpbmctbW9kYWwnO1xuaW1wb3J0IHsgQ2xvc2VJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL0Nsb3NlSWNvbic7XG5pbXBvcnQgeyBTY3JvbGxiYXIgfSBmcm9tICdjb21wb25lbnRzL3Njcm9sbGJhci9zY3JvbGxiYXInO1xuXG50eXBlIFNwcmluZ01vZGFsUHJvcHMgPSB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25SZXF1ZXN0Q2xvc2U6ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIHN0eWxlPzogYW55O1xufTtcblxuY29uc3QgQ2VudGVyTW9kYWw6IFJlYWN0LkZDPFNwcmluZ01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvblJlcXVlc3RDbG9zZSxcbiAgY2hpbGRyZW4sXG4gIHN0eWxlID0ge30sXG59KSA9PiB7XG4gIGNvbnN0IHRyYW5zaXRpb24gPSB1c2VUcmFuc2l0aW9uKGlzT3BlbiwgbnVsbCwge1xuICAgIGZyb206IHsgb3BhY2l0eTogMCB9LFxuICAgIGVudGVyOiB7IG9wYWNpdHk6IDEgfSxcbiAgICBsZWF2ZTogeyBvcGFjaXR5OiAwIH0sXG4gIH0pO1xuXG4gIGNvbnN0IHN0YXRpY1N0eWxlcyA9IHtcbiAgICBwYWRkaW5nOiAwLFxuICAgIG1heFdpZHRoOiAnY2FsYygxMDAlIC0gMzBweCknLFxuICAgIGhlaWdodDogJ2F1dG8nLFxuICAgIG1heEhlaWdodDogJ2NhbGMoMTAwdmggLSAzMHB4KScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnI2ZmZmZmZicsXG4gICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgIHRvcDogJzUwJScsXG4gICAgbGVmdDogJzUwJScsXG4gICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKC01MCUsIC01MCUpJyxcbiAgICB6SW5kZXg6IDk5OTk5LFxuICB9O1xuXG4gIGNvbnN0IGJ1dHRvblN0eWxlID0ge1xuICAgIHdpZHRoOiAzNSxcbiAgICBoZWlnaHQ6IDM1LFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnI2ZmZmZmZicsXG4gICAgY29sb3I6ICcjMEQxMTM2JyxcbiAgICBib3JkZXI6IDAsXG4gICAgb3V0bGluZTogMCxcbiAgICBib3hTaGFkb3c6ICdub25lJyxcbiAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxuICAgIHBvc2l0aW9uOiAnZml4ZWQnIGFzICdmaXhlZCcsXG4gICAgdG9wOiAnMjBweCcsXG4gICAgcmlnaHQ6ICcyMHB4JyxcbiAgICB6SW5kZXg6IDEwMDAwMCxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcblxuICAgICc6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAwLFxuICAgICAgYm94U2hhZG93OiAnbm9uZScsXG4gICAgfSxcbiAgfTtcblxuICBjb25zdCBzY3JvbGxiYXJTdHlsZSA9IHtcbiAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICB3aWR0aDogJzEwMCUnLFxuICAgIC8vIG1heEhlaWdodDogJ2NhbGMoMTAwdmggLSAzMHB4KScsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8QmFzZU1vZGFsIGlzT3Blbj17aXNPcGVufSBvblJlcXVlc3RDbG9zZT17b25SZXF1ZXN0Q2xvc2V9PlxuICAgICAge3RyYW5zaXRpb24ubWFwKFxuICAgICAgICAoeyBpdGVtLCBrZXksIHByb3BzOiB0cmFuc2l0aW9uU3R5bGVzIH0pID0+XG4gICAgICAgICAgaXRlbSAmJiAoXG4gICAgICAgICAgICA8RnJhZ21lbnQga2V5PXtrZXl9PlxuICAgICAgICAgICAgICA8YW5pbWF0ZWQuZGl2IHN0eWxlPXt7IC4uLnRyYW5zaXRpb25TdHlsZXMgfX0+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT0nYnV0dG9uJ1xuICAgICAgICAgICAgICAgICAgb25DbGljaz17b25SZXF1ZXN0Q2xvc2V9XG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyAuLi5idXR0b25TdHlsZSB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDbG9zZUljb24gc3R5bGU9e3sgd2lkdGg6IDExLCBoZWlnaHQ6IDExIH19IC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvYW5pbWF0ZWQuZGl2PlxuXG4gICAgICAgICAgICAgIDxhbmltYXRlZC5kaXZcbiAgICAgICAgICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgICAgICAgICBzdHlsZT17eyAuLi50cmFuc2l0aW9uU3R5bGVzLCAuLi5zdGF0aWNTdHlsZXMsIC4uLnN0eWxlIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2Nyb2xsYmFyIHN0eWxlPXt7IC4uLnNjcm9sbGJhclN0eWxlIH19PntjaGlsZHJlbn08L1Njcm9sbGJhcj5cbiAgICAgICAgICAgICAgPC9hbmltYXRlZC5kaXY+XG4gICAgICAgICAgICA8L0ZyYWdtZW50PlxuICAgICAgICAgIClcbiAgICAgICl9XG4gICAgPC9CYXNlTW9kYWw+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDZW50ZXJNb2RhbDtcbiIsImltcG9ydCB7IE92ZXJsYXlTY3JvbGxiYXJzQ29tcG9uZW50IH0gZnJvbSAnb3ZlcmxheXNjcm9sbGJhcnMtcmVhY3QnO1xuXG50eXBlIFNjcm9sbGJhclByb3BzID0ge1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIG9wdGlvbnM/OiBhbnk7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IFNjcm9sbGJhcjogUmVhY3QuRkM8U2Nyb2xsYmFyUHJvcHM+ID0gKHtcbiAgY2hpbGRyZW4sXG4gIGNsYXNzTmFtZSxcbiAgb3B0aW9ucyxcbiAgc3R5bGUsXG4gIC4uLnByb3BzXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPE92ZXJsYXlTY3JvbGxiYXJzQ29tcG9uZW50XG4gICAgICBvcHRpb25zPXt7XG4gICAgICAgIGNsYXNzTmFtZTogYCR7Y2xhc3NOYW1lfSBvcy10aGVtZS10aGluYCxcbiAgICAgICAgc2Nyb2xsYmFyczoge1xuICAgICAgICAgIGF1dG9IaWRlOiAnbGVhdmUnLFxuICAgICAgICB9LFxuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgfX1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9PdmVybGF5U2Nyb2xsYmFyc0NvbXBvbmVudD5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9