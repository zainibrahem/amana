exports.ids = [16];
exports.modules = {

/***/ "./src/components/error-message/error-message.tsx":
/*!********************************************************!*\
  !*** ./src/components/error-message/error-message.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ErrorMessage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\error-message\\error-message.tsx";

function ErrorMessage({
  message
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(StyledAside, {
    children: message
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 10
  }, this);
}
const StyledAside = styled_components__WEBPACK_IMPORTED_MODULE_1___default.a.aside.withConfig({
  displayName: "error-message__StyledAside",
  componentId: "sc-5jhwvi-0"
})({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100vh',
  padding: '1.5rem',
  fontSize: 'xl',
  color: 'white',
  backgroundColor: 'red'
});

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9lcnJvci1tZXNzYWdlL2Vycm9yLW1lc3NhZ2UudHN4Il0sIm5hbWVzIjpbIkVycm9yTWVzc2FnZSIsIm1lc3NhZ2UiLCJTdHlsZWRBc2lkZSIsInN0eWxlZCIsImFzaWRlIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImhlaWdodCIsInBhZGRpbmciLCJmb250U2l6ZSIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDZSxTQUFTQSxZQUFULENBQXNCO0FBQUVDO0FBQUYsQ0FBdEIsRUFBbUM7QUFDaEQsc0JBQU8scUVBQUMsV0FBRDtBQUFBLGNBQWNBO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ0Q7QUFFRCxNQUFNQyxXQUFXLEdBQUdDLHdEQUFNLENBQUNDLEtBQVY7QUFBQTtBQUFBO0FBQUEsR0FBZ0I7QUFDL0JDLFNBQU8sRUFBRSxNQURzQjtBQUUvQkMsZ0JBQWMsRUFBRSxRQUZlO0FBRy9CQyxZQUFVLEVBQUUsUUFIbUI7QUFJL0JDLFFBQU0sRUFBRSxPQUp1QjtBQUsvQkMsU0FBTyxFQUFFLFFBTHNCO0FBTS9CQyxVQUFRLEVBQUUsSUFOcUI7QUFPL0JDLE9BQUssRUFBRSxPQVB3QjtBQVEvQkMsaUJBQWUsRUFBRTtBQVJjLENBQWhCLENBQWpCLEMiLCJmaWxlIjoiMTYuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVycm9yTWVzc2FnZSh7IG1lc3NhZ2UgfSkge1xuICByZXR1cm4gPFN0eWxlZEFzaWRlPnttZXNzYWdlfTwvU3R5bGVkQXNpZGU+O1xufVxuXG5jb25zdCBTdHlsZWRBc2lkZSA9IHN0eWxlZC5hc2lkZSh7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgaGVpZ2h0OiAnMTAwdmgnLFxuICBwYWRkaW5nOiAnMS41cmVtJyxcbiAgZm9udFNpemU6ICd4bCcsXG4gIGNvbG9yOiAnd2hpdGUnLFxuICBiYWNrZ3JvdW5kQ29sb3I6ICdyZWQnLFxufSk7XG4iXSwic291cmNlUm9vdCI6IiJ9