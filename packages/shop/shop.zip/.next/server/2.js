exports.ids = [2];
exports.modules = {

/***/ "./src/assets/icons/CloseIcon.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/CloseIcon.tsx ***!
  \****************************************/
/*! exports provided: CloseIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return CloseIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CloseIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/LongArrowLeft.tsx":
/*!********************************************!*\
  !*** ./src/assets/icons/LongArrowLeft.tsx ***!
  \********************************************/
/*! exports provided: LongArrowLeft */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LongArrowLeft", function() { return LongArrowLeft; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\LongArrowLeft.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const LongArrowLeft = (_ref) => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "12",
    height: "8.003",
    viewBox: "0 0 12 8.003"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "_ionicons_svg_ios-arrow-round-back (2)",
      d: "M116.447,160.177a.545.545,0,0,1,0,.767l-2.53,2.538h9.641a.542.542,0,0,1,0,1.084h-9.641l2.534,2.538a.549.549,0,0,1,0,.767.54.54,0,0,1-.763,0l-3.435-3.46a.608.608,0,0,1-.113-.171.517.517,0,0,1-.042-.208.543.543,0,0,1,.154-.379l3.435-3.46A.531.531,0,0,1,116.447,160.177Z",
      transform: "translate(-112.1 -160.023)",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/drawer/drawer.tsx":
/*!******************************************!*\
  !*** ./src/components/drawer/drawer.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rc-drawer */ "rc-drawer");
/* harmony import */ var rc_drawer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_drawer__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\drawer\\drawer.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Drawer = (_ref) => {
  let {
    className,
    children,
    closeButton,
    closeButtonStyle,
    drawerHandler,
    toggleHandler,
    open,
    width,
    placement
  } = _ref,
      props = _objectWithoutProperties(_ref, ["className", "children", "closeButton", "closeButtonStyle", "drawerHandler", "toggleHandler", "open", "width", "placement"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(rc_drawer__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({
      open: open,
      onClose: toggleHandler,
      className: `drawer ${className ? className : ''}`.trim(),
      width: width,
      placement: placement,
      handler: false,
      level: null,
      duration: ".4s"
    }, props), {}, {
      children: [closeButton && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "drawer__close",
        onClick: toggleHandler,
        style: closeButtonStyle,
        children: closeButton
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 11
      }, undefined), children]
    }), void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "drawer__handler",
      style: {
        display: 'inline-block'
      },
      onClick: toggleHandler,
      children: drawerHandler
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 5
  }, undefined);
};

Drawer.defaultProps = {
  width: '300px',
  placement: 'left'
};
/* harmony default export */ __webpack_exports__["default"] = (Drawer);

/***/ }),

/***/ "./src/components/scrollbar/scrollbar.tsx":
/*!************************************************!*\
  !*** ./src/components/scrollbar/scrollbar.tsx ***!
  \************************************************/
/*! exports provided: Scrollbar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Scrollbar", function() { return Scrollbar; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! overlayscrollbars-react */ "overlayscrollbars-react");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\scrollbar\\scrollbar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/layouts/header/mobile-drawer.tsx":
/*!**********************************************!*\
  !*** ./src/layouts/header/mobile-drawer.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @redq/reuse-modal */ "@redq/reuse-modal");
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");
/* harmony import */ var components_drawer_drawer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/drawer/drawer */ "./src/components/drawer/drawer.tsx");
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var components_nav_link_nav_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/nav-link/nav-link */ "./src/components/nav-link/nav-link.tsx");
/* harmony import */ var assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! assets/icons/CloseIcon */ "./src/assets/icons/CloseIcon.tsx");
/* harmony import */ var contexts_auth_auth_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! contexts/auth/auth.context */ "./src/contexts/auth/auth.context.tsx");
/* harmony import */ var features_authentication_form__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! features/authentication-form */ "./src/features/authentication-form/index.tsx");
/* harmony import */ var _header_style__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./header.style */ "./src/layouts/header/header.style.tsx");
/* harmony import */ var assets_images_user_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! assets/images/user.jpg */ "./src/assets/images/user.jpg");
/* harmony import */ var site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! site-settings/site-navigation */ "./src/site-settings/site-navigation.ts");
/* harmony import */ var contexts_app_app_provider__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! contexts/app/app.provider */ "./src/contexts/app/app.provider.ts");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\layouts\\header\\mobile-drawer.tsx";
















const MobileDrawer = () => {
  const isDrawerOpen = Object(contexts_app_app_provider__WEBPACK_IMPORTED_MODULE_15__["useAppState"])('isDrawerOpen');
  const dispatch = Object(contexts_app_app_provider__WEBPACK_IMPORTED_MODULE_15__["useAppDispatch"])();
  const {
    authState: {
      isAuthenticated
    },
    authDispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(contexts_auth_auth_context__WEBPACK_IMPORTED_MODULE_10__["AuthContext"]); // Toggle drawer

  const toggleHandler = react__WEBPACK_IMPORTED_MODULE_1___default.a.useCallback(() => {
    dispatch({
      type: 'TOGGLE_DRAWER'
    });
  }, [dispatch]);

  const handleLogout = () => {
    if (false) {}
  };

  const signInOutForm = () => {
    dispatch({
      type: 'TOGGLE_DRAWER'
    });
    authDispatch({
      type: 'SIGNIN'
    });
    Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_2__["openModal"])({
      show: true,
      overlayClassName: 'quick-view-overlay',
      closeOnClickOutside: true,
      component: features_authentication_form__WEBPACK_IMPORTED_MODULE_11__["default"],
      closeComponent: '',
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'quick-view-modal',
        width: 458,
        height: 'auto'
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_drawer_drawer__WEBPACK_IMPORTED_MODULE_6__["default"], {
    width: "316px",
    drawerHandler: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["HamburgerIcon"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 9
    }, undefined),
    open: isDrawerOpen,
    toggleHandler: toggleHandler,
    closeButton: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerClose"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_9__["CloseIcon"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 9
    }, undefined),
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerBody"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__["Scrollbar"], {
        className: "drawer-scrollbar",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerContentWrapper"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerProfile"], {
            children: isAuthenticated ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["LoginView"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["UserAvatar"], {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: assets_images_user_jpg__WEBPACK_IMPORTED_MODULE_13__["default"],
                  alt: "user_avatar"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 105,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 104,
                columnNumber: 19
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["UserDetails"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                  children: "David Kinderson"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 21
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  children: "+990 374 987"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 109,
                  columnNumber: 21
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 107,
                columnNumber: 19
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 103,
              columnNumber: 17
            }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["LogoutView"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_7__["Button"], {
                variant: "primary",
                onClick: signInOutForm,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_4__["FormattedMessage"], {
                  id: "mobileSignInButtonText",
                  defaultMessage: "join"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 115,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 113,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 101,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerMenu"], {
            children: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_14__["MOBILE_DRAWER_MENU"].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerMenuItem"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_nav_link_nav_link__WEBPACK_IMPORTED_MODULE_8__["default"], {
                onClick: toggleHandler,
                href: item.href,
                label: item.defaultMessage,
                intlId: item.id,
                className: "drawer_menu_item"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 127,
                columnNumber: 19
              }, undefined)
            }, item.id, false, {
              fileName: _jsxFileName,
              lineNumber: 126,
              columnNumber: 17
            }, undefined))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 13
          }, undefined), isAuthenticated && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["UserOptionMenu"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerMenuItem"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_nav_link_nav_link__WEBPACK_IMPORTED_MODULE_8__["default"], {
                href: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_14__["PROFILE_PAGE"],
                label: "Your Account Settings",
                className: "drawer_menu_item",
                intlId: "navlinkAccountSettings"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 141,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_12__["DrawerMenuItem"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                onClick: handleLogout,
                className: "drawer_menu_item",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "logoutBtn",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_4__["FormattedMessage"], {
                    id: "navlinkLogout",
                    defaultMessage: "Logout"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 151,
                    columnNumber: 23
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 150,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 149,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 148,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 139,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 98,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 81,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (MobileDrawer);

/***/ }),

/***/ "./src/layouts/header/mobile-header.tsx":
/*!**********************************************!*\
  !*** ./src/layouts/header/mobile-header.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @redq/reuse-modal */ "@redq/reuse-modal");
/* harmony import */ var _redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mobile_drawer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mobile-drawer */ "./src/layouts/header/mobile-drawer.tsx");
/* harmony import */ var _header_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header.style */ "./src/layouts/header/header.style.tsx");
/* harmony import */ var features_search_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! features/search/search */ "./src/features/search/search.tsx");
/* harmony import */ var assets_images_logo_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! assets/images/logo.png */ "./src/assets/images/logo.png");
/* harmony import */ var assets_images_logo_png__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(assets_images_logo_png__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var assets_icons_SearchIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! assets/icons/SearchIcon */ "./src/assets/icons/SearchIcon.tsx");
/* harmony import */ var assets_icons_LongArrowLeft__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! assets/icons/LongArrowLeft */ "./src/assets/icons/LongArrowLeft.tsx");
/* harmony import */ var layouts_logo_logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! layouts/logo/logo */ "./src/layouts/logo/logo.tsx");
/* harmony import */ var _menu_language_switcher_language_switcher__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./menu/language-switcher/language-switcher */ "./src/layouts/header/menu/language-switcher/language-switcher.tsx");
/* harmony import */ var _is_home_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../is-home-page */ "./src/layouts/is-home-page.ts");
/* harmony import */ var utils_useComponentSize__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! utils/useComponentSize */ "./src/utils/useComponentSize.js");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\layouts\\header\\mobile-header.tsx";














const SearchModal = () => {
  const onSubmit = () => {
    Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3__["closeModal"])();
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["SearchModalWrapper"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["SearchModalClose"], {
      type: "submit",
      onClick: () => Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3__["closeModal"])(),
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_LongArrowLeft__WEBPACK_IMPORTED_MODULE_9__["LongArrowLeft"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(features_search_search__WEBPACK_IMPORTED_MODULE_6__["default"], {
      className: "header-modal-search",
      showButtonText: false,
      onSubmit: onSubmit
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 34,
    columnNumber: 5
  }, undefined);
};

const MobileHeader = ({
  className
}) => {
  const {
    pathname,
    query
  } = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  const [mobileHeaderRef, dimensions] = Object(utils_useComponentSize__WEBPACK_IMPORTED_MODULE_13__["default"])();

  const handleSearchModal = () => {
    Object(_redq_reuse_modal__WEBPACK_IMPORTED_MODULE_3__["openModal"])({
      show: true,
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'search-modal-mobile',
        width: '100%',
        height: '100%'
      },
      closeOnClickOutside: false,
      component: SearchModal,
      closeComponent: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 29
      }, undefined)
    });
  };

  const type = pathname === '/restaurant' ? 'restaurant' : query.type;
  const isHomePage = Object(_is_home_page__WEBPACK_IMPORTED_MODULE_12__["isCategoryPage"])(type);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["MobileHeaderWrapper"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["MobileHeaderInnerWrapper"], {
      className: className,
      ref: mobileHeaderRef,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["DrawerWrapper"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_mobile_drawer__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["LogoWrapper"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(layouts_logo_logo__WEBPACK_IMPORTED_MODULE_10__["default"], {
          imageUrl: assets_images_logo_png__WEBPACK_IMPORTED_MODULE_7___default.a,
          alt: "shop logo"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_menu_language_switcher_language_switcher__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 9
      }, undefined), isHomePage ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_header_style__WEBPACK_IMPORTED_MODULE_5__["SearchWrapper"], {
        onClick: handleSearchModal,
        className: "searchIconWrapper",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_SearchIcon__WEBPACK_IMPORTED_MODULE_8__["SearchIcon"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 11
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (MobileHeader);

/***/ }),

/***/ "./src/utils/debounce.ts":
/*!*******************************!*\
  !*** ./src/utils/debounce.ts ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function debounce(func, wait, immediate) {
  let timeout;
  return function executedFunction(...args) {
    const context = this;

    const later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };

    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

/* harmony default export */ __webpack_exports__["default"] = (debounce);

/***/ }),

/***/ "./src/utils/useComponentSize.js":
/*!***************************************!*\
  !*** ./src/utils/useComponentSize.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _debounce__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./debounce */ "./src/utils/debounce.ts");

 // maybe use a hook instead?

function useDimensions(liveMeasure = true, delay = 250, initialDimensions = {}) {
  const {
    0: dimensions,
    1: setDimensions
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(initialDimensions);
  const {
    0: node,
    1: setNode
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const ref = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(newNode => {
    setNode(newNode);
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    // need ref to continue
    if (!node) {
      return;
    }

    const measure = () => {
      window.requestAnimationFrame(() => {
        const newDimensions = node.getBoundingClientRect();
        setDimensions(newDimensions);
      });
    }; // invoke measure right away


    measure();

    if (liveMeasure) {
      const debounceMeasure = Object(_debounce__WEBPACK_IMPORTED_MODULE_1__["default"])(measure, delay);

      if ('ResizeObserver' in window) {
        const resizeObserver = new ResizeObserver(debounceMeasure);
        resizeObserver.observe(node);
        window.addEventListener('scroll', debounceMeasure);
        return () => {
          resizeObserver.disconnect();
          window.removeEventListener('scroll', debounceMeasure);
        };
      }

      window.addEventListener('resize', debounceMeasure);
      window.addEventListener('scroll', debounceMeasure);
      return () => {
        window.removeEventListener('resize', debounceMeasure);
        window.removeEventListener('scroll', debounceMeasure);
      };
    }
  }, [node, liveMeasure, delay]);
  return [ref, dimensions, node];
}

/* harmony default export */ __webpack_exports__["default"] = (useDimensions); // Usage
// function App() {
//   const [wrapperRef, dimensions] = useDimensions();
//   return (
//     <div ref={wrapperRef}>
//       height: {dimensions.height}
//       width: {dimensions.width}
//     </div>
//   );
// }

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0Nsb3NlSWNvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9Mb25nQXJyb3dMZWZ0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9kcmF3ZXIvZHJhd2VyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9zY3JvbGxiYXIvc2Nyb2xsYmFyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvbGF5b3V0cy9oZWFkZXIvbW9iaWxlLWRyYXdlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2xheW91dHMvaGVhZGVyL21vYmlsZS1oZWFkZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy91dGlscy9kZWJvdW5jZS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvdXNlQ29tcG9uZW50U2l6ZS5qcyJdLCJuYW1lcyI6WyJDbG9zZUljb24iLCJwcm9wcyIsIkxvbmdBcnJvd0xlZnQiLCJEcmF3ZXIiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImNsb3NlQnV0dG9uIiwiY2xvc2VCdXR0b25TdHlsZSIsImRyYXdlckhhbmRsZXIiLCJ0b2dnbGVIYW5kbGVyIiwib3BlbiIsIndpZHRoIiwicGxhY2VtZW50IiwidHJpbSIsImRpc3BsYXkiLCJkZWZhdWx0UHJvcHMiLCJTY3JvbGxiYXIiLCJvcHRpb25zIiwic3R5bGUiLCJzY3JvbGxiYXJzIiwiYXV0b0hpZGUiLCJNb2JpbGVEcmF3ZXIiLCJpc0RyYXdlck9wZW4iLCJ1c2VBcHBTdGF0ZSIsImRpc3BhdGNoIiwidXNlQXBwRGlzcGF0Y2giLCJhdXRoU3RhdGUiLCJpc0F1dGhlbnRpY2F0ZWQiLCJhdXRoRGlzcGF0Y2giLCJ1c2VDb250ZXh0IiwiQXV0aENvbnRleHQiLCJSZWFjdCIsInVzZUNhbGxiYWNrIiwidHlwZSIsImhhbmRsZUxvZ291dCIsInNpZ25Jbk91dEZvcm0iLCJvcGVuTW9kYWwiLCJzaG93Iiwib3ZlcmxheUNsYXNzTmFtZSIsImNsb3NlT25DbGlja091dHNpZGUiLCJjb21wb25lbnQiLCJBdXRoZW50aWNhdGlvbkZvcm0iLCJjbG9zZUNvbXBvbmVudCIsImNvbmZpZyIsImVuYWJsZVJlc2l6aW5nIiwiZGlzYWJsZURyYWdnaW5nIiwiaGVpZ2h0IiwiVXNlckltYWdlIiwiTU9CSUxFX0RSQVdFUl9NRU5VIiwibWFwIiwiaXRlbSIsImhyZWYiLCJkZWZhdWx0TWVzc2FnZSIsImlkIiwiUFJPRklMRV9QQUdFIiwiU2VhcmNoTW9kYWwiLCJvblN1Ym1pdCIsImNsb3NlTW9kYWwiLCJNb2JpbGVIZWFkZXIiLCJwYXRobmFtZSIsInF1ZXJ5IiwidXNlUm91dGVyIiwibW9iaWxlSGVhZGVyUmVmIiwiZGltZW5zaW9ucyIsInVzZURpbWVuc2lvbnMiLCJoYW5kbGVTZWFyY2hNb2RhbCIsImlzSG9tZVBhZ2UiLCJpc0NhdGVnb3J5UGFnZSIsIkxvZ29JbWFnZSIsImRlYm91bmNlIiwiZnVuYyIsIndhaXQiLCJpbW1lZGlhdGUiLCJ0aW1lb3V0IiwiZXhlY3V0ZWRGdW5jdGlvbiIsImFyZ3MiLCJjb250ZXh0IiwibGF0ZXIiLCJhcHBseSIsImNhbGxOb3ciLCJjbGVhclRpbWVvdXQiLCJzZXRUaW1lb3V0IiwibGl2ZU1lYXN1cmUiLCJkZWxheSIsImluaXRpYWxEaW1lbnNpb25zIiwic2V0RGltZW5zaW9ucyIsInVzZVN0YXRlIiwibm9kZSIsInNldE5vZGUiLCJyZWYiLCJuZXdOb2RlIiwidXNlRWZmZWN0IiwibWVhc3VyZSIsIndpbmRvdyIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsIm5ld0RpbWVuc2lvbnMiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJkZWJvdW5jZU1lYXN1cmUiLCJyZXNpemVPYnNlcnZlciIsIlJlc2l6ZU9ic2VydmVyIiwib2JzZXJ2ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJkaXNjb25uZWN0IiwicmVtb3ZlRXZlbnRMaXN0ZW5lciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNPLE1BQU1BLFNBQVMsR0FBSUMsS0FBRCxJQUFXO0FBQ2xDLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLFFBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQztBQUpWLEtBS01BLEtBTE47QUFBQSwyQkFPRTtBQUNFLG1CQUFVLDZCQURaO0FBRUUsT0FBQyxFQUFDLG1OQUZKO0FBR0UsZUFBUyxFQUFDLDJCQUhaO0FBSUUsVUFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdCRCxDQWpCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1DLGFBQWEsR0FBRyxVQUFrQjtBQUFBLE1BQVpELEtBQVk7QUFDN0Msc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsSUFGUjtBQUdFLFVBQU0sRUFBQyxPQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQ0UsbUJBQVUsd0NBRFo7QUFFRSxPQUFDLEVBQUMsNlFBRko7QUFHRSxlQUFTLEVBQUMsNEJBSFo7QUFJRSxVQUFJLEVBQUM7QUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0JELENBakJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDQTs7QUFjQSxNQUFNRSxNQUE0QyxHQUFHLFVBVy9DO0FBQUEsTUFYZ0Q7QUFDcERDLGFBRG9EO0FBRXBEQyxZQUZvRDtBQUdwREMsZUFIb0Q7QUFJcERDLG9CQUpvRDtBQUtwREMsaUJBTG9EO0FBTXBEQyxpQkFOb0Q7QUFPcERDLFFBUG9EO0FBUXBEQyxTQVJvRDtBQVNwREM7QUFUb0QsR0FXaEQ7QUFBQSxNQUREWCxLQUNDOztBQUNKLHNCQUNFLHFFQUFDLDhDQUFEO0FBQUEsNEJBQ0UscUVBQUMsZ0RBQUQ7QUFDRSxVQUFJLEVBQUVTLElBRFI7QUFFRSxhQUFPLEVBQUVELGFBRlg7QUFHRSxlQUFTLEVBQUcsVUFBU0wsU0FBUyxHQUFHQSxTQUFILEdBQWUsRUFBRyxFQUFyQyxDQUF1Q1MsSUFBdkMsRUFIYjtBQUlFLFdBQUssRUFBRUYsS0FKVDtBQUtFLGVBQVMsRUFBRUMsU0FMYjtBQU1FLGFBQU8sRUFBRSxLQU5YO0FBT0UsV0FBSyxFQUFFLElBUFQ7QUFRRSxjQUFRLEVBQUM7QUFSWCxPQVNNWCxLQVROO0FBQUEsaUJBV0dLLFdBQVcsaUJBQ1Y7QUFDRSxpQkFBUyxFQUFDLGVBRFo7QUFFRSxlQUFPLEVBQUVHLGFBRlg7QUFHRSxhQUFLLEVBQUVGLGdCQUhUO0FBQUEsa0JBS0dEO0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaSixFQXFCR0QsUUFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBd0JFO0FBQ0UsZUFBUyxFQUFDLGlCQURaO0FBRUUsV0FBSyxFQUFFO0FBQUVTLGVBQU8sRUFBRTtBQUFYLE9BRlQ7QUFHRSxhQUFPLEVBQUVMLGFBSFg7QUFBQSxnQkFLR0Q7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWtDRCxDQTlDRDs7QUFnREFMLE1BQU0sQ0FBQ1ksWUFBUCxHQUFzQjtBQUNwQkosT0FBSyxFQUFFLE9BRGE7QUFFcEJDLFdBQVMsRUFBRTtBQUZTLENBQXRCO0FBS2VULHFFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRUE7QUFTTyxNQUFNYSxTQUFtQyxHQUFHLFVBTTdDO0FBQUEsTUFOOEM7QUFDbERYLFlBRGtEO0FBRWxERCxhQUZrRDtBQUdsRGEsV0FIa0Q7QUFJbERDO0FBSmtELEdBTTlDO0FBQUEsTUFERGpCLEtBQ0M7O0FBQ0osc0JBQ0UscUVBQUMsa0ZBQUQ7QUFDRSxXQUFPO0FBQ0xHLGVBQVMsRUFBRyxHQUFFQSxTQUFVLGdCQURuQjtBQUVMZSxnQkFBVSxFQUFFO0FBQ1ZDLGdCQUFRLEVBQUU7QUFEQTtBQUZQLE9BS0ZILE9BTEUsQ0FEVDtBQVFFLFNBQUssRUFBRUM7QUFSVCxLQVNNakIsS0FUTjtBQUFBLGNBV0dJO0FBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0F0Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVFA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBY0E7QUFDQTtBQUlBOztBQUVBLE1BQU1nQixZQUFxQyxHQUFHLE1BQU07QUFDbEQsUUFBTUMsWUFBWSxHQUFHQyw4RUFBVyxDQUFDLGNBQUQsQ0FBaEM7QUFDQSxRQUFNQyxRQUFRLEdBQUdDLGlGQUFjLEVBQS9CO0FBQ0EsUUFBTTtBQUNKQyxhQUFTLEVBQUU7QUFBRUM7QUFBRixLQURQO0FBRUpDO0FBRkksTUFHRkMsd0RBQVUsQ0FBTUMsdUVBQU4sQ0FIZCxDQUhrRCxDQU9sRDs7QUFDQSxRQUFNckIsYUFBYSxHQUFHc0IsNENBQUssQ0FBQ0MsV0FBTixDQUFrQixNQUFNO0FBQzVDUixZQUFRLENBQUM7QUFDUFMsVUFBSSxFQUFFO0FBREMsS0FBRCxDQUFSO0FBR0QsR0FKcUIsRUFJbkIsQ0FBQ1QsUUFBRCxDQUptQixDQUF0Qjs7QUFNQSxRQUFNVSxZQUFZLEdBQUcsTUFBTTtBQUN6QixlQUFtQyxFQUlsQztBQUNGLEdBTkQ7O0FBUUEsUUFBTUMsYUFBYSxHQUFHLE1BQU07QUFDMUJYLFlBQVEsQ0FBQztBQUNQUyxVQUFJLEVBQUU7QUFEQyxLQUFELENBQVI7QUFJQUwsZ0JBQVksQ0FBQztBQUNYSyxVQUFJLEVBQUU7QUFESyxLQUFELENBQVo7QUFJQUcsdUVBQVMsQ0FBQztBQUNSQyxVQUFJLEVBQUUsSUFERTtBQUVSQyxzQkFBZ0IsRUFBRSxvQkFGVjtBQUdSQyx5QkFBbUIsRUFBRSxJQUhiO0FBSVJDLGVBQVMsRUFBRUMscUVBSkg7QUFLUkMsb0JBQWMsRUFBRSxFQUxSO0FBTVJDLFlBQU0sRUFBRTtBQUNOQyxzQkFBYyxFQUFFLEtBRFY7QUFFTkMsdUJBQWUsRUFBRSxJQUZYO0FBR056QyxpQkFBUyxFQUFFLGtCQUhMO0FBSU5PLGFBQUssRUFBRSxHQUpEO0FBS05tQyxjQUFNLEVBQUU7QUFMRjtBQU5BLEtBQUQsQ0FBVDtBQWNELEdBdkJEOztBQXlCQSxzQkFDRSxxRUFBQyxnRUFBRDtBQUNFLFNBQUssRUFBQyxPQURSO0FBRUUsaUJBQWEsZUFDWCxxRUFBQyw0REFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEo7QUFTRSxRQUFJLEVBQUV4QixZQVRSO0FBVUUsaUJBQWEsRUFBRWIsYUFWakI7QUFXRSxlQUFXLGVBQ1QscUVBQUMsMERBQUQ7QUFBQSw2QkFDRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFaSjtBQUFBLDJCQWlCRSxxRUFBQyx5REFBRDtBQUFBLDZCQUNFLHFFQUFDLHdFQUFEO0FBQVcsaUJBQVMsRUFBQyxrQkFBckI7QUFBQSwrQkFDRSxxRUFBQyxtRUFBRDtBQUFBLGtDQUNFLHFFQUFDLDREQUFEO0FBQUEsc0JBQ0drQixlQUFlLGdCQUNkLHFFQUFDLHdEQUFEO0FBQUEsc0NBQ0UscUVBQUMseURBQUQ7QUFBQSx1Q0FDRTtBQUFLLHFCQUFHLEVBQUVvQiwrREFBVjtBQUFxQixxQkFBRyxFQUFDO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBSUUscUVBQUMsMERBQUQ7QUFBQSx3Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRGMsZ0JBV2QscUVBQUMseURBQUQ7QUFBQSxxQ0FDRSxxRUFBQywrREFBRDtBQUFRLHVCQUFPLEVBQUMsU0FBaEI7QUFBMEIsdUJBQU8sRUFBRVosYUFBbkM7QUFBQSx1Q0FDRSxxRUFBQywyREFBRDtBQUNFLG9CQUFFLEVBQUMsd0JBREw7QUFFRSxnQ0FBYyxFQUFDO0FBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUF3QkUscUVBQUMseURBQUQ7QUFBQSxzQkFDR2EsaUZBQWtCLENBQUNDLEdBQW5CLENBQXdCQyxJQUFELGlCQUN0QixxRUFBQyw2REFBRDtBQUFBLHFDQUNFLHFFQUFDLG9FQUFEO0FBQ0UsdUJBQU8sRUFBRXpDLGFBRFg7QUFFRSxvQkFBSSxFQUFFeUMsSUFBSSxDQUFDQyxJQUZiO0FBR0UscUJBQUssRUFBRUQsSUFBSSxDQUFDRSxjQUhkO0FBSUUsc0JBQU0sRUFBRUYsSUFBSSxDQUFDRyxFQUpmO0FBS0UseUJBQVMsRUFBQztBQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixlQUFxQkgsSUFBSSxDQUFDRyxFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF4QkYsRUFzQ0cxQixlQUFlLGlCQUNkLHFFQUFDLDZEQUFEO0FBQUEsb0NBQ0UscUVBQUMsNkRBQUQ7QUFBQSxxQ0FDRSxxRUFBQyxvRUFBRDtBQUNFLG9CQUFJLEVBQUUyQiwyRUFEUjtBQUVFLHFCQUFLLEVBQUMsdUJBRlI7QUFHRSx5QkFBUyxFQUFDLGtCQUhaO0FBSUUsc0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBU0UscUVBQUMsNkRBQUQ7QUFBQSxxQ0FDRTtBQUFLLHVCQUFPLEVBQUVwQixZQUFkO0FBQTRCLHlCQUFTLEVBQUMsa0JBQXRDO0FBQUEsdUNBQ0U7QUFBTSwyQkFBUyxFQUFDLFdBQWhCO0FBQUEseUNBQ0UscUVBQUMsMkRBQUQ7QUFDRSxzQkFBRSxFQUFDLGVBREw7QUFFRSxrQ0FBYyxFQUFDO0FBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFxRkQsQ0FwSUQ7O0FBc0llYiwyRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFTQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU9BLE1BQU1rQyxXQUF5QixHQUFHLE1BQU07QUFDdEMsUUFBTUMsUUFBUSxHQUFHLE1BQU07QUFDckJDLHdFQUFVO0FBQ1gsR0FGRDs7QUFHQSxzQkFDRSxxRUFBQyxnRUFBRDtBQUFBLDRCQUNFLHFFQUFDLDhEQUFEO0FBQWtCLFVBQUksRUFBQyxRQUF2QjtBQUFnQyxhQUFPLEVBQUUsTUFBTUEsb0VBQVUsRUFBekQ7QUFBQSw2QkFDRSxxRUFBQyx3RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUlFLHFFQUFDLDhEQUFEO0FBQ0UsZUFBUyxFQUFDLHFCQURaO0FBRUUsb0JBQWMsRUFBRSxLQUZsQjtBQUdFLGNBQVEsRUFBRUQ7QUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBWUQsQ0FoQkQ7O0FBa0JBLE1BQU1FLFlBQXlDLEdBQUcsQ0FBQztBQUFFdEQ7QUFBRixDQUFELEtBQW1CO0FBQ25FLFFBQU07QUFBRXVELFlBQUY7QUFBWUM7QUFBWixNQUFzQkMsNkRBQVMsRUFBckM7QUFFQSxRQUFNLENBQUNDLGVBQUQsRUFBa0JDLFVBQWxCLElBQWdDQyx1RUFBYSxFQUFuRDs7QUFFQSxRQUFNQyxpQkFBaUIsR0FBRyxNQUFNO0FBQzlCN0IsdUVBQVMsQ0FBQztBQUNSQyxVQUFJLEVBQUUsSUFERTtBQUVSTSxZQUFNLEVBQUU7QUFDTkMsc0JBQWMsRUFBRSxLQURWO0FBRU5DLHVCQUFlLEVBQUUsSUFGWDtBQUdOekMsaUJBQVMsRUFBRSxxQkFITDtBQUlOTyxhQUFLLEVBQUUsTUFKRDtBQUtObUMsY0FBTSxFQUFFO0FBTEYsT0FGQTtBQVNSUCx5QkFBbUIsRUFBRSxLQVRiO0FBVVJDLGVBQVMsRUFBRWUsV0FWSDtBQVdSYixvQkFBYyxFQUFFLG1CQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFYZCxLQUFELENBQVQ7QUFhRCxHQWREOztBQWVBLFFBQU1ULElBQUksR0FBRzBCLFFBQVEsS0FBSyxhQUFiLEdBQTZCLFlBQTdCLEdBQTRDQyxLQUFLLENBQUMzQixJQUEvRDtBQUVBLFFBQU1pQyxVQUFVLEdBQUdDLHFFQUFjLENBQUNsQyxJQUFELENBQWpDO0FBRUEsc0JBQ0UscUVBQUMsaUVBQUQ7QUFBQSwyQkFDRSxxRUFBQyxzRUFBRDtBQUEwQixlQUFTLEVBQUU3QixTQUFyQztBQUFnRCxTQUFHLEVBQUUwRCxlQUFyRDtBQUFBLDhCQUNFLHFFQUFDLDJEQUFEO0FBQUEsK0JBQ0UscUVBQUMsc0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRSxxRUFBQyx5REFBRDtBQUFBLCtCQUNFLHFFQUFDLDBEQUFEO0FBQU0sa0JBQVEsRUFBRU0sNkRBQWhCO0FBQTJCLGFBQUcsRUFBQztBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQVNFLHFFQUFDLGtGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEYsRUFXR0YsVUFBVSxnQkFDVCxxRUFBQywyREFBRDtBQUNFLGVBQU8sRUFBRUQsaUJBRFg7QUFFRSxpQkFBUyxFQUFDLG1CQUZaO0FBQUEsK0JBSUUscUVBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRFMsR0FPUCxJQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF3QkQsQ0FoREQ7O0FBa0RlUCwyRUFBZixFOzs7Ozs7Ozs7Ozs7QUNoR0E7QUFBQSxTQUFTVyxRQUFULENBQWtCQyxJQUFsQixFQUF3QkMsSUFBeEIsRUFBOEJDLFNBQTlCLEVBQXlDO0FBQ3ZDLE1BQUlDLE9BQUo7QUFFQSxTQUFPLFNBQVNDLGdCQUFULENBQTBCLEdBQUdDLElBQTdCLEVBQW1DO0FBQ3hDLFVBQU1DLE9BQU8sR0FBRyxJQUFoQjs7QUFDQSxVQUFNQyxLQUFLLEdBQUcsWUFBVztBQUN2QkosYUFBTyxHQUFHLElBQVY7QUFDQSxVQUFJLENBQUNELFNBQUwsRUFBZ0JGLElBQUksQ0FBQ1EsS0FBTCxDQUFXRixPQUFYLEVBQW9CRCxJQUFwQjtBQUNqQixLQUhEOztBQUtBLFVBQU1JLE9BQU8sR0FBR1AsU0FBUyxJQUFJLENBQUNDLE9BQTlCO0FBRUFPLGdCQUFZLENBQUNQLE9BQUQsQ0FBWjtBQUVBQSxXQUFPLEdBQUdRLFVBQVUsQ0FBQ0osS0FBRCxFQUFRTixJQUFSLENBQXBCO0FBRUEsUUFBSVEsT0FBSixFQUFhVCxJQUFJLENBQUNRLEtBQUwsQ0FBV0YsT0FBWCxFQUFvQkQsSUFBcEI7QUFDZCxHQWREO0FBZUQ7O0FBRWNOLHVFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3BCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBQ21DOztBQUVuQyxTQUFTTCxhQUFULENBQ0VrQixXQUFXLEdBQUcsSUFEaEIsRUFFRUMsS0FBSyxHQUFHLEdBRlYsRUFHRUMsaUJBQWlCLEdBQUcsRUFIdEIsRUFJRTtBQUNBLFFBQU07QUFBQSxPQUFDckIsVUFBRDtBQUFBLE9BQWFzQjtBQUFiLE1BQThCQyxzREFBUSxDQUFDRixpQkFBRCxDQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDRyxJQUFEO0FBQUEsT0FBT0M7QUFBUCxNQUFrQkYsc0RBQVEsQ0FBQyxJQUFELENBQWhDO0FBRUEsUUFBTUcsR0FBRyxHQUFHekQseURBQVcsQ0FBRTBELE9BQUQsSUFBYTtBQUNuQ0YsV0FBTyxDQUFDRSxPQUFELENBQVA7QUFDRCxHQUZzQixFQUVwQixFQUZvQixDQUF2QjtBQUlBQyx5REFBUyxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQUksQ0FBQ0osSUFBTCxFQUFXO0FBQ1Q7QUFDRDs7QUFFRCxVQUFNSyxPQUFPLEdBQUcsTUFBTTtBQUNwQkMsWUFBTSxDQUFDQyxxQkFBUCxDQUE2QixNQUFNO0FBQ2pDLGNBQU1DLGFBQWEsR0FBR1IsSUFBSSxDQUFDUyxxQkFBTCxFQUF0QjtBQUNBWCxxQkFBYSxDQUFDVSxhQUFELENBQWI7QUFDRCxPQUhEO0FBSUQsS0FMRCxDQU5jLENBWWQ7OztBQUNBSCxXQUFPOztBQUVQLFFBQUlWLFdBQUosRUFBaUI7QUFDZixZQUFNZSxlQUFlLEdBQUc1Qix5REFBUSxDQUFDdUIsT0FBRCxFQUFVVCxLQUFWLENBQWhDOztBQUVBLFVBQUksb0JBQW9CVSxNQUF4QixFQUFnQztBQUM5QixjQUFNSyxjQUFjLEdBQUcsSUFBSUMsY0FBSixDQUFtQkYsZUFBbkIsQ0FBdkI7QUFDQUMsc0JBQWMsQ0FBQ0UsT0FBZixDQUF1QmIsSUFBdkI7QUFDQU0sY0FBTSxDQUFDUSxnQkFBUCxDQUF3QixRQUF4QixFQUFrQ0osZUFBbEM7QUFFQSxlQUFPLE1BQU07QUFDWEMsd0JBQWMsQ0FBQ0ksVUFBZjtBQUNBVCxnQkFBTSxDQUFDVSxtQkFBUCxDQUEyQixRQUEzQixFQUFxQ04sZUFBckM7QUFDRCxTQUhEO0FBSUQ7O0FBQ0RKLFlBQU0sQ0FBQ1EsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NKLGVBQWxDO0FBQ0FKLFlBQU0sQ0FBQ1EsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NKLGVBQWxDO0FBRUEsYUFBTyxNQUFNO0FBQ1hKLGNBQU0sQ0FBQ1UsbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUNOLGVBQXJDO0FBQ0FKLGNBQU0sQ0FBQ1UsbUJBQVAsQ0FBMkIsUUFBM0IsRUFBcUNOLGVBQXJDO0FBQ0QsT0FIRDtBQUlEO0FBQ0YsR0FwQ1EsRUFvQ04sQ0FBQ1YsSUFBRCxFQUFPTCxXQUFQLEVBQW9CQyxLQUFwQixDQXBDTSxDQUFUO0FBc0NBLFNBQU8sQ0FBQ00sR0FBRCxFQUFNMUIsVUFBTixFQUFrQndCLElBQWxCLENBQVA7QUFDRDs7QUFFY3ZCLDRFQUFmLEUsQ0FFQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJIiwiZmlsZSI6IjIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENsb3NlSWNvbiA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScxMC4wMDMnXG4gICAgICBoZWlnaHQ9JzEwJ1xuICAgICAgdmlld0JveD0nMCAwIDEwLjAwMyAxMCdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBkYXRhLW5hbWU9J19pb25pY29uc19zdmdfaW9zLWNsb3NlICg1KSdcbiAgICAgICAgZD0nTTE2Ni42ODYsMTY1LjU1bDMuNTczLTMuNTczYS44MzcuODM3LDAsMCwwLTEuMTg0LTEuMTg0bC0zLjU3MywzLjU3My0zLjU3My0zLjU3M2EuODM3LjgzNywwLDEsMC0xLjE4NCwxLjE4NGwzLjU3MywzLjU3My0zLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NCwxLjE4NGwzLjU3My0zLjU3MywzLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NC0xLjE4NFonXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xNjAuNSAtMTYwLjU1KSdcbiAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IExvbmdBcnJvd0xlZnQgPSAoeyAuLi5wcm9wcyB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9JzEyJ1xuICAgICAgaGVpZ2h0PSc4LjAwMydcbiAgICAgIHZpZXdCb3g9JzAgMCAxMiA4LjAwMydcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBkYXRhLW5hbWU9J19pb25pY29uc19zdmdfaW9zLWFycm93LXJvdW5kLWJhY2sgKDIpJ1xuICAgICAgICBkPSdNMTE2LjQ0NywxNjAuMTc3YS41NDUuNTQ1LDAsMCwxLDAsLjc2N2wtMi41MywyLjUzOGg5LjY0MWEuNTQyLjU0MiwwLDAsMSwwLDEuMDg0aC05LjY0MWwyLjUzNCwyLjUzOGEuNTQ5LjU0OSwwLDAsMSwwLC43NjcuNTQuNTQsMCwwLDEtLjc2MywwbC0zLjQzNS0zLjQ2YS42MDguNjA4LDAsMCwxLS4xMTMtLjE3MS41MTcuNTE3LDAsMCwxLS4wNDItLjIwOC41NDMuNTQzLDAsMCwxLC4xNTQtLjM3OWwzLjQzNS0zLjQ2QS41MzEuNTMxLDAsMCwxLDExNi40NDcsMTYwLjE3N1onXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xMTIuMSAtMTYwLjAyMyknXG4gICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0LCB7IEZyYWdtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IFJjRHJhd2VyIGZyb20gJ3JjLWRyYXdlcic7XG5cbnR5cGUgRHJhd2VyUHJvcHMgPSB7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgY2hpbGRyZW4/OiBhbnk7XG4gIGNsb3NlQnV0dG9uPzogYW55O1xuICBjbG9zZUJ1dHRvblN0eWxlPzogYW55O1xuICBkcmF3ZXJIYW5kbGVyOiBhbnk7XG4gIHRvZ2dsZUhhbmRsZXI6IGFueTtcbiAgb3BlbjogYW55O1xuICB3aWR0aD86IHN0cmluZztcbiAgcGxhY2VtZW50PzogJ2xlZnQnIHwgJ3JpZ2h0JyB8ICd0b3AnIHwgJ2JvdHRvbSc7XG59O1xuXG5jb25zdCBEcmF3ZXI6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PERyYXdlclByb3BzPiA9ICh7XG4gIGNsYXNzTmFtZSxcbiAgY2hpbGRyZW4sXG4gIGNsb3NlQnV0dG9uLFxuICBjbG9zZUJ1dHRvblN0eWxlLFxuICBkcmF3ZXJIYW5kbGVyLFxuICB0b2dnbGVIYW5kbGVyLFxuICBvcGVuLFxuICB3aWR0aCxcbiAgcGxhY2VtZW50LFxuICAuLi5wcm9wc1xufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxGcmFnbWVudD5cbiAgICAgIDxSY0RyYXdlclxuICAgICAgICBvcGVuPXtvcGVufVxuICAgICAgICBvbkNsb3NlPXt0b2dnbGVIYW5kbGVyfVxuICAgICAgICBjbGFzc05hbWU9e2BkcmF3ZXIgJHtjbGFzc05hbWUgPyBjbGFzc05hbWUgOiAnJ31gLnRyaW0oKX1cbiAgICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgICBwbGFjZW1lbnQ9e3BsYWNlbWVudH1cbiAgICAgICAgaGFuZGxlcj17ZmFsc2V9XG4gICAgICAgIGxldmVsPXtudWxsfVxuICAgICAgICBkdXJhdGlvbj1cIi40c1wiXG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgID5cbiAgICAgICAge2Nsb3NlQnV0dG9uICYmIChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJkcmF3ZXJfX2Nsb3NlXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUhhbmRsZXJ9XG4gICAgICAgICAgICBzdHlsZT17Y2xvc2VCdXR0b25TdHlsZX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Y2xvc2VCdXR0b259XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9SY0RyYXdlcj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZHJhd2VyX19oYW5kbGVyXCJcbiAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1ibG9jaycgfX1cbiAgICAgICAgb25DbGljaz17dG9nZ2xlSGFuZGxlcn1cbiAgICAgID5cbiAgICAgICAge2RyYXdlckhhbmRsZXJ9XG4gICAgICA8L2Rpdj5cbiAgICA8L0ZyYWdtZW50PlxuICApO1xufTtcblxuRHJhd2VyLmRlZmF1bHRQcm9wcyA9IHtcbiAgd2lkdGg6ICczMDBweCcsXG4gIHBsYWNlbWVudDogJ2xlZnQnLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgRHJhd2VyO1xuIiwiaW1wb3J0IHsgT3ZlcmxheVNjcm9sbGJhcnNDb21wb25lbnQgfSBmcm9tICdvdmVybGF5c2Nyb2xsYmFycy1yZWFjdCc7XG5cbnR5cGUgU2Nyb2xsYmFyUHJvcHMgPSB7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbiAgb3B0aW9ucz86IGFueTtcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgU2Nyb2xsYmFyOiBSZWFjdC5GQzxTY3JvbGxiYXJQcm9wcz4gPSAoe1xuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lLFxuICBvcHRpb25zLFxuICBzdHlsZSxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8T3ZlcmxheVNjcm9sbGJhcnNDb21wb25lbnRcbiAgICAgIG9wdGlvbnM9e3tcbiAgICAgICAgY2xhc3NOYW1lOiBgJHtjbGFzc05hbWV9IG9zLXRoZW1lLXRoaW5gLFxuICAgICAgICBzY3JvbGxiYXJzOiB7XG4gICAgICAgICAgYXV0b0hpZGU6ICdsZWF2ZScsXG4gICAgICAgIH0sXG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICB9fVxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L092ZXJsYXlTY3JvbGxiYXJzQ29tcG9uZW50PlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgb3Blbk1vZGFsIH0gZnJvbSAnQHJlZHEvcmV1c2UtbW9kYWwnO1xuaW1wb3J0IFJvdXRlciBmcm9tICduZXh0L3JvdXRlcic7XG5pbXBvcnQgeyBGb3JtYXR0ZWRNZXNzYWdlIH0gZnJvbSAncmVhY3QtaW50bCc7XG5pbXBvcnQgeyBTY3JvbGxiYXIgfSBmcm9tICdjb21wb25lbnRzL3Njcm9sbGJhci9zY3JvbGxiYXInO1xuaW1wb3J0IERyYXdlciBmcm9tICdjb21wb25lbnRzL2RyYXdlci9kcmF3ZXInO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnY29tcG9uZW50cy9idXR0b24vYnV0dG9uJztcbmltcG9ydCBOYXZMaW5rIGZyb20gJ2NvbXBvbmVudHMvbmF2LWxpbmsvbmF2LWxpbmsnO1xuaW1wb3J0IHsgQ2xvc2VJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL0Nsb3NlSWNvbic7XG5pbXBvcnQgeyBBdXRoQ29udGV4dCB9IGZyb20gJ2NvbnRleHRzL2F1dGgvYXV0aC5jb250ZXh0JztcbmltcG9ydCBBdXRoZW50aWNhdGlvbkZvcm0gZnJvbSAnZmVhdHVyZXMvYXV0aGVudGljYXRpb24tZm9ybSc7XG5pbXBvcnQge1xuICBEcmF3ZXJCb2R5LFxuICBIYW1idXJnZXJJY29uLFxuICBEcmF3ZXJDb250ZW50V3JhcHBlcixcbiAgRHJhd2VyQ2xvc2UsXG4gIERyYXdlclByb2ZpbGUsXG4gIExvZ291dFZpZXcsXG4gIExvZ2luVmlldyxcbiAgVXNlckF2YXRhcixcbiAgVXNlckRldGFpbHMsXG4gIERyYXdlck1lbnUsXG4gIERyYXdlck1lbnVJdGVtLFxuICBVc2VyT3B0aW9uTWVudSxcbn0gZnJvbSAnLi9oZWFkZXIuc3R5bGUnO1xuaW1wb3J0IFVzZXJJbWFnZSBmcm9tICdhc3NldHMvaW1hZ2VzL3VzZXIuanBnJztcbmltcG9ydCB7XG4gIE1PQklMRV9EUkFXRVJfTUVOVSxcbiAgUFJPRklMRV9QQUdFLFxufSBmcm9tICdzaXRlLXNldHRpbmdzL3NpdGUtbmF2aWdhdGlvbic7XG5pbXBvcnQgeyB1c2VBcHBTdGF0ZSwgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tICdjb250ZXh0cy9hcHAvYXBwLnByb3ZpZGVyJztcblxuY29uc3QgTW9iaWxlRHJhd2VyOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudCA9ICgpID0+IHtcbiAgY29uc3QgaXNEcmF3ZXJPcGVuID0gdXNlQXBwU3RhdGUoJ2lzRHJhd2VyT3BlbicpO1xuICBjb25zdCBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIGNvbnN0IHtcbiAgICBhdXRoU3RhdGU6IHsgaXNBdXRoZW50aWNhdGVkIH0sXG4gICAgYXV0aERpc3BhdGNoLFxuICB9ID0gdXNlQ29udGV4dDxhbnk+KEF1dGhDb250ZXh0KTtcbiAgLy8gVG9nZ2xlIGRyYXdlclxuICBjb25zdCB0b2dnbGVIYW5kbGVyID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGRpc3BhdGNoKHtcbiAgICAgIHR5cGU6ICdUT0dHTEVfRFJBV0VSJyxcbiAgICB9KTtcbiAgfSwgW2Rpc3BhdGNoXSk7XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2FjY2Vzc190b2tlbicpO1xuICAgICAgYXV0aERpc3BhdGNoKHsgdHlwZTogJ1NJR05fT1VUJyB9KTtcbiAgICAgIFJvdXRlci5wdXNoKCcvJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHNpZ25Jbk91dEZvcm0gPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goe1xuICAgICAgdHlwZTogJ1RPR0dMRV9EUkFXRVInLFxuICAgIH0pO1xuXG4gICAgYXV0aERpc3BhdGNoKHtcbiAgICAgIHR5cGU6ICdTSUdOSU4nLFxuICAgIH0pO1xuXG4gICAgb3Blbk1vZGFsKHtcbiAgICAgIHNob3c6IHRydWUsXG4gICAgICBvdmVybGF5Q2xhc3NOYW1lOiAncXVpY2stdmlldy1vdmVybGF5JyxcbiAgICAgIGNsb3NlT25DbGlja091dHNpZGU6IHRydWUsXG4gICAgICBjb21wb25lbnQ6IEF1dGhlbnRpY2F0aW9uRm9ybSxcbiAgICAgIGNsb3NlQ29tcG9uZW50OiAnJyxcbiAgICAgIGNvbmZpZzoge1xuICAgICAgICBlbmFibGVSZXNpemluZzogZmFsc2UsXG4gICAgICAgIGRpc2FibGVEcmFnZ2luZzogdHJ1ZSxcbiAgICAgICAgY2xhc3NOYW1lOiAncXVpY2stdmlldy1tb2RhbCcsXG4gICAgICAgIHdpZHRoOiA0NTgsXG4gICAgICAgIGhlaWdodDogJ2F1dG8nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxEcmF3ZXJcbiAgICAgIHdpZHRoPSczMTZweCdcbiAgICAgIGRyYXdlckhhbmRsZXI9e1xuICAgICAgICA8SGFtYnVyZ2VySWNvbj5cbiAgICAgICAgICA8c3BhbiAvPlxuICAgICAgICAgIDxzcGFuIC8+XG4gICAgICAgICAgPHNwYW4gLz5cbiAgICAgICAgPC9IYW1idXJnZXJJY29uPlxuICAgICAgfVxuICAgICAgb3Blbj17aXNEcmF3ZXJPcGVufVxuICAgICAgdG9nZ2xlSGFuZGxlcj17dG9nZ2xlSGFuZGxlcn1cbiAgICAgIGNsb3NlQnV0dG9uPXtcbiAgICAgICAgPERyYXdlckNsb3NlPlxuICAgICAgICAgIDxDbG9zZUljb24gLz5cbiAgICAgICAgPC9EcmF3ZXJDbG9zZT5cbiAgICAgIH1cbiAgICA+XG4gICAgICA8RHJhd2VyQm9keT5cbiAgICAgICAgPFNjcm9sbGJhciBjbGFzc05hbWU9J2RyYXdlci1zY3JvbGxiYXInPlxuICAgICAgICAgIDxEcmF3ZXJDb250ZW50V3JhcHBlcj5cbiAgICAgICAgICAgIDxEcmF3ZXJQcm9maWxlPlxuICAgICAgICAgICAgICB7aXNBdXRoZW50aWNhdGVkID8gKFxuICAgICAgICAgICAgICAgIDxMb2dpblZpZXc+XG4gICAgICAgICAgICAgICAgICA8VXNlckF2YXRhcj5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e1VzZXJJbWFnZX0gYWx0PSd1c2VyX2F2YXRhcicgLz5cbiAgICAgICAgICAgICAgICAgIDwvVXNlckF2YXRhcj5cbiAgICAgICAgICAgICAgICAgIDxVc2VyRGV0YWlscz5cbiAgICAgICAgICAgICAgICAgICAgPGgzPkRhdmlkIEtpbmRlcnNvbjwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPis5OTAgMzc0IDk4Nzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvVXNlckRldGFpbHM+XG4gICAgICAgICAgICAgICAgPC9Mb2dpblZpZXc+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPExvZ291dFZpZXc+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9J3ByaW1hcnknIG9uQ2xpY2s9e3NpZ25Jbk91dEZvcm19PlxuICAgICAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZVxuICAgICAgICAgICAgICAgICAgICAgIGlkPSdtb2JpbGVTaWduSW5CdXR0b25UZXh0J1xuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRNZXNzYWdlPSdqb2luJ1xuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9Mb2dvdXRWaWV3PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9EcmF3ZXJQcm9maWxlPlxuXG4gICAgICAgICAgICA8RHJhd2VyTWVudT5cbiAgICAgICAgICAgICAge01PQklMRV9EUkFXRVJfTUVOVS5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICA8RHJhd2VyTWVudUl0ZW0ga2V5PXtpdGVtLmlkfT5cbiAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUhhbmRsZXJ9XG4gICAgICAgICAgICAgICAgICAgIGhyZWY9e2l0ZW0uaHJlZn1cbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2l0ZW0uZGVmYXVsdE1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgIGludGxJZD17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdkcmF3ZXJfbWVudV9pdGVtJ1xuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L0RyYXdlck1lbnVJdGVtPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvRHJhd2VyTWVudT5cblxuICAgICAgICAgICAge2lzQXV0aGVudGljYXRlZCAmJiAoXG4gICAgICAgICAgICAgIDxVc2VyT3B0aW9uTWVudT5cbiAgICAgICAgICAgICAgICA8RHJhd2VyTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgICAgICBocmVmPXtQUk9GSUxFX1BBR0V9XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPSdZb3VyIEFjY291bnQgU2V0dGluZ3MnXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZHJhd2VyX21lbnVfaXRlbSdcbiAgICAgICAgICAgICAgICAgICAgaW50bElkPSduYXZsaW5rQWNjb3VudFNldHRpbmdzJ1xuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L0RyYXdlck1lbnVJdGVtPlxuICAgICAgICAgICAgICAgIDxEcmF3ZXJNZW51SXRlbT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgb25DbGljaz17aGFuZGxlTG9nb3V0fSBjbGFzc05hbWU9J2RyYXdlcl9tZW51X2l0ZW0nPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2xvZ291dEJ0bic+XG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPSduYXZsaW5rTG9nb3V0J1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdE1lc3NhZ2U9J0xvZ291dCdcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0RyYXdlck1lbnVJdGVtPlxuICAgICAgICAgICAgICA8L1VzZXJPcHRpb25NZW51PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0RyYXdlckNvbnRlbnRXcmFwcGVyPlxuICAgICAgICA8L1Njcm9sbGJhcj5cbiAgICAgIDwvRHJhd2VyQm9keT5cbiAgICA8L0RyYXdlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IE1vYmlsZURyYXdlcjtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XG5pbXBvcnQgeyBvcGVuTW9kYWwsIGNsb3NlTW9kYWwgfSBmcm9tICdAcmVkcS9yZXVzZS1tb2RhbCc7XG5pbXBvcnQgTW9iaWxlRHJhd2VyIGZyb20gJy4vbW9iaWxlLWRyYXdlcic7XG5pbXBvcnQge1xuICBNb2JpbGVIZWFkZXJXcmFwcGVyLFxuICBNb2JpbGVIZWFkZXJJbm5lcldyYXBwZXIsXG4gIERyYXdlcldyYXBwZXIsXG4gIExvZ29XcmFwcGVyLFxuICBTZWFyY2hXcmFwcGVyLFxuICBTZWFyY2hNb2RhbFdyYXBwZXIsXG4gIFNlYXJjaE1vZGFsQ2xvc2UsXG59IGZyb20gJy4vaGVhZGVyLnN0eWxlJztcbmltcG9ydCBTZWFyY2ggZnJvbSAnZmVhdHVyZXMvc2VhcmNoL3NlYXJjaCc7XG5pbXBvcnQgTG9nb0ltYWdlIGZyb20gJ2Fzc2V0cy9pbWFnZXMvbG9nby5wbmcnO1xuXG5pbXBvcnQgeyBTZWFyY2hJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL1NlYXJjaEljb24nO1xuaW1wb3J0IHsgTG9uZ0Fycm93TGVmdCB9IGZyb20gJ2Fzc2V0cy9pY29ucy9Mb25nQXJyb3dMZWZ0JztcbmltcG9ydCBMb2dvIGZyb20gJ2xheW91dHMvbG9nby9sb2dvJztcbmltcG9ydCBMYW5ndWFnZVN3aXRjaGVyIGZyb20gJy4vbWVudS9sYW5ndWFnZS1zd2l0Y2hlci9sYW5ndWFnZS1zd2l0Y2hlcic7XG5pbXBvcnQgeyBpc0NhdGVnb3J5UGFnZSB9IGZyb20gJy4uL2lzLWhvbWUtcGFnZSc7XG5pbXBvcnQgdXNlRGltZW5zaW9ucyBmcm9tICd1dGlscy91c2VDb21wb25lbnRTaXplJztcblxudHlwZSBNb2JpbGVIZWFkZXJQcm9wcyA9IHtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBjbG9zZVNlYXJjaD86IGFueTtcbn07XG5cbmNvbnN0IFNlYXJjaE1vZGFsOiBSZWFjdC5GQzx7fT4gPSAoKSA9PiB7XG4gIGNvbnN0IG9uU3VibWl0ID0gKCkgPT4ge1xuICAgIGNsb3NlTW9kYWwoKTtcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8U2VhcmNoTW9kYWxXcmFwcGVyPlxuICAgICAgPFNlYXJjaE1vZGFsQ2xvc2UgdHlwZT0nc3VibWl0JyBvbkNsaWNrPXsoKSA9PiBjbG9zZU1vZGFsKCl9PlxuICAgICAgICA8TG9uZ0Fycm93TGVmdCAvPlxuICAgICAgPC9TZWFyY2hNb2RhbENsb3NlPlxuICAgICAgPFNlYXJjaFxuICAgICAgICBjbGFzc05hbWU9J2hlYWRlci1tb2RhbC1zZWFyY2gnXG4gICAgICAgIHNob3dCdXR0b25UZXh0PXtmYWxzZX1cbiAgICAgICAgb25TdWJtaXQ9e29uU3VibWl0fVxuICAgICAgLz5cbiAgICA8L1NlYXJjaE1vZGFsV3JhcHBlcj5cbiAgKTtcbn07XG5cbmNvbnN0IE1vYmlsZUhlYWRlcjogUmVhY3QuRkM8TW9iaWxlSGVhZGVyUHJvcHM+ID0gKHsgY2xhc3NOYW1lIH0pID0+IHtcbiAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnkgfSA9IHVzZVJvdXRlcigpO1xuXG4gIGNvbnN0IFttb2JpbGVIZWFkZXJSZWYsIGRpbWVuc2lvbnNdID0gdXNlRGltZW5zaW9ucygpO1xuXG4gIGNvbnN0IGhhbmRsZVNlYXJjaE1vZGFsID0gKCkgPT4ge1xuICAgIG9wZW5Nb2RhbCh7XG4gICAgICBzaG93OiB0cnVlLFxuICAgICAgY29uZmlnOiB7XG4gICAgICAgIGVuYWJsZVJlc2l6aW5nOiBmYWxzZSxcbiAgICAgICAgZGlzYWJsZURyYWdnaW5nOiB0cnVlLFxuICAgICAgICBjbGFzc05hbWU6ICdzZWFyY2gtbW9kYWwtbW9iaWxlJyxcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgICB9LFxuICAgICAgY2xvc2VPbkNsaWNrT3V0c2lkZTogZmFsc2UsXG4gICAgICBjb21wb25lbnQ6IFNlYXJjaE1vZGFsLFxuICAgICAgY2xvc2VDb21wb25lbnQ6ICgpID0+IDxkaXYgLz4sXG4gICAgfSk7XG4gIH07XG4gIGNvbnN0IHR5cGUgPSBwYXRobmFtZSA9PT0gJy9yZXN0YXVyYW50JyA/ICdyZXN0YXVyYW50JyA6IHF1ZXJ5LnR5cGU7XG5cbiAgY29uc3QgaXNIb21lUGFnZSA9IGlzQ2F0ZWdvcnlQYWdlKHR5cGUpO1xuXG4gIHJldHVybiAoXG4gICAgPE1vYmlsZUhlYWRlcldyYXBwZXI+XG4gICAgICA8TW9iaWxlSGVhZGVySW5uZXJXcmFwcGVyIGNsYXNzTmFtZT17Y2xhc3NOYW1lfSByZWY9e21vYmlsZUhlYWRlclJlZn0+XG4gICAgICAgIDxEcmF3ZXJXcmFwcGVyPlxuICAgICAgICAgIDxNb2JpbGVEcmF3ZXIgLz5cbiAgICAgICAgPC9EcmF3ZXJXcmFwcGVyPlxuXG4gICAgICAgIDxMb2dvV3JhcHBlcj5cbiAgICAgICAgICA8TG9nbyBpbWFnZVVybD17TG9nb0ltYWdlfSBhbHQ9J3Nob3AgbG9nbycgLz5cbiAgICAgICAgPC9Mb2dvV3JhcHBlcj5cblxuICAgICAgICA8TGFuZ3VhZ2VTd2l0Y2hlciAvPlxuXG4gICAgICAgIHtpc0hvbWVQYWdlID8gKFxuICAgICAgICAgIDxTZWFyY2hXcmFwcGVyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZWFyY2hNb2RhbH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0nc2VhcmNoSWNvbldyYXBwZXInXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNlYXJjaEljb24gLz5cbiAgICAgICAgICA8L1NlYXJjaFdyYXBwZXI+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9Nb2JpbGVIZWFkZXJJbm5lcldyYXBwZXI+XG4gICAgPC9Nb2JpbGVIZWFkZXJXcmFwcGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTW9iaWxlSGVhZGVyO1xuIiwiZnVuY3Rpb24gZGVib3VuY2UoZnVuYywgd2FpdCwgaW1tZWRpYXRlKSB7XG4gIGxldCB0aW1lb3V0O1xuXG4gIHJldHVybiBmdW5jdGlvbiBleGVjdXRlZEZ1bmN0aW9uKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBjb250ZXh0ID0gdGhpcztcbiAgICBjb25zdCBsYXRlciA9IGZ1bmN0aW9uKCkge1xuICAgICAgdGltZW91dCA9IG51bGw7XG4gICAgICBpZiAoIWltbWVkaWF0ZSkgZnVuYy5hcHBseShjb250ZXh0LCBhcmdzKTtcbiAgICB9O1xuXG4gICAgY29uc3QgY2FsbE5vdyA9IGltbWVkaWF0ZSAmJiAhdGltZW91dDtcblxuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcblxuICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KGxhdGVyLCB3YWl0KTtcblxuICAgIGlmIChjYWxsTm93KSBmdW5jLmFwcGx5KGNvbnRleHQsIGFyZ3MpO1xuICB9O1xufVxuXG5leHBvcnQgZGVmYXVsdCBkZWJvdW5jZTtcbiIsImltcG9ydCB7IHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGRlYm91bmNlIGZyb20gJy4vZGVib3VuY2UnOyAvLyBtYXliZSB1c2UgYSBob29rIGluc3RlYWQ/XG5cbmZ1bmN0aW9uIHVzZURpbWVuc2lvbnMoXG4gIGxpdmVNZWFzdXJlID0gdHJ1ZSxcbiAgZGVsYXkgPSAyNTAsXG4gIGluaXRpYWxEaW1lbnNpb25zID0ge31cbikge1xuICBjb25zdCBbZGltZW5zaW9ucywgc2V0RGltZW5zaW9uc10gPSB1c2VTdGF0ZShpbml0aWFsRGltZW5zaW9ucyk7XG4gIGNvbnN0IFtub2RlLCBzZXROb2RlXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIGNvbnN0IHJlZiA9IHVzZUNhbGxiYWNrKChuZXdOb2RlKSA9PiB7XG4gICAgc2V0Tm9kZShuZXdOb2RlKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gbmVlZCByZWYgdG8gY29udGludWVcbiAgICBpZiAoIW5vZGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBtZWFzdXJlID0gKCkgPT4ge1xuICAgICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IG5ld0RpbWVuc2lvbnMgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBzZXREaW1lbnNpb25zKG5ld0RpbWVuc2lvbnMpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBpbnZva2UgbWVhc3VyZSByaWdodCBhd2F5XG4gICAgbWVhc3VyZSgpO1xuXG4gICAgaWYgKGxpdmVNZWFzdXJlKSB7XG4gICAgICBjb25zdCBkZWJvdW5jZU1lYXN1cmUgPSBkZWJvdW5jZShtZWFzdXJlLCBkZWxheSk7XG5cbiAgICAgIGlmICgnUmVzaXplT2JzZXJ2ZXInIGluIHdpbmRvdykge1xuICAgICAgICBjb25zdCByZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcihkZWJvdW5jZU1lYXN1cmUpO1xuICAgICAgICByZXNpemVPYnNlcnZlci5vYnNlcnZlKG5vZGUpO1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgZGVib3VuY2VNZWFzdXJlKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIHJlc2l6ZU9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgZGVib3VuY2VNZWFzdXJlKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBkZWJvdW5jZU1lYXN1cmUpO1xuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGRlYm91bmNlTWVhc3VyZSk7XG5cbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCBkZWJvdW5jZU1lYXN1cmUpO1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgZGVib3VuY2VNZWFzdXJlKTtcbiAgICAgIH07XG4gICAgfVxuICB9LCBbbm9kZSwgbGl2ZU1lYXN1cmUsIGRlbGF5XSk7XG5cbiAgcmV0dXJuIFtyZWYsIGRpbWVuc2lvbnMsIG5vZGVdO1xufVxuXG5leHBvcnQgZGVmYXVsdCB1c2VEaW1lbnNpb25zO1xuXG4vLyBVc2FnZVxuXG4vLyBmdW5jdGlvbiBBcHAoKSB7XG4vLyAgIGNvbnN0IFt3cmFwcGVyUmVmLCBkaW1lbnNpb25zXSA9IHVzZURpbWVuc2lvbnMoKTtcblxuLy8gICByZXR1cm4gKFxuLy8gICAgIDxkaXYgcmVmPXt3cmFwcGVyUmVmfT5cbi8vICAgICAgIGhlaWdodDoge2RpbWVuc2lvbnMuaGVpZ2h0fVxuLy8gICAgICAgd2lkdGg6IHtkaW1lbnNpb25zLndpZHRofVxuLy8gICAgIDwvZGl2PlxuLy8gICApO1xuLy8gfVxuIl0sInNvdXJjZVJvb3QiOiIifQ==