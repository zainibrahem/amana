exports.ids = [29];
exports.modules = {

/***/ "17+d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FacialCare; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FacialCare = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "18.814",
    height: "24",
    viewBox: "0 0 18.814 24"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("g", {
      id: "Makup",
      transform: "translate(-507.818 -485.385)",
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
        id: "Path_17426",
        "data-name": "Path 17426",
        d: "M514.58,502.867a.721.721,0,0,0-.448-.579.411.411,0,0,0-.125-.041v-4.5a.591.591,0,0,0-.29-.5V494.9a6.977,6.977,0,0,0-.675-2.868l0-.009,0-.005a3.2,3.2,0,0,0-.272-.449,1.188,1.188,0,0,0-1.347-.362,2.261,2.261,0,0,0-1.492,1.22l-.022.045a6.315,6.315,0,0,0-.338.874c0,.007-.006.012-.008.019s0,.01,0,.015a7.074,7.074,0,0,0-.292,2.044v1.707c-.336.144-.509.35-.509.613v4.486c-.354.155-.545.364-.57.622,0,.006,0,.011,0,.017a71.956,71.956,0,0,0-.289,10.391c0,.787,1.5,1.38,3.49,1.38s3.49-.593,3.489-1.355a72.1,72.1,0,0,0-.288-10.417ZM512.8,494a5.335,5.335,0,0,1,.085.9v2.779a6.961,6.961,0,0,1-1.5.142,7.622,7.622,0,0,1-1.284-.1v-2.3a6.715,6.715,0,0,1,.043-.751,1.974,1.974,0,0,0,.891.2A2.569,2.569,0,0,0,512.8,494Zm-3.209,4.464a8.613,8.613,0,0,0,3.585,0v4.508a10.2,10.2,0,0,1-3.585,0Zm1.087-5.676a1.447,1.447,0,0,1,.938-.773c.172-.042.394-.067.479.048a2.406,2.406,0,0,1,.206.344v0a.832.832,0,0,1-.006.876,1.743,1.743,0,0,1-1.264.749.87.87,0,0,1-.655-.213c-.017-.023-.055-.077-.019-.21a5.462,5.462,0,0,1,.3-.781Zm3.364,20.4a6.081,6.081,0,0,1-5.316,0,71.567,71.567,0,0,1,.219-9.528,10,10,0,0,0,4.877,0A71.829,71.829,0,0,1,514.038,513.194Z",
        transform: "translate(0 -5.256)",
        fill: "currentColor"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
        id: "Path_17427",
        "data-name": "Path 17427",
        d: "M618.005,487.378c-.617-1.323-2.2-1.993-4.7-1.993s-4.08.671-4.7,1.994c-1.3,2.781,2.328,7.41,2.923,8.139l-.194,12.539c0,.514.524,1.279,1.969,1.279s1.969-.765,1.969-1.286l-.195-12.532C615.675,494.791,619.3,490.161,618.005,487.378Zm-5.671,10.394.026-1.66a3.555,3.555,0,0,0,.65.1.415.415,0,0,0,.088.01c.013,0,.024,0,.037,0,.058,0,.116,0,.174,0a3.918,3.918,0,0,0,.949-.107l.026,1.66a2.931,2.931,0,0,1-1.949,0Zm-2.966-10.041c.468-1,1.794-1.511,3.94-1.511s3.472.508,3.94,1.511c.836,1.792-1.112,5.009-2.374,6.7a6.637,6.637,0,0,0,.23-1.731.417.417,0,0,0-.417-.417h0a.418.418,0,0,0-.417.417c0,.657-.2,2.461-1.017,2.665a2.056,2.056,0,0,1-.49-1.175.417.417,0,0,0-.826.123,4.453,4.453,0,0,0,.112.518C610.835,493.3,608.46,489.678,609.368,487.731Zm3.94,20.771c-.9,0-1.126-.359-1.134-.438l.146-9.408a4.2,4.2,0,0,0,1.976,0l.146,9.4C614.435,508.143,614.208,508.5,613.308,508.5Z",
        transform: "translate(-91.651)",
        fill: "currentColor"
      })]
    })
  }));
};

/***/ }),

/***/ "2MIm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("Y3ZS");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("7xIC");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) {}

  return WithRouterWrapper;
}

/***/ }),

/***/ "3G4Q":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__("fvxO");

var _querystring = __webpack_require__("FrRs");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL(true ? 'http://n' : undefined);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error(`invariant: invalid relative URL, router received ${url}`);
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "5l48":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return HOME_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return GROCERY_PAGE; });
/* unused harmony export GROCERY_PAGE_TWO */
/* unused harmony export BAKERY_PAGE */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return MAKEUP_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return CLOTHING_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return BAGS_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return BOOK_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return FURNITURE_PAGE; });
/* unused harmony export FURNITURE_PAGE_TWO */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return MEDICINE_PAGE; });
/* unused harmony export REQUEST_MEDICINE_PAGE */
/* unused harmony export CHECKOUT_PAGE */
/* unused harmony export CHECKOUT_PAGE_TWO */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return PROFILE_PAGE; });
/* unused harmony export YOUR_ORDER_PAGE */
/* unused harmony export ORDER_RECEIVED_PAGE */
/* unused harmony export OFFER_PAGE */
/* unused harmony export HELP_PAGE */
/* unused harmony export TERMS_AND_SERVICES_PAGE */
/* unused harmony export PRIVACY_POLICY_PAGE */
/* unused harmony export HOME_MENU_ITEM */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return HELP_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return OFFER_MENU_ITEM; });
/* unused harmony export ORDER_MENU_ITEM */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "r", function() { return REQUEST_MEDICINE_MENU_ITEM; });
/* unused harmony export PROFILE_MENU_ITEM */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AUTHORIZED_MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return CATEGORY_MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return MOBILE_DRAWER_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "q", function() { return PROFILE_SIDEBAR_TOP_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return PROFILE_SIDEBAR_BOTTOM_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return LANGUAGE_MENU; });
const HOME_PAGE = '/';
const GROCERY_PAGE = '/grocery';
const GROCERY_PAGE_TWO = '/grocery-two';
const BAKERY_PAGE = '/bakery';
const MAKEUP_PAGE = '/makeup';
const CLOTHING_PAGE = '/clothing';
const BAGS_PAGE = '/bags';
const BOOK_PAGE = '/book';
const FURNITURE_PAGE = '/furniture';
const FURNITURE_PAGE_TWO = '/furniture-two';
const MEDICINE_PAGE = '/medicine'; // export const RESTAURANT_PAGE = '/restaurant';

const REQUEST_MEDICINE_PAGE = '/request-medicine';
const CHECKOUT_PAGE = '/checkout';
const CHECKOUT_PAGE_TWO = '/checkout-alternative';
const PROFILE_PAGE = '/profile';
const YOUR_ORDER_PAGE = '/order';
const ORDER_RECEIVED_PAGE = '/order-received';
const OFFER_PAGE = '/offer';
const HELP_PAGE = '/help';
const TERMS_AND_SERVICES_PAGE = '/terms';
const PRIVACY_POLICY_PAGE = '/privacy'; // Mobile Drawer Menus

const HOME_MENU_ITEM = {
  id: 'nav.home',
  defaultMessage: 'Home',
  href: HOME_PAGE
};
const HELP_MENU_ITEM = {
  id: 'nav.help',
  defaultMessage: 'Help',
  href: HELP_PAGE
};
const OFFER_MENU_ITEM = {
  id: 'nav.offer',
  defaultMessage: 'Offer',
  href: OFFER_PAGE
};
const ORDER_MENU_ITEM = {
  id: 'nav.order',
  href: YOUR_ORDER_PAGE,
  defaultMessage: 'Order'
};
const REQUEST_MEDICINE_MENU_ITEM = {
  id: 'nav.request_medicine',
  defaultMessage: 'Request Medicine',
  href: REQUEST_MEDICINE_PAGE
};
const PROFILE_MENU_ITEM = {
  id: 'nav.profile',
  defaultMessage: 'Profile',
  href: PROFILE_PAGE
};
const AUTHORIZED_MENU_ITEMS = [PROFILE_MENU_ITEM, {
  id: 'nav.checkout',
  defaultMessage: 'Checkout',
  href: CHECKOUT_PAGE
}, {
  id: 'alternativeCheckout',
  href: CHECKOUT_PAGE_TWO,
  defaultMessage: 'Checkout Alternative'
}, ORDER_MENU_ITEM, {
  id: 'nav.order_received',
  href: ORDER_RECEIVED_PAGE,
  defaultMessage: 'Order invoice'
}, {
  id: 'nav.terms_and_services',
  defaultMessage: 'Terms and Services',
  href: TERMS_AND_SERVICES_PAGE
}, {
  id: 'nav.privacy_policy',
  defaultMessage: 'Privacy Policy',
  href: PRIVACY_POLICY_PAGE
}]; // category menu items for header navigation

const CATEGORY_MENU_ITEMS = [{
  id: 'nav.grocery',
  href: GROCERY_PAGE,
  defaultMessage: 'Grocery',
  icon: 'FruitsVegetable',
  dynamic: true
}, {
  id: 'nav.grocery-two',
  href: GROCERY_PAGE_TWO,
  defaultMessage: 'Grocery Two',
  icon: 'FruitsVegetable',
  dynamic: false
}, {
  id: 'nav.bakery',
  href: BAKERY_PAGE,
  defaultMessage: 'Bakery',
  icon: 'Bakery',
  dynamic: false
}, {
  id: 'nav.makeup',
  defaultMessage: 'Makeup',
  href: MAKEUP_PAGE,
  icon: 'FacialCare',
  dynamic: true
}, {
  id: 'nav.bags',
  defaultMessage: 'Bags',
  href: BAGS_PAGE,
  icon: 'Handbag',
  dynamic: true
}, {
  id: 'nav.clothing',
  defaultMessage: 'Clothing',
  href: CLOTHING_PAGE,
  icon: 'DressIcon',
  dynamic: true
}, {
  id: 'nav.furniture',
  defaultMessage: 'Furniture',
  href: FURNITURE_PAGE,
  icon: 'FurnitureIcon',
  dynamic: true
}, {
  id: 'nav.furniture-two',
  defaultMessage: 'Furniture Two',
  href: FURNITURE_PAGE_TWO,
  icon: 'FurnitureIcon',
  dynamic: false
}, {
  id: 'nav.book',
  defaultMessage: 'Book',
  href: BOOK_PAGE,
  icon: 'BookIcon',
  dynamic: true
}, {
  id: 'nav.medicine',
  defaultMessage: 'Medicine',
  href: MEDICINE_PAGE,
  icon: 'MedicineIcon',
  dynamic: true
} // {
//   id: 'nav.foods',
//   defaultMessage: 'Foods',
//   href: RESTAURANT_PAGE,
//   icon: 'Restaurant',
// },
];
const MOBILE_DRAWER_MENU = [HOME_MENU_ITEM, ...AUTHORIZED_MENU_ITEMS, HELP_MENU_ITEM, OFFER_MENU_ITEM];
const PROFILE_SIDEBAR_TOP_MENU = [ORDER_MENU_ITEM, HELP_MENU_ITEM];
const PROFILE_SIDEBAR_BOTTOM_MENU = [PROFILE_MENU_ITEM];
const LANGUAGE_MENU = [{
  id: 'ar',
  defaultMessage: 'Arabic',
  icon: 'SAFlag'
}, {
  id: 'zh',
  defaultMessage: 'Chinese',
  icon: 'CNFlag'
}, {
  id: 'en',
  defaultMessage: 'English',
  icon: 'USFlag'
}, {
  id: 'de',
  defaultMessage: 'German',
  icon: 'DEFlag'
}, {
  id: 'he',
  defaultMessage: 'Hebrew',
  icon: 'ILFlag'
}, {
  id: 'es',
  defaultMessage: 'Spanish',
  icon: 'ESFlag'
}];

/***/ }),

/***/ "63jn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./src/components/popover/useOnClickOutside.js

function useOnClickOutside(ref, handler) {
  Object(external_react_["useEffect"])(() => {
    const listener = event => {
      // Do nothing if clicking ref's element or descendent elements
      if (!ref.current || ref.current.contains(event.target)) {
        return;
      }

      handler(event);
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, // Add ref and handler to effect dependencies
  // It's worth noting that because passed in handler is a new ...
  // ... function on every render that will cause this effect ...
  // ... callback/cleanup to run every render. It's not a big deal ...
  // ... but to optimize you can wrap handler in useCallback before ...
  // ... passing it into this hook.
  [ref, handler]);
}
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/theme-get"
var theme_get_ = __webpack_require__("/JeY");

// CONCATENATED MODULE: ./src/components/popover/popover.style.tsx


const PopoverWrapper = external_styled_components_default.a.div.withConfig({
  displayName: "popoverstyle__PopoverWrapper",
  componentId: "sc-19xxsmh-0"
})(["position:relative;cursor:pointer;.popover-handler{display:inline-block;cursor:pointer;}.popover-content{left:0px;top:calc(100% + 15px);display:block;min-width:200px;padding:15px 20px;position:absolute;border-radius:", ";background-color:", ";box-shadow:0 3px 20px rgba(142,142,142,0.14);z-index:99;&:before{content:'';position:absolute;width:0;height:0;border-style:solid;border-width:0 8px 9px 8px;border-color:transparent transparent ", " transparent;top:-8px;left:15px;box-shadow:-4px -4px 8px -3px rgba(142,142,142,0.14);pointer-events:none;}}&.right{.popover-content{left:auto;right:0px;&:before{left:auto;right:15px;}}}"], Object(theme_get_["themeGet"])('radii.base', '6px'), Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('colors.white', '#ffffff'));
/* harmony default export */ var popover_style = (PopoverWrapper);
// CONCATENATED MODULE: ./src/components/popover/popover.tsx






const Popover = ({
  className,
  handler,
  content,
  direction
}) => {
  // Popover State
  const {
    0: state,
    1: setState
  } = Object(external_react_["useState"])(false); // Ref

  const ref = Object(external_react_["useRef"])(); // Add all classs to an array

  const addAllClasses = ['popover-wrapper']; // className prop checking

  if (className) {
    addAllClasses.push(className);
  } // Add direction class on popover content


  if (direction) {
    addAllClasses.push(direction);
  } // Toggle Popover content


  const handleToggle = e => {
    e.stopPropagation();
    setState(state => !state);
  }; // Handle document click


  const handleDocumentClick = e => {
    e.stopPropagation();

    if (state) {
      handleToggle(e);
    }
  }; // Handle window event listener


  Object(external_react_["useEffect"])(() => {
    window.addEventListener('click', handleDocumentClick);
    return () => {
      window.removeEventListener('click', handleDocumentClick);
    };
  }); // Close popover on click outside

  useOnClickOutside(ref, () => setState(state => false));
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(popover_style, {
    className: addAllClasses.join(' '),
    ref: ref,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "popover-handler",
      onClick: handleToggle,
      children: handler
    }), state && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "popover-content",
      children: content && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "inner-wrap",
        onClick: handleToggle,
        children: content
      })
    })]
  });
};

/* harmony default export */ var popover = __webpack_exports__["a"] = (Popover);

/***/ }),

/***/ "7xIC":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("pONU");

var _interopRequireDefault = __webpack_require__("Y3ZS");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("L9lV"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("Osoz");

var _withRouter = _interopRequireDefault(__webpack_require__("2MIm"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "9T+x":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/css"
var css_ = __webpack_require__("ExBD");
var css_default = /*#__PURE__*/__webpack_require__.n(css_);

// CONCATENATED MODULE: ./src/layouts/logo/logo.style.tsx


const LogoBox = external_styled_components_default.a.span.withConfig({
  displayName: "logostyle__LogoBox",
  componentId: "sc-14em7a1-0"
})(css_default()({
  color: 'text.bold',
  fontSize: 26,
  fontWeight: 'bold',
  cursor: 'pointer',
  mr: [0, 20, 40],
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
}));
const LogoImage = external_styled_components_default.a.img.withConfig({
  displayName: "logostyle__LogoImage",
  componentId: "sc-14em7a1-1"
})({
  display: 'block',
  backfaceVisibility: 'hidden',
  maxWidth: 150
});
// CONCATENATED MODULE: ./src/layouts/logo/logo.tsx





const Logo = ({
  imageUrl,
  alt,
  onClick
}) => {
  function onLogoClick() {
    router_default.a.push('/');

    if (onClick) {
      onClick();
    }
  }

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(LogoBox, {
    onClick: onLogoClick,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(LogoImage, {
      src: imageUrl,
      alt: alt
    })
  });
};

/* harmony default export */ var logo = __webpack_exports__["a"] = (Logo);

/***/ }),

/***/ "B68Z":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export StyledButton */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Button; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("Dtiu");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("ExBD");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("4JT2");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_4__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const StyledButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.button.withConfig({
  displayName: "button__StyledButton",
  componentId: "sc-1mky0hn-0"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default()({
  px: '15px',
  py: 0,
  fontSize: ['base'],
  fontWeight: 'bold',
  cursor: props.disabled ? 'not-allowed' : 'pointer',
  color: props.disabled ? 'text.light' : 'white',
  bg: props.disabled ? 'gray.500' : 'primary.regular',
  transition: 'all 0.3s ease',
  borderRadius: 'base',
  '&:hover': {
    color: props.disabled ? 'text.light' : 'white',
    bg: props.disabled ? 'gray.500' : 'primary.hover'
  }
}), {
  appearance: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flexShrink: 0,
  textAlign: 'center',
  height: '38px',
  textDecoration: 'none',
  fontFamily: 'inherit',
  border: 0,
  '&:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["variant"])({
  variants: {
    outlined: {
      color: 'primary.regular',
      bg: 'white',
      border: '1px solid',
      borderColor: 'gray.500',
      '&:hover': {
        borderColor: 'primary.regular',
        color: 'primary.regular',
        bg: 'white'
      }
    },
    primary: {
      color: 'white',
      bg: 'primary.regular',
      '&:hover': {
        bg: 'primary.hover'
      }
    },
    secondary: {
      color: 'primary.regular',
      bg: 'white',
      border: '2px solid',
      borderColor: 'gray.500',
      '&:hover': {
        color: 'white',
        bg: 'primary.regular',
        borderColor: 'primary.regular'
      }
    },
    text: {
      color: 'primary.regular',
      bg: 'transparent',
      '&:hover': {
        bg: 'transparent',
        color: 'primary.hover'
      }
    },
    select: {
      width: 26,
      height: 26,
      lineHeight: 1,
      flexShrink: 0,
      border: '1px solid',
      borderColor: 'text.regular',
      borderRadius: 13,
      padding: 0,
      color: 'text.bold',
      bg: 'transparent',
      '&.selected': {
        bg: 'primary.regular',
        color: 'white',
        borderColor: 'primary.regular'
      },
      '&:hover:not(.selected)': {
        bg: 'transparent',
        color: 'primary.regular',
        borderColor: 'primary.regular'
      }
    }
  }
}), Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["variant"])({
  prop: 'size',
  variants: {
    big: {
      height: '48px',
      px: 30
    },
    small: {
      height: '30px',
      fontSize: 14
    }
  }
}), Object(styled_system__WEBPACK_IMPORTED_MODULE_4__["compose"])(styled_system__WEBPACK_IMPORTED_MODULE_4__["border"], styled_system__WEBPACK_IMPORTED_MODULE_4__["space"], styled_system__WEBPACK_IMPORTED_MODULE_4__["layout"]));
const rotate = Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["keyframes"])(["from{transform:rotate(0deg);}to{transform:rotate(360deg);}"]);
const Spinner = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.div.withConfig({
  displayName: "button__Spinner",
  componentId: "sc-1mky0hn-1"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_3___default()({
  width: 18,
  height: 18,
  marginLeft: 10,
  border: '3px solid white',
  borderTop: `3px solid ${props.color ? props.color : 'primary.regular'}`,
  borderRadius: '50%',
  transitionProperty: 'transform'
}), Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["css"])(["animation:", " 1.2s infinite linear;"], rotate));
const Button = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.forwardRef((_ref, ref) => {
  let {
    children,
    disabled,
    loading = false
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "disabled", "loading"]);

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])(StyledButton, _objectSpread(_objectSpread({
    ref: ref
  }, props), {}, {
    disabled: disabled,
    children: [children, loading && /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Spinner, {})]
  }));
});

/***/ }),

/***/ "BOBJ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__("FrRs"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "Ek28":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("Dtiu");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("jvFD");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("k004");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_5__);







const Icon = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.span.withConfig({
  displayName: "nav-link__Icon",
  componentId: "sc-6likiw-0"
})(["min-width:16px;margin-right:10px;display:flex;align-items:center;justify-content:center;"]);

const NavLink = ({
  href,
  label,
  intlId,
  router,
  icon,
  className,
  onClick,
  iconClass,
  dynamic
}) => {
  const isCurrentPath = router.pathname === href || router.asPath === href;
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
    onClick: onClick,
    className: className ? className : '',
    children: dynamic ? /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: '/[type]',
      as: href,
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("a", {
        className: isCurrentPath ? ' current-page' : '',
        style: {
          display: 'flex',
          alignItems: 'center'
        },
        children: [icon ? /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Icon, {
          className: iconClass,
          children: icon
        }) : '', /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("span", {
          className: "label",
          children: intlId ? /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(react_intl__WEBPACK_IMPORTED_MODULE_5__["FormattedMessage"], {
            id: intlId ? intlId : 'defaultNavLinkId',
            defaultMessage: label
          }) : label
        })]
      })
    }) : /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
      href: href,
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("a", {
        className: isCurrentPath ? ' current-page' : '',
        style: {
          display: 'flex',
          alignItems: 'center'
        },
        children: [icon ? /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Icon, {
          className: iconClass,
          children: icon
        }) : '', /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("span", {
          className: "label",
          children: intlId ? /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(react_intl__WEBPACK_IMPORTED_MODULE_5__["FormattedMessage"], {
            id: intlId ? intlId : 'defaultNavLinkId',
            defaultMessage: label
          }) : label
        })]
      })
    })
  });
};

/* harmony default export */ __webpack_exports__["a"] = (Object(next_router__WEBPACK_IMPORTED_MODULE_4__["withRouter"])(NavLink));

/***/ }),

/***/ "FrRs":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "HOTy":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = __webpack_require__("ZeW2");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "HPEz":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return SearchWrapper; });
/* unused harmony export HeaderLeftSide */
/* unused harmony export HeaderRightSide */
/* unused harmony export MainMenu */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return MobileHeaderWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return MobileHeaderInnerWrapper; });
/* unused harmony export SelectedType */
/* unused harmony export DropDownArrow */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return DrawerWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DrawerBody; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return LogoWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return HamburgerIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return DrawerContentWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DrawerClose; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return DrawerProfile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return LogoutView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return LoginView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "q", function() { return UserAvatar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "r", function() { return UserDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return DrawerMenu; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return DrawerMenuItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "s", function() { return UserOptionMenu; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return SearchModalWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return SearchModalClose; });
/* unused harmony export LanguageItem */
/* unused harmony export LangSwitcher */
/* unused harmony export Flag */
/* unused harmony export TypeIcon */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Dtiu");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("/JeY");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const positionAnim = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["keyframes"])(["from{position:fixed;opacity:1;}to{opacity:0;transition:all 0.3s ease;}"]);
const hideSearch = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["keyframes"])(["from{display:none;}to{display:flex;}"]);
const SearchWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__SearchWrapper",
  componentId: "xdvv0c-0"
})(["padding:5px;cursor:pointer;color:", ";svg{display:block;width:17px;height:auto;}@media only screen and (min-width:991px) and (max-width:1366px){opacity:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const HeaderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.header.withConfig({
  displayName: "headerstyle__HeaderWrapper",
  componentId: "xdvv0c-1"
})(["padding:20px 30px;display:flex;align-items:center;justify-content:space-between;position:fixed;z-index:99999;top:0;left:0;width:100%;background-color:", ";box-shadow:", ";transition:all 0.3s ease;&.home{position:absolute;background-color:transparent;box-shadow:none;}@media (min-width:1600px){padding:25px 40px;}@media (max-width:990px){display:none;}.headerSearch{margin:0 30px;@media only screen and (min-width:991px) and (max-width:1200px){margin:0 15px;input{width:80%;}.buttonText{display:none;}}}&.unSticky{animation:", " 0.3s ease;.headerSearch{animation:", " 0.3s ease;display:none;}}&.sticky{background-color:", ";position:fixed;box-shadow:", ";padding-top:20px;padding-bottom:20px;@media (max-width:1400px){padding-top:20px;padding-bottom:20px;}.headerSearch{display:flex;form{background-color:", ";input{background-color:", ";}}@media only screen and (min-width:991px) and (max-width:1200px){.buttonText{display:none;}}}}.popover-wrapper{.popover-content{padding:20px 0;.menu-item{a{margin:0;padding:12px 30px;border-bottom:1px solid ", ";cursor:pointer;white-space:nowrap;&:last-child{border-bottom:0;}&:hover{color:", ";}&.current-page{color:", ";}.menu-item-icon{margin-right:15px;}}}}}.headerSearch{input{@media (max-width:1400px){padding:0 15px;font-size:", "px;}@media only screen and (min-width:991px) and (max-width:1200px){}}button{@media (max-width:1400px){padding:0 15px;font-size:", "px;}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('shadows.header', '0 1px 2px rgba(0, 0, 0, 0.06)'), positionAnim, hideSearch, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('shadows.header', '0 1px 2px rgba(0, 0, 0, 0.06)'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.400', '#F3F3F3'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.400', '#F3F3F3'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.200', '#F7F7F7'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const HeaderLeftSide = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__HeaderLeftSide",
  componentId: "xdvv0c-2"
})(["display:flex;align-items:center;justify-content:space-between;flex-shrink:0;"]);
const HeaderRightSide = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__HeaderRightSide",
  componentId: "xdvv0c-3"
})(["display:flex;align-items:center;flex-shrink:0;.menu-icon{min-width:14px;margin-right:7px;}.menu-item{a{font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;display:block;transition:0.15s ease-in-out;display:flex;align-items:center;margin-right:45px;@media (max-width:1400px){margin-right:35px;font-size:", "px;}&:hover{color:", ";}&.current-page{color:", ";}}}.user-pages-dropdown{.popover-handler{width:38px;height:38px;border-radius:50%;display:block;overflow:hidden;img{width:100%;height:auto;display:block;}}.popover-content{.inner-wrap{}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const MainMenu = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__MainMenu",
  componentId: "xdvv0c-4"
})(["display:flex;align-items:center;.popover-wrapper{.popover-content{.menu-item{font-family:", ";a{font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;display:block;padding:15px 30px;border-radius:", ";transition:0.15s ease-in-out;display:flex;align-items:center;@media (max-width:1400px){margin-right:10px;font-size:", "px;}@media only screen and (min-width:991px) and (max-width:1200px){padding:15px 30px;}&:hover{color:", ";}&.current-page{color:", ";background-color:", ";}}}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const MobileHeaderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__MobileHeaderWrapper",
  componentId: "xdvv0c-5"
})(["@media (min-width:991px){.desktop{display:none;}}"]);
const MobileHeaderInnerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__MobileHeaderInnerWrapper",
  componentId: "xdvv0c-6"
})(["display:flex;align-items:center;justify-content:space-between;padding:15px;position:fixed;width:100%;top:0;left:0;z-index:999;transition:0.25s ease-in-out;@media only screen and (max-width:990px){padding:15px 20px;}&.home{position:absolute;background-color:transparent;box-shadow:none;}&.unSticky:not(.home){background-color:", ";box-shadow:", ";}&.sticky{position:fixed;background-color:", ";box-shadow:", ";@media only screen and (min-width:991px) and (max-width:1366px){.searchIconWrapper{opacity:1;}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('shadows.header', '0 1px 2px rgba(0, 0, 0, 0.06)'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('shadows.header', '0 1px 2px rgba(0, 0, 0, 0.06)'));
const SelectedType = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "headerstyle__SelectedType",
  componentId: "xdvv0c-7"
})(["width:auto;height:38px;display:flex;align-items:center;background-color:", ";border:1px solid ", ";padding-top:0;padding-bottom:0;padding-left:15px;padding-right:15px;border-radius:", ";outline:0;min-width:150px;cursor:pointer;span{display:flex;align-items:center;font-family:", ";font-size:", "px;font-weight:", ";color:", ";text-decoration:none;&:first-child{margin-right:auto;}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.500', '#f1f1f1'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const DropDownArrow = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "headerstyle__DropDownArrow",
  componentId: "xdvv0c-8"
})(["width:12px;margin-left:16px;"]);
const DrawerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerWrapper",
  componentId: "xdvv0c-9"
})(["display:flex;"]);
const DrawerBody = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerBody",
  componentId: "xdvv0c-10"
})([".drawer-scrollbar{height:100%;}"]);
const LogoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__LogoWrapper",
  componentId: "xdvv0c-11"
})(["margin-left:auto;margin-right:auto;@media (max-width:990px){margin-left:30px;}img{display:block;}"]);
const HamburgerIcon = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__HamburgerIcon",
  componentId: "xdvv0c-12"
})(["width:26px;cursor:pointer;display:block;position:relative;> span{display:block;background-color:", ";border-radius:", ";height:3px;margin-bottom:5px;transition:0.2s ease-in-out;&:nth-child(1){width:26px;}&:nth-child(2){width:12px;}&:nth-child(3){width:22px;}&:last-child{margin-bottom:0;}}&:hover{> span{&:nth-child(1){width:12px;}&:nth-child(2){width:22px;}&:nth-child(3){width:26px;}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const DrawerContentWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerContentWrapper",
  componentId: "xdvv0c-13"
})(["padding-top:60px;"]);
const DrawerClose = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerClose",
  componentId: "xdvv0c-14"
})(["display:block;position:absolute;left:35px;top:14px;color:", ";cursor:pointer;padding:10px;z-index:1;svg{display:block;width:12px;height:auto;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const DrawerProfile = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerProfile",
  componentId: "xdvv0c-15"
})(["background-color:", ";padding:45px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.200', '#F7F7F7'));
const LogoutView = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__LogoutView",
  componentId: "xdvv0c-16"
})(["display:flex;align-items:center;justify-content:center;.sign_in{border:0;padding-left:0;padding-right:25px;}.sign_in,.sign_up{height:36px;padding-left:15px;padding-right:15px;}"]);
const LoginView = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__LoginView",
  componentId: "xdvv0c-17"
})(["display:flex;align-items:center;"]);
const UserAvatar = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__UserAvatar",
  componentId: "xdvv0c-18"
})(["width:50px;height:50px;flex-shrink:0;display:block;border-radius:50%;overflow:hidden;margin-right:15px;img{width:100%;height:auto;display:block;}"]);
const UserDetails = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__UserDetails",
  componentId: "xdvv0c-19"
})(["h3{font-size:calc(", " - 1px);font-weight:", ";color:", ";margin-bottom:10px;line-height:1.2;}span{display:block;font-size:", "px;font-weight:", ";color:", ";}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base' + 'px', '15px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const DrawerMenu = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerMenu",
  componentId: "xdvv0c-20"
})(["padding:40px 0;"]);
const DrawerMenuItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__DrawerMenuItem",
  componentId: "xdvv0c-21"
})(["&:last-child{.drawer_menu_item{margin-bottom:0;}}.drawer_menu_item{a,.logoutBtn{display:block;padding:5px 45px;font-size:calc(", " - 1px);font-weight:", ";color:", ";margin-bottom:19px;position:relative;transition:0.15s ease-in-out;&:hover{color:", ";}&:before{content:'';display:block;position:absolute;top:0;left:0;width:5px;height:100%;background:transparent;}&.current-page{color:", ";font-weight:", ";&:before{background-color:", ";}}}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const UserOptionMenu = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__UserOptionMenu",
  componentId: "xdvv0c-22"
})(["padding:45px 0;border-top:1px solid ", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.700', '#e6e6e6'));
const SearchModalWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__SearchModalWrapper",
  componentId: "xdvv0c-23"
})(["padding-top:15px;padding-bottom:15px;background-color:", ";display:flex;width:100%;.header-modal-search{width:calc(100% - 60px);@media (max-width:420px){input{width:150px;}}button{background:transparent;color:", ";padding-left:15px;padding-right:15px;}input{color:", ";padding-left:5px;padding-right:5px;}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const SearchModalClose = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "headerstyle__SearchModalClose",
  componentId: "xdvv0c-24"
})(["border:0;background:transparent;display:block;padding:0 15px;color:", ";display:flex;align-items:center;justify-content:center;cursor:pointer;svg{display:block;width:20px;height:auto;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const LanguageItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "headerstyle__LanguageItem",
  componentId: "xdvv0c-25"
})(["width:100%;font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;display:block;padding:15px 30px;border-radius:", ";transition:0.15s ease-in-out;display:flex;align-items:center;border:0;border-bottom:1px solid ", ";border-radius:0;background-color:transparent;outline:0;cursor:pointer;&:last-child{border-bottom:0;}@media (max-width:1400px){margin-right:10px;font-size:", "px;}@media only screen and (min-width:991px) and (max-width:1200px){padding:15px 30px;}span{box-shadow:0 0 3px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;border-radius:2px;overflow:hidden;margin-right:15px;svg{display:block;width:20px;height:auto;}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.500', '#f1f1f1'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const LangSwitcher = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__LangSwitcher",
  componentId: "xdvv0c-26"
})(["margin-right:20px;@media (max-width:767px){margin-right:10px;}.popover-wrapper.right{.popover-content{padding:15px 0;}}"]);
const Flag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__Flag",
  componentId: "xdvv0c-27"
})(["margin-right:7px;box-shadow:0 0 3px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;border-radius:2px;overflow:hidden;svg{width:20px;height:auto;}"]);
const TypeIcon = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "headerstyle__TypeIcon",
  componentId: "xdvv0c-28"
})(["margin-right:7px;display:flex;align-items:center;justify-content:center;min-width:16px;"]);
/* harmony default export */ __webpack_exports__["t"] = (HeaderWrapper);

/***/ }),

/***/ "J7Kp":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchIcon; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const SearchIcon = (_ref) => {
  let {
    color = 'currentColor',
    width = '17px',
    height = '18px'
  } = _ref,
      props = _objectWithoutProperties(_ref, ["color", "width", "height"]);

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 17.048 18"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
      id: "Path_142",
      "data-name": "Path 142",
      d: "M380.321,383.992l3.225,3.218c.167.167.341.329.5.506a.894.894,0,1,1-1.286,1.238c-1.087-1.067-2.179-2.131-3.227-3.236a.924.924,0,0,0-1.325-.222,7.509,7.509,0,1,1-3.3-14.207,7.532,7.532,0,0,1,6,11.936C380.736,383.462,380.552,383.685,380.321,383.992Zm-5.537.521a5.707,5.707,0,1,0-5.675-5.72A5.675,5.675,0,0,0,374.784,384.513Z",
      transform: "translate(-367.297 -371.285)",
      fill: color
    })
  }));
};

/***/ }),

/***/ "Jsn8":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.normalizeLocalePath = normalizeLocalePath;

function normalizeLocalePath(pathname, locales) {
  let detectedLocale; // first item will be empty string from splitting at first char

  const pathnameParts = pathname.split('/');
  (locales || []).some(locale => {
    if (pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join('/') || '/';
      return true;
    }

    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}

/***/ }),

/***/ "KRoA":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "FruitsVegetable", function() { return /* reexport */ FruitsVegetable["a" /* FruitsVegetable */]; });
__webpack_require__.d(__webpack_exports__, "FacialCare", function() { return /* reexport */ FacialCare["a" /* FacialCare */]; });
__webpack_require__.d(__webpack_exports__, "Handbag", function() { return /* reexport */ Handbag; });
__webpack_require__.d(__webpack_exports__, "DressIcon", function() { return /* reexport */ DressIcon; });
__webpack_require__.d(__webpack_exports__, "FurnitureIcon", function() { return /* reexport */ FurnitureIcon; });
__webpack_require__.d(__webpack_exports__, "BookIcon", function() { return /* reexport */ BookIcon; });
__webpack_require__.d(__webpack_exports__, "MedicineIcon", function() { return /* reexport */ MedicineIcon; });
__webpack_require__.d(__webpack_exports__, "Restaurant", function() { return /* reexport */ Restaurant; });
__webpack_require__.d(__webpack_exports__, "Bakery", function() { return /* reexport */ Bakery; });

// EXTERNAL MODULE: ./src/assets/icons/FruitsVegetable.tsx
var FruitsVegetable = __webpack_require__("pQO/");

// EXTERNAL MODULE: ./src/assets/icons/FacialCare.tsx
var FacialCare = __webpack_require__("17+d");

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./src/assets/icons/Handbag.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Handbag = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "23.878",
    height: "24.3",
    viewBox: "0 0 23.878 24.3"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      id: "Bags",
      d: "M334.087,36.795h6.808a2.594,2.594,0,0,1,1.833.763h0a2.592,2.592,0,0,1,.763,1.833v2.718h3.328a2.384,2.384,0,0,1,1.686.7h0a2.383,2.383,0,0,1,.7,1.686v3.227a5.569,5.569,0,0,1-.606,2.532v6.066a4.48,4.48,0,0,1-4.469,4.469H330.795a4.567,4.567,0,0,1-4.556-4.556V50.26a5.569,5.569,0,0,1-.606-2.532V44.5a2.384,2.384,0,0,1,.7-1.687h0a2.382,2.382,0,0,1,1.688-.7h3.328v-2.58a2.742,2.742,0,0,1,2.736-2.736Zm13.29,15.077a5.6,5.6,0,0,1-3.443,1.462l-.048,0h-.009l-.061,0h-.01l-.066,0h-3.826v.718a1.838,1.838,0,0,1-.541,1.3v0a1.841,1.841,0,0,1-1.3.541h-1.245a1.891,1.891,0,0,1-1.339-.556v0a1.887,1.887,0,0,1-.556-1.337v-.668H331.1l-.066,0h-.01l-.06,0h-.009l-.048,0a5.6,5.6,0,0,1-3.443-1.462v4.367a3.339,3.339,0,0,0,3.328,3.328h13.341a3.252,3.252,0,0,0,3.241-3.241V51.872Zm-3.883-8.533H328.022a1.159,1.159,0,0,0-.82.342h0a1.158,1.158,0,0,0-.339.82v3.227a4.405,4.405,0,0,0,4.161,4.383h0l.11,0h12.574l.11,0h0a4.4,4.4,0,0,0,4.161-4.383V44.5a1.157,1.157,0,0,0-.339-.82l0,0a1.157,1.157,0,0,0-.82-.339Zm-4.807,10.006h-2.53v.668a.669.669,0,0,0,.2.472h0a.667.667,0,0,0,.471.2h1.245a.615.615,0,0,0,.436-.182h0a.62.62,0,0,0,.18-.437v-.718Zm2.208-15.322h-6.808a1.515,1.515,0,0,0-1.509,1.509v2.58h9.688V39.394a1.365,1.365,0,0,0-.4-.968l0,0A1.365,1.365,0,0,0,340.895,38.023Z",
      transform: "translate(-325.483 -36.645)",
      fill: "currentColor",
      stroke: "#fff",
      strokeWidth: "0.3",
      fillRule: "evenodd"
    })
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/DressIcon.tsx


function DressIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function DressIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { DressIcon_ownKeys(Object(source), true).forEach(function (key) { DressIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { DressIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function DressIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const DressIcon = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", DressIcon_objectSpread(DressIcon_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "14.735",
    height: "24.503",
    viewBox: "0 0 14.735 24.503"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
      id: "Cloth",
      transform: "translate(-255.389 -266.539)",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "Path_17425",
        "data-name": "Path 17425",
        d: "M266.6,273.033c.216-.528.472-1.457.483-1.5a.2.2,0,0,0-.012-.138c-.658-1.409.329-3.9.339-3.925a.2.2,0,0,0-.05-.222,9.5,9.5,0,0,0-1.271-.928.2.2,0,0,0-.3.127c-.339,1.475-1.972,2.824-2.776,3.413a7.168,7.168,0,0,0-.887-.508c-.1-.05-.194-.1-.23-.121a4.167,4.167,0,0,1-1.7-2.76.2.2,0,0,0-.282-.162,5.566,5.566,0,0,0-1.558.942.2.2,0,0,0,0,.227,4.777,4.777,0,0,1,.241,4.008.2.2,0,0,0,0,.125,12.874,12.874,0,0,0,.481,1.277c-.221,1.106-2.826,14.1-3.427,15.87a.2.2,0,0,0,.036.193c.047.056.506.551,2.217.664h.03a3.387,3.387,0,0,1,1.081.17,11.474,11.474,0,0,0,1.552.33,28.226,28.226,0,0,0,3.063.177,16.064,16.064,0,0,0,3.3-.3.2.2,0,0,0,.032-.013s.01,0,.015,0a23.834,23.834,0,0,1,2.73-.686.2.2,0,0,0,.158-.227A134.93,134.93,0,0,0,266.6,273.033Zm-.494-6.225a8.838,8.838,0,0,1,.881.647c-.2.551-.9,2.655-.311,4.042-.061.216-.256.893-.424,1.323h-.518c.21-.487-.209-.482-.441,0h-.086a9.474,9.474,0,0,0-1.866-2.7A7.861,7.861,0,0,0,266.108,266.808ZM259,271.547a5.249,5.249,0,0,0-.227-4.156,6.6,6.6,0,0,1,1.067-.6,4.476,4.476,0,0,0,1.835,2.781,3,3,0,0,0,.273.146,6,6,0,0,1,.958.565l0,0c.045.035.089.071.132.108a8.645,8.645,0,0,1,1.716,2.431h-3.622c-.208-.313-.684-.434-.464,0h-1.187a.231.231,0,0,0-.035-.089A10.391,10.391,0,0,1,259,271.547Zm8.085,17.96a45.2,45.2,0,0,0-1.04-9.177.2.2,0,0,0-.385.114c.834,2.83,1,8.178,1.026,9.188a21.687,21.687,0,0,1-6.073.085,10.977,10.977,0,0,1-1.485-.316,3.862,3.862,0,0,0-1.209-.185,3.8,3.8,0,0,1-1.843-.459c.65-2.122,2.92-13.4,3.347-15.533h6.816a135.764,135.764,0,0,1,3.2,15.711C268.948,289.038,267.708,289.307,267.086,289.507Z",
        transform: "translate(0 0.5)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.5"
      })
    })
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/FurnitureIcon.tsx



function FurnitureIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function FurnitureIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { FurnitureIcon_ownKeys(Object(source), true).forEach(function (key) { FurnitureIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { FurnitureIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function FurnitureIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FurnitureIcon = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", FurnitureIcon_objectSpread(FurnitureIcon_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "18.1",
    height: "24.1",
    viewBox: "0 0 18.1 24.1"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      id: "Furniture",
      transform: "translate(-47.95 -583.95)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "Path_17415",
        "data-name": "Path 17415",
        d: "M66.684,585.288A1.5,1.5,0,0,0,65.2,584H58.8a1.5,1.5,0,0,0-1.485,1.288L56,596H68Zm-8.625.1a.753.753,0,0,1,.741-.638h6.4a.753.753,0,0,1,.741.638l1.212,9.862h-10.3Z",
        transform: "translate(-5)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "Path_17416",
        "data-name": "Path 17416",
        d: "M65.25,608H64.5a.75.75,0,0,0-.75.75v.75a.75.75,0,0,0,.75.75v3h-.75a1.5,1.5,0,0,0-1.5-1.5H51.75a1.5,1.5,0,0,0-1.5,1.5H49.5v-3a.75.75,0,0,0,.75-.75v-.75a.75.75,0,0,0-.75-.75h-.75a.75.75,0,0,0-.75.75v.75a.75.75,0,0,0,.75.75v3a.75.75,0,0,0,.75.75h.952a1.5,1.5,0,0,0,1.3.75H55.5v1.5a.75.75,0,0,0,.75.75h.375v.75h-2.25a1.877,1.877,0,0,0-1.875,1.875v1.19a1.125,1.125,0,1,0,.75,0v-1.19a1.126,1.126,0,0,1,1.125-1.125h2.25v2.315a1.125,1.125,0,1,0,.75,0V618.5h2.25a1.126,1.126,0,0,1,1.125,1.125v1.19a1.125,1.125,0,1,0,.75,0v-1.19a1.877,1.877,0,0,0-1.875-1.875h-2.25V617h.375a.75.75,0,0,0,.75-.75v-1.5h3.75a1.5,1.5,0,0,0,1.3-.75H64.5a.75.75,0,0,0,.75-.75v-3a.75.75,0,0,0,.75-.75v-.75A.75.75,0,0,0,65.25,608Zm-16.5,1.5v-.75h.75v.75Zm4.125,12.75a.375.375,0,1,1,.375-.375A.376.376,0,0,1,52.875,622.25Zm8.25-.75a.375.375,0,1,1-.375.375A.376.376,0,0,1,61.125,621.5ZM57,622.25a.375.375,0,1,1,.375-.375A.376.376,0,0,1,57,622.25Zm.75-6h-1.5v-1.5h1.5Zm4.5-2.25H51.75a.75.75,0,0,1,0-1.5h10.5a.75.75,0,0,1,0,1.5Zm3-4.5H64.5v-.75h.75Z",
        transform: "translate(0 -15)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      })]
    })
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/BookIcon.tsx



function BookIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function BookIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { BookIcon_ownKeys(Object(source), true).forEach(function (key) { BookIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { BookIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function BookIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const BookIcon = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", BookIcon_objectSpread(BookIcon_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "24.6",
    height: "19.335",
    viewBox: "0 0 24.6 19.335"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      id: "Books",
      transform: "translate(-24.7 -30.187)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
        id: "Group_12308",
        "data-name": "Group 12308",
        transform: "translate(25 32.504)",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
          id: "Group_12306",
          "data-name": "Group 12306",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
            id: "Path_17416",
            "data-name": "Path 17416",
            d: "M32.612,50.142h0a34.57,34.57,0,0,0-7.238.8h0l0,0V35a0,0,0,0,1,0,0h.583a0,0,0,0,0,0,0v-.357a0,0,0,0,0,0,0h-.771a.183.183,0,0,0-.183.183V51.164a.182.182,0,0,0,.183.183.181.181,0,0,0,.036,0,28.735,28.735,0,0,1,9.287-.669.006.006,0,0,0,.006,0,.005.005,0,0,0,0-.006Z",
            transform: "translate(-25 -34.629)",
            fill: "currentColor",
            stroke: "currentColor",
            strokeWidth: "0.6"
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
          id: "Group_12307",
          "data-name": "Group 12307",
          transform: "translate(14.922 0)",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
            id: "Path_17417",
            "data-name": "Path 17417",
            d: "M64.983,34.629h-.776V35H64.8V50.957c-.5-.063-1.009-.13-1.515-.2a47.178,47.178,0,0,0-6.073-.546l-.013,0-1.075.311a.048.048,0,0,0,.017.094,37.04,37.04,0,0,1,7.1.5c.576.076,1.152.152,1.724.223a.183.183,0,0,0,.205-.181V34.812A.183.183,0,0,0,64.983,34.629Z",
            transform: "translate(-56.088 -34.629)",
            fill: "currentColor",
            stroke: "currentColor",
            strokeWidth: "0.6"
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        id: "Group_12309",
        "data-name": "Group 12309",
        transform: "translate(26.919 30.542)",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          id: "Path_17418",
          "data-name": "Path 17418",
          d: "M49.16,30.842a.183.183,0,0,0-.166-.182c-.314-.029-7.587-.67-9.915,1.365-2.327-2.035-9.6-1.393-9.915-1.365a.183.183,0,0,0-.166.182v15.7a.183.183,0,0,0,.195.183c.073,0,7.272-.441,9.754,2.133a.187.187,0,0,0,.062.042h0a.186.186,0,0,0,.069.013.182.182,0,0,0,.069-.013h0a.187.187,0,0,0,.062-.042c2.481-2.573,9.682-2.138,9.754-2.133a.187.187,0,0,0,.137-.049.183.183,0,0,0,.058-.134Zm-19.8,15.51V31.011c1.122-.085,7.578-.49,9.531,1.336V48.314c-2.072-1.743-6.2-1.988-8.356-1.988C30.006,46.326,29.594,46.341,29.364,46.352Zm19.429,0c-1.16-.056-6.948-.212-9.531,1.962V32.347c1.954-1.827,8.409-1.421,9.531-1.336Z",
          transform: "translate(-28.998 -30.542)",
          fill: "currentColor",
          stroke: "currentColor",
          strokeWidth: "0.6"
        })
      })]
    })
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/MedicineIcon.tsx



function MedicineIcon_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function MedicineIcon_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { MedicineIcon_ownKeys(Object(source), true).forEach(function (key) { MedicineIcon_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { MedicineIcon_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function MedicineIcon_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const MedicineIcon = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", MedicineIcon_objectSpread(MedicineIcon_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "24.2",
    height: "24.2",
    viewBox: "0 0 24.2 24.2"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      id: "Medicine",
      transform: "translate(-332.9 -1656.038)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        id: "Group_12311",
        "data-name": "Group 12311",
        transform: "translate(333 1656.138)",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          id: "Path_17420",
          "data-name": "Path 17420",
          d: "M350.833,1680.138a6.126,6.126,0,0,1-4.361-1.806l-11.666-11.666a6.167,6.167,0,0,1,8.722-8.722l11.666,11.666a6.167,6.167,0,0,1-4.361,10.528Zm-11.666-23.214a5.381,5.381,0,0,0-3.805,9.186l11.666,11.666a5.381,5.381,0,0,0,7.61,0h0a5.381,5.381,0,0,0,0-7.61L342.972,1658.5A5.346,5.346,0,0,0,339.167,1656.924Z",
          transform: "translate(-333 -1656.138)",
          fill: "currentColor",
          stroke: "currentColor",
          strokeWidth: "0.2"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
        id: "Group_12312",
        "data-name": "Group 12312",
        transform: "translate(340.524 1663.662)",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("line", {
          id: "Line_3",
          "data-name": "Line 3",
          y1: "8.166",
          x2: "8.166",
          transform: "translate(0.393 0.393)",
          fill: "#fff",
          stroke: "currentColor",
          strokeWidth: "0.2"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          id: "Path_17421",
          "data-name": "Path 17421",
          d: "M536.93,1868.628a.393.393,0,0,1-.278-.671l8.166-8.166a.393.393,0,0,1,.556.556l-8.166,8.166A.392.392,0,0,1,536.93,1868.628Z",
          transform: "translate(-536.537 -1859.676)",
          fill: "currentColor",
          stroke: "currentColor",
          strokeWidth: "0.2"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("g", {
        id: "Group_12313",
        "data-name": "Group 12313",
        transform: "translate(334.856 1659.668)",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          id: "Path_17423",
          "data-name": "Path 17423",
          d: "M386.6,1759.337a.392.392,0,0,1-.278-.115,10.88,10.88,0,0,1-2.936-4.287,3.121,3.121,0,0,1,.659-3.167.393.393,0,1,1,.579.532,2.353,2.353,0,0,0-.482,2.417,10.161,10.161,0,0,0,2.737,3.949.393.393,0,0,1-.278.671Z",
          transform: "translate(-383.216 -1751.641)",
          fill: "currentColor",
          stroke: "currentColor",
          strokeWidth: "0.2"
        })
      })]
    })
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/Restaurant.tsx



const Restaurant = ({
  color = 'currentColor',
  width = '9px',
  height = '14px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 9.919 14",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      id: "Food",
      transform: "translate(-760.678 -69.1)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "Path_2721",
        "data-name": "Path 2721",
        d: "M773.859,140.736a5.543,5.543,0,0,1-4.261-2.051l.749,7.838a.482.482,0,0,0,.48.48h6.2a.482.482,0,0,0,.48-.48l.619-7.84A5.544,5.544,0,0,1,773.859,140.736Z",
        transform: "translate(-8.192 -63.904)",
        fill: color
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "Path_2722",
        "data-name": "Path 2722",
        d: "M765.543,76.5c-.08,0-.159-.005-.238-.011l-.1-.007v-4.5c0-.126-.063-.2-.09-.2h-.9c-.026,0-.091.071-.091.2v4.29L764,76.223c-.08-.027-.159-.057-.238-.088l-.066-.026V71.979a.629.629,0,0,1,.481-.666l-.062-.724c-.011-.127-.078-.192-.1-.192l-.895.09c-.012,0-.03.016-.047.048a.314.314,0,0,0-.027.163l.455,5.326-.163-.081c-.086-.044-.17-.088-.25-.134l-.048-.027-.149-1.75-.727-2.476c-.031-.106-.1-.163-.133-.163l-.862.294c-.03.01-.066.106-.031.225l.882,3.013-.081.043-.17-.2c-.08-.086-.151-.166-.216-.244l-.174-.217-.659-2.252a.786.786,0,0,1,.011-.49.508.508,0,0,1,.305-.319l.854-.293a.417.417,0,0,1,.134-.022.637.637,0,0,1,.559.489l.12.412L762.6,70.74a.777.777,0,0,1,.107-.476.488.488,0,0,1,.362-.242l.893-.089.042,0a.619.619,0,0,1,.542.616l.065.764h.149V69.769a.612.612,0,0,1,.529-.669h.9a.612.612,0,0,1,.529.669v1.822l.084-.885a.621.621,0,0,1,.543-.61l.048,0,.891.1a.489.489,0,0,1,.36.246.779.779,0,0,1,.1.477l-.075.783.029-.1a.637.637,0,0,1,.559-.489.416.416,0,0,1,.134.022l.855.293a.508.508,0,0,1,.3.319.786.786,0,0,1,.011.49l-.617,2.09-.156.187c-.067.08-.14.163-.224.253l-.162.163-.079-.046.819-2.786a.315.315,0,0,0,.005-.166c-.01-.035-.026-.055-.037-.059l-.856-.293c-.043,0-.109.056-.139.162l-1.247,4.261-.042.02-.126.056c-.079.034-.158.065-.238.094l-.137.051V73.41c0-.126-.063-.2-.09-.2h-.9c-.026,0-.091.071-.091.2v3.059l-.094.009c-.079.008-.158.014-.238.018l-.107.005v-.88h-.164V76.5Zm.269-1.345V73.41a.63.63,0,0,1,.467-.665V69.769c0-.131-.064-.2-.091-.2h-.9c-.028,0-.091.076-.091.2v1.552a.636.636,0,0,1,.447.658v3.175Zm1.426-2.413a.612.612,0,0,1,.528.669V74.8l.254-.868.289-3.053a.287.287,0,0,0-.04-.188.056.056,0,0,0-.031-.024l-.9-.1c-.027,0-.093.068-.1.191l-.189,1.987Z",
        fill: color
      })]
    })
  });
};
// CONCATENATED MODULE: ./src/assets/icons/Bakery.tsx



function Bakery_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Bakery_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Bakery_ownKeys(Object(source), true).forEach(function (key) { Bakery_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Bakery_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Bakery_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Bakery = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Bakery_objectSpread(Bakery_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    id: "Outline",
    viewBox: "0 0 512 512",
    width: "512",
    height: "512"
  }, props), {}, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M213.056,231.438a8,8,0,1,0,5.888-14.876c-18.527-7.335-42.3-11.374-66.944-11.374s-48.417,4.039-66.944,11.374a8,8,0,1,0,5.888,14.876c16.7-6.61,38.382-10.25,61.056-10.25S196.357,224.828,213.056,231.438Z",
      fill: "currentColor"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M416,16H384c-23.366,0-43.613,25.444-58.552,73.58-7.08,22.815-12.528,49.446-16.163,78.42H144v.118c-32.288.855-62.486,6.86-85.746,17.149C31.006,197.319,16,214.135,16,232.617c0,15.891,11.317,30.777,32,42.266V422.049a65.688,65.688,0,0,0-23.435,38.717,29.684,29.684,0,0,0,6.2,24.659A28.79,28.79,0,0,0,53.047,496H346.953a28.681,28.681,0,0,0,17.852-6.229A34.1,34.1,0,0,0,384,496h32c23.366,0,43.613-25.444,58.552-73.58C488.383,377.854,496,318.751,496,256s-7.617-121.854-21.448-166.42C459.613,41.444,439.366,16,416,16ZM53.047,480a12.848,12.848,0,0,1-9.929-4.743,13.738,13.738,0,0,1-2.851-11.416,49.465,49.465,0,0,1,29.246-36.168,111.883,111.883,0,0,0-4.867,19.063A47.027,47.027,0,0,0,71.416,480ZM104,480H99.361c-4.729,0-9.3-2.31-12.859-6.5-5.263-6.195-7.531-15.233-6.067-24.177,4-24.452,16.7-44.92,33.932-56.125a86.14,86.14,0,0,0-.505,38.033l9.6,45.7a23.548,23.548,0,0,0,.886,3.067Zm18.94-108.547c-18.246,5.984-33.872,19.364-44.576,37.26A63.07,63.07,0,0,0,64,412.654V270.061a8,8,0,0,0-4.415-7.152C41.8,253.993,32,243.235,32,232.617,32,221.024,43.929,209.1,64.727,199.9,87.905,189.646,118.9,184,152,184s64.1,5.646,87.273,15.9c20.8,9.2,32.727,21.125,32.727,32.718,0,10.618-9.8,21.376-27.585,30.292A8,8,0,0,0,240,270.061v66.433a82.933,82.933,0,0,0-19.088-6.381,104.007,104.007,0,0,0-41.824,0,82.889,82.889,0,0,0-52.978,36.075C124.979,367.91,123.938,369.673,122.94,371.453Zm147.539,56.485-9.6,45.707A8.037,8.037,0,0,1,253.05,480H146.95a8.037,8.037,0,0,1-7.829-6.355l-9.6-45.707a69.688,69.688,0,0,1,9.962-52.964,66.994,66.994,0,0,1,42.8-29.184,88.1,88.1,0,0,1,35.426,0,66.994,66.994,0,0,1,42.8,29.184A69.688,69.688,0,0,1,270.479,427.938ZM313.5,473.5c-3.563,4.193-8.13,6.5-12.859,6.5H275.651a23.579,23.579,0,0,0,.886-3.066l9.6-45.706a86.14,86.14,0,0,0-.5-38.033c17.233,11.2,29.929,31.674,33.932,56.126C321.029,458.265,318.761,467.3,313.5,473.5ZM277.06,371.453c-1-1.78-2.039-3.543-3.17-5.265A84.568,84.568,0,0,0,256,346.53V274.883c20.683-11.489,32-26.375,32-42.266,0-18.482-15.006-35.3-42.254-47.35-.982-.435-2-.848-3-1.267h64.745C305.194,206.984,304,231.205,304,256c0,56.555,6.13,109.782,17.4,152.319C310.705,390.619,295.172,377.393,277.06,371.453Zm79.822,103.8A12.848,12.848,0,0,1,346.953,480H328.584a47.028,47.028,0,0,0,6.77-33.265,111.965,111.965,0,0,0-4.867-19.062,49.463,49.463,0,0,1,29.246,36.169A13.737,13.737,0,0,1,356.882,475.257ZM384,480a18.245,18.245,0,0,1-9.814-3.218,29.809,29.809,0,0,0,1.249-16.016A65.552,65.552,0,0,0,339.708,414.3a401.074,401.074,0,0,1-9.879-42.129c11.047-3.1,35.55-7.273,67.641,3.423v0a8,8,0,1,0,5.058-15.17v0l-.089-.029-.113-.035c-34.435-11.43-61.2-7.762-75.142-4.084a677.754,677.754,0,0,1-7.164-94.85c9.779-3.326,35.077-9.281,69.448,2.176v0a8,8,0,1,0,5.058-15.17v0l-.088-.028-.116-.037c-33.673-11.174-60.012-7.529-74.241-3.655a669.018,669.018,0,0,1,6.836-87.643c9.119-3,35.244-9.227,70.549,2.541v0a8,8,0,1,0,5.058-15.17v0l-.089-.029-.113-.035c-32.393-10.752-57.989-8.143-72.517-4.733a393.693,393.693,0,0,1,10.918-45.292C352.84,55.3,369.016,32,384,32s31.16,23.3,43.271,62.322C440.639,137.4,448,194.812,448,256s-7.361,118.605-20.729,161.678C415.16,456.7,398.984,480,384,480Zm75.271-62.322C447.16,456.7,430.984,480,416,480h-1.859c10.781-12.331,20.367-31.659,28.411-57.58C456.383,377.854,464,318.751,464,256s-7.617-121.854-21.448-166.42c-8.044-25.921-17.63-45.249-28.411-57.58H416c14.984,0,31.16,23.3,43.271,62.322C472.639,137.4,480,194.812,480,256S472.639,374.605,459.271,417.678Z",
      fill: "currentColor"
    })]
  }));
};
// CONCATENATED MODULE: ./src/assets/icons/category-menu-icons.ts










/***/ }),

/***/ "KeDb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("pONU");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _router = __webpack_require__("L9lV");

var _router2 = __webpack_require__("7xIC");

var _useIntersection = __webpack_require__("HOTy");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (false) {}
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (false) {}

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router.getDomainLocale)(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router.addBasePath)((0, _router.addLocale)(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "L9lV":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__("ZsnT");

var _routeLoader = __webpack_require__("Ycay");

var _denormalizePagePath = __webpack_require__("uzwF");

var _normalizeLocalePath = __webpack_require__("Jsn8");

var _mitt = _interopRequireDefault(__webpack_require__("YBsB"));

var _utils = __webpack_require__("fvxO");

var _isDynamic = __webpack_require__("Lko9");

var _parseRelativeUrl = __webpack_require__("3G4Q");

var _querystring = __webpack_require__("FrRs");

var _resolveRewrites = _interopRequireDefault(__webpack_require__("cIWs"));

var _routeMatcher = __webpack_require__("TBBy");

var _routeRegex = __webpack_require__("uChv");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {}

  return false;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href); // Return because it cannot be routed by the Next.js router

  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils.getLocationOrigin)();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router.pathname, url, true);
  const origin = (0, _utils.getLocationOrigin)();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router.pathname, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
}

const manualScrollRestoration =  false && false;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  // In-flight Server Data Requests, for deduping
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sdr = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;
    this.domainLocales = void 0;
    this.isReady = void 0;
    this.isPreview = void 0;
    this.isLocaleDomain = void 0;
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic.isDynamicRoute)(_pathname) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || !autoExportDynamic && !self.location.search);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    var _options$scroll;

    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    } // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated


    if (options._h) {
      this.isReady = true;
    } // Default to scroll reset behavior unless explicitly specified to be
    // `false`! This makes the behavior between using `Router#push` and a
    // `<Link />` consistent.


    options.scroll = !!((_options$scroll = options.scroll) != null ? _options$scroll : true);
    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname;

    if (pathname !== '/_error') {
      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname, pages);

        if (parsed.pathname !== pathname) {
          pathname = parsed.pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);

    if (!isLocalURL(as)) {
      if (false) {}

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (false) {}

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var _self$__NEXT_DATA__$p, _self$__NEXT_DATA__$p2;

      let routeInfo = await this.getRouteInfo(route, pathname, query, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);

            if (pages.includes(parsedHref.pathname)) {
              const {
                url: newUrl,
                as: newAs
              } = prepareUrlAs(this, destination, destination);
              return this.change(method, newUrl, newAs, options);
            }
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (false) {} // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      if (options._h && pathname === '/_error' && ((_self$__NEXT_DATA__$p = self.__NEXT_DATA__.props) == null ? void 0 : (_self$__NEXT_DATA__$p2 = _self$__NEXT_DATA__$p.pageProps) == null ? void 0 : _self$__NEXT_DATA__$p2.statusCode) === 500 && props != null && props.pageProps) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo, forcedScroll || (isValidShallowRoute || !options.scroll ? null : {
        x: 0,
        y: 0
      })).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (false) {}

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname) {
        pathname = parsed.pathname;
        url = (0, _utils.formatWithValidation)(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (false) {}

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if ( true && !this.isPreview && this.sdc[cacheKey]) {
      return Promise.resolve(this.sdc[cacheKey]);
    }

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err => {
      delete this.sdr[resourceKey];
      throw err;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "Lko9":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "OBDI":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH3QAMAAQAAQAQAC5hY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAIQACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0MgEJCQkMCwwYDQ0YMiEcITIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIy/8IAEQgAgACAAwEiAAIRAQMRAf/EABsAAAIDAQEBAAAAAAAAAAAAAAQFAwYHAgEA/9oACAEBAAAAANSFss/tcrNV6u9tirnMk7YSJzRc/jF99fao4rIMliXAOcNKr6meUqx7fFW+bF4uVZRq6xMFxCLsRbFjXhg46RcBRgjJKdaok/eniwgoXgsHEhyJgRyIzObVIeoI9BUVq9yt+eOPDPQJhVTtWqsozH35kkNrDE+UU6Mchb1NyQExIHC+XQHG+QEsu2+ZBLDpvFi4m2d8jceWPNPkgN7r2lKGlbqRdjfQ95d9AHtOaWeIqiilFaDZBcQj6G05pnYDuqyyk2a19ZBH1AbpsvtKqc3s1g0LzF4pOID2Q6zyXnux6CP/AP/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwQABf/aAAgBAhAAAADDQkKTF+HUSkeVG1y5pLO9t3YBnTTUknBK+5zLvNfXZ/J9M5pbufyP/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQMEAgAF/9oACAEDEAAAAK8FhWDoUMKJ8uNDxBgrrc9cnkdf3ouRJMKxXdJ50+Leu6TAbOKXQHqv/8QAJBAAAgMAAgIBBQEBAAAAAAAAAgMBBAUGEQAUEhMVISMxIhb/2gAIAQEAAQUA26Svr1cwbc1kghEefzzZ1s2o+zziSPS2NPVZQ27dI8rnVIxrXE2kXc5N0LCHU2fKYkWzHgtifNb8+VHQiuGi+CBCrqecb1PITUuraudCmuW65F57FiUptoU3A5SOZdweRVdhbq6nr085mf4t4HEN6nT6k4QbkfBqmXdQaPHdZq3WBxrE5l2pZrzBXDlENPxgNEcwGBObs+orE0I1MXUvoGuKhgJmI8t2Ic2rMAhpwbuYi8+H4FA9Db9cIG1QQ0XYVefJxEtH7H8osYjqlLEgSsrsBTzsY85sV8bPOVZ9NMPT8CechX76jan58U4pUBF5kz2YlPhxM+VpghAOpBI2I4zllW3tO7eK0sziHberUsDz/WWa7Y26N4O1qTMo3zL/AJviiJMHGIRLxnx3ZiCgABSvxCo+OcArtgEmzpMeGKph1WucYNk3jq2ZROaoCo6susvxBmpxfe1bRvoauoLs2X2Ku/q2soUcj07LOLaN1p1qUOuxxoZGeNlHhccf1OBbjzi0SStue2I11pVdb7JZqhbg2qSZX9kWc1a0V6u3kzdKlx9a7mTlpoNbBTZ+52Qluw8fE7FkiRdNieIzM1dgu32adsjw4aFbFOftrpiZU8ZsOmBW4hFELiSh8VkQoq6p/oLUYkIBNd7YXw8pmrpzHtru5MpNWe3zIIFDdsQAxdrVlhy2u5VXXVpV6pz1qsFFWy0rE1c76kAjMQupnZts6XHKLKtDZRjJ0OV24IOUss1cvlecAr3QHT1dYrkNoWoWVFJsotKq/Evk4dTdozYdYC1Rzp0V2NgbJV8qL1ZSdO8rNXpyyDugYWWSm1NoiDSzGt4Px7aJVj20lWdr0ZsImqa9/XRkNO+di0uz2eTyEpI5fZXNa3IwNoQbZkGezMTYdJqIv30jGMrkOY7C1KHIaza/s1m27OuCKFq9Nu8o+orN6bnPmH8V04AY0EyLQQwpn5qhszEzMkU/54pqjdxLtZFyro8Z0stkN14ZXw7/AKYHM6Ky68rtkGUz6jFsyDVVyGxa+sLCOO4mPkJfgojvC125F2rqVraTOIhFmInmfJAugr8W4/EgXUJORDGbB6SpiXu6lhz3MF+wZmYOP2/2amjZp+L5PbCLW1euxZjpsR0/vzv/ACEwR4Iz9SkyChzoK3//xAAyEAACAwABAwIFAgUDBQAAAAABAgADEQQSITFBURATMmFxBSIUI3KBsSQzoVKCkcHw/9oACAEBAAY/AEsVMY/URNLFVHY4IlaeF+JzlZywMyryPzDSmOyk71PFd7uisBjrKTn4ER05tqisHAMCt79XvDVyCVYNmxLarFZG8ETSAtg8MJ0XjtuK4g+KiO0JDRH5NYs0bjaQI/G/TGfi36FtupcgKvqAvgmFqLCEJDM7sSfzDb0BnGsWfu0Cs3VYRvy1H+T6QMQGOg4Tij7kmO62o1wGjoiclXNiLpZNOEGBPnVC/pDhAcLL75ClqhgYba9en/E1Tp+B+whVDkKy7ldWOqYv3aW22MpvNpKknq6oD31u7DI2oQp0AidFQKAnx2BYwm97CT4GkQ1ozAH0CEE/kw0El19zOQirlpHWjr9VRHhl9pw+fq/zqgxzxsers7EZkGLh9x8LQD9MLMYzACXPQuslq63sJRXaNrrcsVHiBSowRlKKVI8GdkAA9hH1QNMKlST4BEueoAMqklfcRWVAdOMhGyjh8XEpqQLLG5ViGzwFedZfrBJxQ2AT+Xxqh980x3HhoFDYDBOfUzYMH+Y3SPpB1j8DDHbP2/MIBMyWKwBUKRO42kFi35B0QJSoWkfUYW1uqMEru6QexEGvfv3iN5aLOrRonORRjFAf+ZdyD9O9I+GCYLCgPkgaYqKAqgYBAGJz26jCFAzCABLyqYwYhiYS5HTO2TSqw7UsKsTinAJX7GEvmt3An6hxAzBAhQASpx9dhY6ZYqX2M1ZxhSmhf7zqHMvFZYL1WICsVrCpYeSIQhrDehaaeXUp3MKlRFq5aKyt9NiGc3HChriubhGGDL7B/wB07cmyHOU07ck5+JafZpWIqm06JZbQ3a0hWInEQnqCoRCgqXPbIAEUD2CwjwdiOAujCNEFxTGwjRAvFBWvdCE6FgZM78x3b8CAFoOk7MMDES77vFEZ62AEuq5OaO6kx6t/27nUH4CtcLGAEdzFc+PBMDDsTLLc0opIAgRjrsdJg0zWYCahgC+Jb/WYuwIzKGh+VePwDOdQozp5DQw3NeFb3BGwBmYsvbTClNoZPBECk7Kg2nqsBIHqBEdRhOEbA994yY1qyxluXB5wxX+Yx31Bj1ULybizFi5RQP8AMa1U5DHNClaz/wC41tqhG3CiIW6YHurKsOzYdX/zHvTUo5K9a9USvj7pG/mD59FjN5BTCMi2tySjKSCjCFlu6R3AIUnqjmxjoIOmCnkXdICYCFJGxBxOTUz/ANYWMnLLBR9PqDD8nq0mOxtZQwGiKaeSykCFWYCxOx9OoTOohPf1Uw5+1X7EAwox/e1mEicTk0aeRQGsz3Q//AxS40ForFeoEA5AjjqIPhkBgcgHt5zsIEozbdJIhtY6Ii+haKhbVO6GnVRjVtAIF0ACK4YgnsZ9jDoOqcH4iN74c2cZVOgUqP8AiDk0j/SW2FlP/Q3qsrpf1XTDZ0qACAABLFoCoQpPcyqxm1ipIJnmJnozHfwIzHxXWTHrbG1fBmGkQtrp9hGRjjCDz407CPJII2D7GUp1bZSPlsJZRegauwEET5nDb+Jp9Avkf2i0Hicj5h7Kvyzst5360P4fhUoztXv77Pt9p1EBdY9gPAg2H7BjLCfDEAynD3ttAH4JhAds3sNg6LCoAAwDYlq4NOERhvuRAcjqYLVOof22J7xbEcYRCVIyHVCgDuxi/pvDbaS+2OPDQH1LkTfuZYR4AIioDhYzhr6Ltn4A8Q5GBh9mzfTDF+Ge4yBp/KclPUEz0/BnQ9pCHyo7CVQN5/fuiP20gmOB43CYDpAjXt5bFX7KILCRhUT9rA98OGf/xAAhEQADAAICAgIDAAAAAAAAAAAAAQIDERIhEBMgMQRBQv/aAAgBAgEBPwAl/Ds38Kf6QsrQsj2bbEub0LExJpaZsYmyWyU+J9G9GRGSdJUhjTbInX2JuZPXJ6pLHLa0W+KIraHQpb0ca2TFHRpMzRvuSGhTuuiehQmx8Z6TNePY4tpnpmu4ZhxqPH8tCy2tvzmwK+zH+NSYp4+JnZlnjtH/xAAfEQADAAICAwEBAAAAAAAAAAAAAQIDERIhBBMxEEH/2gAIAQMBAT8AXwaJjYp0jgVLQvxGiEeqWPHOi5SHqOx5UNpsS7I+mkUkZK70cdnBMxnjUnblkdCa1oqtroeNZLZzo9lEkZOF8jE1Rw76OP0vKpTOUjqRQhyjDSl6ZFz/AFGapHiVGTG4XR2/4cimetVCaJzuFq0Zsjtio6oeKBsbPH8jh1Rfkw0VW6/Eye2j/9k=");

/***/ }),

/***/ "PsoQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// NAMESPACE OBJECT: ./src/assets/icons/flags.ts
var flags_namespaceObject = {};
__webpack_require__.r(flags_namespaceObject);
__webpack_require__.d(flags_namespaceObject, "DEFlag", function() { return DEFlag; });
__webpack_require__.d(flags_namespaceObject, "CNFlag", function() { return CNFlag; });
__webpack_require__.d(flags_namespaceObject, "USFlag", function() { return USFlag; });
__webpack_require__.d(flags_namespaceObject, "ILFlag", function() { return ILFlag; });
__webpack_require__.d(flags_namespaceObject, "ESFlag", function() { return ESFlag; });
__webpack_require__.d(flags_namespaceObject, "SAFlag", function() { return SAFlag; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/theme-get"
var theme_get_ = __webpack_require__("/JeY");

// CONCATENATED MODULE: ./src/layouts/header/menu/language-switcher/language-switcher.style.tsx


const Box = external_styled_components_default.a.div.withConfig({
  displayName: "language-switcherstyle__Box",
  componentId: "sc-1aklqk-0"
})(["margin-right:20px;@media (max-width:990px){margin-left:auto;}.popover-wrapper.right{.popover-content{padding:15px 0;}}@media (max-width:767px){margin-right:10px;}"]);
const SelectedItem = external_styled_components_default.a.button.withConfig({
  displayName: "language-switcherstyle__SelectedItem",
  componentId: "sc-1aklqk-1"
})(["width:auto;height:38px;display:flex;align-items:center;background-color:", ";border:1px solid ", ";padding-top:0;padding-bottom:0;padding-left:10px;padding-right:10px;border-radius:", ";outline:0;cursor:pointer;@media (max-width:767px){border:0;padding:0;}span{display:flex;align-items:center;font-family:", ";font-size:", "px;font-weight:", ";color:", ";text-decoration:none;@media (max-width:767px){display:none;}&:first-child{margin-right:auto;}}"], Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('colors.gray.500', '#f1f1f1'), Object(theme_get_["themeGet"])('radii.base', '6px'), Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
const Flag = external_styled_components_default.a.div.withConfig({
  displayName: "language-switcherstyle__Flag",
  componentId: "sc-1aklqk-2"
})(["margin-right:7px;box-shadow:0 0 3px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;border-radius:2px;overflow:hidden;svg{width:20px;height:auto;}@media (max-width:767px){margin-right:0;}"]);
const MenuItem = external_styled_components_default.a.button.withConfig({
  displayName: "language-switcherstyle__MenuItem",
  componentId: "sc-1aklqk-3"
})(["width:100%;font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;display:block;padding:15px 30px;border-radius:", ";transition:0.15s ease-in-out;display:flex;align-items:center;border:0;border-bottom:1px solid ", ";border-radius:0;background-color:transparent;outline:0;cursor:pointer;&:last-child{border-bottom:0;}@media (max-width:1400px){margin-right:10px;font-size:", "px;}@media only screen and (min-width:991px) and (max-width:1200px){padding:15px 30px;}span{box-shadow:0 0 3px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;border-radius:2px;overflow:hidden;margin-right:15px;svg{display:block;width:20px;height:auto;}}"], Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.text.bold', '#0D1136'), Object(theme_get_["themeGet"])('radii.base', '6px'), Object(theme_get_["themeGet"])('colors.gray.500', '#f1f1f1'), Object(theme_get_["themeGet"])('fontSizes.base', '15'));
// EXTERNAL MODULE: ./src/components/popover/popover.tsx + 2 modules
var popover = __webpack_require__("63jn");

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// CONCATENATED MODULE: ./src/assets/icons/DEFlag.tsx



const DEFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ffce00",
      d: "M0 320h640v160H0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M0 0h640v160H0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#d00",
      d: "M0 160h640v160H0z"
    })]
  });
};
// CONCATENATED MODULE: ./src/assets/icons/CNFlag.tsx



const CNFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("defs", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        id: "a",
        fill: "#ffde00",
        d: "M-.6.8L0-1 .6.8-1-.3h2z"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#de2910",
      d: "M0 0h640v480H0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("use", {
      width: "30",
      height: "20",
      transform: "matrix(71.9991 0 0 72 120 120)",
      xlinkHref: "#a"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("use", {
      width: "30",
      height: "20",
      transform: "matrix(-12.33562 -20.5871 20.58684 -12.33577 240.3 48)",
      xlinkHref: "#a"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("use", {
      width: "30",
      height: "20",
      transform: "matrix(-3.38573 -23.75998 23.75968 -3.38578 288 95.8)",
      xlinkHref: "#a"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("use", {
      width: "30",
      height: "20",
      transform: "matrix(6.5991 -23.0749 23.0746 6.59919 288 168)",
      xlinkHref: "#a"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("use", {
      width: "30",
      height: "20",
      transform: "matrix(14.9991 -18.73557 18.73533 14.99929 240 216)",
      xlinkHref: "#a"
    })]
  });
};
// CONCATENATED MODULE: ./src/assets/icons/USFlag.tsx



const USFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    id: "flag-icon-css-us",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      fillRule: "evenodd",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
        strokeWidth: "1pt",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          fill: "#bd3d44",
          d: "M0 0h972.8v39.4H0zm0 78.8h972.8v39.4H0zm0 78.7h972.8V197H0zm0 78.8h972.8v39.4H0zm0 78.8h972.8v39.4H0zm0 78.7h972.8v39.4H0zm0 78.8h972.8V512H0z",
          transform: "scale(.9375)"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          fill: "#fff",
          d: "M0 39.4h972.8v39.4H0zm0 78.8h972.8v39.3H0zm0 78.7h972.8v39.4H0zm0 78.8h972.8v39.4H0zm0 78.8h972.8v39.4H0zm0 78.7h972.8v39.4H0z",
          transform: "scale(.9375)"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#192f5d",
        d: "M0 0h389.1v275.7H0z",
        transform: "scale(.9375)"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M32.4 11.8L36 22.7h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7H29zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7h11.4zm64.8 0l3.6 10.9H177l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7h11.5zm64.9 0l3.5 10.9H242l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.2-6.7h11.4zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.5zM64.9 39.4l3.5 10.9h11.5L70.6 57 74 67.9l-9-6.7-9.3 6.7L59 57l-9-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.3 6.7 3.6 10.9-9.3-6.7-9.3 6.7L124 57l-9.3-6.7h11.5zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 10.9-9.2-6.7-9.3 6.7 3.5-10.9-9.2-6.7H191zm64.8 0l3.6 10.9h11.4l-9.3 6.7 3.6 10.9-9.3-6.7-9.2 6.7 3.5-10.9-9.3-6.7H256zm64.9 0l3.5 10.9h11.5L330 57l3.5 10.9-9.2-6.7-9.3 6.7 3.5-10.9-9.2-6.7h11.4zM32.4 66.9L36 78h11.4l-9.2 6.7 3.5 10.9-9.3-6.8-9.2 6.8 3.5-11-9.3-6.7H29zm64.9 0l3.5 11h11.5l-9.3 6.7 3.5 10.9-9.2-6.8-9.3 6.8 3.5-11-9.2-6.7h11.4zm64.8 0l3.6 11H177l-9.2 6.7 3.5 10.9-9.3-6.8-9.2 6.8 3.5-11-9.3-6.7h11.5zm64.9 0l3.5 11H242l-9.3 6.7 3.6 10.9-9.3-6.8-9.3 6.8 3.6-11-9.3-6.7h11.4zm64.8 0l3.6 11h11.4l-9.2 6.7 3.5 10.9-9.3-6.8-9.2 6.8 3.5-11-9.2-6.7h11.4zm64.9 0l3.5 11h11.5l-9.3 6.7 3.6 10.9-9.3-6.8-9.3 6.8 3.6-11-9.3-6.7h11.5zM64.9 94.5l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.5zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7H191zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7H256zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7h11.4zM32.4 122.1L36 133h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7H29zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 10.9-9.2-6.7-9.3 6.7 3.5-10.9-9.2-6.7h11.4zm64.8 0l3.6 10.9H177l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7h11.5zm64.9 0l3.5 10.9H242l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.2-6.7h11.4zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.5zM64.9 149.7l3.5 10.9h11.5l-9.3 6.7 3.5 10.9-9.2-6.8-9.3 6.8 3.5-11-9.2-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.3 6.7 3.6 10.9-9.3-6.8-9.3 6.8 3.6-11-9.3-6.7h11.5zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 10.9-9.2-6.8-9.3 6.8 3.5-11-9.2-6.7H191zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 10.9-9.3-6.8-9.2 6.8 3.5-11-9.3-6.7H256zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 10.9-9.2-6.8-9.3 6.8 3.5-11-9.2-6.7h11.4zM32.4 177.2l3.6 11h11.4l-9.2 6.7 3.5 10.8-9.3-6.7-9.2 6.7 3.5-10.9-9.3-6.7H29zm64.9 0l3.5 11h11.5l-9.3 6.7 3.6 10.8-9.3-6.7-9.3 6.7 3.6-10.9-9.3-6.7h11.4zm64.8 0l3.6 11H177l-9.2 6.7 3.5 10.8-9.3-6.7-9.2 6.7 3.5-10.9-9.3-6.7h11.5zm64.9 0l3.5 11H242l-9.3 6.7 3.6 10.8-9.3-6.7-9.3 6.7 3.6-10.9-9.3-6.7h11.4zm64.8 0l3.6 11h11.4l-9.2 6.7 3.5 10.8-9.3-6.7-9.2 6.7 3.5-10.9-9.2-6.7h11.4zm64.9 0l3.5 11h11.5l-9.3 6.7 3.6 10.8-9.3-6.7-9.3 6.7 3.6-10.9-9.3-6.7h11.5zM64.9 204.8l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.3 6.7 3.6 11-9.3-6.8-9.3 6.7 3.6-10.9-9.3-6.7h11.5zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7H191zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 11-9.3-6.8-9.2 6.7 3.5-10.9-9.3-6.7H256zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.5 11-9.2-6.8-9.3 6.7 3.5-10.9-9.2-6.7h11.4zM32.4 232.4l3.6 10.9h11.4l-9.2 6.7 3.5 10.9-9.3-6.7-9.2 6.7 3.5-11-9.3-6.7H29zm64.9 0l3.5 10.9h11.5L103 250l3.6 10.9-9.3-6.7-9.3 6.7 3.6-11-9.3-6.7h11.4zm64.8 0l3.6 10.9H177l-9 6.7 3.5 10.9-9.3-6.7-9.2 6.7 3.5-11-9.3-6.7h11.5zm64.9 0l3.5 10.9H242l-9.3 6.7 3.6 10.9-9.3-6.7-9.3 6.7 3.6-11-9.3-6.7h11.4zm64.8 0l3.6 10.9h11.4l-9.2 6.7 3.5 10.9-9.3-6.7-9.2 6.7 3.5-11-9.2-6.7h11.4zm64.9 0l3.5 10.9h11.5l-9.3 6.7 3.6 10.9-9.3-6.7-9.3 6.7 3.6-11-9.3-6.7h11.5z",
        transform: "scale(.9375)"
      })]
    })
  });
};
// CONCATENATED MODULE: ./src/assets/icons/ILFlag.tsx



const ILFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("defs", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("clipPath", {
        id: "il-a",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          fillOpacity: ".7",
          d: "M-87.6 0H595v512H-87.6z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      fillRule: "evenodd",
      clipPath: "url(#il-a)",
      transform: "translate(82.1) scale(.94)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M619.4 512H-112V0h731.4z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#00c",
        d: "M619.4 115.2H-112V48h731.4zm0 350.5H-112v-67.2h731.4zm-483-275l110.1 191.6L359 191.6l-222.6-.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M225.8 317.8l20.9 35.5 21.4-35.3-42.4-.2z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#00c",
        d: "M136 320.6L246.2 129l112.4 190.8-222.6.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M225.8 191.6l20.9-35.5 21.4 35.4-42.4.1zM182 271.1l-21.7 36 41-.1-19.3-36zm-21.3-66.5l41.2.3-19.8 36.3-21.4-36.6zm151.2 67l20.9 35.5-41.7-.5 20.8-35zm20.5-67l-41.2.3 19.8 36.3 21.4-36.6zm-114.3 0L189.7 256l28.8 50.3 52.8 1.2 32-51.5-29.6-52-55.6.5z"
      })]
    })]
  });
};
// CONCATENATED MODULE: ./src/assets/icons/ESFlag.tsx



const ESFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    id: "flag-icon-css-es",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#AA151B",
      d: "M0 0h640v480H0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#F1BF00",
      d: "M0 120h640v240H0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M127.3 213.3l-.8-.1-1-1-.7-.4-.6-.8s-.7-1.1-.4-2c.3-.9.9-1.2 1.4-1.5a12 12 0 011.5-.5l1-.4 1.3-.3.5-.3c.2 0 .7 0 1-.2l1-.2 1.6.1h4.8c.4 0 1.2.3 1.4.4a35 35 0 002 .7c.5.1 1.6.3 2.2.6.5.3.9.7 1.1 1l.5 1v1.1l-.5.8-.6 1-.8.6s-.5.5-1 .4c-.4 0-4.8-.8-7.6-.8s-7.3.9-7.3.9"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M127.3 213.3l-.8-.1-1-1-.7-.4-.6-.8s-.7-1.1-.4-2c.3-.9.9-1.2 1.4-1.5a12 12 0 011.5-.5l1-.4 1.3-.3.5-.3c.2 0 .7 0 1-.2l1-.2 1.6.1h4.8c.4 0 1.2.3 1.4.4a35 35 0 002 .7c.5.1 1.6.3 2.2.6.5.3.9.7 1.1 1l.5 1v1.1l-.5.8-.6 1-.8.6s-.5.5-1 .4c-.4 0-4.8-.8-7.6-.8s-7.3.9-7.3.9z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M133.3 207c0-1.3.6-2.3 1.3-2.3.8 0 1.4 1 1.4 2.4 0 1.3-.6 2.4-1.4 2.4s-1.3-1.1-1.3-2.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M133.3 207c0-1.3.6-2.3 1.3-2.3.8 0 1.4 1 1.4 2.4 0 1.3-.6 2.4-1.4 2.4s-1.3-1.1-1.3-2.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134 207c0-1.2.3-2.1.7-2.1.3 0 .6 1 .6 2.1 0 1.3-.3 2.2-.6 2.2-.4 0-.6-1-.6-2.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134 207c0-1.2.3-2.1.7-2.1.3 0 .6 1 .6 2.1 0 1.3-.3 2.2-.6 2.2-.4 0-.6-1-.6-2.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M133.8 204.5c0-.4.4-.8.8-.8s1 .4 1 .8c0 .5-.5.9-1 .9s-.8-.4-.8-.9"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M135.3 204.2v.6h-1.4v-.6h.5V203h-.7v-.6h.7v-.5h.5v.5h.6v.6h-.6v1.2h.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M135.3 204.2v.6h-1.4v-.6h.5V203h-.7v-.6h.7v-.5h.5v.5h.6v.6h-.6v1.2h.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M135.9 204.2v.6h-2.5v-.6h1V203h-.7v-.6h.7v-.5h.5v.5h.6v.6h-.6v1.2h1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M135.9 204.2v.6h-2.5v-.6h1V203h-.7v-.6h.7v-.5h.5v.5h.6v.6h-.6v1.2h1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.9 203.7c.4.1.6.4.6.8 0 .5-.4.9-.8.9s-1-.4-1-.9c0-.4.3-.7.7-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.7 213.2H130v-1.1l-.3-1.2-.2-1.5c-1.3-1.7-2.5-2.8-2.9-2.5.1-.3.2-.6.5-.7 1.1-.7 3.5 1 5.2 3.6l.5.7h3.8l.4-.7c1.8-2.7 4.1-4.3 5.2-3.6.3.1.4.4.5.7-.4-.3-1.6.8-2.9 2.5l-.2 1.5-.2 1.2-.1 1.1h-4.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.7 213.2H130v-1.1l-.3-1.2-.2-1.5c-1.3-1.7-2.5-2.8-2.9-2.5.1-.3.2-.6.5-.7 1.1-.7 3.5 1 5.2 3.6l.5.7h3.8l.4-.7c1.8-2.7 4.1-4.3 5.2-3.6.3.1.4.4.5.7-.4-.3-1.6.8-2.9 2.5l-.2 1.5-.2 1.2-.1 1.1h-4.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M126.8 206.8c1-.5 3 1.1 4.6 3.6m11-3.6c-.8-.5-2.8 1.1-4.5 3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M127.8 215.3l-.5-1a27.3 27.3 0 0114.7 0l-.5.8a5.7 5.7 0 00-.3.8 22.9 22.9 0 00-6.6-.8c-2.6 0-5.2.3-6.5.8l-.3-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M127.8 215.3l-.5-1a27.3 27.3 0 0114.7 0l-.5.8a5.7 5.7 0 00-.3.8 22.9 22.9 0 00-6.6-.8c-2.6 0-5.2.3-6.5.8l-.3-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.6 217.7c2.4 0 5-.4 5.9-.6.6-.2 1-.5 1-.8 0-.2-.2-.3-.4-.4-1.4-.5-4-.8-6.5-.8s-5 .3-6.4.8c-.2 0-.3.2-.4.3 0 .4.3.7 1 .9 1 .2 3.5.6 5.8.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.6 217.7c2.4 0 5-.4 5.9-.6.6-.2 1-.5 1-.8 0-.2-.2-.3-.4-.4-1.4-.5-4-.8-6.5-.8s-5 .3-6.4.8c-.2 0-.3.2-.4.3 0 .4.3.7 1 .9 1 .2 3.5.6 5.8.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M142.1 213.2l-.5-.5s-.6.3-1.3.2c-.6 0-.9-1-.9-1s-.7.7-1.3.7c-.7 0-1-.6-1-.6s-.7.5-1.3.4c-.6 0-1.2-.8-1.2-.8s-.6.8-1.2.8c-.6.1-1-.5-1-.5s-.4.6-1.1.7-1.4-.6-1.4-.6-.5.7-1 1c-.5 0-1.2-.4-1.2-.4l-.2.5-.3.1.2.5a27 27 0 017.2-.9c3 0 5.5.4 7.4 1l.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M142.1 213.2l-.5-.5s-.6.3-1.3.2c-.6 0-.9-1-.9-1s-.7.7-1.3.7c-.7 0-1-.6-1-.6s-.7.5-1.3.4c-.6 0-1.2-.8-1.2-.8s-.6.8-1.2.8c-.6.1-1-.5-1-.5s-.4.6-1.1.7-1.4-.6-1.4-.6-.5.7-1 1c-.5 0-1.2-.4-1.2-.4l-.2.5-.3.1.2.5a27 27 0 017.2-.9c3 0 5.5.4 7.4 1l.2-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.7 210.7h.2a1 1 0 000 .4c0 .6.4 1 1 1a1 1 0 001-.7l.2-.3v.4c.1.5.6.8 1.1.8.6 0 1-.4 1-1v-.1l.4-.4.2.5a.9.9 0 00-.1.4 1 1 0 001 1c.4 0 .7-.2.9-.5l.2-.2v.3c0 .3.1.6.4.7 0 0 .4 0 1-.4l.7-.7v.4s-.5.8-1 1c-.2.2-.5.4-.8.3-.3 0-.6-.3-.7-.6-.2.2-.4.2-.7.2-.6 0-1.2-.3-1.4-.8-.3.3-.7.5-1.1.5a1.6 1.6 0 01-1.2-.6 1.6 1.6 0 01-1 .4 1.6 1.6 0 01-1.3-.6 1.6 1.6 0 01-2.4.2 1.6 1.6 0 01-1.2.6 1.5 1.5 0 01-1.1-.5c-.2.5-.8.8-1.4.8-.2 0-.5 0-.7-.2-.1.3-.4.6-.7.6-.3 0-.6 0-.9-.2l-1-1 .1-.5.8.7c.5.4.9.4.9.4.3 0 .4-.4.4-.7v-.3l.2.2c.2.3.5.5.9.5a1 1 0 001-1 .9.9 0 000-.4v-.5l.4.4a.7.7 0 000 .1c0 .6.5 1 1 1 .6 0 1-.3 1.1-.9v-.3l.2.3c.2.4.6.7 1 .7.7 0 1.1-.4 1.1-1a1 1 0 000-.3h.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.7 210.7h.2a1 1 0 000 .4c0 .6.4 1 1 1a1 1 0 001-.7l.2-.3v.4c.1.5.6.8 1.1.8.6 0 1-.4 1-1v-.1l.4-.4.2.5a.9.9 0 00-.1.4 1 1 0 001 1c.4 0 .7-.2.9-.5l.2-.2v.3c0 .3.1.6.4.7 0 0 .4 0 1-.4l.7-.7v.4s-.5.8-1 1c-.2.2-.5.4-.8.3-.3 0-.6-.3-.7-.6-.2.2-.4.2-.7.2-.6 0-1.2-.3-1.4-.8-.3.3-.7.5-1.1.5a1.6 1.6 0 01-1.2-.6 1.6 1.6 0 01-1 .4 1.6 1.6 0 01-1.3-.6 1.6 1.6 0 01-2.4.2 1.6 1.6 0 01-1.2.6 1.5 1.5 0 01-1.1-.5c-.2.5-.8.8-1.4.8-.2 0-.5 0-.7-.2-.1.3-.4.6-.7.6-.3 0-.6 0-.9-.2l-1-1 .1-.5.8.7c.5.4.9.4.9.4.3 0 .4-.4.4-.7v-.3l.2.2c.2.3.5.5.9.5a1 1 0 001-1 .9.9 0 000-.4v-.5l.4.4a.7.7 0 000 .1c0 .6.5 1 1 1 .6 0 1-.3 1.1-.9v-.3l.2.3c.2.4.6.7 1 .7.7 0 1.1-.4 1.1-1a1 1 0 000-.3h.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.6 213.3c-2.9 0-5.5.4-7.3 1l-.3-.2.1-.3a27 27 0 017.5-1c3 0 5.7.4 7.6 1 0 0 .2.2.1.3l-.3.2a27.3 27.3 0 00-7.4-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M134.6 213.3c-2.9 0-5.5.4-7.3 1l-.3-.2.1-.3a27 27 0 017.5-1c3 0 5.7.4 7.6 1 0 0 .2.2.1.3l-.3.2a27.3 27.3 0 00-7.4-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M131.8 214.4c0-.3.2-.4.5-.4a.4.4 0 01.4.4c0 .2-.2.4-.4.4a.4.4 0 01-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M131.8 214.4c0-.3.2-.4.5-.4a.4.4 0 01.4.4c0 .2-.2.4-.4.4a.4.4 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M134.7 214.5h-1c-.1 0-.3 0-.3-.3l.3-.3h2a.3.3 0 01.2.3.3.3 0 01-.3.3h-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.7 214.5h-1c-.1 0-.3 0-.3-.3l.3-.3h2a.3.3 0 01.2.3.3.3 0 01-.3.3h-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      d: "M130 214.9h-.7c-.1 0-.3 0-.3-.2a.3.3 0 01.2-.3l.7-.1.7-.1c.2 0 .3 0 .4.2a.3.3 0 01-.3.4h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M130 214.9h-.7c-.1 0-.3 0-.3-.2a.3.3 0 01.2-.3l.7-.1.7-.1c.2 0 .3 0 .4.2a.3.3 0 01-.3.4h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M127.3 215.3l.3-.4h.7l-.4.6-.6-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M127.3 215.3l.3-.4h.7l-.4.6-.6-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M136.6 214.4c0-.3.2-.4.4-.4a.4.4 0 01.5.4.4.4 0 01-.5.4.4.4 0 01-.4-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M136.6 214.4c0-.3.2-.4.4-.4a.4.4 0 01.5.4.4.4 0 01-.5.4.4.4 0 01-.4-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      d: "M139.3 214.9h.6a.3.3 0 00.4-.2.3.3 0 00-.3-.3l-.6-.1-.7-.1c-.2 0-.3 0-.4.2 0 .2.1.3.3.4h.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M139.3 214.9h.6a.3.3 0 00.4-.2.3.3 0 00-.3-.3l-.6-.1-.7-.1c-.2 0-.3 0-.4.2 0 .2.1.3.3.4h.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M142 215.4l-.3-.5h-.7l.3.6.6-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M142 215.4l-.3-.5h-.7l.3.6.6-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M134.6 217.1a25 25 0 01-6-.6 25.5 25.5 0 0112.1 0c-1.6.4-3.7.6-6 .6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M134.6 217.1a25 25 0 01-6-.6 25.5 25.5 0 0112.1 0c-1.6.4-3.7.6-6 .6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M142 212l-.1-.3c-.2 0-.3 0-.4.2 0 .2 0 .4.2.4 0 0 .2 0 .3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M142 212l-.1-.3c-.2 0-.3 0-.4.2 0 .2 0 .4.2.4 0 0 .2 0 .3-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M137.3 211.2c0-.2 0-.4-.2-.4 0 0-.2.1-.2.3 0 .2 0 .4.2.4l.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M137.3 211.2c0-.2 0-.4-.2-.4 0 0-.2.1-.2.3 0 .2 0 .4.2.4l.3-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M132 211.2l.1-.4c.2 0 .3.1.3.3 0 .2 0 .4-.2.4l-.2-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M132 211.2l.1-.4c.2 0 .3.1.3.3 0 .2 0 .4-.2.4l-.2-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M127.3 212l.1-.3c.2 0 .3 0 .4.2 0 .2 0 .4-.2.4 0 0-.2 0-.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M127.3 212l.1-.3c.2 0 .3 0 .4.2 0 .2 0 .4-.2.4 0 0-.2 0-.3-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.6 208.5l-.8.5.6 1.3.2.1.2-.1.7-1.3-.9-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.6 208.5l-.8.5.6 1.3.2.1.2-.1.7-1.3-.9-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M132.8 210.5l.4.5 1.3-.4.1-.2-.1-.2-1.3-.3-.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M132.8 210.5l.4.5 1.3-.4.1-.2-.1-.2-1.3-.3-.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M136.4 210.5l-.3.5-1.3-.4-.2-.2.2-.2 1.3-.3.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M136.4 210.5l-.3.5-1.3-.4-.2-.2.2-.2 1.3-.3.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M129.3 209l-.7.7.9 1 .2.1.1-.1.3-1.3-.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M129.3 209l-.7.7.9 1 .2.1.1-.1.3-1.3-.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M128 211.2l.4.5 1.2-.6v-.2l-.1-.2-1.3-.1-.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M128 211.2l.4.5 1.2-.6v-.2l-.1-.2-1.3-.1-.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M131.5 210.5l-.3.6H130l-.2-.2.1-.3 1.2-.6.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M131.5 210.5l-.3.6H130l-.2-.2.1-.3 1.2-.6.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.6 211.4v.6l-1.4.2-.2-.1v-.2l1-.9.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M126.6 211.4v.6l-1.4.2-.2-.1v-.2l1-.9.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M129.2 210.9c0-.3.2-.5.5-.5s.5.2.5.5a.5.5 0 01-.5.4.5.5 0 01-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M129.2 210.9c0-.3.2-.5.5-.5s.5.2.5.5a.5.5 0 01-.5.4.5.5 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M140 209l.7.7-.9 1-.2.1-.1-.1-.3-1.3.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M140 209l.7.7-.9 1-.2.1-.1-.1-.3-1.3.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M141.4 211.2l-.5.5-1.2-.6v-.2l.1-.2 1.3-.1.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M141.4 211.2l-.5.5-1.2-.6v-.2l.1-.2 1.3-.1.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M137.8 210.5l.3.6h1.3l.2-.2-.1-.3-1.2-.6-.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M137.8 210.5l.3.6h1.3l.2-.2-.1-.3-1.2-.6-.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M142.5 211.4l.1.6 1.3.2.2-.1v-.2l-1-.9-.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M142.5 211.4l.1.6 1.3.2.2-.1v-.2l-1-.9-.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M134.2 210.4a.5.5 0 01.4-.4c.3 0 .5.2.5.4a.5.5 0 01-.5.5.5.5 0 01-.4-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M134.2 210.4a.5.5 0 01.4-.4c.3 0 .5.2.5.4a.5.5 0 01-.5.5.5.5 0 01-.4-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M139.1 210.9c0-.3.3-.5.5-.5a.5.5 0 01.5.5.5.5 0 01-.5.4.5.5 0 01-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M139.1 210.9c0-.3.3-.5.5-.5a.5.5 0 01.5.5.5.5 0 01-.5.4.5.5 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M124.8 212.2l-.6-.7c-.2-.2-.7-.3-.7-.3 0-.1.3-.3.6-.3a.5.5 0 01.4.2v-.2s.3 0 .4.3v1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M124.8 212.2l-.6-.7c-.2-.2-.7-.3-.7-.3 0-.1.3-.3.6-.3a.5.5 0 01.4.2v-.2s.3 0 .4.3v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M124.8 212c.1-.2.4-.2.5 0 .2.1.3.3.2.5l-.5-.1c-.2-.1-.3-.4-.2-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M124.8 212c.1-.2.4-.2.5 0 .2.1.3.3.2.5l-.5-.1c-.2-.1-.3-.4-.2-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M144.3 212.2l.6-.7c.2-.2.7-.3.7-.3 0-.1-.3-.3-.6-.3a.6.6 0 00-.4.2v-.2s-.3 0-.4.3v.7l.1.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M144.3 212.2l.6-.7c.2-.2.7-.3.7-.3 0-.1-.3-.3-.6-.3a.6.6 0 00-.4.2v-.2s-.3 0-.4.3v.7l.1.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M144.3 212c0-.2-.3-.2-.5 0-.2.1-.2.3-.1.5l.5-.1c.2-.1.2-.4.1-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M144.3 212c0-.2-.3-.2-.5 0-.2.1-.2.3-.1.5l.5-.1c.2-.1.2-.4.1-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M124 223h21.4v-5.5H124v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M124 223h21.4v-5.5H124v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.2 226.8a1 1 0 01.4 0h16.5a1.4 1.4 0 01-1-1.2c0-.6.5-1.1 1-1.3a1.7 1.7 0 01-.4 0h-16a1.4 1.4 0 01-.5 0c.6.2 1 .7 1 1.3a1.3 1.3 0 01-1 1.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M126.2 226.8a1 1 0 01.4 0h16.5a1.4 1.4 0 01-1-1.2c0-.6.5-1.1 1-1.3a1.7 1.7 0 01-.4 0h-16a1.4 1.4 0 01-.5 0c.6.2 1 .7 1 1.3a1.3 1.3 0 01-1 1.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.6 226.8h16c.6 0 1 .3 1 .7 0 .4-.4.8-1 .8h-16c-.5 0-1-.4-1-.8s.5-.8 1-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M126.6 226.8h16c.6 0 1 .3 1 .7 0 .4-.4.8-1 .8h-16c-.5 0-1-.4-1-.8s.5-.8 1-.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.6 223h16c.6 0 1 .4 1 .7 0 .4-.4.6-1 .6h-16c-.5 0-1-.2-1-.6 0-.3.5-.6 1-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M126.6 223h16c.6 0 1 .4 1 .7 0 .4-.4.6-1 .6h-16c-.5 0-1-.2-1-.6 0-.3.5-.6 1-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M149.6 317.4c-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8c-1.4 0-2.7.3-3.7.8a8.3 8.3 0 01-3.8.8c-1.5 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.7-.8 8 8 0 00-3.7.8 8.3 8.3 0 01-3.8.8v2.4c1.5 0 2.8-.4 3.8-.9a8.2 8.2 0 013.7-.8c1.4 0 2.7.3 3.7.8s2.2.9 3.7.9a8.4 8.4 0 003.8-.9c1-.5 2.3-.8 3.7-.8 1.5 0 2.8.3 3.8.8s2.2.9 3.7.9v-2.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M149.6 317.4c-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8c-1.4 0-2.7.3-3.7.8a8.3 8.3 0 01-3.8.8c-1.5 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.7-.8 8 8 0 00-3.7.8 8.3 8.3 0 01-3.8.8v2.4c1.5 0 2.8-.4 3.8-.9a8.2 8.2 0 013.7-.8c1.4 0 2.7.3 3.7.8s2.2.9 3.7.9a8.4 8.4 0 003.8-.9c1-.5 2.3-.8 3.7-.8 1.5 0 2.8.3 3.8.8s2.2.9 3.7.9v-2.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M149.6 319.8a8 8 0 01-3.7-.9 8.3 8.3 0 00-3.8-.8c-1.4 0-2.7.3-3.7.8s-2.3.9-3.8.9-2.8-.4-3.7-.9a8.4 8.4 0 00-3.7-.8 8.2 8.2 0 00-3.7.8c-1 .5-2.3.9-3.8.9v2.3c1.5 0 2.8-.4 3.8-.9a8.1 8.1 0 013.7-.7c1.4 0 2.7.2 3.7.7a8.3 8.3 0 007.5 0 8.5 8.5 0 017.5.1 8.1 8.1 0 003.7.8v-2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M149.6 319.8a8 8 0 01-3.7-.9 8.3 8.3 0 00-3.8-.8c-1.4 0-2.7.3-3.7.8s-2.3.9-3.8.9-2.8-.4-3.7-.9a8.4 8.4 0 00-3.7-.8 8.2 8.2 0 00-3.7.8c-1 .5-2.3.9-3.8.9v2.3c1.5 0 2.8-.4 3.8-.9a8.1 8.1 0 013.7-.7c1.4 0 2.7.2 3.7.7a8.3 8.3 0 007.5 0 8.5 8.5 0 017.5.1 8.1 8.1 0 003.7.8v-2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M149.6 322a7 7 0 01-3.7-.8 8.3 8.3 0 00-3.8-.7c-1.4 0-2.7.2-3.7.7-1 .6-2.3.9-3.8.9s-2.8-.4-3.7-.9a8.4 8.4 0 00-3.7-.8 8 8 0 00-3.7.8c-1 .5-2.3.9-3.8.9v2.3c1.5 0 2.8-.3 3.8-.9a10.2 10.2 0 017.4 0 7 7 0 003.7.9 8.4 8.4 0 003.8-.8c1-.5 2.3-.8 3.7-.8 1.5 0 2.8.3 3.8.8s2.2.8 3.7.8V322"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M149.6 322a7 7 0 01-3.7-.8 8.3 8.3 0 00-3.8-.7c-1.4 0-2.7.2-3.7.7-1 .6-2.3.9-3.8.9s-2.8-.4-3.7-.9a8.4 8.4 0 00-3.7-.8 8 8 0 00-3.7.8c-1 .5-2.3.9-3.8.9v2.3c1.5 0 2.8-.3 3.8-.9a10.2 10.2 0 017.4 0 7 7 0 003.7.9 8.4 8.4 0 003.8-.8c1-.5 2.3-.8 3.7-.8 1.5 0 2.8.3 3.8.8s2.2.8 3.7.8V322"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M149.6 326.7a8 8 0 01-3.7-.8c-1-.5-2.3-.8-3.7-.8a8.4 8.4 0 00-3.8.8c-1 .5-2.3.8-3.8.8a7 7 0 01-3.7-.9 8.4 8.4 0 00-3.7-.7c-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v-2.3a8.3 8.3 0 003.8-.9 10.2 10.2 0 017.4 0 8 8 0 003.7.9 8.4 8.4 0 003.8-.8c1-.5 2.3-.8 3.8-.8 1.4 0 2.7.3 3.7.8s2.3.8 3.7.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M149.6 326.7a8 8 0 01-3.7-.8c-1-.5-2.3-.8-3.7-.8a8.4 8.4 0 00-3.8.8c-1 .5-2.3.8-3.8.8a7 7 0 01-3.7-.9 8.4 8.4 0 00-3.7-.7c-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v-2.3a8.3 8.3 0 003.8-.9 10.2 10.2 0 017.4 0 8 8 0 003.7.9 8.4 8.4 0 003.8-.8c1-.5 2.3-.8 3.8-.8 1.4 0 2.7.3 3.7.8s2.3.8 3.7.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M149.6 329a8.1 8.1 0 01-3.7-.8c-1-.5-2.3-.8-3.7-.8a8.4 8.4 0 00-3.8.8c-1 .5-2.3.8-3.8.8a7 7 0 01-3.7-.9 8.4 8.4 0 00-3.7-.7c-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v-2.3a8.3 8.3 0 003.8-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.7.3 3.7.7a8.4 8.4 0 007.5 0c1-.4 2.3-.7 3.8-.7 1.4 0 2.7.3 3.7.8s2.2.8 3.7.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M149.6 329a8.1 8.1 0 01-3.7-.8c-1-.5-2.3-.8-3.7-.8a8.4 8.4 0 00-3.8.8c-1 .5-2.3.8-3.8.8a7 7 0 01-3.7-.9 8.4 8.4 0 00-3.7-.7c-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v-2.3a8.3 8.3 0 003.8-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.7.3 3.7.7a8.4 8.4 0 007.5 0c1-.4 2.3-.7 3.8-.7 1.4 0 2.7.3 3.7.8s2.2.8 3.7.8v2.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.2 308l.2.5c0 1.5-1.3 2.6-2.7 2.6h22a2.7 2.7 0 01-2.7-2.6v-.5a1.3 1.3 0 01-.3 0h-16a1.4 1.4 0 01-.5 0"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M126.2 308l.2.5c0 1.5-1.3 2.6-2.7 2.6h22a2.7 2.7 0 01-2.7-2.6v-.5a1.3 1.3 0 01-.3 0h-16a1.4 1.4 0 01-.5 0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M126.6 306.5h16c.6 0 1 .3 1 .8 0 .4-.4.7-1 .7h-16c-.5 0-1-.3-1-.8 0-.4.5-.7 1-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M126.6 306.5h16c.6 0 1 .3 1 .8 0 .4-.4.7-1 .7h-16c-.5 0-1-.3-1-.8 0-.4.5-.7 1-.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M123.7 316.7h22V311h-22v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M123.7 316.7h22V311h-22v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M122 286.7c-2.2 1.2-3.7 2.5-3.4 3.2 0 .6.8 1 1.8 1.6 1.5 1.1 2.5 3 1.7 4a5.5 5.5 0 00-.1-8.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M122 286.7c-2.2 1.2-3.7 2.5-3.4 3.2 0 .6.8 1 1.8 1.6 1.5 1.1 2.5 3 1.7 4a5.5 5.5 0 00-.1-8.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M126.8 305.6h15.6V229h-15.6v76.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M138 229.2v76.3m1.7-76.3v76.3m-12.9 0h15.6v-76.4h-15.6v76.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M158.4 257.7a49.6 49.6 0 00-23.3-2c-9.4 1.6-16.5 5.3-15.9 8.4v.2l-3.5-8.2c-.6-3.3 7.2-7.5 17.6-9.2a43 43 0 019.2-.7c6.6 0 12.4.8 15.8 2.1v9.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M158.4 257.7a49.6 49.6 0 00-23.3-2c-9.4 1.6-16.5 5.3-15.9 8.4v.2l-3.5-8.2c-.6-3.3 7.2-7.5 17.6-9.2a43 43 0 019.2-.7c6.6 0 12.4.8 15.8 2.1v9.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M126.8 267.3c-4.3-.3-7.3-1.4-7.6-3.2-.3-1.5 1.2-3 3.8-4.5 1.2.1 2.5.3 3.8.3v7.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M126.8 267.3c-4.3-.3-7.3-1.4-7.6-3.2-.3-1.5 1.2-3 3.8-4.5 1.2.1 2.5.3 3.8.3v7.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M142.5 261.5c2.7.4 4.7 1 5.7 1.9l.1.2c.5 1-1.9 3-5.9 5.4v-7.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M142.5 261.5c2.7.4 4.7 1 5.7 1.9l.1.2c.5 1-1.9 3-5.9 5.4v-7.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M117.1 282c-.4-1.2 3.8-3.6 9.8-5.8l7.8-3.2c8.3-3.7 14.4-7.9 13.6-9.4v-.2c.4.4 1 8 1 8 .8 1.3-4.8 5.5-12.4 9.1-2.5 1.2-7.6 3-10 4-4.4 1.4-8.7 4.3-8.3 5.3l-1.5-7.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M117.1 282c-.4-1.2 3.8-3.6 9.8-5.8l7.8-3.2c8.3-3.7 14.4-7.9 13.6-9.4v-.2c.4.4 1 8 1 8 .8 1.3-4.8 5.5-12.4 9.1-2.5 1.2-7.6 3-10 4-4.4 1.4-8.7 4.3-8.3 5.3l-1.5-7.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M125.8 254c1.9-.6 3.1-1.5 2.5-3-.4-1-1.4-1-2.8-.6l-2.6 1 2.3 5.8.8-.3.8-.3-1-2.5zm-1.2-2.7l.7-.3c.5-.2 1.2.1 1.4.8.2.5.2 1-.5 1.5a4.4 4.4 0 01-.6.3l-1-2.3m7.3-2.5l-.9.3h-.8l1.3 6.1 4.3-.8-.2-.4v-.4l-2.5.6-1.2-5.3m8.4 5.2c.8-2.2 1.7-4.3 2.7-6.4a5.3 5.3 0 01-1 0 54.8 54.8 0 01-1.8 4.6l-2.4-4.3-1 .1h-1a131.4 131.4 0 013.5 6h1m8.8-4.7l.4-.9a3.4 3.4 0 00-1.7-.6c-1.7-.1-2.7.6-2.8 1.7-.2 2.1 3.2 2 3 3.4 0 .6-.7.9-1.4.8-.8 0-1.4-.5-1.4-1.2h-.3a7.3 7.3 0 01-.4 1.1 4 4 0 001.8.6c1.7.2 3-.5 3.2-1.7.2-2-3.3-2.1-3.1-3.4 0-.5.4-.8 1.3-.7.7 0 1 .4 1.2.9h.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M277.9 211.6s-.7.8-1.3.9c-.5 0-1.1-.5-1.1-.5s-.5.5-1 .6c-.6.1-1.4-.6-1.4-.6l-1 1c-.6 0-1.1-.3-1.1-.3s-.3.4-.7.6h-.4l-.6-.4-.7-.7-.5-.3-.4-1v-.5c-.1-.6.8-1.4 2.2-1.7a3.9 3.9 0 012 0c.5-.5 1.7-.8 3-.8s2.4.3 3 .7a5.5 5.5 0 012.9-.7c1.3 0 2.5.3 3 .8.5-.2 1.2-.2 2 0 1.4.3 2.3 1 2.2 1.7v.5l-.4 1-.6.3-.6.7-.6.3s-.3.2-.4 0c-.4-.1-.7-.5-.7-.5s-.6.4-1 .2c-.5-.2-1-1-1-1s-.9.8-1.4.7c-.6-.1-1-.6-1-.6s-.7.6-1.2.5c-.5-.1-1.2-.9-1.2-.9"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.9 211.6s-.7.8-1.3.9c-.5 0-1.1-.5-1.1-.5s-.5.5-1 .6c-.6.1-1.4-.6-1.4-.6l-1 1c-.6 0-1.1-.3-1.1-.3s-.3.4-.7.6h-.4l-.6-.4-.7-.7-.5-.3-.4-1v-.5c-.1-.6.8-1.4 2.2-1.7a3.9 3.9 0 012 0c.5-.5 1.7-.8 3-.8s2.4.3 3 .7a5.5 5.5 0 012.9-.7c1.3 0 2.5.3 3 .8.5-.2 1.2-.2 2 0 1.4.3 2.3 1 2.2 1.7v.5l-.4 1-.6.3-.6.7-.6.3s-.3.2-.4 0c-.4-.1-.7-.5-.7-.5s-.6.4-1 .2c-.5-.2-1-1-1-1s-.9.8-1.4.7c-.6-.1-1-.6-1-.6s-.7.6-1.2.5c-.5-.1-1.2-.9-1.2-.9z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M276.5 207.6c0-1 .6-2 1.3-2 .8 0 1.3 1 1.3 2s-.5 1.8-1.3 1.8c-.7 0-1.3-.8-1.3-1.9"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M276.5 207.6c0-1 .6-2 1.3-2 .8 0 1.3 1 1.3 2s-.5 1.8-1.3 1.8c-.7 0-1.3-.8-1.3-1.9z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.3 207.6c0-1 .2-1.8.5-1.8.4 0 .7.8.7 1.8s-.3 1.7-.6 1.7c-.4 0-.6-.8-.6-1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.3 207.6c0-1 .2-1.8.5-1.8.4 0 .7.8.7 1.8s-.3 1.7-.6 1.7c-.4 0-.6-.8-.6-1.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M271 215.3a4.5 4.5 0 00-.5-1 27.4 27.4 0 0114.8 0l-.6.8a5.2 5.2 0 00-.3.8 22.9 22.9 0 00-6.6-.8c-2.6 0-5.2.3-6.6.8l-.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M271 215.3a4.5 4.5 0 00-.5-1 27.4 27.4 0 0114.8 0l-.6.8a5.2 5.2 0 00-.3.8 22.9 22.9 0 00-6.6-.8c-2.6 0-5.2.3-6.6.8l-.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.8 217.7c2.4 0 5-.4 5.9-.6.6-.2 1-.5 1-.8 0-.2-.2-.3-.4-.4a24.1 24.1 0 00-6.5-.8c-2.5 0-5 .3-6.4.8-.2 0-.3.2-.4.3 0 .4.3.7 1 .9 1 .2 3.5.6 5.8.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.8 217.7c2.4 0 5-.4 5.9-.6.6-.2 1-.5 1-.8 0-.2-.2-.3-.4-.4a24.1 24.1 0 00-6.5-.8c-2.5 0-5 .3-6.4.8-.2 0-.3.2-.4.3 0 .4.3.7 1 .9 1 .2 3.5.6 5.8.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M283.5 208.4c0-.2.2-.4.4-.4s.5.2.5.4-.2.4-.5.4a.4.4 0 01-.4-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M283.5 208.4c0-.2.2-.4.4-.4s.5.2.5.4-.2.4-.5.4a.4.4 0 01-.4-.4zm-.2-1.4a.4.4 0 01.4-.4c.2 0 .4.1.4.4s-.2.4-.4.4a.4.4 0 01-.4-.4zm-1.1-1c0-.2.2-.3.4-.3s.4.1.4.4c0 .2-.2.4-.4.4a.4.4 0 01-.4-.5zm-1.4-.4c0-.2.2-.4.4-.4.3 0 .5.2.5.4s-.2.4-.4.4-.5-.2-.5-.4zm-1.4 0c0-.2.2-.3.5-.3s.4.1.4.4c0 .2-.2.4-.4.4a.4.4 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinecap: "round",
      strokeWidth: ".3",
      d: "M287.8 211.2l.2-1a2.7 2.7 0 00-2.7-2.8c-.5 0-1 .1-1.3.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M283 209.2l.2-.8c0-1.1-1.1-2-2.5-2-.6 0-1.2.2-1.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M288.2 210c0-.3.2-.5.4-.5s.4.2.4.4c0 .3-.2.4-.4.4s-.4-.1-.4-.4zm-.2-1.6c0-.2.2-.4.4-.4a.4.4 0 01.5.4c0 .2-.2.4-.4.4-.3 0-.5-.2-.5-.4zm-1-1.1a.4.4 0 01.5-.4c.2 0 .4.1.4.4a.4.4 0 01-.4.4.4.4 0 01-.5-.4zm-1.3-.7c0-.2.2-.4.5-.4s.4.2.4.4c0 .3-.2.5-.4.5a.4.4 0 01-.5-.5zm-1.4.1c0-.2.2-.4.5-.4s.4.2.4.4-.2.4-.4.4-.5-.2-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M285.3 213.2l-.5-.5s-.6.3-1.3.2c-.6 0-.9-1-.9-1s-.7.7-1.3.7c-.7 0-1-.6-1-.6s-.7.5-1.3.4c-.6 0-1.2-.8-1.2-.8s-.6.8-1.2.8c-.6.1-1-.5-1-.5s-.3.6-1.1.7-1.4-.6-1.4-.6-.4.7-1 1c-.5 0-1.2-.4-1.2-.4l-.1.5-.3.1.1.5a27 27 0 017.3-.9c2.8 0 5.4.4 7.3 1l.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M285.3 213.2l-.5-.5s-.6.3-1.3.2c-.6 0-.9-1-.9-1s-.7.7-1.3.7c-.7 0-1-.6-1-.6s-.7.5-1.3.4c-.6 0-1.2-.8-1.2-.8s-.6.8-1.2.8c-.6.1-1-.5-1-.5s-.3.6-1.1.7-1.4-.6-1.4-.6-.4.7-1 1c-.5 0-1.2-.4-1.2-.4l-.1.5-.3.1.1.5a27 27 0 017.3-.9c2.8 0 5.4.4 7.3 1l.2-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M271.3 208.4c0-.2.2-.4.4-.4s.4.2.4.4a.4.4 0 01-.4.4.4.4 0 01-.4-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M271.3 208.4c0-.2.2-.4.4-.4s.4.2.4.4a.4.4 0 01-.4.4.4.4 0 01-.4-.4zm.2-1.4c0-.3.2-.4.4-.4s.5.1.5.4-.2.4-.5.4a.4.4 0 01-.4-.4zm1-1c0-.2.3-.3.5-.3s.5.1.5.4c0 .2-.2.4-.5.4a.4.4 0 01-.4-.5zm1.4-.4c0-.2.2-.4.5-.4s.4.2.4.4-.2.4-.4.4-.5-.2-.5-.4zm1.4 0c0-.2.2-.3.5-.3.2 0 .4.1.4.4 0 .2-.2.4-.4.4a.4.4 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinecap: "round",
      strokeWidth: ".3",
      d: "M267.8 211.2a2.8 2.8 0 01-.2-1 2.7 2.7 0 012.7-2.8c.5 0 1 .1 1.4.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M272.7 209.2a1.7 1.7 0 01-.3-.8c0-1 1.2-2 2.6-2a3 3 0 011.5.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M266.6 210c0-.3.2-.5.4-.5.3 0 .4.2.4.4a.4.4 0 01-.4.4c-.2 0-.4-.1-.4-.4zm.1-1.6c0-.2.3-.4.5-.4s.4.2.4.4-.2.4-.4.4-.4-.2-.4-.4zm1-1.1c0-.3.2-.4.5-.4a.4.4 0 01.4.4.4.4 0 01-.4.4.4.4 0 01-.5-.4zm1.3-.7c0-.2.2-.4.5-.4.2 0 .4.2.4.4 0 .3-.2.5-.4.5a.4.4 0 01-.5-.5zm1.4.1c0-.2.2-.4.5-.4a.4.4 0 01.4.4.4.4 0 01-.4.4c-.3 0-.5-.2-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.9 210.7h.2a1 1 0 000 .4c0 .6.5 1 1 1a1 1 0 001-.7l.2-.3v.4c.1.5.6.8 1.1.8.6 0 1-.4 1-1a.7.7 0 000-.1l.4-.4.2.5a1 1 0 00-.1.4 1 1 0 001 1c.4 0 .7-.2.9-.5l.2-.2v.3c0 .3.1.6.4.7 0 0 .4 0 1-.4s.7-.7.7-.7v.4s-.5.8-1 1c-.2.2-.5.4-.8.3-.3 0-.6-.3-.7-.6a1.5 1.5 0 01-.7.2c-.6 0-1.2-.3-1.4-.8a1.5 1.5 0 01-1.1.5c-.5 0-1-.2-1.2-.6a1.5 1.5 0 01-1 .4c-.6 0-1-.2-1.4-.6-.2.4-.7.6-1.2.6-.4 0-.8-.1-1-.4a1.6 1.6 0 01-1.3.6c-.4 0-.8-.2-1.1-.5-.2.5-.8.8-1.4.8-.2 0-.5 0-.7-.2-.1.3-.4.6-.7.6-.3 0-.6 0-.9-.2a4.2 4.2 0 01-1-1l.1-.5.8.7c.5.4.9.4.9.4.3 0 .4-.4.4-.7v-.3l.2.2c.2.3.5.5.9.5a1 1 0 001-1 1 1 0 000-.4v-.5l.4.4v.1c0 .6.5 1 1 1 .6 0 1-.3 1.1-.9v-.3l.2.3c.2.4.6.7 1 .7.6 0 1.1-.4 1.1-1a1 1 0 000-.3h.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.9 210.7h.2a1 1 0 000 .4c0 .6.5 1 1 1a1 1 0 001-.7l.2-.3v.4c.1.5.6.8 1.1.8.6 0 1-.4 1-1a.7.7 0 000-.1l.4-.4.2.5a1 1 0 00-.1.4 1 1 0 001 1c.4 0 .7-.2.9-.5l.2-.2v.3c0 .3.1.6.4.7 0 0 .4 0 1-.4s.7-.7.7-.7v.4s-.5.8-1 1c-.2.2-.5.4-.8.3-.3 0-.6-.3-.7-.6a1.5 1.5 0 01-.7.2c-.6 0-1.2-.3-1.4-.8a1.5 1.5 0 01-1.1.5c-.5 0-1-.2-1.2-.6a1.5 1.5 0 01-1 .4c-.6 0-1-.2-1.4-.6-.2.4-.7.6-1.2.6-.4 0-.8-.1-1-.4a1.6 1.6 0 01-1.3.6c-.4 0-.8-.2-1.1-.5-.2.5-.8.8-1.4.8-.2 0-.5 0-.7-.2-.1.3-.4.6-.7.6-.3 0-.6 0-.9-.2a4.2 4.2 0 01-1-1l.1-.5.8.7c.5.4.9.4.9.4.3 0 .4-.4.4-.7v-.3l.2.2c.2.3.5.5.9.5a1 1 0 001-1 1 1 0 000-.4v-.5l.4.4v.1c0 .6.5 1 1 1 .6 0 1-.3 1.1-.9v-.3l.2.3c.2.4.6.7 1 .7.6 0 1.1-.4 1.1-1a1 1 0 000-.3h.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.8 213.3c-2.9 0-5.5.4-7.3 1l-.3-.2.1-.3c2-.6 4.6-1 7.5-1 3 0 5.7.4 7.6 1 0 0 .2.2.1.3l-.3.2a27 27 0 00-7.4-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.8 213.3c-2.9 0-5.5.4-7.3 1l-.3-.2.1-.3c2-.6 4.6-1 7.5-1 3 0 5.7.4 7.6 1 0 0 .2.2.1.3l-.3.2a27 27 0 00-7.4-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M275 214.4c0-.3.2-.4.5-.4a.4.4 0 01.4.4.4.4 0 01-.4.4c-.3 0-.5-.2-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M275 214.4c0-.3.2-.4.5-.4a.4.4 0 01.4.4.4.4 0 01-.4.4c-.3 0-.5-.2-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M277.9 214.5h-1c-.1 0-.3 0-.3-.3l.3-.3h2a.3.3 0 01.2.3.3.3 0 01-.3.3h-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.9 214.5h-1c-.1 0-.3 0-.3-.3l.3-.3h2a.3.3 0 01.2.3.3.3 0 01-.3.3h-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      d: "M273.2 214.9h-.6a.3.3 0 01-.4-.2.3.3 0 01.3-.3l.6-.1.7-.1c.2 0 .3 0 .4.2a.3.3 0 01-.3.4h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M273.2 214.9h-.6a.3.3 0 01-.4-.2.3.3 0 01.3-.3l.6-.1.7-.1c.2 0 .3 0 .4.2a.3.3 0 01-.3.4h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M270.5 215.3l.3-.4h.7l-.4.6-.6-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M270.5 215.3l.3-.4h.7l-.4.6-.6-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M279.8 214.4c0-.3.2-.4.4-.4.3 0 .5.1.5.4 0 .2-.2.4-.5.4a.4.4 0 01-.4-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M279.8 214.4c0-.3.2-.4.4-.4.3 0 .5.1.5.4 0 .2-.2.4-.5.4a.4.4 0 01-.4-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      d: "M282.5 214.9h.7a.3.3 0 00.3-.2.3.3 0 00-.2-.3l-.7-.1-.7-.1c-.2 0-.3 0-.4.2 0 .2.1.3.3.4h.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M282.5 214.9h.7a.3.3 0 00.3-.2.3.3 0 00-.2-.3l-.7-.1-.7-.1c-.2 0-.3 0-.4.2 0 .2.1.3.3.4h.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M285.1 215.4l-.2-.5h-.7l.3.6.6-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M285.1 215.4l-.2-.5h-.7l.3.6.6-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M277.8 217.1a25 25 0 01-6-.6 25.4 25.4 0 016-.7c2.4 0 4.5.3 6.1.7-1.6.4-3.7.6-6 .6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M277.8 217.1a25 25 0 01-6-.6 25.4 25.4 0 016-.7c2.4 0 4.5.3 6.1.7-1.6.4-3.7.6-6 .6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M285.2 212l-.1-.3c-.2 0-.3 0-.4.2l.1.4c.2 0 .3 0 .4-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M285.2 212l-.1-.3c-.2 0-.3 0-.4.2l.1.4c.2 0 .3 0 .4-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M280.6 211.2c0-.2-.1-.4-.3-.4 0 0-.2.1-.2.3 0 .2 0 .4.2.4l.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M280.6 211.2c0-.2-.1-.4-.3-.4 0 0-.2.1-.2.3 0 .2 0 .4.2.4l.3-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M275.2 211.2c0-.2 0-.4.2-.4l.3.3-.2.4c-.2 0-.3-.2-.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M275.2 211.2c0-.2 0-.4.2-.4l.3.3-.2.4c-.2 0-.3-.2-.3-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M270.5 212l.1-.3c.2 0 .3 0 .4.2l-.1.4c-.2 0-.3 0-.4-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M270.5 212l.1-.3c.2 0 .3 0 .4.2l-.1.4c-.2 0-.3 0-.4-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.8 208.5l-.8.5.6 1.3.2.1.3-.1.6-1.3-.9-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.8 208.5l-.8.5.6 1.3.2.1.3-.1.6-1.3-.9-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M276 210.5l.4.5 1.3-.4.1-.2-.1-.2-1.3-.3-.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M276 210.5l.4.5 1.3-.4.1-.2-.1-.2-1.3-.3-.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M279.6 210.5l-.3.5-1.3-.4-.1-.2v-.2l1.4-.3.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M279.6 210.5l-.3.5-1.3-.4-.1-.2v-.2l1.4-.3.4.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M272.5 209l-.7.7.9 1 .2.1.2-.1.2-1.3-.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M272.5 209l-.7.7.9 1 .2.1.2-.1.2-1.3-.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M271.1 211.2l.5.5 1.2-.6v-.2l-.1-.2-1.3-.1-.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M271.1 211.2l.5.5 1.2-.6v-.2l-.1-.2-1.3-.1-.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M274.7 210.5l-.3.6h-1.3l-.2-.2.1-.3 1.2-.6.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M274.7 210.5l-.3.6h-1.3l-.2-.2.1-.3 1.2-.6.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M269.8 211.4v.6l-1.4.2-.2-.1v-.2l1-.9.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M269.8 211.4v.6l-1.4.2-.2-.1v-.2l1-.9.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M272.4 210.9c0-.3.2-.5.5-.5a.5.5 0 01.5.5.5.5 0 01-.5.4.5.5 0 01-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M272.4 210.9c0-.3.2-.5.5-.5a.5.5 0 01.5.5.5.5 0 01-.5.4.5.5 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M283.2 209l.7.7-.9 1-.2.1-.1-.1-.3-1.3.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M283.2 209l.7.7-.9 1-.2.1-.1-.1-.3-1.3.8-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M284.6 211.2l-.5.5-1.2-.6v-.2l.1-.2 1.3-.1.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M284.6 211.2l-.5.5-1.2-.6v-.2l.1-.2 1.3-.1.3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M281 210.5l.3.6h1.3l.2-.2-.1-.3-1.2-.6-.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M281 210.5l.3.6h1.3l.2-.2-.1-.3-1.2-.6-.5.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M285.7 211.4v.6l1.4.2.2-.1v-.2l-1-.9-.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M285.7 211.4v.6l1.4.2.2-.1v-.2l-1-.9-.6.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277.4 210.4c0-.2.2-.4.5-.4.2 0 .4.2.4.4 0 .3-.2.5-.4.5a.5.5 0 01-.5-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M277.4 210.4c0-.2.2-.4.5-.4.2 0 .4.2.4.4 0 .3-.2.5-.4.5a.5.5 0 01-.5-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M282.3 210.9c0-.3.3-.5.5-.5.3 0 .5.2.5.5s-.2.4-.5.4a.5.5 0 01-.5-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M282.3 210.9c0-.3.3-.5.5-.5.3 0 .5.2.5.5s-.2.4-.5.4a.5.5 0 01-.5-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M277 205.4c0-.5.4-.8.8-.8s1 .3 1 .8-.5.8-1 .8a.9.9 0 01-.8-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M278.5 205.1v.6H277v-.6h.4v-1.3h-.5v-.5h.5v-.6h.6v.6h.6v.6h-.6v1.2h.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M278.5 205.1v.6H277v-.6h.4v-1.3h-.5v-.5h.5v-.6h.6v.6h.6v.6h-.6v1.2h.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M279 205.1v.6h-2.4v-.6h1v-1.3h-.7v-.5h.6v-.6h.6v.6h.6v.6h-.6v1.2h1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M278.1 204.6c.4 0 .6.4.6.8 0 .5-.4.8-.9.8a.9.9 0 01-.8-.8c0-.4.2-.7.6-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M268 212.2l-.6-.7a2.3 2.3 0 00-.7-.3c0-.1.3-.3.6-.3.2 0 .3 0 .4.2v-.2s.3 0 .4.3v1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M268 212.2l-.6-.7a2.3 2.3 0 00-.7-.3c0-.1.3-.3.6-.3.2 0 .3 0 .4.2v-.2s.3 0 .4.3v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M268 212c.1-.2.4-.2.5 0 .2.1.3.3.1.5l-.5-.1c-.1-.1-.2-.4 0-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M268 212c.1-.2.4-.2.5 0 .2.1.3.3.1.5l-.5-.1c-.1-.1-.2-.4 0-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M287.5 212.2l.6-.7c.2-.2.7-.3.7-.3 0-.1-.3-.3-.6-.3a.6.6 0 00-.4.2v-.2s-.3 0-.4.3v.7l.1.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M287.5 212.2l.6-.7c.2-.2.7-.3.7-.3 0-.1-.3-.3-.6-.3a.6.6 0 00-.4.2v-.2s-.3 0-.4.3v.7l.1.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M287.5 212c-.1-.2-.3-.2-.5 0-.2.1-.2.3-.1.5l.5-.1c.2-.1.2-.4.1-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M287.5 212c-.1-.2-.3-.2-.5 0-.2.1-.2.3-.1.5l.5-.1c.2-.1.2-.4.1-.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M267.2 223h21.4v-5.5h-21.4v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M267.2 223h21.4v-5.5h-21.4v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M286.3 226.8a1 1 0 00-.4 0h-16.5c.6-.2 1-.7 1-1.2 0-.6-.4-1.1-1-1.3h17-.1c-.6.2-1 .7-1 1.3 0 .5.4 1 1 1.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M286.3 226.8a1 1 0 00-.4 0h-16.5c.6-.2 1-.7 1-1.2 0-.6-.4-1.1-1-1.3h17-.1c-.6.2-1 .7-1 1.3 0 .5.4 1 1 1.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M269.9 226.8h16c.6 0 1 .3 1 .7 0 .4-.4.8-1 .8h-16c-.6 0-1-.4-1-.8s.5-.8 1-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M269.9 226.8h16c.6 0 1 .3 1 .7 0 .4-.4.8-1 .8h-16c-.6 0-1-.4-1-.8s.5-.8 1-.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M269.9 223h16c.6 0 1 .4 1 .7 0 .4-.4.6-1 .6h-16c-.6 0-1-.2-1-.6 0-.3.4-.6 1-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M269.9 223h16c.6 0 1 .4 1 .7 0 .4-.4.6-1 .6h-16c-.6 0-1-.2-1-.6 0-.3.4-.6 1-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M263 317.4c1.4 0 2.7-.3 3.7-.8a8.4 8.4 0 013.7-.8c1.4 0 2.8.3 3.8.8s2.3.8 3.7.8c1.5 0 2.8-.3 3.8-.8a8.4 8.4 0 013.6-.8 8 8 0 013.7.8c1 .5 2.4.8 3.8.8v2.4a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.8c-1.4 0-2.7.3-3.6.8-1 .5-2.3.9-3.8.9a8 8 0 01-3.7-.9 8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.9-3.8.9v-2.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M263 317.4c1.4 0 2.7-.3 3.7-.8a8.4 8.4 0 013.7-.8c1.4 0 2.8.3 3.8.8s2.3.8 3.7.8c1.5 0 2.8-.3 3.8-.8a8.4 8.4 0 013.6-.8 8 8 0 013.7.8c1 .5 2.4.8 3.8.8v2.4a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.8c-1.4 0-2.7.3-3.6.8-1 .5-2.3.9-3.8.9a8 8 0 01-3.7-.9 8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.9-3.8.9v-2.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M263 319.8c1.4 0 2.7-.4 3.7-.9s2.3-.8 3.7-.8c1.4 0 2.8.3 3.8.8s2.3.9 3.7.9a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.8c1.5 0 2.8.3 3.7.8 1 .5 2.4.9 3.8.9v2.3a8.3 8.3 0 01-3.8-.9 8.1 8.1 0 00-3.7-.7c-1.4 0-2.7.2-3.6.7-1 .5-2.3.9-3.8.9a7 7 0 01-3.7-.9c-1-.4-2.3-.7-3.8-.7a8.3 8.3 0 00-3.7.7 8.1 8.1 0 01-3.8.9v-2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M263 319.8c1.4 0 2.7-.4 3.7-.9s2.3-.8 3.7-.8c1.4 0 2.8.3 3.8.8s2.3.9 3.7.9a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.8c1.5 0 2.8.3 3.7.8 1 .5 2.4.9 3.8.9v2.3a8.3 8.3 0 01-3.8-.9 8.1 8.1 0 00-3.7-.7c-1.4 0-2.7.2-3.6.7-1 .5-2.3.9-3.8.9a7 7 0 01-3.7-.9c-1-.4-2.3-.7-3.8-.7a8.3 8.3 0 00-3.7.7 8.1 8.1 0 01-3.8.9v-2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M263 322c1.4 0 2.7-.2 3.7-.8 1-.4 2.3-.7 3.7-.7 1.4 0 2.8.2 3.8.7s2.3.9 3.7.9a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.8 8 8 0 013.7.8c1 .5 2.4.9 3.8.9v2.3a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.7c-1.4 0-2.7.3-3.6.7-1 .6-2.3.9-3.8.9-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.8-3.8.8V322"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M263 322c1.4 0 2.7-.2 3.7-.8 1-.4 2.3-.7 3.7-.7 1.4 0 2.8.2 3.8.7s2.3.9 3.7.9a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.8 8 8 0 013.7.8c1 .5 2.4.9 3.8.9v2.3a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.7c-1.4 0-2.7.3-3.6.7-1 .6-2.3.9-3.8.9-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.8-3.8.8V322"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M263 326.7a8 8 0 003.7-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.8.3 3.8.8s2.3.8 3.7.8c1.5 0 2.8-.3 3.8-.9a8.4 8.4 0 013.6-.7c1.5 0 2.8.3 3.7.8a8.3 8.3 0 003.8.8v-2.3a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.7c-1.4 0-2.7.3-3.6.7-1 .5-2.3.9-3.8.9-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.8-3.8.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M263 326.7a8 8 0 003.7-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.8.3 3.8.8s2.3.8 3.7.8c1.5 0 2.8-.3 3.8-.9a8.4 8.4 0 013.6-.7c1.5 0 2.8.3 3.7.8a8.3 8.3 0 003.8.8v-2.3a8.3 8.3 0 01-3.8-.9 8.2 8.2 0 00-3.7-.7c-1.4 0-2.7.3-3.6.7-1 .5-2.3.9-3.8.9-1.4 0-2.8-.3-3.7-.8a8.4 8.4 0 00-3.8-.8 8.3 8.3 0 00-3.7.8c-1 .5-2.3.8-3.8.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M263 329a8.1 8.1 0 003.7-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.8.3 3.8.8s2.3.8 3.7.8a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.7c1.5 0 2.8.3 3.7.8 1 .5 2.4.8 3.8.8v-2.3a8.3 8.3 0 01-3.8-.8 8.2 8.2 0 00-3.7-.8 8.4 8.4 0 00-3.6.7 8.2 8.2 0 01-3.8.9c-1.4 0-2.8-.3-3.7-.8-1-.5-2.3-.8-3.8-.8-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M263 329a8.1 8.1 0 003.7-.8c1-.5 2.3-.8 3.7-.8 1.4 0 2.8.3 3.8.8s2.3.8 3.7.8a8.2 8.2 0 003.8-.9 8.4 8.4 0 013.6-.7c1.5 0 2.8.3 3.7.8 1 .5 2.4.8 3.8.8v-2.3a8.3 8.3 0 01-3.8-.8 8.2 8.2 0 00-3.7-.8 8.4 8.4 0 00-3.6.7 8.2 8.2 0 01-3.8.9c-1.4 0-2.8-.3-3.7-.8-1-.5-2.3-.8-3.8-.8-1.4 0-2.7.3-3.7.8s-2.3.8-3.8.8v2.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M286.3 308l-.1.5c0 1.5 1.2 2.6 2.7 2.6h-22c1.5 0 2.7-1.2 2.7-2.6l-.1-.5h16.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M286.3 308l-.1.5c0 1.5 1.2 2.6 2.7 2.6h-22c1.5 0 2.7-1.2 2.7-2.6l-.1-.5h16.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M269.9 306.5h16c.6 0 1 .3 1 .8 0 .4-.4.7-1 .7h-16c-.6 0-1-.3-1-.8 0-.4.5-.7 1-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M269.9 306.5h16c.6 0 1 .3 1 .8 0 .4-.4.7-1 .7h-16c-.6 0-1-.3-1-.8 0-.4.5-.7 1-.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M266.9 316.7h22V311h-22v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M266.9 316.7h22V311h-22v5.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M290.6 286.7c2.1 1.2 3.6 2.5 3.4 3.2-.1.6-.8 1-1.8 1.6-1.6 1.1-2.5 3-1.8 4a5.5 5.5 0 01.2-8.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M290.6 286.7c2.1 1.2 3.6 2.5 3.4 3.2-.1.6-.8 1-1.8 1.6-1.6 1.1-2.5 3-1.8 4a5.5 5.5 0 01.2-8.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M270.1 305.6h15.6V229h-15.6v76.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M281.4 229.1v76.3m1.8-76.3v76.3m-13 .2h15.5V229h-15.6v76.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M254.2 257.7a49.6 49.6 0 0123.3-2c9.3 1.6 16.4 5.3 15.9 8.4v.2l3.5-8.2c.6-3.3-7.3-7.5-17.6-9.2a53.5 53.5 0 00-9.2-.7c-6.7 0-12.4.8-15.9 2.1v9.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M254.2 257.7a49.6 49.6 0 0123.3-2c9.3 1.6 16.4 5.3 15.9 8.4v.2l3.5-8.2c.6-3.3-7.3-7.5-17.6-9.2a53.5 53.5 0 00-9.2-.7c-6.7 0-12.4.8-15.9 2.1v9.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M285.7 267.3c4.4-.3 7.3-1.4 7.7-3.2.2-1.5-1.2-3-3.8-4.5-1.2.1-2.5.3-3.9.3v7.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M285.7 267.3c4.4-.3 7.3-1.4 7.7-3.2.2-1.5-1.2-3-3.8-4.5-1.2.1-2.5.3-3.9.3v7.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M270 261.5a13 13 0 00-5.7 1.9v.2c-.5 1 1.8 3 5.8 5.4v-7.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M270 261.5a13 13 0 00-5.7 1.9v.2c-.5 1 1.8 3 5.8 5.4v-7.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M295.4 282c.4-1.2-3.8-3.6-9.7-5.8-2.8-1-5-2-7.8-3.2-8.3-3.7-14.4-7.9-13.6-9.4v-.2c-.4.4-1 8-1 8-.8 1.3 4.8 5.5 12.4 9.1 2.4 1.2 7.6 3 10 4 4.3 1.4 8.7 4.3 8.3 5.3l1.4-7.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M295.4 282c.4-1.2-3.8-3.6-9.7-5.8-2.8-1-5-2-7.8-3.2-8.3-3.7-14.4-7.9-13.6-9.4v-.2c-.4.4-1 8-1 8-.8 1.3 4.8 5.5 12.4 9.1 2.4 1.2 7.6 3 10 4 4.3 1.4 8.7 4.3 8.3 5.3l1.4-7.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M263.9 254.4c.6-2.3 1.4-4.4 2.1-6.6h-.5a5.2 5.2 0 01-.5.1 52.8 52.8 0 01-1.4 4.8c-1-1.4-2-2.7-2.7-4.1l-1 .2h-1a131.3 131.3 0 014 5.7h.5l.5-.1m6-6.6h-1a8 8 0 01-.8 0v6.2h4.2v-.7h-2.6l.1-5.5m6.8 1l2 .3v-.7l-5.8-.5v.8a19.3 19.3 0 012 0l-.4 5.6h1.6l.5-5.4m2.4 6c.3 0 .5 0 .8.2l.8.2.7-2.9.6 1.2.8 2.1 1 .2c.4 0 .7.2 1 .3l-.3-.7c-.4-1-1-1.9-1.3-2.9 1 0 1.9-.3 2.1-1.2.1-.6 0-1-.7-1.5-.4-.3-1.2-.4-1.7-.5l-2.4-.5-1.4 6m3-5.2c.7.2 1.5.3 1.5 1v.5c-.3.9-1 1.2-2 .9l.5-2.4m8 7l-.2 2 .8.5.9.5.5-7a3.4 3.4 0 01-.7-.3l-6.1 3.8.5.3.4.2 1.7-1.2 2.3 1.3zm-1.7-1.5l2-1.4-.2 2.3-1.8-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M182.2 192.4c0-1 1-2 2-2s2.2 1 2.2 2c0 1.1-1 2-2.1 2a2 2 0 01-2.1-2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M205.7 175.4c6.3 0 12 1 15.7 2.4a31.7 31.7 0 0014.6 2.3c2.7 0 6.5.8 10.3 2.4a27.3 27.3 0 017.4 4.7l-1.5 1.4-.4 3.8-4.1 4.7-2 1.8-5 3.9-2.5.2-.7 2.1-31.6-3.7-31.7 3.7-.8-2.1-2.5-.2-4.9-4-2-1.7-4.1-4.7-.5-3.8-1.5-1.4a27.6 27.6 0 017.5-4.7 26 26 0 0110.2-2.4c2 .2 4.2.1 6.6-.2a30 30 0 008-2c3.7-1.5 9-2.5 15.5-2.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206.2 217.1c-11.8 0-22.4-1.4-29.9-3.6a1.1 1.1 0 01-.8-1.2c0-.5.3-1 .8-1.2a109 109 0 0129.9-3.6c11.7 0 22.3 1.4 29.8 3.6a1.3 1.3 0 010 2.4c-7.5 2.2-18 3.6-29.8 3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M206.1 215.6c-10.6 0-20.2-1.2-27.5-3.1 7.3-2 16.9-3 27.5-3.1a115 115 0 0127.6 3c-7.3 2-17 3.2-27.6 3.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M206.9 215.7v-6.3m-1.7 6.3v-6.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M203.6 215.7v-6.3m-1.6 6.3v-6.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M200.6 215.7v-6.3m-2.8 5.9v-5.7m1.3 5.8v-6m-3.8 5.6v-5.2m1.3 5.4v-5.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M192 214.8V210m1 4.7V210m1.2 5v-5m-3.4 4.7v-4.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M189.7 214.5v-4.2m-1.2 4.1v-4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".6",
      d: "M186 214v-3m1.3 3.2v-3.5m-2.5 3.1V211"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".7",
      d: "M183.7 213.6v-2.3m-1.3 2v-1.8m-1.2 1.6v-1.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".9",
      d: "M179.8 212.8v-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M213.7 215.3v-5.8m-2.9 6v-6.1m-2.1 6.2v-6.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206 207.4a108 108 0 00-30 3.9c.6-.3.5-1-.3-3-1-2.5-2.4-2.4-2.4-2.4 8.3-2.5 20-4 32.8-4a123 123 0 0133 4s-1.5-.1-2.5 2.3c-.8 2-.8 2.8-.2 3-7.5-2.2-18.4-3.7-30.3-3.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206.1 201.9c-12.9 0-24.5 1.5-32.8 4a1 1 0 01-1.3-.6 1 1 0 01.7-1.3 121 121 0 0133.4-4.2c13.2 0 25.2 1.7 33.5 4.2.6.2.9.8.7 1.3-.2.5-.8.8-1.3.6-8.4-2.5-20-4-32.9-4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".4",
      d: "M206.1 215.6c-10.6 0-20.2-1.2-27.5-3.1 7.3-2 16.9-3 27.5-3.1a115 115 0 0127.6 3c-7.3 2-17 3.2-27.6 3.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M197 204.8c0-.5.4-1 1-1 .5 0 1 .5 1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206.1 205.6H203a1 1 0 010-2h6.4c.5 0 1 .5 1 1s-.5 1-1 1h-3.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M190.3 206.5l-2.3.2c-.6.1-1-.3-1.2-.8a1 1 0 011-1.1l2.2-.3 2.4-.3c.5 0 1 .3 1.1.9.1.5-.3 1-.9 1l-2.3.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M181 206.7c0-.6.5-1 1.1-1 .6 0 1 .4 1 1 0 .5-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M174 208.5l1.2-1.6 3.3.4-2.6 2-1.8-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M222 206.5l2.3.2c.5.1 1-.3 1.1-.8a1 1 0 00-.9-1.1l-2.2-.3-2.4-.3a1 1 0 00-1.1.9c-.1.5.3 1 .9 1l2.3.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M213.3 204.8c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1m15.8 1.9c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1 0 .5-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M238.2 208.5l-1.1-1.6-3.3.4 2.6 2 1.8-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M177.3 212.8c7.4-2.1 17.6-3.4 28.8-3.4 11.3 0 21.4 1.3 28.9 3.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M182.3 183.8l1.4 1 2-3.2a7.4 7.4 0 01-3.6-7.2c.2-4.1 5.2-7.6 11.7-7.6 3.3 0 6.3 1 8.5 2.4 0-.6 0-1.2.2-1.8a17.4 17.4 0 00-8.7-2.1c-7.4 0-13.2 4.1-13.5 9.1a8.9 8.9 0 003 7.6l-1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M182.3 183.8l1.4 1 2-3.2a7.4 7.4 0 01-3.6-7.2c.2-4.1 5.2-7.6 11.7-7.6 3.3 0 6.3 1 8.5 2.4 0-.6 0-1.2.2-1.8a17.4 17.4 0 00-8.7-2.1c-7.4 0-13.2 4.1-13.5 9.1a8.9 8.9 0 003 7.6l-1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M182.4 183.8a9.3 9.3 0 01-4-7.3c0-3.2 2-6.1 5.3-8a8.5 8.5 0 00-3.4 6.8 8.9 8.9 0 003 6.7l-.9 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M182.4 183.8a9.3 9.3 0 01-4-7.3c0-3.2 2-6.1 5.3-8a8.5 8.5 0 00-3.4 6.8 8.9 8.9 0 003 6.7l-.9 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M160.1 187.1a8.8 8.8 0 01-2.3-5.9c0-1.3.3-2.6 1-3.8 2-4.2 8.4-7.2 16-7.2 2 0 4 .2 5.9.6l-1 1.4a25.5 25.5 0 00-4.9-.4c-7 0-12.8 2.7-14.5 6.3a7 7 0 00-.7 3.1 7.3 7.3 0 002.7 5.6l-2.6 4.1-1.3-1 1.7-2.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M160.1 187.1a8.8 8.8 0 01-2.3-5.9c0-1.3.3-2.6 1-3.8 2-4.2 8.4-7.2 16-7.2 2 0 4 .2 5.9.6l-1 1.4a25.5 25.5 0 00-4.9-.4c-7 0-12.8 2.7-14.5 6.3a7 7 0 00-.7 3.1 7.3 7.3 0 002.7 5.6l-2.6 4.1-1.3-1 1.7-2.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M162.7 173.3a10.5 10.5 0 00-4 4.1 8.6 8.6 0 00-.9 3.8c0 2.3.9 4.3 2.3 5.9l-1.5 2.5a10.4 10.4 0 01-2.3-6.5c0-4 2.5-7.5 6.4-9.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M162.7 173.3a10.5 10.5 0 00-4 4.1 8.6 8.6 0 00-.9 3.8c0 2.3.9 4.3 2.3 5.9l-1.5 2.5a10.4 10.4 0 01-2.3-6.5c0-4 2.5-7.5 6.4-9.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M206 164.4c1.7 0 3.2 1.1 3.5 2.6.3 1.4.4 2.9.4 4.5v1.1c.1 3.3.6 6.3 1.3 8.1l-5.2 5-5.2-5c.7-1.8 1.2-4.8 1.3-8.1v-1.1c0-1.6.2-3.1.4-4.5.3-1.5 1.8-2.6 3.5-2.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206 164.4c1.7 0 3.2 1.1 3.5 2.6.3 1.4.4 2.9.4 4.5v1.1c.1 3.3.6 6.3 1.3 8.1l-5.2 5-5.2-5c.7-1.8 1.2-4.8 1.3-8.1v-1.1c0-1.6.2-3.1.4-4.5.3-1.5 1.8-2.6 3.5-2.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M206 166c1 0 1.7.6 1.8 1.4.2 1.2.4 2.6.4 4.2v1c.1 3.2.6 6 1.2 7.7l-3.4 3.2-3.4-3.2c.7-1.7 1.1-4.5 1.2-7.7v-1a28.1 28.1 0 01.4-4.2 2 2 0 011.8-1.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206 166c1 0 1.7.6 1.8 1.4.2 1.2.4 2.6.4 4.2v1c.1 3.2.6 6 1.2 7.7l-3.4 3.2-3.4-3.2c.7-1.7 1.1-4.5 1.2-7.7v-1a28.1 28.1 0 01.4-4.2 2 2 0 011.8-1.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M229.7 183.8l-1.3 1-2-3.2a7.4 7.4 0 003.6-6.3 7 7 0 000-.9c-.2-4.1-5.3-7.6-11.7-7.6a15 15 0 00-8.5 2.4 23 23 0 00-.2-1.8 17.4 17.4 0 018.7-2.1c7.4 0 13.2 4.1 13.4 9.1a8.9 8.9 0 01-3 7.6l1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M229.7 183.8l-1.3 1-2-3.2a7.4 7.4 0 003.6-6.3 7 7 0 000-.9c-.2-4.1-5.3-7.6-11.7-7.6a15 15 0 00-8.5 2.4 23 23 0 00-.2-1.8 17.4 17.4 0 018.7-2.1c7.4 0 13.2 4.1 13.4 9.1a8.9 8.9 0 01-3 7.6l1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M229.6 183.8a9.1 9.1 0 004.1-7.3c0-3.2-2.1-6.1-5.3-8a8.5 8.5 0 013.4 6.8 8.9 8.9 0 01-3.2 6.7l1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M229.6 183.8a9.1 9.1 0 004.1-7.3c0-3.2-2.1-6.1-5.3-8a8.5 8.5 0 013.4 6.8 8.9 8.9 0 01-3.2 6.7l1 1.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M252 187.1a8.8 8.8 0 002.2-5.9 8.7 8.7 0 00-.9-3.8c-2-4.2-8.4-7.2-16-7.2a29 29 0 00-6 .6l1 1.4a25.4 25.4 0 015-.4c7 0 12.8 2.7 14.4 6.3.5 1 .7 2 .7 3.1a7.3 7.3 0 01-2.6 5.6l2.5 4.1 1.3-1-1.7-2.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M252 187.1a8.8 8.8 0 002.2-5.9 8.7 8.7 0 00-.9-3.8c-2-4.2-8.4-7.2-16-7.2a29 29 0 00-6 .6l1 1.4a25.4 25.4 0 015-.4c7 0 12.8 2.7 14.4 6.3.5 1 .7 2 .7 3.1a7.3 7.3 0 01-2.6 5.6l2.5 4.1 1.3-1-1.7-2.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M249.3 173.3a10.6 10.6 0 014 4.1 8.7 8.7 0 01.9 3.8 8.8 8.8 0 01-2.3 5.9l1.6 2.5a10.4 10.4 0 002.3-6.5c0-4-2.6-7.5-6.5-9.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M249.3 173.3a10.6 10.6 0 014 4.1 8.7 8.7 0 01.9 3.8 8.8 8.8 0 01-2.3 5.9l1.6 2.5a10.4 10.4 0 002.3-6.5c0-4-2.6-7.5-6.5-9.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M204.2 181.4c0-1 .8-1.8 1.8-1.8s1.9.8 1.9 1.8-.9 1.7-1.9 1.7a1.8 1.8 0 01-1.8-1.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M204.2 181.4c0-1 .8-1.8 1.8-1.8s1.9.8 1.9 1.8-.9 1.7-1.9 1.7a1.8 1.8 0 01-1.8-1.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M204.2 178c0-1 .8-1.8 1.8-1.8s1.9.8 1.9 1.8-.9 1.7-1.9 1.7a1.8 1.8 0 01-1.8-1.7m.4-3.7c0-.7.6-1.3 1.4-1.3.8 0 1.5.6 1.5 1.3 0 .8-.7 1.4-1.5 1.4s-1.4-.6-1.4-1.4m.4-3.3c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1m.2-2.8c0-.5.4-.8.8-.8.5 0 .9.3.9.8 0 .4-.4.8-.9.8a.8.8 0 01-.8-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206.2 191.8l1.2.2a4.6 4.6 0 004.5 6 4.7 4.7 0 004.4-3c.1 0 .5-1.7.7-1.7.2 0 .1 1.8.2 1.7.3 2.3 2.4 3.8 4.7 3.8a4.6 4.6 0 004.7-5l1.5-1.5.7 2a4 4 0 00-.4 1.9 4.4 4.4 0 004.5 4.2c1.6 0 3-.7 3.8-1.9l.9-1.2v1.5c0 1.5.6 2.8 2 3 0 0 1.7.1 4-1.6 2.1-1.7 3.3-3.1 3.3-3.1l.2 1.7s-1.8 2.8-3.8 4c-1 .6-2.7 1.3-4 1-1.4-.2-2.4-1.3-3-2.6a6.7 6.7 0 01-3.3 1 6.5 6.5 0 01-6.1-3.7 7 7 0 01-10.4-.3 7 7 0 01-4.6 1.8 6.9 6.9 0 01-5.7-3 6.9 6.9 0 01-5.7 3 7 7 0 01-4.7-1.8 7 7 0 01-10.4.3 6.5 6.5 0 01-6 3.7 6.7 6.7 0 01-3.4-1c-.6 1.3-1.5 2.4-3 2.7-1.2.2-2.9-.5-4-1.1-2-1.2-3.8-4-3.8-4l.2-1.7s1.2 1.4 3.4 3.1c2.2 1.8 3.9 1.6 3.9 1.6 1.4-.2 2-1.5 2-3v-1.5l1 1.2a4.6 4.6 0 003.7 2c2.5 0 4.5-2 4.5-4.3a4 4 0 00-.4-2l.8-1.9 1.5 1.5a4.4 4.4 0 000 .6c0 2.4 2 4.4 4.6 4.4 2.4 0 4.4-1.5 4.7-3.8 0 0 0-1.6.2-1.7.2 0 .6 1.7.7 1.6a4.7 4.7 0 004.5 3.1 4.6 4.6 0 004.5-6l1.2-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M238.6 197.7c.3-.8 0-1.6-.6-1.8-.5-.2-1.2.3-1.5 1.1-.3.8 0 1.6.6 1.8.5.2 1.2-.3 1.5-1.1m-20.5-4c0-.8-.3-1.6-1-1.6-.5-.1-1 .5-1.2 1.4-.1.8.3 1.5.9 1.6.6 0 1.2-.6 1.3-1.4m-23.9 0c0-.8.4-1.6 1-1.6.6-.1 1.1.5 1.2 1.4.1.8-.3 1.5-.9 1.6-.6 0-1.1-.6-1.2-1.4m-20.6 4c-.2-.8 0-1.6.6-1.8.6-.2 1.2.3 1.5 1.1.3.8 0 1.6-.5 1.8-.6.2-1.3-.3-1.6-1.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M182.7 184a5.1 5.1 0 012.2 2.9s0-.3.6-.6 1-.3 1-.3l-.1 1.3-.3 2.2a7.4 7.4 0 01-.7 1.6 1.9 1.9 0 00-1.5-.4 1.8 1.8 0 00-1.2.9s-.7-.6-1.2-1.3l-1.1-2-.7-1.1s.5-.2 1.1 0c.6 0 .8.2.8.2a4.9 4.9 0 011-3.4m.4 9.8a1.8 1.8 0 01-.6-1c0-.5 0-.9.3-1.2 0 0-.9-.5-1.8-.7-.7-.2-2-.2-2.3-.2h-1l.2.5c.2.5.5.7.5.7a5 5 0 00-3 2 5.3 5.3 0 003.5 1l-.2.8v.6l1-.4c.3-.1 1.5-.5 2-1 .8-.4 1.5-1.1 1.5-1.1m2.7-.5a1.6 1.6 0 00.2-1.1 1.7 1.7 0 00-.6-1l1.4-1.3a10 10 0 012-.9l1.1-.4v.6a5.7 5.7 0 01-.2.8 5 5 0 013.4 1 5 5 0 01-2.9 2 6.4 6.4 0 00.7 1.2h-1c-.4 0-1.6 0-2.3-.2a11 11 0 01-1.8-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M182.2 192.4c0-1 1-2 2-2s2.2 1 2.2 2c0 1.1-1 2-2.1 2a2 2 0 01-2.1-2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M206.1 180.8a5.7 5.7 0 011.9 3.7s.2-.3.9-.5c.7-.3 1.2-.2 1.2-.2l-.5 1.4-.8 2.4a8.2 8.2 0 01-1 1.7 2.1 2.1 0 00-1.7-.7c-.6 0-1.2.3-1.6.7 0 0-.6-.7-1-1.7l-.8-2.4-.5-1.4 1.2.2c.7.2.9.5.9.5 0-1.4.8-2.8 1.8-3.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M204.6 191.8a2 2 0 01-.5-1.2c0-.5.1-1 .4-1.3 0 0-.8-.7-1.8-1-.7-.4-2-.7-2.5-.7l-1.2-.2.2.6.4.9a5.9 5.9 0 00-3.7 1.7c1 .9 2.3 1.6 3.7 1.6l-.4 1-.2.6 1.2-.2c.4-.1 1.8-.4 2.5-.7 1-.4 1.9-1 1.9-1m3 0a1.9 1.9 0 00.1-2.6s.9-.7 1.8-1a8 8 0 012.5-.7l1.2-.3-.1.7-.4.9c1.4 0 2.7.8 3.6 1.7a5.9 5.9 0 01-3.6 1.6 6.9 6.9 0 00.5 1.6l-1.2-.2-2.5-.7c-1-.4-1.8-1-1.8-1m22-8a5.2 5.2 0 00-2.2 3l-.7-.6c-.6-.3-1-.3-1-.3l.2 1.3c0 .3 0 1.3.3 2.2.2 1 .6 1.6.6 1.6a2 2 0 011.5-.4c.6.1 1 .5 1.3.9l1.1-1.3c.6-.8 1-1.7 1.1-2l.7-1.1s-.4-.2-1 0c-.7 0-1 .2-1 .2a4.9 4.9 0 00-1-3.4m-.3 9.8c.3-.3.5-.6.6-1a1.6 1.6 0 00-.2-1.2s.8-.5 1.7-.7c.7-.2 2-.2 2.3-.2h1.1l-.3.5a6.2 6.2 0 01-.4.7 5 5 0 012.9 2 5.3 5.3 0 01-3.5 1l.2.8v.6l-1-.4c-.3-.1-1.4-.5-2-1-.8-.4-1.4-1.1-1.4-1.1m-2.8-.5a1.7 1.7 0 01-.2-1.1c0-.5.3-.8.6-1 0 0-.6-.8-1.4-1.3-.6-.4-1.7-.8-2-.9a171.4 171.4 0 01-1-.4v.6c0 .5.2.8.2.8a5.2 5.2 0 00-3.5 1c.7.9 1.7 1.7 3 2 0 0-.3.2-.5.7l-.3.5h1c.4 0 1.7 0 2.3-.2a11.1 11.1 0 001.8-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M226 192.4c0-1 1-2 2-2s2.1 1 2.1 2a2 2 0 01-2 2 2 2 0 01-2.1-2m23.2 4.4c-.4-.5-1.4-.4-2.2.2-.8.7-1 1.6-.5 2.2.5.5 1.5.4 2.3-.3.7-.6 1-1.6.5-2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M246.3 198l.7-1c.7-.6 1.8-.7 2.3-.2l.1.2s1-2 2.3-2.6c1.3-.7 3.4-.5 3.4-.5a2.8 2.8 0 00-2.9-2.8 3 3 0 00-2.4 1l-.2-1s-1.3.3-1.9 1.8c-.6 1.5 0 3.6 0 3.6s-.3-.9-.7-1.5a8 8 0 00-2.4-1.6l-1.3-.7-.1.5a5 5 0 000 .8 7.9 7.9 0 00-3.7.5 4.7 4.7 0 002.5 2.2l-.8.7a4 4 0 00-.4.5l1.3.2 2.5.2a14.5 14.5 0 001.7-.2m-80.3 0c0-.4-.3-.7-.7-1-.7-.7-1.7-.8-2.2-.3l-.2.3s-1-2-2.3-2.7c-1.2-.7-3.3-.5-3.3-.5a2.8 2.8 0 012.8-2.8c1 0 1.9.4 2.4 1l.2-1s1.3.3 2 1.8c.5 1.5-.1 3.6-.1 3.6s.3-.9.8-1.5a8 8 0 012.4-1.6l1.3-.7v1.3a7.9 7.9 0 013.7.5 4.7 4.7 0 01-2.5 2.2l.8.7.4.5-1.2.2-2.6.2a14.7 14.7 0 01-1.7-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M163 196.8c.6-.5 1.6-.4 2.4.3.7.6 1 1.5.4 2-.5.6-1.5.5-2.2-.2-.8-.6-1-1.6-.5-2m41-6.3c0-1.1.9-2 2-2s2.1.9 2.1 2c0 1-1 2-2 2a2 2 0 01-2.1-2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M201.8 160.6c0-2.2 1.9-4 4.3-4s4.2 1.8 4.2 4-1.9 4-4.3 4a4.1 4.1 0 01-4.2-4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M205 149.3v2.2h-2.4v2.2h2.3v6.3H202l-.2.6c0 .6.1 1.1.3 1.6h7.9c.2-.5.3-1 .3-1.6l-.2-.6h-2.8v-6.3h2.3v-2.2h-2.3v-2.2h-2.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M206.5 330.6a82 82 0 01-35.5-8.2 22.7 22.7 0 01-12.8-20.4v-32h96.4v32a22.7 22.7 0 01-12.8 20.4 81 81 0 01-35.3 8.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M206.5 330.6a82 82 0 01-35.5-8.2 22.7 22.7 0 01-12.8-20.4v-32h96.4v32a22.7 22.7 0 01-12.8 20.4 81 81 0 01-35.3 8.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ccc",
      d: "M206.3 270h48.3v-53.5h-48.3V270z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M206.3 270h48.3v-53.5h-48.3V270z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M206.3 302c0 12.6-10.7 22.9-24 22.9s-24.2-10.3-24.2-23v-32h48.2v32"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M168.6 320.9c1.5.8 3.6 2 5.8 2.6l-.1-54.7h-5.7v52z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".5",
      d: "M158 301.6a24.4 24.4 0 005.5 15v-47.5h-5.4v32.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c7b500",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M179.4 324.7a26.6 26.6 0 005.6 0v-55.9h-5.6v56z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M190 323.5a19 19 0 005.8-2.5v-52.2H190l-.1 54.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M158.1 270h48.2v-53.5H158V270z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M158.1 270h48.2v-53.5H158V270z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M201 316c2.4-2 4.6-6.8 5.4-12.2l.1-35H201l.1 47.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M206.3 302c0 12.6-10.7 22.9-24 22.9s-24.2-10.3-24.2-23v-32h48.2v32"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M254.6 270v32c0 12.6-10.8 22.9-24.1 22.9s-24.2-10.3-24.2-23v-32h48.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M254.6 270v32c0 12.6-10.8 22.9-24.1 22.9s-24.2-10.3-24.2-23v-32h48.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M215.1 294.1l.1.5c0 .6-.5 1-1.1 1a1 1 0 01-1.1-1v-.5h-1.5a2.5 2.5 0 001.8 2.9v3.9h1.6V297a2.6 2.6 0 001.7-1.6h4.4v-1.2h-6m21.8 0v1.2h-4a2.5 2.5 0 01-.3.6l4.6 5.2-1.2 1-4.6-5.3-.2.1v8.7h-1.6V297h-.2l-4.8 5.2-1.2-1 4.7-5.3a2.1 2.1 0 01-.2-.4h-4V294h13zm2.6 0v1.2h4.4c.3.8.9 1.4 1.7 1.6v3.9h1.6V297a2.5 2.5 0 001.8-2.4 2 2 0 000-.5h-1.6l.1.5c0 .6-.5 1-1 1-.7 0-1.2-.4-1.2-1a1 1 0 01.1-.5h-5.9m-6.7 22.1a15.6 15.6 0 003.7-1l.8 1.4a17.6 17.6 0 01-4.3 1.2 2.6 2.6 0 01-2.6 2 2.6 2.6 0 01-2.5-2 17.5 17.5 0 01-4.6-1.2l.8-1.4c1.3.5 2.6.9 4 1a2.5 2.5 0 011.5-1.3v-6.7h1.6v6.7c.7.2 1.3.7 1.6 1.4zm-11-2.2l-.8 1.4a16.6 16.6 0 01-3.6-3.1c-.9.2-1.8 0-2.5-.5a2.4 2.4 0 01-.3-3.5l.1-.1a15.3 15.3 0 01-1.3-4.8h1.7a13.1 13.1 0 001 4c.5 0 1 0 1.4.2l4.1-4.5 1.3 1-4.1 4.5c.5.9.5 2-.1 2.8a15.2 15.2 0 003.1 2.6zm-6-4.8c.3-.4 1-.5 1.5 0s.5 1 .1 1.4a1.2 1.2 0 01-1.6.1 1 1 0 010-1.5zm-2.2-4.5l-1.6-.3-.3-4.3 1.7-.6v2.5c0 1 0 1.8.2 2.7zm1.4-5.3l1.7.4v2.2c0-.8.3 2.1.3 2.1l-1.7.6a14 14 0 01-.3-2.7v-2.6zm5.6 13.7a15.7 15.7 0 004.8 2.6l.4-1.6a13.7 13.7 0 01-4-2l-1.2 1m-.8 1.4a17.4 17.4 0 004.8 2.6l-1.2 1.1a18.7 18.7 0 01-4-2l.4-1.7m2.2-9.4l1.6.7 3-3.3-1-1.4-3.6 4m-1.3-1l-1-1.4 3-3.3 1.6.7-3.6 4m18.1 9.9l.8 1.4a16.7 16.7 0 003.6-3.1c.9.2 1.8 0 2.5-.5a2.4 2.4 0 00.3-3.5l-.1-.1a15 15 0 001.3-4.8h-1.7a13.3 13.3 0 01-1 4 3 3 0 00-1.4.2l-4.1-4.5-1.3 1 4.1 4.5a2.4 2.4 0 00.1 2.8 15 15 0 01-3.1 2.6zm6-4.8a1.2 1.2 0 00-1.5 0 1 1 0 00-.1 1.4 1.2 1.2 0 001.6.1 1 1 0 000-1.5zm2.2-4.5l1.6-.3.3-4.3-1.7-.6v2.5c0 1 0 1.9-.2 2.8zm-1.4-5.3l-1.7.4v2.2c0-.8-.3 2.1-.3 2.1l1.7.6.3-2.7v-2.6m-5.6 13.7a15.7 15.7 0 01-4.8 2.6l-.4-1.6a13.7 13.7 0 004-2l1.2 1m.8 1.4a17.4 17.4 0 01-4.8 2.6l1.2 1.1a18.6 18.6 0 004-2l-.4-1.7m-2.2-9.4l-1.6.7-2.9-3.3 1-1.4 3.5 4m1.3-1l1-1.4-3-3.3-1.6.7 3.6 4m-20.1-8.7l.5 1.6h4.5l.5-1.6h-5.5m21.1 0l-.5 1.6h-4.5l-.5-1.6h5.5m-11.6 21.9c0-.6.5-1 1.1-1a1 1 0 011.1 1c0 .6-.5 1-1 1a1.1 1.1 0 01-1.2-1zm1.9-7.8l1.7-.4v-4.3l-1.7-.5v5.2m-1.6 0l-1.7-.4v-4.3l1.7-.5v5.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M211.5 294.2c.2-1 1-1.6 1.8-2V287h1.6v5.3c.8.3 1.5.9 1.7 1.6h4.4v.3h-6a1.2 1.2 0 00-1-.6c-.4 0-.7.3-1 .6h-1.5m12.2 0v-.3h4.1a2.4 2.4 0 01.2-.3l-5-5.7 1.2-1 5 5.6.2-.1V285h1.6v7.3h.3l4.9-5.5 1.2 1-4.9 5.5.3.6h4v.3h-13zm21.6 0a1.1 1.1 0 011-.6c.5 0 .8.3 1 .6h1.6c-.2-1-.9-1.6-1.8-2V287h-1.6v5.3c-.8.3-1.4.8-1.7 1.6h-4.4v.3h6m-30.2-15l6 6.8 1.3-1-6.1-6.7.3-.6h4.4V276h-4.4a2.6 2.6 0 00-2.5-1.7 2.6 2.6 0 00-2.7 2.5 2.5 2.5 0 001.8 2.4v5.2h1.6v-5.2h.3zm32 0v5.3h-1.7v-5.2a2.5 2.5 0 01-.4-.2l-6 6.8-1.3-1 6.2-6.9-.1-.3h-4.5V276h4.5a2.6 2.6 0 012.4-1.7 2.6 2.6 0 012.7 2.5 2.5 2.5 0 01-1.9 2.4zm-16.1 0v3.3h-1.7v-3.2a2.6 2.6 0 01-1.7-1.6h-4V276h4a2.6 2.6 0 012.5-1.7c1.2 0 2.2.7 2.5 1.7h4v1.6h-4a2.5 2.5 0 01-1.6 1.6zm-17.8 4l-1.7.4v4.3l1.7.5v-5.2m1.6 0l1.7.4v4.3l-1.7.5v-5.2m30.6 0l-1.7.4v4.3l1.7.5v-5.2m1.6 0l1.7.4v4.3l-1.7.5v-5.2m-25.5.8l1.6-.7 2.9 3.3-1 1.4-3.5-4m-1.3 1l-1 1.4 3 3.3 1.6-.7-3.6-4m18.5-1.1l-1.6-.7-3 3.3 1 1.4 3.6-4m1.2 1l1 1.4-3 3.3-1.5-.7 3.5-4m-20.3 9l.5-1.6h4.5l.5 1.6h-5.5m-6.7-17c0-.6.5-1 1.2-1a1 1 0 011 1c0 .6-.4 1-1 1a1.1 1.1 0 01-1.2-1zm12.1.8l-.5 1.6h-4.5l-.5-1.6h5.5m0-1.6l-.5-1.6h-4.5l-.5 1.6h5.5m15.7 17.8l-.5-1.6h-4.5l-.5 1.6h5.5m4.4-17c0-.6.5-1 1.1-1a1 1 0 011.1 1c0 .6-.5 1-1 1a1.1 1.1 0 01-1.2-1zm-16.1 0c0-.6.5-1 1.1-1a1 1 0 011.1 1c0 .6-.5 1-1.1 1a1.1 1.1 0 01-1.1-1zm6.2.8l.5 1.6h4.6l.5-1.6h-5.6m0-1.6l.5-1.6h4.6l.5 1.6h-5.6m-5.9 5l-1.7.5v4.3l1.7.5V281m1.7 0l1.6.5v4.3l-1.6.5V281"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#c8b100",
      strokeWidth: ".3",
      d: "M232.7 316.3a15.6 15.6 0 003.7-1.1l.8 1.4a17.6 17.6 0 01-4.3 1.2 2.6 2.6 0 01-2.6 2 2.6 2.6 0 01-2.5-2 17.5 17.5 0 01-4.6-1.2l.8-1.4c1.3.5 2.6.9 4 1a2.5 2.5 0 011.5-1.3v-6.7h1.6v6.7c.7.2 1.3.7 1.6 1.4zm-4.7-20.4a2.3 2.3 0 01-.2-.5h-4V294h4a2.6 2.6 0 01.2-.4l-5-5.6 1.2-1 5 5.5a2.2 2.2 0 01.2 0V285h1.7v7.3h.2l4.9-5.5 1.2 1-4.9 5.5.3.6h4v1.5h-4c0 .2-.2.4-.3.5l4.7 5.3-1.3 1-4.6-5.3-.2.1v8.7h-1.6V297l-.2-.1-4.8 5.3-1.2-1 4.7-5.3m-12.8-16.7l6 6.8 1.3-1-6.1-6.7.3-.6h4.4V276h-4.4a2.6 2.6 0 00-2.5-1.7 2.6 2.6 0 00-2.6 2.5 2.5 2.5 0 001.7 2.4v5.2h1.6v-5.2h.3zm6.5 34.8l-.8 1.4a16.6 16.6 0 01-3.6-3.1c-.9.2-1.8 0-2.5-.5a2.4 2.4 0 01-.3-3.5l.1-.1a15.3 15.3 0 01-1.2-4.8h1.6a13.1 13.1 0 001 4c.5 0 1 0 1.4.2l4.1-4.5 1.3 1-4.1 4.5c.6.9.5 2-.1 2.8a15.2 15.2 0 003.1 2.6zm-8.4-13.1V297a2.5 2.5 0 01-1.8-2.4c0-1 .8-2 1.8-2.4V287h1.6v5.3c.8.2 1.5.8 1.7 1.6h4.4v1.5h-4.4a2.6 2.6 0 01-1.6 1.6v3.9h-1.7m2.3 8.3c.4-.4 1.1-.5 1.6 0s.5 1 .1 1.4a1.2 1.2 0 01-1.6.1 1 1 0 010-1.5zm-2-4.5l-1.7-.3-.3-4.3 1.7-.6v2.5c0 1 0 1.8.3 2.7zm1.4-5.3l1.6.4v2.2c0-.8.3 2.1.3 2.1l-1.7.6-.3-2.7v-2.6zm5.5 13.7a15.7 15.7 0 004.8 2.6l.4-1.6a13.7 13.7 0 01-4-2l-1.2 1m-.8 1.4a17.4 17.4 0 004.8 2.6l-1.2 1.1a18.7 18.7 0 01-4-2l.4-1.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#c8b100",
      strokeWidth: ".3",
      d: "M221.9 305.1l1.6.7 3-3.3-1-1.4-3.6 4m-1.3-1l-1-1.4 3-3.3 1.6.7-3.6 4m-7.6-9.5c0-.6.5-1 1-1 .7 0 1.2.5 1.2 1 0 .6-.5 1.1-1.1 1.1a1 1 0 01-1.1-1zm25.7 19.4l.8 1.4a16.7 16.7 0 003.6-3.1c.9.2 1.8 0 2.6-.5a2.4 2.4 0 00.2-3.5l-.1-.1a15 15 0 001.3-4.8h-1.7a13.3 13.3 0 01-1 4 3 3 0 00-1.4.2l-4.1-4.5-1.3 1 4.1 4.5a2.4 2.4 0 00.1 2.8 15 15 0 01-3 2.6zm8.4-13.1V297a2.5 2.5 0 001.8-2.4c0-1-.7-2-1.8-2.4V287h-1.6v5.3c-.8.2-1.4.8-1.7 1.6h-4.4v1.5h4.4c.3.8.9 1.3 1.7 1.6v3.9h1.6zm-2.3 8.3a1.2 1.2 0 00-1.6 0 1 1 0 00-.1 1.4 1.2 1.2 0 001.6.1 1 1 0 000-1.5zm2-4.5l1.7-.3.3-4.3-1.7-.6v2.5c0 1 0 1.8-.2 2.7zm-1.3-5.3l-1.7.4v2.2c0-.8-.3 2.1-.3 2.1l1.7.6.3-2.7v-2.6m1.6-20.1v5.2h-1.6v-5.2a2.3 2.3 0 01-.4-.2l-6 6.8-1.2-1 6-7v-.2h-4.5V276h4.4a2.6 2.6 0 012.5-1.7 2.6 2.6 0 012.6 2.5 2.5 2.5 0 01-1.8 2.4zm-16 0v3.2h-1.7v-3.2a2.6 2.6 0 01-1.7-1.6h-4V276h4c.4-1 1.3-1.7 2.5-1.7s2.2.7 2.5 1.7h4v1.6h-4a2.5 2.5 0 01-1.6 1.6zm8.8 33.8a15.7 15.7 0 01-4.8 2.6l-.4-1.6a13.7 13.7 0 004-2l1.2 1m.8 1.4a17.4 17.4 0 01-4.8 2.6l1.2 1.1a18.7 18.7 0 004-2l-.4-1.7m-27.4-31.4l-1.7.5v4.3l1.7.5v-5.2m1.7 0l1.6.4v4.3l-1.6.5V283m30.5 0l-1.7.5v4.3l1.7.5V283"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#c8b100",
      strokeWidth: ".3",
      d: "M247.1 283.1l1.7.5v4.3l-1.7.5V283m-8.6 22l-1.6.7-2.9-3.3 1-1.4 3.5 4m1.3-1l1-1.4-3-3.3-1.6.7 3.6 4m-18.2-20l1.6-.7 3 3.3-1 1.4-3.6-4m-1.3 1l-1 1.4 3 3.3 1.6-.7-3.6-4m18.5-1.1l-1.6-.7-3 3.3 1 1.4 3.6-4m1.2 1l1 1.4-3 3.2-1.5-.6 3.5-4m-20.3 9l.5-1.6h4.5l.5 1.6h-5.5m0 1.5l.5 1.6h4.5l.5-1.6h-5.5M213 277c0-.6.5-1 1.2-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1.2-1zm12.1.8l-.5 1.6h-4.5l-.5-1.6h5.5m0-1.6l-.5-1.6h-4.5l-.5 1.6h5.5m20.1 18.5c0-.5.5-1 1.1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1.1-1 1.1a1 1 0 01-1.2-1zm-4.4-.7l-.5-1.6h-4.5l-.5 1.6h5.5m0 1.5l-.5 1.6h-4.5l-.5-1.6h5.5m-11.6 21.9c0-.6.5-1 1.1-1 .6 0 1.1.4 1.1 1s-.5 1-1 1a1.1 1.1 0 01-1.2-1zm1.9-7.8l1.7-.4v-4.3l-1.7-.5v5.2m-1.6 0l-1.7-.4v-4.3l1.7-.5v5.2m15.7-32.6c0-.6.5-1 1.1-1a1 1 0 011.1 1c0 .6-.5 1-1 1a1.1 1.1 0 01-1.2-1zm-16.1 0c0-.6.5-1 1.1-1a1 1 0 011.1 1c0 .6-.5 1-1 1a1.1 1.1 0 01-1.2-1zm6.2.8l.5 1.6h4.6l.5-1.6h-5.5m0-1.6l.4-1.6h4.6l.5 1.6h-5.5m-6 5l-1.6.5v4.3l1.6.5V281m1.7 0l1.6.5v4.3l-1.6.5V281"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      d: "M227.7 294.7a2.6 2.6 0 012.6-2.5 2.6 2.6 0 012.6 2.5 2.6 2.6 0 01-2.6 2.4c-1.4 0-2.6-1-2.6-2.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M230.9 229.7v-.6l.1-.3-2.3-.1a5.9 5.9 0 01-2.3-1.2c-.8-.7-1.1-1-1.6-1.2-1.3-.2-2.3.4-2.3.4s1 .4 1.7 1.3 1.5 1.3 1.8 1.4c.6.2 2.6 0 3.1.1l1.8.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M230.9 229.7v-.6l.1-.3-2.3-.1a5.9 5.9 0 01-2.3-1.2c-.8-.7-1.1-1-1.6-1.2-1.3-.2-2.3.4-2.3.4s1 .4 1.7 1.3 1.5 1.3 1.8 1.4c.6.2 2.6 0 3.1.1l1.8.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ed72aa",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M238.1 227.5v1.4c.2.6-.1 1.2 0 1.5 0 .4.1.6.3.9l.2.9-.7-.5-.6-.4v1c.1.2.3.8.6 1.1l1 1.3c.2.5.1 1.4.1 1.4s-.4-.7-.8-.8l-1.2-.7s.7.8.7 1.5c0 .8-.3 1.6-.3 1.6s-.3-.7-.8-1.1l-1-.9s.4 1.2.4 2v2.3l-.9-1-1-.7c0-.2.5.6.6 1.1 0 .5.3 2.3 1.8 4.5 1 1.3 2.3 3.6 5.3 2.9 3-.8 1.9-4.8 1.3-6.7a16.8 16.8 0 01-1-4.6c0-.8.6-2.9.5-3.3a8 8 0 01.2-3.1c.4-1.3.7-1.8.9-2.3.2-.6.4-.9.4-1.3l.1-1.3.7 1.3.1 1.5s.1-1 1-1.6c.8-.6 1.8-1.1 2-1.4.3-.3.3-.5.3-.5s0 1.8-.6 2.6l-1.7 2s.7-.3 1.2-.3h.9s-.6.4-1.4 1.6c-.8 1-.5 1.2-1 2.1-.6 1-1 1-1.7 1.5-1 .8-.5 4.2-.4 4.7.2.5 2 4.5 2 5.5s.2 3.2-1.5 4.6c-1.1 1-3 1-3.4 1.2-.4.3-1.2 1.1-1.2 2.8 0 1.7.6 2 1 2.4.6.5 1.2.2 1.3.6.2.3.2.5.5.7.2.2.3.4.2.8 0 .3-.8 1.1-1.1 1.7l-.8 2.4c0 .2-.1 1 .1 1.3 0 0 .9 1 .3 1.2-.4.2-.8-.2-1-.2l-.9.5c-.3-.1-.3-.3-.4-.8l-.1-.7c-.2 0-.3.2-.4.5 0 .2 0 .8-.3.8-.2 0-.5-.4-.8-.5-.2 0-.8-.2-.8-.4 0-.3.4-.9.7-1 .4 0 .8-.3.5-.5s-.5-.2-.7 0-.8 0-.7-.2v-.8c0-.2-.4-.5.1-.8.6-.3.8.2 1.4.1.6 0 .8-.3 1-.6.2-.3.2-1-.2-1.4-.4-.5-.7-.5-.9-.8l-.3-.9v2.2l-.7-.8c-.3-.3-.6-1.3-.6-1.3v1.3c0 .4.3.7.2.8-.1.1-.8-.7-1-.8a3.7 3.7 0 01-1-1l-.4-1.4a4.2 4.2 0 010-1.5l.4-1h-1.4c-.7 0-1.2-.3-1.5.2-.3.5-.2 1.5.2 2.8.3 1.2.5 1.9.4 2.1a3 3 0 01-.7.8h-.9a2.5 2.5 0 00-1.2-.3h-1.3l-1.1-.3c-.3.1-.8.3-.6.7.2.6-.2.7-.5.7l-.9-.2c-.4-.1-.9 0-.8-.4 0-.4.2-.4.4-.7.2-.3.2-.5 0-.5h-.6c-.2.2-.5.5-.8.4-.2-.1-.4-.4-.4-1s-.7-1.2 0-1.1c.5 0 1.3.4 1.4 0 .2-.3 0-.4-.2-.7s-.8-.4-.3-.7l.7-.5c.1-.2.4-.8.7-.6.6.2 0 .7.6 1.3.6.7 1 1 2 .8 1 0 1.3-.2 1.3-.5l-.1-1v-1s-.4.3-.5.6l-.4.8v-2a8 8 0 00-.2-.8l-.3.9-.1 1s-.7-.5-.5-1.5c.1-.7-.1-1.6.1-2 .2-.3.7-1.5 2-1.6h2.6l2-.3s-2.8-1.4-3.5-1.9a9.5 9.5 0 01-2-2l-.6-1.6s-.5 0-1 .3a5 5 0 00-1.2 1l-.7 1 .1-1.2v-.8s-.4 1.2-1 1.7l-1.4 1v-.8l.2-1s-.4.8-1.1 1c-.7 0-1.8 0-1.9.4 0 .5.2 1 0 1.4 0 .3-.4.5-.4.5l-.8-.4c-.4 0-.7.2-.7.2s-.3-.4-.2-.7c.1-.2.7-.6.5-.8l-.8.2c-.3.1-.8.3-.8-.2 0-.4.2-.7 0-1 0-.3 0-.5.2-.6l1.2-.1c0-.2-.2-.5-.8-.6-.6-.1-.8-.5-.5-.8.3-.2.3-.3.5-.6.1-.2.2-.7.7-.5.5.3.4.8 1 1a4 4 0 002-.2l1.5-1 1.5-1-1-.8c-.3-.3-.7-.9-1-1a8.3 8.3 0 00-1.8-.6 9 9 0 01-1.7-.5l.8-.3c.2-.2.6-.6.8-.6h.3-1.4c-.3-.1-1-.6-1.3-.6l-.8.1s.8-.4 1.4-.5l1-.1s-.9-.3-1.1-.6l-.6-1c-.2-.1-.3-.5-.6-.5l-1 .3c-.4 0-.6-.2-.6-.6l-.1-.5c-.2-.3-.6-.8-.2-1h1.4c0-.2-.5-.6-.8-.8-.4-.2-1-.5-.7-.8l.8-.5c.2-.3.3-1 .7-.7.4.2.8 1.2 1.1 1.1.3 0 .3-.8.3-1 0-.4 0-1 .2-.9.3 0 .5.4 1 .5.4 0 1-.1 1 .2 0 .3-.3.7-.6 1-.3.3-.4 1-.3 1.4.2.5.7 1.2 1.2 1.4.4.3 1.2.5 1.7.9.5.3 1.7 1.2 2.1 1.3l.8.4s.5-.2 1.1-.2c.7 0 2.1 0 2.6-.2.6-.2 1.3-.6 1-1-.1-.6-1.3-1-1.2-1.4 0-.4.5-.4 1.2-.4.8 0 1.8.1 2-1 .2-1 .2-1.5-.8-1.8-1-.2-1.8-.2-2-1-.2-.7-.4-.9-.2-1.1.3-.2.6-.3 1.4-.4.8 0 1.6 0 1.9-.2.2-.2.3-.7.6-.9.3-.2 1.4-.4 1.4-.4s1.4.7 2.7 1.7a15 15 0 012.2 2.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M228.1 226.8l-.2-.6v-.3s.8 0 .7.3c0 .2-.2.2-.3.3l-.2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M228.1 226.8l-.2-.6v-.3s.8 0 .7.3c0 .2-.2.2-.3.3l-.2.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M232 225.4v-.4s.7 0 1 .3c.5.4.9 1 .9 1l-.8-.4h-.5l-.3-.1v-.3h-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M232 225.4v-.4s.7 0 1 .3c.5.4.9 1 .9 1l-.8-.4h-.5l-.3-.1v-.3h-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M237.3 231.3l-.4-.7a8 8 0 01-.3-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M217.4 226.6s.5.4.8.4h.8s.2-.5.1-.8c-.2-1.2-1.2-1.4-1.2-1.4s.3.7.1 1a2 2 0 01-.6.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M217.4 226.6s.5.4.8.4h.8s.2-.5.1-.8c-.2-1.2-1.2-1.4-1.2-1.4s.3.7.1 1a2 2 0 01-.6.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M215.2 227.6s-.4-.7-1.3-.6c-.8 0-1.4.8-1.4.8h1.2c.3.3.4 1 .4 1l.7-.6a7.2 7.2 0 00.4-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M215.2 227.6s-.4-.7-1.3-.6c-.8 0-1.4.8-1.4.8h1.2c.3.3.4 1 .4 1l.7-.6a7.2 7.2 0 00.4-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M214.2 230.6s-.8.1-1.2.6c-.4.5-.3 1.3-.3 1.3s.4-.5.9-.5l1 .2-.1-.8-.3-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M214.2 230.6s-.8.1-1.2.6c-.4.5-.3 1.3-.3 1.3s.4-.5.9-.5l1 .2-.1-.8-.3-.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M228.2 230.5l.3-.5.3.5h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M228.2 230.5l.3-.5.3.5h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M229 230.5l.3-.5.4.5h-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M229 230.5l.3-.5.4.5h-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M228.6 227.3l.8.3-.7.4-.1-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M228.6 227.3l.8.3-.7.4-.1-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M229.5 227.6l.7.2-.5.4-.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M229.5 227.6l.7.2-.5.4-.2-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M224.2 233.7s-.7.2-1 .6c-.4.5-.3 1-.3 1s.6-.5 1.5-.3l1.2.3 1.3-.3s-.7.8-.7 1.3l.2 1.1c0 .7-.6 1.6-.6 1.6l1-.3a4.6 4.6 0 001.7-.8l.9-1s-.2 1 0 1.4l.2 1.6.8-.6c.2-.1.7-.4.9-.7l.3-1s0 .8.4 1.3l.6 1.6s.3-.8.6-1.1c.3-.4.7-.8.7-1a4.3 4.3 0 00-.1-.9l.4.8m-11 .6s.5-.8 1-1l1.1-.8.9-.4m1 5l1.3-.8a4 4 0 001-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M216.6 240.4s-.4-.5-1.1-.3c-.7 0-1.2.9-1.2.9s.6-.2 1-.1.6.4.6.4l.4-.4.3-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M216.6 240.4s-.4-.5-1.1-.3c-.7 0-1.2.9-1.2.9s.6-.2 1-.1.6.4.6.4l.4-.4.3-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M215.8 243.2s-.6 0-1.1.3c-.5.4-.5 1.2-.5 1.2s.4-.4.8-.3l.9.2v-.6c.2-.4-.1-.8-.1-.8"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M215.8 243.2s-.6 0-1.1.3c-.5.4-.5 1.2-.5 1.2s.4-.4.8-.3l.9.2v-.6c.2-.4-.1-.8-.1-.8z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M217.2 245.8s0 .8.3 1.3c.4.5 1.1.5 1.1.5l-.3-.7c0-.4.3-.8.3-.8s-.3-.3-.7-.3h-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M217.2 245.8s0 .8.3 1.3c.4.5 1.1.5 1.1.5l-.3-.7c0-.4.3-.8.3-.8s-.3-.3-.7-.3h-.7zm16 1.3s2 1.2 1.9 2.2c0 1-1 2.3-1 2.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M224.2 252.6s-.4-.6-1.1-.6c-.7 0-1.4.7-1.4.7s.8-.1 1 .2l.5.6.5-.3.5-.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M224.2 252.6s-.4-.6-1.1-.6c-.7 0-1.4.7-1.4.7s.8-.1 1 .2l.5.6.5-.3.5-.6z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M222.2 255.3s-1-.1-1.4.3c-.4.5-.4 1.3-.4 1.3s.6-.6 1-.5c.5 0 1 .3 1 .3v-.7l-.3-.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M222.2 255.3s-1-.1-1.4.3c-.4.5-.4 1.3-.4 1.3s.6-.6 1-.5c.5 0 1 .3 1 .3v-.7l-.3-.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M224 258.1s-.3.7 0 1.1c.3.5 1 .8 1 .8s-.3-.4-.2-.8c.1-.3.7-.8.7-.8l-1.4-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M224 258.1s-.3.7 0 1.1c.3.5 1 .8 1 .8s-.3-.4-.2-.8c.1-.3.7-.8.7-.8l-1.4-.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M236 259.3s-.8-.2-1.2 0c-.5.3-.8 1.4-.8 1.4s.7-.6 1.2-.5c.5 0 1 .3 1 .3v-.8l-.2-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M236 259.3s-.8-.2-1.2 0c-.5.3-.8 1.4-.8 1.4s.7-.6 1.2-.5c.5 0 1 .3 1 .3v-.8l-.2-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M236.4 262.2s-.6.6-.4 1.1l.6 1s0-.7.2-1l1-.3-.7-.5a15.8 15.8 0 01-.7-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M236.4 262.2s-.6.6-.4 1.1l.6 1s0-.7.2-1l1-.3-.7-.5a15.8 15.8 0 01-.7-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#db4446",
      d: "M239.4 263s-.3.8.2 1.3c.6.5 1 .5 1 .5s-.3-.7-.2-1.1c.1-.5.5-.7.5-.7l-.8-.2-.7.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M239.4 263s-.3.8.2 1.3c.6.5 1 .5 1 .5s-.3-.7-.2-1.1c.1-.5.5-.7.5-.7l-.8-.2-.7.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ffd691",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M208.8 316.4c2 .6 3 2 3 3.8 0 2.3-2.2 4-5 4-3 0-5.3-1.7-5.3-4 0-1.7 1-3.6 3-3.8l-.2-.4-.7-.7h1.2l.8.5.5-.7c.3-.4.6-.5.6-.5l.6.6.3.5.7-.4.8-.3s0 .4-.2.7l-.1.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M206.3 326.7s-3.8-2.6-5.5-3c-2-.4-4.5 0-5.5 0 0 0 1.2.8 1.8 1.4.5.5 2.3 1.5 3.3 1.8 3 .8 6-.2 6-.2m1 .2s2.4-2.5 5-2.9c3-.4 5 .3 6.2.6l-1.5.8c-.5.3-2 1.5-4 1.6-2 0-4.4-.3-4.8-.2l-.9.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M206.7 323.8a4.8 4.8 0 010-7.1 4.8 4.8 0 011.5 3.5 4.9 4.9 0 01-1.5 3.6"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#058e6e",
      stroke: "#000",
      strokeWidth: ".5",
      d: "M205.7 329s.6-1.5.6-2.7l-.1-2.1h.8s.3 1.1.3 2l-.1 2.4-.7.1-.8.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M254 190.7c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M254 190.7c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M255.4 188.2c0-.6.5-1 1.1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M255.4 188.2c0-.6.5-1 1.1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M256.4 185.2c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M256.4 185.2c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M256.5 182c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M256.5 182c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M255.7 179c0-.6.5-1 1-1 .7 0 1.2.4 1.2 1s-.5 1-1.1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M255.7 179c0-.6.5-1 1-1 .7 0 1.2.4 1.2 1s-.5 1-1.1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M254.1 176.1c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M254.1 176.1c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M252 173.8c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M252 173.8c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M249.4 171.8c0-.5.5-1 1.1-1a1 1 0 010 2c-.6 0-1-.4-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M249.4 171.8c0-.5.5-1 1.1-1a1 1 0 010 2c-.6 0-1-.4-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M246.5 170.3c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M246.5 170.3c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M243.3 169.1c0-.5.5-1 1.1-1a1 1 0 010 2 1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M243.3 169.1c0-.5.5-1 1.1-1a1 1 0 010 2 1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M239.9 168.5c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M239.9 168.5c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M236.6 168.3c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M236.6 168.3c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M233.3 168.5c0-.6.5-1 1-1 .7 0 1.1.4 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M233.3 168.5c0-.6.5-1 1-1 .7 0 1.1.4 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M230.1 168.5c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M230.1 168.5c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M231.7 171.2c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1m.6 3.1c0-.6.4-1 1-1s1 .4 1 1c0 .5-.4 1-1 1a1 1 0 01-1-1m0 3c0-.5.6-1 1.1-1a1 1 0 010 2 1 1 0 01-1-1m-1 2.8c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1 0 .6-.4 1-1 1a1 1 0 01-1-1m-1.9 2.6c0-.5.5-1 1-1 .7 0 1.2.5 1.2 1s-.5 1-1.1 1c-.6 0-1-.4-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M227.6 166.5c0-.5.5-1 1.1-1a1 1 0 010 2 1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M227.6 166.5c0-.5.5-1 1.1-1a1 1 0 010 2 1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M224.8 165c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M224.8 165c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M221.6 164c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1 0 .5-.5 1-1 1-.6 0-1.1-.5-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M221.6 164c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1 0 .5-.5 1-1 1-.6 0-1.1-.5-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M218.3 163.4c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M218.3 163.4c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M215 163.5c0-.6.5-1 1.1-1 .6 0 1 .4 1 1 0 .5-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M215 163.5c0-.6.5-1 1.1-1 .6 0 1 .4 1 1 0 .5-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M211.7 164c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M211.7 164c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M208.6 165.1c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M208.6 165.1c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M156 190.7c0-.5.4-1 1-1s1 .5 1 1c0 .6-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M156 190.7c0-.5.4-1 1-1s1 .5 1 1c0 .6-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M154.5 188.2c0-.6.5-1 1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M154.5 188.2c0-.6.5-1 1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M153.5 185.2c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M153.5 185.2c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M153.4 182c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M153.4 182c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M154.2 179c0-.6.5-1 1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M154.2 179c0-.6.5-1 1-1 .6 0 1 .4 1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M155.8 176.1c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M155.8 176.1c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1s-.5 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M158 173.8c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M158 173.8c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M160.5 171.8c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M160.5 171.8c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M163.5 170.3c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M163.5 170.3c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M166.6 169.1c0-.5.5-1 1-1a1 1 0 010 2 1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M166.6 169.1c0-.5.5-1 1-1a1 1 0 010 2 1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M170 168.5c0-.5.5-1 1.1-1a1 1 0 010 2c-.6 0-1-.4-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M170 168.5c0-.5.5-1 1.1-1a1 1 0 010 2c-.6 0-1-.4-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M173.4 168.3c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M173.4 168.3c0-.5.4-1 1-1s1 .5 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M176.6 168.5c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M176.6 168.5c0-.6.5-1 1-1 .6 0 1.1.4 1.1 1s-.5 1-1 1a1 1 0 01-1.1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M179.8 168.5c0-.6.5-1 1-1 .7 0 1.2.4 1.2 1s-.5 1-1.1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M179.8 168.5c0-.6.5-1 1-1 .7 0 1.2.4 1.2 1s-.5 1-1.1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M178.2 171.2c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1m-.7 3.1c0-.6.4-1 1-1s1 .4 1 1c0 .5-.4 1-1 1a1 1 0 01-1-1m-.2 3c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1m.9 2.8c0-.5.5-1 1-1 .6 0 1.1.5 1.1 1 0 .6-.5 1-1 1a1 1 0 01-1.1-1m1.8 2.6c0-.5.5-1 1-1a1 1 0 010 2 1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M182.3 166.5c0-.5.5-1 1-1a1 1 0 010 2 1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M182.3 166.5c0-.5.5-1 1-1a1 1 0 010 2 1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M185.2 165c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M185.2 165c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M188.3 164c0-.6.5-1 1-1 .7 0 1.1.4 1.1 1 0 .5-.4 1-1 1s-1-.5-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M188.3 164c0-.6.5-1 1-1 .7 0 1.1.4 1.1 1 0 .5-.4 1-1 1s-1-.5-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M191.6 163.4c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M191.6 163.4c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M194.9 163.5c0-.6.4-1 1-1s1 .4 1 1c0 .5-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M194.9 163.5c0-.6.4-1 1-1s1 .4 1 1c0 .5-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M198.2 164c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M198.2 164c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#fff",
      d: "M201.3 165.1c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M201.3 165.1c0-.5.5-1 1-1 .7 0 1.1.5 1.1 1s-.4 1-1 1a1 1 0 01-1-1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M174.7 228.9h-1v-1h-1.5v3.6h1.6v2.5h-3.4v7h1.8v14.3h-3.5v7.3h27.2v-7.3h-3.5V241h1.8v-7h-3.4v-2.5h1.6V228h-1.6v.9h-.8v-1h-1.6v1h-1.1v-1h-1.6v3.6h1.6v2.5H184v-7.8h1.7v-3.5H184v.9h-1v-1h-1.5v1h-.9v-1H179v3.6h1.7v7.8h-3.3v-2.5h1.6V228h-1.6v.9h-.9v-1h-1.8v1zm-6 33.7H196m-27.3-1.8H196m-27.3-1.8H196m-27.3-1.7H196m-27.3-2H196m-23.8-1.6h20.2m-20.2-1.8h20.2m-20.2-2h20.2m-20.2-1.7h20.2m-20.2-1.8h20.2m-20.2-1.8h20.2m-20.2-1.7h20.2m-22-1.8h23.8m-23.8-1.8h23.8m-23.8-1.8h23.8m-23.8-1.8h23.8m-20.4-1.7h17m-10.2-1.8h3.4m-3.4-1.8h3.4m-3.4-1.8h3.4m-3.4-1.7h3.4m-5.1-2.2h6.8m-12 7.5h3.6m-5-2.2h6.6m-6.7 32.6v-1.8m0-1.8v-1.7m-1.8 1.7v1.8m3.4 0V259m1.7 3.6v-1.8m0-1.8v-1.7m0-2v-1.6m0-1.8v-2m-1.7 7.4v-2m-3.4 2v-2m7 0v2m1.5-2v-1.6m-5.1-1.8v1.8m3.5-1.8v1.8m3.3-1.8v1.8M179 252v-2m1.7-1.7v1.7m0-5.3v1.8m-1.7-3.6v1.8m1.7-3.5v1.7m-3.3-1.7v1.7m-3.5-1.7v1.7m-1.6-3.5v1.8m3.3-1.8v1.8m3.4-1.8v1.8m1.7-3.6v1.8m-3.3-1.8v1.8m-3.5-1.8v1.8m-1.6-3.6v1.8m6.7-1.8v1.8m-3.4-5.3v1.8m15.3-1.8h-3.5m5-2.2h-6.6m6.7 32.6v-1.8m0-1.8v-1.7m1.8 1.7v1.8m-3.4 0V259m-1.7 3.6v-1.8m0-1.8v-1.7m0-2v-1.6m0-1.8v-2m1.7 7.4v-2m3.4 2v-2m-7 0v2m-1.5-2v-1.6m5.1-1.8v1.8m-3.5-1.8v1.8m-3.3-1.8v1.8m1.7-1.8v-2m-1.7-1.7v1.7m0-5.3v1.8m1.7-3.6v1.8m-1.7-3.5v1.7m3.3-1.7v1.7m3.5-1.7v1.7m1.6-3.5v1.8m-3.3-1.8v1.8m-3.4-1.8v1.8m-1.7-3.6v1.8m3.3-1.8v1.8m3.5-1.8v1.8m1.6-3.6v1.8m-6.7-1.8v1.8m3.4-5.3v1.8m-7 18v-2m0-5.4v-1.8m0 5.4v-1.8m0-5.3v-1.8m0-1.8v-1.7m0-3.6v-1.8m0-1.7v-1.8m-8.3 4.6h3.5m3.3-5.3h3.4m3.3 5.3h3.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M186.8 262.6v-4.7c0-.8-.4-3.5-4.6-3.5-4 0-4.4 2.7-4.4 3.5v4.7h9z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      stroke: "#000",
      strokeWidth: ".4",
      d: "M179.3 258.2l-2.2-.3c0-.9.2-2.2.9-2.6l2 1.5c-.3.2-.7 1-.7 1.4zm6 0l2.2-.3c0-.9-.2-2.2-.9-2.6l-2 1.5c.3.2.7 1 .7 1.4zm-2.2-2.3l1-2a5.3 5.3 0 00-2-.4l-1.7.4 1.1 2h1.6zm-4.2-5.5v-4.9c0-1.3-1-2.4-2.5-2.4s-2.4 1-2.4 2.4v4.9h4.9zm6.8 0v-4.9c0-1.3 1-2.4 2.5-2.4s2.4 1 2.4 2.4v4.9h-4.9zm-1.7-12l.4-4.4h-4.2l.2 4.4h3.6zm3.3 0l-.4-4.4h4.4l-.5 4.4h-3.5zm-10 0l.2-4.4h-4.2l.5 4.4h3.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#0039f0",
      d: "M185.3 262.6v-4c0-.7-.5-2.7-3.1-2.7-2.4 0-2.9 2-2.9 2.7v4h6zm-6.9-12.7v-4.2c0-1-.6-2.2-2-2.2s-2 1.1-2 2.2v4.3h4zm7.8 0v-4.2c0-1 .7-2.2 2-2.2s2 1.1 2 2.2v4.3h-4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#ad1519",
      d: "M190.8 269.8c0-9.7 7-17.6 15.6-17.6s15.6 7.9 15.6 17.6-7 17.5-15.6 17.5-15.6-7.8-15.6-17.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".6",
      d: "M190.8 269.8c0-9.7 7-17.6 15.6-17.6s15.6 7.9 15.6 17.6-7 17.5-15.6 17.5-15.6-7.8-15.6-17.5z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#005bbf",
      d: "M195.4 269.7c0-7 5-12.8 11-12.8s11 5.7 11 12.8c0 7.2-5 13-11 13s-11-5.8-11-13"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".6",
      d: "M195.4 269.7c0-7 5-12.8 11-12.8s11 5.7 11 12.8c0 7.2-5 13-11 13s-11-5.8-11-13z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M201.2 260.9s-1.3 1.4-1.3 2.7a6 6 0 00.6 2.4c-.2-.5-.8-.8-1.4-.8-.8 0-1.4.6-1.4 1.3l.2.8.5.9c.1-.3.5-.5 1-.5s1 .4 1 1a.9.9 0 010 .2h-1.2v1h1l-.8 1.5 1-.4.8.9.8-.9 1 .4-.7-1.5h1v-1h-1.1a.9.9 0 010-.3 1 1 0 011-1c.4 0 .7.3 1 .6l.4-1 .2-.7a1.4 1.4 0 00-1.4-1.3c-.7 0-1.2.3-1.4.9 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M201.2 260.9s-1.3 1.4-1.3 2.7a6 6 0 00.6 2.4c-.2-.5-.8-.8-1.4-.8-.8 0-1.4.6-1.4 1.3l.2.8.5.9c.1-.3.5-.5 1-.5s1 .4 1 1a.9.9 0 010 .2h-1.2v1h1l-.8 1.5 1-.4.8.9.8-.9 1 .4-.7-1.5h1v-1h-1.1a.9.9 0 010-.3 1 1 0 011-1c.4 0 .7.3 1 .6l.4-1 .2-.7a1.4 1.4 0 00-1.4-1.3c-.7 0-1.2.3-1.4.9 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M199.2 269.9h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M199.2 269.9h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M211.4 260.9s-1.3 1.4-1.3 2.7c0 1.3.6 2.4.6 2.4-.2-.5-.7-.8-1.4-.8-.8 0-1.4.6-1.4 1.3l.2.8.5.9c.2-.3.5-.5 1-.5a1 1 0 011 1 .9.9 0 010 .2h-1.2v1h1l-.8 1.5 1-.4.8.9.8-.9 1 .4-.7-1.5h1v-1h-1.1a.8.8 0 010-.3 1 1 0 011-1c.4 0 .8.3 1 .6l.4-1 .2-.7a1.4 1.4 0 00-1.4-1.3c-.6 0-1.2.3-1.4.9 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M211.4 260.9s-1.3 1.4-1.3 2.7c0 1.3.6 2.4.6 2.4-.2-.5-.7-.8-1.4-.8-.8 0-1.4.6-1.4 1.3l.2.8.5.9c.2-.3.5-.5 1-.5a1 1 0 011 1 .9.9 0 010 .2h-1.2v1h1l-.8 1.5 1-.4.8.9.8-.9 1 .4-.7-1.5h1v-1h-1.1a.8.8 0 010-.3 1 1 0 011-1c.4 0 .8.3 1 .6l.4-1 .2-.7a1.4 1.4 0 00-1.4-1.3c-.6 0-1.2.3-1.4.9 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M209.4 269.9h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M209.4 269.9h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M206.3 269.6s-1.3 1.5-1.3 2.8.6 2.4.6 2.4c-.2-.5-.7-.9-1.4-.9-.8 0-1.4.6-1.4 1.4l.2.7.5 1c.1-.4.5-.6 1-.6a1 1 0 011 1 .9.9 0 010 .3h-1.2v1h1l-.8 1.5 1-.4.8.9.8-1 1 .5-.7-1.5h1v-1h-1.1a.9.9 0 010-.3 1 1 0 011-1c.4 0 .7.2.9.6l.5-1 .2-.7a1.4 1.4 0 00-1.4-1.4c-.7 0-1.2.4-1.4 1 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeLinejoin: "round",
      strokeWidth: ".3",
      d: "M206.3 269.6s-1.3 1.5-1.3 2.8.6 2.4.6 2.4c-.2-.5-.7-.9-1.4-.9-.8 0-1.4.6-1.4 1.4l.2.7.5 1c.1-.4.5-.6 1-.6a1 1 0 011 1 .9.9 0 010 .3h-1.2v1h1l-.8 1.5 1-.4.8.9.8-1 1 .5-.7-1.5h1v-1h-1.1a.9.9 0 010-.3 1 1 0 011-1c.4 0 .7.2.9.6l.5-1 .2-.7a1.4 1.4 0 00-1.4-1.4c-.7 0-1.2.4-1.4 1 0 0 .6-1.2.6-2.5s-1.4-2.7-1.4-2.7z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M204.3 278.6h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M204.3 278.6h4.1v-1h-4.1v1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M237.6 223.4h-.3a1.5 1.5 0 01-.3.4c-.2.2-.6.2-.8 0a.5.5 0 01-.1-.4.5.5 0 01-.5 0c-.3-.1-.3-.5-.1-.7v-.5h-.3l-.1.2c-.2.3-.5.3-.7.2a.6.6 0 010-.2h-.3c-.5.2-.7-1-.7-1.2l-.2.2s.2.7.1 1.2c0 .6-.3 1.2-.3 1.2a9 9 0 012.9 1.6 9 9 0 012.2 2.3l1.2-.5c.6-.2 1.3-.2 1.3-.2l.2-.2c-.3 0-1.5.1-1.5-.4v-.2a.7.7 0 01-.2 0c-.2-.2-.2-.4 0-.7l.2-.1v-.3h-.3l-.2.1c-.2.3-.6.3-.8 0a.4.4 0 01-.1-.4.6.6 0 01-.5 0c-.2-.2-.3-.5 0-.8l.2-.3v-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M237.6 223.4h-.3a1.5 1.5 0 01-.3.4c-.2.2-.6.2-.8 0a.5.5 0 01-.1-.4.5.5 0 01-.5 0c-.3-.1-.3-.5-.1-.7v-.5h-.3l-.1.2c-.2.3-.5.3-.7.2a.6.6 0 010-.2h-.3c-.5.2-.7-1-.7-1.2l-.2.2s.2.7.1 1.2c0 .6-.3 1.2-.3 1.2a9 9 0 012.9 1.6 9 9 0 012.2 2.3l1.2-.5c.6-.2 1.3-.2 1.3-.2l.2-.2c-.3 0-1.5.1-1.5-.4v-.2a.7.7 0 01-.2 0c-.2-.2-.2-.4 0-.7l.2-.1v-.3h-.3l-.2.1c-.2.3-.6.3-.8 0a.4.4 0 01-.1-.4.6.6 0 01-.5 0c-.2-.2-.3-.5 0-.8l.2-.3v-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M235.4 224h.2v.3h-.1c-.1 0-.1-.2 0-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M235.4 224h.2v.3h-.1c-.1 0-.1-.2 0-.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M236.3 224.8l-.3-.2v-.2h.1l.4.3.3.2v.2h-.2l-.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M236.3 224.8l-.3-.2v-.2h.1l.4.3.3.2v.2h-.2l-.3-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M234.6 223.7l-.2-.2s-.1 0 0-.1l.3.1.3.1v.2h-.1l-.3-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M234.6 223.7l-.2-.2s-.1 0 0-.1l.3.1.3.1v.2h-.1l-.3-.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M233.7 223h.2v.2h-.2s-.1-.1 0-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M233.7 223h.2v.2h-.2s-.1-.1 0-.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M237.3 225.5v-.2h-.3l.1.2h.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M237.3 225.5v-.2h-.3l.1.2h.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M237.9 226.2l.2.2h.1c.1 0 0-.1 0-.2l-.2-.2-.2-.2h-.1v.2l.2.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M237.9 226.2l.2.2h.1c.1 0 0-.1 0-.2l-.2-.2-.2-.2h-.1v.2l.2.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M238.8 227v-.3h-.3v.2h.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M238.8 227v-.3h-.3v.2h.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M236.2 221.1h-.6l-.1.9v.1h.2l.7-.5-.3-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M236.2 221.1h-.6l-.1.9v.1h.2l.7-.5-.3-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M234.6 221.6v.5l.9.1h.1v-.2l-.5-.7-.5.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M234.6 221.6v.5l.9.1h.1v-.2l-.5-.7-.5.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M236.4 222.6l-.4.3-.6-.7v-.1h1.1v.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M236.4 222.6l-.4.3-.6-.7v-.1h1.1v.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M235.3 222a.3.3 0 01.4 0 .3.3 0 010 .3.3.3 0 01-.3 0 .3.3 0 01-.1-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M235.3 222a.3.3 0 01.4 0 .3.3 0 010 .3.3.3 0 01-.3 0 .3.3 0 01-.1-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M233.2 221.1l-.2-.7-.4-.4s.4-.2.8.1c.4.3 0 .9 0 .9l-.2.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M233.2 221.1l-.2-.7-.4-.4s.4-.2.8.1c.4.3 0 .9 0 .9l-.2.1z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M234.2 221.4l-.4.4-.6-.6v-.2h1v.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M234.2 221.4l-.4.4-.6-.6v-.2h1v.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M233.1 221l.3-.1v.3c0 .2-.1.2-.2.2l-.1-.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M233.1 221l.3-.1v.3c0 .2-.1.2-.2.2l-.1-.3z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M238.3 222.5h-.5l-.3.7v.2h.2l.8-.4-.2-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M238.3 222.5h-.5l-.3.7v.2h.2l.8-.4-.2-.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M236.7 222.8v.5l.8.2h.1v-.2l-.4-.7-.5.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M236.7 222.8v.5l.8.2h.1v-.2l-.4-.7-.5.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M238.4 224l-.5.2-.4-.7v-.2h.1l.9.2-.1.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M238.4 224l-.5.2-.4-.7v-.2h.1l.9.2-.1.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M237.3 223.2h.4a.3.3 0 010 .4.3.3 0 01-.3 0 .3.3 0 010-.4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M237.3 223.2h.4a.3.3 0 010 .4.3.3 0 01-.3 0 .3.3 0 010-.4z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M240.2 224.3l.1.5-.8.3h-.2v-.2l.4-.8.5.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M240.2 224.3l.1.5-.8.3h-.2v-.2l.4-.8.5.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M240 225.8l-.5.1-.3-.8v-.1h.2l.8.3-.1.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M240 225.8l-.5.1-.3-.8v-.1h.2l.8.3-.1.5"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M238.6 224.3l-.2.5.9.3h.1v-.1l-.3-.8-.5.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M238.6 224.3l-.2.5.9.3h.1v-.1l-.3-.8-.5.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M239.5 225.2a.3.3 0 000-.3.3.3 0 00-.4 0 .3.3 0 000 .3.3.3 0 00.4 0"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M239.5 225.2a.3.3 0 000-.3.3.3 0 00-.4 0 .3.3 0 000 .3.3.3 0 00.4 0z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M240.8 227h.8l.5.3s.1-.4-.3-.7c-.3-.3-.8.2-.8.2l-.2.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M240.8 227h.8l.5.3s.1-.4-.3-.7c-.3-.3-.8.2-.8.2l-.2.2z"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M240.3 226.1l-.3.5.8.5v-.1h.2l-.1-1-.6.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M240.3 226.1l-.3.5.8.5v-.1h.2l-.1-1-.6.1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "#c8b100",
      d: "M241 227s.1-.1 0-.2h-.3c-.2 0-.2.1-.1.2h.3"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".3",
      d: "M241 227s.1-.1 0-.2h-.3c-.2 0-.2.1-.1.2h.3zm38-21.9v.6h-2.4v-.6h1v-1.3h-.7v-.5h.6v-.6h.6v.6h.6v.6h-.6v1.2h1"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: "0",
      d: "M134.4 217.1v-1.2m-.4 1.2v-1.2m-.2 1.2v-1.2m-.3 1.2v-1.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M133.2 217.1v-1.2m-.5 1.1v-1m.2 1v-1m-.7 1v-1m.2 1v-1m-.9 1v-1m.2 1v-1m.3 1v-1m-.7 1v-1m-.3.9v-.8m-.1.8v-.8m-.5.7v-.6m.2.6v-.6m-.4.5v-.5m-.2.5v-.4m-.3.3v-.3m-.3.3v-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M129.2 216.6v-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: "0",
      d: "M135.7 217v-1m-.5 1v-1m-.4 1.2V216m143 1.1V216m-.4 1.1V216m-.3 1.1V216m-.3 1.2V216"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".1",
      d: "M276.6 217.1V216m-.6 1v-1m.3 1v-1m-.8 1v-1m.3 1v-1m-.9 1v-1m.2 1v-1m.2 1v-1m-.6 1v-1m-.3.9v-.8m-.2.8v-.8m-.4.7v-.6m.2.6v-.6m-.5.6v-.6m-.2.5v-.4m-.3.4v-.4m-.2.3v-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: ".2",
      d: "M272.6 216.6v-.2"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      fill: "none",
      stroke: "#000",
      strokeWidth: "0",
      d: "M279.1 217v-1m-.6 1v-1m-.4 1.1V216"
    })]
  });
};
// CONCATENATED MODULE: ./src/assets/icons/SAFlag.tsx



const SAFlag = ({
  width = '640px',
  height = '480px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    id: "flag-icon-css-sa",
    viewBox: "0 0 640 480",
    width: width,
    height: height,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("defs", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("clipPath", {
        id: "sa-a",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
          fillOpacity: ".7",
          d: "M-85.3 0h682.6v512H-85.3z"
        })
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("g", {
      fillRule: "evenodd",
      clipPath: "url(#sa-a)",
      transform: "translate(80) scale(.9375)",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#199d00",
        d: "M-128 0h768v512h-768z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M65.5 145.1c-.8 12-2 33 8.3 35.2 12.3 1.2 5.5-20.8 10-24.8.8-2 2.3-2 2.4.5v18.7c0 6 4 7.8 7 9 3.2-.2 5.4 0 6.6 3l1.6 32.3s7.4 2.2 7.8-18.1c.3-12-2.4-21.9-.8-24.2 0-2.3 3-2.4 5-1.3 3.2 2.2 4.6 5 9.6 4 7.6-2.2 12.2-5.9 12.3-11.7a47 47 0 00-3.5-16.6c.4-1-1.4-3.7-1-4.7 1.3 2.2 3.4 2 3.8 0-1.3-4.2-3.3-8.3-6.5-10-2.7-2.4-6.7-2-8 3-.8 5.7 2 12.4 6.1 18 .9 2.1 2.1 5.7 1.6 8.9-2.2 1.3-4.4.7-6.3-1.2 0 0-6-4.5-6-5.6 1.6-10.2.3-11.4-.6-14.3-.6-3.9-2.5-5.2-4-7.8-1.5-1.6-3.5-1.6-4.5 0-2.7 4.6-1.4 14.5.5 19 1.4 4.1 3.5 6.7 2.5 6.7-.8 2.3-2.5 1.7-3.8-1a66.6 66.6 0 01-2.1-17.4c-.5-4.6-1.1-14.4-4.2-17-1.8-2.4-4.5-1.2-5.5 1a82.4 82.4 0 00.3 13.4c2 7.4 2.7 14 3.7 21.5.3 10.1-5.8 4.4-5.5-.7a45 45 0 00-.3-19.4c-1-2.6-2.1-3.2-4.6-2.8-1.9 0-6.8 5.3-8.2 14.3 0 0-1.2 4.6-1.7 8.7-.7 4.6-3.7 8-5.9-.6-1.8-6.3-3-21.6-6-18z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M99 194.2l-32 15.4c.3-7.3 15.1-20.4 25.3-20.5 6.5.1 4.9 2.5 6.6 5.1z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M93.3 204.2c-16.8 43.5 39.5 49.6 45.8 1.8.6-2 3-3.9 3.4-.7-1.3 43.3-43.6 46.2-50.8 32.6a41.9 41.9 0 01-2.5-14.6c-1-8.5-5.5-5.2-6.2 3.2-.7 4.7-.5 6-.5 10.5 2.2 34.2 56.7 19.5 65.6-8.7 4.7-15.6-.8-27.1 1.7-27.1 5.4 5.8 13 .8 14.7-1.2.7-1 2.5-1.7 3.7-.4 4.2 3 11.6 1.6 13.2-3.7.9-5.3 1.6-10.7 1.8-16.2-3.5 1-6 1.7-6.3 3.2l-.7 4.6c-.3 1.5-3.2 1.5-3.4-.4-1.3-6-6.7-6.7-10 2.5-2.1 1.8-6.1 2.2-6.5-.5.5-6.2-2-7-7-4.1l-4.8-36.2c2 0 4 1.5 5.9-.9-2-6.5-6.5-19.7-9-20.7-1.1-1.4-2.1-.5-3.7-.1-2.6.8-5 3-4.2 7.4 3 18.8 5 33.1 8.1 52 .5 2.1-1.3 5-3.7 4.7-4-2.7-5-8.2-12-8-5 0-10.6 5.5-11.3 10.7-.9 4.2-1.2 8.7 0 12.3 3.5 4.2 7.7 3.8 11.4 2.9 3-1.3 5.5-4.3 6.6-3.6.7.9.1 10.9-14.3 18.5-8.7 4-15.7 4.8-19.4-2.3-2.3-4.5.2-21.4-5.6-17.5z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M165 160c3.3-1.2 19.3-19.6 19.3-19.6l-2.4-2c-.9-.7-.8-1.5 0-2.2 4-2.4 2.7-7.4.7-9.8a9.7 9.7 0 00-8.7.1c-2.8 2.7-3.4 7-1.2 9.6 2.1 1 4.2 3.2 2.8 4.4-6.6 7-24.5 19.1-22.4 19.5.4.6 11.5.6 11.8 0zm-97 65c-6 9.6-6.5 23.9-3.2 28.2 1.8 2 4.7 2.9 6.8 2.2 3.8-1.6 5.5-9.3 4.6-12-1.3-2-2.3-2.3-3.6-.7-2.6 5.4-3.7 1.7-4-1.3a70 70 0 01.8-15.2c.7-4.2 0-3-1.4-1.2zm257.1-15.3c-5.8-12.6-13.9-25-16.4-29.7a557.6 557.6 0 00-24.8-36c-6.2-7.4 10.2 3.1-2-11.7l-8.9-7.5c-2-1.4-6.8-4-7.6.2-.4 3.8-.2 5.8.4 8.9.5 2 3.5 5.5 5 7.5a565 565 0 0153.8 86.5c2.6-1.3 2-16.1.5-18.2z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M299.6 251.5c-1.2 1.3 2.8 6.8 8 6.8 8.6-1 16.2-5.8 23.2-18.6a33 33 0 005.3-14.2 317 317 0 00-5.8-72.4c-.3-2 0-4.4.2-5 .6-.7 2.5 0 3.5-1.7 1.5-1.5-4-14-7-18.7-1-2.2-1.5-3.6-3.3.2a27 27 0 00-3 13.6c4.1 28.5 5.4 53.4 8 81.9.3 2.8-.1 6.8-2 8.4a80.2 80.2 0 01-27.1 19.7zm116.5-.1c-6.2 3.6-6.2 7.7-1.2 7.8 8.6-1 18.8-1.7 25.8-12.3a41 41 0 004.2-16 303 303 0 00-4.7-71.4c-.2-2-1.1-6.7-.8-7.3.6-1.4 3.4.1 4.4-1.5 1.4-1.5-7.3-12.7-10.4-17.5-1-2.2-1.4-3.6-3.3.2a22.3 22.3 0 00-1.8 13.6c4.6 31 8 54.2 8.7 81.6-.4 2.6-.5 4-1.7 7.3-2.7 3.4-5.7 7.8-8.5 9.9-2.8 2-8.8 4-10.7 5.6z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M420.7 223.7c0-7.3.1-13.5-.1-19a34 34 0 00-3-13.5c-1.8-4.1-.7-7.4-1.6-11.8-.8-4.4-.6-11-1.8-16.1-.4-2-1.4-8.5-1.1-9.2.5-1.4 2.4 0 3.4-1.6 1.4-1.5-5-18-8.2-22.7-1.1-2.1-3.3-1.4-5.8 2-2.5 2.3-1.6 7.4-.6 12.3 6.1 32.3 10.8 61.6 9.8 92.3-.4 2.6 9-7.8 9-12.7zm-45.7-40c-3.9-.2-12-7.7-14.4-12a8 8 0 01.4-6.5c1.5-1 3.7-2 5.4-1 0 0 1.7 2.4 1.4 2.7 2 1 3 .5 3.2-.4.1-1.5-.6-2.4-.6-4 .9-4.6 6-5.3 8-2.4 1.4 1.8 2 5.5 2.1 8 0 1.3-2-.2-3.3 0-1.1.4-1.4 1.8-1.5 3-.2 3.3-.6 8.6-.7 12.5zm-71.8 48c1-9.8-.4-27.3-.5-33.1A477 477 0 00299 154c-1.2-8.4 3.4.9 2.8-4-1.5-8.3-6.1-14-11.6-21.5-1.7-2.5-1.7-3-4.4.6-3 6.7-.4 11.4.4 16.7 3.9 17.2 6.2 33 7.3 48.7a393.4 393.4 0 01.4 49c3 .1 7.6-4.7 9.3-11.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M434 216c-6.9-11.6-17.2-24-20-28.7a658 658 0 00-29.2-37.8c-8.5-9 4-1.5-1.6-8.5-4.7-5.1-6-6.8-10.1-9.9-2-1.3-3.2-3.8-4 .5a83 83 0 00-.2 11.2c0 1.7 1.8 5 3.4 7 20.7 25.5 43.4 51.5 61.6 84.2 2.6-1.3 1.7-16 0-18z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#1ba400",
        d: "M122.6 194.7c-.5.9-1.6 2-1.2 3.1.7 1 1.4 1.3 2.6 1.3 1.1 0 2.7.3 3-.3.6-.7 1-2 .6-3.3-1.2-3-4.4-1.8-5-.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M354.2 362.5c9.2.4 15.2.5 23.3 1.4l9.6-1c10.6-1 11 15.1 11 15.1 0 9.5-3.7 10-8.4 11-2.7.4-4-1.6-5.5-3.6a14 14 0 01-7 .4c-3.9-.2-7.7-.2-11.5-.5-4-.3-6.2.5-10.3.1-.8 1.3-2 3.1-4.4 2.6-2-.3-4.5-6-3.8-10.5 1.5-3.2 1-2.1 1-3.5-37.6-1-75.5-2.7-112.3-2.2-28.8.1-57.2 1.3-85.7 2.5-15.2-.2-26.8-2.6-34.8-14.3.8 0 38.8 2.1 49.9 1.4 20.5-.2 39.3-1.9 60.2-2.5 41.2.7 82.1.7 123.3 3.6-4-2.7-4-9 2-10.6.5-.4.8 3.1 1.7 3 4.9-.3 2.7 6.3 1.7 7.6zM188.6 135.3c-6.2 17.8 3.6 37.4 10.4 35.5 5 2 8-7.4 10-17.6 1.5-2.9 2.5-3.2 3.2-1.7-.2 13.6 1 16.7 4.5 20.8 7.8 6 14.3.8 14.8.3l6-6.1c1.4-1.5 3.2-1.5 5.1-.3 1.9 1.7 1.6 4.6 5.6 6.6 3.4 1.4 10.5.4 12.2-2.5 2.2-3.9 2.8-5.2 3.8-6.6 1.6-2.1 4.3-1.2 4.3-.5-.3 1.2-1.9 2.3-.8 4.5 2 1.4 2.4.5 3.5.2 4-2 7-10.6 7-10.6.1-3.2-1.7-3-2.9-2.2l-3.1 2.1c-2 .3-5.7 1.6-7.6-1.3-1.9-3.4-1.9-8.3-3.3-11.8 0-.2-2.6-5.5-.2-5.8 1.2.2 3.7.9 4.1-1.2 1.2-2.1-2.6-8-5.3-11-2.3-2.5-5.5-2.8-8.6-.2-2.2 2-1.9 4.2-2.3 6.3a9.8 9.8 0 002 8.7c2.2 4.2 6.1 9.7 4.8 17.5 0 0-2.3 3.6-6.3 3.1-1.7-.3-4.4-1-5.8-11.8-1.1-8 .2-19.4-3.2-24.7-1.3-3.3-2.2-6.4-5.2-.9-.8 2.2-4.3 5.5-1.8 12.2a36 36 0 012 19c-1.5 2.2-1.8 2.9-3.7 5-2.6 3-5.5 2.2-7.7 1.1-2-1.3-3.6-2-4.6-6.5.2-7 .6-18.5-.7-20.9-1.9-3.8-5-2.4-6.3-1.2a47.7 47.7 0 00-11.5 23.5c-1.8 5.8-3.7 4.1-5 1.8-3.2-3-3.5-26.7-7.4-22.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M207.4 174.1c2.9-2 1.6-3.4 5.8.8a72 72 0 019.2 31.3c-.2 2.6 1.6 4.2 2.5 3.6.4-6 15.1-14.4 28.6-15.6 2-.5 1-4.4 1.3-6.4-.8-7.5 4.2-14.3 11.2-14.8 9.6 1.4 12.8 6.5 13 14.2-1.1 15-16.7 17.5-25.4 18.7-1.3.5-1.9 1.1 0 1.8l36.6.2 1.9 1c.2 1-.6.2-2 2.6a29.5 29.5 0 00-3.7 11.5c-10.9 3.6-22.2 5-33.6 6.5-4 2-6 4.7-5.2 7.7 1.4 3.3 10.2 6.7 10.2 6.8 1.7 1 3.6 3.5-.5 8.6-17.8-.8-31.7-8.4-36.5-19.1-1.4-1.1-3 0-4 1.4-7 9-13.8 17-25.7 21.4-7 1.8-14.3-1.1-17.7-5.7-2.3-2.7-2.2-5.6-3-6.2-3.9 1.7-36.9 15.7-32.7 9.1 8-8.5 22-14.9 34.2-23.3.9-2.9 2.5-12.5 7.3-15.6.3 0-.7 5.6-.6 8 0 2-.2 2.7.2 2.2.9-.5 15.7-12.2 17-15.8 1.4-2 .3-7.2.3-7.4-2.8-7.2-6.7-7.8-8.1-11.4-1.3-4.7-.7-10.1 2-11.7 2.4-2.1 5.2-1.9 7.9.5 3 2.7 5.6 8 6.4 11.9-.5 1.5-4-1-5-.3a16 16 0 013.7 7.8c2 8.2 1.4 11.4-.6 16.7-6.6 13.9-15 18-22.4 23.2-.2 0-.3 3.5 2.4 5.4 1 1 4.9 1.5 9.4 0a54.5 54.5 0 0022.3-23.3 51 51 0 00-2.4-22.2c-2.9-6.7-6.3-16.2-6.3-16.4-.1-4.2.2-5.6 2-7.7zm-95.8-38.6c4.2 2 12.2 1.1 11.8-5.7l-.2-3.1c-.8-2-3.2-1.5-3.7.5-.2.7.3 1.8-.3 2.1-.4.4-1.7.2-1.7-1.7 0-.6-.4-1.2-.7-1.6-.2-.2-.4-.2-.9-.2-.6 0-.6.1-.9.6-.1.5-.3 1-.3 1.6 0 .7-.4.9-.8 1-.6 0-.5 0-1-.2-.2-.3-.5-.4-.5-1l-.3-1.6c-.2-.3-.6-.5-1-.6-2.3 0-2.5 2.7-2.3 3.7-.2.2-.3 4.9 2.8 6.2z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M235.1 187.7c4.2 2 14.3.9 11.8-5.6l-.2-3.2c-.9-2-3.2-1.5-3.7.6-.2.6.3 1.7-.4 2-.3.4-1.7.2-1.6-1.6 0-.6-.4-1.3-.7-1.7-.3-.1-.4-.2-1-.2-.5 0-.5.2-.8.7-.2.5-.3 1-.3 1.6-.1.6-.4.8-.9 1-.5 0-.4 0-.8-.3-.3-.3-.6-.4-.6-.9l-.3-1.6c-.2-.3-.6-.5-1-.6-2.3 0-2.5 2.6-2.4 3.6-.1.2-.2 5 3 6.2zm72-21.6c4.2 2 12.1 1.1 11.8-5.6l-.2-3.2c-.9-2-3.2-1.5-3.7.5-.2.7.3 1.8-.4 2.2-.3.3-1.7.1-1.6-1.8 0-.6-.4-1.2-.7-1.6-.3-.2-.4-.2-1-.2-.5 0-.5.2-.8.7l-.3 1.5c-.1.7-.4 1-.9 1s-.4 0-.8-.2c-.3-.3-.6-.4-.6-.9s-.1-1.3-.3-1.7c-.2-.3-.6-.4-1-.5-2.3 0-2.5 2.6-2.4 3.6-.1.2-.2 4.9 3 6.2zm37.3 54.3c-7.3 8.3-4.1 22-2.4 25 2.4 4.8 4.3 7.9 9 10.3 4.3 3.1 7.7 1.2 9.5-1 4.3-4.5 4.4-16 6.4-18.2 1.4-4.2 5-3.5 6.7-1.6a16.5 16.5 0 006.2 5.3c4 3.5 8.8 4.2 13.6 1 3.2-1.9 5.3-4.2 7.2-8.9 2-5.6 1-31.6.5-47l-4.2-21.5c0-.2-.5-10.2-1-12.5 0-1-.3-1.3.7-1.2 1.1 1 1.2 1 2 1.3 1 .2 2-1.7 1.3-3.3l-10-18.6c-.8-.8-1.9-1.6-3.2.2a7.3 7.3 0 00-2.4 5.5c.3 4.4 1 8.9 1.3 13.3l4 22.6c1.3 16 1.6 29.2 2.9 45.3-.2 6.8-2.3 12.7-4.3 13.6 0 0-3 1.7-5-.2-1.5-.6-7.4-9.9-7.4-9.9-3-2.7-5-2-7.1 0-6 5.8-8.6 16.4-12.7 23.8-1 1.7-4 3-7.2-.1-8.2-11.3-3.4-27.3-4.4-23.2zM309 126.7c3.8 1.5 6.4 9.2 5.6 13-.8 4.5-2.8 9.5-4.2 8.9-1.6-.6 1-4.6-.5-8.8-.8-2.8-6-7.8-5.4-9.2-1-3.1 2.2-4.5 4.5-4z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M356.6 225c.7-9.2-.6-14.8-.8-20.2s-6.1-46.6-7.3-50.6c-1.5-7.8 5.7-1 4.9-5.6-2.5-5.6-8.6-13.9-10.5-18.8-1.2-2-.7-4-3.3-.5a42.3 42.3 0 00-2.3 19.2c6.2 32.3 12.5 59.1 11.5 89.8 3 0 6.3-6.7 7.8-13.3zm64.4-85.3c3.5 1.7 5.5 11.3 5.1 14-.7 5-2.5 10.4-3.8 9.7-1.5-.6.3-7.4-.4-9.5-.8-3-5.5-8.4-5-10-1-3.4 2-4.8 4.1-4.2zm-255.7 67.9c3.3 1.3 5.3 8.3 5 10.3-.8 3.7-2.5 7.7-3.8 7.1-1.3-.4.3-5.4-.3-7-.3-3.7-4.9-5.7-4.8-7.3-.8-3 2-3.5 4-3.1z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#1b9d00",
        d: "M244.9 218.2c4.2.2 6.3 3.6 2.4 5-4 1.3-7.7 2.4-7.8 8 1.5 8-2 5.2-4 4.2-2.4-1.8-9.2-6-10.2-15-.1-2.1 1.6-4 4.3-4 4 1.1 10 1.2 15.3 1.8z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#fff",
        d: "M77.4 124.4c4.8 1.4 5.1 8.6 4.8 10.7-.7 3.8-2.4 7.9-3.6 7.4-1.4-.5 0-5.7-.7-7.3-.7-2.2-4.8-6.4-4.4-7.6-.9-2.5 2-3.7 3.9-3.2zm95.9 33.6c-3.8 2-5.2 8-2.9 11.6 2.2 3 5.6 1.9 6 1.9 3.7.4 5.9-6.9 5.9-6.9s.1-2-4.2 1.9c-1.9.3-2-.4-2.5-1.4a9 9 0 01.5-5.7c.7-1.8-.7-2.6-2.8-1.4zm28-36.4c-2 1.3-5.7 5.2-5.8 9.6-.1 2.5-.6 2.5 1 4 1.3 1.8 2.4 1.7 4.8.4a5.1 5.1 0 002.3-3.4c.6-2.8-3 1.4-3.4-1.8-.8-3 1.5-4.2 3.7-7 0-2 0-3.3-2.7-1.8zm22.4 4a59.5 59.5 0 00-1.6 11.1c-.6 2.8 3 4 4.5.4 2.4-6.5 2.4-9.3 2.6-12-.7-4.3-3.6-4.2-5.5.5zm142 72.3c.4-.5 20-14.4 20-14.4 2-.7 1.5 7.2.6 7.1a77.8 77.8 0 01-20.7 14.3c-1 .7-1.9-5.3 0-7zm17.7-.2c3.5 1.7 4.9 11.8 4.5 14.5 0 5.4-3.3 9.6-4.7 9-1.4-.7.2-6.7-.5-8.8-.8-3-3.7-8.5-3.2-10.1-1-3.4 1.8-5.2 4-4.6zm-116 43.4a26 26 0 015.6-4.9c2-1 3.8.8 3.7.7.3 2-1.2 3.7-.7 6.3.4 1 .7 2.2 2.6 1.8 3.1-2.5 6-2.7 9-2.8 2.5.1 2.6 4.2 1 4.2-5.7 1.2-8.2 2.8-12.3 4.3-2 1.2-3.6-.3-3.6-.4s-1.1-1.1-.4-3.7c.2-2-.6-3.2-2.4-3-1.2.8-2.4 1.2-3-.3-.3-1-.4-1.6.5-2.2zm136.6 5.4c.8 1 1.4 2-.1 3.8l-3.7 3.2c-.6 1-1 2.8 1 3.3 3.6 1 12-4.5 12-4.6 1.4-1 1-3 .8-3-.8-.9-2.6-.3-3.8-.5-.6 0-2.5-.2-1.6-2a11.4 11.4 0 001.6-2.9c.5-1.2 0-2-2-2.7-2.1-.4-3-.2-5.3 0-1.2.2-1.6.8-1.9 2.3.1 2.3 1.5 2.2 3 3z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#259f00",
        d: "M268.1 189.7c-.5 1-2.3 1-4 0s-2.7-2.6-2.1-3.5 2.3-.9 4 0 2.6 2.6 2.1 3.5zm-89-53.6c-1 .3-2.4-.6-3-2s-.3-2.6.7-2.9 2.3.7 3 2 .3 2.7-.8 3z"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
        fill: "#209000",
        d: "M355.2 375c9.4.4 18.2 0 27.5.5 1.7 1.5.5 5-.6 4.8l-7.8-.3c-.1-3-7.7-2.5-7.5.1-4.1.5-7.8-.1-12-.3-1.2-1.5-1-4.2.4-4.8z"
      })]
    })]
  });
};
// CONCATENATED MODULE: ./src/assets/icons/flags.ts






// EXTERNAL MODULE: ./src/contexts/language/language.provider.tsx + 2 modules
var language_provider = __webpack_require__("uiyz");

// EXTERNAL MODULE: ./src/site-settings/site-navigation.ts
var site_navigation = __webpack_require__("5l48");

// CONCATENATED MODULE: ./src/layouts/header/menu/language-switcher/language-switcher.tsx











const FlagIcon = ({
  name
}) => {
  const TagName = flags_namespaceObject[name];
  return !!TagName ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(TagName, {}) : /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
    children: ["Invalid icon ", name]
  });
};

const LanguageMenu = ({
  onClick
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(jsx_runtime_["Fragment"], {
    children: site_navigation["j" /* LANGUAGE_MENU */].map(item => /*#__PURE__*/Object(jsx_runtime_["jsxs"])(MenuItem, {
      onClick: onClick,
      value: item.id,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(FlagIcon, {
          name: item.icon
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
        id: item.id,
        defaultMessage: item.defaultMessage
      })]
    }, item.id))
  });
};

const LanguageSwitcher = () => {
  const {
    locale,
    changeLanguage
  } = Object(language_provider["b" /* useLocale */])();
  const selectedLanguage = site_navigation["j" /* LANGUAGE_MENU */].find(x => x.id === locale);

  const languageChangeHandler = e => {
    changeLanguage(e.target.value);
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Box, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(popover["a" /* default */], {
      className: "right",
      handler: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(SelectedItem, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Flag, {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(FlagIcon, {
            name: selectedLanguage === null || selectedLanguage === void 0 ? void 0 : selectedLanguage.icon
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: selectedLanguage === null || selectedLanguage === void 0 ? void 0 : selectedLanguage.id,
            defaultMessage: selectedLanguage === null || selectedLanguage === void 0 ? void 0 : selectedLanguage.defaultMessage
          })
        })]
      }),
      content: /*#__PURE__*/Object(jsx_runtime_["jsx"])(LanguageMenu, {
        onClick: languageChangeHandler
      })
    })
  });
};

/* harmony default export */ var language_switcher = __webpack_exports__["a"] = (LanguageSwitcher);

/***/ }),

/***/ "TBBy":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "Td6B":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/css"
var css_ = __webpack_require__("ExBD");
var css_default = /*#__PURE__*/__webpack_require__.n(css_);

// EXTERNAL MODULE: external "styled-system"
var external_styled_system_ = __webpack_require__("4JT2");

// CONCATENATED MODULE: ./src/components/search-box/search-box.style.tsx



const StyledForm = external_styled_components_default.a.form.withConfig({
  displayName: "search-boxstyle__StyledForm",
  componentId: "x0hjfp-0"
})(props => css_default()({
  display: 'flex',
  alignItems: 'center',
  borderRadius: 'base',
  overflow: 'hidden',
  width: props.minimal ? '100%' : 700,
  color: 'text.regular',
  backgroundColor: props.minimal ? 'gray.200' : 'white',
  borderWidth: props.minimal ? '1px' : '0',
  borderStyle: 'solid',
  borderColor: props.minimal ? `gray.500` : 'white',
  input: {
    pl: props.minimal ? 0 : 20
  }
}), external_styled_system_["shadow"]);
const StyledInput = external_styled_components_default.a.input.withConfig({
  displayName: "search-boxstyle__StyledInput",
  componentId: "x0hjfp-1"
})(css_default()({
  flexGrow: 1,
  fontSize: 'base',
  pr: 20,
  height: 48,
  color: 'text.regular',
  backgroundColor: 'inherit',
  appearance: 'none'
}), {
  border: 0,
  '&:focus': {
    outline: 0
  },
  '&::-webkit-input-placeholder, &::-moz-placeholder, &::-moz-placeholder, &::-ms-input-placeholder': {
    fontSize: 'base',
    color: 'text.regular',
    whiteSpace: 'nowrap',
    textOverflow: 'ellipsis'
  }
});
const StyledCategoryName = external_styled_components_default.a.span.withConfig({
  displayName: "search-boxstyle__StyledCategoryName",
  componentId: "x0hjfp-2"
})(css_default()({
  fontSize: 14,
  fontWeight: 'bold',
  lineHeight: '38px',
  px: 15,
  color: 'primary.regular',
  backgroundColor: 'gray.200',
  borderRadius: 'base'
}), {
  margin: '5px',
  whiteSpace: 'nowrap',
  textTransform: 'capitalize'
});
const StyledSearchButton = external_styled_components_default.a.button.withConfig({
  displayName: "search-boxstyle__StyledSearchButton",
  componentId: "x0hjfp-3"
})(css_default()({
  backgroundColor: 'primary.regular',
  color: 'white',
  fontSize: 'base',
  fontWeight: 'bold'
}), {
  display: 'flex',
  height: 48,
  alignItems: 'center',
  border: 0,
  outline: 0,
  paddingLeft: 30,
  paddingRight: 30,
  cursor: 'pointer',
  flexShrink: 0
});
// EXTERNAL MODULE: ./src/assets/icons/SearchIcon.tsx
var SearchIcon = __webpack_require__("J7Kp");

// CONCATENATED MODULE: ./src/components/search-box/search-box.tsx




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const SearchBox = (_ref) => {
  let {
    onEnter,
    onChange,
    value,
    name,
    minimal,
    categoryType,
    buttonText,
    className,
    showButtonText = true,
    shadow
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["onEnter", "onChange", "value", "name", "minimal", "categoryType", "buttonText", "className", "showButtonText", "shadow"]);

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(StyledForm, {
    onSubmit: onEnter,
    className: className,
    boxShadow: shadow,
    minimal: minimal,
    children: minimal ? /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchIcon["a" /* SearchIcon */], {
        style: {
          marginLeft: 16,
          marginRight: 16,
          color: '#212121'
        }
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(StyledInput, _objectSpread({
        type: "search",
        onChange: onChange,
        value: value,
        name: name
      }, rest))]
    }) : /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(StyledCategoryName, {
        children: categoryType
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(StyledInput, _objectSpread({
        type: "search",
        onChange: onChange,
        value: value,
        name: name
      }, rest)), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(StyledSearchButton, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchIcon["a" /* SearchIcon */], {
          style: {
            marginRight: 10
          }
        }), showButtonText && buttonText]
      })]
    })
  });
};
// EXTERNAL MODULE: ./src/contexts/app/app.provider.ts + 2 modules
var app_provider = __webpack_require__("xZKy");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// CONCATENATED MODULE: ./src/features/search/search.tsx


function search_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function search_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { search_ownKeys(Object(source), true).forEach(function (key) { search_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { search_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function search_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function search_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = search_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function search_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const Search = (_ref) => {
  let {
    onSubmit
  } = _ref,
      props = search_objectWithoutProperties(_ref, ["onSubmit"]);

  const searchTerm = Object(app_provider["c" /* useAppState */])('searchTerm');
  const dispatch = Object(app_provider["b" /* useAppDispatch */])();
  const router = Object(router_["useRouter"])();
  const intl = Object(external_react_intl_["useIntl"])();

  const handleOnChange = e => {
    const {
      value
    } = e.target;
    dispatch({
      type: 'SET_SEARCH_TERM',
      payload: value
    });
  };

  const {
    pathname,
    query
  } = router;

  const onSearch = e => {
    e.preventDefault();

    const {
      type
    } = query,
          rest = search_objectWithoutProperties(query, ["type"]);

    if (type) {
      router.push({
        pathname,
        query: search_objectSpread(search_objectSpread({}, rest), {}, {
          text: searchTerm
        })
      }, {
        pathname: `/${type}`,
        query: search_objectSpread(search_objectSpread({}, rest), {}, {
          text: searchTerm
        })
      });
    } else {
      router.push({
        pathname,
        query: search_objectSpread(search_objectSpread({}, rest), {}, {
          text: searchTerm
        })
      });
    }

    dispatch({
      type: 'SET_SEARCH_TERM',
      payload: ''
    });

    if (onSubmit) {
      onSubmit();
    }
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchBox, search_objectSpread({
    onEnter: onSearch,
    onChange: handleOnChange,
    value: searchTerm,
    name: "search",
    placeholder: intl.formatMessage({
      id: 'searchPlaceholder',
      defaultMessage: 'Search your products from here'
    }),
    categoryType: query.type || 'bakery',
    buttonText: intl.formatMessage({
      id: 'searchButtonText',
      defaultMessage: 'Search'
    })
  }, props));
};

/* harmony default export */ var search = __webpack_exports__["a"] = (Search);

/***/ }),

/***/ "VnWI":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Input; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Dtiu");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ExBD");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("4JT2");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_2__);



const Input = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.input.withConfig({
  displayName: "input__Input",
  componentId: "sc-9r8pxt-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'block',
  width: '100%',
  p: '0 18px',
  appearance: 'none',
  fontFamily: 'body',
  fontSize: 'base',
  lineHeight: 'inherit',
  border: '1px solid',
  borderColor: 'gray.500',
  borderRadius: 'base',
  backgroundColor: 'white',
  color: 'text.bold',
  height: '48px',
  transition: 'all 0.25s ease',
  // mb: 3,
  '&:focus': {
    borderColor: 'primary.regular'
  }
}), {
  '&:hover,&:focus': {
    outline: 0
  },
  '&::placeholder': {
    color: ''
  },
  '&::-webkit-inner-spin-button,&::-webkit-outer-spin-button': {
    '-webkit-appearance': 'none',
    margin: 0
  },
  '&.disabled': {
    cursor: 'not-allowed',
    opacity: 0.6
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["compose"])(styled_system__WEBPACK_IMPORTED_MODULE_2__["layout"], styled_system__WEBPACK_IMPORTED_MODULE_2__["space"], styled_system__WEBPACK_IMPORTED_MODULE_2__["color"], styled_system__WEBPACK_IMPORTED_MODULE_2__["border"]));

/***/ }),

/***/ "WEnL":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/dynamic"
var dynamic_ = __webpack_require__("/T1H");
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: external "react-stickynode"
var external_react_stickynode_ = __webpack_require__("isz7");
var external_react_stickynode_default = /*#__PURE__*/__webpack_require__.n(external_react_stickynode_);

// EXTERNAL MODULE: ./src/contexts/app/app.provider.ts + 2 modules
var app_provider = __webpack_require__("xZKy");

// EXTERNAL MODULE: external "@redq/reuse-modal"
var reuse_modal_ = __webpack_require__("qbum");

// EXTERNAL MODULE: ./src/contexts/auth/auth.context.tsx
var auth_context = __webpack_require__("QfjN");

// EXTERNAL MODULE: ./src/features/authentication-form/index.tsx + 5 modules
var authentication_form = __webpack_require__("kp67");

// EXTERNAL MODULE: ./src/components/nav-link/nav-link.tsx
var nav_link = __webpack_require__("Ek28");

// EXTERNAL MODULE: ./src/site-settings/site-navigation.ts
var site_navigation = __webpack_require__("5l48");

// EXTERNAL MODULE: ./src/layouts/header/menu/language-switcher/language-switcher.tsx + 8 modules
var language_switcher = __webpack_require__("PsoQ");

// CONCATENATED MODULE: ./src/assets/icons/HelpIcon.tsx


const HelpIcon = ({
  color = 'currentColor',
  width = '14px',
  height = '14px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 14 14",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      id: "Path_111",
      "data-name": "Path 111",
      d: "M269.443,404.312a7,7,0,1,0,7,7,6.98,6.98,0,0,0-7-7Zm.635,10.818a.3.3,0,0,1-.319.319h-.635a.3.3,0,0,1-.319-.319v-.635a.3.3,0,0,1,.319-.319h.635a.3.3,0,0,1,.319.319Zm.859-2.832c-.446.382-.763.637-.859.987a.308.308,0,0,1-.319.255h-.635a.309.309,0,0,1-.319-.35,2.988,2.988,0,0,1,1.336-1.876c.574-.446.892-.732.892-1.274a1.591,1.591,0,1,0-3.182,0v.191a.3.3,0,0,1-.224.351l-.6.189a.318.318,0,0,1-.414-.253,2.363,2.363,0,0,1-.033-.479,2.864,2.864,0,0,1,5.729,0,2.792,2.792,0,0,1-1.369,2.259Zm0,0",
      transform: "translate(-262.442 -404.312)",
      fill: color
    })
  });
};
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/theme-get"
var theme_get_ = __webpack_require__("/JeY");

// CONCATENATED MODULE: ./src/layouts/header/menu/right-menu/right-menu.style.tsx


const RightMenuBox = external_styled_components_default.a.div.withConfig({
  displayName: "right-menustyle__RightMenuBox",
  componentId: "iej1sk-0"
})(["display:flex;align-items:center;flex-shrink:0;.menu-icon{min-width:14px;margin-right:7px;}.menu-item{a{font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;display:block;transition:0.15s ease-in-out;display:flex;align-items:center;margin-right:45px;@media (max-width:1400px){margin-right:35px;font-size:", "px;}&:hover{color:", ";}&.current-page{color:", ";}}}.user-pages-dropdown{.popover-handler{width:38px;height:38px;border-radius:50%;display:block;overflow:hidden;img{width:100%;height:auto;display:block;}}.popover-content{.inner-wrap{}}}"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.text.bold', '#0D1136'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
// CONCATENATED MODULE: ./src/layouts/header/menu/right-menu/right-menu.tsx









const AuthMenu = dynamic_default()(() => __webpack_require__.e(/* import() */ 45).then(__webpack_require__.bind(null, "IQ03")), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/("IQ03")],
    modules: ['../auth-menu']
  }
});
const RightMenu = ({
  onLogout,
  avatar,
  isAuthenticated,
  onJoin
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(RightMenuBox, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(nav_link["a" /* default */], {
      className: "menu-item",
      href: site_navigation["n" /* OFFER_MENU_ITEM */].href,
      label: site_navigation["n" /* OFFER_MENU_ITEM */].defaultMessage,
      intlId: site_navigation["n" /* OFFER_MENU_ITEM */].id
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(nav_link["a" /* default */], {
      className: "menu-item",
      href: site_navigation["h" /* HELP_MENU_ITEM */].href,
      label: site_navigation["h" /* HELP_MENU_ITEM */].defaultMessage,
      intlId: site_navigation["h" /* HELP_MENU_ITEM */].id,
      iconClass: "menu-icon",
      icon: /*#__PURE__*/Object(jsx_runtime_["jsx"])(HelpIcon, {})
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(language_switcher["a" /* default */], {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(AuthMenu, {
      avatar: avatar,
      onJoin: onJoin,
      onLogout: onLogout,
      isAuthenticated: isAuthenticated
    })]
  });
};
// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// EXTERNAL MODULE: ./src/components/popover/popover.tsx + 2 modules
var popover = __webpack_require__("63jn");

// EXTERNAL MODULE: ./src/layouts/logo/logo.tsx + 1 modules
var logo_logo = __webpack_require__("9T+x");

// CONCATENATED MODULE: ./src/assets/icons/MenuDown.tsx


const MenuDown = ({
  color = 'currentColor',
  width = '12px',
  height = '6px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 6",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      id: "Path_2897",
      "data-name": "Path 2897",
      d: "M0,63.75l6,6,6-6Z",
      transform: "translate(0 -63.75)",
      fill: color
    })
  });
};
// EXTERNAL MODULE: ./src/assets/icons/category-menu-icons.ts + 7 modules
var category_menu_icons = __webpack_require__("KRoA");

// CONCATENATED MODULE: ./src/layouts/header/menu/left-menu/left-menu.style.tsx


const LeftMenuBox = external_styled_components_default.a.div.withConfig({
  displayName: "left-menustyle__LeftMenuBox",
  componentId: "sc-155ois-0"
})(["display:flex;align-items:center;justify-content:space-between;flex-shrink:0;"]);
const MainMenu = external_styled_components_default.a.div.withConfig({
  displayName: "left-menustyle__MainMenu",
  componentId: "sc-155ois-1"
})(["display:flex;align-items:center;"]);
const IconWrapper = external_styled_components_default.a.span.withConfig({
  displayName: "left-menustyle__IconWrapper",
  componentId: "sc-155ois-2"
})(["display:flex;align-items:center;justify-content:center;width:24px;margin-right:15px;"]);
const MenuItem = external_styled_components_default.a.button.withConfig({
  displayName: "left-menustyle__MenuItem",
  componentId: "sc-155ois-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1.2em;white-space:nowrap;display:block;padding:12px 30px;border-radius:", ";transition:0.15s ease-in-out;display:flex;align-items:center;background-color:transparent;border:0;outline:0;cursor:pointer;svg{min-width:15px;max-width:20px;max-height:19px;}&:focus{outline:0;box-shadow:none;}@media (max-width:1400px){margin-right:10px;font-size:", "px;}@media only screen and (min-width:991px) and (max-width:1200px){padding:15px 30px;}&:hover{color:", ";}&.current-page{color:", ";background-color:#fff;}"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.text.bold', '#0D1136'), Object(theme_get_["themeGet"])('radii.base', '6px'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
const SelectedItem = external_styled_components_default.a.button.withConfig({
  displayName: "left-menustyle__SelectedItem",
  componentId: "sc-155ois-4"
})(["width:auto;height:38px;display:flex;align-items:center;background-color:", ";border:1px solid ", ";padding-top:0;padding-bottom:0;padding-left:15px;padding-right:15px;border-radius:", ";outline:0;min-width:150px;cursor:pointer;svg{min-width:15px;max-width:20px;max-height:19px;}span{display:flex;align-items:center;font-family:", ";font-size:", "px;font-weight:", ";color:", ";text-decoration:none;&:first-child{margin-right:auto;}}"], Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('colors.gray.500', '#f1f1f1'), Object(theme_get_["themeGet"])('radii.base', '6px'), Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
const Icon = external_styled_components_default.a.div.withConfig({
  displayName: "left-menustyle__Icon",
  componentId: "sc-155ois-5"
})(["margin-right:7px;display:flex;align-items:center;justify-content:center;min-width:16px;"]);
const Arrow = external_styled_components_default.a.span.withConfig({
  displayName: "left-menustyle__Arrow",
  componentId: "sc-155ois-6"
})(["width:12px;margin-left:16px;"]);
// CONCATENATED MODULE: ./src/layouts/header/menu/left-menu/left-menu.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const CategoryIcon = ({
  name
}) => {
  const TagName = category_menu_icons[name];
  return !!TagName ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(TagName, {}) : /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
    children: ["Invalid icon ", name]
  });
};

const CategoryMenu = props => {
  const handleOnClick = item => {
    if (item.dynamic) {
      router_default.a.push('/[type]', `${item.href}`);
      props.onClick(item);
      return;
    }

    router_default.a.push(`${item.href}`);
    props.onClick(item);
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    },
    children: site_navigation["d" /* CATEGORY_MENU_ITEMS */].map(item => /*#__PURE__*/Object(jsx_runtime_["jsxs"])(MenuItem, _objectSpread(_objectSpread({}, props), {}, {
      onClick: () => handleOnClick(item),
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(IconWrapper, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CategoryIcon, {
          name: item.icon
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
        id: item.id,
        defaultMessage: item.defaultMessage
      })]
    }), item.id))
  });
};

const LeftMenu = ({
  logo
}) => {
  const router = Object(router_["useRouter"])();
  const initialMenu = site_navigation["d" /* CATEGORY_MENU_ITEMS */].find(item => item.href === router.asPath);
  const [activeMenu, setActiveMenu] = external_react_default.a.useState(initialMenu !== null && initialMenu !== void 0 ? initialMenu : site_navigation["d" /* CATEGORY_MENU_ITEMS */][0]);
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(LeftMenuBox, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(logo_logo["a" /* default */], {
      imageUrl: logo,
      alt: 'Shop Logo',
      onClick: () => setActiveMenu(site_navigation["d" /* CATEGORY_MENU_ITEMS */][0])
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(MainMenu, {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(popover["a" /* default */], {
        className: "right",
        handler: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(SelectedItem, {
          children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("span", {
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Icon, {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CategoryIcon, {
                name: activeMenu === null || activeMenu === void 0 ? void 0 : activeMenu.icon
              })
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
                id: activeMenu === null || activeMenu === void 0 ? void 0 : activeMenu.id,
                defaultMessage: activeMenu === null || activeMenu === void 0 ? void 0 : activeMenu.defaultMessage
              })
            })]
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Arrow, {
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(MenuDown, {})
          })]
        }),
        content: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CategoryMenu, {
          onClick: setActiveMenu
        })
      })
    })]
  });
};
// EXTERNAL MODULE: ./src/layouts/header/header.style.tsx
var header_style = __webpack_require__("HPEz");

// EXTERNAL MODULE: ./src/assets/images/logo.png
var images_logo = __webpack_require__("nWR2");
var logo_default = /*#__PURE__*/__webpack_require__.n(images_logo);

// EXTERNAL MODULE: ./src/assets/images/user.jpg
var user = __webpack_require__("OBDI");

// EXTERNAL MODULE: ./src/layouts/is-home-page.ts
var is_home_page = __webpack_require__("hp67");

// EXTERNAL MODULE: ./src/features/search/search.tsx + 2 modules
var search = __webpack_require__("Td6B");

// CONCATENATED MODULE: ./src/layouts/header/header.tsx















const Header = ({
  className
}) => {
  const {
    authState: {
      isAuthenticated
    },
    authDispatch
  } = external_react_default.a.useContext(auth_context["a" /* AuthContext */]);
  const {
    pathname,
    query
  } = Object(router_["useRouter"])();

  const handleLogout = () => {
    if (false) {}
  };

  const handleJoin = () => {
    authDispatch({
      type: 'SIGNIN'
    });
    Object(reuse_modal_["openModal"])({
      show: true,
      overlayClassName: 'quick-view-overlay',
      closeOnClickOutside: true,
      component: authentication_form["a" /* default */],
      closeComponent: '',
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'quick-view-modal',
        width: 458,
        height: 'auto'
      }
    });
  };

  const showSearch = Object(is_home_page["a" /* isCategoryPage */])(query.type) || pathname === '/furniture-two' || pathname === '/grocery-two' || pathname === '/bakery';
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["t" /* default */], {
    className: className,
    id: "layout-header",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(LeftMenu, {
      logo: logo_default.a
    }), showSearch && /*#__PURE__*/Object(jsx_runtime_["jsx"])(search["a" /* default */], {
      minimal: true,
      className: "headerSearch"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(RightMenu, {
      isAuthenticated: isAuthenticated,
      onJoin: handleJoin,
      onLogout: handleLogout,
      avatar: user["a" /* default */]
    })]
  });
};

/* harmony default export */ var header = (Header);
// CONCATENATED MODULE: ./src/layouts/layout.style.tsx


const LayoutWrapper = external_styled_components_default.a.div.withConfig({
  displayName: "layoutstyle__LayoutWrapper",
  componentId: "sc-1bo13ya-0"
})(["background-color:", ";@media (max-width:990px){background-color:", ";}.reuseModalHolder{padding:0;overflow:auto;border-radius:", " ", " 0 0;border:0;}"], Object(theme_get_["themeGet"])('colors.gray.200', '#F7F7F7'), Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('radii.small', '3px'), Object(theme_get_["themeGet"])('radii.small', '3px'));
// CONCATENATED MODULE: ./src/layouts/header/category.style.tsx


const positionAnim = Object(external_styled_components_["keyframes"])(["from{position:fixed;opacity:1;transform:translateY(0%)}to{opacity:0;transform:translateY(100%) transition:all 0.3s ease;}"]);
const CatsMenu = external_styled_components_default.a.div.withConfig({
  displayName: "categorystyle__CatsMenu",
  componentId: "sc-1ockjjy-0"
})(["width:100%;height:auto;border-bottom-right-radius:4px;border-bottom-left-radius:4px;position:absolute;top:90px;background:white;box-shadow:0px 27px 44px -24px #000;&.unSticky{opacity:0;animation:", " 0.3s ease;}&.sticky{background-color:", ";position:fixed;box-shadow:", ";padding-top:20px;padding-bottom:20px;transition:all 0.3s ease;@media (max-width:1400px){padding-top:20px;padding-bottom:20px;}}"], positionAnim, Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('shadows.header', '0 1px 2px rgba(0, 0, 0, 0.06)'));
const CatsNav = external_styled_components_default.a.ul.withConfig({
  displayName: "categorystyle__CatsNav",
  componentId: "sc-1ockjjy-1"
})(["width:100%;display:flex;justify-content:flex-start;align-items:center;padding:20px;"]);
const Catsli = external_styled_components_default.a.li.withConfig({
  displayName: "categorystyle__Catsli",
  componentId: "sc-1ockjjy-2"
})(["margin:5px;cursor:pointer;padding:3px;color:#000;font-weight:bold;&.active{color:#F39C12;}"]);
// CONCATENATED MODULE: ./src/layouts/header/CatsLi.tsx




const CatsLi = ({
  Label,
  className
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Catsli, {
    className: className,
    children: Label
  });
};

/* harmony default export */ var header_CatsLi = (CatsLi);
// CONCATENATED MODULE: ./src/layouts/header/category.tsx






const CategoryHeader = ({
  className
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(CatsMenu, {
    className: className,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(CatsNav, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_CatsLi, {
        className: "active",
        Label: "All Categories"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_CatsLi, {
        Label: "Fruits"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_CatsLi, {
        Label: "Vegetables"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_CatsLi, {
        Label: "Technicals"
      })]
    })
  });
};

/* harmony default export */ var category = (CategoryHeader);
// CONCATENATED MODULE: ./src/layouts/app-layout.tsx











const MobileHeader = dynamic_default()(() => __webpack_require__.e(/* import() */ 39).then(__webpack_require__.bind(null, "UTRa")), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/("UTRa")],
    modules: ['./header/mobile-header']
  }
});

const Layout = ({
  className,
  children,
  // deviceType: { mobile, tablet, desktop },
  token
}) => {
  const {
    pathname,
    query
  } = Object(router_["useRouter"])();
  const isSticky = Object(app_provider["c" /* useAppState */])('isSticky') || pathname === '/furniture-two' || pathname === '/grocery-two';
  const isHomePage = Object(is_home_page["a" /* isCategoryPage */])(query.type) || pathname === '/bakery';
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(LayoutWrapper, {
    className: `layoutWrapper ${className}`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_stickynode_default.a, {
      enabled: isSticky,
      innerZ: 1001,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(MobileHeader, {
        className: `${isSticky ? 'sticky' : 'unSticky'} ${isHomePage ? 'home' : ''} desktop`
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header, {
        className: `${isSticky ? 'sticky' : 'unSticky'} ${isHomePage ? 'home' : ''}`
      }), isHomePage ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(category, {
        className: `${isSticky ? 'sticky' : 'unSticky'}`
      }) : ""]
    }), children]
  });
};

/* harmony default export */ var app_layout = __webpack_exports__["default"] = (Layout);

/***/ }),

/***/ "Y3ZS":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "YBsB":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "Ycay":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("Y3ZS");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__("UhrY"));

var _requestIdleCallback = __webpack_require__("ZeW2"); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // Resolve a promise that times out after given amount of milliseconds.


function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject);
    (0, _requestIdleCallback.requestIdleCallback)(() => setTimeout(() => {
      if (!cancelled) {
        reject(err);
      }
    }, ms));
  });
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (false) {}

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route) {
      return withFuture(route, routes, async () => {
        try {
          const {
            scripts,
            css
          } = await getFilesForRoute(assetPrefix, route);
          const [, styles] = await Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
          const entrypoint = await resolvePromiseWithTimeout(this.whenEntrypoint(route), MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`)));
          const res = Object.assign({
            styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        } catch (err) {
          return {
            error: err
          };
        }
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.requestIdleCallback)(() => this.loadRoute(route));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "ZeW2":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "ZsnT":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "cIWs":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

function resolveRewrites() {}

/***/ }),

/***/ "fvxO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__("BOBJ");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (false) { var _App$prototype; } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (false) {}

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "hp67":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return isCategoryPage; });
/* harmony import */ var site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5l48");

const arr = [site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* HOME_PAGE */ "i"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* GROCERY_PAGE */ "g"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* CLOTHING_PAGE */ "e"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* MAKEUP_PAGE */ "k"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* BAGS_PAGE */ "b"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* FURNITURE_PAGE */ "f"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* BOOK_PAGE */ "c"], site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_0__[/* MEDICINE_PAGE */ "l"]];
function isCategoryPage(pathname) {
  return arr.includes(`/${pathname}`);
}

/***/ }),

/***/ "i2RQ":
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "jvFD":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("KeDb")


/***/ }),

/***/ "kp67":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ AuthenticationForm; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/theme-get"
var theme_get_ = __webpack_require__("/JeY");

// EXTERNAL MODULE: ./src/components/button/button.tsx
var button_button = __webpack_require__("B68Z");

// CONCATENATED MODULE: ./src/features/authentication-form/authentication-form.style.tsx




const IconWrapper = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__IconWrapper",
  componentId: "sc-92tj4w-0"
})(["display:flex;margin-right:6px;"]);
const Wrapper = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__Wrapper",
  componentId: "sc-92tj4w-1"
})(["text-align:center;background-color:", ";"], Object(theme_get_["themeGet"])('colors.white', '#ffffff'));
const Container = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__Container",
  componentId: "sc-92tj4w-2"
})(["padding:40px 60px 0;@media (max-width:768px){padding:40px 30px 0;}"]);
const LogoWrapper = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__LogoWrapper",
  componentId: "sc-92tj4w-3"
})(["margin-bottom:30px;img{max-width:160px;}"]);
const Heading = external_styled_components_default.a.h3.withConfig({
  displayName: "authentication-formstyle__Heading",
  componentId: "sc-92tj4w-4"
})(["margin-bottom:10px;font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(theme_get_["themeGet"])('fonts.heading', 'sans-serif'), Object(theme_get_["themeGet"])('fontSizes.lg', '21'), Object(theme_get_["themeGet"])('fontWeights.semiBold', '600'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
const SubHeading = external_styled_components_default.a.span.withConfig({
  displayName: "authentication-formstyle__SubHeading",
  componentId: "sc-92tj4w-5"
})(["margin-bottom:30px;font-family:", ";font-size:", "px;font-weight:", ";color:", ";display:block;"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.regular', '400'), Object(theme_get_["themeGet"])('colors.text.regular', '#77798c'));
const OfferSection = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__OfferSection",
  componentId: "sc-92tj4w-6"
})(["padding:20px;background-color:", ";color:", ";display:flex;justify-content:center;align-items:center;"], Object(theme_get_["themeGet"])('colors.gray.200', '#F7F7F7'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
const Offer = external_styled_components_default.a.p.withConfig({
  displayName: "authentication-formstyle__Offer",
  componentId: "sc-92tj4w-7"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0;"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.regular', '400'), Object(theme_get_["themeGet"])('colors.text.regular', '#77798c'));
const HelperText = external_styled_components_default.a.p.withConfig({
  displayName: "authentication-formstyle__HelperText",
  componentId: "sc-92tj4w-8"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0;text-align:center;width:100%;a{font-weight:", ";color:", ";text-decoration:underline;}"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.sm', '13'), Object(theme_get_["themeGet"])('fontWeights.regular', '400'), Object(theme_get_["themeGet"])('colors.text.regular', '#77798c'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.blue.link', '#4285f4')); // export const Input = styled.input`
//   width: 100%;
//   height: 48px;
//   border-radius: ${themeGet('radii.base', '6px')};
//   background-color: ${themeGet('colors.gray.200', '#f7f7f7')};
//   border: 1px solid ${themeGet('colors.gray.700', '#e6e6e6')};
//   font-family: ${themeGet('fonts.body', 'Lato')};
//   font-size: ${themeGet('fontSizes.base', '15')}px;
//   font-weight: ${themeGet('fontWeights.regular', '400')};
//   color: ${themeGet('colors.text.bold', '#0D1136')};
//   line-height: 19px;
//   padding: 0 18px;
//   box-sizing: border-box;
//   transition: border-color 0.25s ease;
//   margin-bottom: 10px;
//   &:hover,
//   &:focus {
//     outline: 0;
//   }
//   &:focus {
//     border-color: ${themeGet('colors.primary.regular', '#F39C12')};
//   }
//   &::placeholder {
//     color: ${themeGet('colors.text.regular', '#77798c')};
//     font-size: calc(${themeGet('fontSizes.base', '15')}px + 1px);
//   }
//   &::-webkit-inner-spin-button,
//   &::-webkit-outer-spin-button {
//     -webkit-appearance: none;
//     margin: 0;
//   }
//   &.disabled {
//     .inner-wrap {
//       cursor: not-allowed;
//       opacity: 0.6;
//     }
//   }
// `;

const Divider = external_styled_components_default.a.div.withConfig({
  displayName: "authentication-formstyle__Divider",
  componentId: "sc-92tj4w-9"
})(["padding:15px 0;width:100%;display:flex;justify-content:center;align-items:center;position:relative;span{font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1;background-color:", ";z-index:1;position:relative;padding:0 10px;}&::before{content:'';width:100%;height:1px;background-color:", ";position:absolute;top:50%;}"], Object(theme_get_["themeGet"])('fonts.body', 'Lato'), Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.regular', '400'), Object(theme_get_["themeGet"])('colors.text.bold', '#0D1136'), Object(theme_get_["themeGet"])('colors.white', '#ffffff'), Object(theme_get_["themeGet"])('colors.gray.500', '#f1f1f1'));
const LinkButton = external_styled_components_default.a.button.withConfig({
  displayName: "authentication-formstyle__LinkButton",
  componentId: "sc-92tj4w-10"
})(["background-color:transparent;border:0;outline:0;box-shadow:none;padding:0;font-size:calc(", "px - 1px);font-weight:", ";color:", ";text-decoration:underline;cursor:pointer;"], Object(theme_get_["themeGet"])('fontSizes.base', '15'), Object(theme_get_["themeGet"])('fontWeights.bold', '700'), Object(theme_get_["themeGet"])('colors.primary.regular', '#F39C12'));
// EXTERNAL MODULE: ./src/assets/icons/Facebook.tsx
var Facebook = __webpack_require__("lJ4R");

// CONCATENATED MODULE: ./src/assets/icons/Google.tsx


const Google = ({
  color = 'currentColor',
  width = '17px',
  height = '17px'
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 16.677 17",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M68.579,55.29l-.086-.364H60.584v3.348h4.725a4.73,4.73,0,0,1-4.627,3.556,5.533,5.533,0,0,1-3.724-1.484,5.316,5.316,0,0,1-1.586-3.752,5.483,5.483,0,0,1,1.557-3.748,5.3,5.3,0,0,1,3.7-1.447,4.825,4.825,0,0,1,3.147,1.226l2.379-2.367a8.417,8.417,0,0,0-5.6-2.158A8.391,8.391,0,0,0,52,56.6,8.541,8.541,0,0,0,54.326,62.5a8.873,8.873,0,0,0,6.4,2.6,7.891,7.891,0,0,0,5.747-2.416,8.486,8.486,0,0,0,2.207-5.878,9.788,9.788,0,0,0-.1-1.516Z",
      transform: "translate(-52 -48.1)",
      fill: color
    })
  });
};
// EXTERNAL MODULE: ./src/contexts/auth/auth.context.tsx
var auth_context = __webpack_require__("QfjN");

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// EXTERNAL MODULE: external "@redq/reuse-modal"
var reuse_modal_ = __webpack_require__("qbum");

// EXTERNAL MODULE: ./src/components/forms/input.tsx
var input = __webpack_require__("VnWI");

// CONCATENATED MODULE: ./src/features/authentication-form/login.tsx










function SignInModal() {
  const intl = Object(external_react_intl_["useIntl"])();
  const {
    authDispatch
  } = Object(external_react_["useContext"])(auth_context["a" /* AuthContext */]);
  const [email, setEmail] = external_react_default.a.useState('');
  const [password, setPassword] = external_react_default.a.useState('');

  const toggleSignUpForm = () => {
    authDispatch({
      type: 'SIGNUP'
    });
  };

  const toggleForgotPassForm = () => {
    authDispatch({
      type: 'FORGOTPASS'
    });
  };

  const loginCallback = () => {
    if (false) {}
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Wrapper, {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Heading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "welcomeBack",
          defaultMessage: "Welcome Back"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(SubHeading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "loginText",
          defaultMessage: "Login with your email & password"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
        onSubmit: loginCallback,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(input["a" /* Input */], {
          type: "email",
          placeholder: intl.formatMessage({
            id: 'emailAddressPlaceholder',
            defaultMessage: 'Email Address.'
          }),
          value: email,
          onChange: e => setEmail(e.target.value),
          required: true,
          height: "48px",
          backgroundColor: "#F7F7F7",
          mb: "10px"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(input["a" /* Input */], {
          type: "password",
          placeholder: intl.formatMessage({
            id: 'passwordPlaceholder',
            defaultMessage: 'Password (min 6 characters)'
          }),
          value: password,
          onChange: e => setPassword(e.target.value),
          required: true,
          height: "48px",
          backgroundColor: "#F7F7F7",
          mb: "10px"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(button_button["a" /* Button */], {
          variant: "primary",
          size: "big",
          style: {
            width: '100%'
          },
          type: "submit",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "continueBtn",
            defaultMessage: "Continue"
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Divider, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "orText",
            defaultMessage: "or"
          })
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        style: {
          width: '100%',
          backgroundColor: '#4267b2',
          marginBottom: 10
        },
        onClick: loginCallback,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(IconWrapper, {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Facebook["a" /* Facebook */], {})
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "continueFacebookBtn",
          defaultMessage: "Continue with Facebook"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        style: {
          width: '100%',
          backgroundColor: '#4285f4'
        },
        onClick: loginCallback,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(IconWrapper, {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Google, {})
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "continueGoogleBtn",
          defaultMessage: "Continue with Google"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Offer, {
        style: {
          padding: '20px 0'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "dontHaveAccount",
          defaultMessage: "Don't have any account?"
        }), ' ', /*#__PURE__*/Object(jsx_runtime_["jsx"])(LinkButton, {
          onClick: toggleSignUpForm,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "signUpBtnText",
            defaultMessage: "Sign Up"
          })
        })]
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(OfferSection, {
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Offer, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "forgotPasswordText",
          defaultMessage: "Forgot your password?"
        }), ' ', /*#__PURE__*/Object(jsx_runtime_["jsx"])(LinkButton, {
          onClick: toggleForgotPassForm,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "resetText",
            defaultMessage: "Reset It"
          })
        })]
      })
    })]
  });
}
// EXTERNAL MODULE: D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/link.js
var next_link = __webpack_require__("jvFD");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// CONCATENATED MODULE: ./src/features/authentication-form/register.tsx










function SignOutModal() {
  const intl = Object(external_react_intl_["useIntl"])();
  const {
    authDispatch
  } = Object(external_react_["useContext"])(auth_context["a" /* AuthContext */]);

  const toggleSignInForm = () => {
    authDispatch({
      type: 'SIGNIN'
    });
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Wrapper, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Heading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "signUpBtnText",
          defaultMessage: "Sign Up"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(SubHeading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "signUpText",
          defaultMessage: "Every fill is required in sign up"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(input["a" /* Input */], {
        type: "text",
        placeholder: intl.formatMessage({
          id: 'emailAddressPlaceholder',
          defaultMessage: 'Email Address or Contact No.'
        }),
        height: "48px",
        backgroundColor: "#F7F7F7",
        mb: "10px"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(input["a" /* Input */], {
        type: "email",
        placeholder: intl.formatMessage({
          id: 'passwordPlaceholder',
          defaultMessage: 'Password (min 6 characters)'
        }),
        height: "48px",
        backgroundColor: "#F7F7F7",
        mb: "10px"
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(HelperText, {
        style: {
          padding: '20px 0 30px'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "signUpText",
          defaultMessage: "By signing up, you agree to Pickbazar's"
        }), "\xA0", /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
          href: "/",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
              id: "termsConditionText",
              defaultMessage: "Terms & Condition"
            })
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        width: "100%",
        type: "submit",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "continueBtn",
          defaultMessage: "Continue"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Divider, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "orText",
            defaultMessage: "or"
          })
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        style: {
          width: '100%',
          backgroundColor: '#4267b2',
          marginBottom: 10
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(IconWrapper, {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Facebook["a" /* Facebook */], {})
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "continueFacebookBtn",
          defaultMessage: "Continue with Facebook"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        style: {
          width: '100%',
          backgroundColor: '#4285f4'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(IconWrapper, {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Google, {})
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "continueGoogleBtn",
          defaultMessage: "Continue with Google"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Offer, {
        style: {
          padding: '20px 0'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "alreadyHaveAccount",
          defaultMessage: "Already have an account?"
        }), ' ', /*#__PURE__*/Object(jsx_runtime_["jsx"])(LinkButton, {
          onClick: toggleSignInForm,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "loginBtnText",
            defaultMessage: "Login"
          })
        })]
      })]
    })
  });
}
// CONCATENATED MODULE: ./src/features/authentication-form/forgot-password.tsx







function ForgotPasswordModal() {
  const {
    authDispatch
  } = Object(external_react_["useContext"])(auth_context["a" /* AuthContext */]);
  const intl = Object(external_react_intl_["useIntl"])();

  const toggleSignInForm = () => {
    authDispatch({
      type: 'SIGNIN'
    });
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Wrapper, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Container, {
      style: {
        paddingBottom: 30
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Heading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "forgotPassText",
          defaultMessage: "Forgot Password"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(SubHeading, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "sendResetPassText",
          defaultMessage: "We'll send you a link to reset your password"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(input["a" /* Input */], {
        type: "text",
        placeholder: intl.formatMessage({
          id: 'emailAddressPlaceholder',
          defaultMessage: 'Email Address or Contact No.'
        }),
        height: "48px",
        backgroundColor: "#F7F7F7",
        mb: "10px"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(button_button["a" /* Button */], {
        variant: "primary",
        size: "big",
        style: {
          width: '100%'
        },
        type: "submit",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "resetPasswordBtn",
          defaultMessage: "Reset Password"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(Offer, {
        style: {
          padding: '20px 0 0'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
          id: "backToSign",
          defaultMessage: "Back to"
        }), ' ', /*#__PURE__*/Object(jsx_runtime_["jsx"])(LinkButton, {
          onClick: toggleSignInForm,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "loginBtnText",
            defaultMessage: "Login"
          })
        })]
      })]
    })
  });
}
// CONCATENATED MODULE: ./src/features/authentication-form/index.tsx






function AuthenticationForm() {
  const {
    authState
  } = Object(external_react_["useContext"])(auth_context["a" /* AuthContext */]);
  let RenderForm;

  if (authState.currentForm === 'signIn') {
    RenderForm = SignInModal;
  }

  if (authState.currentForm === 'signUp') {
    RenderForm = SignOutModal;
  }

  if (authState.currentForm === 'forgotPass') {
    RenderForm = ForgotPasswordModal;
  }

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(RenderForm, {});
}

/***/ }),

/***/ "lJ4R":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Facebook; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Facebook = ({
  color = 'currentColor',
  width = '17px',
  height = '17px'
}) => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 17 17",
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
      "data-name": "_ionicons_svg_logo-facebook (1)",
      d: "M80.061,64H64.939a.939.939,0,0,0-.939.939V80.061a.939.939,0,0,0,.939.939H72.5V74.271H70.468V71.792H72.5V69.959a3.23,3.23,0,0,1,3.484-3.391c.939,0,1.948.071,2.183.1v2.293H76.6c-1.067,0-1.271.5-1.271,1.248v1.58h2.541l-.332,2.479H75.333V81h4.728A.939.939,0,0,0,81,80.061V64.939A.939.939,0,0,0,80.061,64Z",
      transform: "translate(-64 -64)",
      fill: color
    })
  });
};

/***/ }),

/***/ "nWR2":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/logo-07bec8170d477e42e4f914c713bf0ce9.png";

/***/ }),

/***/ "pONU":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("i2RQ");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "pQO/":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FruitsVegetable; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FruitsVegetable = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20.347",
    height: "24.101",
    viewBox: "0 0 20.347 24.101"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("g", {
      id: "Grocery",
      transform: "translate(-39.481 0.052)",
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
        id: "Path_17386",
        "data-name": "Path 17386",
        d: "M349.261,399.988a.469.469,0,1,1,.461-.385A.473.473,0,0,1,349.261,399.988Z",
        transform: "translate(-294.289 -380.346)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
        id: "Path_17387",
        "data-name": "Path 17387",
        d: "M58.743,8.638A6.2,6.2,0,0,0,55.4,6.3a6.662,6.662,0,0,0-3.058.055h0l-.034.008-.091.02c-.074.017-.188.045-.31.076-.16.041-.323.078-.485.108q0-.182-.014-.374a6.162,6.162,0,0,1,1.87-3.956A6.643,6.643,0,0,1,55.212.9.469.469,0,0,0,54.87.032a7.448,7.448,0,0,0-2.223,1.509,7.229,7.229,0,0,0-1.659,2.437,4.837,4.837,0,0,0-1.119-1.837C47.744.019,43.762.68,43.527.721h0a.457.457,0,0,0-.367.314.6.6,0,0,0-.017.066c-.027.151-.573,3.346.8,5.557a7.353,7.353,0,0,0-3.914,6.923,11.6,11.6,0,0,0,1.142,4.581,14.2,14.2,0,0,0,2.744,4.091A5.044,5.044,0,0,0,47.309,24a6.6,6.6,0,0,0,1.88-.276A3.331,3.331,0,0,1,51,23.691l.006,0,.11.031A6.6,6.6,0,0,0,53,24a4.912,4.912,0,0,0,3.25-1.608,13.985,13.985,0,0,0,4.029-8.812A8.163,8.163,0,0,0,58.743,8.638ZM49.206,2.8a5.247,5.247,0,0,1,1.256,3.409c-.017.211-.025,1.132-.025,1.132L46.881,3.794a.469.469,0,0,0-.663.663L49.8,8.033c-1.224.066-3.343-.027-4.572-1.255C43.75,5.3,43.912,2.552,44.02,1.6c.953-.108,3.709-.27,5.185,1.2ZM55.6,21.716A4.033,4.033,0,0,1,53,23.062a5.728,5.728,0,0,1-1.609-.236l-.141-.04h0a4.269,4.269,0,0,0-2.329.04,5.728,5.728,0,0,1-1.609.236A4.172,4.172,0,0,1,44.58,21.59a13.058,13.058,0,0,1-3.612-8.009c0-3.445,1.878-5.444,3.571-6.163l.024.024a6.632,6.632,0,0,0,4.665,1.547A9.91,9.91,0,0,0,50.9,8.863c.374-.082.365-.256.388-.364V8.482a9.219,9.219,0,0,0,.107-.965.475.475,0,0,0,.083-.007c.22-.038.441-.085.658-.142.084-.022.165-.042.232-.058,1.934.674,3.846,2.849,3.846,6.269a9.857,9.857,0,0,1-.747,3.455.469.469,0,1,0,.874.339,10.789,10.789,0,0,0,.811-3.795,7.594,7.594,0,0,0-3.162-6.493,4.317,4.317,0,0,1,1.17.122c2.013.521,4.18,2.737,4.18,6.371A13.138,13.138,0,0,1,55.6,21.716Z",
        transform: "translate(-0.5)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      })]
    })
  }));
};

/***/ }),

/***/ "uChv":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "uzwF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ })

};;