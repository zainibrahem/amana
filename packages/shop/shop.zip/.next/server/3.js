exports.ids = [3];
exports.modules = {

/***/ "./src/layouts/header/menu/auth-menu.tsx":
/*!***********************************************!*\
  !*** ./src/layouts/header/menu/auth-menu.tsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_popover_popover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/popover/popover */ "./src/components/popover/popover.tsx");
/* harmony import */ var _authorized_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./authorized-menu */ "./src/layouts/header/menu/authorized-menu.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\layouts\\header\\menu\\auth-menu.tsx";






const AuthMenu = ({
  isAuthenticated,
  onJoin,
  onLogout,
  avatar
}) => {
  return !isAuthenticated ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    variant: "primary",
    onClick: onJoin,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "joinButton",
      defaultMessage: "join"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_popover_popover__WEBPACK_IMPORTED_MODULE_4__["default"], {
    direction: "right",
    className: "user-pages-dropdown",
    handler: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      src: avatar,
      alt: "user"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 16
    }, undefined),
    content: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_authorized_menu__WEBPACK_IMPORTED_MODULE_5__["AuthorizedMenu"], {
      onLogout: onLogout
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 16
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (AuthMenu);

/***/ }),

/***/ "./src/layouts/header/menu/authorized-menu.tsx":
/*!*****************************************************!*\
  !*** ./src/layouts/header/menu/authorized-menu.tsx ***!
  \*****************************************************/
/*! exports provided: AuthorizedMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorizedMenu", function() { return AuthorizedMenu; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_nav_link_nav_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/nav-link/nav-link */ "./src/components/nav-link/nav-link.tsx");
/* harmony import */ var site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! site-settings/site-navigation */ "./src/site-settings/site-navigation.ts");


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\layouts\\header\\menu\\authorized-menu.tsx";




const AuthorizedMenu = ({
  onLogout
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_4__["AUTHORIZED_MENU_ITEMS"].map((item, idx) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_nav_link_nav_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
      className: "menu-item",
      href: item.href,
      label: item.defaultMessage,
      intlId: item.id
    }, idx, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 9
    }, undefined)), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "menu-item",
      onClick: onLogout,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_2__["FormattedMessage"], {
            id: "nav.logout",
            defaultMessage: "Logout"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvbGF5b3V0cy9oZWFkZXIvbWVudS9hdXRoLW1lbnUudHN4Iiwid2VicGFjazovLy8uL3NyYy9sYXlvdXRzL2hlYWRlci9tZW51L2F1dGhvcml6ZWQtbWVudS50c3giXSwibmFtZXMiOlsiQXV0aE1lbnUiLCJpc0F1dGhlbnRpY2F0ZWQiLCJvbkpvaW4iLCJvbkxvZ291dCIsImF2YXRhciIsIkF1dGhvcml6ZWRNZW51IiwiQVVUSE9SSVpFRF9NRU5VX0lURU1TIiwibWFwIiwiaXRlbSIsImlkeCIsImhyZWYiLCJkZWZhdWx0TWVzc2FnZSIsImlkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBU0EsTUFBTUEsUUFBUSxHQUFHLENBQUM7QUFBRUMsaUJBQUY7QUFBbUJDLFFBQW5CO0FBQTJCQyxVQUEzQjtBQUFxQ0M7QUFBckMsQ0FBRCxLQUEwRDtBQUN6RSxTQUFPLENBQUNILGVBQUQsZ0JBQ0wscUVBQUMsK0RBQUQ7QUFBUSxXQUFPLEVBQUMsU0FBaEI7QUFBMEIsV0FBTyxFQUFFQyxNQUFuQztBQUFBLDJCQUNFLHFFQUFDLDJEQUFEO0FBQWtCLFFBQUUsRUFBQyxZQUFyQjtBQUFrQyxvQkFBYyxFQUFDO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREssZ0JBS0wscUVBQUMsa0VBQUQ7QUFDRSxhQUFTLEVBQUMsT0FEWjtBQUVFLGFBQVMsRUFBQyxxQkFGWjtBQUdFLFdBQU8sZUFBRTtBQUFLLFNBQUcsRUFBRUUsTUFBVjtBQUFrQixTQUFHLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFIWDtBQUlFLFdBQU8sZUFBRSxxRUFBQywrREFBRDtBQUFnQixjQUFRLEVBQUVEO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTEY7QUFZRCxDQWJEOztBQWNlSCx1RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0JBO0FBQ0E7QUFDQTtBQUNBO0FBTU8sTUFBTUssY0FBK0IsR0FBRyxDQUFDO0FBQUVGO0FBQUYsQ0FBRCxLQUFrQjtBQUMvRCxzQkFDRTtBQUFBLGVBQ0dHLG1GQUFxQixDQUFDQyxHQUF0QixDQUEwQixDQUFDQyxJQUFELEVBQU9DLEdBQVAsa0JBQ3pCLHFFQUFDLG9FQUFEO0FBRUUsZUFBUyxFQUFDLFdBRlo7QUFHRSxVQUFJLEVBQUVELElBQUksQ0FBQ0UsSUFIYjtBQUlFLFdBQUssRUFBRUYsSUFBSSxDQUFDRyxjQUpkO0FBS0UsWUFBTSxFQUFFSCxJQUFJLENBQUNJO0FBTGYsT0FDT0gsR0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURELENBREgsZUFVRTtBQUFLLGVBQVMsRUFBQyxXQUFmO0FBQTJCLGFBQU8sRUFBRU4sUUFBcEM7QUFBQSw2QkFDRTtBQUFBLCtCQUNFO0FBQUEsaUNBQ0UscUVBQUMsMkRBQUQ7QUFBa0IsY0FBRSxFQUFDLFlBQXJCO0FBQWtDLDBCQUFjLEVBQUM7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFWRjtBQUFBLGtCQURGO0FBb0JELENBckJNLEMiLCJmaWxlIjoiMy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdjb21wb25lbnRzL2J1dHRvbi9idXR0b24nO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuaW1wb3J0IFBvcG92ZXIgZnJvbSAnY29tcG9uZW50cy9wb3BvdmVyL3BvcG92ZXInO1xuaW1wb3J0IHsgQXV0aG9yaXplZE1lbnUgfSBmcm9tICcuL2F1dGhvcml6ZWQtbWVudSc7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIGlzQXV0aGVudGljYXRlZDogYm9vbGVhbjtcbiAgb25Kb2luOiAoKSA9PiB2b2lkO1xuICBvbkxvZ291dDogKCkgPT4gdm9pZDtcbiAgYXZhdGFyOiBzdHJpbmc7XG59XG5cbmNvbnN0IEF1dGhNZW51ID0gKHsgaXNBdXRoZW50aWNhdGVkLCBvbkpvaW4sIG9uTG9nb3V0LCBhdmF0YXIgfTogUHJvcHMpID0+IHtcbiAgcmV0dXJuICFpc0F1dGhlbnRpY2F0ZWQgPyAoXG4gICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9e29uSm9pbn0+XG4gICAgICA8Rm9ybWF0dGVkTWVzc2FnZSBpZD1cImpvaW5CdXR0b25cIiBkZWZhdWx0TWVzc2FnZT1cImpvaW5cIiAvPlxuICAgIDwvQnV0dG9uPlxuICApIDogKFxuICAgIDxQb3BvdmVyXG4gICAgICBkaXJlY3Rpb249XCJyaWdodFwiXG4gICAgICBjbGFzc05hbWU9XCJ1c2VyLXBhZ2VzLWRyb3Bkb3duXCJcbiAgICAgIGhhbmRsZXI9ezxpbWcgc3JjPXthdmF0YXJ9IGFsdD1cInVzZXJcIiAvPn1cbiAgICAgIGNvbnRlbnQ9ezxBdXRob3JpemVkTWVudSBvbkxvZ291dD17b25Mb2dvdXR9IC8+fVxuICAgIC8+XG4gICk7XG59O1xuZXhwb3J0IGRlZmF1bHQgQXV0aE1lbnU7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuaW1wb3J0IE5hdkxpbmsgZnJvbSAnY29tcG9uZW50cy9uYXYtbGluay9uYXYtbGluayc7XG5pbXBvcnQgeyBBVVRIT1JJWkVEX01FTlVfSVRFTVMgfSBmcm9tICdzaXRlLXNldHRpbmdzL3NpdGUtbmF2aWdhdGlvbic7XG5cbnR5cGUgUHJvcHMgPSB7XG4gIG9uTG9nb3V0OiAoKSA9PiB2b2lkO1xufTtcblxuZXhwb3J0IGNvbnN0IEF1dGhvcml6ZWRNZW51OiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBvbkxvZ291dCB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtBVVRIT1JJWkVEX01FTlVfSVRFTVMubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICBjbGFzc05hbWU9J21lbnUtaXRlbSdcbiAgICAgICAgICBocmVmPXtpdGVtLmhyZWZ9XG4gICAgICAgICAgbGFiZWw9e2l0ZW0uZGVmYXVsdE1lc3NhZ2V9XG4gICAgICAgICAgaW50bElkPXtpdGVtLmlkfVxuICAgICAgICAvPlxuICAgICAgKSl9XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nbWVudS1pdGVtJyBvbkNsaWNrPXtvbkxvZ291dH0+XG4gICAgICAgIDxhPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2UgaWQ9J25hdi5sb2dvdXQnIGRlZmF1bHRNZXNzYWdlPSdMb2dvdXQnIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2E+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9