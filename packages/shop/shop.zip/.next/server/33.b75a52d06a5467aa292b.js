exports.ids = [33];
exports.modules = {

/***/ "1HxZ":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bakery-069321af4233c2271e028921b402086d.png";

/***/ }),

/***/ "2nMb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CloseIcon; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    })
  }));
};

/***/ }),

/***/ "3gEE":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/makeup-d6164bba6f7ffd3ee517bb28a3b5a483.png";

/***/ }),

/***/ "7UZk":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/bag-29362f82fb955a25b2ea7707d37a7e3f.png";

/***/ }),

/***/ "8dJX":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/furniture-b3a8dc77d51bbfae07955c057f47a6c2.png";

/***/ }),

/***/ "DeKQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "react-spring"
var external_react_spring_ = __webpack_require__("KwCx");

// EXTERNAL MODULE: external "react-spring-modal"
var external_react_spring_modal_ = __webpack_require__("Ay7f");

// EXTERNAL MODULE: ./src/assets/icons/CloseIcon.tsx
var CloseIcon = __webpack_require__("2nMb");

// EXTERNAL MODULE: ./src/components/scrollbar/scrollbar.tsx
var scrollbar = __webpack_require__("ewwY");

// CONCATENATED MODULE: ./src/components/modal/fullscreen-modal.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const SpringModal = ({
  isOpen,
  onRequestClose,
  children,
  defaultClose = true,
  style = {}
}) => {
  const transition = Object(external_react_spring_["useTransition"])(isOpen, null, {
    from: {
      opacity: 0
    },
    enter: {
      opacity: 1
    },
    leave: {
      opacity: 0
    }
  });
  const staticStyles = {
    position: "absolute",
    bottom: 0,
    left: 0,
    padding: 0,
    width: "calc(100% + 1px)",
    height: "100%",
    maxHeight: "100vh",
    backgroundColor: "#ffffff",
    borderRadius: "0px",
    zIndex: 99999
  };
  const buttonStyle = {
    width: 40,
    height: 40,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    color: "#0D1136",
    border: 0,
    outline: 0,
    boxShadow: "none",
    borderRadius: "50%",
    position: "absolute",
    top: 20,
    right: 20,
    zIndex: 100000,
    cursor: "pointer",
    ":focus": {
      outline: 0,
      boxShadow: "none"
    }
  };
  const scrollbarStyle = {
    height: "100%",
    maxHeight: "100%"
  };
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_spring_modal_["BaseModal"], {
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    children: transition.map(({
      item,
      key,
      props: transitionStyles
    }) => item && /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_spring_["animated"].div, {
      style: _objectSpread(_objectSpread(_objectSpread({}, transitionStyles), staticStyles), style),
      children: [defaultClose && /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        onClick: onRequestClose,
        style: _objectSpread({}, buttonStyle),
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseIcon["a" /* CloseIcon */], {
          style: {
            width: 12,
            height: 12
          }
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(scrollbar["a" /* Scrollbar */], {
        style: _objectSpread({}, scrollbarStyle),
        children: children
      })]
    }, key))
  });
};

/* harmony default export */ var fullscreen_modal = (SpringModal);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__("Dtiu");
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "@styled-system/css"
var css_ = __webpack_require__("ExBD");
var css_default = /*#__PURE__*/__webpack_require__.n(css_);

// CONCATENATED MODULE: ./src/components/demo-switcher/switcher.style.tsx


const pulse = Object(external_styled_components_["keyframes"])(["0%{-moz-box-shadow:0 0 0 0 rgba(52,143,80,0.4);box-shadow:0 0 0 0 rgba(52,143,80,0.4);}70%{-moz-box-shadow:0 0 0 10px rgba(52,143,80,0);box-shadow:0 0 0 10px rgba(52,143,80,0);}100%{-moz-box-shadow:0 0 0 0 rgba(52,143,80,0);box-shadow:0 0 0 0 rgba(52,143,80,0);}"]);
const SwitcherWrapper = external_styled_components_default.a.button.withConfig({
  displayName: "switcherstyle__SwitcherWrapper",
  componentId: "hvceol-0"
})(css_default()({
  width: 'auto',
  height: 'auto',
  padding: '20px 15px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  borderRadius: '6px 0 0 6px',
  boxShadow: '0 0 0 rgba(52, 143, 80, 0.4)',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  position: 'fixed',
  bottom: '100px',
  right: 0,
  zIndex: 99,
  ':focus': {
    outline: 0
  },
  '@media only screen and (max-width: 580px)': {
    bottom: '38%',
    transform: 'translateY(50%)',
    padding: '15px 13px'
  }
}), Object(external_styled_components_["css"])(["animation:", " 2s infinite;"], pulse));
const Switcher = external_styled_components_default.a.span.withConfig({
  displayName: "switcherstyle__Switcher",
  componentId: "hvceol-1"
})(css_default()({
  fontSize: '14px',
  fontWeight: 'medium',
  lineHeight: 1,
  color: 'white',
  textTransform: 'uppercase',
  textOrientation: 'upright',
  // writingMode: 'tb',
  writingMode: 'vertical-lr',
  fontFeatureSettings: '"vkrn", "vpal"'
}));
const Header = external_styled_components_default.a.div.withConfig({
  displayName: "switcherstyle__Header",
  componentId: "hvceol-2"
})(css_default()({
  width: '100%',
  height: 100,
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  backgroundColor: 'white',
  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.08)',
  position: 'relative',
  zIndex: 1,
  '@media only screen and (max-width: 767px)': {
    height: 80,
    padding: '0 20px'
  }
}));
const PurchaseBtn = external_styled_components_default.a.a.withConfig({
  displayName: "switcherstyle__PurchaseBtn",
  componentId: "hvceol-3"
})(css_default()({
  fontFamily: 'Lato, sans-serif',
  width: 'auto',
  height: '48px',
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  boxShadow: '0 3px 6px rgba(0, 0, 0, 0.12)',
  borderRadius: '24px',
  fontSize: 'base',
  fontWeight: 'bold',
  lineHeight: 1,
  color: 'white',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  transition: 'all 0.3s',
  '@media only screen and (max-width: 767px)': {
    height: '44px'
  },
  ':hover': {
    backgroundColor: 'primary.hover'
  },
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}), Object(external_styled_components_["css"])(["animation:", " 2s infinite;"], pulse));
const ModalTitle = external_styled_components_default.a.h3.withConfig({
  displayName: "switcherstyle__ModalTitle",
  componentId: "hvceol-4"
})(css_default()({
  fontFamily: 'body',
  fontSize: '36px',
  fontWeight: 'bold',
  lineHeight: 1.5,
  color: 'text.bold',
  margin: 0,
  transform: 'translateX(-50%)',
  '@media only screen and (max-width: 767px)': {
    display: 'none'
  }
}));
const CloseButton = external_styled_components_default.a.button.withConfig({
  displayName: "switcherstyle__CloseButton",
  componentId: "hvceol-5"
})(css_default()({
  width: 40,
  height: 40,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: '#ffffff',
  color: '#0D1136',
  border: 0,
  outline: 0,
  boxShadow: 'none',
  borderRadius: '50%',
  cursor: 'pointer',
  transition: 'all 0.3s',
  ':hover': {
    backgroundColor: 'gray.500'
  },
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}));
const Body = external_styled_components_default.a.div.withConfig({
  displayName: "switcherstyle__Body",
  componentId: "hvceol-6"
})(css_default()({
  width: '100%',
  height: 'calc(100% - 100px)',
  backgroundColor: 'gray.200',
  '@media only screen and (max-width: 767px)': {
    height: 'calc(100% - 80px)'
  }
}));
const Content = external_styled_components_default.a.div.withConfig({
  displayName: "switcherstyle__Content",
  componentId: "hvceol-7"
})(css_default()({
  width: '100%',
  padding: '50px 30px',
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  columnGap: '50px',
  '@media only screen and (min-width: 1600px)': {
    gridTemplateColumns: '1fr 1fr 1fr'
  },
  '@media only screen and (max-width: 767px)': {
    padding: '40px 15px',
    gridTemplateColumns: '1fr'
  }
}));
const DemoCard = external_styled_components_default.a.div.withConfig({
  displayName: "switcherstyle__DemoCard",
  componentId: "hvceol-8"
})(css_default()({
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  marginBottom: 50
}));
const VisitBtn = external_styled_components_default.a.a.withConfig({
  displayName: "switcherstyle__VisitBtn",
  componentId: "hvceol-9"
})(css_default()({
  width: 'auto',
  height: '48px',
  padding: '0 30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: 'primary.regular',
  backgroundImage: 'linear-gradient(-60deg,#348f50, #56b4d3)',
  borderRadius: 'base',
  fontSize: 'base',
  fontWeight: 'bold',
  lineHeight: 1,
  color: 'white',
  boxShadow: '0 3px 6px rgba(0, 0, 0, 0.12)',
  border: 0,
  outline: 0,
  cursor: 'pointer',
  marginTop: -24,
  position: 'absolute',
  top: '50%',
  left: '50%',
  opacity: 0,
  transform: 'translate(-50%, -30px)',
  transition: 'all 0.3s',
  ':focus': {
    outline: 0,
    boxShadow: 'none'
  }
}));
const DemoImageWrapper = external_styled_components_default.a.a.withConfig({
  displayName: "switcherstyle__DemoImageWrapper",
  componentId: "hvceol-10"
})(css_default()({
  width: '100%',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  ':before': {
    content: '""',
    display: 'block',
    width: 'calc(100% - 30px)',
    height: 'calc(100% - 30px)',
    position: 'absolute',
    top: '25px',
    left: '15px',
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    filter: 'blur(15px)',
    WebkitTransform: 'translateZ(0)',
    WebkitBackfaceVisibility: 'hidden',
    WebkitPerspective: 1000
  }
}));
const DemoImage = external_styled_components_default.a.div.withConfig({
  displayName: "switcherstyle__DemoImage",
  componentId: "hvceol-11"
})(css_default()({
  overflow: 'hidden',
  borderRadius: '10px',
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  img: {
    maxWidth: '100%',
    height: 'auto',
    borderRadius: '10px'
  },
  ':after': {
    content: '""',
    display: 'block',
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'transparent',
    zIndex: 0,
    pointerEvents: 'none',
    borderRadius: '10px',
    transition: 'all 0.1s'
  },
  ':hover': {
    '.demo-btn': {
      opacity: 1,
      transform: 'translate3d(-50%, 0, 0)'
    },
    ':after': {
      backgroundColor: 'rgba(33, 33, 33, 0.09)'
    }
  }
}));
const DemoTitle = external_styled_components_default.a.span.withConfig({
  displayName: "switcherstyle__DemoTitle",
  componentId: "hvceol-12"
})(css_default()({
  fontSize: '24px',
  fontWeight: 'bold',
  lineHeight: 1.5,
  color: 'text.bold',
  margin: '30px 0 0',
  textAlign: 'center',
  width: '100%',
  '@media only screen and (max-width: 767px)': {
    fontSize: '18px'
  }
}));
// CONCATENATED MODULE: ./src/assets/icons/ShoppingBagAlt.tsx


function ShoppingBagAlt_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function ShoppingBagAlt_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ShoppingBagAlt_ownKeys(Object(source), true).forEach(function (key) { ShoppingBagAlt_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ShoppingBagAlt_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ShoppingBagAlt_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const ShoppingBagAlt = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", ShoppingBagAlt_objectSpread(ShoppingBagAlt_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20",
    height: "20",
    viewBox: "0 0 20 20"
  }, props), {}, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      id: "shopping-bag",
      d: "M5,4H19a1,1,0,0,1,1,1V19a1,1,0,0,1-1,1H5a1,1,0,0,1-1-1V5A1,1,0,0,1,5,4ZM2,5A3,3,0,0,1,5,2H19a3,3,0,0,1,3,3V19a3,3,0,0,1-3,3H5a3,3,0,0,1-3-3Zm10,7C9.239,12,7,9.314,7,6H9c0,2.566,1.669,4,3,4s3-1.434,3-4h2C17,9.314,14.761,12,12,12Z",
      transform: "translate(-2 -2)",
      fill: "currentColor",
      fillRule: "evenodd"
    })
  }));
};
// EXTERNAL MODULE: ./src/components/demo-switcher/image/grocery.png
var grocery = __webpack_require__("hIZk");
var grocery_default = /*#__PURE__*/__webpack_require__.n(grocery);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/makeup.png
var makeup = __webpack_require__("3gEE");
var makeup_default = /*#__PURE__*/__webpack_require__.n(makeup);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/bag.png
var bag = __webpack_require__("7UZk");
var bag_default = /*#__PURE__*/__webpack_require__.n(bag);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/clothing.png
var clothing = __webpack_require__("zM8v");
var clothing_default = /*#__PURE__*/__webpack_require__.n(clothing);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/furniture.png
var furniture = __webpack_require__("8dJX");
var furniture_default = /*#__PURE__*/__webpack_require__.n(furniture);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/book.png
var book = __webpack_require__("gfEL");
var book_default = /*#__PURE__*/__webpack_require__.n(book);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/medicine.png
var medicine = __webpack_require__("hzWU");
var medicine_default = /*#__PURE__*/__webpack_require__.n(medicine);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/restaurant.png
var restaurant = __webpack_require__("Uxap");
var restaurant_default = /*#__PURE__*/__webpack_require__.n(restaurant);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/bakery.png
var bakery = __webpack_require__("1HxZ");
var bakery_default = /*#__PURE__*/__webpack_require__.n(bakery);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/grocery-2.png
var grocery_2 = __webpack_require__("mzSy");
var grocery_2_default = /*#__PURE__*/__webpack_require__.n(grocery_2);

// EXTERNAL MODULE: ./src/components/demo-switcher/image/furniture-2.png
var furniture_2 = __webpack_require__("mWa/");
var furniture_2_default = /*#__PURE__*/__webpack_require__.n(furniture_2);

// CONCATENATED MODULE: ./src/components/demo-switcher/data.tsx











const DemoData = [{
  image: bakery_default.a,
  title: 'Bakery',
  link: 'https://shop.redq.now.sh/bakery'
}, {
  image: grocery_2_default.a,
  title: 'Grocery Modern',
  link: 'https://shop.redq.now.sh/grocery-two'
}, {
  image: furniture_2_default.a,
  title: 'Furniture Modern',
  link: 'https://shop.redq.now.sh/furniture-two'
}, {
  image: grocery_default.a,
  title: 'Grocery',
  link: 'https://shop.redq.now.sh/grocery'
}, {
  image: makeup_default.a,
  title: 'Makeup',
  link: 'https://shop.redq.now.sh/makeup'
}, {
  image: bag_default.a,
  title: 'Bag',
  link: 'https://shop.redq.now.sh/bags'
}, {
  image: clothing_default.a,
  title: 'Clothing',
  link: 'https://shop.redq.now.sh/clothing'
}, {
  image: furniture_default.a,
  title: 'Furniture',
  link: 'https://shop.redq.now.sh/furniture'
}, {
  image: book_default.a,
  title: 'Book',
  link: 'https://shop.redq.now.sh/book'
}, {
  image: medicine_default.a,
  title: 'Medicine',
  link: 'https://shop.redq.now.sh/medicine'
}, {
  image: restaurant_default.a,
  title: 'Restaurant',
  link: 'https://shop-restaurant.vercel.app'
}];
// CONCATENATED MODULE: ./src/components/demo-switcher/switcher-btn.tsx











const DemoSwitcher = () => {
  const {
    0: isOpen,
    1: setOpen
  } = Object(external_react_["useState"])(false);
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SwitcherWrapper, {
      onClick: () => setOpen(true),
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Switcher, {
        children: "Demos"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(fullscreen_modal, {
      isOpen: isOpen,
      onRequestClose: () => setOpen(false),
      defaultClose: false,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(Header, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(PurchaseBtn, {
          href: "https://1.envato.market/E1DxW",
          target: "_blank",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(ShoppingBagAlt, {
            style: {
              marginRight: '7px',
              width: '18px'
            }
          }), ' ', "Purchase"]
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(ModalTitle, {
          children: "Demos"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseButton, {
          onClick: () => setOpen(false),
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseIcon["a" /* CloseIcon */], {
            style: {
              width: 14,
              height: 14
            }
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Body, {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(scrollbar["a" /* Scrollbar */], {
          style: {
            height: '100%',
            maxHeight: '100%'
          },
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Content, {
            children: DemoData.map((item, index) => /*#__PURE__*/Object(jsx_runtime_["jsxs"])(DemoCard, {
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(DemoImageWrapper, {
                children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(DemoImage, {
                  children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
                    src: item.image,
                    alt: item.title
                  }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(VisitBtn, {
                    className: "demo-btn",
                    href: item.link,
                    target: "_blank",
                    children: "View Demo"
                  })]
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(DemoTitle, {
                children: item.title
              })]
            }, index))
          })
        })
      })]
    })]
  });
};

/* harmony default export */ var switcher_btn = __webpack_exports__["default"] = (DemoSwitcher);

/***/ }),

/***/ "Uxap":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/restaurant-1cd3b06c8e556ab4d9106482b154ef8e.png";

/***/ }),

/***/ "ewwY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Scrollbar; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("trJ8");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }));
};

/***/ }),

/***/ "gfEL":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/book-6d522e5f65990451d8f13d26daceaf68.png";

/***/ }),

/***/ "hIZk":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/grocery-7ab037810b9da31666af384988e83966.png";

/***/ }),

/***/ "hzWU":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/medicine-253ef6a75d070ec9bc88596046e39a56.png";

/***/ }),

/***/ "mWa/":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/furniture-2-1e66df5d88b4a436ba304b7dae93263c.png";

/***/ }),

/***/ "mzSy":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/grocery-2-b9bc1409974c7f5b2d3339bf495f96ae.png";

/***/ }),

/***/ "zM8v":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/clothing-4b013b70efab8ae19dde3fb325d0765f.png";

/***/ })

};;