exports.ids = [39];
exports.modules = {

/***/ "2nMb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CloseIcon; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    })
  }));
};

/***/ }),

/***/ "UTRa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: external "@redq/reuse-modal"
var reuse_modal_ = __webpack_require__("qbum");

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// EXTERNAL MODULE: ./src/components/scrollbar/scrollbar.tsx
var scrollbar = __webpack_require__("ewwY");

// EXTERNAL MODULE: external "rc-drawer"
var external_rc_drawer_ = __webpack_require__("ik7d");
var external_rc_drawer_default = /*#__PURE__*/__webpack_require__.n(external_rc_drawer_);

// CONCATENATED MODULE: ./src/components/drawer/drawer.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Drawer = (_ref) => {
  let {
    className,
    children,
    closeButton,
    closeButtonStyle,
    drawerHandler,
    toggleHandler,
    open,
    width,
    placement
  } = _ref,
      props = _objectWithoutProperties(_ref, ["className", "children", "closeButton", "closeButtonStyle", "drawerHandler", "toggleHandler", "open", "width", "placement"]);

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_rc_drawer_default.a, _objectSpread(_objectSpread({
      open: open,
      onClose: toggleHandler,
      className: `drawer ${className ? className : ''}`.trim(),
      width: width,
      placement: placement,
      handler: false,
      level: null,
      duration: ".4s"
    }, props), {}, {
      children: [closeButton && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "drawer__close",
        onClick: toggleHandler,
        style: closeButtonStyle,
        children: closeButton
      }), children]
    })), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "drawer__handler",
      style: {
        display: 'inline-block'
      },
      onClick: toggleHandler,
      children: drawerHandler
    })]
  });
};

Drawer.defaultProps = {
  width: '300px',
  placement: 'left'
};
/* harmony default export */ var drawer = (Drawer);
// EXTERNAL MODULE: ./src/components/button/button.tsx
var button_button = __webpack_require__("B68Z");

// EXTERNAL MODULE: ./src/components/nav-link/nav-link.tsx
var nav_link = __webpack_require__("Ek28");

// EXTERNAL MODULE: ./src/assets/icons/CloseIcon.tsx
var CloseIcon = __webpack_require__("2nMb");

// EXTERNAL MODULE: ./src/contexts/auth/auth.context.tsx
var auth_context = __webpack_require__("QfjN");

// EXTERNAL MODULE: ./src/features/authentication-form/index.tsx + 5 modules
var authentication_form = __webpack_require__("kp67");

// EXTERNAL MODULE: ./src/layouts/header/header.style.tsx
var header_style = __webpack_require__("HPEz");

// EXTERNAL MODULE: ./src/assets/images/user.jpg
var user = __webpack_require__("OBDI");

// EXTERNAL MODULE: ./src/site-settings/site-navigation.ts
var site_navigation = __webpack_require__("5l48");

// EXTERNAL MODULE: ./src/contexts/app/app.provider.ts + 2 modules
var app_provider = __webpack_require__("xZKy");

// CONCATENATED MODULE: ./src/layouts/header/mobile-drawer.tsx


















const MobileDrawer = () => {
  const isDrawerOpen = Object(app_provider["c" /* useAppState */])('isDrawerOpen');
  const dispatch = Object(app_provider["b" /* useAppDispatch */])();
  const {
    authState: {
      isAuthenticated
    },
    authDispatch
  } = Object(external_react_["useContext"])(auth_context["a" /* AuthContext */]); // Toggle drawer

  const toggleHandler = external_react_default.a.useCallback(() => {
    dispatch({
      type: 'TOGGLE_DRAWER'
    });
  }, [dispatch]);

  const handleLogout = () => {
    if (false) {}
  };

  const signInOutForm = () => {
    dispatch({
      type: 'TOGGLE_DRAWER'
    });
    authDispatch({
      type: 'SIGNIN'
    });
    Object(reuse_modal_["openModal"])({
      show: true,
      overlayClassName: 'quick-view-overlay',
      closeOnClickOutside: true,
      component: authentication_form["a" /* default */],
      closeComponent: '',
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'quick-view-modal',
        width: 458,
        height: 'auto'
      }
    });
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(drawer, {
    width: "316px",
    drawerHandler: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["h" /* HamburgerIcon */], {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {})]
    }),
    open: isDrawerOpen,
    toggleHandler: toggleHandler,
    closeButton: /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["b" /* DrawerClose */], {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseIcon["a" /* CloseIcon */], {})
    }),
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["a" /* DrawerBody */], {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(scrollbar["a" /* Scrollbar */], {
        className: "drawer-scrollbar",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["c" /* DrawerContentWrapper */], {
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["f" /* DrawerProfile */], {
            children: isAuthenticated ? /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["i" /* LoginView */], {
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["q" /* UserAvatar */], {
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
                  src: user["a" /* default */],
                  alt: "user_avatar"
                })
              }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["r" /* UserDetails */], {
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
                  children: "David Kinderson"
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
                  children: "+990 374 987"
                })]
              })]
            }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["k" /* LogoutView */], {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(button_button["a" /* Button */], {
                variant: "primary",
                onClick: signInOutForm,
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
                  id: "mobileSignInButtonText",
                  defaultMessage: "join"
                })
              })
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["d" /* DrawerMenu */], {
            children: site_navigation["m" /* MOBILE_DRAWER_MENU */].map(item => /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["e" /* DrawerMenuItem */], {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(nav_link["a" /* default */], {
                onClick: toggleHandler,
                href: item.href,
                label: item.defaultMessage,
                intlId: item.id,
                className: "drawer_menu_item"
              })
            }, item.id))
          }), isAuthenticated && /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["s" /* UserOptionMenu */], {
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["e" /* DrawerMenuItem */], {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(nav_link["a" /* default */], {
                href: site_navigation["o" /* PROFILE_PAGE */],
                label: "Your Account Settings",
                className: "drawer_menu_item",
                intlId: "navlinkAccountSettings"
              })
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["e" /* DrawerMenuItem */], {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                onClick: handleLogout,
                className: "drawer_menu_item",
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
                  className: "logoutBtn",
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
                    id: "navlinkLogout",
                    defaultMessage: "Logout"
                  })
                })
              })
            })]
          })]
        })
      })
    })
  });
};

/* harmony default export */ var mobile_drawer = (MobileDrawer);
// EXTERNAL MODULE: ./src/features/search/search.tsx + 2 modules
var search = __webpack_require__("Td6B");

// EXTERNAL MODULE: ./src/assets/images/logo.png
var logo = __webpack_require__("nWR2");
var logo_default = /*#__PURE__*/__webpack_require__.n(logo);

// EXTERNAL MODULE: ./src/assets/icons/SearchIcon.tsx
var SearchIcon = __webpack_require__("J7Kp");

// EXTERNAL MODULE: ./src/assets/icons/LongArrowLeft.tsx
var LongArrowLeft = __webpack_require__("iAPg");

// EXTERNAL MODULE: ./src/layouts/logo/logo.tsx + 1 modules
var logo_logo = __webpack_require__("9T+x");

// EXTERNAL MODULE: ./src/layouts/header/menu/language-switcher/language-switcher.tsx + 8 modules
var language_switcher = __webpack_require__("PsoQ");

// EXTERNAL MODULE: ./src/layouts/is-home-page.ts
var is_home_page = __webpack_require__("hp67");

// EXTERNAL MODULE: ./src/utils/useComponentSize.js + 1 modules
var useComponentSize = __webpack_require__("uRCu");

// CONCATENATED MODULE: ./src/layouts/header/mobile-header.tsx
















const SearchModal = () => {
  const onSubmit = () => {
    Object(reuse_modal_["closeModal"])();
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["o" /* SearchModalWrapper */], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["n" /* SearchModalClose */], {
      type: "submit",
      onClick: () => Object(reuse_modal_["closeModal"])(),
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(LongArrowLeft["a" /* LongArrowLeft */], {})
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(search["a" /* default */], {
      className: "header-modal-search",
      showButtonText: false,
      onSubmit: onSubmit
    })]
  });
};

const MobileHeader = ({
  className
}) => {
  const {
    pathname,
    query
  } = Object(router_["useRouter"])();
  const [mobileHeaderRef, dimensions] = Object(useComponentSize["a" /* default */])();

  const handleSearchModal = () => {
    Object(reuse_modal_["openModal"])({
      show: true,
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'search-modal-mobile',
        width: '100%',
        height: '100%'
      },
      closeOnClickOutside: false,
      component: SearchModal,
      closeComponent: () => /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {})
    });
  };

  const type = pathname === '/restaurant' ? 'restaurant' : query.type;
  const isHomePage = Object(is_home_page["a" /* isCategoryPage */])(type);
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["m" /* MobileHeaderWrapper */], {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(header_style["l" /* MobileHeaderInnerWrapper */], {
      className: className,
      ref: mobileHeaderRef,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["g" /* DrawerWrapper */], {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(mobile_drawer, {})
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["j" /* LogoWrapper */], {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(logo_logo["a" /* default */], {
          imageUrl: logo_default.a,
          alt: "shop logo"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(language_switcher["a" /* default */], {}), isHomePage ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(header_style["p" /* SearchWrapper */], {
        onClick: handleSearchModal,
        className: "searchIconWrapper",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(SearchIcon["a" /* SearchIcon */], {})
      }) : null]
    })
  });
};

/* harmony default export */ var mobile_header = __webpack_exports__["default"] = (MobileHeader);

/***/ }),

/***/ "ewwY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Scrollbar; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("trJ8");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }));
};

/***/ }),

/***/ "iAPg":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LongArrowLeft; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const LongArrowLeft = (_ref) => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "12",
    height: "8.003",
    viewBox: "0 0 12 8.003"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("path", {
      "data-name": "_ionicons_svg_ios-arrow-round-back (2)",
      d: "M116.447,160.177a.545.545,0,0,1,0,.767l-2.53,2.538h9.641a.542.542,0,0,1,0,1.084h-9.641l2.534,2.538a.549.549,0,0,1,0,.767.54.54,0,0,1-.763,0l-3.435-3.46a.608.608,0,0,1-.113-.171.517.517,0,0,1-.042-.208.543.543,0,0,1,.154-.379l3.435-3.46A.531.531,0,0,1,116.447,160.177Z",
      transform: "translate(-112.1 -160.023)",
      fill: "currentColor"
    })
  }));
};

/***/ }),

/***/ "uRCu":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./src/utils/debounce.ts
function debounce(func, wait, immediate) {
  let timeout;
  return function executedFunction(...args) {
    const context = this;

    const later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };

    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

/* harmony default export */ var utils_debounce = (debounce);
// CONCATENATED MODULE: ./src/utils/useComponentSize.js

 // maybe use a hook instead?

function useDimensions(liveMeasure = true, delay = 250, initialDimensions = {}) {
  const {
    0: dimensions,
    1: setDimensions
  } = Object(external_react_["useState"])(initialDimensions);
  const {
    0: node,
    1: setNode
  } = Object(external_react_["useState"])(null);
  const ref = Object(external_react_["useCallback"])(newNode => {
    setNode(newNode);
  }, []);
  Object(external_react_["useEffect"])(() => {
    // need ref to continue
    if (!node) {
      return;
    }

    const measure = () => {
      window.requestAnimationFrame(() => {
        const newDimensions = node.getBoundingClientRect();
        setDimensions(newDimensions);
      });
    }; // invoke measure right away


    measure();

    if (liveMeasure) {
      const debounceMeasure = utils_debounce(measure, delay);

      if ('ResizeObserver' in window) {
        const resizeObserver = new ResizeObserver(debounceMeasure);
        resizeObserver.observe(node);
        window.addEventListener('scroll', debounceMeasure);
        return () => {
          resizeObserver.disconnect();
          window.removeEventListener('scroll', debounceMeasure);
        };
      }

      window.addEventListener('resize', debounceMeasure);
      window.addEventListener('scroll', debounceMeasure);
      return () => {
        window.removeEventListener('resize', debounceMeasure);
        window.removeEventListener('scroll', debounceMeasure);
      };
    }
  }, [node, liveMeasure, delay]);
  return [ref, dimensions, node];
}

/* harmony default export */ var useComponentSize = __webpack_exports__["a"] = (useDimensions); // Usage
// function App() {
//   const [wrapperRef, dimensions] = useDimensions();
//   return (
//     <div ref={wrapperRef}>
//       height: {dimensions.height}
//       width: {dimensions.width}
//     </div>
//   );
// }

/***/ })

};;