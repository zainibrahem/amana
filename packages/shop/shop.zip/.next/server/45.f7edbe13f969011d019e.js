exports.ids = [45];
exports.modules = {

/***/ "IQ03":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: ./src/components/button/button.tsx
var button_button = __webpack_require__("B68Z");

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__("k004");

// EXTERNAL MODULE: ./src/components/popover/popover.tsx + 2 modules
var popover = __webpack_require__("63jn");

// EXTERNAL MODULE: ./src/components/nav-link/nav-link.tsx
var nav_link = __webpack_require__("Ek28");

// EXTERNAL MODULE: ./src/site-settings/site-navigation.ts
var site_navigation = __webpack_require__("5l48");

// CONCATENATED MODULE: ./src/layouts/header/menu/authorized-menu.tsx







const AuthorizedMenu = ({
  onLogout
}) => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [site_navigation["a" /* AUTHORIZED_MENU_ITEMS */].map((item, idx) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(nav_link["a" /* default */], {
      className: "menu-item",
      href: item.href,
      label: item.defaultMessage,
      intlId: item.id
    }, idx)), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "menu-item",
      onClick: onLogout,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
            id: "nav.logout",
            defaultMessage: "Logout"
          })
        })
      })
    })]
  });
};
// CONCATENATED MODULE: ./src/layouts/header/menu/auth-menu.tsx







const AuthMenu = ({
  isAuthenticated,
  onJoin,
  onLogout,
  avatar
}) => {
  return !isAuthenticated ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(button_button["a" /* Button */], {
    variant: "primary",
    onClick: onJoin,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_intl_["FormattedMessage"], {
      id: "joinButton",
      defaultMessage: "join"
    })
  }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])(popover["a" /* default */], {
    direction: "right",
    className: "user-pages-dropdown",
    handler: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
      src: avatar,
      alt: "user"
    }),
    content: /*#__PURE__*/Object(jsx_runtime_["jsx"])(AuthorizedMenu, {
      onLogout: onLogout
    })
  });
};

/* harmony default export */ var auth_menu = __webpack_exports__["default"] = (AuthMenu);

/***/ })

};;