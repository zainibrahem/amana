exports.ids = [5];
exports.modules = {

/***/ "../../node_modules/next/dist/client/link.js":
/*!*******************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/link.js ***!
  \*******************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../next-server/lib/router/router */ "../../node_modules/next/dist/next-server/lib/router/router.js");

var _router2 = __webpack_require__(/*! ./router */ "../../node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "../../node_modules/next/dist/client/use-intersection.js");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + (false ? undefined : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router.getDomainLocale)(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router.addBasePath)((0, _router.addLocale)(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "../../node_modules/next/dist/client/normalize-trailing-slash.js":
/*!***************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \***************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "../../node_modules/next/dist/client/request-idle-callback.js":
/*!************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/request-idle-callback.js ***!
  \************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "../../node_modules/next/dist/client/route-loader.js":
/*!***************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/route-loader.js ***!
  \***************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/router/utils/get-asset-path-from-route */ "../next-server/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "../../node_modules/next/dist/client/request-idle-callback.js"); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // Resolve a promise that times out after given amount of milliseconds.


function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject);
    (0, _requestIdleCallback.requestIdleCallback)(() => setTimeout(() => {
      if (!cancelled) {
        reject(err);
      }
    }, ms));
  });
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute.default)(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route) {
      return withFuture(route, routes, async () => {
        try {
          const {
            scripts,
            css
          } = await getFilesForRoute(assetPrefix, route);
          const [, styles] = await Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
          const entrypoint = await resolvePromiseWithTimeout(this.whenEntrypoint(route), MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`)));
          const res = Object.assign({
            styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        } catch (err) {
          return {
            error: err
          };
        }
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.requestIdleCallback)(() => this.loadRoute(route));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "../../node_modules/next/dist/client/router.js":
/*!*********************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/router.js ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router2 = _interopRequireWildcard(__webpack_require__(/*! ../next-server/lib/router/router */ "../../node_modules/next/dist/next-server/lib/router/router.js"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__(/*! ../next-server/lib/router-context */ "../next-server/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "../../node_modules/next/dist/client/with-router.js"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "../../node_modules/next/dist/client/use-intersection.js":
/*!*******************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/use-intersection.js ***!
  \*******************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "../../node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "../../node_modules/next/dist/client/with-router.js":
/*!**************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/client/with-router.js ***!
  \**************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "../../node_modules/next/dist/client/router.js");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js":
/*!**************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js ***!
  \**************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.normalizeLocalePath = normalizeLocalePath;

function normalizeLocalePath(pathname, locales) {
  let detectedLocale; // first item will be empty string from splitting at first char

  const pathnameParts = pathname.split('/');
  (locales || []).some(locale => {
    if (pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join('/') || '/';
      return true;
    }

    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/mitt.js":
/*!****************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/mitt.js ***!
  \****************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/router.js":
/*!*************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/router.js ***!
  \*************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "../../node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "../../node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../server/denormalize-page-path */ "../../node_modules/next/dist/next-server/server/denormalize-page-path.js");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../../node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../../node_modules/next/dist/next-server/lib/mitt.js"));

var _utils = __webpack_require__(/*! ../utils */ "../../node_modules/next/dist/next-server/lib/utils.js");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "../../node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "../../node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "../../node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "../../node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites-noop.js"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "../../node_modules/next/dist/next-server/lib/router/utils/route-matcher.js");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "../../node_modules/next/dist/next-server/lib/router/utils/route-regex.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {}

  return false;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href); // Return because it cannot be routed by the Next.js router

  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils.getLocationOrigin)();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router.pathname, url, true);
  const origin = (0, _utils.getLocationOrigin)();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router.pathname, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
}

const manualScrollRestoration =  false && false;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  // In-flight Server Data Requests, for deduping
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sdr = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;
    this.domainLocales = void 0;
    this.isReady = void 0;
    this.isPreview = void 0;
    this.isLocaleDomain = void 0;
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic.isDynamicRoute)(_pathname) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || !autoExportDynamic && !self.location.search);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    var _options$scroll;

    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    } // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated


    if (options._h) {
      this.isReady = true;
    } // Default to scroll reset behavior unless explicitly specified to be
    // `false`! This makes the behavior between using `Router#push` and a
    // `<Link />` consistent.


    options.scroll = !!((_options$scroll = options.scroll) != null ? _options$scroll : true);
    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname;

    if (pathname !== '/_error') {
      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname, pages);

        if (parsed.pathname !== pathname) {
          pathname = parsed.pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var _self$__NEXT_DATA__$p, _self$__NEXT_DATA__$p2;

      let routeInfo = await this.getRouteInfo(route, pathname, query, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);

            if (pages.includes(parsedHref.pathname)) {
              const {
                url: newUrl,
                as: newAs
              } = prepareUrlAs(this, destination, destination);
              return this.change(method, newUrl, newAs, options);
            }
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      if (options._h && pathname === '/_error' && ((_self$__NEXT_DATA__$p = self.__NEXT_DATA__.props) == null ? void 0 : (_self$__NEXT_DATA__$p2 = _self$__NEXT_DATA__$p.pageProps) == null ? void 0 : _self$__NEXT_DATA__$p2.statusCode) === 500 && props != null && props.pageProps) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo, forcedScroll || (isValidShallowRoute || !options.scroll ? null : {
        x: 0,
        y: 0
      })).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname) {
        pathname = parsed.pathname;
        url = (0, _utils.formatWithValidation)(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err => {
      delete this.sdr[resourceKey];
      throw err;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/format-url.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/format-url.js ***!
  \***********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__(/*! ./querystring */ "../../node_modules/next/dist/next-server/lib/router/utils/querystring.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js ***!
  \***********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js":
/*!*******************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js ***!
  \*******************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__(/*! ../../utils */ "../../node_modules/next/dist/next-server/lib/utils.js");

var _querystring = __webpack_require__(/*! ./querystring */ "../../node_modules/next/dist/next-server/lib/router/utils/querystring.js");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL(true ? 'http://n' : undefined);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error(`invariant: invalid relative URL, router received ${url}`);
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/querystring.js":
/*!************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/querystring.js ***!
  \************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites-noop.js":
/*!**********************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites-noop.js ***!
  \**********************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

function resolveRewrites() {}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/route-matcher.js":
/*!**************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/route-matcher.js ***!
  \**************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/router/utils/route-regex.js":
/*!************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/router/utils/route-regex.js ***!
  \************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "../../node_modules/next/dist/next-server/lib/utils.js":
/*!*****************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/lib/utils.js ***!
  \*****************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__(/*! ./router/utils/format-url */ "../../node_modules/next/dist/next-server/lib/router/utils/format-url.js");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (true) {
    var _App$prototype;

    if ((_App$prototype = App.prototype) != null && _App$prototype.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://nextjs.org/docs/messages/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (Object.keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://nextjs.org/docs/messages/empty-object-getInitialProps`);
    }
  }

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      Object.keys(url).forEach(key => {
        if (urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "../../node_modules/next/dist/next-server/server/denormalize-page-path.js":
/*!************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/dist/next-server/server/denormalize-page-path.js ***!
  \************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "../../node_modules/next/link.js":
/*!*******************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/link.js ***!
  \*******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/link */ "../../node_modules/next/dist/client/link.js")


/***/ }),

/***/ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!************************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "../../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
/*!*************************************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js ***!
  \*************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../../node_modules/next/node_modules/@babel/runtime/helpers/typeof.js");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "../../node_modules/next/node_modules/@babel/runtime/helpers/typeof.js":
/*!*********************************************************************************************************************************************************************!*\
  !*** D:/laravel projects/new website/update/Pickbazar - React GraphQL Ecommerce Template/pickbazar/node_modules/next/node_modules/@babel/runtime/helpers/typeof.js ***!
  \*********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "./src/assets/icons/Accessories.tsx":
/*!******************************************!*\
  !*** ./src/assets/icons/Accessories.tsx ***!
  \******************************************/
/*! exports provided: Accessories */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Accessories", function() { return Accessories; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Accessories.tsx";

const Accessories = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 15",
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 53",
        d: "M17.356 0H.643A.643.643 0 000 .643v10.925a.643.643 0 00.643.643h16.714a.643.643 0 00.643-.643V.643A.644.644 0 0017.356 0zM2.431 11.27a1.306 1.306 0 111.306-1.306 1.306 1.306 0 01-1.306 1.306zm0-3.857a1.305 1.305 0 11.924-.382 1.306 1.306 0 01-.924.382zm0-3.857a1.306 1.306 0 11.925-.384 1.306 1.306 0 01-.925.384zm3.218 7.714a1.307 1.307 0 11.922-.382 1.306 1.306 0 01-.922.382zm0-3.857a1.307 1.307 0 11.922-.381 1.306 1.306 0 01-.922.381zm0-3.857a1.307 1.307 0 11.92-.385 1.306 1.306 0 01-.92.385zm3.218 7.714a1.09 1.09 0 10-.008 0zm0-3.857a1.091 1.091 0 10-.008 0zm0-3.857a1.091 1.091 0 10-.008 0zm3.218 7.714a1.1 1.1 0 10-.012 0zm-1.306-5.166a.525.525 0 11-.012 0zm1.306-2.551a1.571 1.571 0 10-.012 0zm4.8 7c0 .355-.412.643-.921.643H15.5c-.508 0-.921-.288-.921-.643V1.768c0-.355.412-.643.921-.643h.461c.508 0 .921.288.921.643z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 54",
        d: "M16.348 2.78c-.318-1.052-.434-.893-.476-1.186-.013-.1-.346-.095-.351 0-.017.261-.15.378-.365.888-.236.562-.193 1 0 1.186h-.069v2.52a.274.274 0 00-.085.2v4.2h1.445v-4.2a.273.273 0 00-.085-.2V3.684c.106-.13.143-.393-.014-.904zm-.29 3.134h-.672V3.971h.67z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 55",
        d: "M2.43 1.246a1 1 0 101 1 1 1 0 00-1-1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 56",
        d: "M12.073 1.246a1 1 0 101 1 1 1 0 00-1-1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 57",
        d: "M8.859 5.103a1 1 0 101 1 1 1 0 00-1-1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 58",
        d: "M5.645 8.96a1 1 0 101 1 1 1 0 00-1-1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 59",
        d: "M12.073 8.96a1 1 0 101 1 1 1 0 00-1-1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/BathOil.tsx":
/*!**************************************!*\
  !*** ./src/assets/icons/BathOil.tsx ***!
  \**************************************/
/*! exports provided: BathOil */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BathOil", function() { return BathOil; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\BathOil.tsx";

const BathOil = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 27",
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 67",
        d: "M3.866 16.077a2.481 2.481 0 001.645-1.613h-.42q-.269 0-.531-.012a1.23 1.23 0 01-.87.755.724.724 0 10.175.863z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 68",
        d: "M15.172 16.479a.725.725 0 10-.432-1.309 1.458 1.458 0 01-.78-.77 4.085 4.085 0 01-.686.062h-.315a2.318 2.318 0 001.543 1.579.725.725 0 00.67.438z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 69",
        d: "M13.988 2.638l-1.482-1.482a5.015 5.015 0 00-1.356.863l1.972 1.972a4.972 4.972 0 00.866-1.353z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 70",
        d: "M11.173 3.19a.148.148 0 00.108-.043l.208-.208a.147.147 0 00-.164-.237.15.15 0 00-.044.029l-.209.208a.148.148 0 00.108.252z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 71",
        d: "M10.547 3.819a.148.148 0 00.108-.043l.208-.208a.148.148 0 00-.208-.208l-.208.208a.148.148 0 00.108.251z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 72",
        d: "M9.92 4.445a.148.148 0 00.108-.043l.208-.208a.148.148 0 00-.208-.208l-.208.208a.148.148 0 00.108.251z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 73",
        d: "M11.932 3.313a.146.146 0 00-.193-.193.15.15 0 00-.044.029l-.208.209a.148.148 0 00.209.208l.208-.209a.144.144 0 00.028-.044z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 74",
        d: "M11.277 3.775a.148.148 0 00-.208 0l-.208.208a.148.148 0 00.209.208l.208-.208a.148.148 0 000-.208z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 75",
        d: "M10.652 4.402a.148.148 0 00-.208 0l-.208.209a.148.148 0 00.209.208l.208-.209a.148.148 0 000-.208z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 76",
        d: "M12.007 4.028a.148.148 0 00.108-.043l.208-.208a.143.143 0 00.029-.044.148.148 0 00-.238-.164l-.208.208a.148.148 0 000 .208.146.146 0 00.101.043z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 77",
        d: "M11.38 4.654a.148.148 0 00.108-.043l.208-.208a.148.148 0 00-.208-.208l-.208.208a.148.148 0 00.108.251z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 78",
        d: "M10.756 5.28a.148.148 0 00.108-.043l.208-.208a.148.148 0 00-.208-.208l-.208.208a.148.148 0 00.108.251z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 79",
        d: "M17.414 7.083h-.886V.295a.295.295 0 00-.3-.3h-1.277a.3.3 0 00-.2.078l-1.061.976a1.175 1.175 0 00-.69.096l1.013 1.014a1.187 1.187 0 00.083-.68l.966-.888h.872v6.493H.59a.59.59 0 00-.59.591v.59a.59.59 0 00.59.59h.367c.045.229.108.491.176.794l.413 1.98a2.9 2.9 0 003.138 2.53c.134 0 .27.006.408.006h8.191a3.876 3.876 0 00.565-.041 3.157 3.157 0 002.637-2.342l.671-2.929h.3A.588.588 0 0018 8.265v-.59a.59.59 0 00-.586-.592zm-4.7 6.168a.035.035 0 000 .005v-.005z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/BeautyHealth.tsx":
/*!*******************************************!*\
  !*** ./src/assets/icons/BeautyHealth.tsx ***!
  \*******************************************/
/*! exports provided: BeautyHealth */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BeautyHealth", function() { return BeautyHealth; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\BeautyHealth.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const BeautyHealth = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "17.112",
    height: "24",
    viewBox: "0 0 17.112 24"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Beauty",
      transform: "translate(-1278.138 -490.139)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17448",
        "data-name": "Path 17448",
        d: "M1295.25,496.812a.432.432,0,0,0-.432-.432h-1.467a6.671,6.671,0,0,0-13.314,0h-1.467a.433.433,0,0,0-.432.432,8.567,8.567,0,0,0,8.124,8.545v6.335h-3.6a1.223,1.223,0,1,0,0,2.447h8.065a1.223,1.223,0,1,0,0-2.447h-3.6v-6.335A8.567,8.567,0,0,0,1295.25,496.812Zm-4.165,16.1a.359.359,0,0,1-.359.358h-8.065a.359.359,0,1,1,0-.717h8.065A.359.359,0,0,1,1291.085,512.916ZM1286.694,491a5.808,5.808,0,1,1-5.808,5.808A5.814,5.814,0,0,1,1286.694,491Zm-7.679,6.24h1.022a6.671,6.671,0,0,0,13.314,0h1.022a7.691,7.691,0,0,1-15.358,0Z",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17449",
        "data-name": "Path 17449",
        d: "M1334.423,532.013a.431.431,0,0,0,.306-.127l3.391-3.392a.432.432,0,0,0-.612-.611l-3.391,3.391a.432.432,0,0,0,.306.738Z",
        transform: "translate(-50.749 -34.18)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17450",
        "data-name": "Path 17450",
        d: "M1390.525,532.974a.431.431,0,0,0,.306-.127l.569-.569a.432.432,0,0,0-.612-.612l-.569.569a.433.433,0,0,0,.306.738Z",
        transform: "translate(-101.725 -37.618)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17451",
        "data-name": "Path 17451",
        d: "M1337.9,552.1a.432.432,0,0,0,.611,0l3.894-3.894a.432.432,0,0,0-.611-.611l-3.894,3.894A.432.432,0,0,0,1337.9,552.1Z",
        transform: "translate(-54.184 -52.089)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Beverage.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/Beverage.tsx ***!
  \***************************************/
/*! exports provided: Beverage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Beverage", function() { return Beverage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Beverage.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Beverage = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "14.569",
    height: "26.099",
    viewBox: "0 0 14.569 26.099"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "bevarage",
      d: "M901.182,394.343v-.267c0-1.455,0-2.911,0-4.366,0-.192-.037-.279-.246-.333a7.179,7.179,0,0,1-5.405-7.48c.093-1.293.3-2.579.459-3.867q.247-2,.5-3.993a.536.536,0,0,1,.621-.544q5.626,0,11.252,0a.536.536,0,0,1,.614.552c.306,2.43.6,4.862.92,7.291a7.253,7.253,0,0,1-5.12,7.982c-.482.144-.483.144-.483.663q0,2.04,0,4.08v.27c.508.073,1,.13,1.5.219a7.565,7.565,0,0,1,2.734.93,2.92,2.92,0,0,1,.508.4,1.325,1.325,0,0,1,.01,2,3.705,3.705,0,0,1-1.341.82,12.018,12.018,0,0,1-3.443.721,16.444,16.444,0,0,1-5.062-.306,12.666,12.666,0,0,1-1.887-.633,2.91,2.91,0,0,1-.834-.562,1.323,1.323,0,0,1-.03-2.054,4.29,4.29,0,0,1,1.763-.958,12.137,12.137,0,0,1,2.667-.527C900.976,394.376,901.069,394.359,901.182,394.343Zm7.541-13.96c-.329.106-.636.19-.933.3a5.372,5.372,0,0,1-3.76.018c-.931-.323-1.869-.626-2.8-.937a4.011,4.011,0,0,0-2.269-.227c-.695.174-1.376.4-2.061.617a.231.231,0,0,0-.129.159,12.072,12.072,0,0,0-.171,2.765,6.182,6.182,0,0,0,8.7,4.938,6.035,6.035,0,0,0,3.624-5.24A10.427,10.427,0,0,0,908.723,380.383Zm-11.243-5.84-.56,4.5c.2-.061.359-.1.51-.159a5.867,5.867,0,0,1,4.451,0c.917.356,1.867.628,2.806.925a3.391,3.391,0,0,0,1.868.129c.644-.163,1.277-.372,1.909-.577.055-.018.108-.16.1-.237-.125-1.074-.262-2.147-.4-3.22q-.085-.677-.17-1.354Zm3.7,20.782c-.893.191-1.747.332-2.574.567a5.433,5.433,0,0,0-1.343.65c-.332.206-.326.45-.006.681a4.151,4.151,0,0,0,.97.535,12.9,12.9,0,0,0,4.672.683,12.466,12.466,0,0,0,4.433-.712,3.869,3.869,0,0,0,.776-.41c.457-.312.453-.555.006-.869a3.233,3.233,0,0,0-.517-.294,10.12,10.12,0,0,0-3.3-.76c0,.471,0,.928,0,1.384,0,.429-.192.623-.615.624q-.948,0-1.9,0a.531.531,0,0,1-.607-.6C901.18,396.347,901.182,395.889,901.182,395.326Zm1.058-5.713v6.734h1v-6.734Z",
      transform: "translate(-895.457 -373.443)",
      fill: "currentColor",
      stroke: "#fff",
      strokeWidth: "0.1"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Breakfast.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/Breakfast.tsx ***!
  \****************************************/
/*! exports provided: Breakfast */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Breakfast", function() { return Breakfast; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Breakfast.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Breakfast = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "25.408",
    height: "18.5",
    viewBox: "0 0 25.408 18.5"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Breakfast",
      transform: "translate(0.25 -70.75)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17388",
        "data-name": "Path 17388",
        d: "M241.73,131a.73.73,0,0,0-.73.73v1.946a.73.73,0,0,0,1.459,0V131.73A.73.73,0,0,0,241.73,131Z",
        transform: "translate(-229.276 -57.081)",
        fill: "currentColor",
        stroke: "#fff",
        strokeWidth: "0.4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17389",
        "data-name": "Path 17389",
        d: "M292.335,131.324a.73.73,0,1,0-1.214.81l.973,1.459a.73.73,0,0,0,1.214-.81Z",
        transform: "translate(-276.841 -57.08)",
        fill: "currentColor",
        stroke: "#fff",
        strokeWidth: "0.4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17390",
        "data-name": "Path 17390",
        d: "M173.105,131.121a.73.73,0,0,0-1.012.2l-.973,1.459a.73.73,0,1,0,1.214.81l.973-1.459A.73.73,0,0,0,173.105,131.121Z",
        transform: "translate(-162.679 -57.08)",
        fill: "currentColor",
        stroke: "#fff",
        strokeWidth: "0.4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17391",
        "data-name": "Path 17391",
        d: "M24.908,80.487A2.68,2.68,0,0,0,22.926,77.9a6.867,6.867,0,0,0-3.151-4.777A12.907,12.907,0,0,0,12.454,71a12.907,12.907,0,0,0-7.321,2.125A6.867,6.867,0,0,0,1.982,77.9a2.676,2.676,0,0,0,.159,5.207l.874,3.5A3.158,3.158,0,0,0,6.083,89H18.825a3.158,3.158,0,0,0,3.068-2.4l.874-3.5A2.68,2.68,0,0,0,24.908,80.487ZM4.431,86.251l-.772-3.089H6.945l.547,4.378H6.083a1.7,1.7,0,0,1-1.652-1.29Zm12.061-3.089-.547,4.378H13.184V83.162Zm-4.768,4.378H8.963l-.547-4.378h3.309Zm8.753-1.29a1.7,1.7,0,0,1-1.652,1.29H17.416l.547-4.378h3.286ZM22.232,81.7H2.676a1.216,1.216,0,0,1,0-2.432.73.73,0,0,0,.73-.73,5.255,5.255,0,0,1,2.561-4.217,11.44,11.44,0,0,1,6.488-1.864,11.44,11.44,0,0,1,6.488,1.864A5.255,5.255,0,0,1,21.5,78.541a.73.73,0,0,0,.73.73,1.216,1.216,0,1,1,0,2.432Z",
        transform: "translate(0 0)",
        fill: "currentColor",
        stroke: "#fff",
        strokeWidth: "0.5"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/CloseIcon.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/CloseIcon.tsx ***!
  \****************************************/
/*! exports provided: CloseIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloseIcon", function() { return CloseIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CloseIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseIcon = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "10.003",
    height: "10",
    viewBox: "0 0 10.003 10"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "_ionicons_svg_ios-close (5)",
      d: "M166.686,165.55l3.573-3.573a.837.837,0,0,0-1.184-1.184l-3.573,3.573-3.573-3.573a.837.837,0,1,0-1.184,1.184l3.573,3.573-3.573,3.573a.837.837,0,0,0,1.184,1.184l3.573-3.573,3.573,3.573a.837.837,0,0,0,1.184-1.184Z",
      transform: "translate(-160.5 -160.55)",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Cooking.tsx":
/*!**************************************!*\
  !*** ./src/assets/icons/Cooking.tsx ***!
  \**************************************/
/*! exports provided: Cooking */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cooking", function() { return Cooking; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Cooking.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Cooking = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "28.9",
    height: "16.9",
    viewBox: "0 0 28.9 16.9"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Cooking",
      transform: "translate(-61.55 -195.55)",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_12320",
        "data-name": "Group 12320",
        transform: "translate(62 196)",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_12319",
          "data-name": "Group 12319",
          transform: "translate(11.006 10.518)",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            id: "Line_10",
            "data-name": "Line 10",
            x2: "0.963",
            fill: "none",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "0.9"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            id: "Line_11",
            "data-name": "Line 11",
            x2: "0.963",
            transform: "translate(2.345)",
            fill: "none",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "0.9"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            id: "Line_12",
            "data-name": "Line 12",
            x2: "0.963",
            transform: "translate(4.691)",
            fill: "none",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "0.9"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          id: "Path_17428",
          "data-name": "Path 17428",
          d: "M578.074,414.485l3.192-.59v-1.15h-3.192Z",
          transform: "translate(-553.266 -406.978)",
          fill: "none",
          stroke: "currentColor",
          strokeLinejoin: "round",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          id: "Path_17429",
          "data-name": "Path 17429",
          d: "M506.668,414.485l-3.192-.59v-1.15h3.192Z",
          transform: "translate(-503.476 -406.978)",
          fill: "none",
          stroke: "currentColor",
          strokeLinejoin: "round",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          id: "Path_17430",
          "data-name": "Path 17430",
          d: "M523.823,401.744a17.212,17.212,0,0,0-10.749,3.829h21.615A17.751,17.751,0,0,0,523.823,401.744Z",
          transform: "translate(-509.882 -399.805)",
          fill: "none",
          stroke: "currentColor",
          strokeLinejoin: "round",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
          id: "Line_13",
          "data-name": "Line 13",
          y1: "1.939",
          transform: "translate(13.941)",
          fill: "none",
          stroke: "currentColor",
          strokeMiterlimit: "10",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
          id: "Line_14",
          "data-name": "Line 14",
          x2: "3.606",
          transform: "translate(12.197)",
          fill: "none",
          stroke: "currentColor",
          strokeMiterlimit: "10",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          id: "Path_17431",
          "data-name": "Path 17431",
          d: "M534.69,412.643s-.333,10.268-5.321,10.268H518.395c-4.988,0-5.321-10.268-5.321-10.268Z",
          transform: "translate(-509.882 -406.911)",
          fill: "none",
          stroke: "currentColor",
          strokeLinejoin: "round",
          strokeWidth: "0.9"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 102,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Dairy.tsx":
/*!************************************!*\
  !*** ./src/assets/icons/Dairy.tsx ***!
  \************************************/
/*! exports provided: Dairy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Dairy", function() { return Dairy; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Dairy.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Dairy = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "16.967",
    height: "22.1",
    viewBox: "0 0 16.967 22.1"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Dairy",
      transform: "translate(-71.95 -15.95)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17395",
        "data-name": "Path 17395",
        d: "M72.733,36.167v-8.8a8.516,8.516,0,0,1,.693-3.374l.755-1.762c.064-.15.126-.3.183-.46a6.94,6.94,0,0,1,2.722.055,7.585,7.585,0,0,0,2.869.085c.041.107.085.214.13.321l.755,1.763.674-.289-.755-1.763c-.08-.188-.154-.379-.22-.568a8.55,8.55,0,0,1-.465-2.44h.359a.367.367,0,0,0,.367-.367V17.1A1.1,1.1,0,0,0,79.7,16H74.567a1.1,1.1,0,0,0-1.1,1.1v1.467a.367.367,0,0,0,.367.367h.359a8.552,8.552,0,0,1-.45,2.4c-.071.207-.15.412-.235.61L72.752,23.7A9.247,9.247,0,0,0,72,27.367v8.8A1.835,1.835,0,0,0,73.833,38H79.7v-.733H73.833A1.1,1.1,0,0,1,72.733,36.167ZM74.2,17.1a.367.367,0,0,1,.367-.367H79.7a.367.367,0,0,1,.367.367v1.1H74.2Zm5.141,1.833a9.271,9.271,0,0,0,.375,2.27,6.855,6.855,0,0,1-2.47-.095,7.673,7.673,0,0,0-2.633-.118,9.278,9.278,0,0,0,.314-2.057Z",
        transform: "translate(0 0)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17397",
        "data-name": "Path 17397",
        d: "M241.533,201.833c0-1.2-2.4-1.833-4.767-1.833s-4.767.63-4.767,1.833a.88.88,0,0,0,.01.132l1.092,11.271a.367.367,0,0,0,.365.33h6.6a.367.367,0,0,0,.365-.33l1.092-11.271A.884.884,0,0,0,241.533,201.833Zm-1,3-.185.062a5.813,5.813,0,0,1-3.526.053,6.566,6.566,0,0,0-3.778,0l-.033.01-.181-2.047a10.662,10.662,0,0,0,7.873,0Zm-3.767-4.1c2.593,0,4.015.717,4.032,1.093l0,.046c-.091.382-1.506,1.061-4.028,1.061s-3.937-.679-4.028-1.061l0-.046C232.752,201.451,234.173,200.733,236.767,200.733Zm2.968,12.1H233.8l-.718-7.128.175-.052a5.859,5.859,0,0,1,3.357,0,6.539,6.539,0,0,0,3.845-.02Z",
        transform: "translate(-152.667 -175.567)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Deodorant.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/Deodorant.tsx ***!
  \****************************************/
/*! exports provided: Deodorant */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Deodorant", function() { return Deodorant; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Deodorant.tsx";

const Deodorant = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "018---Roll-On",
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
        cx: "1.607",
        cy: "3.535",
        rx: "1.607",
        ry: "3.535",
        transform: "translate(2.176 8.678)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        d: "M7.244 4.821H.321a.321.321 0 00-.32.356l.027.254a71.835 71.835 0 01.311 11.215A1.282 1.282 0 001.621 18h4.325a1.282 1.282 0 001.282-1.353 71.835 71.835 0 01.3-11.214l.027-.254a.321.321 0 00-.316-.358zm-6.355.962a.321.321 0 01.321-.321h.641a.321.321 0 110 .641H1.21a.321.321 0 01-.321-.32zm2.9 10.607c-1.261 0-2.25-1.832-2.25-4.178s.988-4.178 2.25-4.178 2.25 1.832 2.25 4.178-.995 4.181-2.256 4.181zM6.354 6.104H3.14a.321.321 0 110-.641h3.214a.321.321 0 110 .641z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Shape",
        d: "M3.783 0a2.25 2.25 0 00-2.224 1.929h4.447A2.25 2.25 0 003.783 0zM6.443 2.572H1.128a5.946 5.946 0 00-.237 1.607h5.785a5.946 5.946 0 00-.233-1.607zM11.82 16.716h3.214v-1.284a2.893 2.893 0 10-5.786 0v1.284h.964a.321.321 0 010 .641h-.964v.321a.321.321 0 00.321.321h5.143a.321.321 0 00.321-.321v-.321H11.82a.321.321 0 110-.641zm-.964-1.929a.321.321 0 01-.641 0 1.55 1.55 0 011.606-1.608.321.321 0 110 .641.916.916 0 00-.966.964z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Eyes.tsx":
/*!***********************************!*\
  !*** ./src/assets/icons/Eyes.tsx ***!
  \***********************************/
/*! exports provided: Eyes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Eyes", function() { return Eyes; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Eyes.tsx";

const Eyes = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 49",
        d: "M3.002 0h-1.5v.75h-1.5v1.5h1.5V3h-1.5v1.5h1.5v.75h-1.5v1.5h1.5v3.75h-.75a.75.75 0 00-.744.842l.75 6a.75.75 0 00.744.657h1.5a.75.75 0 00.744-.657l.75-6a.75.75 0 00-.744-.842h-.75V6.748h1.5v-1.5h-1.5V4.5h1.5V3h-1.5v-.75h1.5V.75h-1.5z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 50",
        d: "M11.995 17.187l-.746-9.69h-4.5l-.747 9.69a.75.75 0 00.748.807h4.5a.75.75 0 00.748-.807z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 51",
        d: "M11.251 5.249a.75.75 0 00-.75-.75h-3a.75.75 0 00-.75.75v1.5h4.5z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Face.tsx":
/*!***********************************!*\
  !*** ./src/assets/icons/Face.tsx ***!
  \***********************************/
/*! exports provided: Face */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Face", function() { return Face; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Face.tsx";

const Face = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 41",
        d: "M6.388 9.238c-3.319 0-5.11 1.36-5.11 1.911s1.791 1.911 5.11 1.911a9.995 9.995 0 002.653-.345 5.1 5.1 0 011.387-2.612 8.865 8.865 0 00-4.04-.864z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 42",
        d: "M8.34 8.908a7.515 7.515 0 012.3.841 5.111 5.111 0 01.581-.391 7 7 0 00-1.969-.887 5.957 5.957 0 01-.912.438z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 43",
        d: "M8.958 13.383a10.774 10.774 0 01-2.571.3c-3.29 0-5.749-1.349-5.749-2.555 0-.908 1.394-1.9 3.484-2.33a6.017 6.017 0 01-.9-.433c-1.96.571-3.224 1.647-3.224 2.762 0 1.731 2.922 3.193 6.388 3.193a11.64 11.64 0 002.573-.285c-.008-.112-.018-.234-.018-.354.002-.097.011-.197.017-.298z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 44",
        d: "M6.388 8.952a4.833 4.833 0 005.11-4.471A4.833 4.833 0 006.388.01a4.833 4.833 0 00-5.11 4.471 4.833 4.833 0 005.11 4.471zm0-8.3a4.194 4.194 0 014.471 3.833 4.194 4.194 0 01-4.471 3.833A4.194 4.194 0 011.917 4.48 4.194 4.194 0 016.388.647z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 45",
        d: "M6.391 7.675a3.561 3.561 0 003.833-3.193 3.561 3.561 0 00-3.833-3.195A3.561 3.561 0 002.558 4.48a3.561 3.561 0 003.833 3.195zm0-5.749a2.969 2.969 0 013.193 2.555h-.638c0-1.039-1.17-1.911-2.555-1.911z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 46",
        d: "M17.39 11.304a6.91 6.91 0 01-.592.319 5.4 5.4 0 00-2.518 2.518 6.026 6.026 0 01-2.81 2.81 7.22 7.22 0 00-.486.259 4.466 4.466 0 006.407-5.9zm-3.877 6.051v-.638a3.238 3.238 0 00.581-.053l.112.628a3.847 3.847 0 01-.694.063zm1.394-.261l-.233-.595a3.176 3.176 0 002.032-2.976h.638a3.812 3.812 0 01-2.438 3.571z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 47",
        d: "M12.66 15.332a4.74 4.74 0 001.044-1.472 6.029 6.029 0 012.809-2.815c.173-.085.337-.17.518-.278a4.527 4.527 0 00-.4-.45 6.37 6.37 0 01-.731.407 5.386 5.386 0 00-2.512 2.521 6.03 6.03 0 01-2.81 2.81 6.962 6.962 0 00-.532.285 4.507 4.507 0 00.414.438 6.34 6.34 0 01.727-.406 4.733 4.733 0 001.474-1.042z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 48",
        d: "M11.769 14.439a4.74 4.74 0 001.044-1.472 6.022 6.022 0 012.81-2.81c.166-.082.328-.164.5-.265a4.462 4.462 0 00-6.435 5.922c.219-.136.419-.236.614-.337a4.747 4.747 0 001.47-1.037z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/FacialCare.tsx":
/*!*****************************************!*\
  !*** ./src/assets/icons/FacialCare.tsx ***!
  \*****************************************/
/*! exports provided: FacialCare */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FacialCare", function() { return FacialCare; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\FacialCare.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FacialCare = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "18.814",
    height: "24",
    viewBox: "0 0 18.814 24"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Makup",
      transform: "translate(-507.818 -485.385)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17426",
        "data-name": "Path 17426",
        d: "M514.58,502.867a.721.721,0,0,0-.448-.579.411.411,0,0,0-.125-.041v-4.5a.591.591,0,0,0-.29-.5V494.9a6.977,6.977,0,0,0-.675-2.868l0-.009,0-.005a3.2,3.2,0,0,0-.272-.449,1.188,1.188,0,0,0-1.347-.362,2.261,2.261,0,0,0-1.492,1.22l-.022.045a6.315,6.315,0,0,0-.338.874c0,.007-.006.012-.008.019s0,.01,0,.015a7.074,7.074,0,0,0-.292,2.044v1.707c-.336.144-.509.35-.509.613v4.486c-.354.155-.545.364-.57.622,0,.006,0,.011,0,.017a71.956,71.956,0,0,0-.289,10.391c0,.787,1.5,1.38,3.49,1.38s3.49-.593,3.489-1.355a72.1,72.1,0,0,0-.288-10.417ZM512.8,494a5.335,5.335,0,0,1,.085.9v2.779a6.961,6.961,0,0,1-1.5.142,7.622,7.622,0,0,1-1.284-.1v-2.3a6.715,6.715,0,0,1,.043-.751,1.974,1.974,0,0,0,.891.2A2.569,2.569,0,0,0,512.8,494Zm-3.209,4.464a8.613,8.613,0,0,0,3.585,0v4.508a10.2,10.2,0,0,1-3.585,0Zm1.087-5.676a1.447,1.447,0,0,1,.938-.773c.172-.042.394-.067.479.048a2.406,2.406,0,0,1,.206.344v0a.832.832,0,0,1-.006.876,1.743,1.743,0,0,1-1.264.749.87.87,0,0,1-.655-.213c-.017-.023-.055-.077-.019-.21a5.462,5.462,0,0,1,.3-.781Zm3.364,20.4a6.081,6.081,0,0,1-5.316,0,71.567,71.567,0,0,1,.219-9.528,10,10,0,0,0,4.877,0A71.829,71.829,0,0,1,514.038,513.194Z",
        transform: "translate(0 -5.256)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17427",
        "data-name": "Path 17427",
        d: "M618.005,487.378c-.617-1.323-2.2-1.993-4.7-1.993s-4.08.671-4.7,1.994c-1.3,2.781,2.328,7.41,2.923,8.139l-.194,12.539c0,.514.524,1.279,1.969,1.279s1.969-.765,1.969-1.286l-.195-12.532C615.675,494.791,619.3,490.161,618.005,487.378Zm-5.671,10.394.026-1.66a3.555,3.555,0,0,0,.65.1.415.415,0,0,0,.088.01c.013,0,.024,0,.037,0,.058,0,.116,0,.174,0a3.918,3.918,0,0,0,.949-.107l.026,1.66a2.931,2.931,0,0,1-1.949,0Zm-2.966-10.041c.468-1,1.794-1.511,3.94-1.511s3.472.508,3.94,1.511c.836,1.792-1.112,5.009-2.374,6.7a6.637,6.637,0,0,0,.23-1.731.417.417,0,0,0-.417-.417h0a.418.418,0,0,0-.417.417c0,.657-.2,2.461-1.017,2.665a2.056,2.056,0,0,1-.49-1.175.417.417,0,0,0-.826.123,4.453,4.453,0,0,0,.112.518C610.835,493.3,608.46,489.678,609.368,487.731Zm3.94,20.771c-.9,0-1.126-.359-1.134-.438l.146-9.408a4.2,4.2,0,0,0,1.976,0l.146,9.4C614.435,508.143,614.208,508.5,613.308,508.5Z",
        transform: "translate(-91.651)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/FruitsVegetable.tsx":
/*!**********************************************!*\
  !*** ./src/assets/icons/FruitsVegetable.tsx ***!
  \**********************************************/
/*! exports provided: FruitsVegetable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FruitsVegetable", function() { return FruitsVegetable; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\FruitsVegetable.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FruitsVegetable = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20.347",
    height: "24.101",
    viewBox: "0 0 20.347 24.101"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Grocery",
      transform: "translate(-39.481 0.052)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17386",
        "data-name": "Path 17386",
        d: "M349.261,399.988a.469.469,0,1,1,.461-.385A.473.473,0,0,1,349.261,399.988Z",
        transform: "translate(-294.289 -380.346)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17387",
        "data-name": "Path 17387",
        d: "M58.743,8.638A6.2,6.2,0,0,0,55.4,6.3a6.662,6.662,0,0,0-3.058.055h0l-.034.008-.091.02c-.074.017-.188.045-.31.076-.16.041-.323.078-.485.108q0-.182-.014-.374a6.162,6.162,0,0,1,1.87-3.956A6.643,6.643,0,0,1,55.212.9.469.469,0,0,0,54.87.032a7.448,7.448,0,0,0-2.223,1.509,7.229,7.229,0,0,0-1.659,2.437,4.837,4.837,0,0,0-1.119-1.837C47.744.019,43.762.68,43.527.721h0a.457.457,0,0,0-.367.314.6.6,0,0,0-.017.066c-.027.151-.573,3.346.8,5.557a7.353,7.353,0,0,0-3.914,6.923,11.6,11.6,0,0,0,1.142,4.581,14.2,14.2,0,0,0,2.744,4.091A5.044,5.044,0,0,0,47.309,24a6.6,6.6,0,0,0,1.88-.276A3.331,3.331,0,0,1,51,23.691l.006,0,.11.031A6.6,6.6,0,0,0,53,24a4.912,4.912,0,0,0,3.25-1.608,13.985,13.985,0,0,0,4.029-8.812A8.163,8.163,0,0,0,58.743,8.638ZM49.206,2.8a5.247,5.247,0,0,1,1.256,3.409c-.017.211-.025,1.132-.025,1.132L46.881,3.794a.469.469,0,0,0-.663.663L49.8,8.033c-1.224.066-3.343-.027-4.572-1.255C43.75,5.3,43.912,2.552,44.02,1.6c.953-.108,3.709-.27,5.185,1.2ZM55.6,21.716A4.033,4.033,0,0,1,53,23.062a5.728,5.728,0,0,1-1.609-.236l-.141-.04h0a4.269,4.269,0,0,0-2.329.04,5.728,5.728,0,0,1-1.609.236A4.172,4.172,0,0,1,44.58,21.59a13.058,13.058,0,0,1-3.612-8.009c0-3.445,1.878-5.444,3.571-6.163l.024.024a6.632,6.632,0,0,0,4.665,1.547A9.91,9.91,0,0,0,50.9,8.863c.374-.082.365-.256.388-.364V8.482a9.219,9.219,0,0,0,.107-.965.475.475,0,0,0,.083-.007c.22-.038.441-.085.658-.142.084-.022.165-.042.232-.058,1.934.674,3.846,2.849,3.846,6.269a9.857,9.857,0,0,1-.747,3.455.469.469,0,1,0,.874.339,10.789,10.789,0,0,0,.811-3.795,7.594,7.594,0,0,0-3.162-6.493,4.317,4.317,0,0,1,1.17.122c2.013.521,4.18,2.737,4.18,6.371A13.138,13.138,0,0,1,55.6,21.716Z",
        transform: "translate(-0.5)",
        fill: "currentColor",
        stroke: "currentColor",
        strokeWidth: "0.1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/HandBags.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/HandBags.tsx ***!
  \***************************************/
/*! exports provided: HandBags */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HandBags", function() { return HandBags; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\HandBags.tsx";

const HandBags = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 11",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 10",
        fill: color,
        stroke: "#fff",
        strokeMiterlimit: "10",
        strokeWidth: ".091",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 45",
          d: "M17.954 7.253v8.585a1.791 1.791 0 01-1.791 1.791H1.836a1.791 1.791 0 01-1.791-1.791V7.253c0-.988 17.909-.988 17.909 0z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Rectangle 36",
          d: "M.102 8.77h17.795v.913H.102z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 46",
          d: "M4.793 7.253C4.976 4.061 7.113.614 9 .614c2.41 0 4.049 3.84 4.207 6.639h.572C13.618 4.168 11.791.044 8.999.044c-1.131 0-2.338.922-3.312 2.529a10.463 10.463 0 00-1.466 4.68z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/HomeCleaning.tsx":
/*!*******************************************!*\
  !*** ./src/assets/icons/HomeCleaning.tsx ***!
  \*******************************************/
/*! exports provided: HomeCleaning */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeCleaning", function() { return HomeCleaning; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\HomeCleaning.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const HomeCleaning = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20.59",
    height: "25.05",
    viewBox: "0 0 20.59 25.05"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "home_cleaner",
      "data-name": "home cleaner",
      transform: "translate(-2142.193 -787.635)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17440",
        "data-name": "Path 17440",
        d: "M2188.815,831.346a2.538,2.538,0,0,1,2.6-1.81v-1.584a27.676,27.676,0,0,0-3.734-.111,3.962,3.962,0,0,0-3.169,2.034c-.33.684,2.49-.339,2.716,1.471",
        transform: "translate(-39.669 -37.554)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17441",
        "data-name": "Path 17441",
        d: "M2289.466,862.334a10.742,10.742,0,0,0,1.89,3.765c.082.119-.025.28-.137.207a6.8,6.8,0,0,1-2.94-3.5",
        transform: "translate(-138.167 -70.32)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17442",
        "data-name": "Path 17442",
        d: "M2226.052,898.788a2.93,2.93,0,0,0,1.4.214,3.341,3.341,0,0,0,1.319-.214v-1.436a.17.17,0,0,0-.169-.17h-2.377a.17.17,0,0,0-.169.17Z",
        transform: "translate(-79.113 -103.39)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17443",
        "data-name": "Path 17443",
        d: "M2156.93,1189.207",
        transform: "translate(-13.516 -380.522)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17444",
        "data-name": "Path 17444",
        d: "M2320.353,830.622h1.328v1.584h-1.328",
        transform: "translate(-168.605 -40.225)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17445",
        "data-name": "Path 17445",
        d: "M2153.421,936.6a15.113,15.113,0,0,1-1.134,4.707.744.744,0,0,1-.68.515h-7.4a.751.751,0,0,1-.688-.544,12.078,12.078,0,0,1,2.065-12.242,3.527,3.527,0,0,0,.679-3.055,1.052,1.052,0,0,1,.675-1.195",
        transform: "translate(0 -129.588)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17446",
        "data-name": "Path 17446",
        d: "M2278.913,926.025c1.471.905-.25,1.974.006,2.2.847.757-.006,1.8-.006,1.8a1.4,1.4,0,0,1,.369,1.741,8.765,8.765,0,0,1,2.391,2.01",
        transform: "translate(-129.259 -130.762)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_15",
        "data-name": "Line 15",
        y1: "1.511",
        x2: "3.16",
        transform: "translate(2154.628 788.235)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_16",
        "data-name": "Line 16",
        x2: "3.16",
        y2: "1.511",
        transform: "translate(2154.628 792.632)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_17",
        "data-name": "Line 17",
        x2: "4.259",
        transform: "translate(2154.628 791.189)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_9",
        "data-name": "Ellipse 9",
        cx: "2.047",
        cy: "2.047",
        r: "2.047",
        transform: "translate(2158.239 799.709)",
        strokeWidth: "0.9",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 128,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17447",
        "data-name": "Path 17447",
        d: "M2383.738,957.387a1.489,1.489,0,0,0,2.978,0,1.489,1.489,0,0,0-2.978,0Z",
        transform: "translate(-228.757 -159.112)",
        fill: "none",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "0.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_10",
        "data-name": "Ellipse 10",
        cx: "2.764",
        cy: "2.764",
        r: "2.764",
        transform: "translate(2152.212 802.109)",
        strokeWidth: "0.9",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 152,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/LaptopBags.tsx":
/*!*****************************************!*\
  !*** ./src/assets/icons/LaptopBags.tsx ***!
  \*****************************************/
/*! exports provided: LaptopBags */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LaptopBags", function() { return LaptopBags; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\LaptopBags.tsx";

const LaptopBags = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 6",
      fill: color,
      stroke: "#fff",
      strokeMiterlimit: "10",
      strokeWidth: ".091",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 22",
        d: "M6.224 1.741a.408.408 0 01-.292-.175l-.013-.018v-.022c-.08-.612.818-.747.856-.753l.4-.057-.334.222h0a.807.807 0 00-.128.338c-.105.42-.375.465-.489.465zm-.13-.263a.213.213 0 00.13.081c.106 0 .244-.056.305-.323a1.686 1.686 0 01.07-.237c-.214.064-.523.205-.505.479z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 23",
        d: "M9 6.496H.046v6.8a.833.833 0 00.833.833h16.243a.833.833 0 00.833-.833v-6.8z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 24",
        d: "M17.44 2.135H.561a.515.515 0 00-.515.515v6.285a.833.833 0 00.833.833h16.243a.833.833 0 00.833-.833V2.65a.515.515 0 00-.515-.515z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 25",
        d: "M11.776 1.741c-.113 0-.387-.045-.482-.464a.734.734 0 00-.134-.342l-.334-.222.4.061c.038.006.936.141.856.753v.022l-.013.018a.408.408 0 01-.293.174zM11.4.999a1.682 1.682 0 01.071.238c.061.267.2.323.305.323a.216.216 0 00.13-.081c.019-.276-.291-.416-.506-.48z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 26",
        d: "M11.295.752A3.333 3.333 0 009 .045a3.333 3.333 0 00-2.295.707.136.136 0 00.158.222A3.036 3.036 0 018.999.318a3.037 3.037 0 012.136.656.136.136 0 10.158-.222z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 27",
        d: "M9 9.419h-.958v.751h1.917v-.751z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 28",
        d: "M8.698 8.214h0a.9.9 0 00-.657 1.24h1.917a.9.9 0 00-.657-1.24h0a1.656 1.656 0 00-.6 0z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 29",
        d: "M9 10.17h-.958v1.009h1.917V10.17z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 30",
        d: "M9 10.473h-.807v.706h1.615v-.706z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 31",
        d: "M4.725 2.135h1.136a1.287 1.287 0 00.648-.83.118.118 0 00-.117-.139h0a.116.116 0 00-.095.048 1.873 1.873 0 01-1.38.721.118.118 0 00-.088.05z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 32",
        d: "M13.275 2.135H12.14a1.287 1.287 0 01-.648-.83.118.118 0 01.116-.139h0a.116.116 0 01.095.048 1.873 1.873 0 001.38.721.118.118 0 01.088.05z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Lips.tsx":
/*!***********************************!*\
  !*** ./src/assets/icons/Lips.tsx ***!
  \***********************************/
/*! exports provided: Lips */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Lips", function() { return Lips; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Lips.tsx";

const Lips = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 14",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 52",
        d: "M6.035 17.392v-6.2a.567.567 0 00-.516-.61H5.5V5.269h-.527c0-.877.008-1.608.013-2.212.019-2.149.023-2.66-.235-2.923A.454.454 0 004.422 0a1.282 1.282 0 00-.549.193 4.29 4.29 0 01-.708.3 2.882 2.882 0 00-2.117 2.235v2.541H.541v5.306H.519a.567.567 0 00-.516.61v6.2a.567.567 0 00.516.61h5.006a.567.567 0 00.51-.603zm-1.144-6.817H1.148V5.932l3.743.043z",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/MeatFish.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/MeatFish.tsx ***!
  \***************************************/
/*! exports provided: MeatFish */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MeatFish", function() { return MeatFish; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\MeatFish.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const MeatFish = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "24.003",
    height: "24",
    viewBox: "0 0 24.003 24"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Meat_Fish",
      "data-name": "Meat & Fish",
      transform: "translate(-100.274 -126.786)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17433",
        "data-name": "Path 17433",
        d: "M152.165,147.238c-.186,0-.366-.005-.542-.016a.465.465,0,0,1-.27-.108c-.525-.442-1.049-.911-1.546-1.38-.508-.508-.952-1.036-1.383-1.546a.545.545,0,0,1-.124-.289c-.234-3.811,2.129-10.143,4.769-12.784a9.528,9.528,0,0,1,1.8-1.453.463.463,0,1,1,.5.781,8.639,8.639,0,0,0-1.629,1.318c-2.42,2.42-4.661,8.375-4.515,11.929.4.474.8.944,1.236,1.378.439.414.907.835,1.379,1.236,3.5.153,9.508-2.1,11.919-4.506a8.691,8.691,0,0,0,1.328-1.638.463.463,0,1,1,.781.5,9.625,9.625,0,0,1-1.462,1.8C161.888,144.973,156.01,147.238,152.165,147.238Z",
        transform: "translate(-42.009 -2.453)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17434",
        "data-name": "Path 17434",
        d: "M105.065,249.978a2.457,2.457,0,0,1-1.745-.729,2.547,2.547,0,0,1-.707-1.61,2.454,2.454,0,0,1-2.338-2.483,2.479,2.479,0,0,1,3.513-2.21l2.637-2.663a.464.464,0,0,1,.659.653l-2.889,2.916a.465.465,0,0,1-.592.055,1.547,1.547,0,0,0-2.4,1.257,1.544,1.544,0,0,0,.457,1.114,1.572,1.572,0,0,0,1.365.416.463.463,0,0,1,.535.536,1.592,1.592,0,0,0,.425,1.374,1.54,1.54,0,0,0,2.355-1.963.464.464,0,0,1,.062-.583l2.916-2.888a.463.463,0,1,1,.652.658l-2.668,2.644a2.487,2.487,0,0,1-.491,2.778A2.454,2.454,0,0,1,105.065,249.978Z",
        transform: "translate(0 -99.192)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17435",
        "data-name": "Path 17435",
        d: "M206.374,138.769a5.236,5.236,0,0,1-2-.475A14.609,14.609,0,0,1,200,135.177c-2.193-2.193-3.6-4.707-3.593-6.4a1.862,1.862,0,0,1,1.989-1.987h.018c1.7,0,4.2,1.408,6.385,3.593l0,0c2.629,2.655,4.592,6.308,3.05,7.848A2.011,2.011,0,0,1,206.374,138.769Zm-7.96-11.056H198.4a.948.948,0,0,0-1.067,1.066c-.008,1.439,1.327,3.747,3.322,5.743a13.669,13.669,0,0,0,4.084,2.92c1.138.483,2.054.532,2.455.133.814-.814-.239-3.7-3.054-6.541C202.153,129.045,199.854,127.713,198.414,127.713Z",
        transform: "translate(-84.117 0)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17436",
        "data-name": "Path 17436",
        d: "M216.843,148.223h0c-1.039,0-2.9-1.214-4.749-3.084-1.538-1.518-3.09-3.585-3.079-4.77a.963.963,0,0,1,.283-.715.95.95,0,0,1,.7-.266H210c1.187,0,3.243,1.544,4.76,3.081,1.868,1.845,3.079,3.707,3.082,4.746a.944.944,0,0,1-1,1.008Zm-6.811-7.916a.268.268,0,0,0-.1.017c-.133.33.7,2.069,2.815,4.161,2.27,2.3,3.912,2.933,4.181,2.8.115-.253-.521-1.895-2.816-4.159l0,0C212.174,141.163,210.54,140.306,210.032,140.306Z",
        transform: "translate(-95.146 -11.027)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17437",
        "data-name": "Path 17437",
        d: "M181.251,168.174l-.83-.41a5.223,5.223,0,0,1,.391-.689.464.464,0,0,1,.755.539A4.148,4.148,0,0,0,181.251,168.174Z",
        transform: "translate(-70.129 -35.084)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17438",
        "data-name": "Path 17438",
        d: "M164.789,189.173a.478.478,0,0,1-.095-.01.463.463,0,0,1-.359-.548,18.285,18.285,0,0,1,1.23-3.8.464.464,0,0,1,.845.381,17.358,17.358,0,0,0-1.168,3.611A.463.463,0,0,1,164.789,189.173Z",
        transform: "translate(-56.046 -50.535)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17439",
        "data-name": "Path 17439",
        d: "M239.96,170.8a.463.463,0,0,1-.328-.136l-.382-.382a.463.463,0,0,1,.655-.655l.382.382a.464.464,0,0,1-.328.791Z",
        transform: "translate(-121.487 -37.372)",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Minus.tsx":
/*!************************************!*\
  !*** ./src/assets/icons/Minus.tsx ***!
  \************************************/
/*! exports provided: Minus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Minus", function() { return Minus; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Minus.tsx";

const Minus = ({
  color = 'currentColor',
  width = '12px',
  height = '2px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 2",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
      "data-name": "Rectangle 522",
      width: "12",
      height: "2",
      rx: "1",
      fill: color
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/OralCare.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/OralCare.tsx ***!
  \***************************************/
/*! exports provided: OralCare */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OralCare", function() { return OralCare; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\OralCare.tsx";

const OralCare = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 65",
        d: "M3.118 11.024a2.267 2.267 0 01.142 1.454l-.027.333c-.127 1.655.111 3.807 1.157 4.887a.463.463 0 00.1.046.252.252 0 00.317-.127.255.255 0 00.017-.15v-.02c-.017-.157-.385-3.87 1.27-5.887a1.035 1.035 0 011.6.009c1.623 2.025 1.257 5.719 1.241 5.875v.02a.255.255 0 00.017.15.252.252 0 00.317.127.388.388 0 00.111-.049c1.043-1.078 1.281-3.231 1.154-4.887a35.384 35.384 0 00-.027-.333 2.268 2.268 0 01.142-1.455 3.792 3.792 0 011.517-1.087 2.221 2.221 0 001-1.522 3.819 3.819 0 00-.16-2.192c-.555-1.388-1.827-1.924-3.5-1.466a4.521 4.521 0 00-1.368.622c-.2.126-.409.253-.666.384a2.761 2.761 0 001.566.237.248.248 0 11.1.486 3.837 3.837 0 01-2.355-.493 10.454 10.454 0 01-.478-.265 7.466 7.466 0 00-2.338-1.014A2.73 2.73 0 00.698 6.581a2.908 2.908 0 00.92 3.343 3.784 3.784 0 011.5 1.1z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 66",
        d: "M17.256.93H6.409L6.036.558A1.888 1.888 0 004.693.003H.664a.666.666 0 00-.666.666v1.889a.25.25 0 00.5 0V.667A.165.165 0 01.663.502h.1v2.087a.25.25 0 10.5 0V.497h.222v2.087a.25.25 0 10.5 0V.497h.222v2.087a.25.25 0 10.5 0V.497h.222v2.087a.25.25 0 10.5 0V.497h.222v2.087a.25.25 0 10.5 0V.497h.222v2.087a.25.25 0 10.5 0V.507a1.4 1.4 0 01.823.4l.792.789a1.888 1.888 0 001.343.555h9.441a.666.666 0 100-1.323z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/OuterWear.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/OuterWear.tsx ***!
  \****************************************/
/*! exports provided: OuterWear */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OuterWear", function() { return OuterWear; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\OuterWear.tsx";

const OuterWear = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 29",
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 99",
        d: "M15.643 5.659a1.993 1.993 0 00.453-.062c-.224-1.2-.4-1.9-.4-1.9a5.546 5.546 0 00-1.713-1.068 1.964 1.964 0 001.66 3.03z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 100",
        d: "M.896 5.596a1.962 1.962 0 002.113-2.97 5.561 5.561 0 00-1.712 1.068s-.178.697-.401 1.902z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 101",
        d: "M15.641 6.146a2.466 2.466 0 01-2.463-2.463 2.436 2.436 0 01.348-1.24 14.661 14.661 0 00-2.08-.61L11.422.664A5.484 5.484 0 008.947.008c-.225-.01-.677-.01-.904 0a5.5 5.5 0 00-2.478.653l-.02 1.169a14.746 14.746 0 00-2.08.612 2.446 2.446 0 01-2.658 3.64 53.686 53.686 0 00-.771 11.244H.26v.123a.512.512 0 00.532.493h1.24a.512.512 0 00.532-.493v-.123h.23s-.238-7.281 1.02-9.143v9.08a23.275 23.275 0 004.326.735V1.151a5.227 5.227 0 01-1.749-.19S6.529.498 8.043.516h.9c1.5.023 1.653.445 1.653.445a5.226 5.226 0 01-1.751.19v16.847a23.274 23.274 0 004.329-.736V8.184c1.259 1.866 1.023 9.143 1.023 9.143h.229v.123a.511.511 0 00.532.493H16.2a.512.512 0 00.532-.493v-.123h.224a53.827 53.827 0 00-.771-11.246 2.462 2.462 0 01-.544.065z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Pants.tsx":
/*!************************************!*\
  !*** ./src/assets/icons/Pants.tsx ***!
  \************************************/
/*! exports provided: Pants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Pants", function() { return Pants; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Pants.tsx";

const Pants = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 102",
        d: "M7.999 1.165a10.721 10.721 0 00-.139-.71L7.797.187A.243.243 0 007.561 0H.553a.243.243 0 00-.236.187L.253.455c-.056.235-.1.472-.139.71z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 103",
        d: "M.018 2.048a9.93 9.93 0 00-.015.828l.379 13.479a.243.243 0 00.242.236H.86v1.155a.254.254 0 00.254.254h1.288a.254.254 0 00.254-.254v-1.155h.172a.243.243 0 00.242-.225l.833-11.228a.15.15 0 01.3 0l.825 11.228a.243.243 0 00.242.225h.233v1.155a.254.254 0 00.254.254h1.288a.254.254 0 00.254-.254v-1.155h.179a.243.243 0 00.242-.236L8.1 2.876c.008-.276 0-.553-.015-.828z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/PetCare.tsx":
/*!**************************************!*\
  !*** ./src/assets/icons/PetCare.tsx ***!
  \**************************************/
/*! exports provided: PetCare */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PetCare", function() { return PetCare; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\PetCare.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const PetCare = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512",
    width: "60",
    height: "60"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Outline",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        d: "M83.242,192.5,76.758,177.87c-18.5,8.2-28.133,17.987-28.7,29.087L16.142,374.5a8,8,0,0,0,3.812,8.4C47.161,398.85,82.72,411.28,125.642,419.845,165.487,427.8,210.564,432,256,432s90.513-4.2,130.358-12.155c42.922-8.565,78.481-21,105.688-36.943a8,8,0,0,0,3.812-8.4l-10.667-56L469.475,321.5l3.263,17.136-10.656,5.557a270.53,270.53,0,0,1-48.076,19.552C369.917,376.806,313.8,384,256,384c-59.3,0-116.534-7.531-161.151-21.206l-4.69,15.3C136.255,392.219,195.151,400,256,400c59.3,0,117.028-7.428,162.551-20.917a286.6,286.6,0,0,0,50.929-20.706l6.385-3.329,3.2,16.819c-107.232,58.747-338.9,58.747-446.137,0L60.214,228.632q11.793,9.07,34.867,16.276C134.037,257.041,192.689,264,256,264s121.963-6.959,160.92-19.092q23.056-7.182,34.867-16.276L466.428,305.5l15.717-2.994-18.187-95.477c-.88-18.8-27.229-33.514-78.388-43.754l-3.14,15.688C434.3,189.342,448,202.5,448,208c0,4.68-8.951,12.184-28.716,19.253a48.237,48.237,0,0,0-35.856-26.672,48.122,48.122,0,0,0-40-40.008,48.147,48.147,0,0,0-13.489-26.511,47.646,47.646,0,0,0-26.5-13.493,48.015,48.015,0,0,0-94.864,0,47.647,47.647,0,0,0-26.506,13.494,48.167,48.167,0,0,0-12.7,22.608c-29.7,3.39-55.8,8.518-75.8,14.905l4.87,15.241a316.9,316.9,0,0,1,40.8-9.67,47.54,47.54,0,0,0-10.67,23.422,47.647,47.647,0,0,0-26.506,13.494,48.175,48.175,0,0,0-9.33,13.2C72.955,220.188,64,212.681,64,208,64,204.629,69.055,198.787,83.242,192.5Zm30.134,32.88A31.791,31.791,0,0,1,136,216a8,8,0,0,0,8-8,32.013,32.013,0,0,1,32-32,8,8,0,0,0,8-8c0-1.055.055-2.15.16-3.228A32.023,32.023,0,0,1,216,136a8,8,0,0,0,8-8,32,32,0,0,1,64,0,8,8,0,0,0,8,8,32.024,32.024,0,0,1,31.838,28.747c.107,1.1.162,2.2.162,3.253a8,8,0,0,0,8,8,32.036,32.036,0,0,1,32,32,8,8,0,0,0,8,8,32.12,32.12,0,0,1,27.754,16.073C366.446,242.232,313.315,248,256,248s-110.44-5.768-147.748-15.925A32.2,32.2,0,0,1,113.376,225.377ZM248,176v16a24.027,24.027,0,0,0-24,24H208A40.045,40.045,0,0,1,248,176Zm24-24H256V136h16Zm32,64H288V200h16ZM168,200h16v16H168ZM74.3,294.646l15.726,2.948L79.437,354.081,63.71,351.134Zm18.294-11.175-15.742-2.862,3.28-18.04,15.742,2.862Z",
        fill: "currentColor"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Purse.tsx":
/*!************************************!*\
  !*** ./src/assets/icons/Purse.tsx ***!
  \************************************/
/*! exports provided: Purse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Purse", function() { return Purse; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Purse.tsx";

const Purse = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 2",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 1",
        fill: color,
        stroke: "#fff",
        strokeMiterlimit: "10",
        strokeWidth: ".091",
        transform: "translate(-85.169 -7.348)",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 1",
          d: "M98.946 11.381l.217-.061a5.124 5.124 0 00-.6-1.341 11.3 11.3 0 00-1.04-1.279 4.724 4.724 0 00-.93-.679l-.269-.143a3.735 3.735 0 00-.88-.323 5.437 5.437 0 00-1.274-.167l-.317.014a5.3 5.3 0 00-.957.152c-.1.024-.2.061-.3.092a5.009 5.009 0 00-.846.374 4.734 4.734 0 00-.93.679 5.709 5.709 0 00-1.639 2.615l.217.061.217.061a4.7 4.7 0 01.972-1.8 5.106 5.106 0 01.6-.508 4.982 4.982 0 01.874-.521 5.2 5.2 0 011.018-.35 5.315 5.315 0 011.1-.123 5.5 5.5 0 011.1.123 5.2 5.2 0 011.018.35 4.99 4.99 0 01.874.521 5.066 5.066 0 01.585.5 4.7 4.7 0 01.982 1.806z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 2",
          d: "M93.787 22.392a22.149 22.149 0 01-8.561-1.727l3.3-9.285h11.282l3.3 9.285a22.149 22.149 0 01-8.561 1.727z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 3",
          d: "M88.531 11.381l-1.353 3.8a17.645 17.645 0 006.609 1.351h.765a17.643 17.643 0 006.609-1.351l-1.353-3.8z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 4",
          d: "M88.531 11.23l-1.225 3.442a14.059 14.059 0 006.481 1.71h.765a14.059 14.059 0 006.481-1.71l-1.224-3.442z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
          "data-name": "Rectangle 26",
          width: "2.01",
          height: "2.01",
          rx: ".672",
          transform: "rotate(-44.999 66.026 -103.976)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 5",
          d: "M101.162 15.182h0l-.173-.486a14.034 14.034 0 01-6.436 1.687h-.273v.15h.272a17.649 17.649 0 006.61-1.351z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
          "data-name": "Rectangle 27",
          width: "2.01",
          height: "2.01",
          rx: ".672",
          transform: "rotate(-44.999 66.026 -103.976)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
          "data-name": "Rectangle 28",
          width: "1.5",
          height: "1.5",
          rx: ".501",
          transform: "rotate(-44.999 66.206 -104.411)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/ShavingNeeds.tsx":
/*!*******************************************!*\
  !*** ./src/assets/icons/ShavingNeeds.tsx ***!
  \*******************************************/
/*! exports provided: ShavingNeeds */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShavingNeeds", function() { return ShavingNeeds; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\ShavingNeeds.tsx";

const ShavingNeeds = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 17",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 16",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 60",
          d: "M17.24.609h-5.239a.741.741 0 00-.731.731v.667a.741.741 0 00.731.731h.183a1.222 1.222 0 011.222 1.222v1.222l-.152 3.351h2.777l-.183-3.351V3.959a1.222 1.222 0 011.222-1.222h.183a.741.741 0 00.731-.731v-.667a.741.741 0 00-.744-.731zm-2.011 4.265h-1.222v-.609h1.222zm.03-1.222h-1.28a1.741 1.741 0 00-.457-.914h2.163a1.952 1.952 0 00-.425.92z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 19",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 18",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 61",
          d: "M16.023 9.138h-2.8l-.061 1.222h2.924z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 21",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 20",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 62",
          d: "M16.413 16.144l-.243-5.178h-3.046l-.243 5.178a1.768 1.768 0 103.533 0z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 23",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 22",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 63",
          d: "M8.499 1.827V0H2.436v2.742h-.918V4.11A2.283 2.283 0 000 6.274V7.31h6.092v7.31H0v1.066a2.3 2.3 0 002.284 2.285h3.934a2.282 2.282 0 002.284-2.284V6.244a2.312 2.312 0 00-1.526-2.163V2.742h-.915v-.915zM6.092 3.351h.3v.609h-4.26v-.609z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 25",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 24",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 64",
          d: "M0 7.92v1.222h2.132a.304.304 0 110 .609H0v.914h3.655a.304.304 0 110 .609H0v.914h3.655a.304.304 0 110 .609H0v1.222h5.482V7.927z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Shirts.tsx":
/*!*************************************!*\
  !*** ./src/assets/icons/Shirts.tsx ***!
  \*************************************/
/*! exports provided: Shirts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Shirts", function() { return Shirts; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Shirts.tsx";

const Shirts = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 109",
        d: "M6.751 2.546a.172.172 0 00.04 0l2.206-.525 2.2.543a.171.171 0 00.041 0 .142.142 0 00.111-.051.149.149 0 00.027-.128l-.21-.983a.362.362 0 010-.115l.221-1.1a.144.144 0 00-.026-.122.138.138 0 00-.168-.029l-2.192 1.05L6.813.017a.137.137 0 00-.169.028.144.144 0 00-.027.122l.21 1.1a.362.362 0 010 .115l-.217.979a.149.149 0 00.027.128.142.142 0 00.11.053z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 110",
        d: "M2.563 15.126l-1.806-.153a.4.4 0 00-.4.278l-.342 1.214a.285.285 0 00.039.248.285.285 0 00.224.112l1.8.058h.013a.428.428 0 00.391-.288l.334-1.1a.282.282 0 00-.252-.372z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 111",
        d: "M17.985 16.466l-.338-1.2a.4.4 0 00-.4-.278l-1.806.152a.282.282 0 00-.252.372l.33 1.083a.428.428 0 00.391.288l1.815-.058a.274.274 0 00.264-.359z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 112",
        d: "M17.024 14.342a.286.286 0 00.257-.372l-.756-2.678a5.452 5.452 0 01-.105-.451l-1.321-6.627a.61.61 0 00-.315-.4l-2.139-.945a.63.63 0 00-.248-.046.638.638 0 00-.263.051L9.176 4.248a.483.483 0 01-.346 0L5.865 2.876a.64.64 0 00-.263-.051.63.63 0 00-.248.046l-2.139.945a.61.61 0 00-.315.4l-1.318 6.626c-.025.125-.074.328-.105.451l-.759 2.662a.286.286 0 00.257.372l1.824.154a.405.405 0 00.407-.275l.874-2.857a3.587 3.587 0 00.105-.476l.278-2.1-.254 8.162a.326.326 0 00.327.337h8.99a.325.325 0 00.326-.338l-.292-8.058.265 2.006a3.582 3.582 0 00.105.476l.875 2.874a.405.405 0 00.407.275zM8.998 16.3a.558.558 0 11.558-.558.558.558 0 01-.558.558zm0-2.422a.558.558 0 11.558-.558.558.558 0 01-.558.558zm0-2.422a.558.558 0 11.558-.558.558.558 0 01-.558.558zm0-2.422a.558.558 0 11.558-.558.558.558 0 01-.558.558zm0-2.422a.558.558 0 11.558-.558.558.558 0 01-.558.562z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/ShoulderBags.tsx":
/*!*******************************************!*\
  !*** ./src/assets/icons/ShoulderBags.tsx ***!
  \*******************************************/
/*! exports provided: ShoulderBags */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShoulderBags", function() { return ShoulderBags; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\ShoulderBags.tsx";

const ShoulderBags = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 3",
      transform: "translate(-100.548 -66.187)",
      fill: color,
      stroke: "#fff",
      strokeMiterlimit: "10",
      strokeWidth: ".076",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 6",
        d: "M105.083 69.531l-.917.243-.848-3.195a.149.149 0 01.068-.166h0a1.343 1.343 0 01.708-.188h0a.149.149 0 01.141.111z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 7",
        d: "M104.167 69.774l-.917.243-.848-3.195a.149.149 0 01.068-.166h0a1.342 1.342 0 01.708-.188h0a.149.149 0 01.141.111z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 8",
        d: "M106.5 69.531l.917.243.848-3.195a.149.149 0 00-.068-.166h0a1.343 1.343 0 00-.708-.188h0a.149.149 0 00-.141.111z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 9",
        d: "M107.421 69.774l.917.243.848-3.195a.149.149 0 00-.068-.166h0a1.342 1.342 0 00-.708-.188h0a.149.149 0 00-.141.111z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 10",
        d: "M110.987 80.15l-.645-7.545a3.781 3.781 0 00-3.768-3.459h-.78v1.23h0v-1.23h-.78a3.781 3.781 0 00-3.768 3.459l-.646 7.545a3.407 3.407 0 003.395 3.7h3.598a3.407 3.407 0 003.395-3.7z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 11",
        d: "M108.494 69.668c-1.336-.669-1.426-1.652-2.7-1.654h0c-1.272 0-1.362.985-2.7 1.654l.294-.046c1.191-.519 1.271-1.282 2.406-1.283s1.215.764 2.406 1.283z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 12",
        d: "M105.795 77.868l.132-.006 4.385-.192.239 2.792h0a16.8 16.8 0 01-4.579.636h-.177"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 13",
        d: "M105.788 77.868l-.132-.006-4.385-.192-.239 2.792h0a16.8 16.8 0 004.579.636h.177"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 14",
        d: "M110.625 80.455l-.591-6.916a3.54 3.54 0 00-3.527-3.239h-1.427a3.54 3.54 0 00-3.527 3.238l-.591 6.916a3.2 3.2 0 001.393 2.92l.083-.123a3.056 3.056 0 01-1.328-2.785l.591-6.916a3.372 3.372 0 013.38-3.1h1.426a3.372 3.372 0 013.379 3.1l.591 6.916a3.056 3.056 0 01-1.328 2.785l.083.123a3.2 3.2 0 001.392-2.921z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 15",
        d: "M105.792 84.149v-3.008h0a25.049 25.049 0 01-4.756-.676l-.447-.039A3.568 3.568 0 00104 84.149z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 16",
        d: "M105.795 81.141v3.008h1.8A3.568 3.568 0 00111 80.426l-.447.039a25.083 25.083 0 01-4.758.676z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 17",
        d: "M105.792 81.083v2.767h1.647a3.123 3.123 0 003.112-3.389 27.2 27.2 0 01-4.757.622z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 18",
        d: "M105.795 83.85v-2.765h0a27.157 27.157 0 01-4.759-.622h0a3.123 3.123 0 003.112 3.389z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 34",
        width: "2.177",
        height: "1.086",
        rx: ".281",
        transform: "rotate(-3.21 1460.138 -1873.834)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 19",
        d: "M103.251 80.12h0a.158.158 0 01-.158-.158v-6.679a.158.158 0 01.158-.158h0a.158.158 0 01.158.158v6.679a.158.158 0 01-.158.158z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Rectangle 35",
        d: "M103.093 74.874h.316v1.036h-.316z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Skirts.tsx":
/*!*************************************!*\
  !*** ./src/assets/icons/Skirts.tsx ***!
  \*************************************/
/*! exports provided: Skirts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Skirts", function() { return Skirts; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Skirts.tsx";

const Skirts = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 107",
        d: "M17.688 16.585L14.826 5.454a3.95 3.95 0 00-.26-.682l-.822-1.6a.749.749 0 00-.616-.376H4.576a.746.746 0 00-.615.377l-.841 1.65a4.017 4.017 0 00-.258.683L.017 16.585a.373.373 0 00.374.482h.64a1.52 1.52 0 01.612.158l1.246.691a.824.824 0 00.728 0l1.24-.691a.607.607 0 01.514 0l1.246.691a.824.824 0 00.728 0l1.246-.691a.607.607 0 01.514 0l1.246.691a.824.824 0 00.728 0l1.246-.691a.607.607 0 01.514 0l1.246.691a.824.824 0 00.728 0l1.246-.691a1.52 1.52 0 01.612-.158h.64a.373.373 0 00.374-.482z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 108",
        d: "M4.525 2.1h8.656a.333.333 0 00.333-.333V.333A.333.333 0 0013.181 0H4.525a.333.333 0 00-.331.333v1.438a.333.333 0 00.331.331zM7.833.652a.267.267 0 01.262-.266h1.508a.267.267 0 01.266.266v.8a.267.267 0 01-.266.266H8.095a.267.267 0 01-.266-.266z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Rectangle 2",
        d: "M8.275.83h1.153v.444H8.275z"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Snacks.tsx":
/*!*************************************!*\
  !*** ./src/assets/icons/Snacks.tsx ***!
  \*************************************/
/*! exports provided: Snacks */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Snacks", function() { return Snacks; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Snacks.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Snacks = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "25.143",
    height: "22",
    viewBox: "0 0 25.143 22"
  }, props), {}, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Snacks",
      transform: "translate(0 -32.001)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5714",
        "data-name": "Group 5714",
        transform: "translate(3.142 40.381)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5713",
          "data-name": "Group 5713",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17398",
            "data-name": "Path 17398",
            d: "M80.227,202.654H65.559a1.573,1.573,0,0,0-1.571,1.571v1.048a9.928,9.928,0,0,0,5.388,8.847.524.524,0,1,0,.481-.931,8.883,8.883,0,0,1-4.821-7.916v-1.048a.524.524,0,0,1,.524-.524H80.227a.524.524,0,0,1,.524.524v1.048a8.879,8.879,0,0,1-4.822,7.915.524.524,0,0,0,.241.99.517.517,0,0,0,.24-.059,9.923,9.923,0,0,0,5.389-8.846v-1.048A1.573,1.573,0,0,0,80.227,202.654Z",
            transform: "translate(-63.988 -202.654)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5716",
        "data-name": "Group 5716",
        transform: "translate(0 50.857)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5715",
          "data-name": "Group 5715",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17399",
            "data-name": "Path 17399",
            d: "M24.056,416.29a.525.525,0,0,0-.484-.324H.524a.524.524,0,0,0-.371.895l1.174,1.175a3.645,3.645,0,0,0,2.593,1.074H20.174a3.651,3.651,0,0,0,2.6-1.074l1.174-1.175A.523.523,0,0,0,24.056,416.29ZM22.027,417.3a2.6,2.6,0,0,1-1.852.767H3.921a2.6,2.6,0,0,1-1.852-.767l-.281-.281h20.52Z",
            transform: "translate(0 -415.966)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5718",
        "data-name": "Group 5718",
        transform: "translate(17.438 42.474)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5717",
          "data-name": "Group 5717",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17400",
            "data-name": "Path 17400",
            d: "M361.785,245.653c-1.411-.907-3.666.078-3.918.192a.524.524,0,0,0,.435.954c.505-.229,2.125-.773,2.917-.263a1.488,1.488,0,0,1,.532,1.358c0,2.1-4.23,3.365-5.864,3.677l-.371.073a.523.523,0,0,0,.1,1.037.486.486,0,0,0,.1-.01l.368-.072c.274-.052,6.712-1.315,6.712-4.705A2.471,2.471,0,0,0,361.785,245.653Z",
            transform: "translate(-355.093 -245.272)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5720",
        "data-name": "Group 5720",
        transform: "translate(14.667 32.001)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5719",
          "data-name": "Group 5719",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17401",
            "data-name": "Path 17401",
            d: "M300.125,35.994a3.139,3.139,0,0,0,0-3.8.524.524,0,1,0-.818.655,2.113,2.113,0,0,1,0,2.488,3.135,3.135,0,0,0,0,3.8.524.524,0,1,0,.818-.655A2.11,2.11,0,0,1,300.125,35.994Z",
            transform: "translate(-298.666 -32.001)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 63,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5722",
        "data-name": "Group 5722",
        transform: "translate(11.52 32.001)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5721",
          "data-name": "Group 5721",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17402",
            "data-name": "Path 17402",
            d: "M236.055,36a3.135,3.135,0,0,0,0-3.8.524.524,0,1,0-.818.655,2.11,2.11,0,0,1,0,2.488,3.139,3.139,0,0,0,0,3.8.524.524,0,1,0,.818-.655A2.113,2.113,0,0,1,236.055,36Z",
            transform: "translate(-234.597 -32.009)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        id: "Group_5724",
        "data-name": "Group 5724",
        transform: "translate(8.381 32.002)",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          id: "Group_5723",
          "data-name": "Group 5723",
          transform: "translate(0 0)",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            id: "Path_17403",
            "data-name": "Path 17403",
            d: "M172.125,36.015a3.139,3.139,0,0,0,0-3.8.524.524,0,0,0-.818.654,2.113,2.113,0,0,1,0,2.488,3.135,3.135,0,0,0,0,3.8.524.524,0,1,0,.818-.654A2.11,2.11,0,0,1,172.125,36.015Z",
            transform: "translate(-170.666 -32.022)",
            fill: "currentColor"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Tops.tsx":
/*!***********************************!*\
  !*** ./src/assets/icons/Tops.tsx ***!
  \***********************************/
/*! exports provided: Tops */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tops", function() { return Tops; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Tops.tsx";

const Tops = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      fill: color,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 104",
        d: "M6.994 2.83L5.928 5.991a.315.315 0 01-.6 0L4.273 2.83a2.4 2.4 0 00-2.909-.026L0 3.822l.087.329a32.647 32.647 0 01.909 11.921L.79 18h9.7l-.215-1.909a32.667 32.667 0 01.912-11.96l.083-.31-1.366-1.013a2.4 2.4 0 00-2.909.026zm0 0"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 105",
        d: "M.549 2.843l.62-.114L.714.261a.315.315 0 00-.62.114zm0 0"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 106",
        d: "M10.978.369a.316.316 0 00-.622-.108L9.966 2.6l.622.108zm0 0"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/Wallet.tsx":
/*!*************************************!*\
  !*** ./src/assets/icons/Wallet.tsx ***!
  \*************************************/
/*! exports provided: Wallet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Wallet", function() { return Wallet; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\Wallet.tsx";

const Wallet = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Group 9",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 8",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 42",
          d: "M12.362 1.129a1.415 1.415 0 00-1.672-1.1L1.428 1.942h11.1z",
          fill: color
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 43",
        d: "M11.579 11.242v-2.2a1.822 1.822 0 011.82-1.82h2.784v-2.78a1.415 1.415 0 00-1.415-1.415H1.415A1.415 1.415 0 000 4.442v11.4a1.415 1.415 0 001.415 1.415h13.354a1.415 1.415 0 001.415-1.415v-2.776h-2.785a1.822 1.822 0 01-1.82-1.82z",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        "data-name": "Path 44",
        d: "M16.989 8.03h-3.59a1.011 1.011 0 00-1.01 1.01v2.2a1.012 1.012 0 001.01 1.01h3.59a1.012 1.012 0 001.01-1.01v-2.2a1.012 1.012 0 00-1.01-1.01zm-2.8 3.128a1.006 1.006 0 111.006-1.006 1.006 1.006 0 01-1.006 1.006z",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/WomenDress.tsx":
/*!*****************************************!*\
  !*** ./src/assets/icons/WomenDress.tsx ***!
  \*****************************************/
/*! exports provided: WomenDress */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WomenDress", function() { return WomenDress; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\WomenDress.tsx";

const WomenDress = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 18",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("defs", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("clipPath", {
        id: "a",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Rectangle 20",
          transform: "translate(226 1073)",
          fill: "#ebe7e7",
          d: "M0 0h18v18H0z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      "data-name": "Women Dress",
      transform: "translate(-226 -1073)",
      clipPath: "url(#a)",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
        "data-name": "Group 28",
        transform: "translate(230.461 1073)",
        fill: color,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 80",
          d: "M8.236 12.619c-.12-.6-.384-3.422-1.008-4.358a1.446 1.446 0 01-.19-.8.039.039 0 000-.007c.02-.29.052-.6.073-.762a.493.493 0 01.01-.076c.016-.1.036-.192.057-.289a16.065 16.065 0 00.515-2.746c0-1.429-.733-1.849-.733-1.849.251-1.069.434-1.647.434-1.647L7.179 0A10.558 10.558 0 006.7 1.717a2.911 2.911 0 01-2.161.694 2.913 2.913 0 01-2.161-.694A10.578 10.578 0 001.897 0l-.216.087s.18.577.434 1.647c0 0-.733.421-.733 1.849a14.672 14.672 0 00.491 2.631.1.1 0 000 .039.2.2 0 00.01.035l.007.028c.03.123.074.347.081.347.014.087.029.243.043.4.006.055.01.109.014.163l.016.207h-.007a1.462 1.462 0 01-.191.826c-.624.936-.889 3.758-1.008 4.358s-.408 2.81-.552 3.459-.288 1.537-.288 1.537a3.7 3.7 0 001.2.144s-.087.252.649.18a14.433 14.433 0 011.969-.06c.5.024.153.12.72.12s.216-.1.72-.12a14.388 14.388 0 011.969.06c.733.072.649-.18.649-.18a3.708 3.708 0 001.2-.144s-.144-.889-.289-1.537-.428-2.857-.549-3.457zM6.955 6.468c-.056.077-.106.2-.041.251-.017.115-.027.231-.039.347-.065-.075-.274-.006-.274-.006-.155-.068.137.335.254.181-.005.065-.007.13-.01.2-.142-.01-.284-.02-.427-.028a.66.66 0 00-.068-.149c.016-.108-.108.016-.15.137a25.847 25.847 0 00-.925-.02C5.211 7.304 5 7.373 5 7.373c-.031-.014-.044-.008-.044.009h-.032a.147.147 0 00.016-.067.152.152 0 00-.3 0 .149.149 0 00.017.067c-.406 0-.812.013-1.214.023a.791.791 0 00-.042-.077c.014-.092-.074-.017-.126.081l-.207.005a.491.491 0 00.112-.2c.154-.1-.434-.074-.271.151a.2.2 0 00.051.051h-.173a.087.087 0 000-.122c-.136-.2-.238.094-.25.127l-.3.006a.43.43 0 00-.005-.081c.073-.011.315-.308.087-.354a.173.173 0 00-.109.005 4.818 4.818 0 00-.048-.385.674.674 0 00.059-.135c.067-.042-.005-.062-.1-.051a2.26 2.26 0 00-.039-.147h.224a.152.152 0 10.292.057.148.148 0 00-.014-.062l1.04-.019a.1.1 0 000 .132c.143.2.244-.072.266-.137l.479-.005c.075.095.22.2.277.043a.207.207 0 00.009-.046h.7a.15.15 0 00-.034.092.152.152 0 10.3 0 .149.149 0 00-.033-.087c.384.007.766.024 1.148.048-.116.015-.254.077-.166.2.161.225.271-.151.271-.151.029-.018.032-.032.018-.042l.1.007a.042.042 0 00.009.008c-.007.052-.016.1-.026.153z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 81",
          d: "M4.951 7.161c-.144.087.4.076.252-.134s-.252.134-.252.134z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 82",
          d: "M4.286 7.052c-.1.235.249.14.249.14.15.075-.149-.375-.249-.14z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 83",
          d: "M4.768 6.721c-.284-.057-.1.31-.1.31-.049.19.384-.249.1-.31z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 84",
          d: "M5.973 6.533c.095-.26-.277-.138-.277-.138-.167-.073.183.398.277.138z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 85",
          d: "M5.382 6.898c.276.023.061-.3.061-.3.027-.184-.34.279-.061.3z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 86",
          d: "M4.985 6.632c.161.225.271-.151.271-.151.154-.097-.433-.076-.271.151z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
          "data-name": "Ellipse 3",
          cx: ".152",
          cy: ".152",
          r: ".152",
          transform: "translate(3.253 6.916)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 87",
          d: "M3.851 6.782c-.144-.21-.252.134-.252.134-.144.086.396.076.252-.134z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 88",
          d: "M3.649 7.126c-.167-.073.183.4.277.138s-.277-.138-.277-.138z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 89",
          d: "M2.903 6.808c-.1.235.249.14.249.14.151.075-.149-.374-.249-.14z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 90",
          d: "M3.384 6.48c-.284-.057-.1.31-.1.31-.046.185.385-.256.1-.31z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 91",
          d: "M6.359 6.852a.152.152 0 11-.152.152.152.152 0 01.152-.152z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 92",
          d: "M6.553 6.853c-.144.087.4.076.252-.134s-.252.134-.252.134z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 93",
          d: "M5.861 7.3c.161.225.271-.151.271-.151.152-.1-.435-.074-.271.151z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 94",
          d: "M5.856 6.744c-.1.235.249.14.249.14.15.075-.15-.375-.249-.14z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 95",
          d: "M6.338 6.413c-.284-.057-.1.31-.1.31-.049.187.385-.25.1-.31z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 101,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 96",
          d: "M4.064 6.654c.276.023.061-.3.061-.3.027-.184-.339.276-.061.3z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 97",
          d: "M2.972 6.533c.094-.26-.277-.138-.277-.138-.168-.073.182.398.277.138z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          "data-name": "Path 98",
          d: "M2.381 6.898c.276.023.061-.3.061-.3.026-.184-.336.279-.061.3z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category-icons.ts":
/*!********************************************!*\
  !*** ./src/assets/icons/category-icons.ts ***!
  \********************************************/
/*! exports provided: Accessories, FruitsVegetable, MeatFish, Purse, HandBags, ShoulderBags, Wallet, LaptopBags, WomenDress, OuterWear, Pants, Tops, Skirts, Shirts, Face, Eyes, Lips, Snacks, PetCare, HomeCleaning, Dairy, Cooking, Breakfast, Beverage, BeautyHealth, ShavingNeeds, OralCare, FacialCare, Deodorant, BathOil, Minus, Chair, Bed, Bookshelf, CenterTable, DressingTable, ReadingTable, Sofa, RelaxChair, Storage, Tools, Table */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Accessories__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Accessories */ "./src/assets/icons/Accessories.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Accessories", function() { return _Accessories__WEBPACK_IMPORTED_MODULE_0__["Accessories"]; });

/* harmony import */ var _FruitsVegetable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FruitsVegetable */ "./src/assets/icons/FruitsVegetable.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FruitsVegetable", function() { return _FruitsVegetable__WEBPACK_IMPORTED_MODULE_1__["FruitsVegetable"]; });

/* harmony import */ var _MeatFish__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MeatFish */ "./src/assets/icons/MeatFish.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MeatFish", function() { return _MeatFish__WEBPACK_IMPORTED_MODULE_2__["MeatFish"]; });

/* harmony import */ var _Purse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Purse */ "./src/assets/icons/Purse.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Purse", function() { return _Purse__WEBPACK_IMPORTED_MODULE_3__["Purse"]; });

/* harmony import */ var _HandBags__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HandBags */ "./src/assets/icons/HandBags.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HandBags", function() { return _HandBags__WEBPACK_IMPORTED_MODULE_4__["HandBags"]; });

/* harmony import */ var _ShoulderBags__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ShoulderBags */ "./src/assets/icons/ShoulderBags.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ShoulderBags", function() { return _ShoulderBags__WEBPACK_IMPORTED_MODULE_5__["ShoulderBags"]; });

/* harmony import */ var _Wallet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Wallet */ "./src/assets/icons/Wallet.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Wallet", function() { return _Wallet__WEBPACK_IMPORTED_MODULE_6__["Wallet"]; });

/* harmony import */ var _LaptopBags__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./LaptopBags */ "./src/assets/icons/LaptopBags.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LaptopBags", function() { return _LaptopBags__WEBPACK_IMPORTED_MODULE_7__["LaptopBags"]; });

/* harmony import */ var _WomenDress__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./WomenDress */ "./src/assets/icons/WomenDress.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "WomenDress", function() { return _WomenDress__WEBPACK_IMPORTED_MODULE_8__["WomenDress"]; });

/* harmony import */ var _OuterWear__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./OuterWear */ "./src/assets/icons/OuterWear.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OuterWear", function() { return _OuterWear__WEBPACK_IMPORTED_MODULE_9__["OuterWear"]; });

/* harmony import */ var _Pants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Pants */ "./src/assets/icons/Pants.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Pants", function() { return _Pants__WEBPACK_IMPORTED_MODULE_10__["Pants"]; });

/* harmony import */ var _Tops__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Tops */ "./src/assets/icons/Tops.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tops", function() { return _Tops__WEBPACK_IMPORTED_MODULE_11__["Tops"]; });

/* harmony import */ var _Skirts__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Skirts */ "./src/assets/icons/Skirts.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Skirts", function() { return _Skirts__WEBPACK_IMPORTED_MODULE_12__["Skirts"]; });

/* harmony import */ var _Shirts__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Shirts */ "./src/assets/icons/Shirts.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Shirts", function() { return _Shirts__WEBPACK_IMPORTED_MODULE_13__["Shirts"]; });

/* harmony import */ var _Face__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Face */ "./src/assets/icons/Face.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Face", function() { return _Face__WEBPACK_IMPORTED_MODULE_14__["Face"]; });

/* harmony import */ var _Eyes__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Eyes */ "./src/assets/icons/Eyes.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Eyes", function() { return _Eyes__WEBPACK_IMPORTED_MODULE_15__["Eyes"]; });

/* harmony import */ var _Lips__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Lips */ "./src/assets/icons/Lips.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Lips", function() { return _Lips__WEBPACK_IMPORTED_MODULE_16__["Lips"]; });

/* harmony import */ var _Snacks__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./Snacks */ "./src/assets/icons/Snacks.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Snacks", function() { return _Snacks__WEBPACK_IMPORTED_MODULE_17__["Snacks"]; });

/* harmony import */ var _PetCare__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./PetCare */ "./src/assets/icons/PetCare.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PetCare", function() { return _PetCare__WEBPACK_IMPORTED_MODULE_18__["PetCare"]; });

/* harmony import */ var _HomeCleaning__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./HomeCleaning */ "./src/assets/icons/HomeCleaning.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HomeCleaning", function() { return _HomeCleaning__WEBPACK_IMPORTED_MODULE_19__["HomeCleaning"]; });

/* harmony import */ var _Dairy__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./Dairy */ "./src/assets/icons/Dairy.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Dairy", function() { return _Dairy__WEBPACK_IMPORTED_MODULE_20__["Dairy"]; });

/* harmony import */ var _Cooking__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./Cooking */ "./src/assets/icons/Cooking.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Cooking", function() { return _Cooking__WEBPACK_IMPORTED_MODULE_21__["Cooking"]; });

/* harmony import */ var _Breakfast__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./Breakfast */ "./src/assets/icons/Breakfast.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Breakfast", function() { return _Breakfast__WEBPACK_IMPORTED_MODULE_22__["Breakfast"]; });

/* harmony import */ var _Beverage__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./Beverage */ "./src/assets/icons/Beverage.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Beverage", function() { return _Beverage__WEBPACK_IMPORTED_MODULE_23__["Beverage"]; });

/* harmony import */ var _BeautyHealth__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./BeautyHealth */ "./src/assets/icons/BeautyHealth.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BeautyHealth", function() { return _BeautyHealth__WEBPACK_IMPORTED_MODULE_24__["BeautyHealth"]; });

/* harmony import */ var _ShavingNeeds__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./ShavingNeeds */ "./src/assets/icons/ShavingNeeds.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ShavingNeeds", function() { return _ShavingNeeds__WEBPACK_IMPORTED_MODULE_25__["ShavingNeeds"]; });

/* harmony import */ var _OralCare__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./OralCare */ "./src/assets/icons/OralCare.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OralCare", function() { return _OralCare__WEBPACK_IMPORTED_MODULE_26__["OralCare"]; });

/* harmony import */ var _FacialCare__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./FacialCare */ "./src/assets/icons/FacialCare.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FacialCare", function() { return _FacialCare__WEBPACK_IMPORTED_MODULE_27__["FacialCare"]; });

/* harmony import */ var _Deodorant__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./Deodorant */ "./src/assets/icons/Deodorant.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Deodorant", function() { return _Deodorant__WEBPACK_IMPORTED_MODULE_28__["Deodorant"]; });

/* harmony import */ var _BathOil__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./BathOil */ "./src/assets/icons/BathOil.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BathOil", function() { return _BathOil__WEBPACK_IMPORTED_MODULE_29__["BathOil"]; });

/* harmony import */ var _Minus__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./Minus */ "./src/assets/icons/Minus.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Minus", function() { return _Minus__WEBPACK_IMPORTED_MODULE_30__["Minus"]; });

/* harmony import */ var assets_icons_category_chair__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! assets/icons/category/chair */ "./src/assets/icons/category/chair.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Chair", function() { return assets_icons_category_chair__WEBPACK_IMPORTED_MODULE_31__["Chair"]; });

/* harmony import */ var assets_icons_category_bed__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! assets/icons/category/bed */ "./src/assets/icons/category/bed.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Bed", function() { return assets_icons_category_bed__WEBPACK_IMPORTED_MODULE_32__["Bed"]; });

/* harmony import */ var assets_icons_category_book_shelf__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! assets/icons/category/book-shelf */ "./src/assets/icons/category/book-shelf.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Bookshelf", function() { return assets_icons_category_book_shelf__WEBPACK_IMPORTED_MODULE_33__["Bookshelf"]; });

/* harmony import */ var assets_icons_category_center_table__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! assets/icons/category/center-table */ "./src/assets/icons/category/center-table.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CenterTable", function() { return assets_icons_category_center_table__WEBPACK_IMPORTED_MODULE_34__["CenterTable"]; });

/* harmony import */ var assets_icons_category_dressing_table__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! assets/icons/category/dressing-table */ "./src/assets/icons/category/dressing-table.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DressingTable", function() { return assets_icons_category_dressing_table__WEBPACK_IMPORTED_MODULE_35__["DressingTable"]; });

/* harmony import */ var assets_icons_category_reading_table__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! assets/icons/category/reading-table */ "./src/assets/icons/category/reading-table.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ReadingTable", function() { return assets_icons_category_reading_table__WEBPACK_IMPORTED_MODULE_36__["ReadingTable"]; });

/* harmony import */ var assets_icons_category_sofa__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! assets/icons/category/sofa */ "./src/assets/icons/category/sofa.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Sofa", function() { return assets_icons_category_sofa__WEBPACK_IMPORTED_MODULE_37__["Sofa"]; });

/* harmony import */ var assets_icons_category_relax_chair__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! assets/icons/category/relax-chair */ "./src/assets/icons/category/relax-chair.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RelaxChair", function() { return assets_icons_category_relax_chair__WEBPACK_IMPORTED_MODULE_38__["RelaxChair"]; });

/* harmony import */ var assets_icons_category_storage__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! assets/icons/category/storage */ "./src/assets/icons/category/storage.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Storage", function() { return assets_icons_category_storage__WEBPACK_IMPORTED_MODULE_39__["Storage"]; });

/* harmony import */ var assets_icons_category_tools__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! assets/icons/category/tools */ "./src/assets/icons/category/tools.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tools", function() { return assets_icons_category_tools__WEBPACK_IMPORTED_MODULE_40__["Tools"]; });

/* harmony import */ var assets_icons_category_table__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! assets/icons/category/table */ "./src/assets/icons/category/table.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Table", function() { return assets_icons_category_table__WEBPACK_IMPORTED_MODULE_41__["Table"]; });












































/***/ }),

/***/ "./src/assets/icons/category/bed.tsx":
/*!*******************************************!*\
  !*** ./src/assets/icons/category/bed.tsx ***!
  \*******************************************/
/*! exports provided: Bed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Bed", function() { return Bed; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\bed.tsx";
const Bed = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "60",
    height: "60",
    viewBox: "0 0 60 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "Bed",
      d: "M228.5,466.75V455.5A7.5,7.5,0,0,0,221,448H191a7.5,7.5,0,0,0-7.5,7.5v11.25L176,491.125v11.25a1.874,1.874,0,0,0,1.875,1.875h3.75V508H183.5v-3.75h45V508h1.875v-3.75h3.75A1.874,1.874,0,0,0,236,502.375v-11.25ZM185.375,455.5A5.632,5.632,0,0,1,191,449.875h30a5.632,5.632,0,0,1,5.625,5.625v11.1q-.938-.072-1.875-.137V463a3.75,3.75,0,0,0-3.75-3.75h-9.375a3.75,3.75,0,0,0-3.75,3.75v2.824c-.625,0-1.25-.009-1.875-.009s-1.25,0-1.875.009V463a3.75,3.75,0,0,0-3.75-3.75H191a3.75,3.75,0,0,0-3.75,3.75v3.467q-.938.065-1.875.137Zm37.5,10.84q-6.557-.409-13.125-.5V463a1.877,1.877,0,0,1,1.875-1.875H221A1.877,1.877,0,0,1,222.875,463Zm-33.75,0V463A1.877,1.877,0,0,1,191,461.125h9.375A1.877,1.877,0,0,1,202.25,463v2.843Q195.684,465.933,189.125,466.34Zm-4.207,2.176c6.992-.549,14.077-.827,21.082-.827s14.09.277,21.082.827l6.331,20.576c-9.1-.517-18.313-.779-27.413-.779s-18.308.262-27.413.779Zm49.207,33.859h-56.25v-11.36q14.05-.823,28.125-.827t28.125.827Z",
      transform: "translate(-176 -448)",
      fill: "#212121"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/book-shelf.tsx":
/*!**************************************************!*\
  !*** ./src/assets/icons/category/book-shelf.tsx ***!
  \**************************************************/
/*! exports provided: Bookshelf */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Bookshelf", function() { return Bookshelf; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\book-shelf.tsx";
const Bookshelf = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "48.75",
    height: "60",
    viewBox: "0 0 48.75 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "Book_self",
      "data-name": "Book self",
      d: "M228.875,176h-45A1.874,1.874,0,0,0,182,177.875v52.5a1.874,1.874,0,0,0,1.875,1.875h3.75V236H189.5v-3.75h33.75V236h1.875v-3.75h3.75a1.874,1.874,0,0,0,1.875-1.875v-52.5A1.874,1.874,0,0,0,228.875,176Zm-23.437,54.375h-2.812v-11.25H200.75v11.25h-1.875v-11.25H197v11.25h-1.875v-11.25H193.25v11.25h-1.875v-11.25H189.5v11.25h-1.875v-11.25H185.75v11.25h-1.875V213.5h21.563Zm0-18.75h-6.562v-11.25H197v11.25h-1.875v-11.25H193.25v11.25h-1.875v-11.25H189.5v11.25h-1.875v-11.25H185.75v11.25h-1.875V194.75h21.563Zm0-18.75h-6.452l1.764-.6-3.6-10.658-1.777.6,3.6,10.654h-3.848v-11.25H193.25v11.25h-1.875v-11.25H189.5v11.25h-1.875v-11.25H185.75v11.25h-1.875v-15h21.563Zm23.438,37.5h-7.5v-11.25H219.5v11.25H212v-11.25h-1.875v11.25h-2.812V213.5h21.563Zm0-18.75h-5.5l1.752-.592-3.6-10.658-1.777.6,3.6,10.65H219.5V200.379h-1.875v11.246H215.75V200.379h-1.875v11.246H212V200.379h-1.875v11.246h-2.812V194.75h21.563Zm0-18.75H227v-11.25h-1.875v11.25H223.25v-11.25h-1.875v11.25H219.5v-11.25h-1.875v11.25H215.75v-11.25h-1.875v11.25H212v-11.25h-1.875v11.25h-2.812v-15h21.563Z",
      transform: "translate(-182 -176)",
      fill: "#212121"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/center-table.tsx":
/*!****************************************************!*\
  !*** ./src/assets/icons/category/center-table.tsx ***!
  \****************************************************/
/*! exports provided: CenterTable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CenterTable", function() { return CenterTable; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\center-table.tsx";
const CenterTable = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "60",
    height: "48.75",
    viewBox: "0 0 60 48.75",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "Center_table",
      "data-name": "Center table",
      d: "M226.757,591.945A98.842,98.842,0,0,0,206,590a98.842,98.842,0,0,0-20.757,1.945C179.11,593.33,176,595.2,176,597.5s3.11,4.17,9.243,5.555a93.868,93.868,0,0,0,17.945,1.915v4.724a4.674,4.674,0,0,0,0,7.487v8.444h-1.875a4.7,4.7,0,0,0-4.594,3.75h-1.031A4.693,4.693,0,0,0,191,634.063v3.75a.938.938,0,0,0,.938.938h3.75a.938.938,0,0,0,.938-.937V635h.938a4.7,4.7,0,0,0,4.594-3.75h1.031v.938a2.813,2.813,0,0,0,5.625,0v-.937h1.031a4.7,4.7,0,0,0,4.594,3.75h.938v2.813a.938.938,0,0,0,.938.938h3.75a.938.938,0,0,0,.938-.937v-3.75a4.693,4.693,0,0,0-4.687-4.687h-1.031a4.7,4.7,0,0,0-4.594-3.75h-1.875v-8.444a4.674,4.674,0,0,0,0-7.487V604.97a93.877,93.877,0,0,0,17.945-1.915C232.89,601.67,236,599.8,236,597.5S232.89,593.33,226.757,591.945Zm-23.57,37.43h-1.875a.938.938,0,0,0-.937.938,2.816,2.816,0,0,1-2.812,2.813h-1.875a.938.938,0,0,0-.937.938v2.813h-1.875v-2.812a2.816,2.816,0,0,1,2.813-2.812h1.875a.938.938,0,0,0,.938-.937,2.816,2.816,0,0,1,2.813-2.812h1.875Zm7.5-1.875a2.816,2.816,0,0,1,2.813,2.813.938.938,0,0,0,.938.938h1.875a2.816,2.816,0,0,1,2.813,2.813v2.813H217.25v-2.812a.938.938,0,0,0-.937-.937h-1.875a2.816,2.816,0,0,1-2.812-2.812.938.938,0,0,0-.937-.937h-1.875V627.5Zm-3-11.817-.747.562v15.942a.938.938,0,0,1-1.875,0V616.245l-.747-.562a2.8,2.8,0,0,1,0-4.491l.747-.562V605h1.875v5.63l.747.562a2.8,2.8,0,0,1,0,4.491Zm18.659-14.457a96.9,96.9,0,0,1-20.344,1.9,96.9,96.9,0,0,1-20.344-1.9c-6.143-1.387-7.781-2.994-7.781-3.726s1.639-2.339,7.781-3.726a96.9,96.9,0,0,1,20.344-1.9,96.9,96.9,0,0,1,20.344,1.9c6.143,1.387,7.781,2.994,7.781,3.726S232.486,599.839,226.344,601.226Z",
      transform: "translate(-176 -590)",
      fill: "#212121"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/chair.tsx":
/*!*********************************************!*\
  !*** ./src/assets/icons/category/chair.tsx ***!
  \*********************************************/
/*! exports provided: Chair */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Chair", function() { return Chair; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\chair.tsx";
const Chair = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "40.4",
    height: "62",
    viewBox: "0 0 40.4 62",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Chair",
      transform: "translate(-312 -308)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_111",
        "data-name": "Ellipse 111",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(322 314.4)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_112",
        "data-name": "Ellipse 112",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(341.2 314.4)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_113",
        "data-name": "Ellipse 113",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(331.6 314.4)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_114",
        "data-name": "Ellipse 114",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(322 324)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_115",
        "data-name": "Ellipse 115",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(341.2 324)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_116",
        "data-name": "Ellipse 116",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(331.6 324)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_117",
        "data-name": "Ellipse 117",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(322 333.6)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_118",
        "data-name": "Ellipse 118",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(341.2 333.6)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
        id: "Ellipse_119",
        "data-name": "Ellipse 119",
        cx: "0.6",
        cy: "0.6",
        r: "0.6",
        transform: "translate(331.6 333.6)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17427",
        "data-name": "Path 17427",
        d: "M351.4,339.8H313v-2.4a2.4,2.4,0,0,1,2.4-2.4H349a2.4,2.4,0,0,1,2.4,2.4Z",
        transform: "translate(0 5.2)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 131,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_7",
        "data-name": "Line 7",
        y1: "24",
        transform: "translate(315.4 345)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 142,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_8",
        "data-name": "Line 8",
        y2: "24",
        transform: "translate(349 345)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 153,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17428",
        "data-name": "Path 17428",
        d: "M348.6,340.2H315V313.8a4.8,4.8,0,0,1,4.8-4.8h24a4.8,4.8,0,0,1,4.8,4.8Z",
        transform: "translate(0.4 0)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 164,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/dressing-table.tsx":
/*!******************************************************!*\
  !*** ./src/assets/icons/category/dressing-table.tsx ***!
  \******************************************************/
/*! exports provided: DressingTable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DressingTable", function() { return DressingTable; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\dressing-table.tsx";
const DressingTable = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "39.867",
    height: "62",
    viewBox: "0 0 39.867 62",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Dressing_Table",
      "data-name": "Dressing Table",
      transform: "translate(-942.634 -346.008)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        id: "Rectangle_1064",
        "data-name": "Rectangle 1064",
        width: "18.934",
        height: "19.835",
        transform: "translate(943.634 384.083)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17426",
        "data-name": "Path 17426",
        d: "M970.947,347.008h0a14.519,14.519,0,0,1,14.476,14.476v22.6H956.471v-22.6A14.519,14.519,0,0,1,970.947,347.008Z",
        transform: "translate(-8.38)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        id: "Rectangle_1065",
        "data-name": "Rectangle 1065",
        width: "18.934",
        height: "19.835",
        transform: "translate(962.568 384.083)",
        strokeWidth: "2",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_1",
        "data-name": "Line 1",
        y2: "3.09",
        transform: "translate(958.781 392.455)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_2",
        "data-name": "Line 2",
        y2: "3.09",
        transform: "translate(966.355 392.455)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_3",
        "data-name": "Line 3",
        y2: "3.09",
        transform: "translate(945.729 403.918)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_4",
        "data-name": "Line 4",
        y2: "3.09",
        transform: "translate(979.034 403.918)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_5",
        "data-name": "Line 5",
        x1: "15.39",
        y2: "15.39",
        transform: "translate(954.873 359.746)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
        id: "Line_6",
        "data-name": "Line 6",
        x1: "8.437",
        y2: "8.437",
        transform: "translate(955.706 360.578)",
        fill: "none",
        stroke: "#212121",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/reading-table.tsx":
/*!*****************************************************!*\
  !*** ./src/assets/icons/category/reading-table.tsx ***!
  \*****************************************************/
/*! exports provided: ReadingTable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReadingTable", function() { return ReadingTable; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\reading-table.tsx";
const ReadingTable = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "60",
    height: "60",
    viewBox: "0 0 60 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Reading_Table",
      "data-name": "Reading Table",
      transform: "translate(-448 -584)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17417",
        "data-name": "Path 17417",
        d: "M506.125,608.375H459.25a3.749,3.749,0,0,0-2.812-3.627v-3.873a.938.938,0,0,0-.232-.617l-5.843-6.679,9.16-5.829H463v.944a4.676,4.676,0,0,0-1.875,3.743v.938H470.5v-.937a4.676,4.676,0,0,0-1.875-3.743v-1.882a2.811,2.811,0,0,0-5.462-.937H459.25a.938.938,0,0,0-.5.146l-10.312,6.563a.938.938,0,0,0-.2,1.408l6.331,7.236v3.52a3.749,3.749,0,0,0-2.812,3.627h-1.875A1.875,1.875,0,0,0,448,610.25v31.875A1.875,1.875,0,0,0,449.875,644h1.875a1.875,1.875,0,0,0,1.875-1.875V614H478v28.125A1.875,1.875,0,0,0,479.875,644h26.25A1.875,1.875,0,0,0,508,642.125V610.25A1.875,1.875,0,0,0,506.125,608.375Zm-40.312-22.5a.939.939,0,0,1,.938.938v2.817l.747.562a2.805,2.805,0,0,1,.967,1.308h-5.3a2.805,2.805,0,0,1,.967-1.308l.747-.562v-2.817A.939.939,0,0,1,465.813,585.875ZM455.5,606.5a1.877,1.877,0,0,1,1.875,1.875h-3.75A1.877,1.877,0,0,1,455.5,606.5Zm50.625,35.625h-26.25V629h26.25Zm0-15h-26.25V614h26.25Zm0-15H451.75v30h-1.875V610.25h56.25Z",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17418",
        "data-name": "Path 17418",
        d: "M492.938,619.875h3.75a.938.938,0,0,0,0-1.875h-3.75a.938.938,0,0,0,0,1.875Z",
        transform: "translate(-2.75 -2.125)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17419",
        "data-name": "Path 17419",
        d: "M492.938,635.875h3.75a.938.938,0,0,0,0-1.875h-3.75a.938.938,0,0,0,0,1.875Z",
        transform: "translate(-2.75 -3.125)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/relax-chair.tsx":
/*!***************************************************!*\
  !*** ./src/assets/icons/category/relax-chair.tsx ***!
  \***************************************************/
/*! exports provided: RelaxChair */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RelaxChair", function() { return RelaxChair; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\relax-chair.tsx";
const RelaxChair = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "45",
    height: "60",
    viewBox: "0 0 45 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Relax_chair",
      "data-name": "Relax chair",
      transform: "translate(-48 -584)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17415",
        "data-name": "Path 17415",
        d: "M82.71,587.219A3.751,3.751,0,0,0,79,584H63a3.751,3.751,0,0,0-3.713,3.219L56,614H86Zm-21.562.25A1.883,1.883,0,0,1,63,585.875H79a1.883,1.883,0,0,1,1.853,1.595l3.029,24.655H58.12Z",
        transform: "translate(-0.5)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17416",
        "data-name": "Path 17416",
        d: "M91.125,608H89.25a1.875,1.875,0,0,0-1.875,1.875v1.875a1.875,1.875,0,0,0,1.875,1.875v7.5H87.375a3.75,3.75,0,0,0-3.75-3.75H57.375a3.75,3.75,0,0,0-3.75,3.75H51.75v-7.5a1.875,1.875,0,0,0,1.875-1.875v-1.875A1.875,1.875,0,0,0,51.75,608H49.875A1.875,1.875,0,0,0,48,609.875v1.875a1.875,1.875,0,0,0,1.875,1.875v7.5A1.875,1.875,0,0,0,51.75,623h2.38a3.747,3.747,0,0,0,3.245,1.875H66.75v3.75a1.875,1.875,0,0,0,1.875,1.875h.938v1.875H63.938a4.693,4.693,0,0,0-4.687,4.688v2.976a2.813,2.813,0,1,0,1.875,0v-2.976a2.816,2.816,0,0,1,2.813-2.812h5.625v5.788a2.813,2.813,0,1,0,1.875,0V634.25h5.625a2.816,2.816,0,0,1,2.813,2.813v2.976a2.813,2.813,0,1,0,1.875,0v-2.976a4.693,4.693,0,0,0-4.687-4.687H71.438V630.5h.938a1.875,1.875,0,0,0,1.875-1.875v-3.75h9.375A3.744,3.744,0,0,0,86.869,623H89.25a1.875,1.875,0,0,0,1.875-1.875v-7.5A1.875,1.875,0,0,0,93,611.75v-1.875A1.875,1.875,0,0,0,91.125,608Zm-41.25,3.75v-1.875H51.75v1.875Zm10.313,31.875a.938.938,0,1,1,.938-.937A.939.939,0,0,1,60.188,643.625Zm20.625-1.875a.938.938,0,1,1-.937.938A.939.939,0,0,1,80.813,641.75ZM70.5,643.625a.938.938,0,1,1,.938-.937A.939.939,0,0,1,70.5,643.625Zm1.875-15h-3.75v-3.75h3.75ZM83.625,623H57.375a1.875,1.875,0,0,1,0-3.75h26.25a1.875,1.875,0,0,1,0,3.75Zm7.5-11.25H89.25v-1.875h1.875Z",
        transform: "translate(0 -1.5)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/sofa.tsx":
/*!********************************************!*\
  !*** ./src/assets/icons/category/sofa.tsx ***!
  \********************************************/
/*! exports provided: Sofa */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Sofa", function() { return Sofa; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\sofa.tsx";
const Sofa = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "66.782",
    height: "48",
    viewBox: "0 0 66.782 48",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "Sofa",
      d: "M100.643,196.523h-.116a6.04,6.04,0,0,0-2.092.375v-4.549A8.348,8.348,0,0,0,90.087,184H56.7a8.348,8.348,0,0,0-8.348,8.348v4.532a6.258,6.258,0,0,0-2.087-.358c-.133,0-.266,0-.4.013a6.261,6.261,0,0,0-1.687,12.151v21.227A2.086,2.086,0,0,0,46.261,232h4.174a2.086,2.086,0,0,0,2.087-2.087H94.261A2.086,2.086,0,0,0,96.348,232h4.174a2.086,2.086,0,0,0,2.087-2.087V208.686a6.261,6.261,0,0,0-1.966-12.163Zm-50.208,33.39H46.261V208.686a2.086,2.086,0,0,0-1.391-1.967,4.154,4.154,0,0,1-2.778-4.151,4.211,4.211,0,0,1,3.9-3.951c.09-.005.181-.008.27-.008a4.178,4.178,0,0,1,4.174,4.174Zm43.826-2.087H52.522v-6.261H94.261Zm-41.739-8.348v-6.261H70.261a2.089,2.089,0,0,1,2.087,2.087v4.174Zm41.739,0H74.435V215.3a2.089,2.089,0,0,1,2.087-2.087H94.261Zm0-16.555v8.207H76.522a4.161,4.161,0,0,0-3.13,1.419,4.161,4.161,0,0,0-3.13-1.419H52.522v-8.348a6.245,6.245,0,0,0-2.087-4.665v-5.769a6.269,6.269,0,0,1,6.261-6.261H90.087a6.269,6.269,0,0,1,6.261,6.261v5.831A6.467,6.467,0,0,0,94.261,202.923Zm7.652,3.8a2.086,2.086,0,0,0-1.391,1.967v21.227H96.348v-26.99a4.306,4.306,0,0,1,4.179-4.315h.076a4.174,4.174,0,0,1,1.31,8.109Z",
      transform: "translate(-40 -184)",
      fill: "#212121"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/storage.tsx":
/*!***********************************************!*\
  !*** ./src/assets/icons/category/storage.tsx ***!
  \***********************************************/
/*! exports provided: Storage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Storage", function() { return Storage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\storage.tsx";
const Storage = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "48.75",
    height: "60",
    viewBox: "0 0 48.75 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Storage",
      transform: "translate(-318 -448)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17422",
        "data-name": "Path 17422",
        d: "M364.875,448h-45A1.874,1.874,0,0,0,318,449.875v52.5a1.874,1.874,0,0,0,1.875,1.875h3.75V508H325.5v-3.75h33.75V508h1.875v-3.75h3.75a1.874,1.874,0,0,0,1.875-1.875v-52.5A1.874,1.874,0,0,0,364.875,448Zm-22.5,54.375h-22.5V493h22.5Zm0-11.25h-22.5V459.25h10.313v2.311l-8.02,5.347a.938.938,0,0,0,.52,1.717h16.875a.938.938,0,0,0,.52-1.717l-8.02-5.347V459.25h10.313Zm-11.25-27.936,5.341,3.561H325.784Zm11.25-5.814h-22.5v-7.5h22.5Zm22.5,45H344.25V493h20.625Zm0-11.25H344.25v-41.25h20.625Z",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17423",
        "data-name": "Path 17423",
        d: "M355,502h4a1,1,0,0,0,0-2h-4a1,1,0,0,0,0,2Z",
        transform: "translate(-2.543 -4)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17424",
        "data-name": "Path 17424",
        d: "M329,502h4a1,1,0,0,0,0-2h-4a1,1,0,0,0,0,2Z",
        transform: "translate(-0.707 -4)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17425",
        "data-name": "Path 17425",
        d: "M349,478a1,1,0,0,0,1-1v-4a1,1,0,0,0-2,0v4A1,1,0,0,0,349,478Z",
        transform: "translate(-1.95 -1.655)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/table.tsx":
/*!*********************************************!*\
  !*** ./src/assets/icons/category/table.tsx ***!
  \*********************************************/
/*! exports provided: Table */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Table", function() { return Table; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\table.tsx";
const Table = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "60",
    height: "48.75",
    viewBox: "0 0 60 48.75",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      id: "Center_table",
      "data-name": "Center table",
      d: "M226.757,591.945A98.842,98.842,0,0,0,206,590a98.842,98.842,0,0,0-20.757,1.945C179.11,593.33,176,595.2,176,597.5s3.11,4.17,9.243,5.555a93.868,93.868,0,0,0,17.945,1.915v4.724a4.674,4.674,0,0,0,0,7.487v8.444h-1.875a4.7,4.7,0,0,0-4.594,3.75h-1.031A4.693,4.693,0,0,0,191,634.063v3.75a.938.938,0,0,0,.938.938h3.75a.938.938,0,0,0,.938-.937V635h.938a4.7,4.7,0,0,0,4.594-3.75h1.031v.938a2.813,2.813,0,0,0,5.625,0v-.937h1.031a4.7,4.7,0,0,0,4.594,3.75h.938v2.813a.938.938,0,0,0,.938.938h3.75a.938.938,0,0,0,.938-.937v-3.75a4.693,4.693,0,0,0-4.687-4.687h-1.031a4.7,4.7,0,0,0-4.594-3.75h-1.875v-8.444a4.674,4.674,0,0,0,0-7.487V604.97a93.877,93.877,0,0,0,17.945-1.915C232.89,601.67,236,599.8,236,597.5S232.89,593.33,226.757,591.945Zm-23.57,37.43h-1.875a.938.938,0,0,0-.937.938,2.816,2.816,0,0,1-2.812,2.813h-1.875a.938.938,0,0,0-.937.938v2.813h-1.875v-2.812a2.816,2.816,0,0,1,2.813-2.812h1.875a.938.938,0,0,0,.938-.937,2.816,2.816,0,0,1,2.813-2.812h1.875Zm7.5-1.875a2.816,2.816,0,0,1,2.813,2.813.938.938,0,0,0,.938.938h1.875a2.816,2.816,0,0,1,2.813,2.813v2.813H217.25v-2.812a.938.938,0,0,0-.937-.937h-1.875a2.816,2.816,0,0,1-2.812-2.812.938.938,0,0,0-.937-.937h-1.875V627.5Zm-3-11.817-.747.562v15.942a.938.938,0,0,1-1.875,0V616.245l-.747-.562a2.8,2.8,0,0,1,0-4.491l.747-.562V605h1.875v5.63l.747.562a2.8,2.8,0,0,1,0,4.491Zm18.659-14.457a96.9,96.9,0,0,1-20.344,1.9,96.9,96.9,0,0,1-20.344-1.9c-6.143-1.387-7.781-2.994-7.781-3.726s1.639-2.339,7.781-3.726a96.9,96.9,0,0,1,20.344-1.9,96.9,96.9,0,0,1,20.344,1.9c6.143,1.387,7.781,2.994,7.781,3.726S232.486,599.839,226.344,601.226Z",
      transform: "translate(-176 -590)",
      fill: "#212121"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/category/tools.tsx":
/*!*********************************************!*\
  !*** ./src/assets/icons/category/tools.tsx ***!
  \*********************************************/
/*! exports provided: Tools */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tools", function() { return Tools; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\category\\tools.tsx";
const Tools = ({
  color = 'currentColor',
  width = '18px',
  height = '18px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "60",
    height: "60",
    viewBox: "0 0 60 60",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Tools",
      transform: "translate(-448 -720)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17429",
        "data-name": "Path 17429",
        d: "M477.063,765h-.88l.851-3.4-.967-3.865L474.25,765H455.5l3.281-13.125H474.6L474.135,750H459.25l3.281-13.125h8.322L470.385,735H463l3.75-15h-1.933l-14.531,58.125h-1.348a.938.938,0,0,0,0,1.875h3.75a.938.938,0,0,0,0-1.875h-.469l2.813-11.25h18.75l-2.812,11.25h-1.406a.938.938,0,0,0,0,1.875h3.75a.938.938,0,0,0,0-1.875H472.9l2.813-11.25h1.349a.938.938,0,0,0,0-1.875Z",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
        id: "Path_17430",
        "data-name": "Path 17430",
        d: "M508.434,778.125h-1.349l-2.812-11.25h.412a.938.938,0,0,0,0-1.875h-.88l-3.281-13.125h.412a.938.938,0,0,0,0-1.875h-.88l-3.281-13.125h.412a.938.938,0,0,0,0-1.875h-.88l-3.281-13.125h2.287a.938.938,0,0,0,0-1.875H469.938l.114.455,14.417,57.67h-.411a.938.938,0,0,0,0,1.875h3.75a.938.938,0,0,0,0-1.875H486.4l-2.812-11.25h18.75l2.813,11.25h-.469a.938.938,0,0,0,0,1.875h3.75a.938.938,0,0,0,0-1.875Zm-36.094-56.25h18.75L494.371,735h-18.75Zm3.75,15h18.75L498.121,750h-18.75ZM483.121,765l-3.281-13.125h18.75L501.871,765Z",
        transform: "translate(-1.371)",
        fill: "#212121"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/category-walker/category-walker.style.tsx":
/*!******************************************************************!*\
  !*** ./src/components/category-walker/category-walker.style.tsx ***!
  \******************************************************************/
/*! exports provided: WalkerWrapper, CategoryWrapper, Category, NoCategory, IconWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WalkerWrapper", function() { return WalkerWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryWrapper", function() { return CategoryWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return Category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoCategory", function() { return NoCategory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return IconWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);


const WalkerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "category-walkerstyle__WalkerWrapper",
  componentId: "cy1wd6-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
  padding: '0px 20px 15px',
  button: {
    padding: 0
  }
}));
const CategoryWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "category-walkerstyle__CategoryWrapper",
  componentId: "cy1wd6-1"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  alignItems: 'baseline',
  width: '100%'
}));
const Category = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "category-walkerstyle__Category",
  componentId: "cy1wd6-2"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontSize: 'sm',
  color: 'text.bold',
  fontWeight: 'bold',
  padding: '5px 10px',
  backgroundColor: 'gray.500',
  borderRadius: 'base'
}));
const NoCategory = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "category-walkerstyle__NoCategory",
  componentId: "cy1wd6-3"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontSize: 'base',
  color: 'text.bold',
  fontWeight: 'bold'
}));
const IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "category-walkerstyle__IconWrapper",
  componentId: "cy1wd6-4"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  padding: '0 8px',
  color: 'gray.900'
}));

/***/ }),

/***/ "./src/components/category-walker/category-walker.tsx":
/*!************************************************************!*\
  !*** ./src/components/category-walker/category-walker.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _category_walker_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./category-walker.style */ "./src/components/category-walker/category-walker.style.tsx");
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var components_spring_modal_spring_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/spring-modal/spring-modal */ "./src/components/spring-modal/spring-modal.tsx");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/startCase */ "lodash/startCase");
/* harmony import */ var lodash_startCase__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_startCase__WEBPACK_IMPORTED_MODULE_6__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\category-walker\\category-walker.tsx";




 // import { TreeMenu } from 'components/tree-menu/tree-menu';



const CategoryWalker = ({
  style,
  className,
  children
}) => {
  const {
    0: isOpen,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    query
  } = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_category_walker_style__WEBPACK_IMPORTED_MODULE_2__["WalkerWrapper"], {
    style: style,
    className: className,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_category_walker_style__WEBPACK_IMPORTED_MODULE_2__["CategoryWrapper"], {
      children: query.category ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_category_walker_style__WEBPACK_IMPORTED_MODULE_2__["Category"], {
        children: lodash_startCase__WEBPACK_IMPORTED_MODULE_6___default()(query.category)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_category_walker_style__WEBPACK_IMPORTED_MODULE_2__["NoCategory"], {
        children: "No Category Selected"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_3__["Button"], {
      variant: "text",
      onClick: () => setOpen(true),
      children: "Filter"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_spring_modal_spring_modal__WEBPACK_IMPORTED_MODULE_4__["default"], {
      isOpen: isOpen,
      onRequestClose: () => setOpen(false),
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 31,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (CategoryWalker);

/***/ }),

/***/ "./src/components/placeholder/placeholder.tsx":
/*!****************************************************!*\
  !*** ./src/components/placeholder/placeholder.tsx ***!
  \****************************************************/
/*! exports provided: SidebarMobileLoader, SidebarLoader, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarMobileLoader", function() { return SidebarMobileLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarLoader", function() { return SidebarLoader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-content-loader */ "react-content-loader");
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\placeholder\\placeholder.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const PostLoader = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({
  height: 350,
  width: 245,
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb"
}, props), {}, {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "2",
    y: "2",
    rx: "0",
    ry: "0",
    width: "240",
    height: "197"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "220",
    rx: "0",
    ry: "0",
    width: "140",
    height: "25"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "254",
    rx: "0",
    ry: "0",
    width: "65",
    height: "15"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "15",
    y: "300",
    rx: "0",
    ry: "0",
    width: "67",
    height: "20"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "170",
    y: "300",
    rx: "0",
    ry: "0",
    width: "60",
    height: "20"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, undefined)]
}), void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 5,
  columnNumber: 3
}, undefined);

const SidebarMobileLoader = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, {
  height: 46,
  width: 400,
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "58",
    y: "10",
    rx: "0",
    ry: "0",
    width: "287",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "364",
    y: "10",
    rx: "0",
    ry: "0",
    width: "26",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "16",
    y: "10",
    rx: "0",
    ry: "0",
    width: "26",
    height: "26"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, undefined)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 21,
  columnNumber: 3
}, undefined);
const SidebarLoader = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_content_loader__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({
  height: 400,
  width: "calc(100% - 30px)",
  speed: 2,
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb"
}, props), {}, {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "376",
    y: "22",
    rx: "0",
    ry: "0",
    width: "0",
    height: "0"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "50",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 44,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "50",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "89",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 47,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "89",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "128",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "128",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "167",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "167",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 54,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "206",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 56,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "206",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 57,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "245",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "245",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 60,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "284",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 62,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "284",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "27",
    y: "323",
    rx: "0",
    ry: "0",
    width: "24",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 65,
    columnNumber: 5
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
    x: "69",
    y: "323",
    rx: "0",
    ry: "0",
    width: "260",
    height: "24"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 66,
    columnNumber: 5
  }, undefined)]
}), void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 35,
  columnNumber: 3
}, undefined);
/* harmony default export */ __webpack_exports__["default"] = (PostLoader);

/***/ }),

/***/ "./src/components/scrollbar/scrollbar.tsx":
/*!************************************************!*\
  !*** ./src/components/scrollbar/scrollbar.tsx ***!
  \************************************************/
/*! exports provided: Scrollbar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Scrollbar", function() { return Scrollbar; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! overlayscrollbars-react */ "overlayscrollbars-react");
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\scrollbar\\scrollbar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Scrollbar = (_ref) => {
  let {
    children,
    className,
    options,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, ["children", "className", "options", "style"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__["OverlayScrollbarsComponent"], _objectSpread(_objectSpread({
    options: _objectSpread({
      className: `${className} os-theme-thin`,
      scrollbars: {
        autoHide: 'leave'
      }
    }, options),
    style: style
  }, props), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/spring-modal/spring-modal.tsx":
/*!******************************************************!*\
  !*** ./src/components/spring-modal/spring-modal.tsx ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spring */ "react-spring");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spring-modal */ "react-spring-modal");
/* harmony import */ var react_spring_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! assets/icons/CloseIcon */ "./src/assets/icons/CloseIcon.tsx");
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\spring-modal\\spring-modal.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const SpringModal = ({
  isOpen,
  onRequestClose,
  children,
  style = {}
}) => {
  const transition = Object(react_spring__WEBPACK_IMPORTED_MODULE_2__["useTransition"])(isOpen, null, {
    from: {
      transform: 'translateY(100%) translateY(55px) translateX(-50%)'
    },
    enter: {
      transform: 'translateY(0%) translateY(0) translateX(-50%)'
    },
    leave: {
      transform: 'translateY(100%) translateY(55px) translateX(-50%)'
    }
  });
  const staticStyles = {
    position: 'absolute',
    bottom: 0,
    left: '50%',
    padding: '0',
    width: 'calc(100% + 1px)',
    height: '100%',
    maxHeight: '70vh',
    backgroundColor: '#ffffff',
    borderRadius: '0px',
    borderTopLeftRadius: '20px',
    borderTopRightRadius: '20px',
    zIndex: 99999
  };
  const buttonStyle = {
    width: 40,
    height: 40,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    color: '#0D1136',
    border: 0,
    outline: 0,
    boxShadow: 'none',
    borderRadius: '50%',
    position: 'absolute',
    top: -55,
    left: '50%',
    transform: 'translateX(-50%)',
    cursor: 'pointer',
    ':focus': {
      outline: 0,
      boxShadow: 'none'
    }
  };
  const scrollbarStyle = {
    height: '100%',
    maxHeight: '100%'
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring_modal__WEBPACK_IMPORTED_MODULE_3__["BaseModal"], {
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    children: transition.map(({
      item,
      key,
      props: transitionStyles
    }) => item && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring__WEBPACK_IMPORTED_MODULE_2__["animated"].div, {
      style: _objectSpread(_objectSpread(_objectSpread({}, transitionStyles), staticStyles), style),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
        type: "button",
        onClick: onRequestClose,
        style: _objectSpread({}, buttonStyle),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_4__["CloseIcon"], {
          style: {
            width: 12,
            height: 12
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 15
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_5__["Scrollbar"], {
        style: _objectSpread({}, scrollbarStyle),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          style: {
            padding: '30px'
          },
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 87,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 15
      }, undefined)]
    }, key, true, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 13
    }, undefined))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 71,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SpringModal);

/***/ }),

/***/ "./src/components/tree-menu/tree-menu.style.tsx":
/*!******************************************************!*\
  !*** ./src/components/tree-menu/tree-menu.style.tsx ***!
  \******************************************************/
/*! exports provided: Header, IconWrapper, Title, Content, Frame */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconWrapper", function() { return IconWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Title", function() { return Title; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Content", function() { return Content; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Frame", function() { return Frame; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spring */ "react-spring");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_2__);



const Header = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.header.withConfig({
  displayName: "tree-menustyle__Header",
  componentId: "v82zw4-0"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  fontSize: props.depth === 'parent' ? ['base'] : ['sm'],
  fontWeight: 'medium',
  display: 'flex',
  alignItems: 'center',
  marginBottom: props.depth === 'parent' ? 12 : 0,
  color: props.depth === 'parent' ? props.open ? 'primary.regular' : 'text.bold' : props.open ? 'primary.regular' : 'text.regular',
  cursor: 'pointer',
  transition: '0.15s ease-in-out',
  padding: props.depth === 'parent' ? '5px 0' : '5px 10px',
  marginLeft: props.depth === 'child' ? '-10px' : null,
  borderRadius: props.depth === 'child' ? 'base' : null,
  backgroundColor: props.depth === 'child' ? props.open && 'gray.200' : null,
  '.toggleButton': {
    color: props.open ? 'primary.regular' : 'text.bold',
    padding: '0 5px',
    marginLeft: 'auto',
    height: 'auto',
    transition: 'transform 0.3s',
    transform: props.open ? 'rotate(90deg)' : ''
  },
  '&:hover': {
    color: 'primary.regular',
    '.toggleButton': {
      color: 'primary.regular'
    }
  }
}), {
  outline: 0
});
const IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "tree-menustyle__IconWrapper",
  componentId: "v82zw4-1"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  width: props.depth === 'child' ? 10 : 20,
  height: 'auto',
  marginRight: props.depth === 'child' ? '8px' : 15,
  svg: {
    maxWidth: '100%',
    maxHeight: 20,
    height: props.depth === 'child' ? '2px' : 'auto'
  }
}), {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  flexShrink: 0
});
const Title = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "tree-menustyle__Title",
  componentId: "v82zw4-2"
})({
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  verticalAlign: 'middle',
  overflow: 'hidden'
});
const Content = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(react_spring__WEBPACK_IMPORTED_MODULE_2__["animated"].div).withConfig({
  displayName: "tree-menustyle__Content",
  componentId: "v82zw4-3"
})({
  willChange: 'transform, opacity, height',
  borderLeft: 0,
  overflow: 'hidden'
});
const Frame = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "tree-menustyle__Frame",
  componentId: "v82zw4-4"
})(props => _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  marginBottom: props.depth === 'parent' ? 15 : 10,
  paddingLeft: props.depth === 'child' ? 32 : 0
}), {
  position: 'relative',
  overflowX: 'hidden'
});

/***/ }),

/***/ "./src/components/tree-menu/tree-menu.tsx":
/*!************************************************!*\
  !*** ./src/components/tree-menu/tree-menu.tsx ***!
  \************************************************/
/*! exports provided: TreeMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeMenu", function() { return TreeMenu; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! utils/hooks */ "./src/utils/hooks.tsx");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spring */ "react-spring");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _tree_menu_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tree-menu.style */ "./src/components/tree-menu/tree-menu.style.tsx");
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var assets_icons_ArrowNext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! assets/icons/ArrowNext */ "./src/assets/icons/ArrowNext.tsx");
/* harmony import */ var assets_icons_category_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! assets/icons/category-icons */ "./src/assets/icons/category-icons.ts");


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\tree-menu\\tree-menu.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const Tree = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(({
  children,
  name,
  icon,
  // isOpen,
  onClick,
  dropdown,
  onToggleBtnClick,
  depth,
  defaultOpen = false
}) => {
  const {
    0: isOpen,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(defaultOpen);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setOpen(defaultOpen);
  }, [defaultOpen]);
  const previous = Object(utils_hooks__WEBPACK_IMPORTED_MODULE_2__["usePrevious"])(isOpen);
  const [bind, {
    height: viewHeight
  }] = Object(utils_hooks__WEBPACK_IMPORTED_MODULE_2__["useMeasure"])();
  const {
    height,
    opacity,
    transform
  } = Object(react_spring__WEBPACK_IMPORTED_MODULE_3__["useSpring"])({
    from: {
      height: 0,
      opacity: 0,
      transform: 'translate3d(20px,0,0)'
    },
    to: {
      height: isOpen ? viewHeight : 0,
      opacity: isOpen ? 1 : 0,
      transform: `translate3d(${isOpen ? 0 : 20}px,0,0)`
    }
  }); // const Icon = icon ? Icons[icon] : depth === 'child' ? Icons['Minus'] : null;
  // const Icon = icon ? Icons[icon] : null;

  const Icon = ({
    iconName,
    style
  }) => {
    const TagName = assets_icons_category_icons__WEBPACK_IMPORTED_MODULE_7__[iconName];
    return !!TagName ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TagName, {
      style: style
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 9
    }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      children: ["Invalid icon ", iconName]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 9
    }, undefined);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tree_menu_style__WEBPACK_IMPORTED_MODULE_4__["Frame"], {
    depth: depth,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tree_menu_style__WEBPACK_IMPORTED_MODULE_4__["Header"], {
      open: isOpen,
      depth: depth,
      className: depth,
      children: [icon && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tree_menu_style__WEBPACK_IMPORTED_MODULE_4__["IconWrapper"], {
        depth: depth,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Icon, {
          iconName: icon
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 15
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tree_menu_style__WEBPACK_IMPORTED_MODULE_4__["Title"], {
        onClick: onClick,
        children: name
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 11
      }, undefined), dropdown === true && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        onClick: () => setOpen(!isOpen),
        variant: "text",
        className: "toggleButton",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_ArrowNext__WEBPACK_IMPORTED_MODULE_6__["ArrowNext"], {
          width: "16px"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 15
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 9
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tree_menu_style__WEBPACK_IMPORTED_MODULE_4__["Content"], {
      style: {
        opacity,
        height: isOpen && previous === isOpen ? 'auto' : height
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_spring__WEBPACK_IMPORTED_MODULE_3__["animated"].div, _objectSpread(_objectSpread({
        style: {
          transform
        }
      }, bind), {}, {
        children: children
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 9
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 46,
    columnNumber: 7
  }, undefined);
});
const TreeMenu = ({
  data,
  className,
  onClick,
  active
}) => {
  const handler = children => {
    return children.map(subOption => {
      if (!subOption.children) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Tree, {
          name: subOption.title,
          icon: subOption.icon,
          depth: "child",
          onClick: () => onClick(subOption.slug),
          defaultOpen: active === subOption.slug
        }, subOption.title, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, undefined);
      }

      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Tree, {
        name: subOption.title,
        icon: subOption.icon,
        dropdown: !subOption.children.length ? false : true,
        depth: "parent",
        onClick: () => onClick(subOption.slug),
        defaultOpen: active === subOption.slug || subOption.children.some(item => item.slug === active),
        children: handler(subOption.children)
      }, subOption.title, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 9
      }, undefined);
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: handler(data)
  }, void 0, false);
};

/***/ }),

/***/ "./src/layouts/sidebar/sidebar.style.tsx":
/*!***********************************************!*\
  !*** ./src/layouts/sidebar/sidebar.style.tsx ***!
  \***********************************************/
/*! exports provided: PopoverWrapper, RequestMedicine, SidebarWrapper, CategoryWrapper, TreeWrapper, PopoverHandler, Loading */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverWrapper", function() { return PopoverWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestMedicine", function() { return RequestMedicine; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarWrapper", function() { return SidebarWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryWrapper", function() { return CategoryWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreeWrapper", function() { return TreeWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverHandler", function() { return PopoverHandler; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Loading", function() { return Loading; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const Fade = Object(styled_components__WEBPACK_IMPORTED_MODULE_0__["keyframes"])(["from{opacity:0;}to{opacity:1;}"]);
const PopoverWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__PopoverWrapper",
  componentId: "sc-1r07hi6-0"
})(["@media (min-width:991px){display:none;}.popover-handler{display:block;padding:15px;cursor:pointer;}.popover-content{position:relative;top:auto;left:auto;right:auto;border-radius:0;box-shadow:none;padding:25px 35px;border-top:1px solid ", ";&::before{display:none;}.category-dropdown{animation:", " 0.6s;}@media (max-width:990px){padding:25px;}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.500', '#f1f1f1'), Fade);
const RequestMedicine = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "sidebarstyle__RequestMedicine",
  componentId: "sc-1r07hi6-1"
})(["width:100%;height:50px;display:flex;align-items:center;margin-bottom:20px;padding-left:50px;background-color:", ";font-size:calc(", " - 1px);font-weight:", ";color:", ";cursor:pointer;@media (max-width:990px){justify-content:center;padding:0;border-radius:", ";}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const SidebarWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__SidebarWrapper",
  componentId: "sc-1r07hi6-2"
})(["padding:45px 0px;padding-top:35px;padding-right:0;@media (max-width:1199px){padding:40px 0px;padding-right:0;}@media (max-width:990px){display:none;padding:0;}.sidebar-scrollbar{height:100%;max-height:calc(100vh - 108px);}"]);
const CategoryWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__CategoryWrapper",
  componentId: "sc-1r07hi6-3"
})(["position:relative;width:100%;"]);
const TreeWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__TreeWrapper",
  componentId: "sc-1r07hi6-4"
})(["padding-left:50px;padding-right:20px;"]);
const PopoverHandler = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__PopoverHandler",
  componentId: "sc-1r07hi6-5"
})(["font-size:calc(", " - 1px);font-weight:", ";color:", ";display:flex;align-items:center;justify-content:space-between;> div{display:flex;align-items:center;&:first-child{flex-grow:1;svg{margin-right:10px;}}&:last-child{color:", ";}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const Loading = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "sidebarstyle__Loading",
  componentId: "sc-1r07hi6-6"
})(["width:100%;padding:10px;display:flex;align-items:center;justify-content:center;font-size:calc(", " - 1px);color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));

/***/ }),

/***/ "./src/layouts/sidebar/sidebar.tsx":
/*!*****************************************!*\
  !*** ./src/layouts/sidebar/sidebar.tsx ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "../../node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-stickynode */ "react-stickynode");
/* harmony import */ var react_stickynode__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_stickynode__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/scrollbar/scrollbar */ "./src/components/scrollbar/scrollbar.tsx");
/* harmony import */ var contexts_app_app_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! contexts/app/app.provider */ "./src/contexts/app/app.provider.ts");
/* harmony import */ var components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! components/placeholder/placeholder */ "./src/components/placeholder/placeholder.tsx");
/* harmony import */ var _sidebar_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./sidebar.style */ "./src/layouts/sidebar/sidebar.style.tsx");
/* harmony import */ var components_tree_menu_tree_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/tree-menu/tree-menu */ "./src/components/tree-menu/tree-menu.tsx");
/* harmony import */ var graphql_query_category_query__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! graphql/query/category.query */ "./src/graphql/query/category.query.ts");
/* harmony import */ var site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! site-settings/site-navigation */ "./src/site-settings/site-navigation.ts");
/* harmony import */ var components_category_walker_category_walker__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! components/category-walker/category-walker */ "./src/components/category-walker/category-walker.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\layouts\\sidebar\\sidebar.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }
















const SidebarCategory = ({
  deviceType: {
    mobile,
    tablet,
    desktop
  },
  type
}) => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  const {
    data,
    loading
  } = Object(_apollo_client__WEBPACK_IMPORTED_MODULE_5__["useQuery"])(graphql_query_category_query__WEBPACK_IMPORTED_MODULE_12__["GET_CATEGORIES"], {
    variables: {
      type
    }
  });
  const {
    pathname,
    query
  } = router;
  const selectedQueries = query.category;

  const onCategoryClick = slug => {
    const {
      type
    } = query,
          rest = _objectWithoutProperties(query, ["type"]);

    if (type) {
      router.push({
        pathname,
        query: _objectSpread(_objectSpread({}, rest), {}, {
          category: slug
        })
      }, {
        pathname: `/${type}`,
        query: _objectSpread(_objectSpread({}, rest), {}, {
          category: slug
        })
      });
    } else {
      router.push({
        pathname,
        query: _objectSpread(_objectSpread({}, rest), {}, {
          category: slug
        })
      });
    }
  };

  const isSidebarSticky = Object(contexts_app_app_provider__WEBPACK_IMPORTED_MODULE_8__["useAppState"])('isSidebarSticky');

  if (!data || loading) {
    if (mobile || tablet) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_9__["SidebarMobileLoader"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 14
      }, undefined);
    }

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_placeholder_placeholder__WEBPACK_IMPORTED_MODULE_9__["SidebarLoader"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 12
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["CategoryWrapper"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["PopoverWrapper"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_category_walker_category_walker__WEBPACK_IMPORTED_MODULE_14__["default"], {
        children: [type === 'medicine' && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].href,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["RequestMedicine"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_4__["FormattedMessage"], {
              id: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].id,
              defaultMessage: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].defaultMessage
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 82,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_tree_menu_tree_menu__WEBPACK_IMPORTED_MODULE_11__["TreeMenu"], {
          data: data.categories,
          onClick: onCategoryClick,
          active: selectedQueries
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["SidebarWrapper"], {
      style: {
        paddingTop: type === 'medicine' ? 0 : 45
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_stickynode__WEBPACK_IMPORTED_MODULE_6___default.a, {
        enabled: isSidebarSticky,
        top: type === 'medicine' ? 89 : 110,
        children: [type === 'medicine' && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].href,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["RequestMedicine"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_4__["FormattedMessage"], {
              id: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].id,
              defaultMessage: site_settings_site_navigation__WEBPACK_IMPORTED_MODULE_13__["REQUEST_MEDICINE_MENU_ITEM"].defaultMessage
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 102,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 101,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_scrollbar_scrollbar__WEBPACK_IMPORTED_MODULE_7__["Scrollbar"], {
          className: "sidebar-scrollbar",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sidebar_style__WEBPACK_IMPORTED_MODULE_10__["TreeWrapper"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_tree_menu_tree_menu__WEBPACK_IMPORTED_MODULE_11__["TreeMenu"], {
              data: data.categories,
              onClick: onCategoryClick,
              active: selectedQueries
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 112,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 111,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 110,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 98,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 97,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 76,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SidebarCategory);

/***/ }),

/***/ "./src/site-settings/site-navigation.ts":
/*!**********************************************!*\
  !*** ./src/site-settings/site-navigation.ts ***!
  \**********************************************/
/*! exports provided: HOME_PAGE, GROCERY_PAGE, GROCERY_PAGE_TWO, BAKERY_PAGE, MAKEUP_PAGE, CLOTHING_PAGE, BAGS_PAGE, BOOK_PAGE, FURNITURE_PAGE, FURNITURE_PAGE_TWO, MEDICINE_PAGE, REQUEST_MEDICINE_PAGE, CHECKOUT_PAGE, CHECKOUT_PAGE_TWO, PROFILE_PAGE, YOUR_ORDER_PAGE, ORDER_RECEIVED_PAGE, OFFER_PAGE, HELP_PAGE, TERMS_AND_SERVICES_PAGE, PRIVACY_POLICY_PAGE, HOME_MENU_ITEM, HELP_MENU_ITEM, OFFER_MENU_ITEM, ORDER_MENU_ITEM, REQUEST_MEDICINE_MENU_ITEM, PROFILE_MENU_ITEM, AUTHORIZED_MENU_ITEMS, CATEGORY_MENU_ITEMS, MOBILE_DRAWER_MENU, PROFILE_SIDEBAR_TOP_MENU, PROFILE_SIDEBAR_BOTTOM_MENU, LANGUAGE_MENU */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOME_PAGE", function() { return HOME_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GROCERY_PAGE", function() { return GROCERY_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GROCERY_PAGE_TWO", function() { return GROCERY_PAGE_TWO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BAKERY_PAGE", function() { return BAKERY_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MAKEUP_PAGE", function() { return MAKEUP_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CLOTHING_PAGE", function() { return CLOTHING_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BAGS_PAGE", function() { return BAGS_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOOK_PAGE", function() { return BOOK_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FURNITURE_PAGE", function() { return FURNITURE_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FURNITURE_PAGE_TWO", function() { return FURNITURE_PAGE_TWO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MEDICINE_PAGE", function() { return MEDICINE_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REQUEST_MEDICINE_PAGE", function() { return REQUEST_MEDICINE_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CHECKOUT_PAGE", function() { return CHECKOUT_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CHECKOUT_PAGE_TWO", function() { return CHECKOUT_PAGE_TWO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILE_PAGE", function() { return PROFILE_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YOUR_ORDER_PAGE", function() { return YOUR_ORDER_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ORDER_RECEIVED_PAGE", function() { return ORDER_RECEIVED_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OFFER_PAGE", function() { return OFFER_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HELP_PAGE", function() { return HELP_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TERMS_AND_SERVICES_PAGE", function() { return TERMS_AND_SERVICES_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PRIVACY_POLICY_PAGE", function() { return PRIVACY_POLICY_PAGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOME_MENU_ITEM", function() { return HOME_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HELP_MENU_ITEM", function() { return HELP_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OFFER_MENU_ITEM", function() { return OFFER_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ORDER_MENU_ITEM", function() { return ORDER_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REQUEST_MEDICINE_MENU_ITEM", function() { return REQUEST_MEDICINE_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILE_MENU_ITEM", function() { return PROFILE_MENU_ITEM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUTHORIZED_MENU_ITEMS", function() { return AUTHORIZED_MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATEGORY_MENU_ITEMS", function() { return CATEGORY_MENU_ITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MOBILE_DRAWER_MENU", function() { return MOBILE_DRAWER_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILE_SIDEBAR_TOP_MENU", function() { return PROFILE_SIDEBAR_TOP_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROFILE_SIDEBAR_BOTTOM_MENU", function() { return PROFILE_SIDEBAR_BOTTOM_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LANGUAGE_MENU", function() { return LANGUAGE_MENU; });
const HOME_PAGE = '/';
const GROCERY_PAGE = '/grocery';
const GROCERY_PAGE_TWO = '/grocery-two';
const BAKERY_PAGE = '/bakery';
const MAKEUP_PAGE = '/makeup';
const CLOTHING_PAGE = '/clothing';
const BAGS_PAGE = '/bags';
const BOOK_PAGE = '/book';
const FURNITURE_PAGE = '/furniture';
const FURNITURE_PAGE_TWO = '/furniture-two';
const MEDICINE_PAGE = '/medicine'; // export const RESTAURANT_PAGE = '/restaurant';

const REQUEST_MEDICINE_PAGE = '/request-medicine';
const CHECKOUT_PAGE = '/checkout';
const CHECKOUT_PAGE_TWO = '/checkout-alternative';
const PROFILE_PAGE = '/profile';
const YOUR_ORDER_PAGE = '/order';
const ORDER_RECEIVED_PAGE = '/order-received';
const OFFER_PAGE = '/offer';
const HELP_PAGE = '/help';
const TERMS_AND_SERVICES_PAGE = '/terms';
const PRIVACY_POLICY_PAGE = '/privacy'; // Mobile Drawer Menus

const HOME_MENU_ITEM = {
  id: 'nav.home',
  defaultMessage: 'Home',
  href: HOME_PAGE
};
const HELP_MENU_ITEM = {
  id: 'nav.help',
  defaultMessage: 'Help',
  href: HELP_PAGE
};
const OFFER_MENU_ITEM = {
  id: 'nav.offer',
  defaultMessage: 'Offer',
  href: OFFER_PAGE
};
const ORDER_MENU_ITEM = {
  id: 'nav.order',
  href: YOUR_ORDER_PAGE,
  defaultMessage: 'Order'
};
const REQUEST_MEDICINE_MENU_ITEM = {
  id: 'nav.request_medicine',
  defaultMessage: 'Request Medicine',
  href: REQUEST_MEDICINE_PAGE
};
const PROFILE_MENU_ITEM = {
  id: 'nav.profile',
  defaultMessage: 'Profile',
  href: PROFILE_PAGE
};
const AUTHORIZED_MENU_ITEMS = [PROFILE_MENU_ITEM, {
  id: 'nav.checkout',
  defaultMessage: 'Checkout',
  href: CHECKOUT_PAGE
}, {
  id: 'alternativeCheckout',
  href: CHECKOUT_PAGE_TWO,
  defaultMessage: 'Checkout Alternative'
}, ORDER_MENU_ITEM, {
  id: 'nav.order_received',
  href: ORDER_RECEIVED_PAGE,
  defaultMessage: 'Order invoice'
}, {
  id: 'nav.terms_and_services',
  defaultMessage: 'Terms and Services',
  href: TERMS_AND_SERVICES_PAGE
}, {
  id: 'nav.privacy_policy',
  defaultMessage: 'Privacy Policy',
  href: PRIVACY_POLICY_PAGE
}]; // category menu items for header navigation

const CATEGORY_MENU_ITEMS = [{
  id: 'nav.grocery',
  href: GROCERY_PAGE,
  defaultMessage: 'Grocery',
  icon: 'FruitsVegetable',
  dynamic: true
}, {
  id: 'nav.grocery-two',
  href: GROCERY_PAGE_TWO,
  defaultMessage: 'Grocery Two',
  icon: 'FruitsVegetable',
  dynamic: false
}, {
  id: 'nav.bakery',
  href: BAKERY_PAGE,
  defaultMessage: 'Bakery',
  icon: 'Bakery',
  dynamic: false
}, {
  id: 'nav.makeup',
  defaultMessage: 'Makeup',
  href: MAKEUP_PAGE,
  icon: 'FacialCare',
  dynamic: true
}, {
  id: 'nav.bags',
  defaultMessage: 'Bags',
  href: BAGS_PAGE,
  icon: 'Handbag',
  dynamic: true
}, {
  id: 'nav.clothing',
  defaultMessage: 'Clothing',
  href: CLOTHING_PAGE,
  icon: 'DressIcon',
  dynamic: true
}, {
  id: 'nav.furniture',
  defaultMessage: 'Furniture',
  href: FURNITURE_PAGE,
  icon: 'FurnitureIcon',
  dynamic: true
}, {
  id: 'nav.furniture-two',
  defaultMessage: 'Furniture Two',
  href: FURNITURE_PAGE_TWO,
  icon: 'FurnitureIcon',
  dynamic: false
}, {
  id: 'nav.book',
  defaultMessage: 'Book',
  href: BOOK_PAGE,
  icon: 'BookIcon',
  dynamic: true
}, {
  id: 'nav.medicine',
  defaultMessage: 'Medicine',
  href: MEDICINE_PAGE,
  icon: 'MedicineIcon',
  dynamic: true
} // {
//   id: 'nav.foods',
//   defaultMessage: 'Foods',
//   href: RESTAURANT_PAGE,
//   icon: 'Restaurant',
// },
];
const MOBILE_DRAWER_MENU = [HOME_MENU_ITEM, ...AUTHORIZED_MENU_ITEMS, HELP_MENU_ITEM, OFFER_MENU_ITEM];
const PROFILE_SIDEBAR_TOP_MENU = [ORDER_MENU_ITEM, HELP_MENU_ITEM];
const PROFILE_SIDEBAR_BOTTOM_MENU = [PROFILE_MENU_ITEM];
const LANGUAGE_MENU = [{
  id: 'ar',
  defaultMessage: 'Arabic',
  icon: 'SAFlag'
}, {
  id: 'zh',
  defaultMessage: 'Chinese',
  icon: 'CNFlag'
}, {
  id: 'en',
  defaultMessage: 'English',
  icon: 'USFlag'
}, {
  id: 'de',
  defaultMessage: 'German',
  icon: 'DEFlag'
}, {
  id: 'he',
  defaultMessage: 'Hebrew',
  icon: 'ILFlag'
}, {
  id: 'es',
  defaultMessage: 'Spanish',
  icon: 'ESFlag'
}];

/***/ }),

/***/ "./src/utils/hooks.tsx":
/*!*****************************!*\
  !*** ./src/utils/hooks.tsx ***!
  \*****************************/
/*! exports provided: usePrevious, useMeasure */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "usePrevious", function() { return usePrevious; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useMeasure", function() { return useMeasure; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var resize_observer_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! resize-observer-polyfill */ "resize-observer-polyfill");
/* harmony import */ var resize_observer_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(resize_observer_polyfill__WEBPACK_IMPORTED_MODULE_1__);


function usePrevious(value) {
  const ref = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => void (ref.current = value), [value]);
  return ref.current;
}
function useMeasure() {
  const ref = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  const {
    0: bounds,
    1: set
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    left: 0,
    top: 0,
    width: 0,
    height: 0
  });
  const {
    0: ro
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(() => new resize_observer_polyfill__WEBPACK_IMPORTED_MODULE_1___default.a(([entry]) => set(entry.contentRect)));
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (ref.current) ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  return [{
    ref
  }, bounds];
}

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L2xpbmsudHN4Iiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoLnRzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvcmVxdWVzdC1pZGxlLWNhbGxiYWNrLnRzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvcm91dGUtbG9hZGVyLnRzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvcm91dGVyLnRzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvdXNlLWludGVyc2VjdGlvbi50c3giLCJ3ZWJwYWNrOi8vLy4uLy4uL2NsaWVudC93aXRoLXJvdXRlci50c3giLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9pMThuL25vcm1hbGl6ZS1sb2NhbGUtcGF0aC50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL21pdHQudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvcm91dGVyLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2Zvcm1hdC11cmwudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvaXMtZHluYW1pYy50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmwudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcXVlcnlzdHJpbmcudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcmVzb2x2ZS1yZXdyaXRlcy1ub29wLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXgudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi91dGlscy50cyIsIndlYnBhY2s6Ly8vRDovbGFyYXZlbCBwcm9qZWN0cy9uZXcgd2Vic2l0ZS91cGRhdGUvUGlja2JhemFyIC0gUmVhY3QgR3JhcGhRTCBFY29tbWVyY2UgVGVtcGxhdGUvcGlja2JhemFyL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aC5qcyIsIndlYnBhY2s6Ly8vRDovbGFyYXZlbCBwcm9qZWN0cy9uZXcgd2Vic2l0ZS91cGRhdGUvUGlja2JhemFyIC0gUmVhY3QgR3JhcGhRTCBFY29tbWVyY2UgVGVtcGxhdGUvcGlja2JhemFyL25vZGVfbW9kdWxlcy9uZXh0L2xpbmsuanMiLCJ3ZWJwYWNrOi8vL0Q6L2xhcmF2ZWwgcHJvamVjdHMvbmV3IHdlYnNpdGUvdXBkYXRlL1BpY2tiYXphciAtIFJlYWN0IEdyYXBoUUwgRWNvbW1lcmNlIFRlbXBsYXRlL3BpY2tiYXphci9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vL0Q6L2xhcmF2ZWwgcHJvamVjdHMvbmV3IHdlYnNpdGUvdXBkYXRlL1BpY2tiYXphciAtIFJlYWN0IEdyYXBoUUwgRWNvbW1lcmNlIFRlbXBsYXRlL3BpY2tiYXphci9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkLmpzIiwid2VicGFjazovLy9EOi9sYXJhdmVsIHByb2plY3RzL25ldyB3ZWJzaXRlL3VwZGF0ZS9QaWNrYmF6YXIgLSBSZWFjdCBHcmFwaFFMIEVjb21tZXJjZSBUZW1wbGF0ZS9waWNrYmF6YXIvbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvdHlwZW9mLmpzIiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvQWNjZXNzb3JpZXMudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvQmF0aE9pbC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9CZWF1dHlIZWFsdGgudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvQmV2ZXJhZ2UudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvQnJlYWtmYXN0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0Nsb3NlSWNvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9Db29raW5nLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0RhaXJ5LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0Rlb2RvcmFudC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9FeWVzLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0ZhY2UudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvRmFjaWFsQ2FyZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9GcnVpdHNWZWdldGFibGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvSGFuZEJhZ3MudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvSG9tZUNsZWFuaW5nLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0xhcHRvcEJhZ3MudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvTGlwcy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9NZWF0RmlzaC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9NaW51cy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9PcmFsQ2FyZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9PdXRlcldlYXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvUGFudHMudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvUGV0Q2FyZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9QdXJzZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9TaGF2aW5nTmVlZHMudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvU2hpcnRzLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1Nob3VsZGVyQmFncy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9Ta2lydHMudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvU25hY2tzLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1RvcHMudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvV2FsbGV0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1dvbWVuRHJlc3MudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnktaWNvbnMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9iZWQudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvYm9vay1zaGVsZi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9jZW50ZXItdGFibGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvY2hhaXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvZHJlc3NpbmctdGFibGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvcmVhZGluZy10YWJsZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9yZWxheC1jaGFpci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9zb2ZhLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL2NhdGVnb3J5L3N0b3JhZ2UudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvdGFibGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9hc3NldHMvaWNvbnMvY2F0ZWdvcnkvdG9vbHMudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NhdGVnb3J5LXdhbGtlci9jYXRlZ29yeS13YWxrZXIuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NhdGVnb3J5LXdhbGtlci9jYXRlZ29yeS13YWxrZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3BsYWNlaG9sZGVyL3BsYWNlaG9sZGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9zY3JvbGxiYXIvc2Nyb2xsYmFyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9zcHJpbmctbW9kYWwvc3ByaW5nLW1vZGFsLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy90cmVlLW1lbnUvdHJlZS1tZW51LnN0eWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy90cmVlLW1lbnUvdHJlZS1tZW51LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvbGF5b3V0cy9zaWRlYmFyL3NpZGViYXIuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9sYXlvdXRzL3NpZGViYXIvc2lkZWJhci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3NpdGUtc2V0dGluZ3Mvc2l0ZS1uYXZpZ2F0aW9uLnRzIiwid2VicGFjazovLy8uL3NyYy91dGlscy9ob29rcy50c3giXSwibmFtZXMiOlsicHJlZmV0Y2hlZCIsInJvdXRlciIsImVyciIsImN1ckxvY2FsZSIsIm9wdGlvbnMiLCJocmVmIiwiZXZlbnQiLCJ0YXJnZXQiLCJlIiwibm9kZU5hbWUiLCJpc01vZGlmaWVkRXZlbnQiLCJzY3JvbGwiLCJhcyIsInJlcGxhY2UiLCJhcmdzIiwia2V5IiwiZXhwZWN0ZWQiLCJhY3R1YWwiLCJyZXF1aXJlZFByb3BzR3VhcmQiLCJyZXF1aXJlZFByb3BzIiwiT2JqZWN0IiwicHJvcHMiLCJjcmVhdGVQcm9wRXJyb3IiLCJfIiwib3B0aW9uYWxQcm9wc0d1YXJkIiwic2hhbGxvdyIsInBhc3NIcmVmIiwicHJlZmV0Y2giLCJsb2NhbGUiLCJvcHRpb25hbFByb3BzIiwidmFsVHlwZSIsImhhc1dhcm5lZCIsIlJlYWN0IiwiY29uc29sZSIsInAiLCJwYXRobmFtZSIsInJlc29sdmVkQXMiLCJjaGlsZHJlbiIsImNoaWxkIiwiQ2hpbGRyZW4iLCJjaGlsZFJlZiIsInJvb3RNYXJnaW4iLCJzZXRSZWYiLCJlbCIsInNldEludGVyc2VjdGlvblJlZiIsInNob3VsZFByZWZldGNoIiwiaXNWaXNpYmxlIiwiaXNQcmVmZXRjaGVkIiwiY2hpbGRQcm9wcyIsInJlZiIsIm9uQ2xpY2siLCJsaW5rQ2xpY2tlZCIsInByaW9yaXR5IiwibG9jYWxlRG9tYWluIiwiTGluayIsInBhdGgiLCJub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCIsInByb2Nlc3MiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwic2VsZiIsInN0YXJ0IiwiRGF0ZSIsInNldFRpbWVvdXQiLCJjYiIsImRpZFRpbWVvdXQiLCJ0aW1lUmVtYWluaW5nIiwiTWF0aCIsImNhbmNlbElkbGVDYWxsYmFjayIsImNsZWFyVGltZW91dCIsIk1TX01BWF9JRExFX0RFTEFZIiwiZW50cnkiLCJtYXAiLCJQcm9taXNlIiwicHJvbSIsInJlc29sdmUiLCJyZXNvbHZlciIsImZ1dHVyZSIsImdlbmVyYXRvciIsInZhbHVlIiwibGluayIsImRvY3VtZW50Iiwid2luZG93IiwiY2FuUHJlZmV0Y2giLCJoYXNQcmVmZXRjaCIsInJlcyIsIkFTU0VUX0xPQURfRVJST1IiLCJTeW1ib2wiLCJzY3JpcHQiLCJyZWplY3QiLCJtYXJrQXNzZXRFcnJvciIsInNyYyIsImNhbmNlbGxlZCIsInIiLCJvbkJ1aWxkTWFuaWZlc3QiLCJyZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0Iiwic2NyaXB0cyIsImFzc2V0UHJlZml4IiwiZW5jb2RlVVJJIiwiY3NzIiwiZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCIsIm1hbmlmZXN0Iiwicm91dGUiLCJhbGxGaWxlcyIsInYiLCJlbnRyeXBvaW50cyIsImxvYWRlZFNjcmlwdHMiLCJzdHlsZVNoZWV0cyIsInJvdXRlcyIsImFwcGVuZFNjcmlwdCIsImZldGNoIiwidGV4dCIsImNvbnRlbnQiLCJ3aGVuRW50cnlwb2ludCIsIndpdGhGdXR1cmUiLCJvbkVudHJ5cG9pbnQiLCJmbiIsImV4cG9ydHMiLCJjb21wb25lbnQiLCJlcnJvciIsImlucHV0Iiwib2xkIiwibG9hZFJvdXRlIiwiZ2V0RmlsZXNGb3JSb3V0ZSIsImVudHJ5cG9pbnQiLCJjbiIsIm5hdmlnYXRvciIsIm91dHB1dCIsInByZWZldGNoVmlhRG9tIiwiY3JlYXRlUm91dGVMb2FkZXIiLCJzaW5nbGV0b25Sb3V0ZXIiLCJyZWFkeUNhbGxiYWNrcyIsInJlYWR5IiwidXJsUHJvcGVydHlGaWVsZHMiLCJyb3V0ZXJFdmVudHMiLCJjb3JlTWV0aG9kRmllbGRzIiwiZ2V0IiwiUm91dGVyIiwiZmllbGQiLCJnZXRSb3V0ZXIiLCJldmVudEZpZWxkIiwiX3NpbmdsZXRvblJvdXRlciIsIm1lc3NhZ2UiLCJzdGFjayIsIlJvdXRlckNvbnRleHQiLCJjcmVhdGVSb3V0ZXIiLCJfcm91dGVyIiwiaW5zdGFuY2UiLCJBcnJheSIsImhhc0ludGVyc2VjdGlvbk9ic2VydmVyIiwiaXNEaXNhYmxlZCIsImRpc2FibGVkIiwidW5vYnNlcnZlIiwib2JzZXJ2ZSIsInNldFZpc2libGUiLCJpZGxlQ2FsbGJhY2siLCJjcmVhdGVPYnNlcnZlciIsImVsZW1lbnRzIiwib2JzZXJ2ZXIiLCJvYnNlcnZlcnMiLCJpZCIsImVudHJpZXMiLCJjYWxsYmFjayIsIkNvbXBvc2VkQ29tcG9uZW50IiwiZ2V0SW5pdGlhbFByb3BzIiwiV2l0aFJvdXRlcldyYXBwZXIiLCJuYW1lIiwicGF0aG5hbWVQYXJ0cyIsImxvY2FsZXMiLCJkZXRlY3RlZExvY2FsZSIsImFsbCIsIm9uIiwib2ZmIiwiZW1pdCIsImhhbmRsZXIiLCJiYXNlUGF0aCIsInByZWZpeCIsInBhdGhOb1F1ZXJ5SGFzaCIsInF1ZXJ5SW5kZXgiLCJoYXNoSW5kZXgiLCJhZGRQYXRoUHJlZml4IiwidXJsIiwibG9jYXRpb25PcmlnaW4iLCJyZXNvbHZlZCIsImhhc0Jhc2VQYXRoIiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJkeW5hbWljR3JvdXBzIiwiZHluYW1pY01hdGNoZXMiLCJhc1BhdGhuYW1lIiwicGFyYW1zIiwicGFyYW0iLCJyZXBsYWNlZCIsInJlcGVhdCIsIm9wdGlvbmFsIiwic2VnbWVudCIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlc3VsdCIsImZpbHRlcmVkUXVlcnkiLCJxdWVyeSIsImJhc2UiLCJ1cmxBc1N0cmluZyIsImlzTG9jYWxVUkwiLCJyZXNvbHZlQXMiLCJmaW5hbFVybCIsImludGVycG9sYXRlZEFzIiwiaW50ZXJwb2xhdGVBcyIsImhhc2giLCJvbWl0UGFybXNGcm9tUXVlcnkiLCJyZXNvbHZlZEhyZWYiLCJvcmlnaW4iLCJyZXNvbHZlSHJlZiIsImhyZWZIYWRPcmlnaW4iLCJhc0hhZE9yaWdpbiIsInN0cmlwT3JpZ2luIiwicHJlcGFyZWRVcmwiLCJhZGRCYXNlUGF0aCIsInByZXBhcmVkQXMiLCJjbGVhblBhdGhuYW1lIiwicGFnZXMiLCJwYWdlIiwibWFudWFsU2Nyb2xsUmVzdG9yYXRpb24iLCJTU0dfREFUQV9OT1RfRk9VTkQiLCJjcmVkZW50aWFscyIsImF0dGVtcHRzIiwiZmV0Y2hSZXRyeSIsImRhdGEiLCJub3RGb3VuZCIsImlzU2VydmVyUmVuZGVyIiwiY29uc3RydWN0b3IiLCJhc1BhdGgiLCJjb21wb25lbnRzIiwic2RjIiwic2RyIiwic3ViIiwiY2xjIiwicGFnZUxvYWRlciIsIl9icHMiLCJldmVudHMiLCJfd3JhcEFwcCIsImlzU3NyIiwiaXNGYWxsYmFjayIsIl9pbkZsaWdodFJvdXRlIiwiX3NoYWxsb3ciLCJkZWZhdWx0TG9jYWxlIiwiZG9tYWluTG9jYWxlcyIsImlzUmVhZHkiLCJpc1ByZXZpZXciLCJpc0xvY2FsZURvbWFpbiIsIl9pZHgiLCJzdGF0ZSIsImluaXRpYWwiLCJfX05fU1NHIiwiaW5pdGlhbFByb3BzIiwiX19OX1NTUCIsIkNvbXBvbmVudCIsImF1dG9FeHBvcnREeW5hbWljIiwicmVsb2FkIiwiYmFjayIsInB1c2giLCJwcmVwYXJlVXJsQXMiLCJsb2NhbGVDaGFuZ2UiLCJTVCIsInBlcmZvcm1hbmNlIiwicm91dGVQcm9wcyIsImFkZExvY2FsZSIsImRlbEJhc2VQYXRoIiwiY2xlYW5lZEFzIiwiZGVsTG9jYWxlIiwicGFyc2VkIiwiX19yZXdyaXRlcyIsIm1ldGhvZCIsInJlc29sdmVEeW5hbWljUm91dGUiLCJwYXJzZWRBcyIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwicm91dGVJbmZvIiwiZGVzdGluYXRpb24iLCJwYXJzZWRIcmVmIiwibm90Rm91bmRSb3V0ZSIsImFwcENvbXAiLCJpc1ZhbGlkU2hhbGxvd1JvdXRlIiwiZm9yY2VkU2Nyb2xsIiwieCIsInkiLCJjaGFuZ2VTdGF0ZSIsIl9fTiIsImlkeCIsImJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IiLCJleGlzdGluZ1JvdXRlSW5mbyIsImNhY2hlZFJvdXRlSW5mbyIsInJlcXVpcmUiLCJpc1ZhbGlkRWxlbWVudFR5cGUiLCJkYXRhSHJlZiIsInNldCIsImJlZm9yZVBvcFN0YXRlIiwib25seUFIYXNoQ2hhbmdlIiwibmV3SGFzaCIsIm9sZFVybE5vSGFzaCIsIm9sZEhhc2giLCJzY3JvbGxUb0hhc2giLCJpZEVsIiwibmFtZUVsIiwidXJsSXNOZXciLCJpc1NzZyIsImNhbmNlbCIsImNvbXBvbmVudFJlc3VsdCIsIl9nZXREYXRhIiwiX2dldFN0YXRpY0RhdGEiLCJmZXRjaE5leHREYXRhIiwiX2dldFNlcnZlckRhdGEiLCJBcHBUcmVlIiwiY3R4IiwiYWJvcnRDb21wb25lbnRMb2FkIiwibm90aWZ5Iiwic2xhc2hlZFByb3RvY29scyIsInByb3RvY29sIiwidXJsT2JqIiwiaG9zdCIsImF1dGgiLCJob3N0bmFtZSIsIlN0cmluZyIsInF1ZXJ5c3RyaW5nIiwic2VhcmNoIiwiVEVTVF9ST1VURSIsImdsb2JhbEJhc2UiLCJyZXNvbHZlZEJhc2UiLCJzZWFyY2hQYXJhbXMiLCJpc05hTiIsIml0ZW0iLCJzdHJpbmdpZnlVcmxRdWVyeVBhcmFtIiwic2VhcmNoUGFyYW1zTGlzdCIsInJlIiwiZGVjb2RlIiwiZGVjb2RlVVJJQ29tcG9uZW50Iiwic2x1Z05hbWUiLCJnIiwiZ3JvdXBzIiwibSIsInN0ciIsInNlZ21lbnRzIiwibm9ybWFsaXplZFJvdXRlIiwiZ3JvdXBJbmRleCIsInBhcmFtZXRlcml6ZWRSb3V0ZSIsInBhcnNlUGFyYW1ldGVyIiwicG9zIiwiZXNjYXBlUmVnZXgiLCJyb3V0ZUtleUNoYXJDb2RlIiwicm91dGVLZXlDaGFyTGVuZ3RoIiwiZ2V0U2FmZVJvdXRlS2V5Iiwicm91dGVLZXkiLCJpIiwicm91dGVLZXlzIiwibmFtZWRQYXJhbWV0ZXJpemVkUm91dGUiLCJjbGVhbmVkS2V5IiwiaW52YWxpZEtleSIsInBhcnNlSW50IiwibmFtZWRSZWdleCIsInVzZWQiLCJwb3J0IiwiZ2V0TG9jYXRpb25PcmlnaW4iLCJBcHAiLCJnZXREaXNwbGF5TmFtZSIsInBhZ2VQcm9wcyIsImxvYWRHZXRJbml0aWFsUHJvcHMiLCJpc1Jlc1NlbnQiLCJ1cmxPYmplY3RLZXlzIiwiU1AiLCJBY2Nlc3NvcmllcyIsImNvbG9yIiwid2lkdGgiLCJoZWlnaHQiLCJCYXRoT2lsIiwiQmVhdXR5SGVhbHRoIiwiQmV2ZXJhZ2UiLCJCcmVha2Zhc3QiLCJDbG9zZUljb24iLCJDb29raW5nIiwiRGFpcnkiLCJEZW9kb3JhbnQiLCJFeWVzIiwiRmFjZSIsIkZhY2lhbENhcmUiLCJGcnVpdHNWZWdldGFibGUiLCJIYW5kQmFncyIsIkhvbWVDbGVhbmluZyIsIkxhcHRvcEJhZ3MiLCJMaXBzIiwiTWVhdEZpc2giLCJNaW51cyIsIk9yYWxDYXJlIiwiT3V0ZXJXZWFyIiwiUGFudHMiLCJQZXRDYXJlIiwiUHVyc2UiLCJTaGF2aW5nTmVlZHMiLCJTaGlydHMiLCJTaG91bGRlckJhZ3MiLCJTa2lydHMiLCJTbmFja3MiLCJUb3BzIiwiV2FsbGV0IiwiV29tZW5EcmVzcyIsIkJlZCIsIkJvb2tzaGVsZiIsIkNlbnRlclRhYmxlIiwiQ2hhaXIiLCJEcmVzc2luZ1RhYmxlIiwiUmVhZGluZ1RhYmxlIiwiUmVsYXhDaGFpciIsIlNvZmEiLCJTdG9yYWdlIiwiVGFibGUiLCJUb29scyIsIldhbGtlcldyYXBwZXIiLCJzdHlsZWQiLCJkaXYiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwicGFkZGluZyIsImJ1dHRvbiIsIkNhdGVnb3J5V3JhcHBlciIsIkNhdGVnb3J5Iiwic3BhbiIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlclJhZGl1cyIsIk5vQ2F0ZWdvcnkiLCJJY29uV3JhcHBlciIsIkNhdGVnb3J5V2Fsa2VyIiwic3R5bGUiLCJjbGFzc05hbWUiLCJpc09wZW4iLCJzZXRPcGVuIiwidXNlU3RhdGUiLCJ1c2VSb3V0ZXIiLCJjYXRlZ29yeSIsInN0YXJ0Q2FzZSIsIlBvc3RMb2FkZXIiLCJTaWRlYmFyTW9iaWxlTG9hZGVyIiwiU2lkZWJhckxvYWRlciIsIlNjcm9sbGJhciIsInNjcm9sbGJhcnMiLCJhdXRvSGlkZSIsIlNwcmluZ01vZGFsIiwib25SZXF1ZXN0Q2xvc2UiLCJ0cmFuc2l0aW9uIiwidXNlVHJhbnNpdGlvbiIsImZyb20iLCJ0cmFuc2Zvcm0iLCJlbnRlciIsImxlYXZlIiwic3RhdGljU3R5bGVzIiwicG9zaXRpb24iLCJib3R0b20iLCJsZWZ0IiwibWF4SGVpZ2h0IiwiYm9yZGVyVG9wTGVmdFJhZGl1cyIsImJvcmRlclRvcFJpZ2h0UmFkaXVzIiwiekluZGV4IiwiYnV0dG9uU3R5bGUiLCJib3JkZXIiLCJvdXRsaW5lIiwiYm94U2hhZG93IiwidG9wIiwiY3Vyc29yIiwic2Nyb2xsYmFyU3R5bGUiLCJ0cmFuc2l0aW9uU3R5bGVzIiwiSGVhZGVyIiwiaGVhZGVyIiwiZGVwdGgiLCJtYXJnaW5Cb3R0b20iLCJvcGVuIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0Iiwic3ZnIiwibWF4V2lkdGgiLCJvdmVyZmxvdyIsImZsZXhTaHJpbmsiLCJUaXRsZSIsInRleHRPdmVyZmxvdyIsIndoaXRlU3BhY2UiLCJ2ZXJ0aWNhbEFsaWduIiwiQ29udGVudCIsImFuaW1hdGVkIiwid2lsbENoYW5nZSIsImJvcmRlckxlZnQiLCJGcmFtZSIsInBhZGRpbmdMZWZ0Iiwib3ZlcmZsb3dYIiwiVHJlZSIsIm1lbW8iLCJpY29uIiwiZHJvcGRvd24iLCJvblRvZ2dsZUJ0bkNsaWNrIiwiZGVmYXVsdE9wZW4iLCJ1c2VFZmZlY3QiLCJwcmV2aW91cyIsInVzZVByZXZpb3VzIiwiYmluZCIsInZpZXdIZWlnaHQiLCJ1c2VNZWFzdXJlIiwib3BhY2l0eSIsInVzZVNwcmluZyIsInRvIiwiSWNvbiIsImljb25OYW1lIiwiVGFnTmFtZSIsImljb25zIiwiVHJlZU1lbnUiLCJhY3RpdmUiLCJzdWJPcHRpb24iLCJ0aXRsZSIsInNsdWciLCJsZW5ndGgiLCJzb21lIiwiRmFkZSIsImtleWZyYW1lcyIsIlBvcG92ZXJXcmFwcGVyIiwidGhlbWVHZXQiLCJSZXF1ZXN0TWVkaWNpbmUiLCJTaWRlYmFyV3JhcHBlciIsIlRyZWVXcmFwcGVyIiwiUG9wb3ZlckhhbmRsZXIiLCJMb2FkaW5nIiwiU2lkZWJhckNhdGVnb3J5IiwiZGV2aWNlVHlwZSIsIm1vYmlsZSIsInRhYmxldCIsImRlc2t0b3AiLCJ0eXBlIiwibG9hZGluZyIsInVzZVF1ZXJ5IiwiR0VUX0NBVEVHT1JJRVMiLCJ2YXJpYWJsZXMiLCJzZWxlY3RlZFF1ZXJpZXMiLCJvbkNhdGVnb3J5Q2xpY2siLCJyZXN0IiwiaXNTaWRlYmFyU3RpY2t5IiwidXNlQXBwU3RhdGUiLCJSRVFVRVNUX01FRElDSU5FX01FTlVfSVRFTSIsImRlZmF1bHRNZXNzYWdlIiwiY2F0ZWdvcmllcyIsInBhZGRpbmdUb3AiLCJIT01FX1BBR0UiLCJHUk9DRVJZX1BBR0UiLCJHUk9DRVJZX1BBR0VfVFdPIiwiQkFLRVJZX1BBR0UiLCJNQUtFVVBfUEFHRSIsIkNMT1RISU5HX1BBR0UiLCJCQUdTX1BBR0UiLCJCT09LX1BBR0UiLCJGVVJOSVRVUkVfUEFHRSIsIkZVUk5JVFVSRV9QQUdFX1RXTyIsIk1FRElDSU5FX1BBR0UiLCJSRVFVRVNUX01FRElDSU5FX1BBR0UiLCJDSEVDS09VVF9QQUdFIiwiQ0hFQ0tPVVRfUEFHRV9UV08iLCJQUk9GSUxFX1BBR0UiLCJZT1VSX09SREVSX1BBR0UiLCJPUkRFUl9SRUNFSVZFRF9QQUdFIiwiT0ZGRVJfUEFHRSIsIkhFTFBfUEFHRSIsIlRFUk1TX0FORF9TRVJWSUNFU19QQUdFIiwiUFJJVkFDWV9QT0xJQ1lfUEFHRSIsIkhPTUVfTUVOVV9JVEVNIiwiSEVMUF9NRU5VX0lURU0iLCJPRkZFUl9NRU5VX0lURU0iLCJPUkRFUl9NRU5VX0lURU0iLCJQUk9GSUxFX01FTlVfSVRFTSIsIkFVVEhPUklaRURfTUVOVV9JVEVNUyIsIkNBVEVHT1JZX01FTlVfSVRFTVMiLCJkeW5hbWljIiwiTU9CSUxFX0RSQVdFUl9NRU5VIiwiUFJPRklMRV9TSURFQkFSX1RPUF9NRU5VIiwiUFJPRklMRV9TSURFQkFSX0JPVFRPTV9NRU5VIiwiTEFOR1VBR0VfTUVOVSIsInVzZVJlZiIsImN1cnJlbnQiLCJib3VuZHMiLCJybyIsIlJlc2l6ZU9ic2VydmVyIiwiY29udGVudFJlY3QiLCJkaXNjb25uZWN0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFFQTs7QUFTQTs7QUFDQTs7QUF1QkEsTUFBTUEsVUFBMkMsR0FBakQ7O0FBRUEsNkNBS1E7QUFDTixNQUFJLElBQUosRUFBOEM7QUFDOUMsTUFBSSxDQUFDLHdCQUFMLElBQUssQ0FBTCxFQUF1QixPQUZqQixDQUdOO0FBQ0E7QUFDQTtBQUNBOztBQUNBQyxRQUFNLENBQU5BLGtDQUEwQ0MsR0FBRCxJQUFTO0FBQ2hELGNBQTJDO0FBQ3pDO0FBQ0E7QUFFSDtBQUxERDtBQU1BLFFBQU1FLFNBQVMsR0FDYkMsT0FBTyxJQUFJLE9BQU9BLE9BQU8sQ0FBZCxXQUFYQSxjQUNJQSxPQUFPLENBRFhBLFNBRUlILE1BQU0sSUFBSUEsTUFBTSxDQUh0QixPQWJNLENBa0JOOztBQUNBRCxZQUFVLENBQUNLLElBQUksR0FBSkEsWUFBbUJGLFNBQVMsR0FBRyxNQUFILFlBQXZDSCxFQUFXSyxDQUFELENBQVZMO0FBR0Y7O0FBQUEsZ0NBQTJEO0FBQ3pELFFBQU07QUFBQTtBQUFBLE1BQWFNLEtBQUssQ0FBeEI7QUFDQSxTQUNHQyxNQUFNLElBQUlBLE1BQU0sS0FBakIsT0FBQ0EsSUFDREQsS0FBSyxDQURMLE9BQUNDLElBRURELEtBQUssQ0FGTCxPQUFDQyxJQUdERCxLQUFLLENBSEwsUUFBQ0MsSUFJREQsS0FBSyxDQUpMLE1BQUNDLElBSWU7QUFDZkQsT0FBSyxDQUFMQSxlQUFxQkEsS0FBSyxDQUFMQSxzQkFOeEI7QUFVRjs7QUFBQSw0RUFTUTtBQUNOLFFBQU07QUFBQTtBQUFBLE1BQWVFLENBQUMsQ0FBdEI7O0FBRUEsTUFBSUMsUUFBUSxLQUFSQSxRQUFxQkMsZUFBZSxDQUFmQSxDQUFlLENBQWZBLElBQXNCLENBQUMsd0JBQWhELElBQWdELENBQTVDRCxDQUFKLEVBQW1FO0FBQ2pFO0FBQ0E7QUFHRkQ7O0FBQUFBLEdBQUMsQ0FBREEsaUJBUk0sQ0FVTjs7QUFDQSxNQUFJRyxNQUFNLElBQVYsTUFBb0I7QUFDbEJBLFVBQU0sR0FBR0MsRUFBRSxDQUFGQSxlQUFURDtBQUdGLEdBZk0sQ0FlTjs7O0FBQ0FWLFFBQU0sQ0FBQ1ksT0FBTyxlQUFkWixNQUFNLENBQU5BLFdBQStDO0FBQUE7QUFBQTtBQUEvQ0E7QUFBK0MsR0FBL0NBO0FBT0Y7O0FBQUEscUJBQXlEO0FBQ3ZELFlBQTJDO0FBQ3pDLG1DQUlHO0FBQ0QsYUFBTyxVQUNKLGdDQUErQmEsSUFBSSxDQUFDQyxHQUFJLGdCQUFlRCxJQUFJLENBQUNFLFFBQVMsNkJBQTRCRixJQUFJLENBQUNHLE1BQXZHLGFBQUMsSUFDRSxvQkFGTCxFQUNHLENBREksQ0FBUDtBQVFGLEtBZHlDLENBY3pDOzs7QUFDQSxVQUFNQyxrQkFBbUQsR0FBRztBQUMxRGIsVUFBSSxFQUROO0FBQTRELEtBQTVEO0FBR0EsVUFBTWMsYUFBa0MsR0FBR0MsTUFBTSxDQUFOQSxLQUEzQyxrQkFBMkNBLENBQTNDO0FBR0EsaUJBQWEsQ0FBYixRQUF1QkwsR0FBRCxJQUE0QjtBQUNoRCxVQUFJQSxHQUFHLEtBQVAsUUFBb0I7QUFDbEIsWUFDRU0sS0FBSyxDQUFMQSxHQUFLLENBQUxBLFlBQ0MsT0FBT0EsS0FBSyxDQUFaLEdBQVksQ0FBWixpQkFBa0MsT0FBT0EsS0FBSyxDQUFaLEdBQVksQ0FBWixLQUZyQyxVQUdFO0FBQ0EsZ0JBQU1DLGVBQWUsQ0FBQztBQUFBO0FBRXBCTixvQkFBUSxFQUZZO0FBR3BCQyxrQkFBTSxFQUFFSSxLQUFLLENBQUxBLEdBQUssQ0FBTEEscUJBQStCLE9BQU9BLEtBQUssQ0FIckQsR0FHcUQ7QUFIL0IsV0FBRCxDQUFyQjtBQU1IO0FBWEQsYUFXTztBQUNMO0FBQ0E7QUFDQSxjQUFNRSxDQUFRLEdBQWQ7QUFFSDtBQWpCRCxPQXJCeUMsQ0F3Q3pDOztBQUNBLFVBQU1DLGtCQUFtRCxHQUFHO0FBQzFEWixRQUFFLEVBRHdEO0FBRTFEQyxhQUFPLEVBRm1EO0FBRzFERixZQUFNLEVBSG9EO0FBSTFEYyxhQUFPLEVBSm1EO0FBSzFEQyxjQUFRLEVBTGtEO0FBTTFEQyxjQUFRLEVBTmtEO0FBTzFEQyxZQUFNLEVBUFI7QUFBNEQsS0FBNUQ7QUFTQSxVQUFNQyxhQUFrQyxHQUFHVCxNQUFNLENBQU5BLEtBQTNDLGtCQUEyQ0EsQ0FBM0M7QUFHQSxpQkFBYSxDQUFiLFFBQXVCTCxHQUFELElBQTRCO0FBQ2hELFlBQU1lLE9BQU8sR0FBRyxPQUFPVCxLQUFLLENBQTVCLEdBQTRCLENBQTVCOztBQUVBLFVBQUlOLEdBQUcsS0FBUCxNQUFrQjtBQUNoQixZQUFJTSxLQUFLLENBQUxBLEdBQUssQ0FBTEEsSUFBY1MsT0FBTyxLQUFyQlQsWUFBc0NTLE9BQU8sS0FBakQsVUFBZ0U7QUFDOUQsZ0JBQU1SLGVBQWUsQ0FBQztBQUFBO0FBRXBCTixvQkFBUSxFQUZZO0FBR3BCQyxrQkFBTSxFQUhSO0FBQXNCLFdBQUQsQ0FBckI7QUFNSDtBQVJELGFBUU8sSUFBSUYsR0FBRyxLQUFQLFVBQXNCO0FBQzNCLFlBQUlNLEtBQUssQ0FBTEEsR0FBSyxDQUFMQSxJQUFjUyxPQUFPLEtBQXpCLFVBQXdDO0FBQ3RDLGdCQUFNUixlQUFlLENBQUM7QUFBQTtBQUVwQk4sb0JBQVEsRUFGWTtBQUdwQkMsa0JBQU0sRUFIUjtBQUFzQixXQUFELENBQXJCO0FBTUg7QUFSTSxhQVFBLElBQ0xGLEdBQUcsS0FBSEEsYUFDQUEsR0FBRyxLQURIQSxZQUVBQSxHQUFHLEtBRkhBLGFBR0FBLEdBQUcsS0FISEEsY0FJQUEsR0FBRyxLQUxFLFlBTUw7QUFDQSxZQUFJTSxLQUFLLENBQUxBLEdBQUssQ0FBTEEsWUFBc0JTLE9BQU8sS0FBakMsV0FBaUQ7QUFDL0MsZ0JBQU1SLGVBQWUsQ0FBQztBQUFBO0FBRXBCTixvQkFBUSxFQUZZO0FBR3BCQyxrQkFBTSxFQUhSO0FBQXNCLFdBQUQsQ0FBckI7QUFNSDtBQWRNLGFBY0E7QUFDTDtBQUNBO0FBQ0EsY0FBTU0sQ0FBUSxHQUFkO0FBRUg7QUF0Q0QsT0FyRHlDLENBNkZ6QztBQUNBOztBQUNBLFVBQU1RLFNBQVMsR0FBR0Msc0JBQWxCLEtBQWtCQSxDQUFsQjs7QUFDQSxRQUFJWCxLQUFLLENBQUxBLFlBQWtCLENBQUNVLFNBQVMsQ0FBaEMsU0FBMEM7QUFDeENBLGVBQVMsQ0FBVEE7QUFDQUUsYUFBTyxDQUFQQTtBQUlIO0FBQ0Q7O0FBQUEsUUFBTUMsQ0FBQyxHQUFHYixLQUFLLENBQUxBLGFBQVY7QUFFQSxRQUFNcEIsTUFBTSxHQUFHLGFBQWYsU0FBZSxHQUFmO0FBQ0EsUUFBTWtDLFFBQVEsR0FBSWxDLE1BQU0sSUFBSUEsTUFBTSxDQUFqQixRQUFDQSxJQUFsQjs7QUFFQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQWUrQix1QkFBYyxNQUFNO0FBQ3ZDLFVBQU0sNkJBQTZCLG1DQUFzQlgsS0FBSyxDQUEzQixNQUFuQyxJQUFtQyxDQUFuQztBQUNBLFdBQU87QUFDTGhCLFVBQUksRUFEQztBQUVMTyxRQUFFLEVBQUVTLEtBQUssQ0FBTEEsS0FDQSxtQ0FBc0JBLEtBQUssQ0FEM0JBLEVBQ0EsQ0FEQUEsR0FFQWUsVUFBVSxJQUpoQjtBQUFPLEtBQVA7QUFGbUJKLEtBUWxCLFdBQVdYLEtBQUssQ0FBaEIsTUFBdUJBLEtBQUssQ0FSL0IsRUFRRyxDQVJrQlcsQ0FBckI7O0FBVUEsTUFBSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFKLE1Bdkh1RCxDQXlIdkQ7O0FBQ0EsTUFBSSxvQkFBSixVQUFrQztBQUNoQ0ssWUFBUSxnQkFBRyx3Q0FBWEEsUUFBVyxDQUFYQTtBQUdGLEdBOUh1RCxDQThIdkQ7OztBQUNBLFFBQU1DLEtBQVUsR0FBR0MscUJBQW5CLFFBQW1CQSxDQUFuQjs7QUFDQSxRQUFNQyxRQUFhLEdBQUdGLEtBQUssSUFBSSxpQkFBVEEsWUFBc0NBLEtBQUssQ0FBakU7QUFFQSxRQUFNLGtDQUFrQyxzQ0FBZ0I7QUFDdERHLGNBQVUsRUFEWjtBQUF3RCxHQUFoQixDQUF4Qzs7QUFHQSxRQUFNQyxNQUFNLEdBQUdWLDJCQUNaVyxFQUFELElBQWlCO0FBQ2ZDLHNCQUFrQixDQUFsQkEsRUFBa0IsQ0FBbEJBOztBQUNBLGtCQUFjO0FBQ1osVUFBSSxvQkFBSixZQUFvQ0osUUFBUSxDQUE1QyxFQUE0QyxDQUFSQSxDQUFwQyxLQUNLLElBQUksb0JBQUosVUFBa0M7QUFDckNBLGdCQUFRLENBQVJBO0FBRUg7QUFDRjtBQVRZUixLQVViLFdBVkYsa0JBVUUsQ0FWYUEsQ0FBZjs7QUFZQSx3QkFBVSxNQUFNO0FBQ2QsVUFBTWEsY0FBYyxHQUFHQyxTQUFTLElBQVRBLEtBQWtCLHdCQUF6QyxJQUF5QyxDQUF6QztBQUNBLFVBQU0zQyxTQUFTLEdBQ2IseUNBQXlDRixNQUFNLElBQUlBLE1BQU0sQ0FEM0Q7QUFFQSxVQUFNOEMsWUFBWSxHQUNoQi9DLFVBQVUsQ0FBQ0ssSUFBSSxHQUFKQSxZQUFtQkYsU0FBUyxHQUFHLE1BQUgsWUFEekMsRUFDYUUsQ0FBRCxDQURaOztBQUVBLFFBQUl3QyxjQUFjLElBQUksQ0FBdEIsY0FBcUM7QUFDbkNsQixjQUFRLG1CQUFtQjtBQUN6QkMsY0FBTSxFQURSRDtBQUEyQixPQUFuQixDQUFSQTtBQUlIO0FBWEQsS0FXRyxpQ0FYSCxNQVdHLENBWEg7QUFhQSxRQUFNcUIsVUFLTCxHQUFHO0FBQ0ZDLE9BQUcsRUFERDtBQUVGQyxXQUFPLEVBQUcxQyxDQUFELElBQXlCO0FBQ2hDLFVBQUk4QixLQUFLLENBQUxBLFNBQWUsT0FBT0EsS0FBSyxDQUFMQSxNQUFQLFlBQW5CLFlBQThEO0FBQzVEQSxhQUFLLENBQUxBO0FBRUY7O0FBQUEsVUFBSSxDQUFDOUIsQ0FBQyxDQUFOLGtCQUF5QjtBQUN2QjJDLG1CQUFXLGdEQUFYQSxNQUFXLENBQVhBO0FBRUg7QUFkSDtBQUtJLEdBTEo7O0FBaUJBSCxZQUFVLENBQVZBLGVBQTJCeEMsQ0FBRCxJQUF5QjtBQUNqRCxRQUFJLENBQUMsd0JBQUwsSUFBSyxDQUFMLEVBQXVCOztBQUN2QixRQUFJOEIsS0FBSyxDQUFMQSxTQUFlLE9BQU9BLEtBQUssQ0FBTEEsTUFBUCxpQkFBbkIsWUFBbUU7QUFDakVBLFdBQUssQ0FBTEE7QUFFRlg7O0FBQUFBLFlBQVEsbUJBQW1CO0FBQUV5QixjQUFRLEVBQXJDekI7QUFBMkIsS0FBbkIsQ0FBUkE7QUFMRnFCLElBL0t1RCxDQXVMdkQ7QUFDQTs7O0FBQ0EsTUFBSTNCLEtBQUssQ0FBTEEsWUFBbUJpQixLQUFLLENBQUxBLGdCQUFzQixFQUFFLFVBQVVBLEtBQUssQ0FBOUQsS0FBNkMsQ0FBN0MsRUFBd0U7QUFDdEUsVUFBTW5DLFNBQVMsR0FDYix5Q0FBeUNGLE1BQU0sSUFBSUEsTUFBTSxDQUQzRCxPQURzRSxDQUl0RTtBQUNBOztBQUNBLFVBQU1vRCxZQUFZLEdBQ2hCcEQsTUFBTSxJQUNOQSxNQUFNLENBRE5BLGtCQUVBLDRDQUdFQSxNQUFNLElBQUlBLE1BQU0sQ0FIbEIsU0FJRUEsTUFBTSxJQUFJQSxNQUFNLENBUHBCLGFBR0UsQ0FIRjtBQVVBK0MsY0FBVSxDQUFWQSxPQUNFSyxZQUFZLElBQ1oseUJBQVksc0NBQXlCcEQsTUFBTSxJQUFJQSxNQUFNLENBRnZEK0MsYUFFYyxDQUFaLENBRkZBO0FBS0Y7O0FBQUEsc0JBQU9oQixtQ0FBUCxVQUFPQSxDQUFQOzs7ZUFHYXNCLEk7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdUZjtBQUNBO0FBQ0E7O0FBQ08sdUNBQXVEO0FBQzVELFNBQU9DLElBQUksQ0FBSkEsaUJBQXNCQSxJQUFJLEtBQTFCQSxNQUFxQ0EsSUFBSSxDQUFKQSxTQUFjLENBQW5EQSxDQUFxQ0EsQ0FBckNBLEdBQVA7QUFHRjtBQUFBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDTyxNQUFNQywwQkFBMEIsR0FBR0MsU0FDckNGLFNBRHFDRSxHQUFuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUUEsTUFBTUMsbUJBQW1CLEdBQzdCLCtCQUErQkMsSUFBSSxDQUFwQyxtQkFBQyxJQUNELGNBRWtCO0FBQ2hCLE1BQUlDLEtBQUssR0FBR0MsSUFBSSxDQUFoQixHQUFZQSxFQUFaO0FBQ0EsU0FBT0MsVUFBVSxDQUFDLFlBQVk7QUFDNUJDLE1BQUUsQ0FBQztBQUNEQyxnQkFBVSxFQURUO0FBRURDLG1CQUFhLEVBQUUsWUFBWTtBQUN6QixlQUFPQyxJQUFJLENBQUpBLE9BQVksTUFBTUwsSUFBSSxDQUFKQSxRQUF6QixLQUFtQixDQUFaSyxDQUFQO0FBSEpIO0FBQUcsS0FBRCxDQUFGQTtBQURlLEtBQWpCLENBQWlCLENBQWpCO0FBTkc7Ozs7QUFnQkEsTUFBTUksa0JBQWtCLEdBQzVCLCtCQUErQlIsSUFBSSxDQUFwQyxrQkFBQyxJQUNELGNBQXlDO0FBQ3ZDLFNBQU9TLFlBQVksQ0FBbkIsRUFBbUIsQ0FBbkI7QUFIRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakNQOztBQUNBLDhJLENBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU1DLGlCQUFpQixHQUF2Qjs7QUFtQ0EseUNBSWM7QUFDWixNQUFJQyxLQUFnQyxHQUFHQyxHQUFHLENBQUhBLElBQXZDLEdBQXVDQSxDQUF2Qzs7QUFDQSxhQUFXO0FBQ1QsUUFBSSxZQUFKLE9BQXVCO0FBQ3JCLGFBQU9ELEtBQUssQ0FBWjtBQUVGOztBQUFBLFdBQU9FLE9BQU8sQ0FBUEEsUUFBUCxLQUFPQSxDQUFQO0FBRUY7O0FBQUE7QUFDQSxRQUFNQyxJQUFnQixHQUFHLFlBQWdCQyxPQUFELElBQWE7QUFDbkRDLFlBQVEsR0FBUkE7QUFERixHQUF5QixDQUF6QjtBQUdBSixLQUFHLENBQUhBLFNBQWNELEtBQUssR0FBRztBQUFFSSxXQUFPLEVBQVQ7QUFBc0JFLFVBQU0sRUFBbERMO0FBQXNCLEdBQXRCQTtBQUNBLFNBQU9NLFNBQVMsR0FDWjtBQUNBQSxXQUFTLEdBQVRBLEtBQWtCQyxLQUFELEtBQVlILFFBQVEsQ0FBUkEsS0FBUSxDQUFSQSxFQUZqQixLQUVLLENBQWpCRSxDQUZZLEdBQWhCO0FBYUY7O0FBQUEsMkJBQXNEO0FBQ3BELE1BQUk7QUFDRkUsUUFBSSxHQUFHQyxRQUFRLENBQVJBLGNBQVBELE1BQU9DLENBQVBEO0FBQ0EsV0FDRTtBQUNBO0FBQ0MsT0FBQyxDQUFDRSxNQUFNLENBQVIsd0JBQWlDLENBQUMsQ0FBRUQsUUFBRCxDQUFwQyxZQUFDLElBQ0RELElBQUksQ0FBSkEsaUJBSkYsVUFJRUE7QUFKRjtBQU1BLEdBUkYsQ0FRRSxnQkFBTTtBQUNOO0FBRUg7QUFFRDs7QUFBQSxNQUFNRyxXQUFvQixHQUFHQyxXQUE3Qjs7QUFFQSx3Q0FJZ0I7QUFDZCxTQUFPLFlBQVksY0FBYztBQUMvQixRQUFJSCxRQUFRLENBQVJBLGNBQXdCLCtCQUE4QjNFLElBQTFELElBQUkyRSxDQUFKLEVBQXFFO0FBQ25FLGFBQU9JLEdBQVA7QUFHRkw7O0FBQUFBLFFBQUksR0FBR0MsUUFBUSxDQUFSQSxjQUFQRCxNQUFPQyxDQUFQRCxDQUwrQixDQU8vQjs7QUFDQSxZQUFRQSxJQUFJLENBQUpBO0FBQ1JBLFFBQUksQ0FBSkE7QUFDQUEsUUFBSSxDQUFKQSxjQUFvQnRCLFNBQXBCc0I7QUFDQUEsUUFBSSxDQUFKQTtBQUNBQSxRQUFJLENBQUpBLGNBWitCLENBYy9COztBQUNBQSxRQUFJLENBQUpBO0FBRUFDLFlBQVEsQ0FBUkE7QUFqQkYsR0FBTyxDQUFQO0FBcUJGOztBQUFBLE1BQU1LLGdCQUFnQixHQUFHQyxNQUFNLENBQS9CLGtCQUErQixDQUEvQixDLENBQ0E7O0FBQ08sNkJBQTJDO0FBQ2hELFNBQU9sRSxNQUFNLENBQU5BLHNDQUFQLEVBQU9BLENBQVA7QUFHSzs7QUFBQSwyQkFBd0Q7QUFDN0QsU0FBT2xCLEdBQUcsSUFBSW1GLGdCQUFnQixJQUE5QjtBQUdGOztBQUFBLG1DQUdvQjtBQUNsQixTQUFPLFlBQVkscUJBQXFCO0FBQ3RDRSxVQUFNLEdBQUdQLFFBQVEsQ0FBUkEsY0FBVE8sUUFBU1AsQ0FBVE8sQ0FEc0MsQ0FHdEM7QUFDQTtBQUNBOztBQUNBQSxVQUFNLENBQU5BOztBQUNBQSxVQUFNLENBQU5BLFVBQWlCLE1BQ2ZDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDLFVBQVcsMEJBQXlCQyxHQUQ1REgsRUFDd0IsQ0FBRCxDQUFmLENBRFJBLENBUHNDLENBVXRDO0FBQ0E7OztBQUNBQSxVQUFNLENBQU5BLGNBQXFCOUIsU0FBckI4QixDQVpzQyxDQWN0QztBQUNBOztBQUNBQSxVQUFNLENBQU5BO0FBQ0FQLFlBQVEsQ0FBUkE7QUFqQkYsR0FBTyxDQUFQO0FBcUJGLEMsQ0FBQTs7O0FBQ0EsK0NBSWM7QUFDWixTQUFPLFlBQVkscUJBQXFCO0FBQ3RDLFFBQUlXLFNBQVMsR0FBYjtBQUVBLEtBQUMsQ0FBRCxLQUFRQyxDQUFELElBQU87QUFDWjtBQUNBRCxlQUFTLEdBQVRBO0FBQ0FqQixhQUFPLENBQVBBLENBQU8sQ0FBUEE7QUFIRjtBQU1BLGtEQUFvQixNQUNsQlosVUFBVSxDQUFDLE1BQU07QUFDZixVQUFJLENBQUosV0FBZ0I7QUFDZDBCLGNBQU0sQ0FBTkEsR0FBTSxDQUFOQTtBQUVIO0FBSlMsT0FEWixFQUNZLENBRFo7QUFURixHQUFPLENBQVA7QUFtQkYsQyxDQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ08sa0NBQWdFO0FBQ3JFLE1BQUk3QixJQUFJLENBQVIsa0JBQTJCO0FBQ3pCLFdBQU9hLE9BQU8sQ0FBUEEsUUFBZ0JiLElBQUksQ0FBM0IsZ0JBQU9hLENBQVA7QUFHRjs7QUFBQSxRQUFNcUIsZUFBNkMsR0FBRyxZQUVuRG5CLE9BQUQsSUFBYTtBQUNiO0FBQ0EsVUFBTVgsRUFBRSxHQUFHSixJQUFJLENBQWY7O0FBQ0FBLFFBQUksQ0FBSkEsc0JBQTJCLE1BQU07QUFDL0JlLGFBQU8sQ0FBQ2YsSUFBSSxDQUFaZSxnQkFBTyxDQUFQQTtBQUNBWCxRQUFFLElBQUlBLEVBQU5BO0FBRkZKO0FBTEYsR0FBc0QsQ0FBdEQ7QUFXQSxTQUFPbUMseUJBQXlCLHFDQUc5QkwsY0FBYyxDQUFDLFVBSGpCLHNDQUdpQixDQUFELENBSGdCLENBQWhDO0FBV0Y7O0FBQUEsOENBR3VCO0FBQ3JCLFlBQTRDO0FBQzFDLFdBQU8sT0FBTyxDQUFQLFFBQWdCO0FBQ3JCTSxhQUFPLEVBQUUsQ0FDUEMsV0FBVyxHQUFYQSwrQkFFRUMsU0FBUyxDQUFDLDJDQUpPLEtBSVAsQ0FBRCxDQUhKLENBRFk7QUFNckI7QUFDQUMsU0FBRyxFQVBMO0FBQXVCLEtBQWhCLENBQVA7QUFVRjs7QUFBQSxTQUFPQyxzQkFBc0IsR0FBdEJBLEtBQStCQyxRQUFELElBQWM7QUFDakQsUUFBSSxFQUFFQyxLQUFLLElBQVgsUUFBSSxDQUFKLEVBQTBCO0FBQ3hCLFlBQU1aLGNBQWMsQ0FBQyxVQUFXLDJCQUEwQlksS0FBMUQsRUFBcUIsQ0FBRCxDQUFwQjtBQUVGOztBQUFBLFVBQU1DLFFBQVEsR0FBR0YsUUFBUSxDQUFSQSxLQUFRLENBQVJBLEtBQ2Q5QixLQUFELElBQVcwQixXQUFXLEdBQVhBLFlBQTBCQyxTQUFTLENBRGhELEtBQ2dELENBRC9CRyxDQUFqQjtBQUdBLFdBQU87QUFDTEwsYUFBTyxFQUFFTyxRQUFRLENBQVJBLE9BQWlCQyxDQUFELElBQU9BLENBQUMsQ0FBREEsU0FEM0IsS0FDMkJBLENBQXZCRCxDQURKO0FBRUxKLFNBQUcsRUFBRUksUUFBUSxDQUFSQSxPQUFpQkMsQ0FBRCxJQUFPQSxDQUFDLENBQURBLFNBRjlCLE1BRThCQSxDQUF2QkQ7QUFGQSxLQUFQO0FBUEYsR0FBT0gsQ0FBUDtBQWNGOztBQUFBLHdDQUE2RDtBQUMzRCxRQUFNSyxXQUdMLEdBQUcsSUFISixHQUdJLEVBSEo7QUFJQSxRQUFNQyxhQUE0QyxHQUFHLElBQXJELEdBQXFELEVBQXJEO0FBQ0EsUUFBTUMsV0FBa0QsR0FBRyxJQUEzRCxHQUEyRCxFQUEzRDtBQUNBLFFBQU1DLE1BR0wsR0FBRyxJQUhKLEdBR0ksRUFISjs7QUFLQSxtQ0FBMkQ7QUFDekQsUUFBSWxDLElBQWtDLEdBQUdnQyxhQUFhLENBQWJBLElBQXpDLEdBQXlDQSxDQUF6Qzs7QUFDQSxjQUFVO0FBQ1I7QUFHRixLQU55RCxDQU16RDs7O0FBQ0EsUUFBSXpCLFFBQVEsQ0FBUkEsY0FBd0IsZ0JBQWVVLEdBQTNDLElBQUlWLENBQUosRUFBcUQ7QUFDbkQsYUFBT1IsT0FBTyxDQUFkLE9BQU9BLEVBQVA7QUFHRmlDOztBQUFBQSxpQkFBYSxDQUFiQSxTQUF3QmhDLElBQUksR0FBR21DLFlBQVksQ0FBM0NILEdBQTJDLENBQTNDQTtBQUNBO0FBR0Y7O0FBQUEsaUNBQWlFO0FBQy9ELFFBQUloQyxJQUEwQyxHQUFHaUMsV0FBVyxDQUFYQSxJQUFqRCxJQUFpREEsQ0FBakQ7O0FBQ0EsY0FBVTtBQUNSO0FBR0ZBOztBQUFBQSxlQUFXLENBQVhBLFVBRUdqQyxJQUFJLEdBQUdvQyxLQUFLLENBQUxBLElBQUssQ0FBTEEsTUFDQ3pCLEdBQUQsSUFBUztBQUNiLFVBQUksQ0FBQ0EsR0FBRyxDQUFSLElBQWE7QUFDWCxjQUFNLFVBQVcsOEJBQTZCL0UsSUFBOUMsRUFBTSxDQUFOO0FBRUY7O0FBQUEsYUFBTytFLEdBQUcsQ0FBSEEsWUFBaUIwQixJQUFELEtBQVc7QUFBRXpHLFlBQUksRUFBTjtBQUFjMEcsZUFBTyxFQUF2RDtBQUFrQyxPQUFYLENBQWhCM0IsQ0FBUDtBQUxJeUIsYUFPRTNHLEdBQUQsSUFBUztBQUNkLFlBQU11RixjQUFjLENBQXBCLEdBQW9CLENBQXBCO0FBVk5pQixLQUVVRyxDQUZWSDtBQWFBO0FBR0Y7O0FBQUEsU0FBTztBQUNMTSxrQkFBYyxRQUFnQjtBQUM1QixhQUFPQyxVQUFVLFFBQWpCLFdBQWlCLENBQWpCO0FBRkc7O0FBSUxDLGdCQUFZLGlCQUF3QztBQUNsRDFDLGFBQU8sQ0FBUEEsc0JBQ1MyQyxFQUFELElBQVFBLEVBRGhCM0MsU0FHSzRDLE9BQUQsS0FBbUI7QUFDakJDLGlCQUFTLEVBQUdELE9BQU8sSUFBSUEsT0FBTyxDQUFuQixPQUFDQSxJQURLO0FBRWpCQSxlQUFPLEVBTGI1QztBQUd1QixPQUFuQixDQUhKQSxFQU9LdEUsR0FBRCxLQUFVO0FBQUVvSCxhQUFLLEVBUHJCOUM7QUFPYyxPQUFWLENBUEpBLE9BU1MrQyxLQUFELElBQTRCO0FBQ2hDLGNBQU1DLEdBQUcsR0FBR2hCLFdBQVcsQ0FBWEEsSUFBWixLQUFZQSxDQUFaO0FBQ0FBLG1CQUFXLENBQVhBO0FBQ0EsWUFBSWdCLEdBQUcsSUFBSSxhQUFYLEtBQTZCQSxHQUFHLENBQUhBO0FBWmpDaEQ7QUFMRzs7QUFvQkxpRCxhQUFTLFFBQWdCO0FBQ3ZCLGFBQU9SLFVBQVUsZ0JBQWtDLFlBQVk7QUFDN0QsWUFBSTtBQUNGLGdCQUFNO0FBQUE7QUFBQTtBQUFBLGNBQW1CLE1BQU1TLGdCQUFnQixjQUEvQyxLQUErQyxDQUEvQztBQUNBLGdCQUFNLGFBQWEsTUFBTWxELE9BQU8sQ0FBUEEsSUFBWSxDQUNuQ2dDLFdBQVcsQ0FBWEEsa0JBRUloQyxPQUFPLENBQVBBLElBQVl1QixPQUFPLENBQVBBLElBSG1CLGtCQUduQkEsQ0FBWnZCLENBSCtCLEVBSW5DQSxPQUFPLENBQVBBLElBQVkwQixHQUFHLENBQUhBLElBSmQsZUFJY0EsQ0FBWjFCLENBSm1DLENBQVpBLENBQXpCO0FBT0EsZ0JBQU1tRCxVQUEyQixHQUFHLE1BQU03Qix5QkFBeUIsQ0FDakUsb0JBRGlFLEtBQ2pFLENBRGlFLHFCQUdqRUwsY0FBYyxDQUNaLFVBQVcsbUNBQWtDWSxLQUpqRCxFQUlJLENBRFksQ0FIbUQsQ0FBbkU7QUFRQSxnQkFBTWpCLEdBQXFCLEdBQUdoRSxNQUFNLENBQU5BLE9BRzVCO0FBSDRCQTtBQUc1QixXQUg0QkEsRUFBOUIsVUFBOEJBLENBQTlCO0FBSUEsaUJBQU8scUNBQVA7QUFDQSxTQXRCRixDQXNCRSxZQUFZO0FBQ1osaUJBQU87QUFBRWtHLGlCQUFLLEVBQWQ7QUFBTyxXQUFQO0FBRUg7QUExQkQsT0FBaUIsQ0FBakI7QUFyQkc7O0FBaURMM0YsWUFBUSxRQUErQjtBQUNyQztBQUNBO0FBQ0E7O0FBQ0EsVUFBS2lHLEVBQUUsR0FBSUMsU0FBRCxDQUFWLFlBQTBDO0FBQ3hDO0FBQ0EsWUFBSUQsRUFBRSxDQUFGQSxZQUFlLFVBQVVBLEVBQUUsQ0FBL0IsYUFBbUIsQ0FBbkIsRUFBZ0QsT0FBT3BELE9BQU8sQ0FBZCxPQUFPQSxFQUFQO0FBRWxEOztBQUFBLGFBQU8sZ0JBQWdCLGNBQWhCLEtBQWdCLENBQWhCLE1BQ0VzRCxNQUFELElBQ0p0RCxPQUFPLENBQVBBLElBQ0VVLFdBQVcsR0FDUDRDLE1BQU0sQ0FBTkEsWUFBb0J2QyxNQUFELElBQVl3QyxjQUFjLFNBRHRDLFFBQ3NDLENBQTdDRCxDQURPLEdBSFYsRUFFSHRELENBRkcsT0FRQyxNQUFNO0FBQ1Ysc0RBQW9CLE1BQU0sZUFBMUIsS0FBMEIsQ0FBMUI7QUFURyxnQkFZSDtBQUNBLFlBQU0sQ0FiVixDQUFPLENBQVA7QUF6REo7O0FBQU8sR0FBUDs7O2VBNEVhd0QsaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFXZjs7QUFDQTs7Ozs7QUFDQTs7QUF5SEE7OztBQTVIQTs7QUFtQkEsTUFBTUMsZUFBb0MsR0FBRztBQUMzQ2hJLFFBQU0sRUFEcUM7QUFDN0I7QUFDZGlJLGdCQUFjLEVBRjZCOztBQUczQ0MsT0FBSyxLQUFpQjtBQUNwQixRQUFJLEtBQUosUUFBaUIsT0FBT3BFLEVBQVA7O0FBQ2pCLGVBQW1DLEVBR3BDO0FBUkg7O0FBQTZDLENBQTdDLEMsQ0FXQTs7QUFDQSxNQUFNcUUsaUJBQWlCLEdBQUcsK0lBQTFCLGdCQUEwQixDQUExQjtBQWVBLE1BQU1DLFlBQVksR0FBRywwR0FBckIsb0JBQXFCLENBQXJCO0FBUUEsTUFBTUMsZ0JBQWdCLEdBQUcsa0RBQXpCLGdCQUF5QixDQUF6QixDLENBU0E7O0FBQ0FsSCxNQUFNLENBQU5BLDBDQUFpRDtBQUMvQ21ILEtBQUcsR0FBRztBQUNKLFdBQU9DLGlCQUFQO0FBRkpwSDs7QUFBaUQsQ0FBakRBO0FBTUFnSCxpQkFBaUIsQ0FBakJBLFFBQTJCSyxLQUFELElBQW1CO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0FySCxRQUFNLENBQU5BLHVDQUE4QztBQUM1Q21ILE9BQUcsR0FBRztBQUNKLFlBQU10SSxNQUFNLEdBQUd5SSxTQUFmO0FBQ0EsYUFBT3pJLE1BQU0sQ0FBYixLQUFhLENBQWI7QUFISm1COztBQUE4QyxHQUE5Q0E7QUFMRmdIO0FBYUEsZ0JBQWdCLENBQWhCLFFBQTBCSyxLQUFELElBQW1CO0FBQzFDO0FBQ0E7O0FBQUVSLGlCQUFELE9BQUNBLEdBQWlDLENBQUMsR0FBRCxTQUFvQjtBQUNyRCxVQUFNaEksTUFBTSxHQUFHeUksU0FBZjtBQUNBLFdBQU96SSxNQUFNLENBQU5BLEtBQU0sQ0FBTkEsQ0FBYyxHQUFyQixJQUFPQSxDQUFQO0FBRkQsR0FBQ2dJO0FBRko7QUFRQUksWUFBWSxDQUFaQSxRQUFzQi9ILEtBQUQsSUFBbUI7QUFDdEMySCxpQkFBZSxDQUFmQSxNQUFzQixNQUFNO0FBQzFCTyxzQ0FBd0IsQ0FBQyxHQUFELFNBQWE7QUFDbkMsWUFBTUcsVUFBVSxHQUFJLEtBQUlySSxLQUFLLENBQUxBLHVCQUE4QixHQUFFQSxLQUFLLENBQUxBLFlBQXhEO0FBR0EsWUFBTXNJLGdCQUFnQixHQUF0Qjs7QUFDQSxVQUFJQSxnQkFBZ0IsQ0FBcEIsVUFBb0IsQ0FBcEIsRUFBa0M7QUFDaEMsWUFBSTtBQUNGQSwwQkFBZ0IsQ0FBaEJBLFVBQWdCLENBQWhCQSxDQUE2QixHQUE3QkE7QUFDQSxTQUZGLENBRUUsWUFBWTtBQUNaM0csaUJBQU8sQ0FBUEEsTUFBZSx3Q0FBdUMwRyxVQUF0RDFHO0FBQ0FBLGlCQUFPLENBQVBBLE1BQWUsR0FBRS9CLEdBQUcsQ0FBQzJJLE9BQVEsS0FBSTNJLEdBQUcsQ0FBQzRJLEtBQXJDN0c7QUFFSDtBQUNGO0FBYkR1RztBQURGUDtBQURGSTs7QUFtQkEscUJBQTZCO0FBQzNCLE1BQUksQ0FBQ0osZUFBZSxDQUFwQixRQUE2QjtBQUMzQixVQUFNWSxPQUFPLEdBQ1gsZ0NBREY7QUFHQSxVQUFNLFVBQU4sT0FBTSxDQUFOO0FBRUY7O0FBQUEsU0FBT1osZUFBZSxDQUF0QjtBQUdGLEMsQ0FBQTs7O2VBQ2VBLGUsRUFFZjs7OztBQUdPLHFCQUFpQztBQUN0QyxTQUFPakcsMEJBQWlCK0csZUFBeEIsYUFBTy9HLENBQVA7QUFHRixDLENBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7QUFDTyxNQUFNZ0gsWUFBWSxHQUFHLENBQUMsR0FBRCxTQUFpQztBQUMzRGYsaUJBQWUsQ0FBZkEsU0FBeUIsSUFBSU8sU0FBSixRQUFXLEdBQXBDUCxJQUF5QixDQUF6QkE7QUFDQUEsaUJBQWUsQ0FBZkEsdUJBQXdDbEUsRUFBRCxJQUFRQSxFQUEvQ2tFO0FBQ0FBLGlCQUFlLENBQWZBO0FBRUEsU0FBT0EsZUFBZSxDQUF0QjtBQUxLLEUsQ0FRUDs7Ozs7QUFDTywwQ0FBOEQ7QUFDbkUsUUFBTWdCLE9BQU8sR0FBYjtBQUNBLFFBQU1DLFFBQVEsR0FBZDs7QUFFQSxPQUFLLE1BQUwsK0JBQTBDO0FBQ3hDLFFBQUksT0FBT0QsT0FBTyxDQUFkLFFBQWMsQ0FBZCxLQUFKLFVBQTJDO0FBQ3pDQyxjQUFRLENBQVJBLFFBQVEsQ0FBUkEsR0FBcUI5SCxNQUFNLENBQU5BLE9BQ25CK0gsS0FBSyxDQUFMQSxRQUFjRixPQUFPLENBQXJCRSxRQUFxQixDQUFyQkEsU0FEbUIvSCxJQUVuQjZILE9BQU8sQ0FGVEMsUUFFUyxDQUZZOUgsQ0FBckI4SCxDQUR5QyxDQUl2Qzs7QUFDRjtBQUdGQTs7QUFBQUEsWUFBUSxDQUFSQSxRQUFRLENBQVJBLEdBQXFCRCxPQUFPLENBQTVCQyxRQUE0QixDQUE1QkE7QUFHRixHQWhCbUUsQ0FnQm5FOzs7QUFDQUEsVUFBUSxDQUFSQSxTQUFrQlYsaUJBQWxCVTtBQUVBWixrQkFBZ0IsQ0FBaEJBLFFBQTBCRyxLQUFELElBQVc7QUFDbENTLFlBQVEsQ0FBUkEsS0FBUSxDQUFSQSxHQUFrQixDQUFDLEdBQUQsU0FBb0I7QUFDcEMsYUFBT0QsT0FBTyxDQUFQQSxLQUFPLENBQVBBLENBQWUsR0FBdEIsSUFBT0EsQ0FBUDtBQURGQztBQURGWjtBQU1BO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1S0Q7O0FBQ0E7O0FBY0EsTUFBTWMsdUJBQXVCLEdBQUcsZ0NBQWhDOztBQUVPLHlCQUE0QztBQUFBO0FBQTVDO0FBQTRDLENBQTVDLEVBR3FEO0FBQzFELFFBQU1DLFVBQW1CLEdBQUdDLFFBQVEsSUFBSSxDQUF4QztBQUVBLFFBQU1DLFNBQVMsR0FBRyxXQUFsQixNQUFrQixHQUFsQjtBQUNBLFFBQU0sd0JBQXdCLHFCQUE5QixLQUE4QixDQUE5QjtBQUVBLFFBQU03RyxNQUFNLEdBQUcsd0JBQ1pDLEVBQUQsSUFBa0I7QUFDaEIsUUFBSTRHLFNBQVMsQ0FBYixTQUF1QjtBQUNyQkEsZUFBUyxDQUFUQTtBQUNBQSxlQUFTLENBQVRBO0FBR0Y7O0FBQUEsUUFBSUYsVUFBVSxJQUFkLFNBQTJCOztBQUUzQixRQUFJMUcsRUFBRSxJQUFJQSxFQUFFLENBQVosU0FBc0I7QUFDcEI0RyxlQUFTLENBQVRBLFVBQW9CQyxPQUFPLEtBRXhCMUcsU0FBRCxJQUFlQSxTQUFTLElBQUkyRyxVQUFVLENBRmIsU0FFYSxDQUZiLEVBR3pCO0FBSEZGO0FBR0UsT0FIeUIsQ0FBM0JBO0FBTUg7QUFoQlksS0FpQmIseUJBakJGLE9BaUJFLENBakJhLENBQWY7QUFvQkEsd0JBQVUsTUFBTTtBQUNkLFFBQUksQ0FBSix5QkFBOEI7QUFDNUIsVUFBSSxDQUFKLFNBQWM7QUFDWixjQUFNRyxZQUFZLEdBQUcsOENBQW9CLE1BQU1ELFVBQVUsQ0FBekQsSUFBeUQsQ0FBcEMsQ0FBckI7QUFDQSxlQUFPLE1BQU0sNkNBQWIsWUFBYSxDQUFiO0FBRUg7QUFDRjtBQVBELEtBT0csQ0FQSCxPQU9HLENBUEg7QUFTQSxTQUFPLFNBQVAsT0FBTyxDQUFQO0FBR0Y7O0FBQUEsNkNBSWM7QUFDWixRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNkJFLGNBQWMsQ0FBakQsT0FBaUQsQ0FBakQ7QUFDQUMsVUFBUSxDQUFSQTtBQUVBQyxVQUFRLENBQVJBO0FBQ0EsU0FBTyxxQkFBMkI7QUFDaENELFlBQVEsQ0FBUkE7QUFDQUMsWUFBUSxDQUFSQSxtQkFGZ0MsQ0FJaEM7O0FBQ0EsUUFBSUQsUUFBUSxDQUFSQSxTQUFKLEdBQXlCO0FBQ3ZCQyxjQUFRLENBQVJBO0FBQ0FDLGVBQVMsQ0FBVEE7QUFFSDtBQVREO0FBWUY7O0FBQUEsTUFBTUEsU0FBUyxHQUFHLElBQWxCLEdBQWtCLEVBQWxCOztBQUNBLGlDQUF3RTtBQUN0RSxRQUFNQyxFQUFFLEdBQUczSixPQUFPLENBQVBBLGNBQVg7QUFDQSxNQUFJOEksUUFBUSxHQUFHWSxTQUFTLENBQVRBLElBQWYsRUFBZUEsQ0FBZjs7QUFDQSxnQkFBYztBQUNaO0FBR0Y7O0FBQUEsUUFBTUYsUUFBUSxHQUFHLElBQWpCLEdBQWlCLEVBQWpCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHLHlCQUEwQkcsT0FBRCxJQUFhO0FBQ3JEQSxXQUFPLENBQVBBLFFBQWlCMUYsS0FBRCxJQUFXO0FBQ3pCLFlBQU0yRixRQUFRLEdBQUdMLFFBQVEsQ0FBUkEsSUFBYXRGLEtBQUssQ0FBbkMsTUFBaUJzRixDQUFqQjtBQUNBLFlBQU05RyxTQUFTLEdBQUd3QixLQUFLLENBQUxBLGtCQUF3QkEsS0FBSyxDQUFMQSxvQkFBMUM7O0FBQ0EsVUFBSTJGLFFBQVEsSUFBWixXQUEyQjtBQUN6QkEsZ0JBQVEsQ0FBUkEsU0FBUSxDQUFSQTtBQUVIO0FBTkREO0FBRGUsS0FBakIsT0FBaUIsQ0FBakI7QUFVQUYsV0FBUyxDQUFUQSxRQUVHWixRQUFRLEdBQUc7QUFBQTtBQUFBO0FBRmRZO0FBRWMsR0FGZEE7QUFRQTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzR0Q7O0FBRUE7O0FBV2UsdUNBSytCO0FBQzVDLG9DQUFvRDtBQUNsRCx3QkFBTztBQUFtQixZQUFNLEVBQUUsWUFBM0IsU0FBMkI7QUFBM0IsT0FBUCxLQUFPLEVBQVA7QUFHRjs7QUFBQSxtQkFBaUIsQ0FBakIsa0JBQW9DSSxpQkFBaUIsQ0FBQ0MsZUFBdEQsQ0FDQTtBQURBO0FBRUVDLG1CQUFELG9CQUFDQSxHQUFpREYsaUJBQUQsQ0FBakQsbUJBQUNFOztBQUNGLFlBQTJDO0FBQ3pDLFVBQU1DLElBQUksR0FDUkgsaUJBQWlCLENBQWpCQSxlQUFpQ0EsaUJBQWlCLENBQWxEQSxRQURGO0FBRUFFLHFCQUFpQixDQUFqQkEsY0FBaUMsY0FBYUMsSUFBOUNEO0FBR0Y7O0FBQUE7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDTSxnREFNTDtBQUNBLHFCQURBLENBRUE7O0FBQ0EsUUFBTUUsYUFBYSxHQUFHbkksUUFBUSxDQUFSQSxNQUF0QixHQUFzQkEsQ0FBdEI7QUFFQyxHQUFDb0ksT0FBTyxJQUFSLFNBQXNCM0ksTUFBRCxJQUFZO0FBQ2hDLFFBQUkwSSxhQUFhLENBQWJBLENBQWEsQ0FBYkEsbUJBQW1DMUksTUFBTSxDQUE3QyxXQUF1Q0EsRUFBdkMsRUFBNkQ7QUFDM0Q0SSxvQkFBYyxHQUFkQTtBQUNBRixtQkFBYSxDQUFiQTtBQUNBbkksY0FBUSxHQUFHbUksYUFBYSxDQUFiQSxhQUFYbkk7QUFDQTtBQUVGOztBQUFBO0FBUEQ7QUFVRCxTQUFPO0FBQUE7QUFBUDtBQUFPLEdBQVA7QUFJRCxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDekJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUE7QUFDQTtBQUNBOztBQVVlLGdCQUE2QjtBQUMxQyxRQUFNc0ksR0FBK0IsR0FBR3JKLE1BQU0sQ0FBTkEsT0FBeEMsSUFBd0NBLENBQXhDO0FBRUEsU0FBTztBQUNMc0osTUFBRSxnQkFBaUM7QUFDakM7QUFBQyxPQUFDRCxHQUFHLENBQUhBLElBQUcsQ0FBSEEsS0FBY0EsR0FBRyxDQUFIQSxJQUFHLENBQUhBLEdBQWYsRUFBQ0EsQ0FBRDtBQUZFOztBQUtMRSxPQUFHLGdCQUFpQztBQUNsQyxVQUFJRixHQUFHLENBQVAsSUFBTyxDQUFQLEVBQWU7QUFDYkEsV0FBRyxDQUFIQSxJQUFHLENBQUhBLFFBQWlCQSxHQUFHLENBQUhBLElBQUcsQ0FBSEEsc0JBQWpCQTtBQUVIO0FBVEk7O0FBV0xHLFFBQUksT0FBZSxHQUFmLE1BQStCO0FBQ2pDO0FBQ0E7QUFBQyxPQUFDSCxHQUFHLENBQUhBLElBQUcsQ0FBSEEsSUFBRCxnQkFBK0JJLE9BQUQsSUFBc0I7QUFDbkRBLGVBQU8sQ0FBQyxHQUFSQSxJQUFPLENBQVBBO0FBREQ7QUFiTDs7QUFBTyxHQUFQO0FBa0JELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeENEOztBQUtBOztBQU1BOztBQUNBOztBQUNBOztBQUNBOztBQVVBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOzs7Ozs7QUFsQ0E7QUFBQTtBQUNBOzs7QUErREE7O0FBRUEsSUFBSXBILEtBQUosRUFBcUMsRUFLckM7O0FBQUEsTUFBTXFILFFBQVEsR0FBSXJILFVBQWxCOztBQUVBLGtDQUFrQztBQUNoQyxTQUFPckMsTUFBTSxDQUFOQSxPQUFjLFVBQWRBLGlCQUFjLENBQWRBLEVBQTRDO0FBQ2pEdUUsYUFBUyxFQURYO0FBQW1ELEdBQTVDdkUsQ0FBUDtBQUtGOztBQUFBLHFDQUFzRDtBQUNwRCxTQUFPMkosTUFBTSxJQUFJeEgsSUFBSSxDQUFKQSxXQUFWd0gsR0FBVXhILENBQVZ3SCxHQUNIeEgsSUFBSSxLQUFKQSxNQUNFLHdEQURGQSxNQUNFLENBREZBLEdBRUcsR0FBRXdILE1BQU8sR0FBRUMsZUFBZSxDQUFmQSxJQUFlLENBQWZBLFdBQWdDekgsSUFBSSxDQUFKQSxVQUFoQ3lILENBQWdDekgsQ0FBaEN5SCxHQUFvRHpILElBSC9Ed0gsS0FBUDtBQU9LOztBQUFBLCtEQUtMO0FBQ0EsTUFBSXRILEtBQUosRUFBcUMsRUFhckM7O0FBQUE7QUFHSzs7QUFBQSxnREFJTDtBQUNBLE1BQUlBLEtBQUosRUFBcUMsRUFRckM7O0FBQUE7QUFHSzs7QUFBQSxpQ0FBa0Q7QUFDdkQsTUFBSUEsS0FBSixFQUFxQyxFQU1yQzs7QUFBQTtBQUdGOztBQUFBLCtCQUF1QztBQUNyQyxRQUFNd0gsVUFBVSxHQUFHMUgsSUFBSSxDQUFKQSxRQUFuQixHQUFtQkEsQ0FBbkI7QUFDQSxRQUFNMkgsU0FBUyxHQUFHM0gsSUFBSSxDQUFKQSxRQUFsQixHQUFrQkEsQ0FBbEI7O0FBRUEsTUFBSTBILFVBQVUsR0FBRyxDQUFiQSxLQUFtQkMsU0FBUyxHQUFHLENBQW5DLEdBQXVDO0FBQ3JDM0gsUUFBSSxHQUFHQSxJQUFJLENBQUpBLGFBQWtCMEgsVUFBVSxHQUFHLENBQWJBLGlCQUF6QjFILFNBQU9BLENBQVBBO0FBRUY7O0FBQUE7QUFHSzs7QUFBQSwyQkFBNEM7QUFDakRBLE1BQUksR0FBR3lILGVBQWUsQ0FBdEJ6SCxJQUFzQixDQUF0QkE7QUFDQSxTQUFPQSxJQUFJLEtBQUpBLFlBQXFCQSxJQUFJLENBQUpBLFdBQWdCdUgsUUFBUSxHQUFwRCxHQUE0QnZILENBQTVCO0FBR0s7O0FBQUEsMkJBQTJDO0FBQ2hEO0FBQ0EsU0FBTzRILGFBQWEsT0FBcEIsUUFBb0IsQ0FBcEI7QUFHSzs7QUFBQSwyQkFBMkM7QUFDaEQ1SCxNQUFJLEdBQUdBLElBQUksQ0FBSkEsTUFBV3VILFFBQVEsQ0FBMUJ2SCxNQUFPQSxDQUFQQTtBQUNBLE1BQUksQ0FBQ0EsSUFBSSxDQUFKQSxXQUFMLEdBQUtBLENBQUwsRUFBMkJBLElBQUksR0FBSSxJQUFHQSxJQUFYQTtBQUMzQjtBQUdGO0FBQUE7QUFDQTtBQUNBOzs7QUFDTyx5QkFBMEM7QUFDL0M7QUFDQSxNQUFJNkgsR0FBRyxDQUFIQSxtQkFBdUJBLEdBQUcsQ0FBSEEsV0FBM0IsR0FBMkJBLENBQTNCLEVBQWdEOztBQUNoRCxNQUFJO0FBQ0Y7QUFDQSxVQUFNQyxjQUFjLEdBQUcsV0FBdkIsaUJBQXVCLEdBQXZCO0FBQ0EsVUFBTUMsUUFBUSxHQUFHLGFBQWpCLGNBQWlCLENBQWpCO0FBQ0EsV0FBT0EsUUFBUSxDQUFSQSw2QkFBc0NDLFdBQVcsQ0FBQ0QsUUFBUSxDQUFqRSxRQUF3RCxDQUF4RDtBQUNBLEdBTEYsQ0FLRSxVQUFVO0FBQ1Y7QUFFSDtBQUlNOztBQUFBLGlEQUlMO0FBQ0EsTUFBSUUsaUJBQWlCLEdBQXJCO0FBRUEsUUFBTUMsWUFBWSxHQUFHLCtCQUFyQixLQUFxQixDQUFyQjtBQUNBLFFBQU1DLGFBQWEsR0FBR0QsWUFBWSxDQUFsQztBQUNBLFFBQU1FLGNBQWMsR0FDbEI7QUFDQSxHQUFDQyxVQUFVLEtBQVZBLFFBQXVCLGlEQUF2QkEsVUFBdUIsQ0FBdkJBLEdBQUQsT0FDQTtBQUNBO0FBSkY7QUFPQUosbUJBQWlCLEdBQWpCQTtBQUNBLFFBQU1LLE1BQU0sR0FBR3pLLE1BQU0sQ0FBTkEsS0FBZixhQUFlQSxDQUFmOztBQUVBLE1BQ0UsQ0FBQ3lLLE1BQU0sQ0FBTkEsTUFBY0MsS0FBRCxJQUFXO0FBQ3ZCLFFBQUloSCxLQUFLLEdBQUc2RyxjQUFjLENBQWRBLEtBQWMsQ0FBZEEsSUFBWjtBQUNBLFVBQU07QUFBQTtBQUFBO0FBQUEsUUFBdUJELGFBQWEsQ0FBMUMsS0FBMEMsQ0FBMUMsQ0FGdUIsQ0FJdkI7QUFDQTs7QUFDQSxRQUFJSyxRQUFRLEdBQUksSUFBR0MsTUFBTSxXQUFXLEVBQUcsR0FBRUYsS0FBekM7O0FBQ0Esa0JBQWM7QUFDWkMsY0FBUSxHQUFJLEdBQUUsZUFBZSxFQUFHLElBQUdBLFFBQW5DQTtBQUVGOztBQUFBLFFBQUlDLE1BQU0sSUFBSSxDQUFDN0MsS0FBSyxDQUFMQSxRQUFmLEtBQWVBLENBQWYsRUFBcUNyRSxLQUFLLEdBQUcsQ0FBUkEsS0FBUSxDQUFSQTtBQUVyQyxXQUNFLENBQUNtSCxRQUFRLElBQUlILEtBQUssSUFBbEIscUJBQ0E7QUFDQ04scUJBQWlCLEdBQ2hCQSxpQkFBaUIsQ0FBakJBLGtCQUVFUSxNQUFNLEdBQ0RsSCxLQUFELElBQUNBLEVBRUc7QUFDQTtBQUNBO0FBQ0E7QUFDQ29ILFdBQUQsSUFBYUMsa0JBQWtCLENBTm5DLE9BTW1DLENBTmxDckgsRUFBRCxJQUFDQSxDQURDLEdBQ0RBLENBREMsR0FVRnFILGtCQUFrQixDQVp4QlgsS0FZd0IsQ0FaeEJBLEtBSkosR0FDRSxDQURGO0FBYkosR0FDR0ssQ0FESCxFQWlDRTtBQUNBTCxxQkFBaUIsR0FBakJBLEdBREEsQ0FDdUI7QUFFdkI7QUFDQTtBQUVGOztBQUFBLFNBQU87QUFBQTtBQUVMWSxVQUFNLEVBRlI7QUFBTyxHQUFQO0FBTUY7O0FBQUEsMkNBQXFFO0FBQ25FLFFBQU1DLGFBQTZCLEdBQW5DO0FBRUFqTCxRQUFNLENBQU5BLG9CQUE0QkwsR0FBRCxJQUFTO0FBQ2xDLFFBQUksQ0FBQzhLLE1BQU0sQ0FBTkEsU0FBTCxHQUFLQSxDQUFMLEVBQTJCO0FBQ3pCUSxtQkFBYSxDQUFiQSxHQUFhLENBQWJBLEdBQXFCQyxLQUFLLENBQTFCRCxHQUEwQixDQUExQkE7QUFFSDtBQUpEakw7QUFLQTtBQUdGO0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNPLG1EQUlHO0FBQ1I7QUFDQSxRQUFNbUwsSUFBSSxHQUFHLHFCQUFiLFVBQWEsQ0FBYjtBQUNBLFFBQU1DLFdBQVcsR0FDZixrQ0FBa0MsaUNBRHBDLElBQ29DLENBRHBDLENBSFEsQ0FLUjs7QUFDQSxNQUFJLENBQUNDLFVBQVUsQ0FBZixXQUFlLENBQWYsRUFBOEI7QUFDNUIsV0FBUUMsU0FBUyxHQUFHLENBQUgsV0FBRyxDQUFILEdBQWpCO0FBRUY7O0FBQUEsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxxQkFBakIsSUFBaUIsQ0FBakI7QUFDQUEsWUFBUSxDQUFSQSxXQUFvQix3REFBMkJBLFFBQVEsQ0FBdkRBLFFBQW9CLENBQXBCQTtBQUNBLFFBQUlDLGNBQWMsR0FBbEI7O0FBRUEsUUFDRSwrQkFBZUQsUUFBUSxDQUF2QixhQUNBQSxRQUFRLENBRFIsZ0JBREYsV0FJRTtBQUNBLFlBQU1MLEtBQUssR0FBRyx5Q0FBdUJLLFFBQVEsQ0FBN0MsWUFBYyxDQUFkO0FBRUEsWUFBTTtBQUFBO0FBQUE7QUFBQSxVQUFxQkUsYUFBYSxDQUN0Q0YsUUFBUSxDQUQ4QixVQUV0Q0EsUUFBUSxDQUY4QixVQUF4QyxLQUF3QyxDQUF4Qzs7QUFNQSxrQkFBWTtBQUNWQyxzQkFBYyxHQUFHLGlDQUFxQjtBQUNwQ3pLLGtCQUFRLEVBRDRCO0FBRXBDMkssY0FBSSxFQUFFSCxRQUFRLENBRnNCO0FBR3BDTCxlQUFLLEVBQUVTLGtCQUFrQixRQUgzQkgsTUFHMkI7QUFIVyxTQUFyQixDQUFqQkE7QUFNSDtBQUVELEtBM0JFLENBMkJGOzs7QUFDQSxVQUFNSSxZQUFZLEdBQ2hCTCxRQUFRLENBQVJBLFdBQW9CSixJQUFJLENBQXhCSSxTQUNJQSxRQUFRLENBQVJBLFdBQW9CQSxRQUFRLENBQVJBLE9BRHhCQSxNQUNJQSxDQURKQSxHQUVJQSxRQUFRLENBSGQ7QUFLQSxXQUFRRCxTQUFTLEdBQ2IsZUFBZUUsY0FBYyxJQURoQixZQUNiLENBRGEsR0FBakI7QUFHQSxHQXBDRixDQW9DRSxVQUFVO0FBQ1YsV0FBUUYsU0FBUyxHQUFHLENBQUgsV0FBRyxDQUFILEdBQWpCO0FBRUg7QUFFRDs7QUFBQSwwQkFBa0M7QUFDaEMsUUFBTU8sTUFBTSxHQUFHLFdBQWYsaUJBQWUsR0FBZjtBQUVBLFNBQU83QixHQUFHLENBQUhBLHFCQUF5QkEsR0FBRyxDQUFIQSxVQUFjNkIsTUFBTSxDQUE3QzdCLE1BQXlCQSxDQUF6QkEsR0FBUDtBQUdGOztBQUFBLHVDQUE4RDtBQUM1RDtBQUNBO0FBQ0EsTUFBSSw2QkFBNkI4QixXQUFXLENBQUNqTixNQUFNLENBQVAsZUFBNUMsSUFBNEMsQ0FBNUM7QUFDQSxRQUFNZ04sTUFBTSxHQUFHLFdBQWYsaUJBQWUsR0FBZjtBQUNBLFFBQU1FLGFBQWEsR0FBR0gsWUFBWSxDQUFaQSxXQUF0QixNQUFzQkEsQ0FBdEI7QUFDQSxRQUFNSSxXQUFXLEdBQUdoTCxVQUFVLElBQUlBLFVBQVUsQ0FBVkEsV0FBbEMsTUFBa0NBLENBQWxDO0FBRUE0SyxjQUFZLEdBQUdLLFdBQVcsQ0FBMUJMLFlBQTBCLENBQTFCQTtBQUNBNUssWUFBVSxHQUFHQSxVQUFVLEdBQUdpTCxXQUFXLENBQWQsVUFBYyxDQUFkLEdBQXZCakw7QUFFQSxRQUFNa0wsV0FBVyxHQUFHSCxhQUFhLGtCQUFrQkksV0FBVyxDQUE5RCxZQUE4RCxDQUE5RDtBQUNBLFFBQU1DLFVBQVUsR0FBRzVNLEVBQUUsR0FDakJ5TSxXQUFXLENBQUNILFdBQVcsQ0FBQ2pOLE1BQU0sQ0FBUCxVQUROLEVBQ00sQ0FBWixDQURNLEdBRWpCbUMsVUFBVSxJQUZkO0FBSUEsU0FBTztBQUNMZ0osT0FBRyxFQURFO0FBRUx4SyxNQUFFLEVBQUV3TSxXQUFXLGdCQUFnQkcsV0FBVyxDQUY1QyxVQUU0QztBQUZyQyxHQUFQO0FBTUY7O0FBQUEsOENBQWdFO0FBQzlELFFBQU1FLGFBQWEsR0FBRyxxREFBd0IsOENBQTlDLFFBQThDLENBQXhCLENBQXRCOztBQUVBLE1BQUlBLGFBQWEsS0FBYkEsVUFBNEJBLGFBQWEsS0FBN0MsV0FBNkQ7QUFDM0Q7QUFHRixHQVA4RCxDQU85RDs7O0FBQ0EsTUFBSSxDQUFDQyxLQUFLLENBQUxBLFNBQUwsYUFBS0EsQ0FBTCxFQUFxQztBQUNuQztBQUNBQSxTQUFLLENBQUxBLEtBQVlDLElBQUQsSUFBVTtBQUNuQixVQUFJLHdDQUF3Qiw2Q0FBNUIsYUFBNEIsQ0FBNUIsRUFBeUU7QUFDdkV4TCxnQkFBUSxHQUFSQTtBQUNBO0FBRUg7QUFMRHVMO0FBT0Y7O0FBQUEsU0FBTyxxREFBUCxRQUFPLENBQVA7QUFtRUY7O0FBQUEsTUFBTUUsdUJBQXVCLEdBQzNCbkssVUFHQSxLQUpGO0FBWUEsTUFBTW9LLGtCQUFrQixHQUFHdkksTUFBTSxDQUFqQyxvQkFBaUMsQ0FBakM7O0FBRUEsbUNBQWlFO0FBQy9ELFNBQU8sS0FBSyxNQUFNO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQXdJLGVBQVcsRUFaTjtBQUFXLEdBQU4sQ0FBTCxNQWFFMUksR0FBRCxJQUFTO0FBQ2YsUUFBSSxDQUFDQSxHQUFHLENBQVIsSUFBYTtBQUNYLFVBQUkySSxRQUFRLEdBQVJBLEtBQWdCM0ksR0FBRyxDQUFIQSxVQUFwQixLQUF1QztBQUNyQyxlQUFPNEksVUFBVSxNQUFNRCxRQUFRLEdBQS9CLENBQWlCLENBQWpCO0FBRUY7O0FBQUEsVUFBSTNJLEdBQUcsQ0FBSEEsV0FBSixLQUF3QjtBQUN0QixlQUFPQSxHQUFHLENBQUhBLFlBQWlCNkksSUFBRCxJQUFVO0FBQy9CLGNBQUlBLElBQUksQ0FBUixVQUFtQjtBQUNqQixtQkFBTztBQUFFQyxzQkFBUSxFQUFqQjtBQUFPLGFBQVA7QUFFRjs7QUFBQSxnQkFBTSxVQUFOLDZCQUFNLENBQU47QUFKRixTQUFPOUksQ0FBUDtBQU9GOztBQUFBLFlBQU0sVUFBTiw2QkFBTSxDQUFOO0FBRUY7O0FBQUEsV0FBT0EsR0FBRyxDQUFWLElBQU9BLEVBQVA7QUE1QkYsR0FBTyxDQUFQO0FBZ0NGOztBQUFBLGlEQUFrRTtBQUNoRSxTQUFPLFVBQVUsV0FBVytJLGNBQWMsT0FBbkMsQ0FBVSxDQUFWLE9BQW9Eak8sR0FBRCxJQUFnQjtBQUN4RTtBQUNBO0FBQ0E7QUFFQSxRQUFJLENBQUosZ0JBQXFCO0FBQ25CO0FBRUY7O0FBQUE7QUFSRixHQUFPLENBQVA7QUFZYTs7QUFBQSxNQUFNc0ksTUFBTixDQUFtQztBQU9oRDtBQUNGO0FBUmtEO0FBV2hEO0FBRUE7QUF5QkE0RixhQUFXLHlCQUlUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSlM7QUFJVCxHQUpTLEVBaUNUO0FBQUEsU0F0RUYvSCxLQXNFRTtBQUFBLFNBckVGbEUsUUFxRUU7QUFBQSxTQXBFRm1LLEtBb0VFO0FBQUEsU0FuRUYrQixNQW1FRTtBQUFBLFNBbEVGdkQsUUFrRUU7QUFBQSxTQTdERndELFVBNkRFO0FBQUEsU0EzREZDLEdBMkRFLEdBM0RrQyxFQTJEbEM7QUFBQSxTQXpERkMsR0F5REUsR0F6RDJDLEVBeUQzQztBQUFBLFNBdkRGQyxHQXVERTtBQUFBLFNBdERGQyxHQXNERTtBQUFBLFNBckRGQyxVQXFERTtBQUFBLFNBcERGQyxJQW9ERTtBQUFBLFNBbkRGQyxNQW1ERTtBQUFBLFNBbERGQyxRQWtERTtBQUFBLFNBakRGQyxLQWlERTtBQUFBLFNBaERGQyxVQWdERTtBQUFBLFNBL0NGQyxjQStDRTtBQUFBLFNBOUNGQyxRQThDRTtBQUFBLFNBN0NGdE4sTUE2Q0U7QUFBQSxTQTVDRjJJLE9BNENFO0FBQUEsU0EzQ0Y0RSxhQTJDRTtBQUFBLFNBMUNGQyxhQTBDRTtBQUFBLFNBekNGQyxPQXlDRTtBQUFBLFNBeENGQyxTQXdDRTtBQUFBLFNBdkNGQyxjQXVDRTtBQUFBLFNBckNNQyxJQXFDTixHQXJDcUIsQ0FxQ3JCOztBQUFBLHNCQStGWWhQLENBQUQsSUFBNEI7QUFDdkMsWUFBTWlQLEtBQUssR0FBR2pQLENBQUMsQ0FBZjs7QUFFQSxVQUFJLENBQUosT0FBWTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQU07QUFBQTtBQUFBO0FBQUEsWUFBTjtBQUNBLHlDQUVFLGlDQUFxQjtBQUFFMkIsa0JBQVEsRUFBRW9MLFdBQVcsQ0FBdkIsUUFBdUIsQ0FBdkI7QUFGdkI7QUFFdUIsU0FBckIsQ0FGRixFQUdFLFdBSEYsTUFHRSxHQUhGO0FBS0E7QUFHRjs7QUFBQSxVQUFJLENBQUNrQyxLQUFLLENBQVYsS0FBZ0I7QUFDZDtBQUdGOztBQUFBO0FBQ0EsWUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBTjs7QUFDQSxVQUFJaE0sS0FBSixFQUEyQyxFQXFCM0M7O0FBQUE7QUFFQSxZQUFNO0FBQUE7QUFBQSxVQUFlLHdDQUFyQixHQUFxQixDQUFyQixDQW5EdUMsQ0FxRHZDO0FBQ0E7O0FBQ0EsVUFBSSxjQUFjN0MsRUFBRSxLQUFLLEtBQXJCLFVBQW9DdUIsUUFBUSxLQUFLLEtBQXJELFVBQW9FO0FBQ2xFO0FBR0YsT0EzRHVDLENBMkR2QztBQUNBOzs7QUFDQSxVQUFJLGFBQWEsQ0FBQyxVQUFsQixLQUFrQixDQUFsQixFQUFvQztBQUNsQztBQUdGOztBQUFBLDJDQUlFZixNQUFNLENBQU5BLG9CQUFxRTtBQUNuRUssZUFBTyxFQUFFckIsT0FBTyxDQUFQQSxXQUFtQixLQUR1QztBQUVuRXdCLGNBQU0sRUFBRXhCLE9BQU8sQ0FBUEEsVUFBa0IsS0FOOUI7QUFJdUUsT0FBckVnQixDQUpGO0FBaEtBLE9BQ0E7OztBQUNBLGlCQUFhLHFEQUFiLFNBQWEsQ0FBYixDQUZBLENBSUE7O0FBQ0EseUJBTEEsQ0FNQTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSWUsU0FBUSxLQUFaLFdBQTRCO0FBQzFCLHNCQUFnQixLQUFoQixTQUE4QjtBQUFBO0FBRTVCdU4sZUFBTyxFQUZxQjtBQUc1QnJPLGFBQUssRUFIdUI7QUFBQTtBQUs1QnNPLGVBQU8sRUFBRUMsWUFBWSxJQUFJQSxZQUFZLENBTFQ7QUFNNUJDLGVBQU8sRUFBRUQsWUFBWSxJQUFJQSxZQUFZLENBTnZDO0FBQThCLE9BQTlCO0FBVUY7O0FBQUEsK0JBQTJCO0FBQ3pCRSxlQUFTLEVBRGdCO0FBRXpCcEosaUJBQVcsRUFBRTtBQUZmO0FBRWU7QUFGWSxLQUEzQixDQXBCQSxDQTJCQTtBQUNBOztBQUNBLGtCQUFjOEIsTUFBTSxDQUFwQjtBQUVBO0FBQ0E7QUFDQSx3QkFqQ0EsQ0FrQ0E7QUFDQTs7QUFDQSxVQUFNdUgsaUJBQWlCLEdBQ3JCLDZDQUE0QnBNLElBQUksQ0FBSkEsY0FEOUI7O0FBR0Esa0JBQWNvTSxpQkFBaUIsZUFBL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkEzQ0EsQ0E0Q0E7QUFDQTs7QUFDQTtBQUVBO0FBRUEsbUJBQWUsQ0FBQyxFQUNkcE0sSUFBSSxDQUFKQSxzQkFDQUEsSUFBSSxDQUFKQSxjQURBQSxPQUVDLHNCQUFzQixDQUFDQSxJQUFJLENBQUpBLFNBSDFCLE1BQWdCLENBQWhCO0FBS0EscUJBQWlCLENBQUMsQ0FBbEI7QUFDQTs7QUFFQSxRQUFJRixLQUFKLEVBQXFDLEVBV3JDOztBQUFBLGVBQW1DLEVBd0JwQztBQStFRHVNOztBQUFBQSxRQUFNLEdBQVM7QUFDYi9LLFVBQU0sQ0FBTkE7QUFHRjtBQUFBO0FBQ0Y7QUFDQTs7O0FBQ0VnTCxNQUFJLEdBQUc7QUFDTGhMLFVBQU0sQ0FBTkE7QUFHRjtBQUFBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VpTCxNQUFJLFVBQXFCOVAsT0FBMEIsR0FBL0MsSUFBc0Q7QUFDeEQsUUFBSXFELEtBQUosRUFBMkMsRUFhM0M7O0FBQUE7QUFBQyxLQUFDO0FBQUE7QUFBQTtBQUFBLFFBQWMwTSxZQUFZLFlBQTNCLEVBQTJCLENBQTNCO0FBQ0QsV0FBTyxrQ0FBUCxPQUFPLENBQVA7QUFHRjtBQUFBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V0UCxTQUFPLFVBQXFCVCxPQUEwQixHQUEvQyxJQUFzRDtBQUMzRDtBQUFDLEtBQUM7QUFBQTtBQUFBO0FBQUEsUUFBYytQLFlBQVksWUFBM0IsRUFBMkIsQ0FBM0I7QUFDRCxXQUFPLHFDQUFQLE9BQU8sQ0FBUDtBQUdGOztBQUFBLHVEQU1vQjtBQUFBOztBQUNsQixRQUFJLENBQUMxRCxVQUFVLENBQWYsR0FBZSxDQUFmLEVBQXNCO0FBQ3BCeEgsWUFBTSxDQUFOQTtBQUNBO0FBR0YsS0FOa0IsQ0FNbEI7QUFDQTs7O0FBQ0EsUUFBSzdFLE9BQUQsQ0FBSixJQUF5QjtBQUN2QjtBQUdGLEtBWmtCLENBWWxCO0FBQ0E7QUFDQTs7O0FBQ0FBLFdBQU8sQ0FBUEEsU0FBaUIsQ0FBQyxxQkFBRUEsT0FBTyxDQUFULG9DQUFsQkEsSUFBa0IsQ0FBbEJBO0FBRUEsUUFBSWdRLFlBQVksR0FBR2hRLE9BQU8sQ0FBUEEsV0FBbUIsS0FBdEM7O0FBRUEsUUFBSXFELEtBQUosRUFBcUMsc0JBZ0ZyQzs7QUFBQSxRQUFJLENBQUVyRCxPQUFELENBQUwsSUFBMEI7QUFDeEI7QUFFRixLQXRHa0IsQ0FzR2xCOzs7QUFDQSxRQUFJaVEsT0FBSixJQUFRO0FBQ05DLGlCQUFXLENBQVhBO0FBR0Y7O0FBQUEsVUFBTTtBQUFFN08sYUFBTyxHQUFUO0FBQUEsUUFBTjtBQUNBLFVBQU04TyxVQUFVLEdBQUc7QUFBbkI7QUFBbUIsS0FBbkI7O0FBRUEsUUFBSSxLQUFKLGdCQUF5QjtBQUN2Qiw4QkFBd0IsS0FBeEI7QUFHRjNQOztBQUFBQSxNQUFFLEdBQUcyTSxXQUFXLENBQ2RpRCxTQUFTLENBQ1BqRixXQUFXLENBQVhBLEVBQVcsQ0FBWEEsR0FBa0JrRixXQUFXLENBQTdCbEYsRUFBNkIsQ0FBN0JBLEdBRE8sSUFFUG5MLE9BQU8sQ0FGQSxRQUdQLEtBSkpRLGFBQ1csQ0FESyxDQUFoQkE7QUFPQSxVQUFNOFAsU0FBUyxHQUFHQyxTQUFTLENBQ3pCcEYsV0FBVyxDQUFYQSxFQUFXLENBQVhBLEdBQWtCa0YsV0FBVyxDQUE3QmxGLEVBQTZCLENBQTdCQSxHQUR5QixJQUV6QixLQUZGLE1BQTJCLENBQTNCO0FBSUEsNkJBN0hrQixDQStIbEI7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQSxRQUFJLENBQUVuTCxPQUFELENBQUQsTUFBd0IscUJBQTVCLFNBQTRCLENBQTVCLEVBQTZEO0FBQzNEO0FBQ0FvSSxZQUFNLENBQU5BLCtDQUYyRCxDQUczRDs7QUFDQTtBQUNBO0FBQ0Esa0JBQVksZ0JBQWdCLEtBQTVCLEtBQVksQ0FBWjtBQUNBQSxZQUFNLENBQU5BO0FBQ0E7QUFHRjs7QUFBQSxRQUFJb0ksTUFBTSxHQUFHLHdDQUFiLEdBQWEsQ0FBYjtBQUNBLFFBQUk7QUFBQTtBQUFBO0FBQUEsUUFBSixPQWpKa0IsQ0FtSmxCO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQSxRQUFJO0FBQ0ZsRCxXQUFLLEdBQUcsTUFBTSxnQkFBZEEsV0FBYyxFQUFkQTtBQUNDLE9BQUM7QUFBRW1ELGtCQUFVLEVBQVo7QUFBQSxVQUEyQixNQUFNLGlCQUFsQyxzQkFBa0MsR0FBbEM7QUFDRCxLQUhGLENBR0UsWUFBWTtBQUNaO0FBQ0E7QUFDQTVMLFlBQU0sQ0FBTkE7QUFDQTtBQUdGLEtBaktrQixDQWlLbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBSSxDQUFDLGNBQUQsU0FBQyxDQUFELElBQTZCLENBQWpDLGNBQWdEO0FBQzlDNkwsWUFBTSxHQUFOQTtBQUdGLEtBMUtrQixDQTBLbEI7QUFDQTs7O0FBQ0EsUUFBSTFPLFVBQVUsR0FBZCxHQTVLa0IsQ0E4S2xCO0FBQ0E7QUFDQTs7QUFDQUQsWUFBUSxHQUFHQSxRQUFRLEdBQ2YscURBQXdCc08sV0FBVyxDQURwQixRQUNvQixDQUFuQyxDQURlLEdBQW5CdE87O0FBSUEsUUFBSUEsUUFBUSxLQUFaLFdBQTRCO0FBQzFCLFVBQUlzQixLQUFKLEVBQTJELEVBQTNELE1Ba0JPO0FBQ0xtTixjQUFNLENBQU5BLFdBQWtCRyxtQkFBbUIsV0FBckNILEtBQXFDLENBQXJDQTs7QUFFQSxZQUFJQSxNQUFNLENBQU5BLGFBQUosVUFBa0M7QUFDaEN6TyxrQkFBUSxHQUFHeU8sTUFBTSxDQUFqQnpPO0FBQ0FpSixhQUFHLEdBQUcsaUNBQU5BLE1BQU0sQ0FBTkE7QUFFSDtBQUNGO0FBRUQ7O0FBQUEsVUFBTS9FLEtBQUssR0FBRyxxREFBZCxRQUFjLENBQWQ7O0FBRUEsUUFBSSxDQUFDb0csVUFBVSxDQUFmLEVBQWUsQ0FBZixFQUFxQjtBQUNuQixnQkFBMkM7QUFDekMsY0FBTSxVQUNILGtCQUFpQnJCLEdBQUksY0FBYXhLLEVBQW5DLDJDQUFDLEdBREgsb0ZBQU0sQ0FBTjtBQU1GcUU7O0FBQUFBLFlBQU0sQ0FBTkE7QUFDQTtBQUdGN0M7O0FBQUFBLGNBQVUsR0FBR3VPLFNBQVMsQ0FBQ0YsV0FBVyxDQUFaLFVBQVksQ0FBWixFQUEwQixLQUFoRHJPLE1BQXNCLENBQXRCQTs7QUFFQSxRQUFJLCtCQUFKLEtBQUksQ0FBSixFQUEyQjtBQUN6QixZQUFNNE8sUUFBUSxHQUFHLHdDQUFqQixVQUFpQixDQUFqQjtBQUNBLFlBQU1wRixVQUFVLEdBQUdvRixRQUFRLENBQTNCO0FBRUEsWUFBTUMsVUFBVSxHQUFHLCtCQUFuQixLQUFtQixDQUFuQjtBQUNBLFlBQU1DLFVBQVUsR0FBRywrQ0FBbkIsVUFBbUIsQ0FBbkI7QUFDQSxZQUFNQyxpQkFBaUIsR0FBRzlLLEtBQUssS0FBL0I7QUFDQSxZQUFNdUcsY0FBYyxHQUFHdUUsaUJBQWlCLEdBQ3BDdEUsYUFBYSxvQkFEdUIsS0FDdkIsQ0FEdUIsR0FBeEM7O0FBSUEsVUFBSSxlQUFnQnNFLGlCQUFpQixJQUFJLENBQUN2RSxjQUFjLENBQXhELFFBQWtFO0FBQ2hFLGNBQU13RSxhQUFhLEdBQUdoUSxNQUFNLENBQU5BLEtBQVk2UCxVQUFVLENBQXRCN1AsZUFDbkIwSyxLQUFELElBQVcsQ0FBQ1EsS0FBSyxDQURuQixLQUNtQixDQURHbEwsQ0FBdEI7O0FBSUEsWUFBSWdRLGFBQWEsQ0FBYkEsU0FBSixHQUE4QjtBQUM1QixvQkFBMkM7QUFDekNuUCxtQkFBTyxDQUFQQSxLQUNHLEdBQ0NrUCxpQkFBaUIsMEJBRVosaUNBSFAsOEJBQUMsR0FLRSxlQUFjQyxhQUFhLENBQWJBLFVBTm5CblA7QUFZRjs7QUFBQSxnQkFBTSxVQUNKLENBQUNrUCxpQkFBaUIsR0FDYiwwQkFBeUIvRixHQUFJLG9DQUFtQ2dHLGFBQWEsQ0FBYkEsVUFEbkQsb0NBSWIsOEJBQTZCeEYsVUFBVyw4Q0FBNkN2RixLQUoxRixTQUtHLCtDQUNDOEssaUJBQWlCLGlDQUViLHNCQVRWLEVBQU0sQ0FBTjtBQWFIO0FBaENELGFBZ0NPLHVCQUF1QjtBQUM1QnZRLFVBQUUsR0FBRyxpQ0FDSFEsTUFBTSxDQUFOQSxxQkFBNEI7QUFDMUJlLGtCQUFRLEVBQUV5SyxjQUFjLENBREU7QUFFMUJOLGVBQUssRUFBRVMsa0JBQWtCLFFBQVFILGNBQWMsQ0FIbkRoTSxNQUc2QjtBQUZDLFNBQTVCUSxDQURHLENBQUxSO0FBREssYUFPQTtBQUNMO0FBQ0FRLGNBQU0sQ0FBTkE7QUFFSDtBQUVEb0g7O0FBQUFBLFVBQU0sQ0FBTkE7O0FBRUEsUUFBSTtBQUFBOztBQUNGLFVBQUk2SSxTQUFTLEdBQUcsTUFBTSwwREFBdEIsVUFBc0IsQ0FBdEI7QUFRQSxVQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFKLFVBVEUsQ0FXRjs7QUFDQSxVQUFJLENBQUMxQixPQUFPLElBQVIsWUFBSixPQUFtQztBQUNqQyxZQUFLdE8sS0FBRCxVQUFDQSxJQUE0QkEsS0FBRCxVQUFDQSxDQUFqQyxjQUF1RTtBQUNyRSxnQkFBTWlRLFdBQVcsR0FBSWpRLEtBQUQsVUFBQ0EsQ0FBckIsYUFEcUUsQ0FHckU7QUFDQTtBQUNBOztBQUNBLGNBQUlpUSxXQUFXLENBQVhBLFdBQUosR0FBSUEsQ0FBSixFQUFpQztBQUMvQixrQkFBTUMsVUFBVSxHQUFHLHdDQUFuQixXQUFtQixDQUFuQjtBQUNBQSxzQkFBVSxDQUFWQSxXQUFzQlIsbUJBQW1CLENBQ3ZDUSxVQUFVLENBRDZCLFVBQXpDQSxLQUF5QyxDQUF6Q0E7O0FBS0EsZ0JBQUk3RCxLQUFLLENBQUxBLFNBQWU2RCxVQUFVLENBQTdCLFFBQUk3RCxDQUFKLEVBQXlDO0FBQ3ZDLG9CQUFNO0FBQUV0QyxtQkFBRyxFQUFMO0FBQWV4SyxrQkFBRSxFQUFqQjtBQUFBLGtCQUE2QnVQLFlBQVksb0JBQS9DLFdBQStDLENBQS9DO0FBS0EscUJBQU8sbUNBQVAsT0FBTyxDQUFQO0FBRUg7QUFFRGxMOztBQUFBQSxnQkFBTSxDQUFOQTtBQUNBLGlCQUFPLFlBQVksTUFBTSxDQUF6QixDQUFPLENBQVA7QUFHRjs7QUFBQSx5QkFBaUIsQ0FBQyxDQUFDNUQsS0FBSyxDQUF4QixZQTVCaUMsQ0E4QmpDOztBQUNBLFlBQUlBLEtBQUssQ0FBTEEsYUFBSixvQkFBMkM7QUFDekM7O0FBRUEsY0FBSTtBQUNGLGtCQUFNLG9CQUFOLE1BQU0sQ0FBTjtBQUNBbVEseUJBQWEsR0FBYkE7QUFDQSxXQUhGLENBR0UsVUFBVTtBQUNWQSx5QkFBYSxHQUFiQTtBQUdGSDs7QUFBQUEsbUJBQVMsR0FBRyxNQUFNLHVFQU1oQjtBQUFFNVAsbUJBQU8sRUFOWDRQO0FBTUUsV0FOZ0IsQ0FBbEJBO0FBU0g7QUFFRDdJOztBQUFBQSxZQUFNLENBQU5BO0FBQ0E7O0FBRUEsZ0JBQTJDO0FBQ3pDLGNBQU1pSixPQUFZLEdBQUcseUJBQXJCO0FBQ0V4TSxjQUFELEtBQUNBLENBQUQsYUFBQ0EsR0FDQXdNLE9BQU8sQ0FBUEEsb0JBQTRCQSxPQUFPLENBQW5DQSx1QkFDQSxDQUFFSixTQUFTLENBQVYsU0FBQ0EsQ0FGSCxlQUFDcE07QUFLSixPQTFFRSxDQTBFRjs7O0FBQ0EsWUFBTXlNLG1CQUFtQixHQUFHdFIsT0FBTyxDQUFQQSxXQUFtQixlQUEvQzs7QUFFQSxVQUNHQSxPQUFELEdBQUNBLElBQ0QrQixRQUFRLEtBRFIsU0FBQy9CLElBRUQsOEJBQUksQ0FBSiw2SkFGQSxHQUFDQSxJQUdEaUIsS0FIQSxRQUFDakIsSUFHRGlCLEtBQUssQ0FKUCxXQUtFO0FBQ0E7QUFDQTtBQUNBQSxhQUFLLENBQUxBO0FBR0Y7O0FBQUEsWUFBTSx1REFNSnNRLFlBQVksS0FDVEQsbUJBQW1CLElBQUksQ0FBQ3RSLE9BQU8sQ0FBL0JzUixnQkFBZ0Q7QUFBRUUsU0FBQyxFQUFIO0FBQVFDLFNBQUMsRUFQeEQ7QUFPK0MsT0FEdkMsQ0FOUixRQVFHclIsQ0FBRCxJQUFPO0FBQ2IsWUFBSUEsQ0FBQyxDQUFMLFdBQWlCOEcsS0FBSyxHQUFHQSxLQUFLLElBQTlCLENBQWlCQSxDQUFqQixLQUNLO0FBVlAsT0FBTSxDQUFOOztBQWFBLGlCQUFXO0FBQ1RrQixjQUFNLENBQU5BO0FBQ0E7QUFHRjs7QUFBQSxVQUFJL0UsS0FBSixFQUFxQyxFQUtyQytFOztBQUFBQSxZQUFNLENBQU5BO0FBRUE7QUFDQSxLQWxIRixDQWtIRSxZQUFZO0FBQ1osVUFBSXRJLEdBQUcsQ0FBUCxXQUFtQjtBQUNqQjtBQUVGOztBQUFBO0FBRUg7QUFFRDRSOztBQUFBQSxhQUFXLGtCQUlUMVIsT0FBMEIsR0FKakIsSUFLSDtBQUNOLGNBQTJDO0FBQ3pDLFVBQUksT0FBTzZFLE1BQU0sQ0FBYixZQUFKLGFBQTJDO0FBQ3pDaEQsZUFBTyxDQUFQQTtBQUNBO0FBR0Y7O0FBQUEsVUFBSSxPQUFPZ0QsTUFBTSxDQUFOQSxRQUFQLE1BQU9BLENBQVAsS0FBSixhQUFtRDtBQUNqRGhELGVBQU8sQ0FBUEEsTUFBZSwyQkFBMEI2TyxNQUF6QzdPO0FBQ0E7QUFFSDtBQUVEOztBQUFBLFFBQUk2TyxNQUFNLEtBQU5BLGVBQTBCLHlCQUE5QixJQUErQztBQUM3QyxzQkFBZ0IxUSxPQUFPLENBQXZCO0FBQ0EsWUFBTSxDQUFOLGdCQUNFO0FBQUE7QUFBQTtBQUFBO0FBSUUyUixXQUFHLEVBSkw7QUFLRUMsV0FBRyxFQUFFLFlBQVlsQixNQUFNLEtBQU5BLGNBQXlCLEtBQXpCQSxPQUFxQyxZQU4xRDtBQUNFLE9BREYsRUFRRTtBQUNBO0FBQ0E7QUFWRjtBQWVIO0FBRUQ7O0FBQUEsa0ZBT3FDO0FBQ25DLFFBQUk1USxHQUFHLENBQVAsV0FBbUI7QUFDakI7QUFDQTtBQUdGOztBQUFBLFFBQUksdUNBQUosZUFBd0M7QUFDdENzSSxZQUFNLENBQU5BLHFEQURzQyxDQUd0QztBQUNBO0FBQ0E7QUFDQTtBQUVBOztBQUNBdkQsWUFBTSxDQUFOQSxtQkFUc0MsQ0FXdEM7QUFDQTs7QUFDQSxZQUFNZ04sc0JBQU47QUFHRjs7QUFBQSxRQUFJO0FBQ0Y7QUFDQTtBQUNBOztBQUVBLFVBQ0Usb0NBQ0EsdUJBRkYsYUFHRTtBQUNBO0FBQUMsU0FBQztBQUFFdEUsY0FBSSxFQUFOO0FBQUE7QUFBQSxZQUFtQyxNQUFNLG9CQUExQyxTQUEwQyxDQUExQztBQUtIOztBQUFBLFlBQU0wRCxTQUFtQyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLMUMvSixhQUFLLEVBTFA7QUFBNEMsT0FBNUM7O0FBUUEsVUFBSSxDQUFDK0osU0FBUyxDQUFkLE9BQXNCO0FBQ3BCLFlBQUk7QUFDRkEsbUJBQVMsQ0FBVEEsUUFBa0IsTUFBTSxnQ0FBZ0M7QUFBQTtBQUFBO0FBQXhEQTtBQUF3RCxXQUFoQyxDQUF4QkE7QUFLQSxTQU5GLENBTUUsZUFBZTtBQUNmcFAsaUJBQU8sQ0FBUEE7QUFDQW9QLG1CQUFTLENBQVRBO0FBRUg7QUFFRDs7QUFBQTtBQUNBLEtBcENGLENBb0NFLHFCQUFxQjtBQUNyQixhQUFPLHlFQUFQLElBQU8sQ0FBUDtBQVNIO0FBRUQ7O0FBQUEseUVBTzZCO0FBQzNCLFFBQUk7QUFDRixZQUFNYSxpQkFBK0MsR0FBRyxnQkFBeEQsS0FBd0QsQ0FBeEQ7O0FBR0EsVUFBSTNCLFVBQVUsQ0FBVkEsZ0NBQTJDLGVBQS9DLE9BQXFFO0FBQ25FO0FBR0Y7O0FBQUEsWUFBTTRCLGVBQXFELEdBQ3pERCxpQkFBaUIsSUFBSSxhQUFyQkEsZ0NBREY7QUFJQSxZQUFNYixTQUFtQyxHQUFHYyxlQUFlLHFCQUV2RCxNQUFNLGdDQUFpQy9NLEdBQUQsS0FBVTtBQUM5QzBLLGlCQUFTLEVBQUUxSyxHQUFHLENBRGdDO0FBRTlDc0IsbUJBQVcsRUFBRXRCLEdBQUcsQ0FGOEI7QUFHOUN1SyxlQUFPLEVBQUV2SyxHQUFHLENBQUhBLElBSHFDO0FBSTlDeUssZUFBTyxFQUFFekssR0FBRyxDQUFIQSxJQU5mO0FBRW9ELE9BQVYsQ0FBaEMsQ0FGVjtBQVNBLFlBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFOOztBQUVBLGdCQUEyQztBQUN6QyxjQUFNO0FBQUE7QUFBQSxZQUF5QmdOLG1CQUFPLENBQXRDLDBCQUFzQyxDQUF0Qzs7QUFDQSxZQUFJLENBQUNDLGtCQUFrQixDQUF2QixTQUF1QixDQUF2QixFQUFvQztBQUNsQyxnQkFBTSxVQUNILHlEQUF3RGxRLFFBRDNELEdBQU0sQ0FBTjtBQUlIO0FBRUQ7O0FBQUE7O0FBRUEsVUFBSXdOLE9BQU8sSUFBWCxTQUF3QjtBQUN0QjJDLGdCQUFRLEdBQUcsNEJBQ1QsaUNBQXFCO0FBQUE7QUFEWjtBQUNZLFNBQXJCLENBRFMsdUJBSVQsS0FKRkEsTUFBVyxDQUFYQTtBQVFGOztBQUFBLFlBQU1qUixLQUFLLEdBQUcsTUFBTSxjQUF3QyxNQUMxRHNPLE9BQU8sR0FDSCxvQkFERyxRQUNILENBREcsR0FFSEUsT0FBTyxHQUNQLG9CQURPLFFBQ1AsQ0FETyxHQUVQLGdDQUVFO0FBQ0E7QUFBQTtBQUFBO0FBR0V4QixjQUFNLEVBWGhCO0FBUVEsT0FIRixDQUxjLENBQXBCO0FBZ0JBZ0QsZUFBUyxDQUFUQTtBQUNBO0FBQ0E7QUFDQSxLQTlERixDQThERSxZQUFZO0FBQ1osYUFBTyxvREFBUCxVQUFPLENBQVA7QUFFSDtBQUVEa0I7O0FBQUFBLEtBQUcsZ0RBT2M7QUFDZjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBTyxrQkFBUCxXQUFPLENBQVA7QUFHRjtBQUFBO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRUMsZ0JBQWMsS0FBNkI7QUFDekM7QUFHRkM7O0FBQUFBLGlCQUFlLEtBQXNCO0FBQ25DLFFBQUksQ0FBQyxLQUFMLFFBQWtCO0FBQ2xCLFVBQU0sMEJBQTBCLGtCQUFoQyxHQUFnQyxDQUFoQztBQUNBLFVBQU0sMEJBQTBCN1IsRUFBRSxDQUFGQSxNQUFoQyxHQUFnQ0EsQ0FBaEMsQ0FIbUMsQ0FLbkM7O0FBQ0EsUUFBSThSLE9BQU8sSUFBSUMsWUFBWSxLQUF2QkQsZ0JBQTRDRSxPQUFPLEtBQXZELFNBQXFFO0FBQ25FO0FBR0YsS0FWbUMsQ0FVbkM7OztBQUNBLFFBQUlELFlBQVksS0FBaEIsY0FBbUM7QUFDakM7QUFHRixLQWZtQyxDQWVuQztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBT0MsT0FBTyxLQUFkO0FBR0ZDOztBQUFBQSxjQUFZLEtBQW1CO0FBQzdCLFVBQU0sV0FBV2pTLEVBQUUsQ0FBRkEsTUFBakIsR0FBaUJBLENBQWpCLENBRDZCLENBRTdCO0FBQ0E7O0FBQ0EsUUFBSWtNLElBQUksS0FBSkEsTUFBZUEsSUFBSSxLQUF2QixPQUFtQztBQUNqQzdILFlBQU0sQ0FBTkE7QUFDQTtBQUdGLEtBVDZCLENBUzdCOzs7QUFDQSxVQUFNNk4sSUFBSSxHQUFHOU4sUUFBUSxDQUFSQSxlQUFiLElBQWFBLENBQWI7O0FBQ0EsY0FBVTtBQUNSOE4sVUFBSSxDQUFKQTtBQUNBO0FBRUYsS0FmNkIsQ0FlN0I7QUFDQTs7O0FBQ0EsVUFBTUMsTUFBTSxHQUFHL04sUUFBUSxDQUFSQSx3QkFBZixDQUFlQSxDQUFmOztBQUNBLGdCQUFZO0FBQ1YrTixZQUFNLENBQU5BO0FBRUg7QUFFREM7O0FBQUFBLFVBQVEsU0FBMEI7QUFDaEMsV0FBTyxnQkFBUDtBQUdGO0FBQUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRSxzQkFFRTNFLE1BQWMsR0FGaEIsS0FHRWpPLE9BQXdCLEdBSDFCLElBSWlCO0FBQ2YsUUFBSXdRLE1BQU0sR0FBRyx3Q0FBYixHQUFhLENBQWI7QUFFQSxRQUFJO0FBQUE7QUFBQSxRQUFKOztBQUVBLFFBQUluTixLQUFKLEVBQXFDLEVBaUJyQzs7QUFBQSxVQUFNaUssS0FBSyxHQUFHLE1BQU0sZ0JBQXBCLFdBQW9CLEVBQXBCO0FBQ0EsUUFBSXRMLFVBQVUsR0FBZDs7QUFFQSxRQUFJcUIsS0FBSixFQUErRCxFQUEvRCxNQXFCTztBQUNMbU4sWUFBTSxDQUFOQSxXQUFrQkcsbUJBQW1CLENBQUNILE1BQU0sQ0FBUCxVQUFyQ0EsS0FBcUMsQ0FBckNBOztBQUVBLFVBQUlBLE1BQU0sQ0FBTkEsYUFBSixVQUFrQztBQUNoQ3pPLGdCQUFRLEdBQUd5TyxNQUFNLENBQWpCek87QUFDQWlKLFdBQUcsR0FBRyxpQ0FBTkEsTUFBTSxDQUFOQTtBQUVIO0FBQ0Q7O0FBQUEsVUFBTS9FLEtBQUssR0FBRyxxREFBZCxRQUFjLENBQWQsQ0F0RGUsQ0F3RGY7O0FBQ0EsY0FBMkM7QUFDekM7QUFHRjs7QUFBQSxVQUFNN0IsT0FBTyxDQUFQQSxJQUFZLENBQ2hCLG1DQUFvQ3lPLEtBQUQsSUFBb0I7QUFDckQsYUFBT0EsS0FBSyxHQUNSLG9CQUNFLG1EQUlFLE9BQU83UyxPQUFPLENBQWQseUJBQ0lBLE9BQU8sQ0FEWCxTQUVJLEtBUkEsTUFFTixDQURGLENBRFEsR0FBWjtBQUZjLEtBQ2hCLENBRGdCLEVBZWhCLGdCQUFnQkEsT0FBTyxDQUFQQSx3QkFBaEIsWUFmRixLQWVFLENBZmdCLENBQVpvRSxDQUFOO0FBbUJGOztBQUFBLDhCQUE0RDtBQUMxRCxRQUFJbUIsU0FBUyxHQUFiOztBQUNBLFVBQU11TixNQUFNLEdBQUksV0FBVyxNQUFNO0FBQy9Cdk4sZUFBUyxHQUFUQTtBQURGOztBQUlBLFVBQU13TixlQUFlLEdBQUcsTUFBTSx5QkFBOUIsS0FBOEIsQ0FBOUI7O0FBRUEsbUJBQWU7QUFDYixZQUFNN0wsS0FBVSxHQUFHLFVBQ2hCLHdDQUF1Q2pCLEtBRDFDLEdBQW1CLENBQW5CO0FBR0FpQixXQUFLLENBQUxBO0FBQ0E7QUFHRjs7QUFBQSxRQUFJNEwsTUFBTSxLQUFLLEtBQWYsS0FBeUI7QUFDdkI7QUFHRjs7QUFBQTtBQUdGRTs7QUFBQUEsVUFBUSxLQUFzQztBQUM1QyxRQUFJek4sU0FBUyxHQUFiOztBQUNBLFVBQU11TixNQUFNLEdBQUcsTUFBTTtBQUNuQnZOLGVBQVMsR0FBVEE7QUFERjs7QUFHQTtBQUNBLFdBQU93QixFQUFFLEdBQUZBLEtBQVc4RyxJQUFELElBQVU7QUFDekIsVUFBSWlGLE1BQU0sS0FBSyxLQUFmLEtBQXlCO0FBQ3ZCO0FBR0Y7O0FBQUEscUJBQWU7QUFDYixjQUFNaFQsR0FBUSxHQUFHLFVBQWpCLGlDQUFpQixDQUFqQjtBQUNBQSxXQUFHLENBQUhBO0FBQ0E7QUFHRjs7QUFBQTtBQVhGLEtBQU9pSCxDQUFQO0FBZUZrTTs7QUFBQUEsZ0JBQWMsV0FBb0M7QUFDaEQsVUFBTTtBQUFFaFQsVUFBSSxFQUFOO0FBQUEsUUFBcUIsa0JBQWtCNEUsTUFBTSxDQUFOQSxTQUE3QyxJQUEyQixDQUEzQjs7QUFDQSxRQUNFeEIsS0FERixFQUlFLEVBR0Y7O0FBQUEsV0FBTzZQLGFBQWEsV0FBVyxLQUF4QkEsS0FBYSxDQUFiQSxNQUEwQ3JGLElBQUQsSUFBVTtBQUN4RDtBQUNBO0FBRkYsS0FBT3FGLENBQVA7QUFNRkM7O0FBQUFBLGdCQUFjLFdBQW9DO0FBQ2hELFVBQU07QUFBRWxULFVBQUksRUFBTjtBQUFBLFFBQXdCLGtCQUFrQjRFLE1BQU0sQ0FBTkEsU0FBaEQsSUFBOEIsQ0FBOUI7O0FBQ0EsUUFBSSxTQUFKLFdBQUksQ0FBSixFQUEyQjtBQUN6QixhQUFPLFNBQVAsV0FBTyxDQUFQO0FBRUY7O0FBQUEsV0FBUSx3QkFBd0JxTyxhQUFhLFdBQVcsS0FBeEJBLEtBQWEsQ0FBYkEsTUFDdkJyRixJQUFELElBQVU7QUFDZCxhQUFPLFNBQVAsV0FBTyxDQUFQO0FBQ0E7QUFINEJxRixhQUt0QnBULEdBQUQsSUFBUztBQUNkLGFBQU8sU0FBUCxXQUFPLENBQVA7QUFDQTtBQVBKLEtBQWdDb1QsQ0FBaEM7QUFXRm5KOztBQUFBQSxpQkFBZSxpQkFHQztBQUNkLFVBQU07QUFBRTJGLGVBQVMsRUFBWDtBQUFBLFFBQXFCLGdCQUEzQixPQUEyQixDQUEzQjs7QUFDQSxVQUFNMEQsT0FBTyxHQUFHLGNBQWhCLEdBQWdCLENBQWhCOztBQUNBQyxPQUFHLENBQUhBO0FBQ0EsV0FBTyxxQ0FBaUQ7QUFBQTtBQUFBO0FBR3REeFQsWUFBTSxFQUhnRDtBQUF4RDtBQUF3RCxLQUFqRCxDQUFQO0FBUUZ5VDs7QUFBQUEsb0JBQWtCLGlCQUFnRDtBQUNoRSxRQUFJLEtBQUosS0FBYztBQUNabEwsWUFBTSxDQUFOQSxnQ0FFRXlKLHNCQUZGeko7QUFNQTtBQUNBO0FBRUg7QUFFRG1MOztBQUFBQSxRQUFNLG9CQUdXO0FBQ2YsV0FBTyxlQUVMLHlCQUZLLFdBQVAsV0FBTyxDQUFQO0FBem9DOEM7O0FBQUE7OztBQUE3Qm5MLE0sQ0FvQ1pxRyxNQXBDWXJHLEdBb0NVLG9CQXBDVkEsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Y3JCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeEJBLEMsQ0FBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQU1BLE1BQU1vTCxnQkFBZ0IsR0FBdEI7O0FBRU8sMkJBQXNDO0FBQzNDLE1BQUk7QUFBQTtBQUFBO0FBQUEsTUFBSjtBQUNBLE1BQUlDLFFBQVEsR0FBR0MsTUFBTSxDQUFOQSxZQUFmO0FBQ0EsTUFBSTNSLFFBQVEsR0FBRzJSLE1BQU0sQ0FBTkEsWUFBZjtBQUNBLE1BQUloSCxJQUFJLEdBQUdnSCxNQUFNLENBQU5BLFFBQVg7QUFDQSxNQUFJeEgsS0FBSyxHQUFHd0gsTUFBTSxDQUFOQSxTQUFaO0FBQ0EsTUFBSUMsSUFBb0IsR0FBeEI7QUFFQUMsTUFBSSxHQUFHQSxJQUFJLEdBQUc3SCxrQkFBa0IsQ0FBbEJBLElBQWtCLENBQWxCQSx3QkFBSCxNQUFYNkg7O0FBRUEsTUFBSUYsTUFBTSxDQUFWLE1BQWlCO0FBQ2ZDLFFBQUksR0FBR0MsSUFBSSxHQUFHRixNQUFNLENBQXBCQztBQURGLFNBRU8sY0FBYztBQUNuQkEsUUFBSSxHQUFHQyxJQUFJLElBQUksQ0FBQ0MsUUFBUSxDQUFSQSxRQUFELEdBQUNBLENBQUQsR0FBMEIsSUFBR0EsUUFBN0IsTUFBZkYsUUFBVyxDQUFYQTs7QUFDQSxRQUFJRCxNQUFNLENBQVYsTUFBaUI7QUFDZkMsVUFBSSxJQUFJLE1BQU1ELE1BQU0sQ0FBcEJDO0FBRUg7QUFFRDs7QUFBQSxNQUFJekgsS0FBSyxJQUFJLGlCQUFiLFVBQXdDO0FBQ3RDQSxTQUFLLEdBQUc0SCxNQUFNLENBQUNDLFdBQVcsQ0FBWEEsdUJBQWY3SCxLQUFlNkgsQ0FBRCxDQUFkN0g7QUFHRjs7QUFBQSxNQUFJOEgsTUFBTSxHQUFHTixNQUFNLENBQU5BLFVBQWtCeEgsS0FBSyxJQUFLLElBQUdBLEtBQS9Cd0gsTUFBYjtBQUVBLE1BQUlELFFBQVEsSUFBSUEsUUFBUSxDQUFSQSxPQUFnQixDQUFoQkEsT0FBaEIsS0FBNkNBLFFBQVEsSUFBUkE7O0FBRTdDLE1BQ0VDLE1BQU0sQ0FBTkEsV0FDQyxDQUFDLGFBQWFGLGdCQUFnQixDQUFoQkEsS0FBZCxRQUFjQSxDQUFkLEtBQWtERyxJQUFJLEtBRnpELE9BR0U7QUFDQUEsUUFBSSxHQUFHLFFBQVFBLElBQUksSUFBbkJBLEVBQU8sQ0FBUEE7QUFDQSxRQUFJNVIsUUFBUSxJQUFJQSxRQUFRLENBQVJBLENBQVEsQ0FBUkEsS0FBaEIsS0FBcUNBLFFBQVEsR0FBRyxNQUFYQTtBQUx2QyxTQU1PLElBQUksQ0FBSixNQUFXO0FBQ2hCNFIsUUFBSSxHQUFKQTtBQUdGOztBQUFBLE1BQUlqSCxJQUFJLElBQUlBLElBQUksQ0FBSkEsQ0FBSSxDQUFKQSxLQUFaLEtBQTZCQSxJQUFJLEdBQUcsTUFBUEE7QUFDN0IsTUFBSXNILE1BQU0sSUFBSUEsTUFBTSxDQUFOQSxDQUFNLENBQU5BLEtBQWQsS0FBaUNBLE1BQU0sR0FBRyxNQUFUQTtBQUVqQ2pTLFVBQVEsR0FBR0EsUUFBUSxDQUFSQSxpQkFBWEEsa0JBQVdBLENBQVhBO0FBQ0FpUyxRQUFNLEdBQUdBLE1BQU0sQ0FBTkEsYUFBVEEsS0FBU0EsQ0FBVEE7QUFFQSxTQUFRLEdBQUVQLFFBQVMsR0FBRUUsSUFBSyxHQUFFNVIsUUFBUyxHQUFFaVMsTUFBTyxHQUFFdEgsSUFBaEQ7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7eUNDeEVEOztBQUNBLE1BQU11SCxVQUFVLEdBQWhCOztBQUVPLCtCQUFnRDtBQUNyRCxTQUFPQSxVQUFVLENBQVZBLEtBQVAsS0FBT0EsQ0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEQ7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNPLHFDQUFzRDtBQUMzRCxRQUFNQyxVQUFVLEdBQUcsUUFDakIsb0JBQTZDLFNBRDVCLENBQW5CO0FBR0EsUUFBTUMsWUFBWSxHQUFHaEksSUFBSSxHQUFHLGNBQUgsVUFBRyxDQUFILEdBQXpCO0FBQ0EsUUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQXlELGFBQS9ELFlBQStELENBQS9EOztBQUlBLE1BQUlVLE1BQU0sS0FBS3FILFVBQVUsQ0FBekIsUUFBa0M7QUFDaEMsVUFBTSxVQUFXLG9EQUFtRGxKLEdBQXBFLEVBQU0sQ0FBTjtBQUVGOztBQUFBLFNBQU87QUFBQTtBQUVMa0IsU0FBSyxFQUFFLHlDQUZGLFlBRUUsQ0FGRjtBQUFBO0FBQUE7QUFLTGpNLFFBQUksRUFBRUEsSUFBSSxDQUFKQSxNQUFXaVUsVUFBVSxDQUFWQSxPQUxuQixNQUtRalU7QUFMRCxHQUFQO0FBT0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCTSw4Q0FFVztBQUNoQixRQUFNaU0sS0FBcUIsR0FBM0I7QUFDQWtJLGNBQVksQ0FBWkEsUUFBcUIsZ0JBQWdCO0FBQ25DLFFBQUksT0FBT2xJLEtBQUssQ0FBWixHQUFZLENBQVosS0FBSixhQUF1QztBQUNyQ0EsV0FBSyxDQUFMQSxHQUFLLENBQUxBO0FBREYsV0FFTyxJQUFJbkQsS0FBSyxDQUFMQSxRQUFjbUQsS0FBSyxDQUF2QixHQUF1QixDQUFuQm5ELENBQUosRUFBK0I7QUFDcEM7QUFBRW1ELFdBQUssQ0FBTixHQUFNLENBQUxBLENBQUQsSUFBQ0EsQ0FBRCxLQUFDQTtBQURHLFdBRUE7QUFDTEEsV0FBSyxDQUFMQSxHQUFLLENBQUxBLEdBQWEsQ0FBQ0EsS0FBSyxDQUFOLEdBQU0sQ0FBTixFQUFiQSxLQUFhLENBQWJBO0FBRUg7QUFSRGtJO0FBU0E7QUFHRjs7QUFBQSx1Q0FBdUQ7QUFDckQsTUFDRSw2QkFDQyw2QkFBNkIsQ0FBQ0MsS0FBSyxDQURwQyxLQUNvQyxDQURwQyxJQUVBLGlCQUhGLFdBSUU7QUFDQSxXQUFPUCxNQUFNLENBQWIsS0FBYSxDQUFiO0FBTEYsU0FNTztBQUNMO0FBRUg7QUFFTTs7QUFBQSwwQ0FFWTtBQUNqQixRQUFNOUgsTUFBTSxHQUFHLElBQWYsZUFBZSxFQUFmO0FBQ0FoTCxRQUFNLENBQU5BLDBCQUFpQyxDQUFDLE1BQUQsS0FBQyxDQUFELEtBQWtCO0FBQ2pELFFBQUkrSCxLQUFLLENBQUxBLFFBQUosS0FBSUEsQ0FBSixFQUEwQjtBQUN4QnJFLFdBQUssQ0FBTEEsUUFBZTRQLElBQUQsSUFBVXRJLE1BQU0sQ0FBTkEsWUFBbUJ1SSxzQkFBc0IsQ0FBakU3UCxJQUFpRSxDQUF6Q3NILENBQXhCdEg7QUFERixXQUVPO0FBQ0xzSCxZQUFNLENBQU5BLFNBQWdCdUksc0JBQXNCLENBQXRDdkksS0FBc0MsQ0FBdENBO0FBRUg7QUFORGhMO0FBT0E7QUFHSzs7QUFBQSx3QkFFTCxHQUZLLGtCQUdZO0FBQ2pCd1Qsa0JBQWdCLENBQWhCQSxRQUEwQkosWUFBRCxJQUFrQjtBQUN6Q3JMLFNBQUssQ0FBTEEsS0FBV3FMLFlBQVksQ0FBdkJyTCxJQUFXcUwsRUFBWHJMLFVBQXlDcEksR0FBRCxJQUFTUixNQUFNLENBQU5BLE9BQWpENEksR0FBaUQ1SSxDQUFqRDRJO0FBQ0FxTCxnQkFBWSxDQUFaQSxRQUFxQixnQkFBZ0JqVSxNQUFNLENBQU5BLFlBQXJDaVUsS0FBcUNqVSxDQUFyQ2lVO0FBRkZJO0FBSUE7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JEYywyQkFBMkIsQ0FBRSxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0VyQyxxQ0FBdUU7QUFDNUUsUUFBTTtBQUFBO0FBQUE7QUFBQSxNQUFOO0FBQ0EsU0FBUXpTLFFBQUQsSUFBeUM7QUFDOUMsVUFBTStPLFVBQVUsR0FBRzJELEVBQUUsQ0FBRkEsS0FBbkIsUUFBbUJBLENBQW5COztBQUNBLFFBQUksQ0FBSixZQUFpQjtBQUNmO0FBR0Y7O0FBQUEsVUFBTUMsTUFBTSxHQUFJaEosS0FBRCxJQUFtQjtBQUNoQyxVQUFJO0FBQ0YsZUFBT2lKLGtCQUFrQixDQUF6QixLQUF5QixDQUF6QjtBQUNBLE9BRkYsQ0FFRSxVQUFVO0FBQ1YsY0FBTTdVLEdBQThCLEdBQUcsVUFBdkMsd0JBQXVDLENBQXZDO0FBR0FBLFdBQUcsQ0FBSEE7QUFDQTtBQUVIO0FBVkQ7O0FBV0EsVUFBTTJMLE1BQWtELEdBQXhEO0FBRUF6SyxVQUFNLENBQU5BLHFCQUE2QjRULFFBQUQsSUFBc0I7QUFDaEQsWUFBTUMsQ0FBQyxHQUFHQyxNQUFNLENBQWhCLFFBQWdCLENBQWhCO0FBQ0EsWUFBTUMsQ0FBQyxHQUFHakUsVUFBVSxDQUFDK0QsQ0FBQyxDQUF0QixHQUFvQixDQUFwQjs7QUFDQSxVQUFJRSxDQUFDLEtBQUwsV0FBcUI7QUFDbkJ0SixjQUFNLENBQU5BLFFBQU0sQ0FBTkEsR0FBbUIsQ0FBQ3NKLENBQUMsQ0FBREEsUUFBRCxHQUFDQSxDQUFELEdBQ2ZBLENBQUMsQ0FBREEsZUFBa0I3USxLQUFELElBQVd3USxNQUFNLENBRG5CLEtBQ21CLENBQWxDSyxDQURlLEdBRWZGLENBQUMsQ0FBREEsU0FDQSxDQUFDSCxNQUFNLENBRFBHLENBQ08sQ0FBUCxDQURBQSxHQUVBSCxNQUFNLENBSlZqSixDQUlVLENBSlZBO0FBTUg7QUFWRHpLO0FBV0E7QUE5QkY7QUFnQ0QsQzs7Ozs7Ozs7Ozs7Ozs7O3VDQzlCRDtBQUNBOztBQUNBLDBCQUFrQztBQUNoQyxTQUFPZ1UsR0FBRyxDQUFIQSxnQ0FBUCxNQUFPQSxDQUFQO0FBR0Y7O0FBQUEsK0JBQXVDO0FBQ3JDLFFBQU1uSixRQUFRLEdBQUdILEtBQUssQ0FBTEEsbUJBQXlCQSxLQUFLLENBQUxBLFNBQTFDLEdBQTBDQSxDQUExQzs7QUFDQSxnQkFBYztBQUNaQSxTQUFLLEdBQUdBLEtBQUssQ0FBTEEsU0FBZSxDQUF2QkEsQ0FBUUEsQ0FBUkE7QUFFRjs7QUFBQSxRQUFNRSxNQUFNLEdBQUdGLEtBQUssQ0FBTEEsV0FBZixLQUFlQSxDQUFmOztBQUNBLGNBQVk7QUFDVkEsU0FBSyxHQUFHQSxLQUFLLENBQUxBLE1BQVJBLENBQVFBLENBQVJBO0FBRUY7O0FBQUEsU0FBTztBQUFFL0ssT0FBRyxFQUFMO0FBQUE7QUFBUDtBQUFPLEdBQVA7QUFHSzs7QUFBQSx3Q0FPTDtBQUNBLFFBQU1zVSxRQUFRLEdBQUcsQ0FBQ0MsZUFBZSxDQUFmQSxzQkFBRCxvQkFBakIsR0FBaUIsQ0FBakI7QUFJQSxRQUFNSixNQUFzQyxHQUE1QztBQUNBLE1BQUlLLFVBQVUsR0FBZDtBQUNBLFFBQU1DLGtCQUFrQixHQUFHSCxRQUFRLENBQVJBLElBQ25CbkosT0FBRCxJQUFhO0FBQ2hCLFFBQUlBLE9BQU8sQ0FBUEEsbUJBQTJCQSxPQUFPLENBQVBBLFNBQS9CLEdBQStCQSxDQUEvQixFQUFzRDtBQUNwRCxZQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBNEJ1SixjQUFjLENBQUN2SixPQUFPLENBQVBBLFNBQWlCLENBQWxFLENBQWlEQSxDQUFELENBQWhEO0FBQ0FnSixZQUFNLENBQU5BLEdBQU0sQ0FBTkEsR0FBYztBQUFFUSxXQUFHLEVBQUVILFVBQVA7QUFBQTtBQUFkTDtBQUFjLE9BQWRBO0FBQ0EsYUFBT2xKLE1BQU0sR0FBSUMsUUFBUSxtQkFBWixXQUFiO0FBSEYsV0FJTztBQUNMLGFBQVEsSUFBRzBKLFdBQVcsU0FBdEI7QUFFSDtBQVR3Qk4sVUFBM0IsRUFBMkJBLENBQTNCLENBUEEsQ0FtQkE7QUFDQTs7QUFDQSxZQUFtQztBQUNqQyxRQUFJTyxnQkFBZ0IsR0FBcEI7QUFDQSxRQUFJQyxrQkFBa0IsR0FBdEIsRUFGaUMsQ0FJakM7O0FBQ0EsVUFBTUMsZUFBZSxHQUFHLE1BQU07QUFDNUIsVUFBSUMsUUFBUSxHQUFaOztBQUVBLFdBQUssSUFBSUMsQ0FBQyxHQUFWLEdBQWdCQSxDQUFDLEdBQWpCLG9CQUF3Q0EsQ0FBeEMsSUFBNkM7QUFDM0NELGdCQUFRLElBQUk3QixNQUFNLENBQU5BLGFBQVo2QixnQkFBWTdCLENBQVo2QjtBQUNBSCx3QkFBZ0I7O0FBRWhCLFlBQUlBLGdCQUFnQixHQUFwQixLQUE0QjtBQUMxQkMsNEJBQWtCO0FBQ2xCRCwwQkFBZ0IsR0FBaEJBO0FBRUg7QUFDRDs7QUFBQTtBQVpGOztBQWVBLFVBQU1LLFNBQXNDLEdBQTVDO0FBRUEsUUFBSUMsdUJBQXVCLEdBQUdiLFFBQVEsQ0FBUkEsSUFDdEJuSixPQUFELElBQWE7QUFDaEIsVUFBSUEsT0FBTyxDQUFQQSxtQkFBMkJBLE9BQU8sQ0FBUEEsU0FBL0IsR0FBK0JBLENBQS9CLEVBQXNEO0FBQ3BELGNBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUE0QnVKLGNBQWMsQ0FBQ3ZKLE9BQU8sQ0FBUEEsU0FBaUIsQ0FBbEUsQ0FBaURBLENBQUQsQ0FBaEQsQ0FEb0QsQ0FFcEQ7QUFDQTs7QUFDQSxZQUFJaUssVUFBVSxHQUFHcFYsR0FBRyxDQUFIQSxlQUFqQixFQUFpQkEsQ0FBakI7QUFDQSxZQUFJcVYsVUFBVSxHQUFkLE1BTG9ELENBT3BEO0FBQ0E7O0FBQ0EsWUFBSUQsVUFBVSxDQUFWQSxnQkFBMkJBLFVBQVUsQ0FBVkEsU0FBL0IsSUFBdUQ7QUFDckRDLG9CQUFVLEdBQVZBO0FBRUY7O0FBQUEsWUFBSSxDQUFDM0IsS0FBSyxDQUFDNEIsUUFBUSxDQUFDRixVQUFVLENBQVZBLFVBQXBCLENBQW9CQSxDQUFELENBQVQsQ0FBVixFQUErQztBQUM3Q0Msb0JBQVUsR0FBVkE7QUFHRjs7QUFBQSx3QkFBZ0I7QUFDZEQsb0JBQVUsR0FBR0wsZUFBYks7QUFHRkY7O0FBQUFBLGlCQUFTLENBQVRBLFVBQVMsQ0FBVEE7QUFDQSxlQUFPakssTUFBTSxHQUNUQyxRQUFRLEdBQ0wsVUFBU2tLLFVBREosWUFFTCxPQUFNQSxVQUhBLFVBSVIsT0FBTUEsVUFKWDtBQXJCRixhQTBCTztBQUNMLGVBQVEsSUFBR1IsV0FBVyxTQUF0QjtBQUVIO0FBL0IyQk4sWUFBOUIsRUFBOEJBLENBQTlCO0FBa0NBLFdBQU87QUFDTFIsUUFBRSxFQUFFLFdBQVksSUFBR1csa0JBRGQsU0FDRCxDQURDO0FBQUE7QUFBQTtBQUlMYyxnQkFBVSxFQUFHLElBQUdKLHVCQUpsQjtBQUFPLEtBQVA7QUFRRjs7QUFBQSxTQUFPO0FBQ0xyQixNQUFFLEVBQUUsV0FBWSxJQUFHVyxrQkFEZCxTQUNELENBREM7QUFBUDtBQUFPLEdBQVA7QUFJRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEQ7QUE0UUE7QUFDQTtBQUNBOzs7QUFDTyxzQkFFRjtBQUNILE1BQUllLElBQUksR0FBUjtBQUNBO0FBRUEsU0FBUSxDQUFDLEdBQUQsU0FBb0I7QUFDMUIsUUFBSSxDQUFKLE1BQVc7QUFDVEEsVUFBSSxHQUFKQTtBQUNBbkssWUFBTSxHQUFHakYsRUFBRSxDQUFDLEdBQVppRixJQUFXLENBQVhBO0FBRUY7O0FBQUE7QUFMRjtBQVNLOztBQUFBLDZCQUE2QjtBQUNsQyxRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBK0JuSCxNQUFNLENBQTNDO0FBQ0EsU0FBUSxHQUFFNE8sUUFBUyxLQUFJSSxRQUFTLEdBQUV1QyxJQUFJLEdBQUcsTUFBSCxPQUFnQixFQUF0RDtBQUdLOztBQUFBLGtCQUFrQjtBQUN2QixRQUFNO0FBQUE7QUFBQSxNQUFXdlIsTUFBTSxDQUF2QjtBQUNBLFFBQU1nSSxNQUFNLEdBQUd3SixpQkFBZjtBQUNBLFNBQU9wVyxJQUFJLENBQUpBLFVBQWU0TSxNQUFNLENBQTVCLE1BQU81TSxDQUFQO0FBR0s7O0FBQUEsbUNBQXdEO0FBQzdELFNBQU8sNENBRUh5UCxTQUFTLENBQVRBLGVBQXlCQSxTQUFTLENBQWxDQSxRQUZKO0FBS0s7O0FBQUEsd0JBQXdDO0FBQzdDLFNBQU8xSyxHQUFHLENBQUhBLFlBQWdCQSxHQUFHLENBQTFCO0FBR0s7O0FBQUEsNkNBSWtEO0FBQ3ZELFlBQTJDO0FBQUE7O0FBQ3pDLDBCQUFJc1IsR0FBRyxDQUFQLHNCQUFJQSxlQUFKLGlCQUFvQztBQUNsQyxZQUFNN04sT0FBTyxHQUFJLElBQUc4TixjQUFjLEtBQWxDO0FBR0EsWUFBTSxVQUFOLE9BQU0sQ0FBTjtBQUVIO0FBQ0QsR0FUdUQsQ0FTdkQ7OztBQUNBLFFBQU12UixHQUFHLEdBQUdxTyxHQUFHLENBQUhBLE9BQVlBLEdBQUcsQ0FBSEEsT0FBV0EsR0FBRyxDQUFIQSxJQUFuQzs7QUFFQSxNQUFJLENBQUNpRCxHQUFHLENBQVIsaUJBQTBCO0FBQ3hCLFFBQUlqRCxHQUFHLENBQUhBLE9BQVdBLEdBQUcsQ0FBbEIsV0FBOEI7QUFDNUI7QUFDQSxhQUFPO0FBQ0xtRCxpQkFBUyxFQUFFLE1BQU1DLG1CQUFtQixDQUFDcEQsR0FBRyxDQUFKLFdBQWdCQSxHQUFHLENBRHpELEdBQ3NDO0FBRC9CLE9BQVA7QUFJRjs7QUFBQTtBQUdGOztBQUFBLFFBQU1wUyxLQUFLLEdBQUcsTUFBTXFWLEdBQUcsQ0FBSEEsZ0JBQXBCLEdBQW9CQSxDQUFwQjs7QUFFQSxNQUFJdFIsR0FBRyxJQUFJMFIsU0FBUyxDQUFwQixHQUFvQixDQUFwQixFQUEyQjtBQUN6QjtBQUdGOztBQUFBLE1BQUksQ0FBSixPQUFZO0FBQ1YsVUFBTWpPLE9BQU8sR0FBSSxJQUFHOE4sY0FBYyxLQUVoQywrREFBOER0VixLQUZoRTtBQUdBLFVBQU0sVUFBTixPQUFNLENBQU47QUFHRjs7QUFBQSxZQUEyQztBQUN6QyxRQUFJRCxNQUFNLENBQU5BLDRCQUFtQyxDQUFDcVMsR0FBRyxDQUEzQyxLQUFpRDtBQUMvQ3hSLGFBQU8sQ0FBUEEsS0FDRyxHQUFFMFUsY0FBYyxLQURuQjFVO0FBTUg7QUFFRDs7QUFBQTtBQUdLOztBQUFBLE1BQU04VSxhQUFhLEdBQUcsd0dBQXRCLFNBQXNCLENBQXRCOzs7QUFlQSxtQ0FBc0Q7QUFDM0QsWUFBNEM7QUFDMUMsUUFBSTNMLEdBQUcsS0FBSEEsUUFBZ0IsZUFBcEIsVUFBNkM7QUFDM0NoSyxZQUFNLENBQU5BLGtCQUEwQkwsR0FBRCxJQUFTO0FBQ2hDLFlBQUlnVyxhQUFhLENBQWJBLGlCQUErQixDQUFuQyxHQUF1QztBQUNyQzlVLGlCQUFPLENBQVBBLEtBQ0cscURBQW9EbEIsR0FEdkRrQjtBQUlIO0FBTkRiO0FBUUg7QUFFRDs7QUFBQSxTQUFPLDBCQUFQLEdBQU8sQ0FBUDtBQUdLOztBQUFBLE1BQU00VixFQUFFLEdBQUcsdUJBQVg7O0FBQ0EsTUFBTTNHLEVBQUUsR0FDYjJHLEVBQUUsSUFDRixPQUFPMUcsV0FBVyxDQUFsQixTQURBMEcsY0FFQSxPQUFPMUcsV0FBVyxDQUFsQixZQUhLOzs7Ozs7Ozs7Ozs7O0FDM1lNLHdCQUF3QiwwQ0FBMEMsZ0RBQWdELGdDQUFnQyxnQ0FBZ0MsbUNBQW1DLDRCQUE0QiwrQkFBK0Isb0JBQW9CLHlCQUF5QixVQUFVO0FBQ3BWLGlEOzs7Ozs7Ozs7OztBQ0RBLGlCQUFpQixtQkFBTyxDQUFDLHVFQUFvQjs7Ozs7Ozs7Ozs7O0FDQTdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7O0FDTkEsY0FBYyxtQkFBTyxDQUFDLDRHQUErQjs7QUFFckQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEseUM7Ozs7Ozs7Ozs7O0FDdERBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSx5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQkE7QUFFTyxNQUFNMkcsV0FBVyxHQUFHLENBQUM7QUFDMUJDLE9BQUssR0FBRyxjQURrQjtBQUUxQkMsT0FBSyxHQUFHLE1BRmtCO0FBRzFCQyxRQUFNLEdBQUc7QUFIaUIsQ0FBRCxLQUlyQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLG1CQUFVLFVBQWI7QUFBd0IsVUFBSSxFQUFFRixLQUE5QjtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBU0U7QUFBTSxxQkFBVSxTQUFoQjtBQUEwQixTQUFDLEVBQUM7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQVVFO0FBQU0scUJBQVUsU0FBaEI7QUFBMEIsU0FBQyxFQUFDO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkYsZUFXRTtBQUFNLHFCQUFVLFNBQWhCO0FBQTBCLFNBQUMsRUFBQztBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGLGVBWUU7QUFBTSxxQkFBVSxTQUFoQjtBQUEwQixTQUFDLEVBQUM7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRixlQWFFO0FBQU0scUJBQVUsU0FBaEI7QUFBMEIsU0FBQyxFQUFDO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBd0JELENBN0JNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRlA7QUFDTyxNQUFNRyxPQUFPLEdBQUcsQ0FBQztBQUN0QkgsT0FBSyxHQUFHLGNBRGM7QUFFdEJDLE9BQUssR0FBRyxNQUZjO0FBR3RCQyxRQUFNLEdBQUc7QUFIYSxDQUFELEtBSWpCO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQUcsbUJBQVUsVUFBYjtBQUF3QixVQUFJLEVBQUVGLEtBQTlCO0FBQUEsOEJBQ0U7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUtFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFTRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGLGVBYUU7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRixlQWlCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRixlQXFCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJCRixlQXlCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpCRixlQTZCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdCRixlQWlDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpDRixlQXFDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJDRixlQXlDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpDRixlQTZDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdDRixlQWlERTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUErREQsQ0FwRU0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNSSxZQUFZLEdBQUlqVyxLQUFELElBQVc7QUFDckMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQUcsUUFBRSxFQUFDLFFBQU47QUFBZSxlQUFTLEVBQUMsK0JBQXpCO0FBQUEsOEJBQ0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsZ2dCQUhKO0FBSUUsWUFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLHVIQUhKO0FBSUUsaUJBQVMsRUFBQywyQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFjRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxrSEFISjtBQUlFLGlCQUFTLEVBQUMsNkJBSlo7QUFLRSxZQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWRGLGVBcUJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLG9IQUhKO0FBSUUsaUJBQVMsRUFBQyw0QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXVDRCxDQXhDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1rVyxRQUFRLEdBQUlsVyxLQUFELElBQVc7QUFDakMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxRQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQ0UsUUFBRSxFQUFDLFVBREw7QUFFRSxPQUFDLEVBQUMsNm9EQUZKO0FBR0UsZUFBUyxFQUFDLDhCQUhaO0FBSUUsVUFBSSxFQUFDLGNBSlA7QUFLRSxZQUFNLEVBQUMsTUFMVDtBQU1FLGlCQUFXLEVBQUM7QUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBa0JELENBbkJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTW1XLFNBQVMsR0FBSW5XLEtBQUQsSUFBVztBQUNsQyxzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxRQUZSO0FBR0UsVUFBTSxFQUFDLE1BSFQ7QUFJRSxXQUFPLEVBQUM7QUFKVixLQUtNQSxLQUxOO0FBQUEsMkJBT0U7QUFBRyxRQUFFLEVBQUMsV0FBTjtBQUFrQixlQUFTLEVBQUMsd0JBQTVCO0FBQUEsOEJBQ0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsNEZBSEo7QUFJRSxpQkFBUyxFQUFDLDZCQUpaO0FBS0UsWUFBSSxFQUFDLGNBTFA7QUFNRSxjQUFNLEVBQUMsTUFOVDtBQU9FLG1CQUFXLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBVUU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsMkVBSEo7QUFJRSxpQkFBUyxFQUFDLDRCQUpaO0FBS0UsWUFBSSxFQUFDLGNBTFA7QUFNRSxjQUFNLEVBQUMsTUFOVDtBQU9FLG1CQUFXLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGLGVBbUJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLGtIQUhKO0FBSUUsaUJBQVMsRUFBQyw0QkFKWjtBQUtFLFlBQUksRUFBQyxjQUxQO0FBTUUsY0FBTSxFQUFDLE1BTlQ7QUFPRSxtQkFBVyxFQUFDO0FBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuQkYsZUE0QkU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsNHVCQUhKO0FBSUUsaUJBQVMsRUFBQyxnQkFKWjtBQUtFLFlBQUksRUFBQyxjQUxQO0FBTUUsY0FBTSxFQUFDLE1BTlQ7QUFPRSxtQkFBVyxFQUFDO0FBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0RELENBakRNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTW9XLFNBQVMsR0FBSXBXLEtBQUQsSUFBVztBQUNsQyxzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxRQUZSO0FBR0UsVUFBTSxFQUFDLElBSFQ7QUFJRSxXQUFPLEVBQUM7QUFKVixLQUtNQSxLQUxOO0FBQUEsMkJBT0U7QUFDRSxtQkFBVSw2QkFEWjtBQUVFLE9BQUMsRUFBQyxtTkFGSjtBQUdFLGVBQVMsRUFBQywyQkFIWjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnQkQsQ0FqQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNcVcsT0FBTyxHQUFJclcsS0FBRCxJQUFXO0FBQ2hDLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLE1BRlI7QUFHRSxVQUFNLEVBQUMsTUFIVDtBQUlFLFdBQU8sRUFBQztBQUpWLEtBS01BLEtBTE47QUFBQSwyQkFPRTtBQUFHLFFBQUUsRUFBQyxTQUFOO0FBQWdCLGVBQVMsRUFBQywyQkFBMUI7QUFBQSw2QkFDRTtBQUNFLFVBQUUsRUFBQyxhQURMO0FBRUUscUJBQVUsYUFGWjtBQUdFLGlCQUFTLEVBQUMsbUJBSFo7QUFBQSxnQ0FLRTtBQUNFLFlBQUUsRUFBQyxhQURMO0FBRUUsdUJBQVUsYUFGWjtBQUdFLG1CQUFTLEVBQUMsMEJBSFo7QUFBQSxrQ0FLRTtBQUNFLGNBQUUsRUFBQyxTQURMO0FBRUUseUJBQVUsU0FGWjtBQUdFLGNBQUUsRUFBQyxPQUhMO0FBSUUsZ0JBQUksRUFBQyxNQUpQO0FBS0Usa0JBQU0sRUFBQyxjQUxUO0FBTUUsMEJBQWMsRUFBQyxPQU5qQjtBQU9FLHVCQUFXLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUxGLGVBY0U7QUFDRSxjQUFFLEVBQUMsU0FETDtBQUVFLHlCQUFVLFNBRlo7QUFHRSxjQUFFLEVBQUMsT0FITDtBQUlFLHFCQUFTLEVBQUMsa0JBSlo7QUFLRSxnQkFBSSxFQUFDLE1BTFA7QUFNRSxrQkFBTSxFQUFDLGNBTlQ7QUFPRSwwQkFBYyxFQUFDLE9BUGpCO0FBUUUsdUJBQVcsRUFBQztBQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZEYsZUF3QkU7QUFDRSxjQUFFLEVBQUMsU0FETDtBQUVFLHlCQUFVLFNBRlo7QUFHRSxjQUFFLEVBQUMsT0FITDtBQUlFLHFCQUFTLEVBQUMsa0JBSlo7QUFLRSxnQkFBSSxFQUFDLE1BTFA7QUFNRSxrQkFBTSxFQUFDLGNBTlQ7QUFPRSwwQkFBYyxFQUFDLE9BUGpCO0FBUUUsdUJBQVcsRUFBQztBQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMRixlQXdDRTtBQUNFLFlBQUUsRUFBQyxZQURMO0FBRUUsdUJBQVUsWUFGWjtBQUdFLFdBQUMsRUFBQywwQ0FISjtBQUlFLG1CQUFTLEVBQUMsOEJBSlo7QUFLRSxjQUFJLEVBQUMsTUFMUDtBQU1FLGdCQUFNLEVBQUMsY0FOVDtBQU9FLHdCQUFjLEVBQUMsT0FQakI7QUFRRSxxQkFBVyxFQUFDO0FBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF4Q0YsZUFrREU7QUFDRSxZQUFFLEVBQUMsWUFETDtBQUVFLHVCQUFVLFlBRlo7QUFHRSxXQUFDLEVBQUMsMENBSEo7QUFJRSxtQkFBUyxFQUFDLDhCQUpaO0FBS0UsY0FBSSxFQUFDLE1BTFA7QUFNRSxnQkFBTSxFQUFDLGNBTlQ7QUFPRSx3QkFBYyxFQUFDLE9BUGpCO0FBUUUscUJBQVcsRUFBQztBQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbERGLGVBNERFO0FBQ0UsWUFBRSxFQUFDLFlBREw7QUFFRSx1QkFBVSxZQUZaO0FBR0UsV0FBQyxFQUFDLCtGQUhKO0FBSUUsbUJBQVMsRUFBQyw4QkFKWjtBQUtFLGNBQUksRUFBQyxNQUxQO0FBTUUsZ0JBQU0sRUFBQyxjQU5UO0FBT0Usd0JBQWMsRUFBQyxPQVBqQjtBQVFFLHFCQUFXLEVBQUM7QUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTVERixlQXNFRTtBQUNFLFlBQUUsRUFBQyxTQURMO0FBRUUsdUJBQVUsU0FGWjtBQUdFLFlBQUUsRUFBQyxPQUhMO0FBSUUsbUJBQVMsRUFBQyxtQkFKWjtBQUtFLGNBQUksRUFBQyxNQUxQO0FBTUUsZ0JBQU0sRUFBQyxjQU5UO0FBT0UsMEJBQWdCLEVBQUMsSUFQbkI7QUFRRSxxQkFBVyxFQUFDO0FBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF0RUYsZUFnRkU7QUFDRSxZQUFFLEVBQUMsU0FETDtBQUVFLHVCQUFVLFNBRlo7QUFHRSxZQUFFLEVBQUMsT0FITDtBQUlFLG1CQUFTLEVBQUMsbUJBSlo7QUFLRSxjQUFJLEVBQUMsTUFMUDtBQU1FLGdCQUFNLEVBQUMsY0FOVDtBQU9FLDBCQUFnQixFQUFDLElBUG5CO0FBUUUscUJBQVcsRUFBQztBQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEZGLGVBMEZFO0FBQ0UsWUFBRSxFQUFDLFlBREw7QUFFRSx1QkFBVSxZQUZaO0FBR0UsV0FBQyxFQUFDLHVGQUhKO0FBSUUsbUJBQVMsRUFBQyw4QkFKWjtBQUtFLGNBQUksRUFBQyxNQUxQO0FBTUUsZ0JBQU0sRUFBQyxjQU5UO0FBT0Usd0JBQWMsRUFBQyxPQVBqQjtBQVFFLHFCQUFXLEVBQUM7QUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBaUhELENBbEhNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTXNXLEtBQUssR0FBSXRXLEtBQUQsSUFBVztBQUM5QixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxRQUZSO0FBR0UsVUFBTSxFQUFDLE1BSFQ7QUFJRSxXQUFPLEVBQUM7QUFKVixLQUtNQSxLQUxOO0FBQUEsMkJBT0U7QUFBRyxRQUFFLEVBQUMsT0FBTjtBQUFjLGVBQVMsRUFBQywwQkFBeEI7QUFBQSw4QkFDRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxzdUJBSEo7QUFJRSxpQkFBUyxFQUFDLGdCQUpaO0FBS0UsWUFBSSxFQUFDLGNBTFA7QUFNRSxjQUFNLEVBQUMsY0FOVDtBQU9FLG1CQUFXLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBVUU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsMGpCQUhKO0FBSUUsaUJBQVMsRUFBQyw4QkFKWjtBQUtFLFlBQUksRUFBQyxjQUxQO0FBTUUsY0FBTSxFQUFDLGNBTlQ7QUFPRSxtQkFBVyxFQUFDO0FBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUE4QkQsQ0EvQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU11VyxTQUFTLEdBQUcsQ0FBQztBQUN4QlYsT0FBSyxHQUFHLGNBRGdCO0FBRXhCQyxPQUFLLEdBQUcsTUFGZ0I7QUFHeEJDLFFBQU0sR0FBRztBQUhlLENBQUQsS0FJbkI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFBRyxtQkFBVSxlQUFiO0FBQTZCLFVBQUksRUFBRUYsS0FBbkM7QUFBQSw4QkFDRTtBQUNFLFVBQUUsRUFBQyxPQURMO0FBRUUsVUFBRSxFQUFDLE9BRkw7QUFHRSxVQUFFLEVBQUMsT0FITDtBQUlFLFVBQUUsRUFBQyxPQUpMO0FBS0UsaUJBQVMsRUFBQztBQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFRRTtBQUFNLFNBQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkYsZUFTRTtBQUNFLHFCQUFVLE9BRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXVCRCxDQTVCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTVcsSUFBSSxHQUFHLENBQUM7QUFDbkJYLE9BQUssR0FBRyxjQURXO0FBRW5CQyxPQUFLLEdBQUcsTUFGVztBQUduQkMsUUFBTSxHQUFHO0FBSFUsQ0FBRCxLQUlkO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQUcsVUFBSSxFQUFFRixLQUFUO0FBQUEsOEJBQ0U7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUtFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFTRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXVCRCxDQTVCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTVksSUFBSSxHQUFHLENBQUM7QUFDbkJaLE9BQUssR0FBRyxjQURXO0FBRW5CQyxPQUFLLEdBQUcsTUFGVztBQUduQkMsUUFBTSxHQUFHO0FBSFUsQ0FBRCxLQUlkO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQUcsVUFBSSxFQUFFRixLQUFUO0FBQUEsOEJBQ0U7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUtFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFTRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGLGVBYUU7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRixlQWlCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRixlQXFCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJCRixlQXlCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpCRixlQTZCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyQ0QsQ0FoRE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNYSxVQUFVLEdBQUkxVyxLQUFELElBQVc7QUFDbkMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQUcsUUFBRSxFQUFDLE9BQU47QUFBYyxlQUFTLEVBQUMsOEJBQXhCO0FBQUEsOEJBQ0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsdW1DQUhKO0FBSUUsaUJBQVMsRUFBQyxxQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFRRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyw0MUJBSEo7QUFJRSxpQkFBUyxFQUFDLG9CQUpaO0FBS0UsWUFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEwQkQsQ0EzQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNMlcsZUFBZSxHQUFJM1csS0FBRCxJQUFXO0FBQ3hDLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLFFBRlI7QUFHRSxVQUFNLEVBQUMsUUFIVDtBQUlFLFdBQU8sRUFBQztBQUpWLEtBS01BLEtBTE47QUFBQSwyQkFPRTtBQUFHLFFBQUUsRUFBQyxTQUFOO0FBQWdCLGVBQVMsRUFBQywwQkFBMUI7QUFBQSw4QkFDRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQywyRUFISjtBQUlFLGlCQUFTLEVBQUMsOEJBSlo7QUFLRSxZQUFJLEVBQUMsY0FMUDtBQU1FLGNBQU0sRUFBQyxjQU5UO0FBT0UsbUJBQVcsRUFBQztBQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFVRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxvbERBSEo7QUFJRSxpQkFBUyxFQUFDLGlCQUpaO0FBS0UsWUFBSSxFQUFDLGNBTFA7QUFNRSxjQUFNLEVBQUMsY0FOVDtBQU9FLG1CQUFXLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQThCRCxDQS9CTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTTRXLFFBQVEsR0FBRyxDQUFDO0FBQ3ZCZixPQUFLLEdBQUcsY0FEZTtBQUV2QkMsT0FBSyxHQUFHLE1BRmU7QUFHdkJDLFFBQU0sR0FBRztBQUhjLENBQUQsS0FJbEI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFBRyxtQkFBVSxVQUFiO0FBQUEsNkJBQ0U7QUFDRSxxQkFBVSxVQURaO0FBRUUsWUFBSSxFQUFFRixLQUZSO0FBR0UsY0FBTSxFQUFDLE1BSFQ7QUFJRSx3QkFBZ0IsRUFBQyxJQUpuQjtBQUtFLG1CQUFXLEVBQUMsTUFMZDtBQUFBLGdDQU9FO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEYsZUFXRTtBQUFNLHVCQUFVLGNBQWhCO0FBQStCLFdBQUMsRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhGLGVBWUU7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBNEJELENBakNNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTWdCLFlBQVksR0FBSTdXLEtBQUQsSUFBVztBQUNyQyxzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxPQUZSO0FBR0UsVUFBTSxFQUFDLE9BSFQ7QUFJRSxXQUFPLEVBQUM7QUFKVixLQUtNQSxLQUxOO0FBQUEsMkJBT0U7QUFDRSxRQUFFLEVBQUMsY0FETDtBQUVFLG1CQUFVLGNBRlo7QUFHRSxlQUFTLEVBQUMsK0JBSFo7QUFBQSw4QkFLRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxpSkFISjtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxjQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQWdCRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxtR0FISjtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxjQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoQkYsZUEyQkU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsa0lBSEo7QUFJRSxpQkFBUyxFQUFDLDRCQUpaO0FBS0UsWUFBSSxFQUFDLE1BTFA7QUFNRSxjQUFNLEVBQUMsY0FOVDtBQU9FLHFCQUFhLEVBQUMsT0FQaEI7QUFRRSxzQkFBYyxFQUFDLE9BUmpCO0FBU0UsbUJBQVcsRUFBQztBQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0JGLGVBc0NFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLG1CQUhKO0FBSUUsaUJBQVMsRUFBQyw2QkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLGNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRDRixlQWlERTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxzQ0FISjtBQUlFLGlCQUFTLEVBQUMsNkJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxjQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqREYsZUE0REU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsZ01BSEo7QUFJRSxpQkFBUyxFQUFDLHVCQUpaO0FBS0UsWUFBSSxFQUFDLE1BTFA7QUFNRSxjQUFNLEVBQUMsY0FOVDtBQU9FLHFCQUFhLEVBQUMsT0FQaEI7QUFRRSxzQkFBYyxFQUFDLE9BUmpCO0FBU0UsbUJBQVcsRUFBQztBQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNURGLGVBdUVFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLCtIQUhKO0FBSUUsaUJBQVMsRUFBQyw4QkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLGNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZFRixlQWtGRTtBQUNFLFVBQUUsRUFBQyxTQURMO0FBRUUscUJBQVUsU0FGWjtBQUdFLFVBQUUsRUFBQyxPQUhMO0FBSUUsVUFBRSxFQUFDLE1BSkw7QUFLRSxpQkFBUyxFQUFDLDZCQUxaO0FBTUUsWUFBSSxFQUFDLE1BTlA7QUFPRSxjQUFNLEVBQUMsY0FQVDtBQVFFLHFCQUFhLEVBQUMsT0FSaEI7QUFTRSxzQkFBYyxFQUFDLE9BVGpCO0FBVUUsbUJBQVcsRUFBQztBQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbEZGLGVBOEZFO0FBQ0UsVUFBRSxFQUFDLFNBREw7QUFFRSxxQkFBVSxTQUZaO0FBR0UsVUFBRSxFQUFDLE1BSEw7QUFJRSxVQUFFLEVBQUMsT0FKTDtBQUtFLGlCQUFTLEVBQUMsNkJBTFo7QUFNRSxZQUFJLEVBQUMsTUFOUDtBQU9FLGNBQU0sRUFBQyxjQVBUO0FBUUUscUJBQWEsRUFBQyxPQVJoQjtBQVNFLHNCQUFjLEVBQUMsT0FUakI7QUFVRSxtQkFBVyxFQUFDO0FBVmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5RkYsZUEwR0U7QUFDRSxVQUFFLEVBQUMsU0FETDtBQUVFLHFCQUFVLFNBRlo7QUFHRSxVQUFFLEVBQUMsT0FITDtBQUlFLGlCQUFTLEVBQUMsNkJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxjQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExR0YsZUFxSEU7QUFDRSxVQUFFLEVBQUMsV0FETDtBQUVFLHFCQUFVLFdBRlo7QUFHRSxVQUFFLEVBQUMsT0FITDtBQUlFLFVBQUUsRUFBQyxPQUpMO0FBS0UsU0FBQyxFQUFDLE9BTEo7QUFNRSxpQkFBUyxFQUFDLDZCQU5aO0FBT0UsbUJBQVcsRUFBQyxLQVBkO0FBUUUsY0FBTSxFQUFDLGNBUlQ7QUFTRSxxQkFBYSxFQUFDLE9BVGhCO0FBVUUsc0JBQWMsRUFBQyxPQVZqQjtBQVdFLFlBQUksRUFBQztBQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckhGLGVBa0lFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLHdFQUhKO0FBSUUsaUJBQVMsRUFBQyw4QkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLGNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxJRixlQTZJRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFVBQUUsRUFBQyxPQUhMO0FBSUUsVUFBRSxFQUFDLE9BSkw7QUFLRSxTQUFDLEVBQUMsT0FMSjtBQU1FLGlCQUFTLEVBQUMsNkJBTlo7QUFPRSxtQkFBVyxFQUFDLEtBUGQ7QUFRRSxjQUFNLEVBQUMsY0FSVDtBQVNFLHFCQUFhLEVBQUMsT0FUaEI7QUFVRSxzQkFBYyxFQUFDLE9BVmpCO0FBV0UsWUFBSSxFQUFDO0FBWFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUtELENBdEtNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNOFcsVUFBVSxHQUFHLENBQUM7QUFDekJqQixPQUFLLEdBQUcsY0FEaUI7QUFFekJDLE9BQUssR0FBRyxNQUZpQjtBQUd6QkMsUUFBTSxHQUFHO0FBSGdCLENBQUQsS0FJcEI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxtQkFBVSxTQURaO0FBRUUsVUFBSSxFQUFFRixLQUZSO0FBR0UsWUFBTSxFQUFDLE1BSFQ7QUFJRSxzQkFBZ0IsRUFBQyxJQUpuQjtBQUtFLGlCQUFXLEVBQUMsTUFMZDtBQUFBLDhCQU9FO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFXRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGLGVBZUU7QUFDRSxxQkFBVSxTQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFmRixlQW1CRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5CRixlQXVCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZCRixlQTJCRTtBQUFNLHFCQUFVLFNBQWhCO0FBQTBCLFNBQUMsRUFBQztBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNCRixlQTRCRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVCRixlQWdDRTtBQUFNLHFCQUFVLFNBQWhCO0FBQTBCLFNBQUMsRUFBQztBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhDRixlQWlDRTtBQUFNLHFCQUFVLFNBQWhCO0FBQTBCLFNBQUMsRUFBQztBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpDRixlQWtDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxDRixlQXNDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFvREQsQ0F6RE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1rQixJQUFJLEdBQUcsQ0FBQztBQUNuQmxCLE9BQUssR0FBRyxjQURXO0FBRW5CQyxPQUFLLEdBQUcsTUFGVztBQUduQkMsUUFBTSxHQUFHO0FBSFUsQ0FBRCxLQUlkO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQUcsbUJBQVUsVUFBYjtBQUFBLDZCQUNFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQyw0VkFGSjtBQUdFLFlBQUksRUFBRUY7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdCRCxDQXJCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1tQixRQUFRLEdBQUloWCxLQUFELElBQVc7QUFDakMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDO0FBSlYsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQ0UsUUFBRSxFQUFDLFdBREw7QUFFRSxtQkFBVSxhQUZaO0FBR0UsZUFBUyxFQUFDLDhCQUhaO0FBQUEsOEJBS0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsNGdCQUhKO0FBSUUsaUJBQVMsRUFBQywyQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFZRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyw2ZkFISjtBQUlFLGlCQUFTLEVBQUMsc0JBSlo7QUFLRSxZQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGLGVBbUJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLG1kQUhKO0FBSUUsaUJBQVMsRUFBQyxzQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbkJGLGVBMEJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLG9aQUhKO0FBSUUsaUJBQVMsRUFBQyw0QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMUJGLGVBaUNFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLGlIQUhKO0FBSUUsaUJBQVMsRUFBQyw0QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakNGLGVBd0NFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLHNMQUhKO0FBSUUsaUJBQVMsRUFBQyw0QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeENGLGVBK0NFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDhHQUhKO0FBSUUsaUJBQVMsRUFBQyw2QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWlFRCxDQWxFTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBRU8sTUFBTWlYLEtBQUssR0FBRyxDQUFDO0FBQ3BCcEIsT0FBSyxHQUFHLGNBRFk7QUFFcEJDLE9BQUssR0FBRyxNQUZZO0FBR3BCQyxRQUFNLEdBQUc7QUFIVyxDQUFELEtBSWY7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxVQUpWO0FBQUEsMkJBTUU7QUFDRSxtQkFBVSxlQURaO0FBRUUsV0FBSyxFQUFDLElBRlI7QUFHRSxZQUFNLEVBQUMsR0FIVDtBQUlFLFFBQUUsRUFBQyxHQUpMO0FBS0UsVUFBSSxFQUFFRjtBQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnQkQsQ0FyQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDtBQUNPLE1BQU1xQixRQUFRLEdBQUcsQ0FBQztBQUN2QnJCLE9BQUssR0FBRyxjQURlO0FBRXZCQyxPQUFLLEdBQUcsTUFGZTtBQUd2QkMsUUFBTSxHQUFHO0FBSGMsQ0FBRCxLQUlsQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLFVBQUksRUFBRUYsS0FBVDtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQXhCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTXNCLFNBQVMsR0FBRyxDQUFDO0FBQ3hCdEIsT0FBSyxHQUFHLGNBRGdCO0FBRXhCQyxPQUFLLEdBQUcsTUFGZ0I7QUFHeEJDLFFBQU0sR0FBRztBQUhlLENBQUQsS0FJbkI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFBRyxtQkFBVSxVQUFiO0FBQXdCLFVBQUksRUFBRUYsS0FBOUI7QUFBQSw4QkFDRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBS0U7QUFDRSxxQkFBVSxVQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQVNFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBdUJELENBNUJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNdUIsS0FBSyxHQUFHLENBQUM7QUFDcEJ2QixPQUFLLEdBQUcsY0FEWTtBQUVwQkMsT0FBSyxHQUFHLE1BRlk7QUFHcEJDLFFBQU0sR0FBRztBQUhXLENBQUQsS0FJZjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLFVBQUksRUFBRUYsS0FBVDtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFVBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQXhCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU13QixPQUFPLEdBQUlyWCxLQUFELElBQVc7QUFDaEMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxXQUFPLEVBQUMsYUFGVjtBQUdFLFNBQUssRUFBQyxJQUhSO0FBSUUsVUFBTSxFQUFDO0FBSlQsS0FLTUEsS0FMTjtBQUFBLDJCQU9FO0FBQUcsUUFBRSxFQUFDLFNBQU47QUFBQSw2QkFDRTtBQUNFLFNBQUMsRUFBQyxxK0RBREo7QUFFRSxZQUFJLEVBQUM7QUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdCRCxDQWpCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTXNYLEtBQUssR0FBRyxDQUFDO0FBQ3BCekIsT0FBSyxHQUFHLGNBRFk7QUFFcEJDLE9BQUssR0FBRyxNQUZZO0FBR3BCQyxRQUFNLEdBQUc7QUFIVyxDQUFELEtBSWY7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFBRyxtQkFBVSxTQUFiO0FBQUEsNkJBQ0U7QUFDRSxxQkFBVSxTQURaO0FBRUUsWUFBSSxFQUFFRixLQUZSO0FBR0UsY0FBTSxFQUFDLE1BSFQ7QUFJRSx3QkFBZ0IsRUFBQyxJQUpuQjtBQUtFLG1CQUFXLEVBQUMsTUFMZDtBQU1FLGlCQUFTLEVBQUMsMkJBTlo7QUFBQSxnQ0FRRTtBQUNFLHVCQUFVLFFBRFo7QUFFRSxXQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJGLGVBWUU7QUFDRSx1QkFBVSxRQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFaRixlQWdCRTtBQUNFLHVCQUFVLFFBRFo7QUFFRSxXQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWhCRixlQW9CRTtBQUNFLHVCQUFVLFFBRFo7QUFFRSxXQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXBCRixlQXdCRTtBQUNFLHVCQUFVLGNBRFo7QUFFRSxlQUFLLEVBQUMsTUFGUjtBQUdFLGdCQUFNLEVBQUMsTUFIVDtBQUlFLFlBQUUsRUFBQyxNQUpMO0FBS0UsbUJBQVMsRUFBQztBQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeEJGLGVBK0JFO0FBQ0UsdUJBQVUsUUFEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBL0JGLGVBbUNFO0FBQ0UsdUJBQVUsY0FEWjtBQUVFLGVBQUssRUFBQyxNQUZSO0FBR0UsZ0JBQU0sRUFBQyxNQUhUO0FBSUUsWUFBRSxFQUFDLE1BSkw7QUFLRSxtQkFBUyxFQUFDO0FBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFuQ0YsZUEwQ0U7QUFDRSx1QkFBVSxjQURaO0FBRUUsZUFBSyxFQUFDLEtBRlI7QUFHRSxnQkFBTSxFQUFDLEtBSFQ7QUFJRSxZQUFFLEVBQUMsTUFKTDtBQUtFLG1CQUFTLEVBQUM7QUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBNkRELENBbEVNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNMEIsWUFBWSxHQUFHLENBQUM7QUFDM0IxQixPQUFLLEdBQUcsY0FEbUI7QUFFM0JDLE9BQUssR0FBRyxNQUZtQjtBQUczQkMsUUFBTSxHQUFHO0FBSGtCLENBQUQsS0FJdEI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsNEJBTUU7QUFBRyxtQkFBVSxVQUFiO0FBQUEsNkJBQ0U7QUFBRyxxQkFBVSxVQUFiO0FBQUEsK0JBQ0U7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDLG1WQUZKO0FBR0UsY0FBSSxFQUFFRjtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORixlQWVFO0FBQUcsbUJBQVUsVUFBYjtBQUFBLDZCQUNFO0FBQUcscUJBQVUsVUFBYjtBQUFBLCtCQUNFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQyx1Q0FGSjtBQUdFLGNBQUksRUFBRUE7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZkYsZUF3QkU7QUFBRyxtQkFBVSxVQUFiO0FBQUEsNkJBQ0U7QUFBRyxxQkFBVSxVQUFiO0FBQUEsK0JBQ0U7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDLHdFQUZKO0FBR0UsY0FBSSxFQUFFQTtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF4QkYsZUFpQ0U7QUFBRyxtQkFBVSxVQUFiO0FBQUEsNkJBQ0U7QUFBRyxxQkFBVSxVQUFiO0FBQUEsK0JBQ0U7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDLHdPQUZKO0FBR0UsY0FBSSxFQUFFQTtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQ0YsZUEwQ0U7QUFBRyxtQkFBVSxVQUFiO0FBQUEsNkJBQ0U7QUFBRyxxQkFBVSxVQUFiO0FBQUEsK0JBQ0U7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDLGdJQUZKO0FBR0UsY0FBSSxFQUFFQTtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFzREQsQ0EzRE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU0yQixNQUFNLEdBQUcsQ0FBQztBQUNyQjNCLE9BQUssR0FBRyxjQURhO0FBRXJCQyxPQUFLLEdBQUcsTUFGYTtBQUdyQkMsUUFBTSxHQUFHO0FBSFksQ0FBRCxLQUloQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLFVBQUksRUFBRUYsS0FBVDtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFVBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBU0U7QUFDRSxxQkFBVSxVQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQWFFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBMkJELENBaENNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNNEIsWUFBWSxHQUFHLENBQUM7QUFDM0I1QixPQUFLLEdBQUcsY0FEbUI7QUFFM0JDLE9BQUssR0FBRyxNQUZtQjtBQUczQkMsUUFBTSxHQUFHO0FBSGtCLENBQUQsS0FJdEI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxtQkFBVSxTQURaO0FBRUUsZUFBUyxFQUFDLDZCQUZaO0FBR0UsVUFBSSxFQUFFRixLQUhSO0FBSUUsWUFBTSxFQUFDLE1BSlQ7QUFLRSxzQkFBZ0IsRUFBQyxJQUxuQjtBQU1FLGlCQUFXLEVBQUMsTUFOZDtBQUFBLDhCQVFFO0FBQ0UscUJBQVUsUUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkYsZUFZRTtBQUNFLHFCQUFVLFFBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGLGVBZ0JFO0FBQ0UscUJBQVUsUUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEJGLGVBb0JFO0FBQ0UscUJBQVUsUUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcEJGLGVBd0JFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeEJGLGVBNEJFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNUJGLGVBZ0NFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaENGLGVBb0NFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcENGLGVBd0NFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeENGLGVBNENFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNUNGLGVBZ0RFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaERGLGVBb0RFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcERGLGVBd0RFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeERGLGVBNERFO0FBQ0UscUJBQVUsY0FEWjtBQUVFLGFBQUssRUFBQyxPQUZSO0FBR0UsY0FBTSxFQUFDLE9BSFQ7QUFJRSxVQUFFLEVBQUMsTUFKTDtBQUtFLGlCQUFTLEVBQUM7QUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVERixlQW1FRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5FRixlQXVFRTtBQUFNLHFCQUFVLGNBQWhCO0FBQStCLFNBQUMsRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFrRkQsQ0F2Rk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU02QixNQUFNLEdBQUcsQ0FBQztBQUNyQjdCLE9BQUssR0FBRyxjQURhO0FBRXJCQyxPQUFLLEdBQUcsTUFGYTtBQUdyQkMsUUFBTSxHQUFHO0FBSFksQ0FBRCxLQUloQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLFVBQUksRUFBRUYsS0FBVDtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFVBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBU0U7QUFBTSxxQkFBVSxhQUFoQjtBQUE4QixTQUFDLEVBQUM7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFvQkQsQ0F6Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNOEIsTUFBTSxHQUFJM1gsS0FBRCxJQUFXO0FBQy9CLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLFFBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQztBQUpWLEtBS01BLEtBTE47QUFBQSwyQkFPRTtBQUFHLFFBQUUsRUFBQyxRQUFOO0FBQWUsZUFBUyxFQUFDLHNCQUF6QjtBQUFBLDhCQUNFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsaUJBQVMsRUFBQyx5QkFIWjtBQUFBLCtCQUtFO0FBQUcsWUFBRSxFQUFDLFlBQU47QUFBbUIsdUJBQVUsWUFBN0I7QUFBMEMsbUJBQVMsRUFBQyxnQkFBcEQ7QUFBQSxpQ0FDRTtBQUNFLGNBQUUsRUFBQyxZQURMO0FBRUUseUJBQVUsWUFGWjtBQUdFLGFBQUMsRUFBQyx1V0FISjtBQUlFLHFCQUFTLEVBQUMsNkJBSlo7QUFLRSxnQkFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBZ0JFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsaUJBQVMsRUFBQyxxQkFIWjtBQUFBLCtCQUtFO0FBQUcsWUFBRSxFQUFDLFlBQU47QUFBbUIsdUJBQVUsWUFBN0I7QUFBMEMsbUJBQVMsRUFBQyxnQkFBcEQ7QUFBQSxpQ0FDRTtBQUNFLGNBQUUsRUFBQyxZQURMO0FBRUUseUJBQVUsWUFGWjtBQUdFLGFBQUMsRUFBQyxtUkFISjtBQUlFLHFCQUFTLEVBQUMsdUJBSlo7QUFLRSxnQkFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhCRixlQStCRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLGlCQUFTLEVBQUMsMEJBSFo7QUFBQSwrQkFLRTtBQUFHLFlBQUUsRUFBQyxZQUFOO0FBQW1CLHVCQUFVLFlBQTdCO0FBQUEsaUNBQ0U7QUFDRSxjQUFFLEVBQUMsWUFETDtBQUVFLHlCQUFVLFlBRlo7QUFHRSxhQUFDLEVBQUMsMFNBSEo7QUFJRSxxQkFBUyxFQUFDLDhCQUpaO0FBS0UsZ0JBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvQkYsZUE4Q0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxpQkFBUyxFQUFDLDBCQUhaO0FBQUEsK0JBS0U7QUFBRyxZQUFFLEVBQUMsWUFBTjtBQUFtQix1QkFBVSxZQUE3QjtBQUEwQyxtQkFBUyxFQUFDLGdCQUFwRDtBQUFBLGlDQUNFO0FBQ0UsY0FBRSxFQUFDLFlBREw7QUFFRSx5QkFBVSxZQUZaO0FBR0UsYUFBQyxFQUFDLDBLQUhKO0FBSUUscUJBQVMsRUFBQyw2QkFKWjtBQUtFLGdCQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOUNGLGVBNkRFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsaUJBQVMsRUFBQyx5QkFIWjtBQUFBLCtCQUtFO0FBQUcsWUFBRSxFQUFDLFlBQU47QUFBbUIsdUJBQVUsWUFBN0I7QUFBMEMsbUJBQVMsRUFBQyxnQkFBcEQ7QUFBQSxpQ0FDRTtBQUNFLGNBQUUsRUFBQyxZQURMO0FBRUUseUJBQVUsWUFGWjtBQUdFLGFBQUMsRUFBQyxrS0FISjtBQUlFLHFCQUFTLEVBQUMsNkJBSlo7QUFLRSxnQkFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdERixlQTRFRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLGlCQUFTLEVBQUMseUJBSFo7QUFBQSwrQkFLRTtBQUFHLFlBQUUsRUFBQyxZQUFOO0FBQW1CLHVCQUFVLFlBQTdCO0FBQTBDLG1CQUFTLEVBQUMsZ0JBQXBEO0FBQUEsaUNBQ0U7QUFDRSxjQUFFLEVBQUMsWUFETDtBQUVFLHlCQUFVLFlBRlo7QUFHRSxhQUFDLEVBQUMsMEtBSEo7QUFJRSxxQkFBUyxFQUFDLDZCQUpaO0FBS0UsZ0JBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBc0dELENBdkdNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRFA7QUFDTyxNQUFNNFgsSUFBSSxHQUFHLENBQUM7QUFDbkIvQixPQUFLLEdBQUcsY0FEVztBQUVuQkMsT0FBSyxHQUFHLE1BRlc7QUFHbkJDLFFBQU0sR0FBRztBQUhVLENBQUQsS0FJZDtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLFVBQUksRUFBRUYsS0FBVDtBQUFBLDhCQUNFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLFNBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUNFLHFCQUFVLFVBRFo7QUFFRSxTQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBU0U7QUFDRSxxQkFBVSxVQURaO0FBRUUsU0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF1QkQsQ0E1Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNPLE1BQU1nQyxNQUFNLEdBQUcsQ0FBQztBQUNyQmhDLE9BQUssR0FBRyxjQURhO0FBRXJCQyxPQUFLLEdBQUcsTUFGYTtBQUdyQkMsUUFBTSxHQUFHO0FBSFksQ0FBRCxLQUloQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUFHLG1CQUFVLFNBQWI7QUFBQSw4QkFDRTtBQUFHLHFCQUFVLFNBQWI7QUFBQSwrQkFDRTtBQUNFLHVCQUFVLFNBRFo7QUFFRSxXQUFDLEVBQUMsNERBRko7QUFHRSxjQUFJLEVBQUVGO0FBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFRRTtBQUNFLHFCQUFVLFNBRFo7QUFFRSxTQUFDLEVBQUMsb09BRko7QUFHRSxZQUFJLEVBQUVBO0FBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQWFFO0FBQ0UscUJBQVUsU0FEWjtBQUVFLFNBQUMsRUFBQyxrTkFGSjtBQUdFLFlBQUksRUFBRUE7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTRCRCxDQWpDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RQO0FBQ08sTUFBTWlDLFVBQVUsR0FBRyxDQUFDO0FBQ3pCakMsT0FBSyxHQUFHLGNBRGlCO0FBRXpCQyxPQUFLLEdBQUcsTUFGaUI7QUFHekJDLFFBQU0sR0FBRztBQUhnQixDQUFELEtBSXBCO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDRCQU1FO0FBQUEsNkJBQ0U7QUFBVSxVQUFFLEVBQUMsR0FBYjtBQUFBLCtCQUNFO0FBQ0UsdUJBQVUsY0FEWjtBQUVFLG1CQUFTLEVBQUMscUJBRlo7QUFHRSxjQUFJLEVBQUMsU0FIUDtBQUlFLFdBQUMsRUFBQztBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORixlQWdCRTtBQUNFLG1CQUFVLGFBRFo7QUFFRSxlQUFTLEVBQUMsdUJBRlo7QUFHRSxjQUFRLEVBQUMsU0FIWDtBQUFBLDZCQUtFO0FBQ0UscUJBQVUsVUFEWjtBQUVFLGlCQUFTLEVBQUMseUJBRlo7QUFHRSxZQUFJLEVBQUVGLEtBSFI7QUFBQSxnQ0FLRTtBQUNFLHVCQUFVLFNBRFo7QUFFRSxXQUFDLEVBQUM7QUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUxGLGVBU0U7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURixlQWFFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYkYsZUFpQkU7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFqQkYsZUFxQkU7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFyQkYsZUF5QkU7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF6QkYsZUE2QkU7QUFDRSx1QkFBVSxTQURaO0FBRUUsV0FBQyxFQUFDO0FBRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE3QkYsZUFpQ0U7QUFDRSx1QkFBVSxXQURaO0FBRUUsWUFBRSxFQUFDLE1BRkw7QUFHRSxZQUFFLEVBQUMsTUFITDtBQUlFLFdBQUMsRUFBQyxNQUpKO0FBS0UsbUJBQVMsRUFBQztBQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakNGLGVBd0NFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeENGLGVBNENFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNUNGLGVBZ0RFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaERGLGVBb0RFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcERGLGVBd0RFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeERGLGVBNERFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNURGLGVBZ0VFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEVGLGVBb0VFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcEVGLGVBd0VFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeEVGLGVBNEVFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNUVGLGVBZ0ZFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEZGLGVBb0ZFO0FBQ0UsdUJBQVUsU0FEWjtBQUVFLFdBQUMsRUFBQztBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBa0hELENBdkhNLEM7Ozs7Ozs7Ozs7OztBQ0RQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hDTyxNQUFNa0MsR0FBRyxHQUFHLENBQUM7QUFDbEJsQyxPQUFLLEdBQUcsY0FEVTtBQUVsQkMsT0FBSyxHQUFHLE1BRlU7QUFHbEJDLFFBQU0sR0FBRztBQUhTLENBQUQsS0FJYjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLElBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsS0FETDtBQUVFLE9BQUMsRUFBQyxzNkJBRko7QUFHRSxlQUFTLEVBQUMsc0JBSFo7QUFJRSxVQUFJLEVBQUM7QUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FwQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsTUFBTWlDLFNBQVMsR0FBRyxDQUFDO0FBQ3hCbkMsT0FBSyxHQUFHLGNBRGdCO0FBRXhCQyxPQUFLLEdBQUcsTUFGZ0I7QUFHeEJDLFFBQU0sR0FBRztBQUhlLENBQUQsS0FJbkI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxPQUZSO0FBR0UsVUFBTSxFQUFDLElBSFQ7QUFJRSxXQUFPLEVBQUMsY0FKVjtBQUFBLDJCQU1FO0FBQ0UsUUFBRSxFQUFDLFdBREw7QUFFRSxtQkFBVSxXQUZaO0FBR0UsT0FBQyxFQUFDLHNoQ0FISjtBQUlFLGVBQVMsRUFBQyxzQkFKWjtBQUtFLFVBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnQkQsQ0FyQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsTUFBTWtDLFdBQVcsR0FBRyxDQUFDO0FBQzFCcEMsT0FBSyxHQUFHLGNBRGtCO0FBRTFCQyxPQUFLLEdBQUcsTUFGa0I7QUFHMUJDLFFBQU0sR0FBRztBQUhpQixDQUFELEtBSXJCO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsSUFGUjtBQUdFLFVBQU0sRUFBQyxPQUhUO0FBSUUsV0FBTyxFQUFDLGNBSlY7QUFBQSwyQkFNRTtBQUNFLFFBQUUsRUFBQyxjQURMO0FBRUUsbUJBQVUsY0FGWjtBQUdFLE9BQUMsRUFBQyx5aERBSEo7QUFJRSxlQUFTLEVBQUMsc0JBSlo7QUFLRSxVQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0JELENBckJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLE1BQU1tQyxLQUFLLEdBQUcsQ0FBQztBQUNwQnJDLE9BQUssR0FBRyxjQURZO0FBRXBCQyxPQUFLLEdBQUcsTUFGWTtBQUdwQkMsUUFBTSxHQUFHO0FBSFcsQ0FBRCxLQUlmO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsTUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDLGFBSlY7QUFBQSwyQkFNRTtBQUFHLFFBQUUsRUFBQyxPQUFOO0FBQWMsZUFBUyxFQUFDLHNCQUF4QjtBQUFBLDhCQUNFO0FBQ0UsVUFBRSxFQUFDLGFBREw7QUFFRSxxQkFBVSxhQUZaO0FBR0UsVUFBRSxFQUFDLEtBSEw7QUFJRSxVQUFFLEVBQUMsS0FKTDtBQUtFLFNBQUMsRUFBQyxLQUxKO0FBTUUsaUJBQVMsRUFBQyxzQkFOWjtBQU9FLG1CQUFXLEVBQUMsR0FQZDtBQVFFLGNBQU0sRUFBQyxTQVJUO0FBU0UscUJBQWEsRUFBQyxPQVRoQjtBQVVFLHNCQUFjLEVBQUMsT0FWakI7QUFXRSxZQUFJLEVBQUM7QUFYUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBY0U7QUFDRSxVQUFFLEVBQUMsYUFETDtBQUVFLHFCQUFVLGFBRlo7QUFHRSxVQUFFLEVBQUMsS0FITDtBQUlFLFVBQUUsRUFBQyxLQUpMO0FBS0UsU0FBQyxFQUFDLEtBTEo7QUFNRSxpQkFBUyxFQUFDLHdCQU5aO0FBT0UsbUJBQVcsRUFBQyxHQVBkO0FBUUUsY0FBTSxFQUFDLFNBUlQ7QUFTRSxxQkFBYSxFQUFDLE9BVGhCO0FBVUUsc0JBQWMsRUFBQyxPQVZqQjtBQVdFLFlBQUksRUFBQztBQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEYsZUEyQkU7QUFDRSxVQUFFLEVBQUMsYUFETDtBQUVFLHFCQUFVLGFBRlo7QUFHRSxVQUFFLEVBQUMsS0FITDtBQUlFLFVBQUUsRUFBQyxLQUpMO0FBS0UsU0FBQyxFQUFDLEtBTEo7QUFNRSxpQkFBUyxFQUFDLHdCQU5aO0FBT0UsbUJBQVcsRUFBQyxHQVBkO0FBUUUsY0FBTSxFQUFDLFNBUlQ7QUFTRSxxQkFBYSxFQUFDLE9BVGhCO0FBVUUsc0JBQWMsRUFBQyxPQVZqQjtBQVdFLFlBQUksRUFBQztBQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0JGLGVBd0NFO0FBQ0UsVUFBRSxFQUFDLGFBREw7QUFFRSxxQkFBVSxhQUZaO0FBR0UsVUFBRSxFQUFDLEtBSEw7QUFJRSxVQUFFLEVBQUMsS0FKTDtBQUtFLFNBQUMsRUFBQyxLQUxKO0FBTUUsaUJBQVMsRUFBQyxvQkFOWjtBQU9FLG1CQUFXLEVBQUMsR0FQZDtBQVFFLGNBQU0sRUFBQyxTQVJUO0FBU0UscUJBQWEsRUFBQyxPQVRoQjtBQVVFLHNCQUFjLEVBQUMsT0FWakI7QUFXRSxZQUFJLEVBQUM7QUFYUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhDRixlQXFERTtBQUNFLFVBQUUsRUFBQyxhQURMO0FBRUUscUJBQVUsYUFGWjtBQUdFLFVBQUUsRUFBQyxLQUhMO0FBSUUsVUFBRSxFQUFDLEtBSkw7QUFLRSxTQUFDLEVBQUMsS0FMSjtBQU1FLGlCQUFTLEVBQUMsc0JBTlo7QUFPRSxtQkFBVyxFQUFDLEdBUGQ7QUFRRSxjQUFNLEVBQUMsU0FSVDtBQVNFLHFCQUFhLEVBQUMsT0FUaEI7QUFVRSxzQkFBYyxFQUFDLE9BVmpCO0FBV0UsWUFBSSxFQUFDO0FBWFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyREYsZUFrRUU7QUFDRSxVQUFFLEVBQUMsYUFETDtBQUVFLHFCQUFVLGFBRlo7QUFHRSxVQUFFLEVBQUMsS0FITDtBQUlFLFVBQUUsRUFBQyxLQUpMO0FBS0UsU0FBQyxFQUFDLEtBTEo7QUFNRSxpQkFBUyxFQUFDLHNCQU5aO0FBT0UsbUJBQVcsRUFBQyxHQVBkO0FBUUUsY0FBTSxFQUFDLFNBUlQ7QUFTRSxxQkFBYSxFQUFDLE9BVGhCO0FBVUUsc0JBQWMsRUFBQyxPQVZqQjtBQVdFLFlBQUksRUFBQztBQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbEVGLGVBK0VFO0FBQ0UsVUFBRSxFQUFDLGFBREw7QUFFRSxxQkFBVSxhQUZaO0FBR0UsVUFBRSxFQUFDLEtBSEw7QUFJRSxVQUFFLEVBQUMsS0FKTDtBQUtFLFNBQUMsRUFBQyxLQUxKO0FBTUUsaUJBQVMsRUFBQyxzQkFOWjtBQU9FLG1CQUFXLEVBQUMsR0FQZDtBQVFFLGNBQU0sRUFBQyxTQVJUO0FBU0UscUJBQWEsRUFBQyxPQVRoQjtBQVVFLHNCQUFjLEVBQUMsT0FWakI7QUFXRSxZQUFJLEVBQUM7QUFYUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9FRixlQTRGRTtBQUNFLFVBQUUsRUFBQyxhQURMO0FBRUUscUJBQVUsYUFGWjtBQUdFLFVBQUUsRUFBQyxLQUhMO0FBSUUsVUFBRSxFQUFDLEtBSkw7QUFLRSxTQUFDLEVBQUMsS0FMSjtBQU1FLGlCQUFTLEVBQUMsd0JBTlo7QUFPRSxtQkFBVyxFQUFDLEdBUGQ7QUFRRSxjQUFNLEVBQUMsU0FSVDtBQVNFLHFCQUFhLEVBQUMsT0FUaEI7QUFVRSxzQkFBYyxFQUFDLE9BVmpCO0FBV0UsWUFBSSxFQUFDO0FBWFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1RkYsZUF5R0U7QUFDRSxVQUFFLEVBQUMsYUFETDtBQUVFLHFCQUFVLGFBRlo7QUFHRSxVQUFFLEVBQUMsS0FITDtBQUlFLFVBQUUsRUFBQyxLQUpMO0FBS0UsU0FBQyxFQUFDLEtBTEo7QUFNRSxpQkFBUyxFQUFDLHdCQU5aO0FBT0UsbUJBQVcsRUFBQyxHQVBkO0FBUUUsY0FBTSxFQUFDLFNBUlQ7QUFTRSxxQkFBYSxFQUFDLE9BVGhCO0FBVUUsc0JBQWMsRUFBQyxPQVZqQjtBQVdFLFlBQUksRUFBQztBQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekdGLGVBc0hFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLHdFQUhKO0FBSUUsaUJBQVMsRUFBQyxrQkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLFNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRIRixlQWlJRTtBQUNFLFVBQUUsRUFBQyxRQURMO0FBRUUscUJBQVUsUUFGWjtBQUdFLFVBQUUsRUFBQyxJQUhMO0FBSUUsaUJBQVMsRUFBQyxzQkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLFNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpJRixlQTRJRTtBQUNFLFVBQUUsRUFBQyxRQURMO0FBRUUscUJBQVUsUUFGWjtBQUdFLFVBQUUsRUFBQyxJQUhMO0FBSUUsaUJBQVMsRUFBQyxvQkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLFNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVJRixlQXVKRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyx3RUFISjtBQUlFLGlCQUFTLEVBQUMsa0JBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxTQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2SkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBNEtELENBakxNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLE1BQU1vQyxhQUFhLEdBQUcsQ0FBQztBQUM1QnRDLE9BQUssR0FBRyxjQURvQjtBQUU1QkMsT0FBSyxHQUFHLE1BRm9CO0FBRzVCQyxRQUFNLEdBQUc7QUFIbUIsQ0FBRCxLQUl2QjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLFFBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQyxlQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsZ0JBREw7QUFFRSxtQkFBVSxnQkFGWjtBQUdFLGVBQVMsRUFBQyw4QkFIWjtBQUFBLDhCQUtFO0FBQ0UsVUFBRSxFQUFDLGdCQURMO0FBRUUscUJBQVUsZ0JBRlo7QUFHRSxhQUFLLEVBQUMsUUFIUjtBQUlFLGNBQU0sRUFBQyxRQUpUO0FBS0UsaUJBQVMsRUFBQyw0QkFMWjtBQU1FLG1CQUFXLEVBQUMsR0FOZDtBQU9FLGNBQU0sRUFBQyxTQVBUO0FBUUUscUJBQWEsRUFBQyxPQVJoQjtBQVNFLHNCQUFjLEVBQUMsT0FUakI7QUFVRSxZQUFJLEVBQUM7QUFWUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBaUJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDhHQUhKO0FBSUUsaUJBQVMsRUFBQyxrQkFKWjtBQUtFLFlBQUksRUFBQyxNQUxQO0FBTUUsY0FBTSxFQUFDLFNBTlQ7QUFPRSxxQkFBYSxFQUFDLE9BUGhCO0FBUUUsc0JBQWMsRUFBQyxPQVJqQjtBQVNFLG1CQUFXLEVBQUM7QUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRixlQTRCRTtBQUNFLFVBQUUsRUFBQyxnQkFETDtBQUVFLHFCQUFVLGdCQUZaO0FBR0UsYUFBSyxFQUFDLFFBSFI7QUFJRSxjQUFNLEVBQUMsUUFKVDtBQUtFLGlCQUFTLEVBQUMsNEJBTFo7QUFNRSxtQkFBVyxFQUFDLEdBTmQ7QUFPRSxjQUFNLEVBQUMsU0FQVDtBQVFFLHFCQUFhLEVBQUMsT0FSaEI7QUFTRSxzQkFBYyxFQUFDLE9BVGpCO0FBVUUsWUFBSSxFQUFDO0FBVlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1QkYsZUF3Q0U7QUFDRSxVQUFFLEVBQUMsUUFETDtBQUVFLHFCQUFVLFFBRlo7QUFHRSxVQUFFLEVBQUMsTUFITDtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxTQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4Q0YsZUFtREU7QUFDRSxVQUFFLEVBQUMsUUFETDtBQUVFLHFCQUFVLFFBRlo7QUFHRSxVQUFFLEVBQUMsTUFITDtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxTQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuREYsZUE4REU7QUFDRSxVQUFFLEVBQUMsUUFETDtBQUVFLHFCQUFVLFFBRlo7QUFHRSxVQUFFLEVBQUMsTUFITDtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxTQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5REYsZUF5RUU7QUFDRSxVQUFFLEVBQUMsUUFETDtBQUVFLHFCQUFVLFFBRlo7QUFHRSxVQUFFLEVBQUMsTUFITDtBQUlFLGlCQUFTLEVBQUMsNEJBSlo7QUFLRSxZQUFJLEVBQUMsTUFMUDtBQU1FLGNBQU0sRUFBQyxTQU5UO0FBT0UscUJBQWEsRUFBQyxPQVBoQjtBQVFFLHNCQUFjLEVBQUMsT0FSakI7QUFTRSxtQkFBVyxFQUFDO0FBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6RUYsZUFvRkU7QUFDRSxVQUFFLEVBQUMsUUFETDtBQUVFLHFCQUFVLFFBRlo7QUFHRSxVQUFFLEVBQUMsT0FITDtBQUlFLFVBQUUsRUFBQyxPQUpMO0FBS0UsaUJBQVMsRUFBQyw0QkFMWjtBQU1FLFlBQUksRUFBQyxNQU5QO0FBT0UsY0FBTSxFQUFDLFNBUFQ7QUFRRSxxQkFBYSxFQUFDLE9BUmhCO0FBU0Usc0JBQWMsRUFBQyxPQVRqQjtBQVVFLG1CQUFXLEVBQUM7QUFWZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBGRixlQWdHRTtBQUNFLFVBQUUsRUFBQyxRQURMO0FBRUUscUJBQVUsUUFGWjtBQUdFLFVBQUUsRUFBQyxPQUhMO0FBSUUsVUFBRSxFQUFDLE9BSkw7QUFLRSxpQkFBUyxFQUFDLDRCQUxaO0FBTUUsWUFBSSxFQUFDLE1BTlA7QUFPRSxjQUFNLEVBQUMsU0FQVDtBQVFFLHFCQUFhLEVBQUMsT0FSaEI7QUFTRSxzQkFBYyxFQUFDLE9BVGpCO0FBVUUsbUJBQVcsRUFBQztBQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNIRCxDQTNITSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxNQUFNcUMsWUFBWSxHQUFHLENBQUM7QUFDM0J2QyxPQUFLLEdBQUcsY0FEbUI7QUFFM0JDLE9BQUssR0FBRyxNQUZtQjtBQUczQkMsUUFBTSxHQUFHO0FBSGtCLENBQUQsS0FJdEI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxJQUZSO0FBR0UsVUFBTSxFQUFDLElBSFQ7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQ0UsUUFBRSxFQUFDLGVBREw7QUFFRSxtQkFBVSxlQUZaO0FBR0UsZUFBUyxFQUFDLHNCQUhaO0FBQUEsOEJBS0U7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsaTVCQUhKO0FBSUUsWUFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQVdFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDRFQUhKO0FBSUUsaUJBQVMsRUFBQyx5QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWEYsZUFrQkU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMsNEVBSEo7QUFJRSxpQkFBUyxFQUFDLHlCQUpaO0FBS0UsWUFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBbUNELENBeENNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLE1BQU1zQyxVQUFVLEdBQUcsQ0FBQztBQUN6QnhDLE9BQUssR0FBRyxjQURpQjtBQUV6QkMsT0FBSyxHQUFHLE1BRmlCO0FBR3pCQyxRQUFNLEdBQUc7QUFIZ0IsQ0FBRCxLQUlwQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLElBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsYUFETDtBQUVFLG1CQUFVLGFBRlo7QUFHRSxlQUFTLEVBQUMscUJBSFo7QUFBQSw4QkFLRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyxrTEFISjtBQUlFLGlCQUFTLEVBQUMsaUJBSlo7QUFLRSxZQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBWUU7QUFDRSxVQUFFLEVBQUMsWUFETDtBQUVFLHFCQUFVLFlBRlo7QUFHRSxTQUFDLEVBQUMseXRDQUhKO0FBSUUsaUJBQVMsRUFBQyxtQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBNkJELENBbENNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLE1BQU11QyxJQUFJLEdBQUcsQ0FBQztBQUNuQnpDLE9BQUssR0FBRyxjQURXO0FBRW5CQyxPQUFLLEdBQUcsTUFGVztBQUduQkMsUUFBTSxHQUFHO0FBSFUsQ0FBRCxLQUlkO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUMsUUFGUjtBQUdFLFVBQU0sRUFBQyxJQUhUO0FBSUUsV0FBTyxFQUFDLGVBSlY7QUFBQSwyQkFNRTtBQUNFLFFBQUUsRUFBQyxNQURMO0FBRUUsT0FBQyxFQUFDLG1rQ0FGSjtBQUdFLGVBQVMsRUFBQyxxQkFIWjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFlRCxDQXBCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxNQUFNd0MsT0FBTyxHQUFHLENBQUM7QUFDdEIxQyxPQUFLLEdBQUcsY0FEYztBQUV0QkMsT0FBSyxHQUFHLE1BRmM7QUFHdEJDLFFBQU0sR0FBRztBQUhhLENBQUQsS0FJakI7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBQyxPQUZSO0FBR0UsVUFBTSxFQUFDLElBSFQ7QUFJRSxXQUFPLEVBQUMsY0FKVjtBQUFBLDJCQU1FO0FBQUcsUUFBRSxFQUFDLFNBQU47QUFBZ0IsZUFBUyxFQUFDLHNCQUExQjtBQUFBLDhCQUNFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDhkQUhKO0FBSUUsWUFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDRDQUhKO0FBSUUsaUJBQVMsRUFBQyxzQkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFjRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyw0Q0FISjtBQUlFLGlCQUFTLEVBQUMsc0JBSlo7QUFLRSxZQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWRGLGVBcUJFO0FBQ0UsVUFBRSxFQUFDLFlBREw7QUFFRSxxQkFBVSxZQUZaO0FBR0UsU0FBQyxFQUFDLDhEQUhKO0FBSUUsaUJBQVMsRUFBQyx5QkFKWjtBQUtFLFlBQUksRUFBQztBQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNDRCxDQTNDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxNQUFNeUMsS0FBSyxHQUFHLENBQUM7QUFDcEIzQyxPQUFLLEdBQUcsY0FEWTtBQUVwQkMsT0FBSyxHQUFHLE1BRlk7QUFHcEJDLFFBQU0sR0FBRztBQUhXLENBQUQsS0FJZjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLElBRlI7QUFHRSxVQUFNLEVBQUMsT0FIVDtBQUlFLFdBQU8sRUFBQyxjQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsY0FETDtBQUVFLG1CQUFVLGNBRlo7QUFHRSxPQUFDLEVBQUMseWhEQUhKO0FBSUUsZUFBUyxFQUFDLHNCQUpaO0FBS0UsVUFBSSxFQUFDO0FBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdCRCxDQXJCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxNQUFNMEMsS0FBSyxHQUFHLENBQUM7QUFDcEI1QyxPQUFLLEdBQUcsY0FEWTtBQUVwQkMsT0FBSyxHQUFHLE1BRlk7QUFHcEJDLFFBQU0sR0FBRztBQUhXLENBQUQsS0FJZjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFDLElBRlI7QUFHRSxVQUFNLEVBQUMsSUFIVDtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFBRyxRQUFFLEVBQUMsT0FBTjtBQUFjLGVBQVMsRUFBQyxzQkFBeEI7QUFBQSw4QkFDRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyx3V0FISjtBQUlFLFlBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFPRTtBQUNFLFVBQUUsRUFBQyxZQURMO0FBRUUscUJBQVUsWUFGWjtBQUdFLFNBQUMsRUFBQyw2ZkFISjtBQUlFLGlCQUFTLEVBQUMsbUJBSlo7QUFLRSxZQUFJLEVBQUM7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXdCRCxDQTdCTSxDOzs7Ozs7Ozs7Ozs7QUNBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFTyxNQUFNMkMsYUFBYSxHQUFHQyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3hCL1QseURBQUcsQ0FBQztBQUNGZ1UsU0FBTyxFQUFFLE1BRFA7QUFFRkMsWUFBVSxFQUFFLFFBRlY7QUFHRkMsZ0JBQWMsRUFBRSxlQUhkO0FBSUZqRCxPQUFLLEVBQUUsTUFKTDtBQUtGa0QsU0FBTyxFQUFFLGVBTFA7QUFPRkMsUUFBTSxFQUFFO0FBQ05ELFdBQU8sRUFBRTtBQURIO0FBUE4sQ0FBRCxDQURxQixDQUFuQjtBQWNBLE1BQU1FLGVBQWUsR0FBR1Asd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUMxQi9ULHlEQUFHLENBQUM7QUFDRmdVLFNBQU8sRUFBRSxNQURQO0FBRUZDLFlBQVUsRUFBRSxVQUZWO0FBR0ZoRCxPQUFLLEVBQUU7QUFITCxDQUFELENBRHVCLENBQXJCO0FBUUEsTUFBTXFELFFBQVEsR0FBR1Isd0RBQU0sQ0FBQ1MsSUFBVjtBQUFBO0FBQUE7QUFBQSxHQUNuQnZVLHlEQUFHLENBQUM7QUFDRndVLFVBQVEsRUFBRSxJQURSO0FBRUZ4RCxPQUFLLEVBQUUsV0FGTDtBQUdGeUQsWUFBVSxFQUFFLE1BSFY7QUFJRk4sU0FBTyxFQUFFLFVBSlA7QUFLRk8saUJBQWUsRUFBRSxVQUxmO0FBTUZDLGNBQVksRUFBRTtBQU5aLENBQUQsQ0FEZ0IsQ0FBZDtBQVdBLE1BQU1DLFVBQVUsR0FBR2Qsd0RBQU0sQ0FBQ1MsSUFBVjtBQUFBO0FBQUE7QUFBQSxHQUNyQnZVLHlEQUFHLENBQUM7QUFDRndVLFVBQVEsRUFBRSxNQURSO0FBRUZ4RCxPQUFLLEVBQUUsV0FGTDtBQUdGeUQsWUFBVSxFQUFFO0FBSFYsQ0FBRCxDQURrQixDQUFoQjtBQVFBLE1BQU1JLFdBQVcsR0FBR2Ysd0RBQU0sQ0FBQ1MsSUFBVjtBQUFBO0FBQUE7QUFBQSxHQUN0QnZVLHlEQUFHLENBQUM7QUFDRmdVLFNBQU8sRUFBRSxNQURQO0FBRUZHLFNBQU8sRUFBRSxPQUZQO0FBR0ZuRCxPQUFLLEVBQUU7QUFITCxDQUFELENBRG1CLENBQWpCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUNQO0FBQ0E7QUFPQTtBQUVBO0NBRUE7O0FBQ0E7O0FBU0EsTUFBTThELGNBQW9ELEdBQUcsQ0FBQztBQUM1REMsT0FENEQ7QUFFNURDLFdBRjREO0FBRzVEN1k7QUFINEQsQ0FBRCxLQUl2RDtBQUNKLFFBQU07QUFBQSxPQUFDOFksTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBb0JDLHNEQUFRLENBQUMsS0FBRCxDQUFsQztBQUNBLFFBQU07QUFBRS9PO0FBQUYsTUFBWWdQLDZEQUFTLEVBQTNCO0FBQ0Esc0JBQ0UscUVBQUMsb0VBQUQ7QUFBZSxTQUFLLEVBQUVMLEtBQXRCO0FBQTZCLGFBQVMsRUFBRUMsU0FBeEM7QUFBQSw0QkFDRSxxRUFBQyxzRUFBRDtBQUFBLGdCQUNHNU8sS0FBSyxDQUFDaVAsUUFBTixnQkFDQyxxRUFBQywrREFBRDtBQUFBLGtCQUFXQyx1REFBUyxDQUFDbFAsS0FBSyxDQUFDaVAsUUFBUDtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURELGdCQUdDLHFFQUFDLGlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQWFFLHFFQUFDLCtEQUFEO0FBQVEsYUFBTyxFQUFDLE1BQWhCO0FBQXVCLGFBQU8sRUFBRSxNQUFNSCxPQUFPLENBQUMsSUFBRCxDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFiRixlQWdCRSxxRUFBQyw0RUFBRDtBQUFhLFlBQU0sRUFBRUQsTUFBckI7QUFBNkIsb0JBQWMsRUFBRSxNQUFNQyxPQUFPLENBQUMsS0FBRCxDQUExRDtBQUFBLGdCQUNHL1k7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNCRCxDQTdCRDs7QUErQmUyWSw2RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyREE7QUFDQTs7QUFFQSxNQUFNUyxVQUFVLEdBQUlwYSxLQUFELGlCQUNqQixxRUFBQywyREFBRDtBQUNFLFFBQU0sRUFBRSxHQURWO0FBRUUsT0FBSyxFQUFFLEdBRlQ7QUFHRSxPQUFLLEVBQUUsQ0FIVDtBQUlFLGlCQUFlLEVBQUMsU0FKbEI7QUFLRSxpQkFBZSxFQUFDO0FBTGxCLEdBTU1BLEtBTk47QUFBQSwwQkFRRTtBQUFNLEtBQUMsRUFBQyxHQUFSO0FBQVksS0FBQyxFQUFDLEdBQWQ7QUFBa0IsTUFBRSxFQUFDLEdBQXJCO0FBQXlCLE1BQUUsRUFBQyxHQUE1QjtBQUFnQyxTQUFLLEVBQUMsS0FBdEM7QUFBNEMsVUFBTSxFQUFDO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFSRixlQVNFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxLQUF6QztBQUErQyxVQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVRGLGVBVUU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVkYsZUFXRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFYRixlQVlFO0FBQU0sS0FBQyxFQUFDLEtBQVI7QUFBYyxLQUFDLEVBQUMsS0FBaEI7QUFBc0IsTUFBRSxFQUFDLEdBQXpCO0FBQTZCLE1BQUUsRUFBQyxHQUFoQztBQUFvQyxTQUFLLEVBQUMsSUFBMUM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjs7QUFnQk8sTUFBTXFhLG1CQUFtQixHQUFHLG1CQUNqQyxxRUFBQywyREFBRDtBQUNFLFFBQU0sRUFBRSxFQURWO0FBRUUsT0FBSyxFQUFFLEdBRlQ7QUFHRSxPQUFLLEVBQUUsQ0FIVDtBQUlFLGlCQUFlLEVBQUMsU0FKbEI7QUFLRSxpQkFBZSxFQUFDLFNBTGxCO0FBQUEsMEJBT0U7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxJQUFmO0FBQW9CLE1BQUUsRUFBQyxHQUF2QjtBQUEyQixNQUFFLEVBQUMsR0FBOUI7QUFBa0MsU0FBSyxFQUFDLEtBQXhDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUEYsZUFRRTtBQUFNLEtBQUMsRUFBQyxLQUFSO0FBQWMsS0FBQyxFQUFDLElBQWhCO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUkYsZUFTRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLElBQWY7QUFBb0IsTUFBRSxFQUFDLEdBQXZCO0FBQTJCLE1BQUUsRUFBQyxHQUE5QjtBQUFrQyxTQUFLLEVBQUMsSUFBeEM7QUFBNkMsVUFBTSxFQUFDO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESztBQWNBLE1BQU1DLGFBQWEsR0FBSXRhLEtBQUQsaUJBQzNCLHFFQUFDLDJEQUFEO0FBQ0UsUUFBTSxFQUFFLEdBRFY7QUFFRSxPQUFLLEVBQUMsbUJBRlI7QUFHRSxPQUFLLEVBQUUsQ0FIVDtBQUlFLGlCQUFlLEVBQUMsU0FKbEI7QUFLRSxpQkFBZSxFQUFDO0FBTGxCLEdBTU1BLEtBTk47QUFBQSwwQkFRRTtBQUFNLEtBQUMsRUFBQyxLQUFSO0FBQWMsS0FBQyxFQUFDLElBQWhCO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLEdBQXpDO0FBQTZDLFVBQU0sRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUkYsZUFTRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLElBQWY7QUFBb0IsTUFBRSxFQUFDLEdBQXZCO0FBQTJCLE1BQUUsRUFBQyxHQUE5QjtBQUFrQyxTQUFLLEVBQUMsSUFBeEM7QUFBNkMsVUFBTSxFQUFDO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURixlQVVFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsSUFBZjtBQUFvQixNQUFFLEVBQUMsR0FBdkI7QUFBMkIsTUFBRSxFQUFDLEdBQTlCO0FBQWtDLFNBQUssRUFBQyxLQUF4QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVZGLGVBWUU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxJQUFmO0FBQW9CLE1BQUUsRUFBQyxHQUF2QjtBQUEyQixNQUFFLEVBQUMsR0FBOUI7QUFBa0MsU0FBSyxFQUFDLElBQXhDO0FBQTZDLFVBQU0sRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWkYsZUFhRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLElBQWY7QUFBb0IsTUFBRSxFQUFDLEdBQXZCO0FBQTJCLE1BQUUsRUFBQyxHQUE5QjtBQUFrQyxTQUFLLEVBQUMsS0FBeEM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFiRixlQWVFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWZGLGVBZ0JFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxLQUF6QztBQUErQyxVQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWhCRixlQWtCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFsQkYsZUFtQkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLEtBQXpDO0FBQStDLFVBQU0sRUFBQztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbkJGLGVBcUJFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXJCRixlQXNCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsS0FBekM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF0QkYsZUF3QkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLElBQXpDO0FBQThDLFVBQU0sRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeEJGLGVBeUJFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxLQUF6QztBQUErQyxVQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXpCRixlQTJCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsSUFBekM7QUFBOEMsVUFBTSxFQUFDO0FBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEzQkYsZUE0QkU7QUFBTSxLQUFDLEVBQUMsSUFBUjtBQUFhLEtBQUMsRUFBQyxLQUFmO0FBQXFCLE1BQUUsRUFBQyxHQUF4QjtBQUE0QixNQUFFLEVBQUMsR0FBL0I7QUFBbUMsU0FBSyxFQUFDLEtBQXpDO0FBQStDLFVBQU0sRUFBQztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNUJGLGVBOEJFO0FBQU0sS0FBQyxFQUFDLElBQVI7QUFBYSxLQUFDLEVBQUMsS0FBZjtBQUFxQixNQUFFLEVBQUMsR0FBeEI7QUFBNEIsTUFBRSxFQUFDLEdBQS9CO0FBQW1DLFNBQUssRUFBQyxJQUF6QztBQUE4QyxVQUFNLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTlCRixlQStCRTtBQUFNLEtBQUMsRUFBQyxJQUFSO0FBQWEsS0FBQyxFQUFDLEtBQWY7QUFBcUIsTUFBRSxFQUFDLEdBQXhCO0FBQTRCLE1BQUUsRUFBQyxHQUEvQjtBQUFtQyxTQUFLLEVBQUMsS0FBekM7QUFBK0MsVUFBTSxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREs7QUFtQ1FvYSx5RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEVBO0FBU08sTUFBTUcsU0FBbUMsR0FBRyxVQU03QztBQUFBLE1BTjhDO0FBQ2xEdlosWUFEa0Q7QUFFbEQ2WSxhQUZrRDtBQUdsRDlhLFdBSGtEO0FBSWxENmE7QUFKa0QsR0FNOUM7QUFBQSxNQURENVosS0FDQzs7QUFDSixzQkFDRSxxRUFBQyxrRkFBRDtBQUNFLFdBQU87QUFDTDZaLGVBQVMsRUFBRyxHQUFFQSxTQUFVLGdCQURuQjtBQUVMVyxnQkFBVSxFQUFFO0FBQ1ZDLGdCQUFRLEVBQUU7QUFEQTtBQUZQLE9BS0YxYixPQUxFLENBRFQ7QUFRRSxTQUFLLEVBQUU2YTtBQVJULEtBU001WixLQVROO0FBQUEsY0FXR2dCO0FBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0F0Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNUUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVNBLE1BQU0wWixXQUF1QyxHQUFHLENBQUM7QUFDL0NaLFFBRCtDO0FBRS9DYSxnQkFGK0M7QUFHL0MzWixVQUgrQztBQUkvQzRZLE9BQUssR0FBRztBQUp1QyxDQUFELEtBSzFDO0FBQ0osUUFBTWdCLFVBQVUsR0FBR0Msa0VBQWEsQ0FBQ2YsTUFBRCxFQUFTLElBQVQsRUFBZTtBQUM3Q2dCLFFBQUksRUFBRTtBQUFFQyxlQUFTLEVBQUU7QUFBYixLQUR1QztBQUU3Q0MsU0FBSyxFQUFFO0FBQUVELGVBQVMsRUFBRTtBQUFiLEtBRnNDO0FBRzdDRSxTQUFLLEVBQUU7QUFBRUYsZUFBUyxFQUFFO0FBQWI7QUFIc0MsR0FBZixDQUFoQztBQU1BLFFBQU1HLFlBQVksR0FBRztBQUNuQkMsWUFBUSxFQUFFLFVBRFM7QUFFbkJDLFVBQU0sRUFBRSxDQUZXO0FBR25CQyxRQUFJLEVBQUUsS0FIYTtBQUluQnJDLFdBQU8sRUFBRSxHQUpVO0FBS25CbEQsU0FBSyxFQUFFLGtCQUxZO0FBTW5CQyxVQUFNLEVBQUUsTUFOVztBQU9uQnVGLGFBQVMsRUFBRSxNQVBRO0FBUW5CL0IsbUJBQWUsRUFBRSxTQVJFO0FBU25CQyxnQkFBWSxFQUFFLEtBVEs7QUFVbkIrQix1QkFBbUIsRUFBRSxNQVZGO0FBV25CQyx3QkFBb0IsRUFBRSxNQVhIO0FBWW5CQyxVQUFNLEVBQUU7QUFaVyxHQUFyQjtBQWVBLFFBQU1DLFdBQVcsR0FBRztBQUNsQjVGLFNBQUssRUFBRSxFQURXO0FBRWxCQyxVQUFNLEVBQUUsRUFGVTtBQUdsQjhDLFdBQU8sRUFBRSxNQUhTO0FBSWxCQyxjQUFVLEVBQUUsUUFKTTtBQUtsQkMsa0JBQWMsRUFBRSxRQUxFO0FBTWxCUSxtQkFBZSxFQUFFLFNBTkM7QUFPbEIxRCxTQUFLLEVBQUUsU0FQVztBQVFsQjhGLFVBQU0sRUFBRSxDQVJVO0FBU2xCQyxXQUFPLEVBQUUsQ0FUUztBQVVsQkMsYUFBUyxFQUFFLE1BVk87QUFXbEJyQyxnQkFBWSxFQUFFLEtBWEk7QUFZbEIyQixZQUFRLEVBQUUsVUFaUTtBQWFsQlcsT0FBRyxFQUFFLENBQUMsRUFiWTtBQWNsQlQsUUFBSSxFQUFFLEtBZFk7QUFlbEJOLGFBQVMsRUFBRSxrQkFmTztBQWdCbEJnQixVQUFNLEVBQUUsU0FoQlU7QUFrQmxCLGNBQVU7QUFDUkgsYUFBTyxFQUFFLENBREQ7QUFFUkMsZUFBUyxFQUFFO0FBRkg7QUFsQlEsR0FBcEI7QUF3QkEsUUFBTUcsY0FBYyxHQUFHO0FBQ3JCakcsVUFBTSxFQUFFLE1BRGE7QUFFckJ1RixhQUFTLEVBQUU7QUFGVSxHQUF2QjtBQUtBLHNCQUNFLHFFQUFDLDREQUFEO0FBQVcsVUFBTSxFQUFFeEIsTUFBbkI7QUFBMkIsa0JBQWMsRUFBRWEsY0FBM0M7QUFBQSxjQUNHQyxVQUFVLENBQUMxWCxHQUFYLENBQ0MsQ0FBQztBQUFFbVEsVUFBRjtBQUFRM1QsU0FBUjtBQUFhTSxXQUFLLEVBQUVpYztBQUFwQixLQUFELEtBQ0U1SSxJQUFJLGlCQUNGLHFFQUFDLHFEQUFELENBQVUsR0FBVjtBQUVFLFdBQUssZ0RBQU80SSxnQkFBUCxHQUE0QmYsWUFBNUIsR0FBNkN0QixLQUE3QyxDQUZQO0FBQUEsOEJBSUU7QUFDRSxZQUFJLEVBQUMsUUFEUDtBQUVFLGVBQU8sRUFBRWUsY0FGWDtBQUdFLGFBQUssb0JBQU9lLFdBQVAsQ0FIUDtBQUFBLCtCQUtFLHFFQUFDLGdFQUFEO0FBQVcsZUFBSyxFQUFFO0FBQUU1RixpQkFBSyxFQUFFLEVBQVQ7QUFBYUMsa0JBQU0sRUFBRTtBQUFyQjtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQVdFLHFFQUFDLHdFQUFEO0FBQVcsYUFBSyxvQkFBT2lHLGNBQVAsQ0FBaEI7QUFBQSwrQkFDRTtBQUFLLGVBQUssRUFBRTtBQUFFaEQsbUJBQU8sRUFBRTtBQUFYLFdBQVo7QUFBQSxvQkFBa0NoWTtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRjtBQUFBLE9BQ090QixHQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEw7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF3QkQsQ0FoRkQ7O0FBa0ZlZ2IsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDL0ZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNPLE1BQU13QixNQUFNLEdBQUd2RCx3REFBTSxDQUFDd0QsTUFBVjtBQUFBO0FBQUE7QUFBQSxHQUNoQm5jLEtBQUQsSUFDRTZFLHlEQUFHLENBQUM7QUFDRndVLFVBQVEsRUFBRXJaLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsUUFBaEIsR0FBMkIsQ0FBQyxNQUFELENBQTNCLEdBQXNDLENBQUMsSUFBRCxDQUQ5QztBQUVGOUMsWUFBVSxFQUFFLFFBRlY7QUFHRlQsU0FBTyxFQUFFLE1BSFA7QUFJRkMsWUFBVSxFQUFFLFFBSlY7QUFLRnVELGNBQVksRUFBRXJjLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsUUFBaEIsR0FBMkIsRUFBM0IsR0FBZ0MsQ0FMNUM7QUFNRnZHLE9BQUssRUFDSDdWLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsUUFBaEIsR0FDSXBjLEtBQUssQ0FBQ3NjLElBQU4sR0FDRSxpQkFERixHQUVFLFdBSE4sR0FJSXRjLEtBQUssQ0FBQ3NjLElBQU4sR0FDQSxpQkFEQSxHQUVBLGNBYko7QUFjRlAsUUFBTSxFQUFFLFNBZE47QUFlRm5CLFlBQVUsRUFBRSxtQkFmVjtBQWdCRjVCLFNBQU8sRUFBRWhaLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsUUFBaEIsR0FBMkIsT0FBM0IsR0FBcUMsVUFoQjVDO0FBaUJGRyxZQUFVLEVBQUV2YyxLQUFLLENBQUNvYyxLQUFOLEtBQWdCLE9BQWhCLEdBQTBCLE9BQTFCLEdBQW9DLElBakI5QztBQWtCRjVDLGNBQVksRUFBRXhaLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsT0FBaEIsR0FBMEIsTUFBMUIsR0FBbUMsSUFsQi9DO0FBbUJGN0MsaUJBQWUsRUFDYnZaLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsT0FBaEIsR0FBMEJwYyxLQUFLLENBQUNzYyxJQUFOLElBQWMsVUFBeEMsR0FBcUQsSUFwQnJEO0FBc0JGLG1CQUFpQjtBQUNmekcsU0FBSyxFQUFFN1YsS0FBSyxDQUFDc2MsSUFBTixHQUFhLGlCQUFiLEdBQWlDLFdBRHpCO0FBRWZ0RCxXQUFPLEVBQUUsT0FGTTtBQUdmdUQsY0FBVSxFQUFFLE1BSEc7QUFJZnhHLFVBQU0sRUFBRSxNQUpPO0FBS2Y2RSxjQUFVLEVBQUUsZ0JBTEc7QUFNZkcsYUFBUyxFQUFFL2EsS0FBSyxDQUFDc2MsSUFBTixHQUFhLGVBQWIsR0FBK0I7QUFOM0IsR0F0QmY7QUErQkYsYUFBVztBQUNUekcsU0FBSyxFQUFFLGlCQURFO0FBR1QscUJBQWlCO0FBQ2ZBLFdBQUssRUFBRTtBQURRO0FBSFI7QUEvQlQsQ0FBRCxDQUZZLEVBeUNqQjtBQUNFK0YsU0FBTyxFQUFFO0FBRFgsQ0F6Q2lCLENBQVo7QUE4Q0EsTUFBTWxDLFdBQVcsR0FBR2Ysd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNyQjVZLEtBQUQsSUFDRTZFLHlEQUFHLENBQUM7QUFDRmlSLE9BQUssRUFBRTlWLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsT0FBaEIsR0FBMEIsRUFBMUIsR0FBK0IsRUFEcEM7QUFFRnJHLFFBQU0sRUFBRSxNQUZOO0FBR0Z5RyxhQUFXLEVBQUV4YyxLQUFLLENBQUNvYyxLQUFOLEtBQWdCLE9BQWhCLEdBQTBCLEtBQTFCLEdBQWtDLEVBSDdDO0FBS0ZLLEtBQUcsRUFBRTtBQUNIQyxZQUFRLEVBQUUsTUFEUDtBQUVIcEIsYUFBUyxFQUFFLEVBRlI7QUFHSHZGLFVBQU0sRUFBRS9WLEtBQUssQ0FBQ29jLEtBQU4sS0FBZ0IsT0FBaEIsR0FBMEIsS0FBMUIsR0FBa0M7QUFIdkM7QUFMSCxDQUFELENBRmlCLEVBYXRCO0FBQ0V2RCxTQUFPLEVBQUUsTUFEWDtBQUVFQyxZQUFVLEVBQUUsUUFGZDtBQUdFQyxnQkFBYyxFQUFFLFFBSGxCO0FBSUU0RCxVQUFRLEVBQUUsUUFKWjtBQUtFQyxZQUFVLEVBQUU7QUFMZCxDQWJzQixDQUFqQjtBQXNCQSxNQUFNQyxLQUFLLEdBQUdsRSx3REFBTSxDQUFDUyxJQUFWO0FBQUE7QUFBQTtBQUFBLEdBQWU7QUFDL0IwRCxjQUFZLEVBQUUsVUFEaUI7QUFFL0JDLFlBQVUsRUFBRSxRQUZtQjtBQUcvQkMsZUFBYSxFQUFFLFFBSGdCO0FBSS9CTCxVQUFRLEVBQUU7QUFKcUIsQ0FBZixDQUFYO0FBT0EsTUFBTU0sT0FBTyxHQUFHdEUsd0RBQU0sQ0FBQ3VFLHFEQUFRLENBQUN0RSxHQUFWLENBQVQ7QUFBQTtBQUFBO0FBQUEsR0FBd0I7QUFDMUN1RSxZQUFVLEVBQUUsNEJBRDhCO0FBRTFDQyxZQUFVLEVBQUUsQ0FGOEI7QUFHMUNULFVBQVEsRUFBRTtBQUhnQyxDQUF4QixDQUFiO0FBTUEsTUFBTVUsS0FBSyxHQUFHMUUsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNmNVksS0FBRCxJQUNFNkUseURBQUcsQ0FBQztBQUNGd1gsY0FBWSxFQUFFcmMsS0FBSyxDQUFDb2MsS0FBTixLQUFnQixRQUFoQixHQUEyQixFQUEzQixHQUFnQyxFQUQ1QztBQUVGa0IsYUFBVyxFQUFFdGQsS0FBSyxDQUFDb2MsS0FBTixLQUFnQixPQUFoQixHQUEwQixFQUExQixHQUErQjtBQUYxQyxDQUFELENBRlcsRUFNaEI7QUFDRWpCLFVBQVEsRUFBRSxVQURaO0FBR0VvQyxXQUFTLEVBQUU7QUFIYixDQU5nQixDQUFYLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEZQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUMsSUFBSSxnQkFBRzdjLDRDQUFLLENBQUM4YyxJQUFOLENBQ1gsQ0FBQztBQUNDemMsVUFERDtBQUVDZ0ksTUFGRDtBQUdDMFUsTUFIRDtBQUlDO0FBQ0E3YixTQUxEO0FBTUM4YixVQU5EO0FBT0NDLGtCQVBEO0FBUUN4QixPQVJEO0FBU0N5QixhQUFXLEdBQUc7QUFUZixDQUFELEtBVVc7QUFDVCxRQUFNO0FBQUEsT0FBQy9ELE1BQUQ7QUFBQSxPQUFTQztBQUFULE1BQW9CQyxzREFBUSxDQUFDNkQsV0FBRCxDQUFsQztBQUNBQyx5REFBUyxDQUFDLE1BQU07QUFDZC9ELFdBQU8sQ0FBQzhELFdBQUQsQ0FBUDtBQUNELEdBRlEsRUFFTixDQUFDQSxXQUFELENBRk0sQ0FBVDtBQUdBLFFBQU1FLFFBQVEsR0FBR0MsK0RBQVcsQ0FBQ2xFLE1BQUQsQ0FBNUI7QUFDQSxRQUFNLENBQUNtRSxJQUFELEVBQU87QUFBRWxJLFVBQU0sRUFBRW1JO0FBQVYsR0FBUCxJQUFpQ0MsOERBQVUsRUFBakQ7QUFDQSxRQUFNO0FBQUVwSSxVQUFGO0FBQVVxSSxXQUFWO0FBQW1CckQ7QUFBbkIsTUFBaUNzRCw4REFBUyxDQUFNO0FBQ3BEdkQsUUFBSSxFQUFFO0FBQUUvRSxZQUFNLEVBQUUsQ0FBVjtBQUFhcUksYUFBTyxFQUFFLENBQXRCO0FBQXlCckQsZUFBUyxFQUFFO0FBQXBDLEtBRDhDO0FBRXBEdUQsTUFBRSxFQUFFO0FBQ0Z2SSxZQUFNLEVBQUUrRCxNQUFNLEdBQUdvRSxVQUFILEdBQWdCLENBRDVCO0FBRUZFLGFBQU8sRUFBRXRFLE1BQU0sR0FBRyxDQUFILEdBQU8sQ0FGcEI7QUFHRmlCLGVBQVMsRUFBRyxlQUFjakIsTUFBTSxHQUFHLENBQUgsR0FBTyxFQUFHO0FBSHhDO0FBRmdELEdBQU4sQ0FBaEQsQ0FQUyxDQWVUO0FBQ0E7O0FBQ0EsUUFBTXlFLElBQUksR0FBRyxDQUFDO0FBQUVDLFlBQUY7QUFBWTVFO0FBQVosR0FBRCxLQUF5RDtBQUNwRSxVQUFNNkUsT0FBTyxHQUFHQyx3REFBSyxDQUFDRixRQUFELENBQXJCO0FBQ0EsV0FBTyxDQUFDLENBQUNDLE9BQUYsZ0JBQ0wscUVBQUMsT0FBRDtBQUFTLFdBQUssRUFBRTdFO0FBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREssZ0JBR0w7QUFBQSxrQ0FBaUI0RSxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEY7QUFLRCxHQVBEOztBQVFBLHNCQUNFLHFFQUFDLHNEQUFEO0FBQU8sU0FBSyxFQUFFcEMsS0FBZDtBQUFBLDRCQUNFLHFFQUFDLHVEQUFEO0FBQVEsVUFBSSxFQUFFdEMsTUFBZDtBQUFzQixXQUFLLEVBQUVzQyxLQUE3QjtBQUFvQyxlQUFTLEVBQUVBLEtBQS9DO0FBQUEsaUJBQ0dzQixJQUFJLGlCQUNILHFFQUFDLDREQUFEO0FBQWEsYUFBSyxFQUFFdEIsS0FBcEI7QUFBQSwrQkFDRSxxRUFBQyxJQUFEO0FBQU0sa0JBQVEsRUFBRXNCO0FBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKLGVBTUUscUVBQUMsc0RBQUQ7QUFBTyxlQUFPLEVBQUU3YixPQUFoQjtBQUFBLGtCQUEwQm1IO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkYsRUFRRzJVLFFBQVEsS0FBSyxJQUFiLGlCQUNDLHFFQUFDLCtEQUFEO0FBQ0UsZUFBTyxFQUFFLE1BQU01RCxPQUFPLENBQUMsQ0FBQ0QsTUFBRixDQUR4QjtBQUVFLGVBQU8sRUFBQyxNQUZWO0FBR0UsaUJBQVMsRUFBQyxjQUhaO0FBQUEsK0JBS0UscUVBQUMsZ0VBQUQ7QUFBVyxlQUFLLEVBQUM7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBbUJFLHFFQUFDLHdEQUFEO0FBQ0UsV0FBSyxFQUFFO0FBQ0xzRSxlQURLO0FBRUxySSxjQUFNLEVBQUUrRCxNQUFNLElBQUlpRSxRQUFRLEtBQUtqRSxNQUF2QixHQUFnQyxNQUFoQyxHQUF5Qy9EO0FBRjVDLE9BRFQ7QUFBQSw2QkFNRSxxRUFBQyxxREFBRCxDQUFVLEdBQVY7QUFBYyxhQUFLLEVBQUU7QUFBRWdGO0FBQUY7QUFBckIsU0FBd0NrRCxJQUF4QztBQUE4QyxnQkFBUSxFQUFFamQ7QUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBOEJELENBbEVVLENBQWI7QUEyRU8sTUFBTTJkLFFBQXlCLEdBQUcsQ0FBQztBQUN4Qy9SLE1BRHdDO0FBRXhDaU4sV0FGd0M7QUFHeENoWSxTQUh3QztBQUl4QytjO0FBSndDLENBQUQsS0FLbkM7QUFDSixRQUFNcFYsT0FBTyxHQUFJeEksUUFBRCxJQUFjO0FBQzVCLFdBQU9BLFFBQVEsQ0FBQ2tDLEdBQVQsQ0FBYzJiLFNBQUQsSUFBZTtBQUNqQyxVQUFJLENBQUNBLFNBQVMsQ0FBQzdkLFFBQWYsRUFBeUI7QUFDdkIsNEJBQ0UscUVBQUMsSUFBRDtBQUVFLGNBQUksRUFBRTZkLFNBQVMsQ0FBQ0MsS0FGbEI7QUFHRSxjQUFJLEVBQUVELFNBQVMsQ0FBQ25CLElBSGxCO0FBSUUsZUFBSyxFQUFDLE9BSlI7QUFLRSxpQkFBTyxFQUFFLE1BQU03YixPQUFPLENBQUNnZCxTQUFTLENBQUNFLElBQVgsQ0FMeEI7QUFNRSxxQkFBVyxFQUFFSCxNQUFNLEtBQUtDLFNBQVMsQ0FBQ0U7QUFOcEMsV0FDT0YsU0FBUyxDQUFDQyxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBVUQ7O0FBQ0QsMEJBQ0UscUVBQUMsSUFBRDtBQUVFLFlBQUksRUFBRUQsU0FBUyxDQUFDQyxLQUZsQjtBQUdFLFlBQUksRUFBRUQsU0FBUyxDQUFDbkIsSUFIbEI7QUFJRSxnQkFBUSxFQUFFLENBQUNtQixTQUFTLENBQUM3ZCxRQUFWLENBQW1CZ2UsTUFBcEIsR0FBNkIsS0FBN0IsR0FBcUMsSUFKakQ7QUFLRSxhQUFLLEVBQUMsUUFMUjtBQU1FLGVBQU8sRUFBRSxNQUFNbmQsT0FBTyxDQUFDZ2QsU0FBUyxDQUFDRSxJQUFYLENBTnhCO0FBT0UsbUJBQVcsRUFDVEgsTUFBTSxLQUFLQyxTQUFTLENBQUNFLElBQXJCLElBQ0FGLFNBQVMsQ0FBQzdkLFFBQVYsQ0FBbUJpZSxJQUFuQixDQUF5QjVMLElBQUQsSUFBVUEsSUFBSSxDQUFDMEwsSUFBTCxLQUFjSCxNQUFoRCxDQVRKO0FBQUEsa0JBWUdwVixPQUFPLENBQUNxVixTQUFTLENBQUM3ZCxRQUFYO0FBWlYsU0FDTzZkLFNBQVMsQ0FBQ0MsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQWdCRCxLQTdCTSxDQUFQO0FBOEJELEdBL0JEOztBQWdDQSxzQkFBTztBQUFBLGNBQUd0VixPQUFPLENBQUNvRCxJQUFEO0FBQVYsbUJBQVA7QUFDRCxDQXZDTSxDOzs7Ozs7Ozs7Ozs7QUNuRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBLE1BQU1zUyxJQUFJLEdBQUdDLG1FQUFILG9DQUFWO0FBU08sTUFBTUMsY0FBYyxHQUFHekcsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxpV0FrQkN5Ryx5RUFBUSxDQUFDLGlCQUFELEVBQW9CLFNBQXBCLENBbEJULEVBd0JSSCxJQXhCUSxDQUFwQjtBQWdDQSxNQUFNSSxlQUFlLEdBQUczRyx3REFBTSxDQUFDUyxJQUFWO0FBQUE7QUFBQTtBQUFBLCtRQU9OaUcseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQVBGLEVBUVJBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsTUFBbkIsQ0FSQSxFQVNYQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBVEcsRUFVakJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQVZTLEVBZ0JQQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBaEJELENBQXJCO0FBb0JBLE1BQU1FLGNBQWMsR0FBRzVHLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsc09BQXBCO0FBcUJBLE1BQU1NLGVBQWUsR0FBR1Asd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxxQ0FBckI7QUFLQSxNQUFNNEcsV0FBVyxHQUFHN0csd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw2Q0FBakI7QUFLQSxNQUFNNkcsY0FBYyxHQUFHOUcsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxnUEFDUHlHLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsTUFBbkIsQ0FERCxFQUVWQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBRkUsRUFHaEJBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FIUSxFQWtCWkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQWxCSSxDQUFwQjtBQXVCQSxNQUFNSyxPQUFPLEdBQUcvRyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLDhIQU1BeUcseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixNQUFuQixDQU5SLEVBT1RBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FQQyxDQUFiLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JIUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQVFBO0FBQ0E7QUFFQTtBQUNBOztBQVdBLE1BQU1NLGVBQStDLEdBQUcsQ0FBQztBQUN2REMsWUFBVSxFQUFFO0FBQUVDLFVBQUY7QUFBVUMsVUFBVjtBQUFrQkM7QUFBbEIsR0FEMkM7QUFFdkRDO0FBRnVELENBQUQsS0FHbEQ7QUFDSixRQUFNcGhCLE1BQU0sR0FBR3FiLDZEQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFFck4sUUFBRjtBQUFRcVQ7QUFBUixNQUFvQkMsK0RBQVEsQ0FBQ0MsNEVBQUQsRUFBaUI7QUFDakRDLGFBQVMsRUFBRTtBQUFFSjtBQUFGO0FBRHNDLEdBQWpCLENBQWxDO0FBR0EsUUFBTTtBQUFFbGYsWUFBRjtBQUFZbUs7QUFBWixNQUFzQnJNLE1BQTVCO0FBQ0EsUUFBTXloQixlQUFlLEdBQUdwVixLQUFLLENBQUNpUCxRQUE5Qjs7QUFFQSxRQUFNb0csZUFBZSxHQUFJdkIsSUFBRCxJQUFrQjtBQUN4QyxVQUFNO0FBQUVpQjtBQUFGLFFBQW9CL1UsS0FBMUI7QUFBQSxVQUFpQnNWLElBQWpCLDRCQUEwQnRWLEtBQTFCOztBQUNBLFFBQUkrVSxJQUFKLEVBQVU7QUFDUnBoQixZQUFNLENBQUNpUSxJQUFQLENBQ0U7QUFDRS9OLGdCQURGO0FBRUVtSyxhQUFLLGtDQUFPc1YsSUFBUDtBQUFhckcsa0JBQVEsRUFBRTZFO0FBQXZCO0FBRlAsT0FERixFQUtFO0FBQ0VqZSxnQkFBUSxFQUFHLElBQUdrZixJQUFLLEVBRHJCO0FBRUUvVSxhQUFLLGtDQUFPc1YsSUFBUDtBQUFhckcsa0JBQVEsRUFBRTZFO0FBQXZCO0FBRlAsT0FMRjtBQVVELEtBWEQsTUFXTztBQUNMbmdCLFlBQU0sQ0FBQ2lRLElBQVAsQ0FBWTtBQUNWL04sZ0JBRFU7QUFFVm1LLGFBQUssa0NBQU9zVixJQUFQO0FBQWFyRyxrQkFBUSxFQUFFNkU7QUFBdkI7QUFGSyxPQUFaO0FBSUQ7QUFDRixHQW5CRDs7QUFvQkEsUUFBTXlCLGVBQWUsR0FBR0MsNkVBQVcsQ0FBQyxpQkFBRCxDQUFuQzs7QUFFQSxNQUFJLENBQUM3VCxJQUFELElBQVNxVCxPQUFiLEVBQXNCO0FBQ3BCLFFBQUlKLE1BQU0sSUFBSUMsTUFBZCxFQUFzQjtBQUNwQiwwQkFBTyxxRUFBQyxzRkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFQO0FBQ0Q7O0FBQ0Qsd0JBQU8scUVBQUMsZ0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUDtBQUNEOztBQUNELHNCQUNFLHFFQUFDLCtEQUFEO0FBQUEsNEJBQ0UscUVBQUMsOERBQUQ7QUFBQSw2QkFDRSxxRUFBQyxtRkFBRDtBQUFBLG1CQUNHRSxJQUFJLEtBQUssVUFBVCxpQkFDQyxxRUFBQyxnREFBRDtBQUFNLGNBQUksRUFBRVUseUZBQTBCLENBQUMxaEIsSUFBdkM7QUFBQSxpQ0FDRSxxRUFBQywrREFBRDtBQUFBLG1DQUNFLHFFQUFDLDJEQUFEO0FBQ0UsZ0JBQUUsRUFBRTBoQix5RkFBMEIsQ0FBQ2hZLEVBRGpDO0FBRUUsNEJBQWMsRUFBRWdZLHlGQUEwQixDQUFDQztBQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkosZUFXRSxxRUFBQyx3RUFBRDtBQUNFLGNBQUksRUFBRS9ULElBQUksQ0FBQ2dVLFVBRGI7QUFFRSxpQkFBTyxFQUFFTixlQUZYO0FBR0UsZ0JBQU0sRUFBRUQ7QUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFxQkUscUVBQUMsOERBQUQ7QUFBZ0IsV0FBSyxFQUFFO0FBQUVRLGtCQUFVLEVBQUViLElBQUksS0FBSyxVQUFULEdBQXNCLENBQXRCLEdBQTBCO0FBQXhDLE9BQXZCO0FBQUEsNkJBQ0UscUVBQUMsdURBQUQ7QUFBUSxlQUFPLEVBQUVRLGVBQWpCO0FBQWtDLFdBQUcsRUFBRVIsSUFBSSxLQUFLLFVBQVQsR0FBc0IsRUFBdEIsR0FBMkIsR0FBbEU7QUFBQSxtQkFDR0EsSUFBSSxLQUFLLFVBQVQsaUJBQ0MscUVBQUMsZ0RBQUQ7QUFBTSxjQUFJLEVBQUVVLHlGQUEwQixDQUFDMWhCLElBQXZDO0FBQUEsaUNBQ0UscUVBQUMsK0RBQUQ7QUFBQSxtQ0FDRSxxRUFBQywyREFBRDtBQUNFLGdCQUFFLEVBQUUwaEIseUZBQTBCLENBQUNoWSxFQURqQztBQUVFLDRCQUFjLEVBQUVnWSx5RkFBMEIsQ0FBQ0M7QUFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKLGVBWUUscUVBQUMsd0VBQUQ7QUFBVyxtQkFBUyxFQUFDLG1CQUFyQjtBQUFBLGlDQUNFLHFFQUFDLDJEQUFEO0FBQUEsbUNBQ0UscUVBQUMsd0VBQUQ7QUFDRSxrQkFBSSxFQUFFL1QsSUFBSSxDQUFDZ1UsVUFEYjtBQUVFLHFCQUFPLEVBQUVOLGVBRlg7QUFHRSxvQkFBTSxFQUFFRDtBQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdERCxDQXZGRDs7QUF5RmVWLDhFQUFmLEU7Ozs7Ozs7Ozs7OztBQzVIQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1tQixTQUFTLEdBQUcsR0FBbEI7QUFDQSxNQUFNQyxZQUFZLEdBQUcsVUFBckI7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBRyxjQUF6QjtBQUNBLE1BQU1DLFdBQVcsR0FBRyxTQUFwQjtBQUNBLE1BQU1DLFdBQVcsR0FBRyxTQUFwQjtBQUNBLE1BQU1DLGFBQWEsR0FBRyxXQUF0QjtBQUNBLE1BQU1DLFNBQVMsR0FBRyxPQUFsQjtBQUNBLE1BQU1DLFNBQVMsR0FBRyxPQUFsQjtBQUNBLE1BQU1DLGNBQWMsR0FBRyxZQUF2QjtBQUNBLE1BQU1DLGtCQUFrQixHQUFHLGdCQUEzQjtBQUNBLE1BQU1DLGFBQWEsR0FBRyxXQUF0QixDLENBQ1A7O0FBQ08sTUFBTUMscUJBQXFCLEdBQUcsbUJBQTlCO0FBQ0EsTUFBTUMsYUFBYSxHQUFHLFdBQXRCO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcsdUJBQTFCO0FBQ0EsTUFBTUMsWUFBWSxHQUFHLFVBQXJCO0FBQ0EsTUFBTUMsZUFBZSxHQUFHLFFBQXhCO0FBQ0EsTUFBTUMsbUJBQW1CLEdBQUcsaUJBQTVCO0FBQ0EsTUFBTUMsVUFBVSxHQUFHLFFBQW5CO0FBQ0EsTUFBTUMsU0FBUyxHQUFHLE9BQWxCO0FBQ0EsTUFBTUMsdUJBQXVCLEdBQUcsUUFBaEM7QUFDQSxNQUFNQyxtQkFBbUIsR0FBRyxVQUE1QixDLENBQ1A7O0FBRU8sTUFBTUMsY0FBYyxHQUFHO0FBQzVCelosSUFBRSxFQUFFLFVBRHdCO0FBRTVCaVksZ0JBQWMsRUFBRSxNQUZZO0FBRzVCM2hCLE1BQUksRUFBRThoQjtBQUhzQixDQUF2QjtBQU1BLE1BQU1zQixjQUFjLEdBQUc7QUFDNUIxWixJQUFFLEVBQUUsVUFEd0I7QUFFNUJpWSxnQkFBYyxFQUFFLE1BRlk7QUFHNUIzaEIsTUFBSSxFQUFFZ2pCO0FBSHNCLENBQXZCO0FBS0EsTUFBTUssZUFBZSxHQUFHO0FBQzdCM1osSUFBRSxFQUFFLFdBRHlCO0FBRTdCaVksZ0JBQWMsRUFBRSxPQUZhO0FBRzdCM2hCLE1BQUksRUFBRStpQjtBQUh1QixDQUF4QjtBQUtBLE1BQU1PLGVBQWUsR0FBRztBQUM3QjVaLElBQUUsRUFBRSxXQUR5QjtBQUU3QjFKLE1BQUksRUFBRTZpQixlQUZ1QjtBQUc3QmxCLGdCQUFjLEVBQUU7QUFIYSxDQUF4QjtBQUtBLE1BQU1ELDBCQUEwQixHQUFHO0FBQ3hDaFksSUFBRSxFQUFFLHNCQURvQztBQUV4Q2lZLGdCQUFjLEVBQUUsa0JBRndCO0FBR3hDM2hCLE1BQUksRUFBRXlpQjtBQUhrQyxDQUFuQztBQUtBLE1BQU1jLGlCQUFpQixHQUFHO0FBQy9CN1osSUFBRSxFQUFFLGFBRDJCO0FBRS9CaVksZ0JBQWMsRUFBRSxTQUZlO0FBRy9CM2hCLE1BQUksRUFBRTRpQjtBQUh5QixDQUExQjtBQUtBLE1BQU1ZLHFCQUFxQixHQUFHLENBQ25DRCxpQkFEbUMsRUFFbkM7QUFDRTdaLElBQUUsRUFBRSxjQUROO0FBRUVpWSxnQkFBYyxFQUFFLFVBRmxCO0FBR0UzaEIsTUFBSSxFQUFFMGlCO0FBSFIsQ0FGbUMsRUFPbkM7QUFDRWhaLElBQUUsRUFBRSxxQkFETjtBQUVFMUosTUFBSSxFQUFFMmlCLGlCQUZSO0FBR0VoQixnQkFBYyxFQUFFO0FBSGxCLENBUG1DLEVBWW5DMkIsZUFabUMsRUFhbkM7QUFDRTVaLElBQUUsRUFBRSxvQkFETjtBQUVFMUosTUFBSSxFQUFFOGlCLG1CQUZSO0FBR0VuQixnQkFBYyxFQUFFO0FBSGxCLENBYm1DLEVBa0JuQztBQUNFalksSUFBRSxFQUFFLHdCQUROO0FBRUVpWSxnQkFBYyxFQUFFLG9CQUZsQjtBQUdFM2hCLE1BQUksRUFBRWlqQjtBQUhSLENBbEJtQyxFQXVCbkM7QUFDRXZaLElBQUUsRUFBRSxvQkFETjtBQUVFaVksZ0JBQWMsRUFBRSxnQkFGbEI7QUFHRTNoQixNQUFJLEVBQUVrakI7QUFIUixDQXZCbUMsQ0FBOUIsQyxDQTZCUDs7QUFDTyxNQUFNTyxtQkFBbUIsR0FBRyxDQUNqQztBQUNFL1osSUFBRSxFQUFFLGFBRE47QUFFRTFKLE1BQUksRUFBRStoQixZQUZSO0FBR0VKLGdCQUFjLEVBQUUsU0FIbEI7QUFJRWpELE1BQUksRUFBRSxpQkFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0FEaUMsRUFRakM7QUFDRWhhLElBQUUsRUFBRSxpQkFETjtBQUVFMUosTUFBSSxFQUFFZ2lCLGdCQUZSO0FBR0VMLGdCQUFjLEVBQUUsYUFIbEI7QUFJRWpELE1BQUksRUFBRSxpQkFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0FSaUMsRUFlakM7QUFDRWhhLElBQUUsRUFBRSxZQUROO0FBRUUxSixNQUFJLEVBQUVpaUIsV0FGUjtBQUdFTixnQkFBYyxFQUFFLFFBSGxCO0FBSUVqRCxNQUFJLEVBQUUsUUFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0FmaUMsRUFzQmpDO0FBQ0VoYSxJQUFFLEVBQUUsWUFETjtBQUVFaVksZ0JBQWMsRUFBRSxRQUZsQjtBQUdFM2hCLE1BQUksRUFBRWtpQixXQUhSO0FBSUV4RCxNQUFJLEVBQUUsWUFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0F0QmlDLEVBNkJqQztBQUNFaGEsSUFBRSxFQUFFLFVBRE47QUFFRWlZLGdCQUFjLEVBQUUsTUFGbEI7QUFHRTNoQixNQUFJLEVBQUVvaUIsU0FIUjtBQUlFMUQsTUFBSSxFQUFFLFNBSlI7QUFLRWdGLFNBQU8sRUFBRTtBQUxYLENBN0JpQyxFQW9DakM7QUFDRWhhLElBQUUsRUFBRSxjQUROO0FBRUVpWSxnQkFBYyxFQUFFLFVBRmxCO0FBR0UzaEIsTUFBSSxFQUFFbWlCLGFBSFI7QUFJRXpELE1BQUksRUFBRSxXQUpSO0FBS0VnRixTQUFPLEVBQUU7QUFMWCxDQXBDaUMsRUEyQ2pDO0FBQ0VoYSxJQUFFLEVBQUUsZUFETjtBQUVFaVksZ0JBQWMsRUFBRSxXQUZsQjtBQUdFM2hCLE1BQUksRUFBRXNpQixjQUhSO0FBSUU1RCxNQUFJLEVBQUUsZUFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0EzQ2lDLEVBa0RqQztBQUNFaGEsSUFBRSxFQUFFLG1CQUROO0FBRUVpWSxnQkFBYyxFQUFFLGVBRmxCO0FBR0UzaEIsTUFBSSxFQUFFdWlCLGtCQUhSO0FBSUU3RCxNQUFJLEVBQUUsZUFKUjtBQUtFZ0YsU0FBTyxFQUFFO0FBTFgsQ0FsRGlDLEVBeURqQztBQUNFaGEsSUFBRSxFQUFFLFVBRE47QUFFRWlZLGdCQUFjLEVBQUUsTUFGbEI7QUFHRTNoQixNQUFJLEVBQUVxaUIsU0FIUjtBQUlFM0QsTUFBSSxFQUFFLFVBSlI7QUFLRWdGLFNBQU8sRUFBRTtBQUxYLENBekRpQyxFQWdFakM7QUFDRWhhLElBQUUsRUFBRSxjQUROO0FBRUVpWSxnQkFBYyxFQUFFLFVBRmxCO0FBR0UzaEIsTUFBSSxFQUFFd2lCLGFBSFI7QUFJRTlELE1BQUksRUFBRSxjQUpSO0FBS0VnRixTQUFPLEVBQUU7QUFMWCxDQWhFaUMsQ0F1RWpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTVFaUMsQ0FBNUI7QUErRUEsTUFBTUMsa0JBQWtCLEdBQUcsQ0FDaENSLGNBRGdDLEVBRWhDLEdBQUdLLHFCQUY2QixFQUdoQ0osY0FIZ0MsRUFJaENDLGVBSmdDLENBQTNCO0FBT0EsTUFBTU8sd0JBQXdCLEdBQUcsQ0FBQ04sZUFBRCxFQUFrQkYsY0FBbEIsQ0FBakM7QUFDQSxNQUFNUywyQkFBMkIsR0FBRyxDQUFDTixpQkFBRCxDQUFwQztBQUVBLE1BQU1PLGFBQWEsR0FBRyxDQUMzQjtBQUNFcGEsSUFBRSxFQUFFLElBRE47QUFFRWlZLGdCQUFjLEVBQUUsUUFGbEI7QUFHRWpELE1BQUksRUFBRTtBQUhSLENBRDJCLEVBTTNCO0FBQ0VoVixJQUFFLEVBQUUsSUFETjtBQUVFaVksZ0JBQWMsRUFBRSxTQUZsQjtBQUdFakQsTUFBSSxFQUFFO0FBSFIsQ0FOMkIsRUFXM0I7QUFDRWhWLElBQUUsRUFBRSxJQUROO0FBRUVpWSxnQkFBYyxFQUFFLFNBRmxCO0FBR0VqRCxNQUFJLEVBQUU7QUFIUixDQVgyQixFQWdCM0I7QUFDRWhWLElBQUUsRUFBRSxJQUROO0FBRUVpWSxnQkFBYyxFQUFFLFFBRmxCO0FBR0VqRCxNQUFJLEVBQUU7QUFIUixDQWhCMkIsRUFxQjNCO0FBQ0VoVixJQUFFLEVBQUUsSUFETjtBQUVFaVksZ0JBQWMsRUFBRSxRQUZsQjtBQUdFakQsTUFBSSxFQUFFO0FBSFIsQ0FyQjJCLEVBMEIzQjtBQUNFaFYsSUFBRSxFQUFFLElBRE47QUFFRWlZLGdCQUFjLEVBQUUsU0FGbEI7QUFHRWpELE1BQUksRUFBRTtBQUhSLENBMUIyQixDQUF0QixDOzs7Ozs7Ozs7Ozs7QUM5S1A7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRU8sU0FBU00sV0FBVCxDQUFxQnZhLEtBQXJCLEVBQTRCO0FBQ2pDLFFBQU03QixHQUFHLEdBQUdtaEIsb0RBQU0sRUFBbEI7QUFDQWpGLHlEQUFTLENBQUMsTUFBTSxNQUFNbGMsR0FBRyxDQUFDb2hCLE9BQUosR0FBY3ZmLEtBQXBCLENBQVAsRUFBbUMsQ0FBQ0EsS0FBRCxDQUFuQyxDQUFUO0FBQ0EsU0FBTzdCLEdBQUcsQ0FBQ29oQixPQUFYO0FBQ0Q7QUFFTSxTQUFTN0UsVUFBVCxHQUFzQjtBQUMzQixRQUFNdmMsR0FBRyxHQUFHbWhCLG9EQUFNLEVBQWxCO0FBQ0EsUUFBTTtBQUFBLE9BQUNFLE1BQUQ7QUFBQSxPQUFTL1I7QUFBVCxNQUFnQjhJLHNEQUFRLENBQU07QUFBRXFCLFFBQUksRUFBRSxDQUFSO0FBQVdTLE9BQUcsRUFBRSxDQUFoQjtBQUFtQmhHLFNBQUssRUFBRSxDQUExQjtBQUE2QkMsVUFBTSxFQUFFO0FBQXJDLEdBQU4sQ0FBOUI7QUFDQSxRQUFNO0FBQUEsT0FBQ21OO0FBQUQsTUFBT2xKLHNEQUFRLENBQ25CLE1BQU0sSUFBSW1KLCtEQUFKLENBQW1CLENBQUMsQ0FBQ2xnQixLQUFELENBQUQsS0FBYWlPLEdBQUcsQ0FBQ2pPLEtBQUssQ0FBQ21nQixXQUFQLENBQW5DLENBRGEsQ0FBckI7QUFHQXRGLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlsYyxHQUFHLENBQUNvaEIsT0FBUixFQUFpQkUsRUFBRSxDQUFDL2EsT0FBSCxDQUFXdkcsR0FBRyxDQUFDb2hCLE9BQWY7QUFDakIsV0FBTyxNQUFNRSxFQUFFLENBQUNHLFVBQUgsRUFBYjtBQUNELEdBSFEsRUFHTixFQUhNLENBQVQ7QUFJQSxTQUFPLENBQUM7QUFBRXpoQjtBQUFGLEdBQUQsRUFBVXFoQixNQUFWLENBQVA7QUFDRCxDIiwiZmlsZSI6IjUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ2hpbGRyZW4sIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXJsT2JqZWN0IH0gZnJvbSAndXJsJ1xuaW1wb3J0IHtcbiAgYWRkQmFzZVBhdGgsXG4gIGFkZExvY2FsZSxcbiAgZ2V0RG9tYWluTG9jYWxlLFxuICBpc0xvY2FsVVJMLFxuICBOZXh0Um91dGVyLFxuICBQcmVmZXRjaE9wdGlvbnMsXG4gIHJlc29sdmVIcmVmLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3JvdXRlcidcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJy4vcm91dGVyJ1xuaW1wb3J0IHsgdXNlSW50ZXJzZWN0aW9uIH0gZnJvbSAnLi91c2UtaW50ZXJzZWN0aW9uJ1xuXG50eXBlIFVybCA9IHN0cmluZyB8IFVybE9iamVjdFxudHlwZSBSZXF1aXJlZEtleXM8VD4gPSB7XG4gIFtLIGluIGtleW9mIFRdLT86IHt9IGV4dGVuZHMgUGljazxULCBLPiA/IG5ldmVyIDogS1xufVtrZXlvZiBUXVxudHlwZSBPcHRpb25hbEtleXM8VD4gPSB7XG4gIFtLIGluIGtleW9mIFRdLT86IHt9IGV4dGVuZHMgUGljazxULCBLPiA/IEsgOiBuZXZlclxufVtrZXlvZiBUXVxuXG5leHBvcnQgdHlwZSBMaW5rUHJvcHMgPSB7XG4gIGhyZWY6IFVybFxuICBhcz86IFVybFxuICByZXBsYWNlPzogYm9vbGVhblxuICBzY3JvbGw/OiBib29sZWFuXG4gIHNoYWxsb3c/OiBib29sZWFuXG4gIHBhc3NIcmVmPzogYm9vbGVhblxuICBwcmVmZXRjaD86IGJvb2xlYW5cbiAgbG9jYWxlPzogc3RyaW5nIHwgZmFsc2Vcbn1cbnR5cGUgTGlua1Byb3BzUmVxdWlyZWQgPSBSZXF1aXJlZEtleXM8TGlua1Byb3BzPlxudHlwZSBMaW5rUHJvcHNPcHRpb25hbCA9IE9wdGlvbmFsS2V5czxMaW5rUHJvcHM+XG5cbmNvbnN0IHByZWZldGNoZWQ6IHsgW2NhY2hlS2V5OiBzdHJpbmddOiBib29sZWFuIH0gPSB7fVxuXG5mdW5jdGlvbiBwcmVmZXRjaChcbiAgcm91dGVyOiBOZXh0Um91dGVyLFxuICBocmVmOiBzdHJpbmcsXG4gIGFzOiBzdHJpbmcsXG4gIG9wdGlvbnM/OiBQcmVmZXRjaE9wdGlvbnNcbik6IHZvaWQge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgfHwgIXJvdXRlcikgcmV0dXJuXG4gIGlmICghaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuXG4gIC8vIFByZWZldGNoIHRoZSBKU09OIHBhZ2UgaWYgYXNrZWQgKG9ubHkgaW4gdGhlIGNsaWVudClcbiAgLy8gV2UgbmVlZCB0byBoYW5kbGUgYSBwcmVmZXRjaCBlcnJvciBoZXJlIHNpbmNlIHdlIG1heSBiZVxuICAvLyBsb2FkaW5nIHdpdGggcHJpb3JpdHkgd2hpY2ggY2FuIHJlamVjdCBidXQgd2UgZG9uJ3RcbiAgLy8gd2FudCB0byBmb3JjZSBuYXZpZ2F0aW9uIHNpbmNlIHRoaXMgaXMgb25seSBhIHByZWZldGNoXG4gIHJvdXRlci5wcmVmZXRjaChocmVmLCBhcywgb3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAvLyByZXRocm93IHRvIHNob3cgaW52YWxpZCBVUkwgZXJyb3JzXG4gICAgICB0aHJvdyBlcnJcbiAgICB9XG4gIH0pXG4gIGNvbnN0IGN1ckxvY2FsZSA9XG4gICAgb3B0aW9ucyAmJiB0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgIT09ICd1bmRlZmluZWQnXG4gICAgICA/IG9wdGlvbnMubG9jYWxlXG4gICAgICA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlXG5cbiAgLy8gSm9pbiBvbiBhbiBpbnZhbGlkIFVSSSBjaGFyYWN0ZXJcbiAgcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXSA9IHRydWVcbn1cblxuZnVuY3Rpb24gaXNNb2RpZmllZEV2ZW50KGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHsgdGFyZ2V0IH0gPSBldmVudC5jdXJyZW50VGFyZ2V0IGFzIEhUTUxBbmNob3JFbGVtZW50XG4gIHJldHVybiAoXG4gICAgKHRhcmdldCAmJiB0YXJnZXQgIT09ICdfc2VsZicpIHx8XG4gICAgZXZlbnQubWV0YUtleSB8fFxuICAgIGV2ZW50LmN0cmxLZXkgfHxcbiAgICBldmVudC5zaGlmdEtleSB8fFxuICAgIGV2ZW50LmFsdEtleSB8fCAvLyB0cmlnZ2VycyByZXNvdXJjZSBkb3dubG9hZFxuICAgIChldmVudC5uYXRpdmVFdmVudCAmJiBldmVudC5uYXRpdmVFdmVudC53aGljaCA9PT0gMilcbiAgKVxufVxuXG5mdW5jdGlvbiBsaW5rQ2xpY2tlZChcbiAgZTogUmVhY3QuTW91c2VFdmVudCxcbiAgcm91dGVyOiBOZXh0Um91dGVyLFxuICBocmVmOiBzdHJpbmcsXG4gIGFzOiBzdHJpbmcsXG4gIHJlcGxhY2U/OiBib29sZWFuLFxuICBzaGFsbG93PzogYm9vbGVhbixcbiAgc2Nyb2xsPzogYm9vbGVhbixcbiAgbG9jYWxlPzogc3RyaW5nIHwgZmFsc2Vcbik6IHZvaWQge1xuICBjb25zdCB7IG5vZGVOYW1lIH0gPSBlLmN1cnJlbnRUYXJnZXRcblxuICBpZiAobm9kZU5hbWUgPT09ICdBJyAmJiAoaXNNb2RpZmllZEV2ZW50KGUpIHx8ICFpc0xvY2FsVVJMKGhyZWYpKSkge1xuICAgIC8vIGlnbm9yZSBjbGljayBmb3IgYnJvd3NlcuKAmXMgZGVmYXVsdCBiZWhhdmlvclxuICAgIHJldHVyblxuICB9XG5cbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgLy8gIGF2b2lkIHNjcm9sbCBmb3IgdXJscyB3aXRoIGFuY2hvciByZWZzXG4gIGlmIChzY3JvbGwgPT0gbnVsbCkge1xuICAgIHNjcm9sbCA9IGFzLmluZGV4T2YoJyMnKSA8IDBcbiAgfVxuXG4gIC8vIHJlcGxhY2Ugc3RhdGUgaW5zdGVhZCBvZiBwdXNoIGlmIHByb3AgaXMgcHJlc2VudFxuICByb3V0ZXJbcmVwbGFjZSA/ICdyZXBsYWNlJyA6ICdwdXNoJ10oaHJlZiwgYXMsIHtcbiAgICBzaGFsbG93LFxuICAgIGxvY2FsZSxcbiAgICBzY3JvbGwsXG4gIH0pXG59XG5cbmZ1bmN0aW9uIExpbmsocHJvcHM6IFJlYWN0LlByb3BzV2l0aENoaWxkcmVuPExpbmtQcm9wcz4pIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBmdW5jdGlvbiBjcmVhdGVQcm9wRXJyb3IoYXJnczoge1xuICAgICAga2V5OiBzdHJpbmdcbiAgICAgIGV4cGVjdGVkOiBzdHJpbmdcbiAgICAgIGFjdHVhbDogc3RyaW5nXG4gICAgfSkge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcihcbiAgICAgICAgYEZhaWxlZCBwcm9wIHR5cGU6IFRoZSBwcm9wIFxcYCR7YXJncy5rZXl9XFxgIGV4cGVjdHMgYSAke2FyZ3MuZXhwZWN0ZWR9IGluIFxcYDxMaW5rPlxcYCwgYnV0IGdvdCBcXGAke2FyZ3MuYWN0dWFsfVxcYCBpbnN0ZWFkLmAgK1xuICAgICAgICAgICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICAgICAgICAgPyBcIlxcbk9wZW4geW91ciBicm93c2VyJ3MgY29uc29sZSB0byB2aWV3IHRoZSBDb21wb25lbnQgc3RhY2sgdHJhY2UuXCJcbiAgICAgICAgICAgIDogJycpXG4gICAgICApXG4gICAgfVxuXG4gICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICBjb25zdCByZXF1aXJlZFByb3BzR3VhcmQ6IFJlY29yZDxMaW5rUHJvcHNSZXF1aXJlZCwgdHJ1ZT4gPSB7XG4gICAgICBocmVmOiB0cnVlLFxuICAgIH0gYXMgY29uc3RcbiAgICBjb25zdCByZXF1aXJlZFByb3BzOiBMaW5rUHJvcHNSZXF1aXJlZFtdID0gT2JqZWN0LmtleXMoXG4gICAgICByZXF1aXJlZFByb3BzR3VhcmRcbiAgICApIGFzIExpbmtQcm9wc1JlcXVpcmVkW11cbiAgICByZXF1aXJlZFByb3BzLmZvckVhY2goKGtleTogTGlua1Byb3BzUmVxdWlyZWQpID0+IHtcbiAgICAgIGlmIChrZXkgPT09ICdocmVmJykge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgcHJvcHNba2V5XSA9PSBudWxsIHx8XG4gICAgICAgICAgKHR5cGVvZiBwcm9wc1trZXldICE9PSAnc3RyaW5nJyAmJiB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ29iamVjdCcpXG4gICAgICAgICkge1xuICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgIG9yIGBvYmplY3RgJyxcbiAgICAgICAgICAgIGFjdHVhbDogcHJvcHNba2V5XSA9PT0gbnVsbCA/ICdudWxsJyA6IHR5cGVvZiBwcm9wc1trZXldLFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgY29uc3QgXzogbmV2ZXIgPSBrZXlcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICBjb25zdCBvcHRpb25hbFByb3BzR3VhcmQ6IFJlY29yZDxMaW5rUHJvcHNPcHRpb25hbCwgdHJ1ZT4gPSB7XG4gICAgICBhczogdHJ1ZSxcbiAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICBzY3JvbGw6IHRydWUsXG4gICAgICBzaGFsbG93OiB0cnVlLFxuICAgICAgcGFzc0hyZWY6IHRydWUsXG4gICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgIGxvY2FsZTogdHJ1ZSxcbiAgICB9IGFzIGNvbnN0XG4gICAgY29uc3Qgb3B0aW9uYWxQcm9wczogTGlua1Byb3BzT3B0aW9uYWxbXSA9IE9iamVjdC5rZXlzKFxuICAgICAgb3B0aW9uYWxQcm9wc0d1YXJkXG4gICAgKSBhcyBMaW5rUHJvcHNPcHRpb25hbFtdXG4gICAgb3B0aW9uYWxQcm9wcy5mb3JFYWNoKChrZXk6IExpbmtQcm9wc09wdGlvbmFsKSA9PiB7XG4gICAgICBjb25zdCB2YWxUeXBlID0gdHlwZW9mIHByb3BzW2tleV1cblxuICAgICAgaWYgKGtleSA9PT0gJ2FzJykge1xuICAgICAgICBpZiAocHJvcHNba2V5XSAmJiB2YWxUeXBlICE9PSAnc3RyaW5nJyAmJiB2YWxUeXBlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgIG9yIGBvYmplY3RgJyxcbiAgICAgICAgICAgIGFjdHVhbDogdmFsVHlwZSxcbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGtleSA9PT0gJ2xvY2FsZScpIHtcbiAgICAgICAgaWYgKHByb3BzW2tleV0gJiYgdmFsVHlwZSAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgc3RyaW5nYCcsXG4gICAgICAgICAgICBhY3R1YWw6IHZhbFR5cGUsXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAga2V5ID09PSAncmVwbGFjZScgfHxcbiAgICAgICAga2V5ID09PSAnc2Nyb2xsJyB8fFxuICAgICAgICBrZXkgPT09ICdzaGFsbG93JyB8fFxuICAgICAgICBrZXkgPT09ICdwYXNzSHJlZicgfHxcbiAgICAgICAga2V5ID09PSAncHJlZmV0Y2gnXG4gICAgICApIHtcbiAgICAgICAgaWYgKHByb3BzW2tleV0gIT0gbnVsbCAmJiB2YWxUeXBlICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgYm9vbGVhbmAnLFxuICAgICAgICAgICAgYWN0dWFsOiB2YWxUeXBlLFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgY29uc3QgXzogbmV2ZXIgPSBrZXlcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gVGhpcyBob29rIGlzIGluIGEgY29uZGl0aW9uYWwgYnV0IHRoYXQgaXMgb2sgYmVjYXVzZSBgcHJvY2Vzcy5lbnYuTk9ERV9FTlZgIG5ldmVyIGNoYW5nZXNcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcbiAgICBjb25zdCBoYXNXYXJuZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpXG4gICAgaWYgKHByb3BzLnByZWZldGNoICYmICFoYXNXYXJuZWQuY3VycmVudCkge1xuICAgICAgaGFzV2FybmVkLmN1cnJlbnQgPSB0cnVlXG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICdOZXh0LmpzIGF1dG8tcHJlZmV0Y2hlcyBhdXRvbWF0aWNhbGx5IGJhc2VkIG9uIHZpZXdwb3J0LiBUaGUgcHJlZmV0Y2ggYXR0cmlidXRlIGlzIG5vIGxvbmdlciBuZWVkZWQuIE1vcmU6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL3ByZWZldGNoLXRydWUtZGVwcmVjYXRlZCdcbiAgICAgIClcbiAgICB9XG4gIH1cbiAgY29uc3QgcCA9IHByb3BzLnByZWZldGNoICE9PSBmYWxzZVxuXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHBhdGhuYW1lID0gKHJvdXRlciAmJiByb3V0ZXIucGF0aG5hbWUpIHx8ICcvJ1xuXG4gIGNvbnN0IHsgaHJlZiwgYXMgfSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gcmVzb2x2ZUhyZWYocGF0aG5hbWUsIHByb3BzLmhyZWYsIHRydWUpXG4gICAgcmV0dXJuIHtcbiAgICAgIGhyZWY6IHJlc29sdmVkSHJlZixcbiAgICAgIGFzOiBwcm9wcy5hc1xuICAgICAgICA/IHJlc29sdmVIcmVmKHBhdGhuYW1lLCBwcm9wcy5hcylcbiAgICAgICAgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZixcbiAgICB9XG4gIH0sIFtwYXRobmFtZSwgcHJvcHMuaHJlZiwgcHJvcHMuYXNdKVxuXG4gIGxldCB7IGNoaWxkcmVuLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSB9ID0gcHJvcHNcblxuICAvLyBEZXByZWNhdGVkLiBXYXJuaW5nIHNob3duIGJ5IHByb3BUeXBlIGNoZWNrLiBJZiB0aGUgY2hpbGRyZW4gcHJvdmlkZWQgaXMgYSBzdHJpbmcgKDxMaW5rPmV4YW1wbGU8L0xpbms+KSB3ZSB3cmFwIGl0IGluIGFuIDxhPiB0YWdcbiAgaWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gJ3N0cmluZycpIHtcbiAgICBjaGlsZHJlbiA9IDxhPntjaGlsZHJlbn08L2E+XG4gIH1cblxuICAvLyBUaGlzIHdpbGwgcmV0dXJuIHRoZSBmaXJzdCBjaGlsZCwgaWYgbXVsdGlwbGUgYXJlIHByb3ZpZGVkIGl0IHdpbGwgdGhyb3cgYW4gZXJyb3JcbiAgY29uc3QgY2hpbGQ6IGFueSA9IENoaWxkcmVuLm9ubHkoY2hpbGRyZW4pXG4gIGNvbnN0IGNoaWxkUmVmOiBhbnkgPSBjaGlsZCAmJiB0eXBlb2YgY2hpbGQgPT09ICdvYmplY3QnICYmIGNoaWxkLnJlZlxuXG4gIGNvbnN0IFtzZXRJbnRlcnNlY3Rpb25SZWYsIGlzVmlzaWJsZV0gPSB1c2VJbnRlcnNlY3Rpb24oe1xuICAgIHJvb3RNYXJnaW46ICcyMDBweCcsXG4gIH0pXG4gIGNvbnN0IHNldFJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgIChlbDogRWxlbWVudCkgPT4ge1xuICAgICAgc2V0SW50ZXJzZWN0aW9uUmVmKGVsKVxuICAgICAgaWYgKGNoaWxkUmVmKSB7XG4gICAgICAgIGlmICh0eXBlb2YgY2hpbGRSZWYgPT09ICdmdW5jdGlvbicpIGNoaWxkUmVmKGVsKVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgY2hpbGRSZWYgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgY2hpbGRSZWYuY3VycmVudCA9IGVsXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIFtjaGlsZFJlZiwgc2V0SW50ZXJzZWN0aW9uUmVmXVxuICApXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc2hvdWxkUHJlZmV0Y2ggPSBpc1Zpc2libGUgJiYgcCAmJiBpc0xvY2FsVVJMKGhyZWYpXG4gICAgY29uc3QgY3VyTG9jYWxlID1cbiAgICAgIHR5cGVvZiBsb2NhbGUgIT09ICd1bmRlZmluZWQnID8gbG9jYWxlIDogcm91dGVyICYmIHJvdXRlci5sb2NhbGVcbiAgICBjb25zdCBpc1ByZWZldGNoZWQgPVxuICAgICAgcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXVxuICAgIGlmIChzaG91bGRQcmVmZXRjaCAmJiAhaXNQcmVmZXRjaGVkKSB7XG4gICAgICBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzLCB7XG4gICAgICAgIGxvY2FsZTogY3VyTG9jYWxlLFxuICAgICAgfSlcbiAgICB9XG4gIH0sIFthcywgaHJlZiwgaXNWaXNpYmxlLCBsb2NhbGUsIHAsIHJvdXRlcl0pXG5cbiAgY29uc3QgY2hpbGRQcm9wczoge1xuICAgIG9uTW91c2VFbnRlcj86IFJlYWN0Lk1vdXNlRXZlbnRIYW5kbGVyXG4gICAgb25DbGljazogUmVhY3QuTW91c2VFdmVudEhhbmRsZXJcbiAgICBocmVmPzogc3RyaW5nXG4gICAgcmVmPzogYW55XG4gIH0gPSB7XG4gICAgcmVmOiBzZXRSZWYsXG4gICAgb25DbGljazogKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25DbGljayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjaGlsZC5wcm9wcy5vbkNsaWNrKGUpXG4gICAgICB9XG4gICAgICBpZiAoIWUuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSlcbiAgICAgIH1cbiAgICB9LFxuICB9XG5cbiAgY2hpbGRQcm9wcy5vbk1vdXNlRW50ZXIgPSAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgIGlmICghaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuXG4gICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNoaWxkLnByb3BzLm9uTW91c2VFbnRlcihlKVxuICAgIH1cbiAgICBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzLCB7IHByaW9yaXR5OiB0cnVlIH0pXG4gIH1cblxuICAvLyBJZiBjaGlsZCBpcyBhbiA8YT4gdGFnIGFuZCBkb2Vzbid0IGhhdmUgYSBocmVmIGF0dHJpYnV0ZSwgb3IgaWYgdGhlICdwYXNzSHJlZicgcHJvcGVydHkgaXNcbiAgLy8gZGVmaW5lZCwgd2Ugc3BlY2lmeSB0aGUgY3VycmVudCAnaHJlZicsIHNvIHRoYXQgcmVwZXRpdGlvbiBpcyBub3QgbmVlZGVkIGJ5IHRoZSB1c2VyXG4gIGlmIChwcm9wcy5wYXNzSHJlZiB8fCAoY2hpbGQudHlwZSA9PT0gJ2EnICYmICEoJ2hyZWYnIGluIGNoaWxkLnByb3BzKSkpIHtcbiAgICBjb25zdCBjdXJMb2NhbGUgPVxuICAgICAgdHlwZW9mIGxvY2FsZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZVxuXG4gICAgLy8gd2Ugb25seSByZW5kZXIgZG9tYWluIGxvY2FsZXMgaWYgd2UgYXJlIGN1cnJlbnRseSBvbiBhIGRvbWFpbiBsb2NhbGVcbiAgICAvLyBzbyB0aGF0IGxvY2FsZSBsaW5rcyBhcmUgc3RpbGwgdmlzaXRhYmxlIGluIGRldmVsb3BtZW50L3ByZXZpZXcgZW52c1xuICAgIGNvbnN0IGxvY2FsZURvbWFpbiA9XG4gICAgICByb3V0ZXIgJiZcbiAgICAgIHJvdXRlci5pc0xvY2FsZURvbWFpbiAmJlxuICAgICAgZ2V0RG9tYWluTG9jYWxlKFxuICAgICAgICBhcyxcbiAgICAgICAgY3VyTG9jYWxlLFxuICAgICAgICByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZXMsXG4gICAgICAgIHJvdXRlciAmJiByb3V0ZXIuZG9tYWluTG9jYWxlc1xuICAgICAgKVxuXG4gICAgY2hpbGRQcm9wcy5ocmVmID1cbiAgICAgIGxvY2FsZURvbWFpbiB8fFxuICAgICAgYWRkQmFzZVBhdGgoYWRkTG9jYWxlKGFzLCBjdXJMb2NhbGUsIHJvdXRlciAmJiByb3V0ZXIuZGVmYXVsdExvY2FsZSkpXG4gIH1cblxuICByZXR1cm4gUmVhY3QuY2xvbmVFbGVtZW50KGNoaWxkLCBjaGlsZFByb3BzKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMaW5rXG4iLCIvKipcbiAqIFJlbW92ZXMgdGhlIHRyYWlsaW5nIHNsYXNoIG9mIGEgcGF0aCBpZiB0aGVyZSBpcyBvbmUuIFByZXNlcnZlcyB0aGUgcm9vdCBwYXRoIGAvYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBwYXRoLmVuZHNXaXRoKCcvJykgJiYgcGF0aCAhPT0gJy8nID8gcGF0aC5zbGljZSgwLCAtMSkgOiBwYXRoXG59XG5cbi8qKlxuICogTm9ybWFsaXplcyB0aGUgdHJhaWxpbmcgc2xhc2ggb2YgYSBwYXRoIGFjY29yZGluZyB0byB0aGUgYHRyYWlsaW5nU2xhc2hgIG9wdGlvblxuICogaW4gYG5leHQuY29uZmlnLmpzYC5cbiAqL1xuZXhwb3J0IGNvbnN0IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1RSQUlMSU5HX1NMQVNIXG4gID8gKHBhdGg6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gICAgICBpZiAoL1xcLlteL10rXFwvPyQvLnRlc3QocGF0aCkpIHtcbiAgICAgICAgcmV0dXJuIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpXG4gICAgICB9IGVsc2UgaWYgKHBhdGguZW5kc1dpdGgoJy8nKSkge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHBhdGggKyAnLydcbiAgICAgIH1cbiAgICB9XG4gIDogcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2hcbiIsInR5cGUgUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSA9IGFueVxudHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrT3B0aW9ucyA9IHtcbiAgdGltZW91dDogbnVtYmVyXG59XG50eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSA9IHtcbiAgcmVhZG9ubHkgZGlkVGltZW91dDogYm9vbGVhblxuICB0aW1lUmVtYWluaW5nOiAoKSA9PiBudW1iZXJcbn1cblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICByZXF1ZXN0SWRsZUNhbGxiYWNrOiAoXG4gICAgICBjYWxsYmFjazogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWQsXG4gICAgICBvcHRzPzogUmVxdWVzdElkbGVDYWxsYmFja09wdGlvbnNcbiAgICApID0+IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGVcbiAgICBjYW5jZWxJZGxlQ2FsbGJhY2s6IChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkgPT4gdm9pZFxuICB9XG59XG5cbmV4cG9ydCBjb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrID1cbiAgKHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChcbiAgICBjYjogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWRcbiAgKTogTm9kZUpTLlRpbWVvdXQge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KClcbiAgICByZXR1cm4gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICBjYih7XG4gICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICB0aW1lUmVtYWluaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0sIDEpXG4gIH1cblxuZXhwb3J0IGNvbnN0IGNhbmNlbElkbGVDYWxsYmFjayA9XG4gICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpXG4gIH1cbiIsImltcG9ydCB7IENvbXBvbmVudFR5cGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENsaWVudEJ1aWxkTWFuaWZlc3QgfSBmcm9tICcuLi9idWlsZC93ZWJwYWNrL3BsdWdpbnMvYnVpbGQtbWFuaWZlc3QtcGx1Z2luJ1xuaW1wb3J0IGdldEFzc2V0UGF0aEZyb21Sb3V0ZSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGUnXG5pbXBvcnQgeyByZXF1ZXN0SWRsZUNhbGxiYWNrIH0gZnJvbSAnLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2snXG5cbi8vIDMuOHMgd2FzIGFyYml0cmFyaWx5IGNob3NlbiBhcyBpdCdzIHdoYXQgaHR0cHM6Ly93ZWIuZGV2L2ludGVyYWN0aXZlXG4vLyBjb25zaWRlcnMgYXMgXCJHb29kXCIgdGltZS10by1pbnRlcmFjdGl2ZS4gV2UgbXVzdCBhc3N1bWUgc29tZXRoaW5nIHdlbnRcbi8vIHdyb25nIGJleW9uZCB0aGlzIHBvaW50LCBhbmQgdGhlbiBmYWxsLWJhY2sgdG8gYSBmdWxsIHBhZ2UgdHJhbnNpdGlvbiB0b1xuLy8gc2hvdyB0aGUgdXNlciBzb21ldGhpbmcgb2YgdmFsdWUuXG5jb25zdCBNU19NQVhfSURMRV9ERUxBWSA9IDM4MDBcblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICBfX0JVSUxEX01BTklGRVNUPzogQ2xpZW50QnVpbGRNYW5pZmVzdFxuICAgIF9fQlVJTERfTUFOSUZFU1RfQ0I/OiBGdW5jdGlvblxuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9hZGVkRW50cnlwb2ludFN1Y2Nlc3Mge1xuICBjb21wb25lbnQ6IENvbXBvbmVudFR5cGVcbiAgZXhwb3J0czogYW55XG59XG5leHBvcnQgaW50ZXJmYWNlIExvYWRlZEVudHJ5cG9pbnRGYWlsdXJlIHtcbiAgZXJyb3I6IHVua25vd25cbn1cbmV4cG9ydCB0eXBlIFJvdXRlRW50cnlwb2ludCA9IExvYWRlZEVudHJ5cG9pbnRTdWNjZXNzIHwgTG9hZGVkRW50cnlwb2ludEZhaWx1cmVcblxuZXhwb3J0IGludGVyZmFjZSBSb3V0ZVN0eWxlU2hlZXQge1xuICBocmVmOiBzdHJpbmdcbiAgY29udGVudDogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9hZGVkUm91dGVTdWNjZXNzIGV4dGVuZHMgTG9hZGVkRW50cnlwb2ludFN1Y2Nlc3Mge1xuICBzdHlsZXM6IFJvdXRlU3R5bGVTaGVldFtdXG59XG5leHBvcnQgaW50ZXJmYWNlIExvYWRlZFJvdXRlRmFpbHVyZSB7XG4gIGVycm9yOiB1bmtub3duXG59XG5leHBvcnQgdHlwZSBSb3V0ZUxvYWRlckVudHJ5ID0gTG9hZGVkUm91dGVTdWNjZXNzIHwgTG9hZGVkUm91dGVGYWlsdXJlXG5cbmV4cG9ydCB0eXBlIEZ1dHVyZTxWPiA9IHtcbiAgcmVzb2x2ZTogKGVudHJ5cG9pbnQ6IFYpID0+IHZvaWRcbiAgZnV0dXJlOiBQcm9taXNlPFY+XG59XG5mdW5jdGlvbiB3aXRoRnV0dXJlPFQ+KFxuICBrZXk6IHN0cmluZyxcbiAgbWFwOiBNYXA8c3RyaW5nLCBGdXR1cmU8VD4gfCBUPixcbiAgZ2VuZXJhdG9yPzogKCkgPT4gUHJvbWlzZTxUPlxuKTogUHJvbWlzZTxUPiB7XG4gIGxldCBlbnRyeTogRnV0dXJlPFQ+IHwgVCB8IHVuZGVmaW5lZCA9IG1hcC5nZXQoa2V5KVxuICBpZiAoZW50cnkpIHtcbiAgICBpZiAoJ2Z1dHVyZScgaW4gZW50cnkpIHtcbiAgICAgIHJldHVybiBlbnRyeS5mdXR1cmVcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShlbnRyeSlcbiAgfVxuICBsZXQgcmVzb2x2ZXI6IChlbnRyeXBvaW50OiBUKSA9PiB2b2lkXG4gIGNvbnN0IHByb206IFByb21pc2U8VD4gPSBuZXcgUHJvbWlzZTxUPigocmVzb2x2ZSkgPT4ge1xuICAgIHJlc29sdmVyID0gcmVzb2x2ZVxuICB9KVxuICBtYXAuc2V0KGtleSwgKGVudHJ5ID0geyByZXNvbHZlOiByZXNvbHZlciEsIGZ1dHVyZTogcHJvbSB9KSlcbiAgcmV0dXJuIGdlbmVyYXRvclxuICAgID8gLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlcXVlbmNlc1xuICAgICAgZ2VuZXJhdG9yKCkudGhlbigodmFsdWUpID0+IChyZXNvbHZlcih2YWx1ZSksIHZhbHVlKSlcbiAgICA6IHByb21cbn1cblxuZXhwb3J0IGludGVyZmFjZSBSb3V0ZUxvYWRlciB7XG4gIHdoZW5FbnRyeXBvaW50KHJvdXRlOiBzdHJpbmcpOiBQcm9taXNlPFJvdXRlRW50cnlwb2ludD5cbiAgb25FbnRyeXBvaW50KHJvdXRlOiBzdHJpbmcsIGV4ZWN1dGU6ICgpID0+IHVua25vd24pOiB2b2lkXG4gIGxvYWRSb3V0ZShyb3V0ZTogc3RyaW5nKTogUHJvbWlzZTxSb3V0ZUxvYWRlckVudHJ5PlxuICBwcmVmZXRjaChyb3V0ZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPlxufVxuXG5mdW5jdGlvbiBoYXNQcmVmZXRjaChsaW5rPzogSFRNTExpbmtFbGVtZW50KTogYm9vbGVhbiB7XG4gIHRyeSB7XG4gICAgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKVxuICAgIHJldHVybiAoXG4gICAgICAvLyBkZXRlY3QgSUUxMSBzaW5jZSBpdCBzdXBwb3J0cyBwcmVmZXRjaCBidXQgaXNuJ3QgZGV0ZWN0ZWRcbiAgICAgIC8vIHdpdGggcmVsTGlzdC5zdXBwb3J0XG4gICAgICAoISF3aW5kb3cuTVNJbnB1dE1ldGhvZENvbnRleHQgJiYgISEoZG9jdW1lbnQgYXMgYW55KS5kb2N1bWVudE1vZGUpIHx8XG4gICAgICBsaW5rLnJlbExpc3Quc3VwcG9ydHMoJ3ByZWZldGNoJylcbiAgICApXG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG59XG5cbmNvbnN0IGNhblByZWZldGNoOiBib29sZWFuID0gaGFzUHJlZmV0Y2goKVxuXG5mdW5jdGlvbiBwcmVmZXRjaFZpYURvbShcbiAgaHJlZjogc3RyaW5nLFxuICBhczogc3RyaW5nLFxuICBsaW5rPzogSFRNTExpbmtFbGVtZW50XG4pOiBQcm9taXNlPGFueT4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XG4gICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYGxpbmtbcmVsPVwicHJlZmV0Y2hcIl1baHJlZl49XCIke2hyZWZ9XCJdYCkpIHtcbiAgICAgIHJldHVybiByZXMoKVxuICAgIH1cblxuICAgIGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJylcblxuICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWw6XG4gICAgaWYgKGFzKSBsaW5rIS5hcyA9IGFzXG4gICAgbGluayEucmVsID0gYHByZWZldGNoYFxuICAgIGxpbmshLmNyb3NzT3JpZ2luID0gcHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTiFcbiAgICBsaW5rIS5vbmxvYWQgPSByZXNcbiAgICBsaW5rIS5vbmVycm9yID0gcmVqXG5cbiAgICAvLyBgaHJlZmAgc2hvdWxkIGFsd2F5cyBiZSBsYXN0OlxuICAgIGxpbmshLmhyZWYgPSBocmVmXG5cbiAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspXG4gIH0pXG59XG5cbmNvbnN0IEFTU0VUX0xPQURfRVJST1IgPSBTeW1ib2woJ0FTU0VUX0xPQURfRVJST1InKVxuLy8gVE9ETzogdW5leHBvcnRcbmV4cG9ydCBmdW5jdGlvbiBtYXJrQXNzZXRFcnJvcihlcnI6IEVycm9yKTogRXJyb3Ige1xuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGVyciwgQVNTRVRfTE9BRF9FUlJPUiwge30pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0Fzc2V0RXJyb3IoZXJyPzogRXJyb3IpOiBib29sZWFuIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIGVyciAmJiBBU1NFVF9MT0FEX0VSUk9SIGluIGVyclxufVxuXG5mdW5jdGlvbiBhcHBlbmRTY3JpcHQoXG4gIHNyYzogc3RyaW5nLFxuICBzY3JpcHQ/OiBIVE1MU2NyaXB0RWxlbWVudFxuKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0JylcblxuICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWwuXG4gICAgLy8gMS4gU2V0dXAgc3VjY2Vzcy9mYWlsdXJlIGhvb2tzIGluIGNhc2UgdGhlIGJyb3dzZXIgc3luY2hyb25vdXNseVxuICAgIC8vICAgIGV4ZWN1dGVzIHdoZW4gYHNyY2AgaXMgc2V0LlxuICAgIHNjcmlwdC5vbmxvYWQgPSByZXNvbHZlXG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PlxuICAgICAgcmVqZWN0KG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc2NyaXB0OiAke3NyY31gKSkpXG5cbiAgICAvLyAyLiBDb25maWd1cmUgdGhlIGNyb3NzLW9yaWdpbiBhdHRyaWJ1dGUgYmVmb3JlIHNldHRpbmcgYHNyY2AgaW4gY2FzZSB0aGVcbiAgICAvLyAgICBicm93c2VyIGJlZ2lucyB0byBmZXRjaC5cbiAgICBzY3JpcHQuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOIVxuXG4gICAgLy8gMy4gRmluYWxseSwgc2V0IHRoZSBzb3VyY2UgYW5kIGluamVjdCBpbnRvIHRoZSBET00gaW4gY2FzZSB0aGUgY2hpbGRcbiAgICAvLyAgICBtdXN0IGJlIGFwcGVuZGVkIGZvciBmZXRjaGluZyB0byBzdGFydC5cbiAgICBzY3JpcHQuc3JjID0gc3JjXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpXG4gIH0pXG59XG5cbi8vIFJlc29sdmUgYSBwcm9taXNlIHRoYXQgdGltZXMgb3V0IGFmdGVyIGdpdmVuIGFtb3VudCBvZiBtaWxsaXNlY29uZHMuXG5mdW5jdGlvbiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0PFQ+KFxuICBwOiBQcm9taXNlPFQ+LFxuICBtczogbnVtYmVyLFxuICBlcnI6IEVycm9yXG4pOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcblxuICAgIHAudGhlbigocikgPT4ge1xuICAgICAgLy8gUmVzb2x2ZWQsIGNhbmNlbCB0aGUgdGltZW91dFxuICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgcmVzb2x2ZShyKVxuICAgIH0pLmNhdGNoKHJlamVjdClcblxuICAgIHJlcXVlc3RJZGxlQ2FsbGJhY2soKCkgPT5cbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgIHJlamVjdChlcnIpXG4gICAgICAgIH1cbiAgICAgIH0sIG1zKVxuICAgIClcbiAgfSlcbn1cblxuLy8gVE9ETzogc3RvcCBleHBvcnRpbmcgb3IgY2FjaGUgdGhlIGZhaWx1cmVcbi8vIEl0J2QgYmUgYmVzdCB0byBzdG9wIGV4cG9ydGluZyB0aGlzLiBJdCdzIGFuIGltcGxlbWVudGF0aW9uIGRldGFpbC4gV2UncmVcbi8vIG9ubHkgZXhwb3J0aW5nIGl0IGZvciBiYWNrd2FyZHMgY29tcGF0aWJpbHR5IHdpdGggdGhlIGBwYWdlLWxvYWRlcmAuXG4vLyBPbmx5IGNhY2hlIHRoaXMgcmVzcG9uc2UgYXMgYSBsYXN0IHJlc29ydCBpZiB3ZSBjYW5ub3QgZWxpbWluYXRlIGFsbCBvdGhlclxuLy8gY29kZSBicmFuY2hlcyB0aGF0IHVzZSB0aGUgQnVpbGQgTWFuaWZlc3QgQ2FsbGJhY2sgYW5kIHB1c2ggdGhlbSB0aHJvdWdoXG4vLyB0aGUgUm91dGUgTG9hZGVyIGludGVyZmFjZS5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCk6IFByb21pc2U8Q2xpZW50QnVpbGRNYW5pZmVzdD4ge1xuICBpZiAoc2VsZi5fX0JVSUxEX01BTklGRVNUKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpXG4gIH1cblxuICBjb25zdCBvbkJ1aWxkTWFuaWZlc3Q6IFByb21pc2U8Q2xpZW50QnVpbGRNYW5pZmVzdD4gPSBuZXcgUHJvbWlzZTxcbiAgICBDbGllbnRCdWlsZE1hbmlmZXN0XG4gID4oKHJlc29sdmUpID0+IHtcbiAgICAvLyBNYW5kYXRvcnkgYmVjYXVzZSB0aGlzIGlzIG5vdCBjb25jdXJyZW50IHNhZmU6XG4gICAgY29uc3QgY2IgPSBzZWxmLl9fQlVJTERfTUFOSUZFU1RfQ0JcbiAgICBzZWxmLl9fQlVJTERfTUFOSUZFU1RfQ0IgPSAoKSA9PiB7XG4gICAgICByZXNvbHZlKHNlbGYuX19CVUlMRF9NQU5JRkVTVCEpXG4gICAgICBjYiAmJiBjYigpXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0PENsaWVudEJ1aWxkTWFuaWZlc3Q+KFxuICAgIG9uQnVpbGRNYW5pZmVzdCxcbiAgICBNU19NQVhfSURMRV9ERUxBWSxcbiAgICBtYXJrQXNzZXRFcnJvcihuZXcgRXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGNsaWVudCBidWlsZCBtYW5pZmVzdCcpKVxuICApXG59XG5cbmludGVyZmFjZSBSb3V0ZUZpbGVzIHtcbiAgc2NyaXB0czogc3RyaW5nW11cbiAgY3NzOiBzdHJpbmdbXVxufVxuZnVuY3Rpb24gZ2V0RmlsZXNGb3JSb3V0ZShcbiAgYXNzZXRQcmVmaXg6IHN0cmluZyxcbiAgcm91dGU6IHN0cmluZ1xuKTogUHJvbWlzZTxSb3V0ZUZpbGVzPiB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgc2NyaXB0czogW1xuICAgICAgICBhc3NldFByZWZpeCArXG4gICAgICAgICAgJy9fbmV4dC9zdGF0aWMvY2h1bmtzL3BhZ2VzJyArXG4gICAgICAgICAgZW5jb2RlVVJJKGdldEFzc2V0UGF0aEZyb21Sb3V0ZShyb3V0ZSwgJy5qcycpKSxcbiAgICAgIF0sXG4gICAgICAvLyBTdHlsZXMgYXJlIGhhbmRsZWQgYnkgYHN0eWxlLWxvYWRlcmAgaW4gZGV2ZWxvcG1lbnQ6XG4gICAgICBjc3M6IFtdLFxuICAgIH0pXG4gIH1cbiAgcmV0dXJuIGdldENsaWVudEJ1aWxkTWFuaWZlc3QoKS50aGVuKChtYW5pZmVzdCkgPT4ge1xuICAgIGlmICghKHJvdXRlIGluIG1hbmlmZXN0KSkge1xuICAgICAgdGhyb3cgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBGYWlsZWQgdG8gbG9va3VwIHJvdXRlOiAke3JvdXRlfWApKVxuICAgIH1cbiAgICBjb25zdCBhbGxGaWxlcyA9IG1hbmlmZXN0W3JvdXRlXS5tYXAoXG4gICAgICAoZW50cnkpID0+IGFzc2V0UHJlZml4ICsgJy9fbmV4dC8nICsgZW5jb2RlVVJJKGVudHJ5KVxuICAgIClcbiAgICByZXR1cm4ge1xuICAgICAgc2NyaXB0czogYWxsRmlsZXMuZmlsdGVyKCh2KSA9PiB2LmVuZHNXaXRoKCcuanMnKSksXG4gICAgICBjc3M6IGFsbEZpbGVzLmZpbHRlcigodikgPT4gdi5lbmRzV2l0aCgnLmNzcycpKSxcbiAgICB9XG4gIH0pXG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlTG9hZGVyKGFzc2V0UHJlZml4OiBzdHJpbmcpOiBSb3V0ZUxvYWRlciB7XG4gIGNvbnN0IGVudHJ5cG9pbnRzOiBNYXA8XG4gICAgc3RyaW5nLFxuICAgIEZ1dHVyZTxSb3V0ZUVudHJ5cG9pbnQ+IHwgUm91dGVFbnRyeXBvaW50XG4gID4gPSBuZXcgTWFwKClcbiAgY29uc3QgbG9hZGVkU2NyaXB0czogTWFwPHN0cmluZywgUHJvbWlzZTx1bmtub3duPj4gPSBuZXcgTWFwKClcbiAgY29uc3Qgc3R5bGVTaGVldHM6IE1hcDxzdHJpbmcsIFByb21pc2U8Um91dGVTdHlsZVNoZWV0Pj4gPSBuZXcgTWFwKClcbiAgY29uc3Qgcm91dGVzOiBNYXA8XG4gICAgc3RyaW5nLFxuICAgIEZ1dHVyZTxSb3V0ZUxvYWRlckVudHJ5PiB8IFJvdXRlTG9hZGVyRW50cnlcbiAgPiA9IG5ldyBNYXAoKVxuXG4gIGZ1bmN0aW9uIG1heWJlRXhlY3V0ZVNjcmlwdChzcmM6IHN0cmluZyk6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGxldCBwcm9tOiBQcm9taXNlPHVua25vd24+IHwgdW5kZWZpbmVkID0gbG9hZGVkU2NyaXB0cy5nZXQoc3JjKVxuICAgIGlmIChwcm9tKSB7XG4gICAgICByZXR1cm4gcHJvbVxuICAgIH1cblxuICAgIC8vIFNraXAgZXhlY3V0aW5nIHNjcmlwdCBpZiBpdCdzIGFscmVhZHkgaW4gdGhlIERPTTpcbiAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihgc2NyaXB0W3NyY149XCIke3NyY31cIl1gKSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpXG4gICAgfVxuXG4gICAgbG9hZGVkU2NyaXB0cy5zZXQoc3JjLCAocHJvbSA9IGFwcGVuZFNjcmlwdChzcmMpKSlcbiAgICByZXR1cm4gcHJvbVxuICB9XG5cbiAgZnVuY3Rpb24gZmV0Y2hTdHlsZVNoZWV0KGhyZWY6IHN0cmluZyk6IFByb21pc2U8Um91dGVTdHlsZVNoZWV0PiB7XG4gICAgbGV0IHByb206IFByb21pc2U8Um91dGVTdHlsZVNoZWV0PiB8IHVuZGVmaW5lZCA9IHN0eWxlU2hlZXRzLmdldChocmVmKVxuICAgIGlmIChwcm9tKSB7XG4gICAgICByZXR1cm4gcHJvbVxuICAgIH1cblxuICAgIHN0eWxlU2hlZXRzLnNldChcbiAgICAgIGhyZWYsXG4gICAgICAocHJvbSA9IGZldGNoKGhyZWYpXG4gICAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gbG9hZCBzdHlsZXNoZWV0OiAke2hyZWZ9YClcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHJlcy50ZXh0KCkudGhlbigodGV4dCkgPT4gKHsgaHJlZjogaHJlZiwgY29udGVudDogdGV4dCB9KSlcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICB0aHJvdyBtYXJrQXNzZXRFcnJvcihlcnIpXG4gICAgICAgIH0pKVxuICAgIClcbiAgICByZXR1cm4gcHJvbVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICB3aGVuRW50cnlwb2ludChyb3V0ZTogc3RyaW5nKSB7XG4gICAgICByZXR1cm4gd2l0aEZ1dHVyZShyb3V0ZSwgZW50cnlwb2ludHMpXG4gICAgfSxcbiAgICBvbkVudHJ5cG9pbnQocm91dGU6IHN0cmluZywgZXhlY3V0ZTogKCkgPT4gdW5rbm93bikge1xuICAgICAgUHJvbWlzZS5yZXNvbHZlKGV4ZWN1dGUpXG4gICAgICAgIC50aGVuKChmbikgPT4gZm4oKSlcbiAgICAgICAgLnRoZW4oXG4gICAgICAgICAgKGV4cG9ydHM6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIGNvbXBvbmVudDogKGV4cG9ydHMgJiYgZXhwb3J0cy5kZWZhdWx0KSB8fCBleHBvcnRzLFxuICAgICAgICAgICAgZXhwb3J0czogZXhwb3J0cyxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICAoZXJyKSA9PiAoeyBlcnJvcjogZXJyIH0pXG4gICAgICAgIClcbiAgICAgICAgLnRoZW4oKGlucHV0OiBSb3V0ZUVudHJ5cG9pbnQpID0+IHtcbiAgICAgICAgICBjb25zdCBvbGQgPSBlbnRyeXBvaW50cy5nZXQocm91dGUpXG4gICAgICAgICAgZW50cnlwb2ludHMuc2V0KHJvdXRlLCBpbnB1dClcbiAgICAgICAgICBpZiAob2xkICYmICdyZXNvbHZlJyBpbiBvbGQpIG9sZC5yZXNvbHZlKGlucHV0KVxuICAgICAgICB9KVxuICAgIH0sXG4gICAgbG9hZFJvdXRlKHJvdXRlOiBzdHJpbmcpIHtcbiAgICAgIHJldHVybiB3aXRoRnV0dXJlPFJvdXRlTG9hZGVyRW50cnk+KHJvdXRlLCByb3V0ZXMsIGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB7IHNjcmlwdHMsIGNzcyB9ID0gYXdhaXQgZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpXG4gICAgICAgICAgY29uc3QgWywgc3R5bGVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIGVudHJ5cG9pbnRzLmhhcyhyb3V0ZSlcbiAgICAgICAgICAgICAgPyBbXVxuICAgICAgICAgICAgICA6IFByb21pc2UuYWxsKHNjcmlwdHMubWFwKG1heWJlRXhlY3V0ZVNjcmlwdCkpLFxuICAgICAgICAgICAgUHJvbWlzZS5hbGwoY3NzLm1hcChmZXRjaFN0eWxlU2hlZXQpKSxcbiAgICAgICAgICBdIGFzIGNvbnN0KVxuXG4gICAgICAgICAgY29uc3QgZW50cnlwb2ludDogUm91dGVFbnRyeXBvaW50ID0gYXdhaXQgcmVzb2x2ZVByb21pc2VXaXRoVGltZW91dChcbiAgICAgICAgICAgIHRoaXMud2hlbkVudHJ5cG9pbnQocm91dGUpLFxuICAgICAgICAgICAgTVNfTUFYX0lETEVfREVMQVksXG4gICAgICAgICAgICBtYXJrQXNzZXRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEVycm9yKGBSb3V0ZSBkaWQgbm90IGNvbXBsZXRlIGxvYWRpbmc6ICR7cm91dGV9YClcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG5cbiAgICAgICAgICBjb25zdCByZXM6IFJvdXRlTG9hZGVyRW50cnkgPSBPYmplY3QuYXNzaWduPFxuICAgICAgICAgICAgeyBzdHlsZXM6IFJvdXRlU3R5bGVTaGVldFtdIH0sXG4gICAgICAgICAgICBSb3V0ZUVudHJ5cG9pbnRcbiAgICAgICAgICA+KHsgc3R5bGVzIH0sIGVudHJ5cG9pbnQpXG4gICAgICAgICAgcmV0dXJuICdlcnJvcicgaW4gZW50cnlwb2ludCA/IGVudHJ5cG9pbnQgOiByZXNcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVyciB9XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSxcbiAgICBwcmVmZXRjaChyb3V0ZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lTGFicy9xdWlja2xpbmsvYmxvYi80NTNhNjYxZmExZmE5NDBlMmQyZTA0NDQ1MjM5OGUzOGM2N2E5OGZiL3NyYy9pbmRleC5tanMjTDExNS1MMTE4XG4gICAgICAvLyBMaWNlbnNlOiBBcGFjaGUgMi4wXG4gICAgICBsZXQgY25cbiAgICAgIGlmICgoY24gPSAobmF2aWdhdG9yIGFzIGFueSkuY29ubmVjdGlvbikpIHtcbiAgICAgICAgLy8gRG9uJ3QgcHJlZmV0Y2ggaWYgdXNpbmcgMkcgb3IgaWYgU2F2ZS1EYXRhIGlzIGVuYWJsZWQuXG4gICAgICAgIGlmIChjbi5zYXZlRGF0YSB8fCAvMmcvLnRlc3QoY24uZWZmZWN0aXZlVHlwZSkpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKVxuICAgICAgfVxuICAgICAgcmV0dXJuIGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKVxuICAgICAgICAudGhlbigob3V0cHV0KSA9PlxuICAgICAgICAgIFByb21pc2UuYWxsKFxuICAgICAgICAgICAgY2FuUHJlZmV0Y2hcbiAgICAgICAgICAgICAgPyBvdXRwdXQuc2NyaXB0cy5tYXAoKHNjcmlwdCkgPT4gcHJlZmV0Y2hWaWFEb20oc2NyaXB0LCAnc2NyaXB0JykpXG4gICAgICAgICAgICAgIDogW11cbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIHJlcXVlc3RJZGxlQ2FsbGJhY2soKCkgPT4gdGhpcy5sb2FkUm91dGUocm91dGUpKVxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goXG4gICAgICAgICAgLy8gc3dhbGxvdyBwcmVmZXRjaCBlcnJvcnNcbiAgICAgICAgICAoKSA9PiB7fVxuICAgICAgICApXG4gICAgfSxcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjcmVhdGVSb3V0ZUxvYWRlclxuIiwiLyogZ2xvYmFsIHdpbmRvdyAqL1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFJvdXRlciwgeyBOZXh0Um91dGVyIH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXInXG5pbXBvcnQgeyBSb3V0ZXJDb250ZXh0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci1jb250ZXh0J1xuXG50eXBlIENsYXNzQXJndW1lbnRzPFQ+ID0gVCBleHRlbmRzIG5ldyAoLi4uYXJnczogaW5mZXIgVSkgPT4gYW55ID8gVSA6IGFueVxuXG50eXBlIFJvdXRlckFyZ3MgPSBDbGFzc0FyZ3VtZW50czx0eXBlb2YgUm91dGVyPlxuXG50eXBlIFNpbmdsZXRvblJvdXRlckJhc2UgPSB7XG4gIHJvdXRlcjogUm91dGVyIHwgbnVsbFxuICByZWFkeUNhbGxiYWNrczogQXJyYXk8KCkgPT4gYW55PlxuICByZWFkeShjYjogKCkgPT4gYW55KTogdm9pZFxufVxuXG5leHBvcnQgeyBSb3V0ZXIsIE5leHRSb3V0ZXIgfVxuXG5leHBvcnQgdHlwZSBTaW5nbGV0b25Sb3V0ZXIgPSBTaW5nbGV0b25Sb3V0ZXJCYXNlICYgTmV4dFJvdXRlclxuXG5jb25zdCBzaW5nbGV0b25Sb3V0ZXI6IFNpbmdsZXRvblJvdXRlckJhc2UgPSB7XG4gIHJvdXRlcjogbnVsbCwgLy8gaG9sZHMgdGhlIGFjdHVhbCByb3V0ZXIgaW5zdGFuY2VcbiAgcmVhZHlDYWxsYmFja3M6IFtdLFxuICByZWFkeShjYjogKCkgPT4gdm9pZCkge1xuICAgIGlmICh0aGlzLnJvdXRlcikgcmV0dXJuIGNiKClcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHRoaXMucmVhZHlDYWxsYmFja3MucHVzaChjYilcbiAgICB9XG4gIH0sXG59XG5cbi8vIENyZWF0ZSBwdWJsaWMgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgcm91dGVyIGluIHRoZSBzaW5nbGV0b25Sb3V0ZXJcbmNvbnN0IHVybFByb3BlcnR5RmllbGRzID0gW1xuICAncGF0aG5hbWUnLFxuICAncm91dGUnLFxuICAncXVlcnknLFxuICAnYXNQYXRoJyxcbiAgJ2NvbXBvbmVudHMnLFxuICAnaXNGYWxsYmFjaycsXG4gICdiYXNlUGF0aCcsXG4gICdsb2NhbGUnLFxuICAnbG9jYWxlcycsXG4gICdkZWZhdWx0TG9jYWxlJyxcbiAgJ2lzUmVhZHknLFxuICAnaXNQcmV2aWV3JyxcbiAgJ2lzTG9jYWxlRG9tYWluJyxcbl1cbmNvbnN0IHJvdXRlckV2ZW50cyA9IFtcbiAgJ3JvdXRlQ2hhbmdlU3RhcnQnLFxuICAnYmVmb3JlSGlzdG9yeUNoYW5nZScsXG4gICdyb3V0ZUNoYW5nZUNvbXBsZXRlJyxcbiAgJ3JvdXRlQ2hhbmdlRXJyb3InLFxuICAnaGFzaENoYW5nZVN0YXJ0JyxcbiAgJ2hhc2hDaGFuZ2VDb21wbGV0ZScsXG5dXG5jb25zdCBjb3JlTWV0aG9kRmllbGRzID0gW1xuICAncHVzaCcsXG4gICdyZXBsYWNlJyxcbiAgJ3JlbG9hZCcsXG4gICdiYWNrJyxcbiAgJ3ByZWZldGNoJyxcbiAgJ2JlZm9yZVBvcFN0YXRlJyxcbl1cblxuLy8gRXZlbnRzIGlzIGEgc3RhdGljIHByb3BlcnR5IG9uIHRoZSByb3V0ZXIsIHRoZSByb3V0ZXIgZG9lc24ndCBoYXZlIHRvIGJlIGluaXRpYWxpemVkIHRvIHVzZSBpdFxuT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlciwgJ2V2ZW50cycsIHtcbiAgZ2V0KCkge1xuICAgIHJldHVybiBSb3V0ZXIuZXZlbnRzXG4gIH0sXG59KVxuXG51cmxQcm9wZXJ0eUZpZWxkcy5mb3JFYWNoKChmaWVsZDogc3RyaW5nKSA9PiB7XG4gIC8vIEhlcmUgd2UgbmVlZCB0byB1c2UgT2JqZWN0LmRlZmluZVByb3BlcnR5IGJlY2F1c2UsIHdlIG5lZWQgdG8gcmV0dXJuXG4gIC8vIHRoZSBwcm9wZXJ0eSBhc3NpZ25lZCB0byB0aGUgYWN0dWFsIHJvdXRlclxuICAvLyBUaGUgdmFsdWUgbWlnaHQgZ2V0IGNoYW5nZWQgYXMgd2UgY2hhbmdlIHJvdXRlcyBhbmQgdGhpcyBpcyB0aGVcbiAgLy8gcHJvcGVyIHdheSB0byBhY2Nlc3MgaXRcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlciwgZmllbGQsIHtcbiAgICBnZXQoKSB7XG4gICAgICBjb25zdCByb3V0ZXIgPSBnZXRSb3V0ZXIoKSBhcyBhbnlcbiAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdIGFzIHN0cmluZ1xuICAgIH0sXG4gIH0pXG59KVxuXG5jb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkOiBzdHJpbmcpID0+IHtcbiAgLy8gV2UgZG9uJ3QgcmVhbGx5IGtub3cgdGhlIHR5cGVzIGhlcmUsIHNvIHdlIGFkZCB0aGVtIGxhdGVyIGluc3RlYWRcbiAgOyhzaW5nbGV0b25Sb3V0ZXIgYXMgYW55KVtmaWVsZF0gPSAoLi4uYXJnczogYW55W10pID0+IHtcbiAgICBjb25zdCByb3V0ZXIgPSBnZXRSb3V0ZXIoKSBhcyBhbnlcbiAgICByZXR1cm4gcm91dGVyW2ZpZWxkXSguLi5hcmdzKVxuICB9XG59KVxuXG5yb3V0ZXJFdmVudHMuZm9yRWFjaCgoZXZlbnQ6IHN0cmluZykgPT4ge1xuICBzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCkgPT4ge1xuICAgIFJvdXRlci5ldmVudHMub24oZXZlbnQsICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zdCBldmVudEZpZWxkID0gYG9uJHtldmVudC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX0ke2V2ZW50LnN1YnN0cmluZyhcbiAgICAgICAgMVxuICAgICAgKX1gXG4gICAgICBjb25zdCBfc2luZ2xldG9uUm91dGVyID0gc2luZ2xldG9uUm91dGVyIGFzIGFueVxuICAgICAgaWYgKF9zaW5nbGV0b25Sb3V0ZXJbZXZlbnRGaWVsZF0pIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKC4uLmFyZ3MpXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHdoZW4gcnVubmluZyB0aGUgUm91dGVyIGV2ZW50OiAke2V2ZW50RmllbGR9YClcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGAke2Vyci5tZXNzYWdlfVxcbiR7ZXJyLnN0YWNrfWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuICB9KVxufSlcblxuZnVuY3Rpb24gZ2V0Um91dGVyKCk6IFJvdXRlciB7XG4gIGlmICghc2luZ2xldG9uUm91dGVyLnJvdXRlcikge1xuICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgJ05vIHJvdXRlciBpbnN0YW5jZSBmb3VuZC5cXG4nICtcbiAgICAgICdZb3Ugc2hvdWxkIG9ubHkgdXNlIFwibmV4dC9yb3V0ZXJcIiBpbnNpZGUgdGhlIGNsaWVudCBzaWRlIG9mIHlvdXIgYXBwLlxcbidcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSlcbiAgfVxuICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlclxufVxuXG4vLyBFeHBvcnQgdGhlIHNpbmdsZXRvblJvdXRlciBhbmQgdGhpcyBpcyB0aGUgcHVibGljIEFQSS5cbmV4cG9ydCBkZWZhdWx0IHNpbmdsZXRvblJvdXRlciBhcyBTaW5nbGV0b25Sb3V0ZXJcblxuLy8gUmVleHBvcnQgdGhlIHdpdGhSb3V0ZSBIT0NcbmV4cG9ydCB7IGRlZmF1bHQgYXMgd2l0aFJvdXRlciB9IGZyb20gJy4vd2l0aC1yb3V0ZXInXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VSb3V0ZXIoKTogTmV4dFJvdXRlciB7XG4gIHJldHVybiBSZWFjdC51c2VDb250ZXh0KFJvdXRlckNvbnRleHQpXG59XG5cbi8vIElOVEVSTkFMIEFQSVNcbi8vIC0tLS0tLS0tLS0tLS1cbi8vIChkbyBub3QgdXNlIGZvbGxvd2luZyBleHBvcnRzIGluc2lkZSB0aGUgYXBwKVxuXG4vLyBDcmVhdGUgYSByb3V0ZXIgYW5kIGFzc2lnbiBpdCBhcyB0aGUgc2luZ2xldG9uIGluc3RhbmNlLlxuLy8gVGhpcyBpcyB1c2VkIGluIGNsaWVudCBzaWRlIHdoZW4gd2UgYXJlIGluaXRpbGl6aW5nIHRoZSBhcHAuXG4vLyBUaGlzIHNob3VsZCAqKm5vdCoqIHVzZSBpbnNpZGUgdGhlIHNlcnZlci5cbmV4cG9ydCBjb25zdCBjcmVhdGVSb3V0ZXIgPSAoLi4uYXJnczogUm91dGVyQXJncyk6IFJvdXRlciA9PiB7XG4gIHNpbmdsZXRvblJvdXRlci5yb3V0ZXIgPSBuZXcgUm91dGVyKC4uLmFyZ3MpXG4gIHNpbmdsZXRvblJvdXRlci5yZWFkeUNhbGxiYWNrcy5mb3JFYWNoKChjYikgPT4gY2IoKSlcbiAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzID0gW11cblxuICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlclxufVxuXG4vLyBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gY3JlYXRlIHRoZSBgd2l0aFJvdXRlcmAgcm91dGVyIGluc3RhbmNlXG5leHBvcnQgZnVuY3Rpb24gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlKHJvdXRlcjogUm91dGVyKTogTmV4dFJvdXRlciB7XG4gIGNvbnN0IF9yb3V0ZXIgPSByb3V0ZXIgYXMgYW55XG4gIGNvbnN0IGluc3RhbmNlID0ge30gYXMgYW55XG5cbiAgZm9yIChjb25zdCBwcm9wZXJ0eSBvZiB1cmxQcm9wZXJ0eUZpZWxkcykge1xuICAgIGlmICh0eXBlb2YgX3JvdXRlcltwcm9wZXJ0eV0gPT09ICdvYmplY3QnKSB7XG4gICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBPYmplY3QuYXNzaWduKFxuICAgICAgICBBcnJheS5pc0FycmF5KF9yb3V0ZXJbcHJvcGVydHldKSA/IFtdIDoge30sXG4gICAgICAgIF9yb3V0ZXJbcHJvcGVydHldXG4gICAgICApIC8vIG1ha2VzIHN1cmUgcXVlcnkgaXMgbm90IHN0YXRlZnVsXG4gICAgICBjb250aW51ZVxuICAgIH1cblxuICAgIGluc3RhbmNlW3Byb3BlcnR5XSA9IF9yb3V0ZXJbcHJvcGVydHldXG4gIH1cblxuICAvLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG4gIGluc3RhbmNlLmV2ZW50cyA9IFJvdXRlci5ldmVudHNcblxuICBjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XG4gICAgaW5zdGFuY2VbZmllbGRdID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgICByZXR1cm4gX3JvdXRlcltmaWVsZF0oLi4uYXJncylcbiAgICB9XG4gIH0pXG5cbiAgcmV0dXJuIGluc3RhbmNlXG59XG4iLCJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQge1xuICByZXF1ZXN0SWRsZUNhbGxiYWNrLFxuICBjYW5jZWxJZGxlQ2FsbGJhY2ssXG59IGZyb20gJy4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrJ1xuXG50eXBlIFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdCA9IFBpY2s8SW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0LCAncm9vdE1hcmdpbic+XG50eXBlIFVzZUludGVyc2VjdGlvbiA9IHsgZGlzYWJsZWQ/OiBib29sZWFuIH0gJiBVc2VJbnRlcnNlY3Rpb25PYnNlcnZlckluaXRcbnR5cGUgT2JzZXJ2ZUNhbGxiYWNrID0gKGlzVmlzaWJsZTogYm9vbGVhbikgPT4gdm9pZFxudHlwZSBPYnNlcnZlciA9IHtcbiAgaWQ6IHN0cmluZ1xuICBvYnNlcnZlcjogSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcbiAgZWxlbWVudHM6IE1hcDxFbGVtZW50LCBPYnNlcnZlQ2FsbGJhY2s+XG59XG5cbmNvbnN0IGhhc0ludGVyc2VjdGlvbk9ic2VydmVyID0gdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyICE9PSAndW5kZWZpbmVkJ1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlSW50ZXJzZWN0aW9uPFQgZXh0ZW5kcyBFbGVtZW50Pih7XG4gIHJvb3RNYXJnaW4sXG4gIGRpc2FibGVkLFxufTogVXNlSW50ZXJzZWN0aW9uKTogWyhlbGVtZW50OiBUIHwgbnVsbCkgPT4gdm9pZCwgYm9vbGVhbl0ge1xuICBjb25zdCBpc0Rpc2FibGVkOiBib29sZWFuID0gZGlzYWJsZWQgfHwgIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyXG5cbiAgY29uc3QgdW5vYnNlcnZlID0gdXNlUmVmPEZ1bmN0aW9uPigpXG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IHNldFJlZiA9IHVzZUNhbGxiYWNrKFxuICAgIChlbDogVCB8IG51bGwpID0+IHtcbiAgICAgIGlmICh1bm9ic2VydmUuY3VycmVudCkge1xuICAgICAgICB1bm9ic2VydmUuY3VycmVudCgpXG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gdW5kZWZpbmVkXG4gICAgICB9XG5cbiAgICAgIGlmIChpc0Rpc2FibGVkIHx8IHZpc2libGUpIHJldHVyblxuXG4gICAgICBpZiAoZWwgJiYgZWwudGFnTmFtZSkge1xuICAgICAgICB1bm9ic2VydmUuY3VycmVudCA9IG9ic2VydmUoXG4gICAgICAgICAgZWwsXG4gICAgICAgICAgKGlzVmlzaWJsZSkgPT4gaXNWaXNpYmxlICYmIHNldFZpc2libGUoaXNWaXNpYmxlKSxcbiAgICAgICAgICB7IHJvb3RNYXJnaW4gfVxuICAgICAgICApXG4gICAgICB9XG4gICAgfSxcbiAgICBbaXNEaXNhYmxlZCwgcm9vdE1hcmdpbiwgdmlzaWJsZV1cbiAgKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlcikge1xuICAgICAgaWYgKCF2aXNpYmxlKSB7XG4gICAgICAgIGNvbnN0IGlkbGVDYWxsYmFjayA9IHJlcXVlc3RJZGxlQ2FsbGJhY2soKCkgPT4gc2V0VmlzaWJsZSh0cnVlKSlcbiAgICAgICAgcmV0dXJuICgpID0+IGNhbmNlbElkbGVDYWxsYmFjayhpZGxlQ2FsbGJhY2spXG4gICAgICB9XG4gICAgfVxuICB9LCBbdmlzaWJsZV0pXG5cbiAgcmV0dXJuIFtzZXRSZWYsIHZpc2libGVdXG59XG5cbmZ1bmN0aW9uIG9ic2VydmUoXG4gIGVsZW1lbnQ6IEVsZW1lbnQsXG4gIGNhbGxiYWNrOiBPYnNlcnZlQ2FsbGJhY2ssXG4gIG9wdGlvbnM6IFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdFxuKTogKCkgPT4gdm9pZCB7XG4gIGNvbnN0IHsgaWQsIG9ic2VydmVyLCBlbGVtZW50cyB9ID0gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucylcbiAgZWxlbWVudHMuc2V0KGVsZW1lbnQsIGNhbGxiYWNrKVxuXG4gIG9ic2VydmVyLm9ic2VydmUoZWxlbWVudClcbiAgcmV0dXJuIGZ1bmN0aW9uIHVub2JzZXJ2ZSgpOiB2b2lkIHtcbiAgICBlbGVtZW50cy5kZWxldGUoZWxlbWVudClcbiAgICBvYnNlcnZlci51bm9ic2VydmUoZWxlbWVudClcblxuICAgIC8vIERlc3Ryb3kgb2JzZXJ2ZXIgd2hlbiB0aGVyZSdzIG5vdGhpbmcgbGVmdCB0byB3YXRjaDpcbiAgICBpZiAoZWxlbWVudHMuc2l6ZSA9PT0gMCkge1xuICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4gICAgICBvYnNlcnZlcnMuZGVsZXRlKGlkKVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBvYnNlcnZlcnMgPSBuZXcgTWFwPHN0cmluZywgT2JzZXJ2ZXI+KClcbmZ1bmN0aW9uIGNyZWF0ZU9ic2VydmVyKG9wdGlvbnM6IFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdCk6IE9ic2VydmVyIHtcbiAgY29uc3QgaWQgPSBvcHRpb25zLnJvb3RNYXJnaW4gfHwgJydcbiAgbGV0IGluc3RhbmNlID0gb2JzZXJ2ZXJzLmdldChpZClcbiAgaWYgKGluc3RhbmNlKSB7XG4gICAgcmV0dXJuIGluc3RhbmNlXG4gIH1cblxuICBjb25zdCBlbGVtZW50cyA9IG5ldyBNYXA8RWxlbWVudCwgT2JzZXJ2ZUNhbGxiYWNrPigpXG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKSA9PiB7XG4gICAgZW50cmllcy5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgY29uc3QgY2FsbGJhY2sgPSBlbGVtZW50cy5nZXQoZW50cnkudGFyZ2V0KVxuICAgICAgY29uc3QgaXNWaXNpYmxlID0gZW50cnkuaXNJbnRlcnNlY3RpbmcgfHwgZW50cnkuaW50ZXJzZWN0aW9uUmF0aW8gPiAwXG4gICAgICBpZiAoY2FsbGJhY2sgJiYgaXNWaXNpYmxlKSB7XG4gICAgICAgIGNhbGxiYWNrKGlzVmlzaWJsZSlcbiAgICAgIH1cbiAgICB9KVxuICB9LCBvcHRpb25zKVxuXG4gIG9ic2VydmVycy5zZXQoXG4gICAgaWQsXG4gICAgKGluc3RhbmNlID0ge1xuICAgICAgaWQsXG4gICAgICBvYnNlcnZlcixcbiAgICAgIGVsZW1lbnRzLFxuICAgIH0pXG4gIClcbiAgcmV0dXJuIGluc3RhbmNlXG59XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBOZXh0Q29tcG9uZW50VHlwZSwgTmV4dFBhZ2VDb250ZXh0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3V0aWxzJ1xuaW1wb3J0IHsgTmV4dFJvdXRlciwgdXNlUm91dGVyIH0gZnJvbSAnLi9yb3V0ZXInXG5cbmV4cG9ydCB0eXBlIFdpdGhSb3V0ZXJQcm9wcyA9IHtcbiAgcm91dGVyOiBOZXh0Um91dGVyXG59XG5cbmV4cG9ydCB0eXBlIEV4Y2x1ZGVSb3V0ZXJQcm9wczxQPiA9IFBpY2s8XG4gIFAsXG4gIEV4Y2x1ZGU8a2V5b2YgUCwga2V5b2YgV2l0aFJvdXRlclByb3BzPlxuPlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB3aXRoUm91dGVyPFxuICBQIGV4dGVuZHMgV2l0aFJvdXRlclByb3BzLFxuICBDID0gTmV4dFBhZ2VDb250ZXh0XG4+KFxuICBDb21wb3NlZENvbXBvbmVudDogTmV4dENvbXBvbmVudFR5cGU8QywgYW55LCBQPlxuKTogUmVhY3QuQ29tcG9uZW50VHlwZTxFeGNsdWRlUm91dGVyUHJvcHM8UD4+IHtcbiAgZnVuY3Rpb24gV2l0aFJvdXRlcldyYXBwZXIocHJvcHM6IGFueSk6IEpTWC5FbGVtZW50IHtcbiAgICByZXR1cm4gPENvbXBvc2VkQ29tcG9uZW50IHJvdXRlcj17dXNlUm91dGVyKCl9IHsuLi5wcm9wc30gLz5cbiAgfVxuXG4gIFdpdGhSb3V0ZXJXcmFwcGVyLmdldEluaXRpYWxQcm9wcyA9IENvbXBvc2VkQ29tcG9uZW50LmdldEluaXRpYWxQcm9wc1xuICAvLyBUaGlzIGlzIG5lZWRlZCB0byBhbGxvdyBjaGVja2luZyBmb3IgY3VzdG9tIGdldEluaXRpYWxQcm9wcyBpbiBfYXBwXG4gIDsoV2l0aFJvdXRlcldyYXBwZXIgYXMgYW55KS5vcmlnR2V0SW5pdGlhbFByb3BzID0gKENvbXBvc2VkQ29tcG9uZW50IGFzIGFueSkub3JpZ0dldEluaXRpYWxQcm9wc1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IG5hbWUgPVxuICAgICAgQ29tcG9zZWRDb21wb25lbnQuZGlzcGxheU5hbWUgfHwgQ29tcG9zZWRDb21wb25lbnQubmFtZSB8fCAnVW5rbm93bidcbiAgICBXaXRoUm91dGVyV3JhcHBlci5kaXNwbGF5TmFtZSA9IGB3aXRoUm91dGVyKCR7bmFtZX0pYFxuICB9XG5cbiAgcmV0dXJuIFdpdGhSb3V0ZXJXcmFwcGVyXG59XG4iLCJleHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplTG9jYWxlUGF0aChcbiAgcGF0aG5hbWU6IHN0cmluZyxcbiAgbG9jYWxlcz86IHN0cmluZ1tdXG4pOiB7XG4gIGRldGVjdGVkTG9jYWxlPzogc3RyaW5nXG4gIHBhdGhuYW1lOiBzdHJpbmdcbn0ge1xuICBsZXQgZGV0ZWN0ZWRMb2NhbGU6IHN0cmluZyB8IHVuZGVmaW5lZFxuICAvLyBmaXJzdCBpdGVtIHdpbGwgYmUgZW1wdHkgc3RyaW5nIGZyb20gc3BsaXR0aW5nIGF0IGZpcnN0IGNoYXJcbiAgY29uc3QgcGF0aG5hbWVQYXJ0cyA9IHBhdGhuYW1lLnNwbGl0KCcvJylcblxuICA7KGxvY2FsZXMgfHwgW10pLnNvbWUoKGxvY2FsZSkgPT4ge1xuICAgIGlmIChwYXRobmFtZVBhcnRzWzFdLnRvTG93ZXJDYXNlKCkgPT09IGxvY2FsZS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICBkZXRlY3RlZExvY2FsZSA9IGxvY2FsZVxuICAgICAgcGF0aG5hbWVQYXJ0cy5zcGxpY2UoMSwgMSlcbiAgICAgIHBhdGhuYW1lID0gcGF0aG5hbWVQYXJ0cy5qb2luKCcvJykgfHwgJy8nXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2VcbiAgfSlcblxuICByZXR1cm4ge1xuICAgIHBhdGhuYW1lLFxuICAgIGRldGVjdGVkTG9jYWxlLFxuICB9XG59XG4iLCIvKlxuTUlUIExpY2Vuc2VcblxuQ29weXJpZ2h0IChjKSBKYXNvbiBNaWxsZXIgKGh0dHBzOi8vamFzb25mb3JtYXQuY29tLylcblxuUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczpcblxuVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG5cblRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuKi9cblxuLy8gVGhpcyBmaWxlIGlzIGJhc2VkIG9uIGh0dHBzOi8vZ2l0aHViLmNvbS9kZXZlbG9waXQvbWl0dC9ibG9iL3YxLjEuMy9zcmMvaW5kZXguanNcbi8vIEl0J3MgYmVlbiBlZGl0ZWQgZm9yIHRoZSBuZWVkcyBvZiB0aGlzIHNjcmlwdFxuLy8gU2VlIHRoZSBMSUNFTlNFIGF0IHRoZSB0b3Agb2YgdGhlIGZpbGVcblxudHlwZSBIYW5kbGVyID0gKC4uLmV2dHM6IGFueVtdKSA9PiB2b2lkXG5cbmV4cG9ydCB0eXBlIE1pdHRFbWl0dGVyID0ge1xuICBvbih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpOiB2b2lkXG4gIG9mZih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpOiB2b2lkXG4gIGVtaXQodHlwZTogc3RyaW5nLCAuLi5ldnRzOiBhbnlbXSk6IHZvaWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbWl0dCgpOiBNaXR0RW1pdHRlciB7XG4gIGNvbnN0IGFsbDogeyBbczogc3RyaW5nXTogSGFuZGxlcltdIH0gPSBPYmplY3QuY3JlYXRlKG51bGwpXG5cbiAgcmV0dXJuIHtcbiAgICBvbih0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IEhhbmRsZXIpIHtcbiAgICAgIDsoYWxsW3R5cGVdIHx8IChhbGxbdHlwZV0gPSBbXSkpLnB1c2goaGFuZGxlcilcbiAgICB9LFxuXG4gICAgb2ZmKHR5cGU6IHN0cmluZywgaGFuZGxlcjogSGFuZGxlcikge1xuICAgICAgaWYgKGFsbFt0eXBlXSkge1xuICAgICAgICBhbGxbdHlwZV0uc3BsaWNlKGFsbFt0eXBlXS5pbmRleE9mKGhhbmRsZXIpID4+PiAwLCAxKVxuICAgICAgfVxuICAgIH0sXG5cbiAgICBlbWl0KHR5cGU6IHN0cmluZywgLi4uZXZ0czogYW55W10pIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgIDsoYWxsW3R5cGVdIHx8IFtdKS5zbGljZSgpLm1hcCgoaGFuZGxlcjogSGFuZGxlcikgPT4ge1xuICAgICAgICBoYW5kbGVyKC4uLmV2dHMpXG4gICAgICB9KVxuICAgIH0sXG4gIH1cbn1cbiIsIi8qIGdsb2JhbCBfX05FWFRfREFUQV9fICovXG4vLyB0c2xpbnQ6ZGlzYWJsZTpuby1jb25zb2xlXG5pbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXJsT2JqZWN0IH0gZnJvbSAndXJsJ1xuaW1wb3J0IHtcbiAgbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2gsXG4gIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoLFxufSBmcm9tICcuLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoJ1xuaW1wb3J0IHsgR29vZFBhZ2VDYWNoZSwgU3R5bGVTaGVldFR1cGxlIH0gZnJvbSAnLi4vLi4vLi4vY2xpZW50L3BhZ2UtbG9hZGVyJ1xuaW1wb3J0IHtcbiAgZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCxcbiAgaXNBc3NldEVycm9yLFxuICBtYXJrQXNzZXRFcnJvcixcbn0gZnJvbSAnLi4vLi4vLi4vY2xpZW50L3JvdXRlLWxvYWRlcidcbmltcG9ydCB7IERvbWFpbkxvY2FsZXMgfSBmcm9tICcuLi8uLi9zZXJ2ZXIvY29uZmlnJ1xuaW1wb3J0IHsgZGVub3JtYWxpemVQYWdlUGF0aCB9IGZyb20gJy4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGgnXG5pbXBvcnQgeyBub3JtYWxpemVMb2NhbGVQYXRoIH0gZnJvbSAnLi4vaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGgnXG5pbXBvcnQgbWl0dCwgeyBNaXR0RW1pdHRlciB9IGZyb20gJy4uL21pdHQnXG5pbXBvcnQge1xuICBBcHBDb250ZXh0VHlwZSxcbiAgZm9ybWF0V2l0aFZhbGlkYXRpb24sXG4gIGdldExvY2F0aW9uT3JpZ2luLFxuICBnZXRVUkwsXG4gIGxvYWRHZXRJbml0aWFsUHJvcHMsXG4gIE5leHRQYWdlQ29udGV4dCxcbiAgU1QsXG4gIE5FWFRfREFUQSxcbn0gZnJvbSAnLi4vdXRpbHMnXG5pbXBvcnQgeyBpc0R5bmFtaWNSb3V0ZSB9IGZyb20gJy4vdXRpbHMvaXMtZHluYW1pYydcbmltcG9ydCB7IHBhcnNlUmVsYXRpdmVVcmwgfSBmcm9tICcuL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybCdcbmltcG9ydCB7IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkgfSBmcm9tICcuL3V0aWxzL3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHJlc29sdmVSZXdyaXRlcyBmcm9tICcuL3V0aWxzL3Jlc29sdmUtcmV3cml0ZXMnXG5pbXBvcnQgeyBnZXRSb3V0ZU1hdGNoZXIgfSBmcm9tICcuL3V0aWxzL3JvdXRlLW1hdGNoZXInXG5pbXBvcnQgeyBnZXRSb3V0ZVJlZ2V4IH0gZnJvbSAnLi91dGlscy9yb3V0ZS1yZWdleCdcblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICAvKiBwcm9kICovXG4gICAgX19ORVhUX0RBVEFfXzogTkVYVF9EQVRBXG4gIH1cbn1cblxuaW50ZXJmYWNlIFJvdXRlUHJvcGVydGllcyB7XG4gIHNoYWxsb3c6IGJvb2xlYW5cbn1cblxuaW50ZXJmYWNlIFRyYW5zaXRpb25PcHRpb25zIHtcbiAgc2hhbGxvdz86IGJvb2xlYW5cbiAgbG9jYWxlPzogc3RyaW5nIHwgZmFsc2VcbiAgc2Nyb2xsPzogYm9vbGVhblxufVxuXG5pbnRlcmZhY2UgTmV4dEhpc3RvcnlTdGF0ZSB7XG4gIHVybDogc3RyaW5nXG4gIGFzOiBzdHJpbmdcbiAgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnNcbn1cblxudHlwZSBIaXN0b3J5U3RhdGUgPVxuICB8IG51bGxcbiAgfCB7IF9fTjogZmFsc2UgfVxuICB8ICh7IF9fTjogdHJ1ZTsgaWR4OiBudW1iZXIgfSAmIE5leHRIaXN0b3J5U3RhdGUpXG5cbmxldCBkZXRlY3REb21haW5Mb2NhbGU6IHR5cGVvZiBpbXBvcnQoJy4uL2kxOG4vZGV0ZWN0LWRvbWFpbi1sb2NhbGUnKS5kZXRlY3REb21haW5Mb2NhbGVcblxuaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgZGV0ZWN0RG9tYWluTG9jYWxlID0gcmVxdWlyZSgnLi4vaTE4bi9kZXRlY3QtZG9tYWluLWxvY2FsZScpXG4gICAgLmRldGVjdERvbWFpbkxvY2FsZVxufVxuXG5jb25zdCBiYXNlUGF0aCA9IChwcm9jZXNzLmVudi5fX05FWFRfUk9VVEVSX0JBU0VQQVRIIGFzIHN0cmluZykgfHwgJydcblxuZnVuY3Rpb24gYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpIHtcbiAgcmV0dXJuIE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdSb3V0ZSBDYW5jZWxsZWQnKSwge1xuICAgIGNhbmNlbGxlZDogdHJ1ZSxcbiAgfSlcbn1cblxuZnVuY3Rpb24gYWRkUGF0aFByZWZpeChwYXRoOiBzdHJpbmcsIHByZWZpeD86IHN0cmluZykge1xuICByZXR1cm4gcHJlZml4ICYmIHBhdGguc3RhcnRzV2l0aCgnLycpXG4gICAgPyBwYXRoID09PSAnLydcbiAgICAgID8gbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2gocHJlZml4KVxuICAgICAgOiBgJHtwcmVmaXh9JHtwYXRoTm9RdWVyeUhhc2gocGF0aCkgPT09ICcvJyA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aH1gXG4gICAgOiBwYXRoXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXREb21haW5Mb2NhbGUoXG4gIHBhdGg6IHN0cmluZyxcbiAgbG9jYWxlPzogc3RyaW5nIHwgZmFsc2UsXG4gIGxvY2FsZXM/OiBzdHJpbmdbXSxcbiAgZG9tYWluTG9jYWxlcz86IERvbWFpbkxvY2FsZXNcbikge1xuICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgIGxvY2FsZSA9IGxvY2FsZSB8fCBub3JtYWxpemVMb2NhbGVQYXRoKHBhdGgsIGxvY2FsZXMpLmRldGVjdGVkTG9jYWxlXG5cbiAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLCB1bmRlZmluZWQsIGxvY2FsZSlcblxuICAgIGlmIChkZXRlY3RlZERvbWFpbikge1xuICAgICAgcmV0dXJuIGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHtcbiAgICAgICAgYmFzZVBhdGggfHwgJydcbiAgICAgIH0ke2xvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke2xvY2FsZX1gfSR7cGF0aH1gXG4gICAgfVxuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRMb2NhbGUoXG4gIHBhdGg6IHN0cmluZyxcbiAgbG9jYWxlPzogc3RyaW5nIHwgZmFsc2UsXG4gIGRlZmF1bHRMb2NhbGU/OiBzdHJpbmdcbikge1xuICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgIHJldHVybiBsb2NhbGUgJiZcbiAgICAgIGxvY2FsZSAhPT0gZGVmYXVsdExvY2FsZSAmJlxuICAgICAgIXBhdGguc3RhcnRzV2l0aCgnLycgKyBsb2NhbGUgKyAnLycpICYmXG4gICAgICBwYXRoICE9PSAnLycgKyBsb2NhbGVcbiAgICAgID8gYWRkUGF0aFByZWZpeChwYXRoLCAnLycgKyBsb2NhbGUpXG4gICAgICA6IHBhdGhcbiAgfVxuICByZXR1cm4gcGF0aFxufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVsTG9jYWxlKHBhdGg6IHN0cmluZywgbG9jYWxlPzogc3RyaW5nKSB7XG4gIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgcmV0dXJuIGxvY2FsZSAmJlxuICAgICAgKHBhdGguc3RhcnRzV2l0aCgnLycgKyBsb2NhbGUgKyAnLycpIHx8IHBhdGggPT09ICcvJyArIGxvY2FsZSlcbiAgICAgID8gcGF0aC5zdWJzdHIobG9jYWxlLmxlbmd0aCArIDEpIHx8ICcvJ1xuICAgICAgOiBwYXRoXG4gIH1cbiAgcmV0dXJuIHBhdGhcbn1cblxuZnVuY3Rpb24gcGF0aE5vUXVlcnlIYXNoKHBhdGg6IHN0cmluZykge1xuICBjb25zdCBxdWVyeUluZGV4ID0gcGF0aC5pbmRleE9mKCc/JylcbiAgY29uc3QgaGFzaEluZGV4ID0gcGF0aC5pbmRleE9mKCcjJylcblxuICBpZiAocXVlcnlJbmRleCA+IC0xIHx8IGhhc2hJbmRleCA+IC0xKSB7XG4gICAgcGF0aCA9IHBhdGguc3Vic3RyaW5nKDAsIHF1ZXJ5SW5kZXggPiAtMSA/IHF1ZXJ5SW5kZXggOiBoYXNoSW5kZXgpXG4gIH1cbiAgcmV0dXJuIHBhdGhcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhhc0Jhc2VQYXRoKHBhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBwYXRoID0gcGF0aE5vUXVlcnlIYXNoKHBhdGgpXG4gIHJldHVybiBwYXRoID09PSBiYXNlUGF0aCB8fCBwYXRoLnN0YXJ0c1dpdGgoYmFzZVBhdGggKyAnLycpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRCYXNlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyB3ZSBvbmx5IGFkZCB0aGUgYmFzZXBhdGggb24gcmVsYXRpdmUgdXJsc1xuICByZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLCBiYXNlUGF0aClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlbEJhc2VQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIHBhdGggPSBwYXRoLnNsaWNlKGJhc2VQYXRoLmxlbmd0aClcbiAgaWYgKCFwYXRoLnN0YXJ0c1dpdGgoJy8nKSkgcGF0aCA9IGAvJHtwYXRofWBcbiAgcmV0dXJuIHBhdGhcbn1cblxuLyoqXG4gKiBEZXRlY3RzIHdoZXRoZXIgYSBnaXZlbiB1cmwgaXMgcm91dGFibGUgYnkgdGhlIE5leHQuanMgcm91dGVyIChicm93c2VyIG9ubHkpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNMb2NhbFVSTCh1cmw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAvLyBwcmV2ZW50IGEgaHlkcmF0aW9uIG1pc21hdGNoIG9uIGhyZWYgZm9yIHVybCB3aXRoIGFuY2hvciByZWZzXG4gIGlmICh1cmwuc3RhcnRzV2l0aCgnLycpIHx8IHVybC5zdGFydHNXaXRoKCcjJykpIHJldHVybiB0cnVlXG4gIHRyeSB7XG4gICAgLy8gYWJzb2x1dGUgdXJscyBjYW4gYmUgbG9jYWwgaWYgdGhleSBhcmUgb24gdGhlIHNhbWUgb3JpZ2luXG4gICAgY29uc3QgbG9jYXRpb25PcmlnaW4gPSBnZXRMb2NhdGlvbk9yaWdpbigpXG4gICAgY29uc3QgcmVzb2x2ZWQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb25PcmlnaW4pXG4gICAgcmV0dXJuIHJlc29sdmVkLm9yaWdpbiA9PT0gbG9jYXRpb25PcmlnaW4gJiYgaGFzQmFzZVBhdGgocmVzb2x2ZWQucGF0aG5hbWUpXG4gIH0gY2F0Y2ggKF8pIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxufVxuXG50eXBlIFVybCA9IFVybE9iamVjdCB8IHN0cmluZ1xuXG5leHBvcnQgZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhcbiAgcm91dGU6IHN0cmluZyxcbiAgYXNQYXRobmFtZTogc3RyaW5nLFxuICBxdWVyeTogUGFyc2VkVXJsUXVlcnlcbikge1xuICBsZXQgaW50ZXJwb2xhdGVkUm91dGUgPSAnJ1xuXG4gIGNvbnN0IGR5bmFtaWNSZWdleCA9IGdldFJvdXRlUmVnZXgocm91dGUpXG4gIGNvbnN0IGR5bmFtaWNHcm91cHMgPSBkeW5hbWljUmVnZXguZ3JvdXBzXG4gIGNvbnN0IGR5bmFtaWNNYXRjaGVzID1cbiAgICAvLyBUcnkgdG8gbWF0Y2ggdGhlIGR5bmFtaWMgcm91dGUgYWdhaW5zdCB0aGUgYXNQYXRoXG4gICAgKGFzUGF0aG5hbWUgIT09IHJvdXRlID8gZ2V0Um91dGVNYXRjaGVyKGR5bmFtaWNSZWdleCkoYXNQYXRobmFtZSkgOiAnJykgfHxcbiAgICAvLyBGYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgdmFsdWVzIGZyb20gdGhlIGhyZWZcbiAgICAvLyBUT0RPOiBzaG91bGQgdGhpcyB0YWtlIHByaW9yaXR5OyBhbHNvIG5lZWQgdG8gY2hhbmdlIGluIHRoZSByb3V0ZXIuXG4gICAgcXVlcnlcblxuICBpbnRlcnBvbGF0ZWRSb3V0ZSA9IHJvdXRlXG4gIGNvbnN0IHBhcmFtcyA9IE9iamVjdC5rZXlzKGR5bmFtaWNHcm91cHMpXG5cbiAgaWYgKFxuICAgICFwYXJhbXMuZXZlcnkoKHBhcmFtKSA9PiB7XG4gICAgICBsZXQgdmFsdWUgPSBkeW5hbWljTWF0Y2hlc1twYXJhbV0gfHwgJydcbiAgICAgIGNvbnN0IHsgcmVwZWF0LCBvcHRpb25hbCB9ID0gZHluYW1pY0dyb3Vwc1twYXJhbV1cblxuICAgICAgLy8gc3VwcG9ydCBzaW5nbGUtbGV2ZWwgY2F0Y2gtYWxsXG4gICAgICAvLyBUT0RPOiBtb3JlIHJvYnVzdCBoYW5kbGluZyBmb3IgdXNlci1lcnJvciAocGFzc2luZyBgL2ApXG4gICAgICBsZXQgcmVwbGFjZWQgPSBgWyR7cmVwZWF0ID8gJy4uLicgOiAnJ30ke3BhcmFtfV1gXG4gICAgICBpZiAob3B0aW9uYWwpIHtcbiAgICAgICAgcmVwbGFjZWQgPSBgJHshdmFsdWUgPyAnLycgOiAnJ31bJHtyZXBsYWNlZH1dYFxuICAgICAgfVxuICAgICAgaWYgKHJlcGVhdCAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlID0gW3ZhbHVlXVxuXG4gICAgICByZXR1cm4gKFxuICAgICAgICAob3B0aW9uYWwgfHwgcGFyYW0gaW4gZHluYW1pY01hdGNoZXMpICYmXG4gICAgICAgIC8vIEludGVycG9sYXRlIGdyb3VwIGludG8gZGF0YSBVUkwgaWYgcHJlc2VudFxuICAgICAgICAoaW50ZXJwb2xhdGVkUm91dGUgPVxuICAgICAgICAgIGludGVycG9sYXRlZFJvdXRlIS5yZXBsYWNlKFxuICAgICAgICAgICAgcmVwbGFjZWQsXG4gICAgICAgICAgICByZXBlYXRcbiAgICAgICAgICAgICAgPyAodmFsdWUgYXMgc3RyaW5nW10pXG4gICAgICAgICAgICAgICAgICAubWFwKFxuICAgICAgICAgICAgICAgICAgICAvLyB0aGVzZSB2YWx1ZXMgc2hvdWxkIGJlIGZ1bGx5IGVuY29kZWQgaW5zdGVhZCBvZiBqdXN0XG4gICAgICAgICAgICAgICAgICAgIC8vIHBhdGggZGVsaW1pdGVyIGVzY2FwZWQgc2luY2UgdGhleSBhcmUgYmVpbmcgaW5zZXJ0ZWRcbiAgICAgICAgICAgICAgICAgICAgLy8gaW50byB0aGUgVVJMIGFuZCB3ZSBleHBlY3QgVVJMIGVuY29kZWQgc2VnbWVudHNcbiAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiBwYXJzaW5nIGR5bmFtaWMgcm91dGUgcGFyYW1zXG4gICAgICAgICAgICAgICAgICAgIChzZWdtZW50KSA9PiBlbmNvZGVVUklDb21wb25lbnQoc2VnbWVudClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIC5qb2luKCcvJylcbiAgICAgICAgICAgICAgOiBlbmNvZGVVUklDb21wb25lbnQodmFsdWUgYXMgc3RyaW5nKVxuICAgICAgICAgICkgfHwgJy8nKVxuICAgICAgKVxuICAgIH0pXG4gICkge1xuICAgIGludGVycG9sYXRlZFJvdXRlID0gJycgLy8gZGlkIG5vdCBzYXRpc2Z5IGFsbCByZXF1aXJlbWVudHNcblxuICAgIC8vIG4uYi4gV2UgaWdub3JlIHRoaXMgZXJyb3IgYmVjYXVzZSB3ZSBoYW5kbGUgd2FybmluZyBmb3IgdGhpcyBjYXNlIGluXG4gICAgLy8gZGV2ZWxvcG1lbnQgaW4gdGhlIGA8TGluaz5gIGNvbXBvbmVudCBkaXJlY3RseS5cbiAgfVxuICByZXR1cm4ge1xuICAgIHBhcmFtcyxcbiAgICByZXN1bHQ6IGludGVycG9sYXRlZFJvdXRlLFxuICB9XG59XG5cbmZ1bmN0aW9uIG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeTogUGFyc2VkVXJsUXVlcnksIHBhcmFtczogc3RyaW5nW10pIHtcbiAgY29uc3QgZmlsdGVyZWRRdWVyeTogUGFyc2VkVXJsUXVlcnkgPSB7fVxuXG4gIE9iamVjdC5rZXlzKHF1ZXJ5KS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICBpZiAoIXBhcmFtcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICBmaWx0ZXJlZFF1ZXJ5W2tleV0gPSBxdWVyeVtrZXldXG4gICAgfVxuICB9KVxuICByZXR1cm4gZmlsdGVyZWRRdWVyeVxufVxuXG4vKipcbiAqIFJlc29sdmVzIGEgZ2l2ZW4gaHlwZXJsaW5rIHdpdGggYSBjZXJ0YWluIHJvdXRlciBzdGF0ZSAoYmFzZVBhdGggbm90IGluY2x1ZGVkKS5cbiAqIFByZXNlcnZlcyBhYnNvbHV0ZSB1cmxzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhyZWYoXG4gIGN1cnJlbnRQYXRoOiBzdHJpbmcsXG4gIGhyZWY6IFVybCxcbiAgcmVzb2x2ZUFzPzogYm9vbGVhblxuKTogc3RyaW5nIHtcbiAgLy8gd2UgdXNlIGEgZHVtbXkgYmFzZSB1cmwgZm9yIHJlbGF0aXZlIHVybHNcbiAgY29uc3QgYmFzZSA9IG5ldyBVUkwoY3VycmVudFBhdGgsICdodHRwOi8vbicpXG4gIGNvbnN0IHVybEFzU3RyaW5nID1cbiAgICB0eXBlb2YgaHJlZiA9PT0gJ3N0cmluZycgPyBocmVmIDogZm9ybWF0V2l0aFZhbGlkYXRpb24oaHJlZilcbiAgLy8gUmV0dXJuIGJlY2F1c2UgaXQgY2Fubm90IGJlIHJvdXRlZCBieSB0aGUgTmV4dC5qcyByb3V0ZXJcbiAgaWYgKCFpc0xvY2FsVVJMKHVybEFzU3RyaW5nKSkge1xuICAgIHJldHVybiAocmVzb2x2ZUFzID8gW3VybEFzU3RyaW5nXSA6IHVybEFzU3RyaW5nKSBhcyBzdHJpbmdcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGZpbmFsVXJsID0gbmV3IFVSTCh1cmxBc1N0cmluZywgYmFzZSlcbiAgICBmaW5hbFVybC5wYXRobmFtZSA9IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKGZpbmFsVXJsLnBhdGhuYW1lKVxuICAgIGxldCBpbnRlcnBvbGF0ZWRBcyA9ICcnXG5cbiAgICBpZiAoXG4gICAgICBpc0R5bmFtaWNSb3V0ZShmaW5hbFVybC5wYXRobmFtZSkgJiZcbiAgICAgIGZpbmFsVXJsLnNlYXJjaFBhcmFtcyAmJlxuICAgICAgcmVzb2x2ZUFzXG4gICAgKSB7XG4gICAgICBjb25zdCBxdWVyeSA9IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkoZmluYWxVcmwuc2VhcmNoUGFyYW1zKVxuXG4gICAgICBjb25zdCB7IHJlc3VsdCwgcGFyYW1zIH0gPSBpbnRlcnBvbGF0ZUFzKFxuICAgICAgICBmaW5hbFVybC5wYXRobmFtZSxcbiAgICAgICAgZmluYWxVcmwucGF0aG5hbWUsXG4gICAgICAgIHF1ZXJ5XG4gICAgICApXG5cbiAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgaW50ZXJwb2xhdGVkQXMgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbih7XG4gICAgICAgICAgcGF0aG5hbWU6IHJlc3VsdCxcbiAgICAgICAgICBoYXNoOiBmaW5hbFVybC5oYXNoLFxuICAgICAgICAgIHF1ZXJ5OiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnksIHBhcmFtcyksXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gaWYgdGhlIG9yaWdpbiBkaWRuJ3QgY2hhbmdlLCBpdCBtZWFucyB3ZSByZWNlaXZlZCBhIHJlbGF0aXZlIGhyZWZcbiAgICBjb25zdCByZXNvbHZlZEhyZWYgPVxuICAgICAgZmluYWxVcmwub3JpZ2luID09PSBiYXNlLm9yaWdpblxuICAgICAgICA/IGZpbmFsVXJsLmhyZWYuc2xpY2UoZmluYWxVcmwub3JpZ2luLmxlbmd0aClcbiAgICAgICAgOiBmaW5hbFVybC5ocmVmXG5cbiAgICByZXR1cm4gKHJlc29sdmVBc1xuICAgICAgPyBbcmVzb2x2ZWRIcmVmLCBpbnRlcnBvbGF0ZWRBcyB8fCByZXNvbHZlZEhyZWZdXG4gICAgICA6IHJlc29sdmVkSHJlZikgYXMgc3RyaW5nXG4gIH0gY2F0Y2ggKF8pIHtcbiAgICByZXR1cm4gKHJlc29sdmVBcyA/IFt1cmxBc1N0cmluZ10gOiB1cmxBc1N0cmluZykgYXMgc3RyaW5nXG4gIH1cbn1cblxuZnVuY3Rpb24gc3RyaXBPcmlnaW4odXJsOiBzdHJpbmcpIHtcbiAgY29uc3Qgb3JpZ2luID0gZ2V0TG9jYXRpb25PcmlnaW4oKVxuXG4gIHJldHVybiB1cmwuc3RhcnRzV2l0aChvcmlnaW4pID8gdXJsLnN1YnN0cmluZyhvcmlnaW4ubGVuZ3RoKSA6IHVybFxufVxuXG5mdW5jdGlvbiBwcmVwYXJlVXJsQXMocm91dGVyOiBOZXh0Um91dGVyLCB1cmw6IFVybCwgYXM/OiBVcmwpIHtcbiAgLy8gSWYgdXJsIGFuZCBhcyBwcm92aWRlZCBhcyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24sXG4gIC8vIHdlJ2xsIGZvcm1hdCB0aGVtIGludG8gdGhlIHN0cmluZyB2ZXJzaW9uIGhlcmUuXG4gIGxldCBbcmVzb2x2ZWRIcmVmLCByZXNvbHZlZEFzXSA9IHJlc29sdmVIcmVmKHJvdXRlci5wYXRobmFtZSwgdXJsLCB0cnVlKVxuICBjb25zdCBvcmlnaW4gPSBnZXRMb2NhdGlvbk9yaWdpbigpXG4gIGNvbnN0IGhyZWZIYWRPcmlnaW4gPSByZXNvbHZlZEhyZWYuc3RhcnRzV2l0aChvcmlnaW4pXG4gIGNvbnN0IGFzSGFkT3JpZ2luID0gcmVzb2x2ZWRBcyAmJiByZXNvbHZlZEFzLnN0YXJ0c1dpdGgob3JpZ2luKVxuXG4gIHJlc29sdmVkSHJlZiA9IHN0cmlwT3JpZ2luKHJlc29sdmVkSHJlZilcbiAgcmVzb2x2ZWRBcyA9IHJlc29sdmVkQXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlZEFzKSA6IHJlc29sdmVkQXNcblxuICBjb25zdCBwcmVwYXJlZFVybCA9IGhyZWZIYWRPcmlnaW4gPyByZXNvbHZlZEhyZWYgOiBhZGRCYXNlUGF0aChyZXNvbHZlZEhyZWYpXG4gIGNvbnN0IHByZXBhcmVkQXMgPSBhc1xuICAgID8gc3RyaXBPcmlnaW4ocmVzb2x2ZUhyZWYocm91dGVyLnBhdGhuYW1lLCBhcykpXG4gICAgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZlxuXG4gIHJldHVybiB7XG4gICAgdXJsOiBwcmVwYXJlZFVybCxcbiAgICBhczogYXNIYWRPcmlnaW4gPyBwcmVwYXJlZEFzIDogYWRkQmFzZVBhdGgocHJlcGFyZWRBcyksXG4gIH1cbn1cblxuZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXRobmFtZTogc3RyaW5nLCBwYWdlczogc3RyaW5nW10pIHtcbiAgY29uc3QgY2xlYW5QYXRobmFtZSA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKGRlbm9ybWFsaXplUGFnZVBhdGgocGF0aG5hbWUhKSlcblxuICBpZiAoY2xlYW5QYXRobmFtZSA9PT0gJy80MDQnIHx8IGNsZWFuUGF0aG5hbWUgPT09ICcvX2Vycm9yJykge1xuICAgIHJldHVybiBwYXRobmFtZVxuICB9XG5cbiAgLy8gaGFuZGxlIHJlc29sdmluZyBocmVmIGZvciBkeW5hbWljIHJvdXRlc1xuICBpZiAoIXBhZ2VzLmluY2x1ZGVzKGNsZWFuUGF0aG5hbWUhKSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICBwYWdlcy5zb21lKChwYWdlKSA9PiB7XG4gICAgICBpZiAoaXNEeW5hbWljUm91dGUocGFnZSkgJiYgZ2V0Um91dGVSZWdleChwYWdlKS5yZS50ZXN0KGNsZWFuUGF0aG5hbWUhKSkge1xuICAgICAgICBwYXRobmFtZSA9IHBhZ2VcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH1cbiAgICB9KVxuICB9XG4gIHJldHVybiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSlcbn1cblxuZXhwb3J0IHR5cGUgQmFzZVJvdXRlciA9IHtcbiAgcm91dGU6IHN0cmluZ1xuICBwYXRobmFtZTogc3RyaW5nXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICBhc1BhdGg6IHN0cmluZ1xuICBiYXNlUGF0aDogc3RyaW5nXG4gIGxvY2FsZT86IHN0cmluZ1xuICBsb2NhbGVzPzogc3RyaW5nW11cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xuICBkb21haW5Mb2NhbGVzPzogRG9tYWluTG9jYWxlc1xuICBpc0xvY2FsZURvbWFpbjogYm9vbGVhblxufVxuXG5leHBvcnQgdHlwZSBOZXh0Um91dGVyID0gQmFzZVJvdXRlciAmXG4gIFBpY2s8XG4gICAgUm91dGVyLFxuICAgIHwgJ3B1c2gnXG4gICAgfCAncmVwbGFjZSdcbiAgICB8ICdyZWxvYWQnXG4gICAgfCAnYmFjaydcbiAgICB8ICdwcmVmZXRjaCdcbiAgICB8ICdiZWZvcmVQb3BTdGF0ZSdcbiAgICB8ICdldmVudHMnXG4gICAgfCAnaXNGYWxsYmFjaydcbiAgICB8ICdpc1JlYWR5J1xuICAgIHwgJ2lzUHJldmlldydcbiAgPlxuXG5leHBvcnQgdHlwZSBQcmVmZXRjaE9wdGlvbnMgPSB7XG4gIHByaW9yaXR5PzogYm9vbGVhblxuICBsb2NhbGU/OiBzdHJpbmcgfCBmYWxzZVxufVxuXG5leHBvcnQgdHlwZSBQcml2YXRlUm91dGVJbmZvID1cbiAgfCAoT21pdDxDb21wbGV0ZVByaXZhdGVSb3V0ZUluZm8sICdzdHlsZVNoZWV0cyc+ICYgeyBpbml0aWFsOiB0cnVlIH0pXG4gIHwgQ29tcGxldGVQcml2YXRlUm91dGVJbmZvXG5cbmV4cG9ydCB0eXBlIENvbXBsZXRlUHJpdmF0ZVJvdXRlSW5mbyA9IHtcbiAgQ29tcG9uZW50OiBDb21wb25lbnRUeXBlXG4gIHN0eWxlU2hlZXRzOiBTdHlsZVNoZWV0VHVwbGVbXVxuICBfX05fU1NHPzogYm9vbGVhblxuICBfX05fU1NQPzogYm9vbGVhblxuICBwcm9wcz86IFJlY29yZDxzdHJpbmcsIGFueT5cbiAgZXJyPzogRXJyb3JcbiAgZXJyb3I/OiBhbnlcbn1cblxuZXhwb3J0IHR5cGUgQXBwUHJvcHMgPSBQaWNrPENvbXBsZXRlUHJpdmF0ZVJvdXRlSW5mbywgJ0NvbXBvbmVudCcgfCAnZXJyJz4gJiB7XG4gIHJvdXRlcjogUm91dGVyXG59ICYgUmVjb3JkPHN0cmluZywgYW55PlxuZXhwb3J0IHR5cGUgQXBwQ29tcG9uZW50ID0gQ29tcG9uZW50VHlwZTxBcHBQcm9wcz5cblxudHlwZSBTdWJzY3JpcHRpb24gPSAoXG4gIGRhdGE6IFByaXZhdGVSb3V0ZUluZm8sXG4gIEFwcDogQXBwQ29tcG9uZW50LFxuICByZXNldFNjcm9sbDogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9IHwgbnVsbFxuKSA9PiBQcm9taXNlPHZvaWQ+XG5cbnR5cGUgQmVmb3JlUG9wU3RhdGVDYWxsYmFjayA9IChzdGF0ZTogTmV4dEhpc3RvcnlTdGF0ZSkgPT4gYm9vbGVhblxuXG50eXBlIENvbXBvbmVudExvYWRDYW5jZWwgPSAoKCkgPT4gdm9pZCkgfCBudWxsXG5cbnR5cGUgSGlzdG9yeU1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnIHwgJ3B1c2hTdGF0ZSdcblxuY29uc3QgbWFudWFsU2Nyb2xsUmVzdG9yYXRpb24gPVxuICBwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OICYmXG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICdzY3JvbGxSZXN0b3JhdGlvbicgaW4gd2luZG93Lmhpc3RvcnkgJiZcbiAgISEoZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICBsZXQgdiA9ICdfX25leHQnXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VxdWVuY2VzXG4gICAgICByZXR1cm4gc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSh2LCB2KSwgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSh2KSwgdHJ1ZVxuICAgIH0gY2F0Y2ggKG4pIHt9XG4gIH0pKClcblxuY29uc3QgU1NHX0RBVEFfTk9UX0ZPVU5EID0gU3ltYm9sKCdTU0dfREFUQV9OT1RfRk9VTkQnKVxuXG5mdW5jdGlvbiBmZXRjaFJldHJ5KHVybDogc3RyaW5nLCBhdHRlbXB0czogbnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcbiAgcmV0dXJuIGZldGNoKHVybCwge1xuICAgIC8vIENvb2tpZXMgYXJlIHJlcXVpcmVkIHRvIGJlIHByZXNlbnQgZm9yIE5leHQuanMnIFNTRyBcIlByZXZpZXcgTW9kZVwiLlxuICAgIC8vIENvb2tpZXMgbWF5IGFsc28gYmUgcmVxdWlyZWQgZm9yIGBnZXRTZXJ2ZXJTaWRlUHJvcHNgLlxuICAgIC8vXG4gICAgLy8gPiBgZmV0Y2hgIHdvbuKAmXQgc2VuZCBjb29raWVzLCB1bmxlc3MgeW91IHNldCB0aGUgY3JlZGVudGlhbHMgaW5pdFxuICAgIC8vID4gb3B0aW9uLlxuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9GZXRjaF9BUEkvVXNpbmdfRmV0Y2hcbiAgICAvL1xuICAgIC8vID4gRm9yIG1heGltdW0gYnJvd3NlciBjb21wYXRpYmlsaXR5IHdoZW4gaXQgY29tZXMgdG8gc2VuZGluZyAmXG4gICAgLy8gPiByZWNlaXZpbmcgY29va2llcywgYWx3YXlzIHN1cHBseSB0aGUgYGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nYFxuICAgIC8vID4gb3B0aW9uIGluc3RlYWQgb2YgcmVseWluZyBvbiB0aGUgZGVmYXVsdC5cbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2ZldGNoI2NhdmVhdHNcbiAgICBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJyxcbiAgfSkudGhlbigocmVzKSA9PiB7XG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGlmIChhdHRlbXB0cyA+IDEgJiYgcmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgICAgcmV0dXJuIGZldGNoUmV0cnkodXJsLCBhdHRlbXB0cyAtIDEpXG4gICAgICB9XG4gICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICAgIHJldHVybiByZXMuanNvbigpLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgICBpZiAoZGF0YS5ub3RGb3VuZCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgbm90Rm91bmQ6IFNTR19EQVRBX05PVF9GT1VORCB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYClcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYClcbiAgICB9XG4gICAgcmV0dXJuIHJlcy5qc29uKClcbiAgfSlcbn1cblxuZnVuY3Rpb24gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZjogc3RyaW5nLCBpc1NlcnZlclJlbmRlcjogYm9vbGVhbikge1xuICByZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIgPyAzIDogMSkuY2F0Y2goKGVycjogRXJyb3IpID0+IHtcbiAgICAvLyBXZSBzaG91bGQgb25seSB0cmlnZ2VyIGEgc2VydmVyLXNpZGUgdHJhbnNpdGlvbiBpZiB0aGlzIHdhcyBjYXVzZWRcbiAgICAvLyBvbiBhIGNsaWVudC1zaWRlIHRyYW5zaXRpb24uIE90aGVyd2lzZSwgd2UnZCBnZXQgaW50byBhbiBpbmZpbml0ZVxuICAgIC8vIGxvb3AuXG5cbiAgICBpZiAoIWlzU2VydmVyUmVuZGVyKSB7XG4gICAgICBtYXJrQXNzZXRFcnJvcihlcnIpXG4gICAgfVxuICAgIHRocm93IGVyclxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSb3V0ZXIgaW1wbGVtZW50cyBCYXNlUm91dGVyIHtcbiAgcm91dGU6IHN0cmluZ1xuICBwYXRobmFtZTogc3RyaW5nXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICBhc1BhdGg6IHN0cmluZ1xuICBiYXNlUGF0aDogc3RyaW5nXG5cbiAgLyoqXG4gICAqIE1hcCBvZiBhbGwgY29tcG9uZW50cyBsb2FkZWQgaW4gYFJvdXRlcmBcbiAgICovXG4gIGNvbXBvbmVudHM6IHsgW3BhdGhuYW1lOiBzdHJpbmddOiBQcml2YXRlUm91dGVJbmZvIH1cbiAgLy8gU3RhdGljIERhdGEgQ2FjaGVcbiAgc2RjOiB7IFthc1BhdGg6IHN0cmluZ106IG9iamVjdCB9ID0ge31cbiAgLy8gSW4tZmxpZ2h0IFNlcnZlciBEYXRhIFJlcXVlc3RzLCBmb3IgZGVkdXBpbmdcbiAgc2RyOiB7IFthc1BhdGg6IHN0cmluZ106IFByb21pc2U8b2JqZWN0PiB9ID0ge31cblxuICBzdWI6IFN1YnNjcmlwdGlvblxuICBjbGM6IENvbXBvbmVudExvYWRDYW5jZWxcbiAgcGFnZUxvYWRlcjogYW55XG4gIF9icHM6IEJlZm9yZVBvcFN0YXRlQ2FsbGJhY2sgfCB1bmRlZmluZWRcbiAgZXZlbnRzOiBNaXR0RW1pdHRlclxuICBfd3JhcEFwcDogKEFwcDogQXBwQ29tcG9uZW50KSA9PiBhbnlcbiAgaXNTc3I6IGJvb2xlYW5cbiAgaXNGYWxsYmFjazogYm9vbGVhblxuICBfaW5GbGlnaHRSb3V0ZT86IHN0cmluZ1xuICBfc2hhbGxvdz86IGJvb2xlYW5cbiAgbG9jYWxlPzogc3RyaW5nXG4gIGxvY2FsZXM/OiBzdHJpbmdbXVxuICBkZWZhdWx0TG9jYWxlPzogc3RyaW5nXG4gIGRvbWFpbkxvY2FsZXM/OiBEb21haW5Mb2NhbGVzXG4gIGlzUmVhZHk6IGJvb2xlYW5cbiAgaXNQcmV2aWV3OiBib29sZWFuXG4gIGlzTG9jYWxlRG9tYWluOiBib29sZWFuXG5cbiAgcHJpdmF0ZSBfaWR4OiBudW1iZXIgPSAwXG5cbiAgc3RhdGljIGV2ZW50czogTWl0dEVtaXR0ZXIgPSBtaXR0KClcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwYXRobmFtZTogc3RyaW5nLFxuICAgIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeSxcbiAgICBhczogc3RyaW5nLFxuICAgIHtcbiAgICAgIGluaXRpYWxQcm9wcyxcbiAgICAgIHBhZ2VMb2FkZXIsXG4gICAgICBBcHAsXG4gICAgICB3cmFwQXBwLFxuICAgICAgQ29tcG9uZW50LFxuICAgICAgZXJyLFxuICAgICAgc3Vic2NyaXB0aW9uLFxuICAgICAgaXNGYWxsYmFjayxcbiAgICAgIGxvY2FsZSxcbiAgICAgIGxvY2FsZXMsXG4gICAgICBkZWZhdWx0TG9jYWxlLFxuICAgICAgZG9tYWluTG9jYWxlcyxcbiAgICAgIGlzUHJldmlldyxcbiAgICB9OiB7XG4gICAgICBzdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvblxuICAgICAgaW5pdGlhbFByb3BzOiBhbnlcbiAgICAgIHBhZ2VMb2FkZXI6IGFueVxuICAgICAgQ29tcG9uZW50OiBDb21wb25lbnRUeXBlXG4gICAgICBBcHA6IEFwcENvbXBvbmVudFxuICAgICAgd3JhcEFwcDogKEFwcDogQXBwQ29tcG9uZW50KSA9PiBhbnlcbiAgICAgIGVycj86IEVycm9yXG4gICAgICBpc0ZhbGxiYWNrOiBib29sZWFuXG4gICAgICBsb2NhbGU/OiBzdHJpbmdcbiAgICAgIGxvY2FsZXM/OiBzdHJpbmdbXVxuICAgICAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xuICAgICAgZG9tYWluTG9jYWxlcz86IERvbWFpbkxvY2FsZXNcbiAgICAgIGlzUHJldmlldz86IGJvb2xlYW5cbiAgICB9XG4gICkge1xuICAgIC8vIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgY29tcG9uZW50IGtleVxuICAgIHRoaXMucm91dGUgPSByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSlcblxuICAgIC8vIHNldCB1cCB0aGUgY29tcG9uZW50IGNhY2hlIChieSByb3V0ZSBrZXlzKVxuICAgIHRoaXMuY29tcG9uZW50cyA9IHt9XG4gICAgLy8gV2Ugc2hvdWxkIG5vdCBrZWVwIHRoZSBjYWNoZSwgaWYgdGhlcmUncyBhbiBlcnJvclxuICAgIC8vIE90aGVyd2lzZSwgdGhpcyBjYXVzZSBpc3N1ZXMgd2hlbiB3aGVuIGdvaW5nIGJhY2sgYW5kXG4gICAgLy8gY29tZSBhZ2FpbiB0byB0aGUgZXJyb3JlZCBwYWdlLlxuICAgIGlmIChwYXRobmFtZSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICB0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0gPSB7XG4gICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgaW5pdGlhbDogdHJ1ZSxcbiAgICAgICAgcHJvcHM6IGluaXRpYWxQcm9wcyxcbiAgICAgICAgZXJyLFxuICAgICAgICBfX05fU1NHOiBpbml0aWFsUHJvcHMgJiYgaW5pdGlhbFByb3BzLl9fTl9TU0csXG4gICAgICAgIF9fTl9TU1A6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTUCxcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10gPSB7XG4gICAgICBDb21wb25lbnQ6IEFwcCBhcyBDb21wb25lbnRUeXBlLFxuICAgICAgc3R5bGVTaGVldHM6IFtcbiAgICAgICAgLyogL19hcHAgZG9lcyBub3QgbmVlZCBpdHMgc3R5bGVzaGVldHMgbWFuYWdlZCAqL1xuICAgICAgXSxcbiAgICB9XG5cbiAgICAvLyBCYWNrd2FyZHMgY29tcGF0IGZvciBSb3V0ZXIucm91dGVyLmV2ZW50c1xuICAgIC8vIFRPRE86IFNob3VsZCBiZSByZW1vdmUgdGhlIGZvbGxvd2luZyBtYWpvciB2ZXJzaW9uIGFzIGl0IHdhcyBuZXZlciBkb2N1bWVudGVkXG4gICAgdGhpcy5ldmVudHMgPSBSb3V0ZXIuZXZlbnRzXG5cbiAgICB0aGlzLnBhZ2VMb2FkZXIgPSBwYWdlTG9hZGVyXG4gICAgdGhpcy5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5XG4gICAgLy8gaWYgYXV0byBwcmVyZW5kZXJlZCBhbmQgZHluYW1pYyByb3V0ZSB3YWl0IHRvIHVwZGF0ZSBhc1BhdGhcbiAgICAvLyB1bnRpbCBhZnRlciBtb3VudCB0byBwcmV2ZW50IGh5ZHJhdGlvbiBtaXNtYXRjaFxuICAgIGNvbnN0IGF1dG9FeHBvcnREeW5hbWljID1cbiAgICAgIGlzRHluYW1pY1JvdXRlKHBhdGhuYW1lKSAmJiBzZWxmLl9fTkVYVF9EQVRBX18uYXV0b0V4cG9ydFxuXG4gICAgdGhpcy5hc1BhdGggPSBhdXRvRXhwb3J0RHluYW1pYyA/IHBhdGhuYW1lIDogYXNcbiAgICB0aGlzLmJhc2VQYXRoID0gYmFzZVBhdGhcbiAgICB0aGlzLnN1YiA9IHN1YnNjcmlwdGlvblxuICAgIHRoaXMuY2xjID0gbnVsbFxuICAgIHRoaXMuX3dyYXBBcHAgPSB3cmFwQXBwXG4gICAgLy8gbWFrZSBzdXJlIHRvIGlnbm9yZSBleHRyYSBwb3BTdGF0ZSBpbiBzYWZhcmkgb24gbmF2aWdhdGluZ1xuICAgIC8vIGJhY2sgZnJvbSBleHRlcm5hbCBzaXRlXG4gICAgdGhpcy5pc1NzciA9IHRydWVcblxuICAgIHRoaXMuaXNGYWxsYmFjayA9IGlzRmFsbGJhY2tcblxuICAgIHRoaXMuaXNSZWFkeSA9ICEhKFxuICAgICAgc2VsZi5fX05FWFRfREFUQV9fLmdzc3AgfHxcbiAgICAgIHNlbGYuX19ORVhUX0RBVEFfXy5naXAgfHxcbiAgICAgICghYXV0b0V4cG9ydER5bmFtaWMgJiYgIXNlbGYubG9jYXRpb24uc2VhcmNoKVxuICAgIClcbiAgICB0aGlzLmlzUHJldmlldyA9ICEhaXNQcmV2aWV3XG4gICAgdGhpcy5pc0xvY2FsZURvbWFpbiA9IGZhbHNlXG5cbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVcbiAgICAgIHRoaXMubG9jYWxlcyA9IGxvY2FsZXNcbiAgICAgIHRoaXMuZGVmYXVsdExvY2FsZSA9IGRlZmF1bHRMb2NhbGVcbiAgICAgIHRoaXMuZG9tYWluTG9jYWxlcyA9IGRvbWFpbkxvY2FsZXNcbiAgICAgIHRoaXMuaXNMb2NhbGVEb21haW4gPSAhIWRldGVjdERvbWFpbkxvY2FsZShcbiAgICAgICAgZG9tYWluTG9jYWxlcyxcbiAgICAgICAgc2VsZi5sb2NhdGlvbi5ob3N0bmFtZVxuICAgICAgKVxuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgLy8gbWFrZSBzdXJlIFwiYXNcIiBkb2Vzbid0IHN0YXJ0IHdpdGggZG91YmxlIHNsYXNoZXMgb3IgZWxzZSBpdCBjYW5cbiAgICAgIC8vIHRocm93IGFuIGVycm9yIGFzIGl0J3MgY29uc2lkZXJlZCBpbnZhbGlkXG4gICAgICBpZiAoYXMuc3Vic3RyKDAsIDIpICE9PSAnLy8nKSB7XG4gICAgICAgIC8vIGluIG9yZGVyIGZvciBgZS5zdGF0ZWAgdG8gd29yayBvbiB0aGUgYG9ucG9wc3RhdGVgIGV2ZW50XG4gICAgICAgIC8vIHdlIGhhdmUgdG8gcmVnaXN0ZXIgdGhlIGluaXRpYWwgcm91dGUgdXBvbiBpbml0aWFsaXphdGlvblxuICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKFxuICAgICAgICAgICdyZXBsYWNlU3RhdGUnLFxuICAgICAgICAgIGZvcm1hdFdpdGhWYWxpZGF0aW9uKHsgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lKSwgcXVlcnkgfSksXG4gICAgICAgICAgZ2V0VVJMKCksXG4gICAgICAgICAgeyBsb2NhbGUgfVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdwb3BzdGF0ZScsIHRoaXMub25Qb3BTdGF0ZSlcblxuICAgICAgLy8gZW5hYmxlIGN1c3RvbSBzY3JvbGwgcmVzdG9yYXRpb24gaGFuZGxpbmcgd2hlbiBhdmFpbGFibGVcbiAgICAgIC8vIG90aGVyd2lzZSBmYWxsYmFjayB0byBicm93c2VyJ3MgZGVmYXVsdCBoYW5kbGluZ1xuICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSAnbWFudWFsJ1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgb25Qb3BTdGF0ZSA9IChlOiBQb3BTdGF0ZUV2ZW50KTogdm9pZCA9PiB7XG4gICAgY29uc3Qgc3RhdGUgPSBlLnN0YXRlIGFzIEhpc3RvcnlTdGF0ZVxuXG4gICAgaWYgKCFzdGF0ZSkge1xuICAgICAgLy8gV2UgZ2V0IHN0YXRlIGFzIHVuZGVmaW5lZCBmb3IgdHdvIHJlYXNvbnMuXG4gICAgICAvLyAgMS4gV2l0aCBvbGRlciBzYWZhcmkgKDwgOCkgYW5kIG9sZGVyIGNocm9tZSAoPCAzNClcbiAgICAgIC8vICAyLiBXaGVuIHRoZSBVUkwgY2hhbmdlZCB3aXRoICNcbiAgICAgIC8vXG4gICAgICAvLyBJbiB0aGUgYm90aCBjYXNlcywgd2UgZG9uJ3QgbmVlZCB0byBwcm9jZWVkIGFuZCBjaGFuZ2UgdGhlIHJvdXRlLlxuICAgICAgLy8gKGFzIGl0J3MgYWxyZWFkeSBjaGFuZ2VkKVxuICAgICAgLy8gQnV0IHdlIGNhbiBzaW1wbHkgcmVwbGFjZSB0aGUgc3RhdGUgd2l0aCB0aGUgbmV3IGNoYW5nZXMuXG4gICAgICAvLyBBY3R1YWxseSwgZm9yICgxKSB3ZSBkb24ndCBuZWVkIHRvIG5vdGhpbmcuIEJ1dCBpdCdzIGhhcmQgdG8gZGV0ZWN0IHRoYXQgZXZlbnQuXG4gICAgICAvLyBTbywgZG9pbmcgdGhlIGZvbGxvd2luZyBmb3IgKDEpIGRvZXMgbm8gaGFybS5cbiAgICAgIGNvbnN0IHsgcGF0aG5hbWUsIHF1ZXJ5IH0gPSB0aGlzXG4gICAgICB0aGlzLmNoYW5nZVN0YXRlKFxuICAgICAgICAncmVwbGFjZVN0YXRlJyxcbiAgICAgICAgZm9ybWF0V2l0aFZhbGlkYXRpb24oeyBwYXRobmFtZTogYWRkQmFzZVBhdGgocGF0aG5hbWUpLCBxdWVyeSB9KSxcbiAgICAgICAgZ2V0VVJMKClcbiAgICAgIClcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGlmICghc3RhdGUuX19OKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBsZXQgZm9yY2VkU2Nyb2xsOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0gfCB1bmRlZmluZWRcbiAgICBjb25zdCB7IHVybCwgYXMsIG9wdGlvbnMsIGlkeCB9ID0gc3RhdGVcbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgIGlmICh0aGlzLl9pZHggIT09IGlkeCkge1xuICAgICAgICAgIC8vIFNuYXBzaG90IGN1cnJlbnQgc2Nyb2xsIHBvc2l0aW9uOlxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAgICAgICAnX19uZXh0X3Njcm9sbF8nICsgdGhpcy5faWR4LFxuICAgICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHg6IHNlbGYucGFnZVhPZmZzZXQsIHk6IHNlbGYucGFnZVlPZmZzZXQgfSlcbiAgICAgICAgICAgIClcbiAgICAgICAgICB9IGNhdGNoIHt9XG5cbiAgICAgICAgICAvLyBSZXN0b3JlIG9sZCBzY3JvbGwgcG9zaXRpb246XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHYgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdfX25leHRfc2Nyb2xsXycgKyBpZHgpXG4gICAgICAgICAgICBmb3JjZWRTY3JvbGwgPSBKU09OLnBhcnNlKHYhKVxuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgZm9yY2VkU2Nyb2xsID0geyB4OiAwLCB5OiAwIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5faWR4ID0gaWR4XG5cbiAgICBjb25zdCB7IHBhdGhuYW1lIH0gPSBwYXJzZVJlbGF0aXZlVXJsKHVybClcblxuICAgIC8vIE1ha2Ugc3VyZSB3ZSBkb24ndCByZS1yZW5kZXIgb24gaW5pdGlhbCBsb2FkLFxuICAgIC8vIGNhbiBiZSBjYXVzZWQgYnkgbmF2aWdhdGluZyBiYWNrIGZyb20gYW4gZXh0ZXJuYWwgc2l0ZVxuICAgIGlmICh0aGlzLmlzU3NyICYmIGFzID09PSB0aGlzLmFzUGF0aCAmJiBwYXRobmFtZSA9PT0gdGhpcy5wYXRobmFtZSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIGRvd25zdHJlYW0gYXBwbGljYXRpb24gcmV0dXJucyBmYWxzeSwgcmV0dXJuLlxuICAgIC8vIFRoZXkgd2lsbCB0aGVuIGJlIHJlc3BvbnNpYmxlIGZvciBoYW5kbGluZyB0aGUgZXZlbnQuXG4gICAgaWYgKHRoaXMuX2JwcyAmJiAhdGhpcy5fYnBzKHN0YXRlKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgdGhpcy5jaGFuZ2UoXG4gICAgICAncmVwbGFjZVN0YXRlJyxcbiAgICAgIHVybCxcbiAgICAgIGFzLFxuICAgICAgT2JqZWN0LmFzc2lnbjx7fSwgVHJhbnNpdGlvbk9wdGlvbnMsIFRyYW5zaXRpb25PcHRpb25zPih7fSwgb3B0aW9ucywge1xuICAgICAgICBzaGFsbG93OiBvcHRpb25zLnNoYWxsb3cgJiYgdGhpcy5fc2hhbGxvdyxcbiAgICAgICAgbG9jYWxlOiBvcHRpb25zLmxvY2FsZSB8fCB0aGlzLmRlZmF1bHRMb2NhbGUsXG4gICAgICB9KSxcbiAgICAgIGZvcmNlZFNjcm9sbFxuICAgIClcbiAgfVxuXG4gIHJlbG9hZCgpOiB2b2lkIHtcbiAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKClcbiAgfVxuXG4gIC8qKlxuICAgKiBHbyBiYWNrIGluIGhpc3RvcnlcbiAgICovXG4gIGJhY2soKSB7XG4gICAgd2luZG93Lmhpc3RvcnkuYmFjaygpXG4gIH1cblxuICAvKipcbiAgICogUGVyZm9ybXMgYSBgcHVzaFN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovXG4gIHB1c2godXJsOiBVcmwsIGFzPzogVXJsLCBvcHRpb25zOiBUcmFuc2l0aW9uT3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgIC8vIFRPRE86IHJlbW92ZSBpbiB0aGUgZnV0dXJlIHdoZW4gd2UgdXBkYXRlIGhpc3RvcnkgYmVmb3JlIHJvdXRlIGNoYW5nZVxuICAgICAgLy8gaXMgY29tcGxldGUsIGFzIHRoZSBwb3BzdGF0ZSBldmVudCBzaG91bGQgaGFuZGxlIHRoaXMgY2FwdHVyZS5cbiAgICAgIGlmIChtYW51YWxTY3JvbGxSZXN0b3JhdGlvbikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIC8vIFNuYXBzaG90IHNjcm9sbCBwb3NpdGlvbiByaWdodCBiZWZvcmUgbmF2aWdhdGluZyB0byBhIG5ldyBwYWdlOlxuICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICAgICAnX19uZXh0X3Njcm9sbF8nICsgdGhpcy5faWR4LFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyB4OiBzZWxmLnBhZ2VYT2Zmc2V0LCB5OiBzZWxmLnBhZ2VZT2Zmc2V0IH0pXG4gICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIHt9XG4gICAgICB9XG4gICAgfVxuICAgIDsoeyB1cmwsIGFzIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpXG4gICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdwdXNoU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKVxuICB9XG5cbiAgLyoqXG4gICAqIFBlcmZvcm1zIGEgYHJlcGxhY2VTdGF0ZWAgd2l0aCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHVybCBvZiB0aGUgcm91dGVcbiAgICogQHBhcmFtIGFzIG1hc2tzIGB1cmxgIGZvciB0aGUgYnJvd3NlclxuICAgKiBAcGFyYW0gb3B0aW9ucyBvYmplY3QgeW91IGNhbiBkZWZpbmUgYHNoYWxsb3dgIGFuZCBvdGhlciBvcHRpb25zXG4gICAqL1xuICByZXBsYWNlKHVybDogVXJsLCBhcz86IFVybCwgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnMgPSB7fSkge1xuICAgIDsoeyB1cmwsIGFzIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpXG4gICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdyZXBsYWNlU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjaGFuZ2UoXG4gICAgbWV0aG9kOiBIaXN0b3J5TWV0aG9kLFxuICAgIHVybDogc3RyaW5nLFxuICAgIGFzOiBzdHJpbmcsXG4gICAgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnMsXG4gICAgZm9yY2VkU2Nyb2xsPzogeyB4OiBudW1iZXI7IHk6IG51bWJlciB9XG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGlmICghaXNMb2NhbFVSTCh1cmwpKSB7XG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHVybFxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgLy8gZm9yIHN0YXRpYyBwYWdlcyB3aXRoIHF1ZXJ5IHBhcmFtcyBpbiB0aGUgVVJMIHdlIGRlbGF5XG4gICAgLy8gbWFya2luZyB0aGUgcm91dGVyIHJlYWR5IHVudGlsIGFmdGVyIHRoZSBxdWVyeSBpcyB1cGRhdGVkXG4gICAgaWYgKChvcHRpb25zIGFzIGFueSkuX2gpIHtcbiAgICAgIHRoaXMuaXNSZWFkeSA9IHRydWVcbiAgICB9XG5cbiAgICAvLyBEZWZhdWx0IHRvIHNjcm9sbCByZXNldCBiZWhhdmlvciB1bmxlc3MgZXhwbGljaXRseSBzcGVjaWZpZWQgdG8gYmVcbiAgICAvLyBgZmFsc2VgISBUaGlzIG1ha2VzIHRoZSBiZWhhdmlvciBiZXR3ZWVuIHVzaW5nIGBSb3V0ZXIjcHVzaGAgYW5kIGFcbiAgICAvLyBgPExpbmsgLz5gIGNvbnNpc3RlbnQuXG4gICAgb3B0aW9ucy5zY3JvbGwgPSAhIShvcHRpb25zLnNjcm9sbCA/PyB0cnVlKVxuXG4gICAgbGV0IGxvY2FsZUNoYW5nZSA9IG9wdGlvbnMubG9jYWxlICE9PSB0aGlzLmxvY2FsZVxuXG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgIHRoaXMubG9jYWxlID1cbiAgICAgICAgb3B0aW9ucy5sb2NhbGUgPT09IGZhbHNlXG4gICAgICAgICAgPyB0aGlzLmRlZmF1bHRMb2NhbGVcbiAgICAgICAgICA6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMubG9jYWxlXG5cbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIG9wdGlvbnMubG9jYWxlID0gdGhpcy5sb2NhbGVcbiAgICAgIH1cblxuICAgICAgY29uc3QgcGFyc2VkQXMgPSBwYXJzZVJlbGF0aXZlVXJsKGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzKVxuICAgICAgY29uc3QgbG9jYWxlUGF0aFJlc3VsdCA9IG5vcm1hbGl6ZUxvY2FsZVBhdGgoXG4gICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lLFxuICAgICAgICB0aGlzLmxvY2FsZXNcbiAgICAgIClcblxuICAgICAgaWYgKGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUpIHtcbiAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlXG4gICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGFyc2VkQXMucGF0aG5hbWUpXG4gICAgICAgIGFzID0gZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkQXMpXG4gICAgICAgIHVybCA9IGFkZEJhc2VQYXRoKFxuICAgICAgICAgIG5vcm1hbGl6ZUxvY2FsZVBhdGgoXG4gICAgICAgICAgICBoYXNCYXNlUGF0aCh1cmwpID8gZGVsQmFzZVBhdGgodXJsKSA6IHVybCxcbiAgICAgICAgICAgIHRoaXMubG9jYWxlc1xuICAgICAgICAgICkucGF0aG5hbWVcbiAgICAgICAgKVxuICAgICAgfVxuICAgICAgbGV0IGRpZE5hdmlnYXRlID0gZmFsc2VcblxuICAgICAgLy8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAvLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIC8vIGlmIHRoZSBsb2NhbGUgaXNuJ3QgY29uZmlndXJlZCBoYXJkIG5hdmlnYXRlIHRvIHNob3cgNDA0IHBhZ2VcbiAgICAgICAgaWYgKCF0aGlzLmxvY2FsZXM/LmluY2x1ZGVzKHRoaXMubG9jYWxlISkpIHtcbiAgICAgICAgICBwYXJzZWRBcy5wYXRobmFtZSA9IGFkZExvY2FsZShwYXJzZWRBcy5wYXRobmFtZSwgdGhpcy5sb2NhbGUpXG4gICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWRBcylcbiAgICAgICAgICAvLyB0aGlzIHdhcyBwcmV2aW91c2x5IGEgcmV0dXJuIGJ1dCB3YXMgcmVtb3ZlZCBpbiBmYXZvclxuICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgZGlkTmF2aWdhdGUgPSB0cnVlXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgZGV0ZWN0ZWREb21haW4gPSBkZXRlY3REb21haW5Mb2NhbGUoXG4gICAgICAgIHRoaXMuZG9tYWluTG9jYWxlcyxcbiAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICB0aGlzLmxvY2FsZVxuICAgICAgKVxuXG4gICAgICAvLyB3ZSBuZWVkIHRvIHdyYXAgdGhpcyBpbiB0aGUgZW52IGNoZWNrIGFnYWluIHNpbmNlIHJlZ2VuZXJhdG9yIHJ1bnRpbWVcbiAgICAgIC8vIG1vdmVzIHRoaXMgb24gaXRzIG93biBkdWUgdG8gdGhlIHJldHVyblxuICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgLy8gaWYgd2UgYXJlIG5hdmlnYXRpbmcgdG8gYSBkb21haW4gbG9jYWxlIGVuc3VyZSB3ZSByZWRpcmVjdCB0byB0aGVcbiAgICAgICAgLy8gY29ycmVjdCBkb21haW5cbiAgICAgICAgaWYgKFxuICAgICAgICAgICFkaWROYXZpZ2F0ZSAmJlxuICAgICAgICAgIGRldGVjdGVkRG9tYWluICYmXG4gICAgICAgICAgdGhpcy5pc0xvY2FsZURvbWFpbiAmJlxuICAgICAgICAgIHNlbGYubG9jYXRpb24uaG9zdG5hbWUgIT09IGRldGVjdGVkRG9tYWluLmRvbWFpblxuICAgICAgICApIHtcbiAgICAgICAgICBjb25zdCBhc05vQmFzZVBhdGggPSBkZWxCYXNlUGF0aChhcylcbiAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtcbiAgICAgICAgICAgIGRldGVjdGVkRG9tYWluLmRvbWFpblxuICAgICAgICAgIH0ke2FkZEJhc2VQYXRoKFxuICAgICAgICAgICAgYCR7XG4gICAgICAgICAgICAgIHRoaXMubG9jYWxlID09PSBkZXRlY3RlZERvbWFpbi5kZWZhdWx0TG9jYWxlXG4gICAgICAgICAgICAgICAgPyAnJ1xuICAgICAgICAgICAgICAgIDogYC8ke3RoaXMubG9jYWxlfWBcbiAgICAgICAgICAgIH0ke2FzTm9CYXNlUGF0aCA9PT0gJy8nID8gJycgOiBhc05vQmFzZVBhdGh9YCB8fCAnLydcbiAgICAgICAgICApfWBcbiAgICAgICAgICAvLyB0aGlzIHdhcyBwcmV2aW91c2x5IGEgcmV0dXJuIGJ1dCB3YXMgcmVtb3ZlZCBpbiBmYXZvclxuICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgZGlkTmF2aWdhdGUgPSB0cnVlXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGRpZE5hdmlnYXRlKSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgoKSA9PiB7fSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIShvcHRpb25zIGFzIGFueSkuX2gpIHtcbiAgICAgIHRoaXMuaXNTc3IgPSBmYWxzZVxuICAgIH1cbiAgICAvLyBtYXJraW5nIHJvdXRlIGNoYW5nZXMgYXMgYSBuYXZpZ2F0aW9uIHN0YXJ0IGVudHJ5XG4gICAgaWYgKFNUKSB7XG4gICAgICBwZXJmb3JtYW5jZS5tYXJrKCdyb3V0ZUNoYW5nZScpXG4gICAgfVxuXG4gICAgY29uc3QgeyBzaGFsbG93ID0gZmFsc2UgfSA9IG9wdGlvbnNcbiAgICBjb25zdCByb3V0ZVByb3BzID0geyBzaGFsbG93IH1cblxuICAgIGlmICh0aGlzLl9pbkZsaWdodFJvdXRlKSB7XG4gICAgICB0aGlzLmFib3J0Q29tcG9uZW50TG9hZCh0aGlzLl9pbkZsaWdodFJvdXRlLCByb3V0ZVByb3BzKVxuICAgIH1cblxuICAgIGFzID0gYWRkQmFzZVBhdGgoXG4gICAgICBhZGRMb2NhbGUoXG4gICAgICAgIGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLFxuICAgICAgICBvcHRpb25zLmxvY2FsZSxcbiAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICApXG4gICAgKVxuICAgIGNvbnN0IGNsZWFuZWRBcyA9IGRlbExvY2FsZShcbiAgICAgIGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLFxuICAgICAgdGhpcy5sb2NhbGVcbiAgICApXG4gICAgdGhpcy5faW5GbGlnaHRSb3V0ZSA9IGFzXG5cbiAgICAvLyBJZiB0aGUgdXJsIGNoYW5nZSBpcyBvbmx5IHJlbGF0ZWQgdG8gYSBoYXNoIGNoYW5nZVxuICAgIC8vIFdlIHNob3VsZCBub3QgcHJvY2VlZC4gV2Ugc2hvdWxkIG9ubHkgY2hhbmdlIHRoZSBzdGF0ZS5cblxuICAgIC8vIFdBUk5JTkc6IGBfaGAgaXMgYW4gaW50ZXJuYWwgb3B0aW9uIGZvciBoYW5kaW5nIE5leHQuanMgY2xpZW50LXNpZGVcbiAgICAvLyBoeWRyYXRpb24uIFlvdXIgYXBwIHNob3VsZCBfbmV2ZXJfIHVzZSB0aGlzIHByb3BlcnR5LiBJdCBtYXkgY2hhbmdlIGF0XG4gICAgLy8gYW55IHRpbWUgd2l0aG91dCBub3RpY2UuXG4gICAgaWYgKCEob3B0aW9ucyBhcyBhbnkpLl9oICYmIHRoaXMub25seUFIYXNoQ2hhbmdlKGNsZWFuZWRBcykpIHtcbiAgICAgIHRoaXMuYXNQYXRoID0gY2xlYW5lZEFzXG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2hhc2hDaGFuZ2VTdGFydCcsIGFzLCByb3V0ZVByb3BzKVxuICAgICAgLy8gVE9ETzogZG8gd2UgbmVlZCB0aGUgcmVzb2x2ZWQgaHJlZiB3aGVuIG9ubHkgYSBoYXNoIGNoYW5nZT9cbiAgICAgIHRoaXMuY2hhbmdlU3RhdGUobWV0aG9kLCB1cmwsIGFzLCBvcHRpb25zKVxuICAgICAgdGhpcy5zY3JvbGxUb0hhc2goY2xlYW5lZEFzKVxuICAgICAgdGhpcy5ub3RpZnkodGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdLCBudWxsKVxuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlQ29tcGxldGUnLCBhcywgcm91dGVQcm9wcylcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgbGV0IHBhcnNlZCA9IHBhcnNlUmVsYXRpdmVVcmwodXJsKVxuICAgIGxldCB7IHBhdGhuYW1lLCBxdWVyeSB9ID0gcGFyc2VkXG5cbiAgICAvLyBUaGUgYnVpbGQgbWFuaWZlc3QgbmVlZHMgdG8gYmUgbG9hZGVkIGJlZm9yZSBhdXRvLXN0YXRpYyBkeW5hbWljIHBhZ2VzXG4gICAgLy8gZ2V0IHRoZWlyIHF1ZXJ5IHBhcmFtZXRlcnMgdG8gYWxsb3cgZW5zdXJpbmcgdGhleSBjYW4gYmUgcGFyc2VkIHByb3Blcmx5XG4gICAgLy8gd2hlbiByZXdyaXR0ZW4gdG9cbiAgICBsZXQgcGFnZXM6IGFueSwgcmV3cml0ZXM6IGFueVxuICAgIHRyeSB7XG4gICAgICBwYWdlcyA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpXG4gICAgICA7KHsgX19yZXdyaXRlczogcmV3cml0ZXMgfSA9IGF3YWl0IGdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIElmIHdlIGZhaWwgdG8gcmVzb2x2ZSB0aGUgcGFnZSBsaXN0IG9yIGNsaWVudC1idWlsZCBtYW5pZmVzdCwgd2UgbXVzdFxuICAgICAgLy8gZG8gYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uOlxuICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhc1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgLy8gSWYgYXNrZWQgdG8gY2hhbmdlIHRoZSBjdXJyZW50IFVSTCB3ZSBzaG91bGQgcmVsb2FkIHRoZSBjdXJyZW50IHBhZ2VcbiAgICAvLyAobm90IGxvY2F0aW9uLnJlbG9hZCgpIGJ1dCByZWxvYWQgZ2V0SW5pdGlhbFByb3BzIGFuZCBvdGhlciBOZXh0LmpzIHN0dWZmcylcbiAgICAvLyBXZSBhbHNvIG5lZWQgdG8gc2V0IHRoZSBtZXRob2QgPSByZXBsYWNlU3RhdGUgYWx3YXlzXG4gICAgLy8gYXMgdGhpcyBzaG91bGQgbm90IGdvIGludG8gdGhlIGhpc3RvcnkgKFRoYXQncyBob3cgYnJvd3NlcnMgd29yaylcbiAgICAvLyBXZSBzaG91bGQgY29tcGFyZSB0aGUgbmV3IGFzUGF0aCB0byB0aGUgY3VycmVudCBhc1BhdGgsIG5vdCB0aGUgdXJsXG4gICAgaWYgKCF0aGlzLnVybElzTmV3KGNsZWFuZWRBcykgJiYgIWxvY2FsZUNoYW5nZSkge1xuICAgICAgbWV0aG9kID0gJ3JlcGxhY2VTdGF0ZSdcbiAgICB9XG5cbiAgICAvLyB3ZSBuZWVkIHRvIHJlc29sdmUgdGhlIGFzIHZhbHVlIHVzaW5nIHJld3JpdGVzIGZvciBkeW5hbWljIFNTR1xuICAgIC8vIHBhZ2VzIHRvIGFsbG93IGJ1aWxkaW5nIHRoZSBkYXRhIFVSTCBjb3JyZWN0bHlcbiAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzXG5cbiAgICAvLyB1cmwgYW5kIGFzIHNob3VsZCBhbHdheXMgYmUgcHJlZml4ZWQgd2l0aCBiYXNlUGF0aCBieSB0aGlzXG4gICAgLy8gcG9pbnQgYnkgZWl0aGVyIG5leHQvbGluayBvciByb3V0ZXIucHVzaC9yZXBsYWNlIHNvIHN0cmlwIHRoZVxuICAgIC8vIGJhc2VQYXRoIGZyb20gdGhlIHBhdGhuYW1lIHRvIG1hdGNoIHRoZSBwYWdlcyBkaXIgMS10by0xXG4gICAgcGF0aG5hbWUgPSBwYXRobmFtZVxuICAgICAgPyByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChkZWxCYXNlUGF0aChwYXRobmFtZSkpXG4gICAgICA6IHBhdGhuYW1lXG5cbiAgICBpZiAocGF0aG5hbWUgIT09ICcvX2Vycm9yJykge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXMuc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgIGNvbnN0IHJld3JpdGVzUmVzdWx0ID0gcmVzb2x2ZVJld3JpdGVzKFxuICAgICAgICAgIGFkZEJhc2VQYXRoKGFkZExvY2FsZShkZWxCYXNlUGF0aChhcyksIHRoaXMubG9jYWxlKSksXG4gICAgICAgICAgcGFnZXMsXG4gICAgICAgICAgcmV3cml0ZXMsXG4gICAgICAgICAgcXVlcnksXG4gICAgICAgICAgKHA6IHN0cmluZykgPT4gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwLCBwYWdlcyksXG4gICAgICAgICAgdGhpcy5sb2NhbGVzXG4gICAgICAgIClcbiAgICAgICAgcmVzb2x2ZWRBcyA9IHJld3JpdGVzUmVzdWx0LmFzUGF0aFxuXG4gICAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgICAvLyBpZiB0aGlzIGRpcmVjdGx5IG1hdGNoZXMgYSBwYWdlIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBocmVmIHRvXG4gICAgICAgICAgLy8gYWxsb3cgdGhlIGNvcnJlY3QgcGFnZSBjaHVuayB0byBiZSBsb2FkZWRcbiAgICAgICAgICBwYXRobmFtZSA9IHJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZlxuICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgICAgICAgdXJsID0gZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lLCBwYWdlcylcblxuICAgICAgICBpZiAocGFyc2VkLnBhdGhuYW1lICE9PSBwYXRobmFtZSkge1xuICAgICAgICAgIHBhdGhuYW1lID0gcGFyc2VkLnBhdGhuYW1lXG4gICAgICAgICAgdXJsID0gZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3Qgcm91dGUgPSByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSlcblxuICAgIGlmICghaXNMb2NhbFVSTChhcykpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgSW52YWxpZCBocmVmOiBcIiR7dXJsfVwiIGFuZCBhczogXCIke2FzfVwiLCByZWNlaXZlZCByZWxhdGl2ZSBocmVmIGFuZCBleHRlcm5hbCBhc2AgK1xuICAgICAgICAgICAgYFxcblNlZSBtb3JlIGluZm86IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2ludmFsaWQtcmVsYXRpdmUtdXJsLWV4dGVybmFsLWFzYFxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXNcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHJlc29sdmVkQXMgPSBkZWxMb2NhbGUoZGVsQmFzZVBhdGgocmVzb2x2ZWRBcyksIHRoaXMubG9jYWxlKVxuXG4gICAgaWYgKGlzRHluYW1pY1JvdXRlKHJvdXRlKSkge1xuICAgICAgY29uc3QgcGFyc2VkQXMgPSBwYXJzZVJlbGF0aXZlVXJsKHJlc29sdmVkQXMpXG4gICAgICBjb25zdCBhc1BhdGhuYW1lID0gcGFyc2VkQXMucGF0aG5hbWVcblxuICAgICAgY29uc3Qgcm91dGVSZWdleCA9IGdldFJvdXRlUmVnZXgocm91dGUpXG4gICAgICBjb25zdCByb3V0ZU1hdGNoID0gZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpKGFzUGF0aG5hbWUpXG4gICAgICBjb25zdCBzaG91bGRJbnRlcnBvbGF0ZSA9IHJvdXRlID09PSBhc1BhdGhuYW1lXG4gICAgICBjb25zdCBpbnRlcnBvbGF0ZWRBcyA9IHNob3VsZEludGVycG9sYXRlXG4gICAgICAgID8gaW50ZXJwb2xhdGVBcyhyb3V0ZSwgYXNQYXRobmFtZSwgcXVlcnkpXG4gICAgICAgIDogKHt9IGFzIHsgcmVzdWx0OiB1bmRlZmluZWQ7IHBhcmFtczogdW5kZWZpbmVkIH0pXG5cbiAgICAgIGlmICghcm91dGVNYXRjaCB8fCAoc2hvdWxkSW50ZXJwb2xhdGUgJiYgIWludGVycG9sYXRlZEFzLnJlc3VsdCkpIHtcbiAgICAgICAgY29uc3QgbWlzc2luZ1BhcmFtcyA9IE9iamVjdC5rZXlzKHJvdXRlUmVnZXguZ3JvdXBzKS5maWx0ZXIoXG4gICAgICAgICAgKHBhcmFtKSA9PiAhcXVlcnlbcGFyYW1dXG4gICAgICAgIClcblxuICAgICAgICBpZiAobWlzc2luZ1BhcmFtcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgYCR7XG4gICAgICAgICAgICAgICAgc2hvdWxkSW50ZXJwb2xhdGVcbiAgICAgICAgICAgICAgICAgID8gYEludGVycG9sYXRpbmcgaHJlZmBcbiAgICAgICAgICAgICAgICAgIDogYE1pc21hdGNoaW5nIFxcYGFzXFxgIGFuZCBcXGBocmVmXFxgYFxuICAgICAgICAgICAgICB9IGZhaWxlZCB0byBtYW51YWxseSBwcm92aWRlIGAgK1xuICAgICAgICAgICAgICAgIGB0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbihcbiAgICAgICAgICAgICAgICAgICcsICdcbiAgICAgICAgICAgICAgICApfSBpbiB0aGUgXFxgaHJlZlxcYCdzIFxcYHF1ZXJ5XFxgYFxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIChzaG91bGRJbnRlcnBvbGF0ZVxuICAgICAgICAgICAgICA/IGBUaGUgcHJvdmlkZWQgXFxgaHJlZlxcYCAoJHt1cmx9KSB2YWx1ZSBpcyBtaXNzaW5nIHF1ZXJ5IHZhbHVlcyAoJHttaXNzaW5nUGFyYW1zLmpvaW4oXG4gICAgICAgICAgICAgICAgICAnLCAnXG4gICAgICAgICAgICAgICAgKX0pIHRvIGJlIGludGVycG9sYXRlZCBwcm9wZXJseS4gYFxuICAgICAgICAgICAgICA6IGBUaGUgcHJvdmlkZWQgXFxgYXNcXGAgdmFsdWUgKCR7YXNQYXRobmFtZX0pIGlzIGluY29tcGF0aWJsZSB3aXRoIHRoZSBcXGBocmVmXFxgIHZhbHVlICgke3JvdXRlfSkuIGApICtcbiAgICAgICAgICAgICAgYFJlYWQgbW9yZTogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvJHtcbiAgICAgICAgICAgICAgICBzaG91bGRJbnRlcnBvbGF0ZVxuICAgICAgICAgICAgICAgICAgPyAnaHJlZi1pbnRlcnBvbGF0aW9uLWZhaWxlZCdcbiAgICAgICAgICAgICAgICAgIDogJ2luY29tcGF0aWJsZS1ocmVmLWFzJ1xuICAgICAgICAgICAgICB9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChzaG91bGRJbnRlcnBvbGF0ZSkge1xuICAgICAgICBhcyA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICAgIE9iamVjdC5hc3NpZ24oe30sIHBhcnNlZEFzLCB7XG4gICAgICAgICAgICBwYXRobmFtZTogaW50ZXJwb2xhdGVkQXMucmVzdWx0LFxuICAgICAgICAgICAgcXVlcnk6IG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeSwgaW50ZXJwb2xhdGVkQXMucGFyYW1zISksXG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTWVyZ2UgcGFyYW1zIGludG8gYHF1ZXJ5YCwgb3ZlcndyaXRpbmcgYW55IHNwZWNpZmllZCBpbiBzZWFyY2hcbiAgICAgICAgT2JqZWN0LmFzc2lnbihxdWVyeSwgcm91dGVNYXRjaClcbiAgICAgIH1cbiAgICB9XG5cbiAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlU3RhcnQnLCBhcywgcm91dGVQcm9wcylcblxuICAgIHRyeSB7XG4gICAgICBsZXQgcm91dGVJbmZvID0gYXdhaXQgdGhpcy5nZXRSb3V0ZUluZm8oXG4gICAgICAgIHJvdXRlLFxuICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgcXVlcnksXG4gICAgICAgIGFzLFxuICAgICAgICByZXNvbHZlZEFzLFxuICAgICAgICByb3V0ZVByb3BzXG4gICAgICApXG4gICAgICBsZXQgeyBlcnJvciwgcHJvcHMsIF9fTl9TU0csIF9fTl9TU1AgfSA9IHJvdXRlSW5mb1xuXG4gICAgICAvLyBoYW5kbGUgcmVkaXJlY3Qgb24gY2xpZW50LXRyYW5zaXRpb25cbiAgICAgIGlmICgoX19OX1NTRyB8fCBfX05fU1NQKSAmJiBwcm9wcykge1xuICAgICAgICBpZiAoKHByb3BzIGFzIGFueSkucGFnZVByb3BzICYmIChwcm9wcyBhcyBhbnkpLnBhZ2VQcm9wcy5fX05fUkVESVJFQ1QpIHtcbiAgICAgICAgICBjb25zdCBkZXN0aW5hdGlvbiA9IChwcm9wcyBhcyBhbnkpLnBhZ2VQcm9wcy5fX05fUkVESVJFQ1RcblxuICAgICAgICAgIC8vIGNoZWNrIGlmIGRlc3RpbmF0aW9uIGlzIGludGVybmFsIChyZXNvbHZlcyB0byBhIHBhZ2UpIGFuZCBhdHRlbXB0XG4gICAgICAgICAgLy8gY2xpZW50LW5hdmlnYXRpb24gaWYgaXQgaXMgZmFsbGluZyBiYWNrIHRvIGhhcmQgbmF2aWdhdGlvbiBpZlxuICAgICAgICAgIC8vIGl0J3Mgbm90XG4gICAgICAgICAgaWYgKGRlc3RpbmF0aW9uLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkSHJlZiA9IHBhcnNlUmVsYXRpdmVVcmwoZGVzdGluYXRpb24pXG4gICAgICAgICAgICBwYXJzZWRIcmVmLnBhdGhuYW1lID0gcmVzb2x2ZUR5bmFtaWNSb3V0ZShcbiAgICAgICAgICAgICAgcGFyc2VkSHJlZi5wYXRobmFtZSxcbiAgICAgICAgICAgICAgcGFnZXNcbiAgICAgICAgICAgIClcblxuICAgICAgICAgICAgaWYgKHBhZ2VzLmluY2x1ZGVzKHBhcnNlZEhyZWYucGF0aG5hbWUpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHsgdXJsOiBuZXdVcmwsIGFzOiBuZXdBcyB9ID0gcHJlcGFyZVVybEFzKFxuICAgICAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb24sXG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb25cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UobWV0aG9kLCBuZXdVcmwsIG5ld0FzLCBvcHRpb25zKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gZGVzdGluYXRpb25cbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKCkgPT4ge30pXG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmlzUHJldmlldyA9ICEhcHJvcHMuX19OX1BSRVZJRVdcblxuICAgICAgICAvLyBoYW5kbGUgU1NHIGRhdGEgNDA0XG4gICAgICAgIGlmIChwcm9wcy5ub3RGb3VuZCA9PT0gU1NHX0RBVEFfTk9UX0ZPVU5EKSB7XG4gICAgICAgICAgbGV0IG5vdEZvdW5kUm91dGVcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLmZldGNoQ29tcG9uZW50KCcvNDA0JylcbiAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnLzQwNCdcbiAgICAgICAgICB9IGNhdGNoIChfKSB7XG4gICAgICAgICAgICBub3RGb3VuZFJvdXRlID0gJy9fZXJyb3InXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcm91dGVJbmZvID0gYXdhaXQgdGhpcy5nZXRSb3V0ZUluZm8oXG4gICAgICAgICAgICBub3RGb3VuZFJvdXRlLFxuICAgICAgICAgICAgbm90Rm91bmRSb3V0ZSxcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgYXMsXG4gICAgICAgICAgICByZXNvbHZlZEFzLFxuICAgICAgICAgICAgeyBzaGFsbG93OiBmYWxzZSB9XG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnYmVmb3JlSGlzdG9yeUNoYW5nZScsIGFzLCByb3V0ZVByb3BzKVxuICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShtZXRob2QsIHVybCwgYXMsIG9wdGlvbnMpXG5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IGFwcENvbXA6IGFueSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXS5Db21wb25lbnRcbiAgICAgICAgOyh3aW5kb3cgYXMgYW55KS5uZXh0LmlzUHJlcmVuZGVyZWQgPVxuICAgICAgICAgIGFwcENvbXAuZ2V0SW5pdGlhbFByb3BzID09PSBhcHBDb21wLm9yaWdHZXRJbml0aWFsUHJvcHMgJiZcbiAgICAgICAgICAhKHJvdXRlSW5mby5Db21wb25lbnQgYXMgYW55KS5nZXRJbml0aWFsUHJvcHNcbiAgICAgIH1cblxuICAgICAgLy8gc2hhbGxvdyByb3V0aW5nIGlzIG9ubHkgYWxsb3dlZCBmb3Igc2FtZSBwYWdlIFVSTCBjaGFuZ2VzLlxuICAgICAgY29uc3QgaXNWYWxpZFNoYWxsb3dSb3V0ZSA9IG9wdGlvbnMuc2hhbGxvdyAmJiB0aGlzLnJvdXRlID09PSByb3V0ZVxuXG4gICAgICBpZiAoXG4gICAgICAgIChvcHRpb25zIGFzIGFueSkuX2ggJiZcbiAgICAgICAgcGF0aG5hbWUgPT09ICcvX2Vycm9yJyAmJlxuICAgICAgICBzZWxmLl9fTkVYVF9EQVRBX18ucHJvcHM/LnBhZ2VQcm9wcz8uc3RhdHVzQ29kZSA9PT0gNTAwICYmXG4gICAgICAgIHByb3BzPy5wYWdlUHJvcHNcbiAgICAgICkge1xuICAgICAgICAvLyBlbnN1cmUgc3RhdHVzQ29kZSBpcyBzdGlsbCBjb3JyZWN0IGZvciBzdGF0aWMgNTAwIHBhZ2VcbiAgICAgICAgLy8gd2hlbiB1cGRhdGluZyBxdWVyeSBpbmZvcm1hdGlvblxuICAgICAgICBwcm9wcy5wYWdlUHJvcHMuc3RhdHVzQ29kZSA9IDUwMFxuICAgICAgfVxuXG4gICAgICBhd2FpdCB0aGlzLnNldChcbiAgICAgICAgcm91dGUsXG4gICAgICAgIHBhdGhuYW1lISxcbiAgICAgICAgcXVlcnksXG4gICAgICAgIGNsZWFuZWRBcyxcbiAgICAgICAgcm91dGVJbmZvLFxuICAgICAgICBmb3JjZWRTY3JvbGwgfHxcbiAgICAgICAgICAoaXNWYWxpZFNoYWxsb3dSb3V0ZSB8fCAhb3B0aW9ucy5zY3JvbGwgPyBudWxsIDogeyB4OiAwLCB5OiAwIH0pXG4gICAgICApLmNhdGNoKChlKSA9PiB7XG4gICAgICAgIGlmIChlLmNhbmNlbGxlZCkgZXJyb3IgPSBlcnJvciB8fCBlXG4gICAgICAgIGVsc2UgdGhyb3cgZVxuICAgICAgfSlcblxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsIGVycm9yLCBjbGVhbmVkQXMsIHJvdXRlUHJvcHMpXG4gICAgICAgIHRocm93IGVycm9yXG4gICAgICB9XG5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIGlmICh0aGlzLmxvY2FsZSkge1xuICAgICAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5sYW5nID0gdGhpcy5sb2NhbGVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgYXMsIHJvdXRlUHJvcHMpXG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyLmNhbmNlbGxlZCkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIHRocm93IGVyclxuICAgIH1cbiAgfVxuXG4gIGNoYW5nZVN0YXRlKFxuICAgIG1ldGhvZDogSGlzdG9yeU1ldGhvZCxcbiAgICB1cmw6IHN0cmluZyxcbiAgICBhczogc3RyaW5nLFxuICAgIG9wdGlvbnM6IFRyYW5zaXRpb25PcHRpb25zID0ge31cbiAgKTogdm9pZCB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIGlmICh0eXBlb2Ygd2luZG93Lmhpc3RvcnkgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5IGlzIG5vdCBhdmFpbGFibGUuYClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2Ygd2luZG93Lmhpc3RvcnlbbWV0aG9kXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgV2FybmluZzogd2luZG93Lmhpc3RvcnkuJHttZXRob2R9IGlzIG5vdCBhdmFpbGFibGVgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAobWV0aG9kICE9PSAncHVzaFN0YXRlJyB8fCBnZXRVUkwoKSAhPT0gYXMpIHtcbiAgICAgIHRoaXMuX3NoYWxsb3cgPSBvcHRpb25zLnNoYWxsb3dcbiAgICAgIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0oXG4gICAgICAgIHtcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgYXMsXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICBfX046IHRydWUsXG4gICAgICAgICAgaWR4OiB0aGlzLl9pZHggPSBtZXRob2QgIT09ICdwdXNoU3RhdGUnID8gdGhpcy5faWR4IDogdGhpcy5faWR4ICsgMSxcbiAgICAgICAgfSBhcyBIaXN0b3J5U3RhdGUsXG4gICAgICAgIC8vIE1vc3QgYnJvd3NlcnMgY3VycmVudGx5IGlnbm9yZXMgdGhpcyBwYXJhbWV0ZXIsIGFsdGhvdWdoIHRoZXkgbWF5IHVzZSBpdCBpbiB0aGUgZnV0dXJlLlxuICAgICAgICAvLyBQYXNzaW5nIHRoZSBlbXB0eSBzdHJpbmcgaGVyZSBzaG91bGQgYmUgc2FmZSBhZ2FpbnN0IGZ1dHVyZSBjaGFuZ2VzIHRvIHRoZSBtZXRob2QuXG4gICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuICAgICAgICAnJyxcbiAgICAgICAgYXNcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBhc3luYyBoYW5kbGVSb3V0ZUluZm9FcnJvcihcbiAgICBlcnI6IEVycm9yICYgeyBjb2RlOiBhbnk7IGNhbmNlbGxlZDogYm9vbGVhbiB9LFxuICAgIHBhdGhuYW1lOiBzdHJpbmcsXG4gICAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5LFxuICAgIGFzOiBzdHJpbmcsXG4gICAgcm91dGVQcm9wczogUm91dGVQcm9wZXJ0aWVzLFxuICAgIGxvYWRFcnJvckZhaWw/OiBib29sZWFuXG4gICk6IFByb21pc2U8Q29tcGxldGVQcml2YXRlUm91dGVJbmZvPiB7XG4gICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgIC8vIGJ1YmJsZSB1cCBjYW5jZWxsYXRpb24gZXJyb3JzXG4gICAgICB0aHJvdyBlcnJcbiAgICB9XG5cbiAgICBpZiAoaXNBc3NldEVycm9yKGVycikgfHwgbG9hZEVycm9yRmFpbCkge1xuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyLCBhcywgcm91dGVQcm9wcylcblxuICAgICAgLy8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgcGFnZSBpdCBjb3VsZCBiZSBvbmUgb2YgZm9sbG93aW5nIHJlYXNvbnNcbiAgICAgIC8vICAxLiBQYWdlIGRvZXNuJ3QgZXhpc3RzXG4gICAgICAvLyAgMi4gUGFnZSBkb2VzIGV4aXN0IGluIGEgZGlmZmVyZW50IHpvbmVcbiAgICAgIC8vICAzLiBJbnRlcm5hbCBlcnJvciB3aGlsZSBsb2FkaW5nIHRoZSBwYWdlXG5cbiAgICAgIC8vIFNvLCBkb2luZyBhIGhhcmQgcmVsb2FkIGlzIHRoZSBwcm9wZXIgd2F5IHRvIGRlYWwgd2l0aCB0aGlzLlxuICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhc1xuXG4gICAgICAvLyBDaGFuZ2luZyB0aGUgVVJMIGRvZXNuJ3QgYmxvY2sgZXhlY3V0aW5nIHRoZSBjdXJyZW50IGNvZGUgcGF0aC5cbiAgICAgIC8vIFNvIGxldCdzIHRocm93IGEgY2FuY2VsbGF0aW9uIGVycm9yIHN0b3AgdGhlIHJvdXRpbmcgbG9naWMuXG4gICAgICB0aHJvdyBidWlsZENhbmNlbGxhdGlvbkVycm9yKClcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgbGV0IENvbXBvbmVudDogQ29tcG9uZW50VHlwZVxuICAgICAgbGV0IHN0eWxlU2hlZXRzOiBTdHlsZVNoZWV0VHVwbGVbXVxuICAgICAgbGV0IHByb3BzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkXG5cbiAgICAgIGlmIChcbiAgICAgICAgdHlwZW9mIENvbXBvbmVudCEgPT09ICd1bmRlZmluZWQnIHx8XG4gICAgICAgIHR5cGVvZiBzdHlsZVNoZWV0cyEgPT09ICd1bmRlZmluZWQnXG4gICAgICApIHtcbiAgICAgICAgOyh7IHBhZ2U6IENvbXBvbmVudCwgc3R5bGVTaGVldHMgfSA9IGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQoXG4gICAgICAgICAgJy9fZXJyb3InXG4gICAgICAgICkpXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJvdXRlSW5mbzogQ29tcGxldGVQcml2YXRlUm91dGVJbmZvID0ge1xuICAgICAgICBwcm9wcyxcbiAgICAgICAgQ29tcG9uZW50LFxuICAgICAgICBzdHlsZVNoZWV0cyxcbiAgICAgICAgZXJyLFxuICAgICAgICBlcnJvcjogZXJyLFxuICAgICAgfVxuXG4gICAgICBpZiAoIXJvdXRlSW5mby5wcm9wcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IGF3YWl0IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCwge1xuICAgICAgICAgICAgZXJyLFxuICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICB9IGFzIGFueSlcbiAgICAgICAgfSBjYXRjaCAoZ2lwRXJyKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gZXJyb3IgcGFnZSBgZ2V0SW5pdGlhbFByb3BzYDogJywgZ2lwRXJyKVxuICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHt9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJvdXRlSW5mb1xuICAgIH0gY2F0Y2ggKHJvdXRlSW5mb0Vycikge1xuICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoXG4gICAgICAgIHJvdXRlSW5mb0VycixcbiAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgIHF1ZXJ5LFxuICAgICAgICBhcyxcbiAgICAgICAgcm91dGVQcm9wcyxcbiAgICAgICAgdHJ1ZVxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdldFJvdXRlSW5mbyhcbiAgICByb3V0ZTogc3RyaW5nLFxuICAgIHBhdGhuYW1lOiBzdHJpbmcsXG4gICAgcXVlcnk6IGFueSxcbiAgICBhczogc3RyaW5nLFxuICAgIHJlc29sdmVkQXM6IHN0cmluZyxcbiAgICByb3V0ZVByb3BzOiBSb3V0ZVByb3BlcnRpZXNcbiAgKTogUHJvbWlzZTxQcml2YXRlUm91dGVJbmZvPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nUm91dGVJbmZvOiBQcml2YXRlUm91dGVJbmZvIHwgdW5kZWZpbmVkID0gdGhpcy5jb21wb25lbnRzW1xuICAgICAgICByb3V0ZVxuICAgICAgXVxuICAgICAgaWYgKHJvdXRlUHJvcHMuc2hhbGxvdyAmJiBleGlzdGluZ1JvdXRlSW5mbyAmJiB0aGlzLnJvdXRlID09PSByb3V0ZSkge1xuICAgICAgICByZXR1cm4gZXhpc3RpbmdSb3V0ZUluZm9cbiAgICAgIH1cblxuICAgICAgY29uc3QgY2FjaGVkUm91dGVJbmZvOiBDb21wbGV0ZVByaXZhdGVSb3V0ZUluZm8gfCB1bmRlZmluZWQgPVxuICAgICAgICBleGlzdGluZ1JvdXRlSW5mbyAmJiAnaW5pdGlhbCcgaW4gZXhpc3RpbmdSb3V0ZUluZm9cbiAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgIDogZXhpc3RpbmdSb3V0ZUluZm9cbiAgICAgIGNvbnN0IHJvdXRlSW5mbzogQ29tcGxldGVQcml2YXRlUm91dGVJbmZvID0gY2FjaGVkUm91dGVJbmZvXG4gICAgICAgID8gY2FjaGVkUm91dGVJbmZvXG4gICAgICAgIDogYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudChyb3V0ZSkudGhlbigocmVzKSA9PiAoe1xuICAgICAgICAgICAgQ29tcG9uZW50OiByZXMucGFnZSxcbiAgICAgICAgICAgIHN0eWxlU2hlZXRzOiByZXMuc3R5bGVTaGVldHMsXG4gICAgICAgICAgICBfX05fU1NHOiByZXMubW9kLl9fTl9TU0csXG4gICAgICAgICAgICBfX05fU1NQOiByZXMubW9kLl9fTl9TU1AsXG4gICAgICAgICAgfSkpXG5cbiAgICAgIGNvbnN0IHsgQ29tcG9uZW50LCBfX05fU1NHLCBfX05fU1NQIH0gPSByb3V0ZUluZm9cblxuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgY29uc3QgeyBpc1ZhbGlkRWxlbWVudFR5cGUgfSA9IHJlcXVpcmUoJ3JlYWN0LWlzJylcbiAgICAgICAgaWYgKCFpc1ZhbGlkRWxlbWVudFR5cGUoQ29tcG9uZW50KSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBUaGUgZGVmYXVsdCBleHBvcnQgaXMgbm90IGEgUmVhY3QgQ29tcG9uZW50IGluIHBhZ2U6IFwiJHtwYXRobmFtZX1cImBcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGRhdGFIcmVmOiBzdHJpbmcgfCB1bmRlZmluZWRcblxuICAgICAgaWYgKF9fTl9TU0cgfHwgX19OX1NTUCkge1xuICAgICAgICBkYXRhSHJlZiA9IHRoaXMucGFnZUxvYWRlci5nZXREYXRhSHJlZihcbiAgICAgICAgICBmb3JtYXRXaXRoVmFsaWRhdGlvbih7IHBhdGhuYW1lLCBxdWVyeSB9KSxcbiAgICAgICAgICByZXNvbHZlZEFzLFxuICAgICAgICAgIF9fTl9TU0csXG4gICAgICAgICAgdGhpcy5sb2NhbGVcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBwcm9wcyA9IGF3YWl0IHRoaXMuX2dldERhdGE8Q29tcGxldGVQcml2YXRlUm91dGVJbmZvPigoKSA9PlxuICAgICAgICBfX05fU1NHXG4gICAgICAgICAgPyB0aGlzLl9nZXRTdGF0aWNEYXRhKGRhdGFIcmVmISlcbiAgICAgICAgICA6IF9fTl9TU1BcbiAgICAgICAgICA/IHRoaXMuX2dldFNlcnZlckRhdGEoZGF0YUhyZWYhKVxuICAgICAgICAgIDogdGhpcy5nZXRJbml0aWFsUHJvcHMoXG4gICAgICAgICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgICAgICAgLy8gd2UgcHJvdmlkZSBBcHBUcmVlIGxhdGVyIHNvIHRoaXMgbmVlZHMgdG8gYmUgYGFueWBcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgICAgIGFzUGF0aDogYXMsXG4gICAgICAgICAgICAgIH0gYXMgYW55XG4gICAgICAgICAgICApXG4gICAgICApXG5cbiAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHByb3BzXG4gICAgICB0aGlzLmNvbXBvbmVudHNbcm91dGVdID0gcm91dGVJbmZvXG4gICAgICByZXR1cm4gcm91dGVJbmZvXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICByZXR1cm4gdGhpcy5oYW5kbGVSb3V0ZUluZm9FcnJvcihlcnIsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHJvdXRlUHJvcHMpXG4gICAgfVxuICB9XG5cbiAgc2V0KFxuICAgIHJvdXRlOiBzdHJpbmcsXG4gICAgcGF0aG5hbWU6IHN0cmluZyxcbiAgICBxdWVyeTogUGFyc2VkVXJsUXVlcnksXG4gICAgYXM6IHN0cmluZyxcbiAgICBkYXRhOiBQcml2YXRlUm91dGVJbmZvLFxuICAgIHJlc2V0U2Nyb2xsOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0gfCBudWxsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuaXNGYWxsYmFjayA9IGZhbHNlXG5cbiAgICB0aGlzLnJvdXRlID0gcm91dGVcbiAgICB0aGlzLnBhdGhuYW1lID0gcGF0aG5hbWVcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnlcbiAgICB0aGlzLmFzUGF0aCA9IGFzXG4gICAgcmV0dXJuIHRoaXMubm90aWZ5KGRhdGEsIHJlc2V0U2Nyb2xsKVxuICB9XG5cbiAgLyoqXG4gICAqIENhbGxiYWNrIHRvIGV4ZWN1dGUgYmVmb3JlIHJlcGxhY2luZyByb3V0ZXIgc3RhdGVcbiAgICogQHBhcmFtIGNiIGNhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkXG4gICAqL1xuICBiZWZvcmVQb3BTdGF0ZShjYjogQmVmb3JlUG9wU3RhdGVDYWxsYmFjaykge1xuICAgIHRoaXMuX2JwcyA9IGNiXG4gIH1cblxuICBvbmx5QUhhc2hDaGFuZ2UoYXM6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGlmICghdGhpcy5hc1BhdGgpIHJldHVybiBmYWxzZVxuICAgIGNvbnN0IFtvbGRVcmxOb0hhc2gsIG9sZEhhc2hdID0gdGhpcy5hc1BhdGguc3BsaXQoJyMnKVxuICAgIGNvbnN0IFtuZXdVcmxOb0hhc2gsIG5ld0hhc2hdID0gYXMuc3BsaXQoJyMnKVxuXG4gICAgLy8gTWFrZXMgc3VyZSB3ZSBzY3JvbGwgdG8gdGhlIHByb3ZpZGVkIGhhc2ggaWYgdGhlIHVybC9oYXNoIGFyZSB0aGUgc2FtZVxuICAgIGlmIChuZXdIYXNoICYmIG9sZFVybE5vSGFzaCA9PT0gbmV3VXJsTm9IYXNoICYmIG9sZEhhc2ggPT09IG5ld0hhc2gpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIHVybHMgYXJlIGNoYW5nZSwgdGhlcmUncyBtb3JlIHRoYW4gYSBoYXNoIGNoYW5nZVxuICAgIGlmIChvbGRVcmxOb0hhc2ggIT09IG5ld1VybE5vSGFzaCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIGhhc2ggaGFzIGNoYW5nZWQsIHRoZW4gaXQncyBhIGhhc2ggb25seSBjaGFuZ2UuXG4gICAgLy8gVGhpcyBjaGVjayBpcyBuZWNlc3NhcnkgdG8gaGFuZGxlIGJvdGggdGhlIGVudGVyIGFuZFxuICAgIC8vIGxlYXZlIGhhc2ggPT09ICcnIGNhc2VzLiBUaGUgaWRlbnRpdHkgY2FzZSBmYWxscyB0aHJvdWdoXG4gICAgLy8gYW5kIGlzIHRyZWF0ZWQgYXMgYSBuZXh0IHJlbG9hZC5cbiAgICByZXR1cm4gb2xkSGFzaCAhPT0gbmV3SGFzaFxuICB9XG5cbiAgc2Nyb2xsVG9IYXNoKGFzOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBjb25zdCBbLCBoYXNoXSA9IGFzLnNwbGl0KCcjJylcbiAgICAvLyBTY3JvbGwgdG8gdG9wIGlmIHRoZSBoYXNoIGlzIGp1c3QgYCNgIHdpdGggbm8gdmFsdWUgb3IgYCN0b3BgXG4gICAgLy8gVG8gbWlycm9yIGJyb3dzZXJzXG4gICAgaWYgKGhhc2ggPT09ICcnIHx8IGhhc2ggPT09ICd0b3AnKSB7XG4gICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMClcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIC8vIEZpcnN0IHdlIGNoZWNrIGlmIHRoZSBlbGVtZW50IGJ5IGlkIGlzIGZvdW5kXG4gICAgY29uc3QgaWRFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpXG4gICAgaWYgKGlkRWwpIHtcbiAgICAgIGlkRWwuc2Nyb2xsSW50b1ZpZXcoKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIC8vIElmIHRoZXJlJ3Mgbm8gZWxlbWVudCB3aXRoIHRoZSBpZCwgd2UgY2hlY2sgdGhlIGBuYW1lYCBwcm9wZXJ0eVxuICAgIC8vIFRvIG1pcnJvciBicm93c2Vyc1xuICAgIGNvbnN0IG5hbWVFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKGhhc2gpWzBdXG4gICAgaWYgKG5hbWVFbCkge1xuICAgICAgbmFtZUVsLnNjcm9sbEludG9WaWV3KClcbiAgICB9XG4gIH1cblxuICB1cmxJc05ldyhhc1BhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLmFzUGF0aCAhPT0gYXNQYXRoXG4gIH1cblxuICAvKipcbiAgICogUHJlZmV0Y2ggcGFnZSBjb2RlLCB5b3UgbWF5IHdhaXQgZm9yIHRoZSBkYXRhIGR1cmluZyBwYWdlIHJlbmRlcmluZy5cbiAgICogVGhpcyBmZWF0dXJlIG9ubHkgd29ya3MgaW4gcHJvZHVjdGlvbiFcbiAgICogQHBhcmFtIHVybCB0aGUgaHJlZiBvZiBwcmVmZXRjaGVkIHBhZ2VcbiAgICogQHBhcmFtIGFzUGF0aCB0aGUgYXMgcGF0aCBvZiB0aGUgcHJlZmV0Y2hlZCBwYWdlXG4gICAqL1xuICBhc3luYyBwcmVmZXRjaChcbiAgICB1cmw6IHN0cmluZyxcbiAgICBhc1BhdGg6IHN0cmluZyA9IHVybCxcbiAgICBvcHRpb25zOiBQcmVmZXRjaE9wdGlvbnMgPSB7fVxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBsZXQgcGFyc2VkID0gcGFyc2VSZWxhdGl2ZVVybCh1cmwpXG5cbiAgICBsZXQgeyBwYXRobmFtZSB9ID0gcGFyc2VkXG5cbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgaWYgKG9wdGlvbnMubG9jYWxlID09PSBmYWxzZSkge1xuICAgICAgICBwYXRobmFtZSA9IG5vcm1hbGl6ZUxvY2FsZVBhdGghKHBhdGhuYW1lLCB0aGlzLmxvY2FsZXMpLnBhdGhuYW1lXG4gICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgICAgIHVybCA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZClcblxuICAgICAgICBsZXQgcGFyc2VkQXMgPSBwYXJzZVJlbGF0aXZlVXJsKGFzUGF0aClcbiAgICAgICAgY29uc3QgbG9jYWxlUGF0aFJlc3VsdCA9IG5vcm1hbGl6ZUxvY2FsZVBhdGghKFxuICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lLFxuICAgICAgICAgIHRoaXMubG9jYWxlc1xuICAgICAgICApXG4gICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gbG9jYWxlUGF0aFJlc3VsdC5wYXRobmFtZVxuICAgICAgICBvcHRpb25zLmxvY2FsZSA9IGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUgfHwgdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICAgIGFzUGF0aCA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZEFzKVxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KClcbiAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzUGF0aFxuXG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXNQYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgbGV0IHJld3JpdGVzOiBhbnlcbiAgICAgIDsoeyBfX3Jld3JpdGVzOiByZXdyaXRlcyB9ID0gYXdhaXQgZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpKVxuXG4gICAgICBjb25zdCByZXdyaXRlc1Jlc3VsdCA9IHJlc29sdmVSZXdyaXRlcyhcbiAgICAgICAgYWRkQmFzZVBhdGgoYWRkTG9jYWxlKGFzUGF0aCwgdGhpcy5sb2NhbGUpKSxcbiAgICAgICAgcGFnZXMsXG4gICAgICAgIHJld3JpdGVzLFxuICAgICAgICBwYXJzZWQucXVlcnksXG4gICAgICAgIChwOiBzdHJpbmcpID0+IHJlc29sdmVEeW5hbWljUm91dGUocCwgcGFnZXMpLFxuICAgICAgICB0aGlzLmxvY2FsZXNcbiAgICAgIClcbiAgICAgIHJlc29sdmVkQXMgPSBkZWxMb2NhbGUoZGVsQmFzZVBhdGgocmV3cml0ZXNSZXN1bHQuYXNQYXRoKSwgdGhpcy5sb2NhbGUpXG5cbiAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAvLyBhbGxvdyB0aGUgY29ycmVjdCBwYWdlIGNodW5rIHRvIGJlIGxvYWRlZFxuICAgICAgICBwYXRobmFtZSA9IHJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZlxuICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZVxuICAgICAgICB1cmwgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHJlc29sdmVEeW5hbWljUm91dGUocGFyc2VkLnBhdGhuYW1lLCBwYWdlcylcblxuICAgICAgaWYgKHBhcnNlZC5wYXRobmFtZSAhPT0gcGF0aG5hbWUpIHtcbiAgICAgICAgcGF0aG5hbWUgPSBwYXJzZWQucGF0aG5hbWVcbiAgICAgICAgdXJsID0gZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByb3V0ZSA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lKVxuXG4gICAgLy8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICB0aGlzLnBhZ2VMb2FkZXIuX2lzU3NnKHJvdXRlKS50aGVuKChpc1NzZzogYm9vbGVhbikgPT4ge1xuICAgICAgICByZXR1cm4gaXNTc2dcbiAgICAgICAgICA/IHRoaXMuX2dldFN0YXRpY0RhdGEoXG4gICAgICAgICAgICAgIHRoaXMucGFnZUxvYWRlci5nZXREYXRhSHJlZihcbiAgICAgICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICAgICAgcmVzb2x2ZWRBcyxcbiAgICAgICAgICAgICAgICB0cnVlLFxuICAgICAgICAgICAgICAgIHR5cGVvZiBvcHRpb25zLmxvY2FsZSAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgICAgICAgICAgID8gb3B0aW9ucy5sb2NhbGVcbiAgICAgICAgICAgICAgICAgIDogdGhpcy5sb2NhbGVcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKVxuICAgICAgICAgIDogZmFsc2VcbiAgICAgIH0pLFxuICAgICAgdGhpcy5wYWdlTG9hZGVyW29wdGlvbnMucHJpb3JpdHkgPyAnbG9hZFBhZ2UnIDogJ3ByZWZldGNoJ10ocm91dGUpLFxuICAgIF0pXG4gIH1cblxuICBhc3luYyBmZXRjaENvbXBvbmVudChyb3V0ZTogc3RyaW5nKTogUHJvbWlzZTxHb29kUGFnZUNhY2hlPiB7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlXG4gICAgY29uc3QgY2FuY2VsID0gKHRoaXMuY2xjID0gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxuICAgIH0pXG5cbiAgICBjb25zdCBjb21wb25lbnRSZXN1bHQgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIubG9hZFBhZ2Uocm91dGUpXG5cbiAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICBjb25zdCBlcnJvcjogYW55ID0gbmV3IEVycm9yKFxuICAgICAgICBgQWJvcnQgZmV0Y2hpbmcgY29tcG9uZW50IGZvciByb3V0ZTogXCIke3JvdXRlfVwiYFxuICAgICAgKVxuICAgICAgZXJyb3IuY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG5cbiAgICBpZiAoY2FuY2VsID09PSB0aGlzLmNsYykge1xuICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbXBvbmVudFJlc3VsdFxuICB9XG5cbiAgX2dldERhdGE8VD4oZm46ICgpID0+IFByb21pc2U8VD4pOiBQcm9taXNlPFQ+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcbiAgICBjb25zdCBjYW5jZWwgPSAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlXG4gICAgfVxuICAgIHRoaXMuY2xjID0gY2FuY2VsXG4gICAgcmV0dXJuIGZuKCkudGhlbigoZGF0YSkgPT4ge1xuICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgICB9XG5cbiAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgY29uc3QgZXJyOiBhbnkgPSBuZXcgRXJyb3IoJ0xvYWRpbmcgaW5pdGlhbCBwcm9wcyBjYW5jZWxsZWQnKVxuICAgICAgICBlcnIuY2FuY2VsbGVkID0gdHJ1ZVxuICAgICAgICB0aHJvdyBlcnJcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGRhdGFcbiAgICB9KVxuICB9XG5cbiAgX2dldFN0YXRpY0RhdGEoZGF0YUhyZWY6IHN0cmluZyk6IFByb21pc2U8b2JqZWN0PiB7XG4gICAgY29uc3QgeyBocmVmOiBjYWNoZUtleSB9ID0gbmV3IFVSTChkYXRhSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpXG4gICAgaWYgKFxuICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJyAmJlxuICAgICAgIXRoaXMuaXNQcmV2aWV3ICYmXG4gICAgICB0aGlzLnNkY1tjYWNoZUtleV1cbiAgICApIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpcy5zZGNbY2FjaGVLZXldKVxuICAgIH1cbiAgICByZXR1cm4gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgdGhpcy5pc1NzcikudGhlbigoZGF0YSkgPT4ge1xuICAgICAgdGhpcy5zZGNbY2FjaGVLZXldID0gZGF0YVxuICAgICAgcmV0dXJuIGRhdGFcbiAgICB9KVxuICB9XG5cbiAgX2dldFNlcnZlckRhdGEoZGF0YUhyZWY6IHN0cmluZyk6IFByb21pc2U8b2JqZWN0PiB7XG4gICAgY29uc3QgeyBocmVmOiByZXNvdXJjZUtleSB9ID0gbmV3IFVSTChkYXRhSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpXG4gICAgaWYgKHRoaXMuc2RyW3Jlc291cmNlS2V5XSkge1xuICAgICAgcmV0dXJuIHRoaXMuc2RyW3Jlc291cmNlS2V5XVxuICAgIH1cbiAgICByZXR1cm4gKHRoaXMuc2RyW3Jlc291cmNlS2V5XSA9IGZldGNoTmV4dERhdGEoZGF0YUhyZWYsIHRoaXMuaXNTc3IpXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICBkZWxldGUgdGhpcy5zZHJbcmVzb3VyY2VLZXldXG4gICAgICAgIHJldHVybiBkYXRhXG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgZGVsZXRlIHRoaXMuc2RyW3Jlc291cmNlS2V5XVxuICAgICAgICB0aHJvdyBlcnJcbiAgICAgIH0pKVxuICB9XG5cbiAgZ2V0SW5pdGlhbFByb3BzKFxuICAgIENvbXBvbmVudDogQ29tcG9uZW50VHlwZSxcbiAgICBjdHg6IE5leHRQYWdlQ29udGV4dFxuICApOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IHsgQ29tcG9uZW50OiBBcHAgfSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXVxuICAgIGNvbnN0IEFwcFRyZWUgPSB0aGlzLl93cmFwQXBwKEFwcCBhcyBBcHBDb21wb25lbnQpXG4gICAgY3R4LkFwcFRyZWUgPSBBcHBUcmVlXG4gICAgcmV0dXJuIGxvYWRHZXRJbml0aWFsUHJvcHM8QXBwQ29udGV4dFR5cGU8Um91dGVyPj4oQXBwLCB7XG4gICAgICBBcHBUcmVlLFxuICAgICAgQ29tcG9uZW50LFxuICAgICAgcm91dGVyOiB0aGlzLFxuICAgICAgY3R4LFxuICAgIH0pXG4gIH1cblxuICBhYm9ydENvbXBvbmVudExvYWQoYXM6IHN0cmluZywgcm91dGVQcm9wczogUm91dGVQcm9wZXJ0aWVzKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuY2xjKSB7XG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoXG4gICAgICAgICdyb3V0ZUNoYW5nZUVycm9yJyxcbiAgICAgICAgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLFxuICAgICAgICBhcyxcbiAgICAgICAgcm91dGVQcm9wc1xuICAgICAgKVxuICAgICAgdGhpcy5jbGMoKVxuICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgfVxuICB9XG5cbiAgbm90aWZ5KFxuICAgIGRhdGE6IFByaXZhdGVSb3V0ZUluZm8sXG4gICAgcmVzZXRTY3JvbGw6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IG51bGxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMuc3ViKFxuICAgICAgZGF0YSxcbiAgICAgIHRoaXMuY29tcG9uZW50c1snL19hcHAnXS5Db21wb25lbnQgYXMgQXBwQ29tcG9uZW50LFxuICAgICAgcmVzZXRTY3JvbGxcbiAgICApXG4gIH1cbn1cbiIsIi8vIEZvcm1hdCBmdW5jdGlvbiBtb2RpZmllZCBmcm9tIG5vZGVqc1xuLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG5cbmltcG9ydCB7IFVybE9iamVjdCB9IGZyb20gJ3VybCdcbmltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5pbXBvcnQgKiBhcyBxdWVyeXN0cmluZyBmcm9tICcuL3F1ZXJ5c3RyaW5nJ1xuXG5jb25zdCBzbGFzaGVkUHJvdG9jb2xzID0gL2h0dHBzP3xmdHB8Z29waGVyfGZpbGUvXG5cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRVcmwodXJsT2JqOiBVcmxPYmplY3QpIHtcbiAgbGV0IHsgYXV0aCwgaG9zdG5hbWUgfSA9IHVybE9ialxuICBsZXQgcHJvdG9jb2wgPSB1cmxPYmoucHJvdG9jb2wgfHwgJydcbiAgbGV0IHBhdGhuYW1lID0gdXJsT2JqLnBhdGhuYW1lIHx8ICcnXG4gIGxldCBoYXNoID0gdXJsT2JqLmhhc2ggfHwgJydcbiAgbGV0IHF1ZXJ5ID0gdXJsT2JqLnF1ZXJ5IHx8ICcnXG4gIGxldCBob3N0OiBzdHJpbmcgfCBmYWxzZSA9IGZhbHNlXG5cbiAgYXV0aCA9IGF1dGggPyBlbmNvZGVVUklDb21wb25lbnQoYXV0aCkucmVwbGFjZSgvJTNBL2ksICc6JykgKyAnQCcgOiAnJ1xuXG4gIGlmICh1cmxPYmouaG9zdCkge1xuICAgIGhvc3QgPSBhdXRoICsgdXJsT2JqLmhvc3RcbiAgfSBlbHNlIGlmIChob3N0bmFtZSkge1xuICAgIGhvc3QgPSBhdXRoICsgKH5ob3N0bmFtZS5pbmRleE9mKCc6JykgPyBgWyR7aG9zdG5hbWV9XWAgOiBob3N0bmFtZSlcbiAgICBpZiAodXJsT2JqLnBvcnQpIHtcbiAgICAgIGhvc3QgKz0gJzonICsgdXJsT2JqLnBvcnRcbiAgICB9XG4gIH1cblxuICBpZiAocXVlcnkgJiYgdHlwZW9mIHF1ZXJ5ID09PSAnb2JqZWN0Jykge1xuICAgIHF1ZXJ5ID0gU3RyaW5nKHF1ZXJ5c3RyaW5nLnVybFF1ZXJ5VG9TZWFyY2hQYXJhbXMocXVlcnkgYXMgUGFyc2VkVXJsUXVlcnkpKVxuICB9XG5cbiAgbGV0IHNlYXJjaCA9IHVybE9iai5zZWFyY2ggfHwgKHF1ZXJ5ICYmIGA/JHtxdWVyeX1gKSB8fCAnJ1xuXG4gIGlmIChwcm90b2NvbCAmJiBwcm90b2NvbC5zdWJzdHIoLTEpICE9PSAnOicpIHByb3RvY29sICs9ICc6J1xuXG4gIGlmIChcbiAgICB1cmxPYmouc2xhc2hlcyB8fFxuICAgICgoIXByb3RvY29sIHx8IHNsYXNoZWRQcm90b2NvbHMudGVzdChwcm90b2NvbCkpICYmIGhvc3QgIT09IGZhbHNlKVxuICApIHtcbiAgICBob3N0ID0gJy8vJyArIChob3N0IHx8ICcnKVxuICAgIGlmIChwYXRobmFtZSAmJiBwYXRobmFtZVswXSAhPT0gJy8nKSBwYXRobmFtZSA9ICcvJyArIHBhdGhuYW1lXG4gIH0gZWxzZSBpZiAoIWhvc3QpIHtcbiAgICBob3N0ID0gJydcbiAgfVxuXG4gIGlmIChoYXNoICYmIGhhc2hbMF0gIT09ICcjJykgaGFzaCA9ICcjJyArIGhhc2hcbiAgaWYgKHNlYXJjaCAmJiBzZWFyY2hbMF0gIT09ICc/Jykgc2VhcmNoID0gJz8nICsgc2VhcmNoXG5cbiAgcGF0aG5hbWUgPSBwYXRobmFtZS5yZXBsYWNlKC9bPyNdL2csIGVuY29kZVVSSUNvbXBvbmVudClcbiAgc2VhcmNoID0gc2VhcmNoLnJlcGxhY2UoJyMnLCAnJTIzJylcblxuICByZXR1cm4gYCR7cHJvdG9jb2x9JHtob3N0fSR7cGF0aG5hbWV9JHtzZWFyY2h9JHtoYXNofWBcbn1cbiIsIi8vIElkZW50aWZ5IC9bcGFyYW1dLyBpbiByb3V0ZSBzdHJpbmdcbmNvbnN0IFRFU1RfUk9VVEUgPSAvXFwvXFxbW14vXSs/XFxdKD89XFwvfCQpL1xuXG5leHBvcnQgZnVuY3Rpb24gaXNEeW5hbWljUm91dGUocm91dGU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gVEVTVF9ST1VURS50ZXN0KHJvdXRlKVxufVxuIiwiaW1wb3J0IHsgZ2V0TG9jYXRpb25PcmlnaW4gfSBmcm9tICcuLi8uLi91dGlscydcbmltcG9ydCB7IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkgfSBmcm9tICcuL3F1ZXJ5c3RyaW5nJ1xuXG4vKipcbiAqIFBhcnNlcyBwYXRoLXJlbGF0aXZlIHVybHMgKGUuZy4gYC9oZWxsby93b3JsZD9mb289YmFyYCkuIElmIHVybCBpc24ndCBwYXRoLXJlbGF0aXZlXG4gKiAoZS5nLiBgLi9oZWxsb2ApIHRoZW4gYXQgbGVhc3QgYmFzZSBtdXN0IGJlLlxuICogQWJzb2x1dGUgdXJscyBhcmUgcmVqZWN0ZWQgd2l0aCBvbmUgZXhjZXB0aW9uLCBpbiB0aGUgYnJvd3NlciwgYWJzb2x1dGUgdXJscyB0aGF0IGFyZSBvblxuICogdGhlIGN1cnJlbnQgb3JpZ2luIHdpbGwgYmUgcGFyc2VkIGFzIHJlbGF0aXZlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVJlbGF0aXZlVXJsKHVybDogc3RyaW5nLCBiYXNlPzogc3RyaW5nKSB7XG4gIGNvbnN0IGdsb2JhbEJhc2UgPSBuZXcgVVJMKFxuICAgIHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnID8gJ2h0dHA6Ly9uJyA6IGdldExvY2F0aW9uT3JpZ2luKClcbiAgKVxuICBjb25zdCByZXNvbHZlZEJhc2UgPSBiYXNlID8gbmV3IFVSTChiYXNlLCBnbG9iYWxCYXNlKSA6IGdsb2JhbEJhc2VcbiAgY29uc3QgeyBwYXRobmFtZSwgc2VhcmNoUGFyYW1zLCBzZWFyY2gsIGhhc2gsIGhyZWYsIG9yaWdpbiB9ID0gbmV3IFVSTChcbiAgICB1cmwsXG4gICAgcmVzb2x2ZWRCYXNlXG4gIClcbiAgaWYgKG9yaWdpbiAhPT0gZ2xvYmFsQmFzZS5vcmlnaW4pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYGludmFyaWFudDogaW52YWxpZCByZWxhdGl2ZSBVUkwsIHJvdXRlciByZWNlaXZlZCAke3VybH1gKVxuICB9XG4gIHJldHVybiB7XG4gICAgcGF0aG5hbWUsXG4gICAgcXVlcnk6IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkoc2VhcmNoUGFyYW1zKSxcbiAgICBzZWFyY2gsXG4gICAgaGFzaCxcbiAgICBocmVmOiBocmVmLnNsaWNlKGdsb2JhbEJhc2Uub3JpZ2luLmxlbmd0aCksXG4gIH1cbn1cbiIsImltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5cbmV4cG9ydCBmdW5jdGlvbiBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KFxuICBzZWFyY2hQYXJhbXM6IFVSTFNlYXJjaFBhcmFtc1xuKTogUGFyc2VkVXJsUXVlcnkge1xuICBjb25zdCBxdWVyeTogUGFyc2VkVXJsUXVlcnkgPSB7fVxuICBzZWFyY2hQYXJhbXMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgIGlmICh0eXBlb2YgcXVlcnlba2V5XSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHF1ZXJ5W2tleV0gPSB2YWx1ZVxuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShxdWVyeVtrZXldKSkge1xuICAgICAgOyhxdWVyeVtrZXldIGFzIHN0cmluZ1tdKS5wdXNoKHZhbHVlKVxuICAgIH0gZWxzZSB7XG4gICAgICBxdWVyeVtrZXldID0gW3F1ZXJ5W2tleV0gYXMgc3RyaW5nLCB2YWx1ZV1cbiAgICB9XG4gIH0pXG4gIHJldHVybiBxdWVyeVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlVcmxRdWVyeVBhcmFtKHBhcmFtOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoXG4gICAgdHlwZW9mIHBhcmFtID09PSAnc3RyaW5nJyB8fFxuICAgICh0eXBlb2YgcGFyYW0gPT09ICdudW1iZXInICYmICFpc05hTihwYXJhbSkpIHx8XG4gICAgdHlwZW9mIHBhcmFtID09PSAnYm9vbGVhbidcbiAgKSB7XG4gICAgcmV0dXJuIFN0cmluZyhwYXJhbSlcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gJydcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXJsUXVlcnlUb1NlYXJjaFBhcmFtcyhcbiAgdXJsUXVlcnk6IFBhcnNlZFVybFF1ZXJ5XG4pOiBVUkxTZWFyY2hQYXJhbXMge1xuICBjb25zdCByZXN1bHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKClcbiAgT2JqZWN0LmVudHJpZXModXJsUXVlcnkpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgdmFsdWUuZm9yRWFjaCgoaXRlbSkgPT4gcmVzdWx0LmFwcGVuZChrZXksIHN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0oaXRlbSkpKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQuc2V0KGtleSwgc3RyaW5naWZ5VXJsUXVlcnlQYXJhbSh2YWx1ZSkpXG4gICAgfVxuICB9KVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhc3NpZ24oXG4gIHRhcmdldDogVVJMU2VhcmNoUGFyYW1zLFxuICAuLi5zZWFyY2hQYXJhbXNMaXN0OiBVUkxTZWFyY2hQYXJhbXNbXVxuKTogVVJMU2VhcmNoUGFyYW1zIHtcbiAgc2VhcmNoUGFyYW1zTGlzdC5mb3JFYWNoKChzZWFyY2hQYXJhbXMpID0+IHtcbiAgICBBcnJheS5mcm9tKHNlYXJjaFBhcmFtcy5rZXlzKCkpLmZvckVhY2goKGtleSkgPT4gdGFyZ2V0LmRlbGV0ZShrZXkpKVxuICAgIHNlYXJjaFBhcmFtcy5mb3JFYWNoKCh2YWx1ZSwga2V5KSA9PiB0YXJnZXQuYXBwZW5kKGtleSwgdmFsdWUpKVxuICB9KVxuICByZXR1cm4gdGFyZ2V0XG59XG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiByZXNvbHZlUmV3cml0ZXMoKSB7fVxuIiwiaW1wb3J0IHsgZ2V0Um91dGVSZWdleCB9IGZyb20gJy4vcm91dGUtcmVnZXgnXG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRSb3V0ZU1hdGNoZXIocm91dGVSZWdleDogUmV0dXJuVHlwZTx0eXBlb2YgZ2V0Um91dGVSZWdleD4pIHtcbiAgY29uc3QgeyByZSwgZ3JvdXBzIH0gPSByb3V0ZVJlZ2V4XG4gIHJldHVybiAocGF0aG5hbWU6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpID0+IHtcbiAgICBjb25zdCByb3V0ZU1hdGNoID0gcmUuZXhlYyhwYXRobmFtZSEpXG4gICAgaWYgKCFyb3V0ZU1hdGNoKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICBjb25zdCBkZWNvZGUgPSAocGFyYW06IHN0cmluZykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudChwYXJhbSlcbiAgICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgY29uc3QgZXJyOiBFcnJvciAmIHsgY29kZT86IHN0cmluZyB9ID0gbmV3IEVycm9yKFxuICAgICAgICAgICdmYWlsZWQgdG8gZGVjb2RlIHBhcmFtJ1xuICAgICAgICApXG4gICAgICAgIGVyci5jb2RlID0gJ0RFQ09ERV9GQUlMRUQnXG4gICAgICAgIHRocm93IGVyclxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBwYXJhbXM6IHsgW3BhcmFtTmFtZTogc3RyaW5nXTogc3RyaW5nIHwgc3RyaW5nW10gfSA9IHt9XG5cbiAgICBPYmplY3Qua2V5cyhncm91cHMpLmZvckVhY2goKHNsdWdOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGcgPSBncm91cHNbc2x1Z05hbWVdXG4gICAgICBjb25zdCBtID0gcm91dGVNYXRjaFtnLnBvc11cbiAgICAgIGlmIChtICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcGFyYW1zW3NsdWdOYW1lXSA9IH5tLmluZGV4T2YoJy8nKVxuICAgICAgICAgID8gbS5zcGxpdCgnLycpLm1hcCgoZW50cnkpID0+IGRlY29kZShlbnRyeSkpXG4gICAgICAgICAgOiBnLnJlcGVhdFxuICAgICAgICAgID8gW2RlY29kZShtKV1cbiAgICAgICAgICA6IGRlY29kZShtKVxuICAgICAgfVxuICAgIH0pXG4gICAgcmV0dXJuIHBhcmFtc1xuICB9XG59XG4iLCJleHBvcnQgaW50ZXJmYWNlIEdyb3VwIHtcbiAgcG9zOiBudW1iZXJcbiAgcmVwZWF0OiBib29sZWFuXG4gIG9wdGlvbmFsOiBib29sZWFuXG59XG5cbi8vIHRoaXMgaXNuJ3QgaW1wb3J0aW5nIHRoZSBlc2NhcGUtc3RyaW5nLXJlZ2V4IG1vZHVsZVxuLy8gdG8gcmVkdWNlIGJ5dGVzXG5mdW5jdGlvbiBlc2NhcGVSZWdleChzdHI6IHN0cmluZykge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoL1t8XFxcXHt9KClbXFxdXiQrKj8uLV0vZywgJ1xcXFwkJicpXG59XG5cbmZ1bmN0aW9uIHBhcnNlUGFyYW1ldGVyKHBhcmFtOiBzdHJpbmcpIHtcbiAgY29uc3Qgb3B0aW9uYWwgPSBwYXJhbS5zdGFydHNXaXRoKCdbJykgJiYgcGFyYW0uZW5kc1dpdGgoJ10nKVxuICBpZiAob3B0aW9uYWwpIHtcbiAgICBwYXJhbSA9IHBhcmFtLnNsaWNlKDEsIC0xKVxuICB9XG4gIGNvbnN0IHJlcGVhdCA9IHBhcmFtLnN0YXJ0c1dpdGgoJy4uLicpXG4gIGlmIChyZXBlYXQpIHtcbiAgICBwYXJhbSA9IHBhcmFtLnNsaWNlKDMpXG4gIH1cbiAgcmV0dXJuIHsga2V5OiBwYXJhbSwgcmVwZWF0LCBvcHRpb25hbCB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRSb3V0ZVJlZ2V4KFxuICBub3JtYWxpemVkUm91dGU6IHN0cmluZ1xuKToge1xuICByZTogUmVnRXhwXG4gIG5hbWVkUmVnZXg/OiBzdHJpbmdcbiAgcm91dGVLZXlzPzogeyBbbmFtZWQ6IHN0cmluZ106IHN0cmluZyB9XG4gIGdyb3VwczogeyBbZ3JvdXBOYW1lOiBzdHJpbmddOiBHcm91cCB9XG59IHtcbiAgY29uc3Qgc2VnbWVudHMgPSAobm9ybWFsaXplZFJvdXRlLnJlcGxhY2UoL1xcLyQvLCAnJykgfHwgJy8nKVxuICAgIC5zbGljZSgxKVxuICAgIC5zcGxpdCgnLycpXG5cbiAgY29uc3QgZ3JvdXBzOiB7IFtncm91cE5hbWU6IHN0cmluZ106IEdyb3VwIH0gPSB7fVxuICBsZXQgZ3JvdXBJbmRleCA9IDFcbiAgY29uc3QgcGFyYW1ldGVyaXplZFJvdXRlID0gc2VnbWVudHNcbiAgICAubWFwKChzZWdtZW50KSA9PiB7XG4gICAgICBpZiAoc2VnbWVudC5zdGFydHNXaXRoKCdbJykgJiYgc2VnbWVudC5lbmRzV2l0aCgnXScpKSB7XG4gICAgICAgIGNvbnN0IHsga2V5LCBvcHRpb25hbCwgcmVwZWF0IH0gPSBwYXJzZVBhcmFtZXRlcihzZWdtZW50LnNsaWNlKDEsIC0xKSlcbiAgICAgICAgZ3JvdXBzW2tleV0gPSB7IHBvczogZ3JvdXBJbmRleCsrLCByZXBlYXQsIG9wdGlvbmFsIH1cbiAgICAgICAgcmV0dXJuIHJlcGVhdCA/IChvcHRpb25hbCA/ICcoPzovKC4rPykpPycgOiAnLyguKz8pJykgOiAnLyhbXi9dKz8pJ1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGAvJHtlc2NhcGVSZWdleChzZWdtZW50KX1gXG4gICAgICB9XG4gICAgfSlcbiAgICAuam9pbignJylcblxuICAvLyBkZWFkIGNvZGUgZWxpbWluYXRlIGZvciBicm93c2VyIHNpbmNlIGl0J3Mgb25seSBuZWVkZWRcbiAgLy8gd2hpbGUgZ2VuZXJhdGluZyByb3V0ZXMtbWFuaWZlc3RcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgbGV0IHJvdXRlS2V5Q2hhckNvZGUgPSA5N1xuICAgIGxldCByb3V0ZUtleUNoYXJMZW5ndGggPSAxXG5cbiAgICAvLyBidWlsZHMgYSBtaW5pbWFsIHJvdXRlS2V5IHVzaW5nIG9ubHkgYS16IGFuZCBtaW5pbWFsIG51bWJlciBvZiBjaGFyYWN0ZXJzXG4gICAgY29uc3QgZ2V0U2FmZVJvdXRlS2V5ID0gKCkgPT4ge1xuICAgICAgbGV0IHJvdXRlS2V5ID0gJydcblxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3V0ZUtleUNoYXJMZW5ndGg7IGkrKykge1xuICAgICAgICByb3V0ZUtleSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHJvdXRlS2V5Q2hhckNvZGUpXG4gICAgICAgIHJvdXRlS2V5Q2hhckNvZGUrK1xuXG4gICAgICAgIGlmIChyb3V0ZUtleUNoYXJDb2RlID4gMTIyKSB7XG4gICAgICAgICAgcm91dGVLZXlDaGFyTGVuZ3RoKytcbiAgICAgICAgICByb3V0ZUtleUNoYXJDb2RlID0gOTdcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHJvdXRlS2V5XG4gICAgfVxuXG4gICAgY29uc3Qgcm91dGVLZXlzOiB7IFtuYW1lZDogc3RyaW5nXTogc3RyaW5nIH0gPSB7fVxuXG4gICAgbGV0IG5hbWVkUGFyYW1ldGVyaXplZFJvdXRlID0gc2VnbWVudHNcbiAgICAgIC5tYXAoKHNlZ21lbnQpID0+IHtcbiAgICAgICAgaWYgKHNlZ21lbnQuc3RhcnRzV2l0aCgnWycpICYmIHNlZ21lbnQuZW5kc1dpdGgoJ10nKSkge1xuICAgICAgICAgIGNvbnN0IHsga2V5LCBvcHRpb25hbCwgcmVwZWF0IH0gPSBwYXJzZVBhcmFtZXRlcihzZWdtZW50LnNsaWNlKDEsIC0xKSlcbiAgICAgICAgICAvLyByZXBsYWNlIGFueSBub24td29yZCBjaGFyYWN0ZXJzIHNpbmNlIHRoZXkgY2FuIGJyZWFrXG4gICAgICAgICAgLy8gdGhlIG5hbWVkIHJlZ2V4XG4gICAgICAgICAgbGV0IGNsZWFuZWRLZXkgPSBrZXkucmVwbGFjZSgvXFxXL2csICcnKVxuICAgICAgICAgIGxldCBpbnZhbGlkS2V5ID0gZmFsc2VcblxuICAgICAgICAgIC8vIGNoZWNrIGlmIHRoZSBrZXkgaXMgc3RpbGwgaW52YWxpZCBhbmQgZmFsbGJhY2sgdG8gdXNpbmcgYSBrbm93blxuICAgICAgICAgIC8vIHNhZmUga2V5XG4gICAgICAgICAgaWYgKGNsZWFuZWRLZXkubGVuZ3RoID09PSAwIHx8IGNsZWFuZWRLZXkubGVuZ3RoID4gMzApIHtcbiAgICAgICAgICAgIGludmFsaWRLZXkgPSB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VJbnQoY2xlYW5lZEtleS5zdWJzdHIoMCwgMSkpKSkge1xuICAgICAgICAgICAgaW52YWxpZEtleSA9IHRydWVcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoaW52YWxpZEtleSkge1xuICAgICAgICAgICAgY2xlYW5lZEtleSA9IGdldFNhZmVSb3V0ZUtleSgpXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcm91dGVLZXlzW2NsZWFuZWRLZXldID0ga2V5XG4gICAgICAgICAgcmV0dXJuIHJlcGVhdFxuICAgICAgICAgICAgPyBvcHRpb25hbFxuICAgICAgICAgICAgICA/IGAoPzovKD88JHtjbGVhbmVkS2V5fT4uKz8pKT9gXG4gICAgICAgICAgICAgIDogYC8oPzwke2NsZWFuZWRLZXl9Pi4rPylgXG4gICAgICAgICAgICA6IGAvKD88JHtjbGVhbmVkS2V5fT5bXi9dKz8pYFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBgLyR7ZXNjYXBlUmVnZXgoc2VnbWVudCl9YFxuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmpvaW4oJycpXG5cbiAgICByZXR1cm4ge1xuICAgICAgcmU6IG5ldyBSZWdFeHAoYF4ke3BhcmFtZXRlcml6ZWRSb3V0ZX0oPzovKT8kYCksXG4gICAgICBncm91cHMsXG4gICAgICByb3V0ZUtleXMsXG4gICAgICBuYW1lZFJlZ2V4OiBgXiR7bmFtZWRQYXJhbWV0ZXJpemVkUm91dGV9KD86Lyk/JGAsXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICByZTogbmV3IFJlZ0V4cChgXiR7cGFyYW1ldGVyaXplZFJvdXRlfSg/Oi8pPyRgKSxcbiAgICBncm91cHMsXG4gIH1cbn1cbiIsImltcG9ydCB7IEluY29taW5nTWVzc2FnZSwgU2VydmVyUmVzcG9uc2UgfSBmcm9tICdodHRwJ1xuaW1wb3J0IHsgUGFyc2VkVXJsUXVlcnkgfSBmcm9tICdxdWVyeXN0cmluZydcbmltcG9ydCB7IENvbXBvbmVudFR5cGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFVybE9iamVjdCB9IGZyb20gJ3VybCdcbmltcG9ydCB7IGZvcm1hdFVybCB9IGZyb20gJy4vcm91dGVyL3V0aWxzL2Zvcm1hdC11cmwnXG5pbXBvcnQgeyBNYW5pZmVzdEl0ZW0gfSBmcm9tICcuLi9zZXJ2ZXIvbG9hZC1jb21wb25lbnRzJ1xuaW1wb3J0IHsgTmV4dFJvdXRlciB9IGZyb20gJy4vcm91dGVyL3JvdXRlcidcbmltcG9ydCB7IEVudiB9IGZyb20gJ0BuZXh0L2VudidcbmltcG9ydCB7IEJ1aWxkTWFuaWZlc3QgfSBmcm9tICcuLi9zZXJ2ZXIvZ2V0LXBhZ2UtZmlsZXMnXG5pbXBvcnQgeyBEb21haW5Mb2NhbGVzIH0gZnJvbSAnLi4vc2VydmVyL2NvbmZpZydcblxuLyoqXG4gKiBUeXBlcyB1c2VkIGJ5IGJvdGggbmV4dCBhbmQgbmV4dC1zZXJ2ZXJcbiAqL1xuXG5leHBvcnQgdHlwZSBOZXh0Q29tcG9uZW50VHlwZTxcbiAgQyBleHRlbmRzIEJhc2VDb250ZXh0ID0gTmV4dFBhZ2VDb250ZXh0LFxuICBJUCA9IHt9LFxuICBQID0ge31cbj4gPSBDb21wb25lbnRUeXBlPFA+ICYge1xuICAvKipcbiAgICogVXNlZCBmb3IgaW5pdGlhbCBwYWdlIGxvYWQgZGF0YSBwb3B1bGF0aW9uLiBEYXRhIHJldHVybmVkIGZyb20gYGdldEluaXRpYWxQcm9wc2AgaXMgc2VyaWFsaXplZCB3aGVuIHNlcnZlciByZW5kZXJlZC5cbiAgICogTWFrZSBzdXJlIHRvIHJldHVybiBwbGFpbiBgT2JqZWN0YCB3aXRob3V0IHVzaW5nIGBEYXRlYCwgYE1hcGAsIGBTZXRgLlxuICAgKiBAcGFyYW0gY3R4IENvbnRleHQgb2YgYHBhZ2VgXG4gICAqL1xuICBnZXRJbml0aWFsUHJvcHM/KGNvbnRleHQ6IEMpOiBJUCB8IFByb21pc2U8SVA+XG59XG5cbmV4cG9ydCB0eXBlIERvY3VtZW50VHlwZSA9IE5leHRDb21wb25lbnRUeXBlPFxuICBEb2N1bWVudENvbnRleHQsXG4gIERvY3VtZW50SW5pdGlhbFByb3BzLFxuICBEb2N1bWVudFByb3BzXG4+ICYge1xuICByZW5kZXJEb2N1bWVudChcbiAgICBEb2N1bWVudDogRG9jdW1lbnRUeXBlLFxuICAgIHByb3BzOiBEb2N1bWVudFByb3BzXG4gICk6IFJlYWN0LlJlYWN0RWxlbWVudFxufVxuXG5leHBvcnQgdHlwZSBBcHBUeXBlID0gTmV4dENvbXBvbmVudFR5cGU8XG4gIEFwcENvbnRleHRUeXBlLFxuICBBcHBJbml0aWFsUHJvcHMsXG4gIEFwcFByb3BzVHlwZVxuPlxuXG5leHBvcnQgdHlwZSBBcHBUcmVlVHlwZSA9IENvbXBvbmVudFR5cGU8XG4gIEFwcEluaXRpYWxQcm9wcyAmIHsgW25hbWU6IHN0cmluZ106IGFueSB9XG4+XG5cbi8qKlxuICogV2ViIHZpdGFscyBwcm92aWRlZCB0byBfYXBwLnJlcG9ydFdlYlZpdGFscyBieSBDb3JlIFdlYiBWaXRhbHMgcGx1Z2luIGRldmVsb3BlZCBieSBHb29nbGUgQ2hyb21lIHRlYW0uXG4gKiBodHRwczovL25leHRqcy5vcmcvYmxvZy9uZXh0LTktNCNpbnRlZ3JhdGVkLXdlYi12aXRhbHMtcmVwb3J0aW5nXG4gKi9cbmV4cG9ydCB0eXBlIE5leHRXZWJWaXRhbHNNZXRyaWMgPSB7XG4gIGlkOiBzdHJpbmdcbiAgbGFiZWw6IHN0cmluZ1xuICBuYW1lOiBzdHJpbmdcbiAgc3RhcnRUaW1lOiBudW1iZXJcbiAgdmFsdWU6IG51bWJlclxufVxuXG5leHBvcnQgdHlwZSBFbmhhbmNlcjxDPiA9IChDb21wb25lbnQ6IEMpID0+IENcblxuZXhwb3J0IHR5cGUgQ29tcG9uZW50c0VuaGFuY2VyID1cbiAgfCB7XG4gICAgICBlbmhhbmNlQXBwPzogRW5oYW5jZXI8QXBwVHlwZT5cbiAgICAgIGVuaGFuY2VDb21wb25lbnQ/OiBFbmhhbmNlcjxOZXh0Q29tcG9uZW50VHlwZT5cbiAgICB9XG4gIHwgRW5oYW5jZXI8TmV4dENvbXBvbmVudFR5cGU+XG5cbmV4cG9ydCB0eXBlIFJlbmRlclBhZ2VSZXN1bHQgPSB7XG4gIGh0bWw6IHN0cmluZ1xuICBoZWFkPzogQXJyYXk8SlNYLkVsZW1lbnQgfCBudWxsPlxufVxuXG5leHBvcnQgdHlwZSBSZW5kZXJQYWdlID0gKFxuICBvcHRpb25zPzogQ29tcG9uZW50c0VuaGFuY2VyXG4pID0+IFJlbmRlclBhZ2VSZXN1bHQgfCBQcm9taXNlPFJlbmRlclBhZ2VSZXN1bHQ+XG5cbmV4cG9ydCB0eXBlIEJhc2VDb250ZXh0ID0ge1xuICByZXM/OiBTZXJ2ZXJSZXNwb25zZVxuICBbazogc3RyaW5nXTogYW55XG59XG5cbmV4cG9ydCB0eXBlIE5FWFRfREFUQSA9IHtcbiAgcHJvcHM6IFJlY29yZDxzdHJpbmcsIGFueT5cbiAgcGFnZTogc3RyaW5nXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICBidWlsZElkOiBzdHJpbmdcbiAgYXNzZXRQcmVmaXg/OiBzdHJpbmdcbiAgcnVudGltZUNvbmZpZz86IHsgW2tleTogc3RyaW5nXTogYW55IH1cbiAgbmV4dEV4cG9ydD86IGJvb2xlYW5cbiAgYXV0b0V4cG9ydD86IGJvb2xlYW5cbiAgaXNGYWxsYmFjaz86IGJvb2xlYW5cbiAgZHluYW1pY0lkcz86IHN0cmluZ1tdXG4gIGVycj86IEVycm9yICYgeyBzdGF0dXNDb2RlPzogbnVtYmVyIH1cbiAgZ3NwPzogYm9vbGVhblxuICBnc3NwPzogYm9vbGVhblxuICBjdXN0b21TZXJ2ZXI/OiBib29sZWFuXG4gIGdpcD86IGJvb2xlYW5cbiAgYXBwR2lwPzogYm9vbGVhblxuICBsb2NhbGU/OiBzdHJpbmdcbiAgbG9jYWxlcz86IHN0cmluZ1tdXG4gIGRlZmF1bHRMb2NhbGU/OiBzdHJpbmdcbiAgZG9tYWluTG9jYWxlcz86IERvbWFpbkxvY2FsZXNcbiAgc2NyaXB0TG9hZGVyPzogYW55W11cbiAgaXNQcmV2aWV3PzogYm9vbGVhblxufVxuXG4vKipcbiAqIGBOZXh0YCBjb250ZXh0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTmV4dFBhZ2VDb250ZXh0IHtcbiAgLyoqXG4gICAqIEVycm9yIG9iamVjdCBpZiBlbmNvdW50ZXJlZCBkdXJpbmcgcmVuZGVyaW5nXG4gICAqL1xuICBlcnI/OiAoRXJyb3IgJiB7IHN0YXR1c0NvZGU/OiBudW1iZXIgfSkgfCBudWxsXG4gIC8qKlxuICAgKiBgSFRUUGAgcmVxdWVzdCBvYmplY3QuXG4gICAqL1xuICByZXE/OiBJbmNvbWluZ01lc3NhZ2VcbiAgLyoqXG4gICAqIGBIVFRQYCByZXNwb25zZSBvYmplY3QuXG4gICAqL1xuICByZXM/OiBTZXJ2ZXJSZXNwb25zZVxuICAvKipcbiAgICogUGF0aCBzZWN0aW9uIG9mIGBVUkxgLlxuICAgKi9cbiAgcGF0aG5hbWU6IHN0cmluZ1xuICAvKipcbiAgICogUXVlcnkgc3RyaW5nIHNlY3Rpb24gb2YgYFVSTGAgcGFyc2VkIGFzIGFuIG9iamVjdC5cbiAgICovXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICAvKipcbiAgICogYFN0cmluZ2Agb2YgdGhlIGFjdHVhbCBwYXRoIGluY2x1ZGluZyBxdWVyeS5cbiAgICovXG4gIGFzUGF0aD86IHN0cmluZ1xuICAvKipcbiAgICogYENvbXBvbmVudGAgdGhlIHRyZWUgb2YgdGhlIEFwcCB0byB1c2UgaWYgbmVlZGluZyB0byByZW5kZXIgc2VwYXJhdGVseVxuICAgKi9cbiAgQXBwVHJlZTogQXBwVHJlZVR5cGVcbn1cblxuZXhwb3J0IHR5cGUgQXBwQ29udGV4dFR5cGU8UiBleHRlbmRzIE5leHRSb3V0ZXIgPSBOZXh0Um91dGVyPiA9IHtcbiAgQ29tcG9uZW50OiBOZXh0Q29tcG9uZW50VHlwZTxOZXh0UGFnZUNvbnRleHQ+XG4gIEFwcFRyZWU6IEFwcFRyZWVUeXBlXG4gIGN0eDogTmV4dFBhZ2VDb250ZXh0XG4gIHJvdXRlcjogUlxufVxuXG5leHBvcnQgdHlwZSBBcHBJbml0aWFsUHJvcHMgPSB7XG4gIHBhZ2VQcm9wczogYW55XG59XG5cbmV4cG9ydCB0eXBlIEFwcFByb3BzVHlwZTxcbiAgUiBleHRlbmRzIE5leHRSb3V0ZXIgPSBOZXh0Um91dGVyLFxuICBQID0ge31cbj4gPSBBcHBJbml0aWFsUHJvcHMgJiB7XG4gIENvbXBvbmVudDogTmV4dENvbXBvbmVudFR5cGU8TmV4dFBhZ2VDb250ZXh0LCBhbnksIFA+XG4gIHJvdXRlcjogUlxuICBfX05fU1NHPzogYm9vbGVhblxuICBfX05fU1NQPzogYm9vbGVhblxufVxuXG5leHBvcnQgdHlwZSBEb2N1bWVudENvbnRleHQgPSBOZXh0UGFnZUNvbnRleHQgJiB7XG4gIHJlbmRlclBhZ2U6IFJlbmRlclBhZ2Vcbn1cblxuZXhwb3J0IHR5cGUgRG9jdW1lbnRJbml0aWFsUHJvcHMgPSBSZW5kZXJQYWdlUmVzdWx0ICYge1xuICBzdHlsZXM/OiBSZWFjdC5SZWFjdEVsZW1lbnRbXSB8IFJlYWN0LlJlYWN0RnJhZ21lbnRcbn1cblxuZXhwb3J0IHR5cGUgRG9jdW1lbnRQcm9wcyA9IERvY3VtZW50SW5pdGlhbFByb3BzICYge1xuICBfX05FWFRfREFUQV9fOiBORVhUX0RBVEFcbiAgZGFuZ2Vyb3VzQXNQYXRoOiBzdHJpbmdcbiAgZG9jQ29tcG9uZW50c1JlbmRlcmVkOiB7XG4gICAgSHRtbD86IGJvb2xlYW5cbiAgICBNYWluPzogYm9vbGVhblxuICAgIEhlYWQ/OiBib29sZWFuXG4gICAgTmV4dFNjcmlwdD86IGJvb2xlYW5cbiAgfVxuICBidWlsZE1hbmlmZXN0OiBCdWlsZE1hbmlmZXN0XG4gIGFtcFBhdGg6IHN0cmluZ1xuICBpbkFtcE1vZGU6IGJvb2xlYW5cbiAgaHlicmlkQW1wOiBib29sZWFuXG4gIGlzRGV2ZWxvcG1lbnQ6IGJvb2xlYW5cbiAgZHluYW1pY0ltcG9ydHM6IE1hbmlmZXN0SXRlbVtdXG4gIGFzc2V0UHJlZml4Pzogc3RyaW5nXG4gIGNhbm9uaWNhbEJhc2U6IHN0cmluZ1xuICBoZWFkVGFnczogYW55W11cbiAgdW5zdGFibGVfcnVudGltZUpTPzogZmFsc2VcbiAgdW5zdGFibGVfSnNQcmVsb2FkPzogZmFsc2VcbiAgZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmc6IHN0cmluZ1xuICBzY3JpcHRMb2FkZXI6IHsgZGVmZXI/OiBzdHJpbmdbXTsgZWFnZXI/OiBhbnlbXSB9XG4gIGxvY2FsZT86IHN0cmluZ1xufVxuXG4vKipcbiAqIE5leHQgYEFQSWAgcm91dGUgcmVxdWVzdFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5leHRBcGlSZXF1ZXN0IGV4dGVuZHMgSW5jb21pbmdNZXNzYWdlIHtcbiAgLyoqXG4gICAqIE9iamVjdCBvZiBgcXVlcnlgIHZhbHVlcyBmcm9tIHVybFxuICAgKi9cbiAgcXVlcnk6IHtcbiAgICBba2V5OiBzdHJpbmddOiBzdHJpbmcgfCBzdHJpbmdbXVxuICB9XG4gIC8qKlxuICAgKiBPYmplY3Qgb2YgYGNvb2tpZXNgIGZyb20gaGVhZGVyXG4gICAqL1xuICBjb29raWVzOiB7XG4gICAgW2tleTogc3RyaW5nXTogc3RyaW5nXG4gIH1cblxuICBib2R5OiBhbnlcblxuICBlbnY6IEVudlxuXG4gIHByZXZpZXc/OiBib29sZWFuXG4gIC8qKlxuICAgKiBQcmV2aWV3IGRhdGEgc2V0IG9uIHRoZSByZXF1ZXN0LCBpZiBhbnlcbiAgICogKi9cbiAgcHJldmlld0RhdGE/OiBhbnlcbn1cblxuLyoqXG4gKiBTZW5kIGJvZHkgb2YgcmVzcG9uc2VcbiAqL1xudHlwZSBTZW5kPFQ+ID0gKGJvZHk6IFQpID0+IHZvaWRcblxuLyoqXG4gKiBOZXh0IGBBUElgIHJvdXRlIHJlc3BvbnNlXG4gKi9cbmV4cG9ydCB0eXBlIE5leHRBcGlSZXNwb25zZTxUID0gYW55PiA9IFNlcnZlclJlc3BvbnNlICYge1xuICAvKipcbiAgICogU2VuZCBkYXRhIGBhbnlgIGRhdGEgaW4gcmVzcG9uc2VcbiAgICovXG4gIHNlbmQ6IFNlbmQ8VD5cbiAgLyoqXG4gICAqIFNlbmQgZGF0YSBganNvbmAgZGF0YSBpbiByZXNwb25zZVxuICAgKi9cbiAganNvbjogU2VuZDxUPlxuICBzdGF0dXM6IChzdGF0dXNDb2RlOiBudW1iZXIpID0+IE5leHRBcGlSZXNwb25zZTxUPlxuICByZWRpcmVjdCh1cmw6IHN0cmluZyk6IE5leHRBcGlSZXNwb25zZTxUPlxuICByZWRpcmVjdChzdGF0dXM6IG51bWJlciwgdXJsOiBzdHJpbmcpOiBOZXh0QXBpUmVzcG9uc2U8VD5cblxuICAvKipcbiAgICogU2V0IHByZXZpZXcgZGF0YSBmb3IgTmV4dC5qcycgcHJlcmVuZGVyIG1vZGVcbiAgICovXG4gIHNldFByZXZpZXdEYXRhOiAoXG4gICAgZGF0YTogb2JqZWN0IHwgc3RyaW5nLFxuICAgIG9wdGlvbnM/OiB7XG4gICAgICAvKipcbiAgICAgICAqIFNwZWNpZmllcyB0aGUgbnVtYmVyIChpbiBzZWNvbmRzKSBmb3IgdGhlIHByZXZpZXcgc2Vzc2lvbiB0byBsYXN0IGZvci5cbiAgICAgICAqIFRoZSBnaXZlbiBudW1iZXIgd2lsbCBiZSBjb252ZXJ0ZWQgdG8gYW4gaW50ZWdlciBieSByb3VuZGluZyBkb3duLlxuICAgICAgICogQnkgZGVmYXVsdCwgbm8gbWF4aW11bSBhZ2UgaXMgc2V0IGFuZCB0aGUgcHJldmlldyBzZXNzaW9uIGZpbmlzaGVzXG4gICAgICAgKiB3aGVuIHRoZSBjbGllbnQgc2h1dHMgZG93biAoYnJvd3NlciBpcyBjbG9zZWQpLlxuICAgICAgICovXG4gICAgICBtYXhBZ2U/OiBudW1iZXJcbiAgICB9XG4gICkgPT4gTmV4dEFwaVJlc3BvbnNlPFQ+XG4gIGNsZWFyUHJldmlld0RhdGE6ICgpID0+IE5leHRBcGlSZXNwb25zZTxUPlxufVxuXG4vKipcbiAqIE5leHQgYEFQSWAgcm91dGUgaGFuZGxlclxuICovXG5leHBvcnQgdHlwZSBOZXh0QXBpSGFuZGxlcjxUID0gYW55PiA9IChcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcbiAgcmVzOiBOZXh0QXBpUmVzcG9uc2U8VD5cbikgPT4gdm9pZCB8IFByb21pc2U8dm9pZD5cblxuLyoqXG4gKiBVdGlsc1xuICovXG5leHBvcnQgZnVuY3Rpb24gZXhlY09uY2U8VCBleHRlbmRzICguLi5hcmdzOiBhbnlbXSkgPT4gUmV0dXJuVHlwZTxUPj4oXG4gIGZuOiBUXG4pOiBUIHtcbiAgbGV0IHVzZWQgPSBmYWxzZVxuICBsZXQgcmVzdWx0OiBSZXR1cm5UeXBlPFQ+XG5cbiAgcmV0dXJuICgoLi4uYXJnczogYW55W10pID0+IHtcbiAgICBpZiAoIXVzZWQpIHtcbiAgICAgIHVzZWQgPSB0cnVlXG4gICAgICByZXN1bHQgPSBmbiguLi5hcmdzKVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0XG4gIH0pIGFzIFRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2F0aW9uT3JpZ2luKCkge1xuICBjb25zdCB7IHByb3RvY29sLCBob3N0bmFtZSwgcG9ydCB9ID0gd2luZG93LmxvY2F0aW9uXG4gIHJldHVybiBgJHtwcm90b2NvbH0vLyR7aG9zdG5hbWV9JHtwb3J0ID8gJzonICsgcG9ydCA6ICcnfWBcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFVSTCgpIHtcbiAgY29uc3QgeyBocmVmIH0gPSB3aW5kb3cubG9jYXRpb25cbiAgY29uc3Qgb3JpZ2luID0gZ2V0TG9jYXRpb25PcmlnaW4oKVxuICByZXR1cm4gaHJlZi5zdWJzdHJpbmcob3JpZ2luLmxlbmd0aClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldERpc3BsYXlOYW1lPFA+KENvbXBvbmVudDogQ29tcG9uZW50VHlwZTxQPikge1xuICByZXR1cm4gdHlwZW9mIENvbXBvbmVudCA9PT0gJ3N0cmluZydcbiAgICA/IENvbXBvbmVudFxuICAgIDogQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNSZXNTZW50KHJlczogU2VydmVyUmVzcG9uc2UpIHtcbiAgcmV0dXJuIHJlcy5maW5pc2hlZCB8fCByZXMuaGVhZGVyc1NlbnRcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRHZXRJbml0aWFsUHJvcHM8XG4gIEMgZXh0ZW5kcyBCYXNlQ29udGV4dCxcbiAgSVAgPSB7fSxcbiAgUCA9IHt9XG4+KEFwcDogTmV4dENvbXBvbmVudFR5cGU8QywgSVAsIFA+LCBjdHg6IEMpOiBQcm9taXNlPElQPiB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgaWYgKEFwcC5wcm90b3R5cGU/LmdldEluaXRpYWxQcm9wcykge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IGBcIiR7Z2V0RGlzcGxheU5hbWUoXG4gICAgICAgIEFwcFxuICAgICAgKX0uZ2V0SW5pdGlhbFByb3BzKClcIiBpcyBkZWZpbmVkIGFzIGFuIGluc3RhbmNlIG1ldGhvZCAtIHZpc2l0IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2dldC1pbml0aWFsLXByb3BzLWFzLWFuLWluc3RhbmNlLW1ldGhvZCBmb3IgbW9yZSBpbmZvcm1hdGlvbi5gXG4gICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSlcbiAgICB9XG4gIH1cbiAgLy8gd2hlbiBjYWxsZWQgZnJvbSBfYXBwIGBjdHhgIGlzIG5lc3RlZCBpbiBgY3R4YFxuICBjb25zdCByZXMgPSBjdHgucmVzIHx8IChjdHguY3R4ICYmIGN0eC5jdHgucmVzKVxuXG4gIGlmICghQXBwLmdldEluaXRpYWxQcm9wcykge1xuICAgIGlmIChjdHguY3R4ICYmIGN0eC5Db21wb25lbnQpIHtcbiAgICAgIC8vIEB0cy1pZ25vcmUgcGFnZVByb3BzIGRlZmF1bHRcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHBhZ2VQcm9wczogYXdhaXQgbG9hZEdldEluaXRpYWxQcm9wcyhjdHguQ29tcG9uZW50LCBjdHguY3R4KSxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHt9IGFzIElQXG4gIH1cblxuICBjb25zdCBwcm9wcyA9IGF3YWl0IEFwcC5nZXRJbml0aWFsUHJvcHMoY3R4KVxuXG4gIGlmIChyZXMgJiYgaXNSZXNTZW50KHJlcykpIHtcbiAgICByZXR1cm4gcHJvcHNcbiAgfVxuXG4gIGlmICghcHJvcHMpIHtcbiAgICBjb25zdCBtZXNzYWdlID0gYFwiJHtnZXREaXNwbGF5TmFtZShcbiAgICAgIEFwcFxuICAgICl9LmdldEluaXRpYWxQcm9wcygpXCIgc2hvdWxkIHJlc29sdmUgdG8gYW4gb2JqZWN0LiBCdXQgZm91bmQgXCIke3Byb3BzfVwiIGluc3RlYWQuYFxuICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKVxuICB9XG5cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoT2JqZWN0LmtleXMocHJvcHMpLmxlbmd0aCA9PT0gMCAmJiAhY3R4LmN0eCkge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBgJHtnZXREaXNwbGF5TmFtZShcbiAgICAgICAgICBBcHBcbiAgICAgICAgKX0gcmV0dXJuZWQgYW4gZW1wdHkgb2JqZWN0IGZyb20gXFxgZ2V0SW5pdGlhbFByb3BzXFxgLiBUaGlzIGRlLW9wdGltaXplcyBhbmQgcHJldmVudHMgYXV0b21hdGljIHN0YXRpYyBvcHRpbWl6YXRpb24uIGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2VtcHR5LW9iamVjdC1nZXRJbml0aWFsUHJvcHNgXG4gICAgICApXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHByb3BzXG59XG5cbmV4cG9ydCBjb25zdCB1cmxPYmplY3RLZXlzID0gW1xuICAnYXV0aCcsXG4gICdoYXNoJyxcbiAgJ2hvc3QnLFxuICAnaG9zdG5hbWUnLFxuICAnaHJlZicsXG4gICdwYXRoJyxcbiAgJ3BhdGhuYW1lJyxcbiAgJ3BvcnQnLFxuICAncHJvdG9jb2wnLFxuICAncXVlcnknLFxuICAnc2VhcmNoJyxcbiAgJ3NsYXNoZXMnLFxuXVxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0V2l0aFZhbGlkYXRpb24odXJsOiBVcmxPYmplY3QpOiBzdHJpbmcge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICBpZiAodXJsICE9PSBudWxsICYmIHR5cGVvZiB1cmwgPT09ICdvYmplY3QnKSB7XG4gICAgICBPYmplY3Qua2V5cyh1cmwpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBpZiAodXJsT2JqZWN0S2V5cy5pbmRleE9mKGtleSkgPT09IC0xKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgYFVua25vd24ga2V5IHBhc3NlZCB2aWEgdXJsT2JqZWN0IGludG8gdXJsLmZvcm1hdDogJHtrZXl9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZm9ybWF0VXJsKHVybClcbn1cblxuZXhwb3J0IGNvbnN0IFNQID0gdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJ1xuZXhwb3J0IGNvbnN0IFNUID1cbiAgU1AgJiZcbiAgdHlwZW9mIHBlcmZvcm1hbmNlLm1hcmsgPT09ICdmdW5jdGlvbicgJiZcbiAgdHlwZW9mIHBlcmZvcm1hbmNlLm1lYXN1cmUgPT09ICdmdW5jdGlvbidcbiIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMubm9ybWFsaXplUGF0aFNlcD1ub3JtYWxpemVQYXRoU2VwO2V4cG9ydHMuZGVub3JtYWxpemVQYWdlUGF0aD1kZW5vcm1hbGl6ZVBhZ2VQYXRoO2Z1bmN0aW9uIG5vcm1hbGl6ZVBhdGhTZXAocGF0aCl7cmV0dXJuIHBhdGgucmVwbGFjZSgvXFxcXC9nLCcvJyk7fWZ1bmN0aW9uIGRlbm9ybWFsaXplUGFnZVBhdGgocGFnZSl7cGFnZT1ub3JtYWxpemVQYXRoU2VwKHBhZ2UpO2lmKHBhZ2Uuc3RhcnRzV2l0aCgnL2luZGV4LycpKXtwYWdlPXBhZ2Uuc2xpY2UoNik7fWVsc2UgaWYocGFnZT09PScvaW5kZXgnKXtwYWdlPScvJzt9cmV0dXJuIHBhZ2U7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVub3JtYWxpemUtcGFnZS1wYXRoLmpzLm1hcCIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9saW5rJylcbiIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwidmFyIF90eXBlb2YgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2ZcIik7XG5cbmZ1bmN0aW9uIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpIHtcbiAgaWYgKHR5cGVvZiBXZWFrTWFwICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuICB2YXIgY2FjaGUgPSBuZXcgV2Vha01hcCgpO1xuXG4gIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSA9IGZ1bmN0aW9uIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpIHtcbiAgICByZXR1cm4gY2FjaGU7XG4gIH07XG5cbiAgcmV0dXJuIGNhY2hlO1xufVxuXG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZChvYmopIHtcbiAgaWYgKG9iaiAmJiBvYmouX19lc01vZHVsZSkge1xuICAgIHJldHVybiBvYmo7XG4gIH1cblxuICBpZiAob2JqID09PSBudWxsIHx8IF90eXBlb2Yob2JqKSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2Ygb2JqICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgXCJkZWZhdWx0XCI6IG9ialxuICAgIH07XG4gIH1cblxuICB2YXIgY2FjaGUgPSBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUoKTtcblxuICBpZiAoY2FjaGUgJiYgY2FjaGUuaGFzKG9iaikpIHtcbiAgICByZXR1cm4gY2FjaGUuZ2V0KG9iaik7XG4gIH1cblxuICB2YXIgbmV3T2JqID0ge307XG4gIHZhciBoYXNQcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZGVmaW5lUHJvcGVydHkgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxuICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGtleSkpIHtcbiAgICAgIHZhciBkZXNjID0gaGFzUHJvcGVydHlEZXNjcmlwdG9yID8gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosIGtleSkgOiBudWxsO1xuXG4gICAgICBpZiAoZGVzYyAmJiAoZGVzYy5nZXQgfHwgZGVzYy5zZXQpKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShuZXdPYmosIGtleSwgZGVzYyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBuZXdPYmpba2V5XSA9IG9ialtrZXldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG5ld09ialtcImRlZmF1bHRcIl0gPSBvYmo7XG5cbiAgaWYgKGNhY2hlKSB7XG4gICAgY2FjaGUuc2V0KG9iaiwgbmV3T2JqKTtcbiAgfVxuXG4gIHJldHVybiBuZXdPYmo7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQ7IiwiZnVuY3Rpb24gX3R5cGVvZihvYmopIHtcbiAgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiO1xuXG4gIGlmICh0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gXCJzeW1ib2xcIikge1xuICAgIG1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiA9IGZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gICAgICByZXR1cm4gdHlwZW9mIG9iajtcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiA9IGZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gICAgICByZXR1cm4gb2JqICYmIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvYmouY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBvYmogIT09IFN5bWJvbC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG9iajtcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIF90eXBlb2Yob2JqKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfdHlwZW9mOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBBY2Nlc3NvcmllcyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxNScgZmlsbD17Y29sb3J9PlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA1MydcbiAgICAgICAgICBkPSdNMTcuMzU2IDBILjY0M0EuNjQzLjY0MyAwIDAwMCAuNjQzdjEwLjkyNWEuNjQzLjY0MyAwIDAwLjY0My42NDNoMTYuNzE0YS42NDMuNjQzIDAgMDAuNjQzLS42NDNWLjY0M0EuNjQ0LjY0NCAwIDAwMTcuMzU2IDB6TTIuNDMxIDExLjI3YTEuMzA2IDEuMzA2IDAgMTExLjMwNi0xLjMwNiAxLjMwNiAxLjMwNiAwIDAxLTEuMzA2IDEuMzA2em0wLTMuODU3YTEuMzA1IDEuMzA1IDAgMTEuOTI0LS4zODIgMS4zMDYgMS4zMDYgMCAwMS0uOTI0LjM4MnptMC0zLjg1N2ExLjMwNiAxLjMwNiAwIDExLjkyNS0uMzg0IDEuMzA2IDEuMzA2IDAgMDEtLjkyNS4zODR6bTMuMjE4IDcuNzE0YTEuMzA3IDEuMzA3IDAgMTEuOTIyLS4zODIgMS4zMDYgMS4zMDYgMCAwMS0uOTIyLjM4MnptMC0zLjg1N2ExLjMwNyAxLjMwNyAwIDExLjkyMi0uMzgxIDEuMzA2IDEuMzA2IDAgMDEtLjkyMi4zODF6bTAtMy44NTdhMS4zMDcgMS4zMDcgMCAxMS45Mi0uMzg1IDEuMzA2IDEuMzA2IDAgMDEtLjkyLjM4NXptMy4yMTggNy43MTRhMS4wOSAxLjA5IDAgMTAtLjAwOCAwem0wLTMuODU3YTEuMDkxIDEuMDkxIDAgMTAtLjAwOCAwem0wLTMuODU3YTEuMDkxIDEuMDkxIDAgMTAtLjAwOCAwem0zLjIxOCA3LjcxNGExLjEgMS4xIDAgMTAtLjAxMiAwem0tMS4zMDYtNS4xNjZhLjUyNS41MjUgMCAxMS0uMDEyIDB6bTEuMzA2LTIuNTUxYTEuNTcxIDEuNTcxIDAgMTAtLjAxMiAwem00LjggN2MwIC4zNTUtLjQxMi42NDMtLjkyMS42NDNIMTUuNWMtLjUwOCAwLS45MjEtLjI4OC0uOTIxLS42NDNWMS43NjhjMC0uMzU1LjQxMi0uNjQzLjkyMS0uNjQzaC40NjFjLjUwOCAwIC45MjEuMjg4LjkyMS42NDN6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA1NCdcbiAgICAgICAgICBkPSdNMTYuMzQ4IDIuNzhjLS4zMTgtMS4wNTItLjQzNC0uODkzLS40NzYtMS4xODYtLjAxMy0uMS0uMzQ2LS4wOTUtLjM1MSAwLS4wMTcuMjYxLS4xNS4zNzgtLjM2NS44ODgtLjIzNi41NjItLjE5MyAxIDAgMS4xODZoLS4wNjl2Mi41MmEuMjc0LjI3NCAwIDAwLS4wODUuMnY0LjJoMS40NDV2LTQuMmEuMjczLjI3MyAwIDAwLS4wODUtLjJWMy42ODRjLjEwNi0uMTMuMTQzLS4zOTMtLjAxNC0uOTA0em0tLjI5IDMuMTM0aC0uNjcyVjMuOTcxaC42N3onXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoIGRhdGEtbmFtZT0nUGF0aCA1NScgZD0nTTIuNDMgMS4yNDZhMSAxIDAgMTAxIDEgMSAxIDAgMDAtMS0xeicgLz5cbiAgICAgICAgPHBhdGggZGF0YS1uYW1lPSdQYXRoIDU2JyBkPSdNMTIuMDczIDEuMjQ2YTEgMSAwIDEwMSAxIDEgMSAwIDAwLTEtMXonIC8+XG4gICAgICAgIDxwYXRoIGRhdGEtbmFtZT0nUGF0aCA1NycgZD0nTTguODU5IDUuMTAzYTEgMSAwIDEwMSAxIDEgMSAwIDAwLTEtMXonIC8+XG4gICAgICAgIDxwYXRoIGRhdGEtbmFtZT0nUGF0aCA1OCcgZD0nTTUuNjQ1IDguOTZhMSAxIDAgMTAxIDEgMSAxIDAgMDAtMS0xeicgLz5cbiAgICAgICAgPHBhdGggZGF0YS1uYW1lPSdQYXRoIDU5JyBkPSdNMTIuMDczIDguOTZhMSAxIDAgMTAxIDEgMSAxIDAgMDAtMS0xeicgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IEJhdGhPaWwgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMjcnIGZpbGw9e2NvbG9yfT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjcnXG4gICAgICAgICAgZD0nTTMuODY2IDE2LjA3N2EyLjQ4MSAyLjQ4MSAwIDAwMS42NDUtMS42MTNoLS40MnEtLjI2OSAwLS41MzEtLjAxMmExLjIzIDEuMjMgMCAwMS0uODcuNzU1LjcyNC43MjQgMCAxMC4xNzUuODYzeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjgnXG4gICAgICAgICAgZD0nTTE1LjE3MiAxNi40NzlhLjcyNS43MjUgMCAxMC0uNDMyLTEuMzA5IDEuNDU4IDEuNDU4IDAgMDEtLjc4LS43NyA0LjA4NSA0LjA4NSAwIDAxLS42ODYuMDYyaC0uMzE1YTIuMzE4IDIuMzE4IDAgMDAxLjU0MyAxLjU3OS43MjUuNzI1IDAgMDAuNjcuNDM4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjknXG4gICAgICAgICAgZD0nTTEzLjk4OCAyLjYzOGwtMS40ODItMS40ODJhNS4wMTUgNS4wMTUgMCAwMC0xLjM1Ni44NjNsMS45NzIgMS45NzJhNC45NzIgNC45NzIgMCAwMC44NjYtMS4zNTN6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA3MCdcbiAgICAgICAgICBkPSdNMTEuMTczIDMuMTlhLjE0OC4xNDggMCAwMC4xMDgtLjA0M2wuMjA4LS4yMDhhLjE0Ny4xNDcgMCAwMC0uMTY0LS4yMzcuMTUuMTUgMCAwMC0uMDQ0LjAyOWwtLjIwOS4yMDhhLjE0OC4xNDggMCAwMC4xMDguMjUyeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzEnXG4gICAgICAgICAgZD0nTTEwLjU0NyAzLjgxOWEuMTQ4LjE0OCAwIDAwLjEwOC0uMDQzbC4yMDgtLjIwOGEuMTQ4LjE0OCAwIDAwLS4yMDgtLjIwOGwtLjIwOC4yMDhhLjE0OC4xNDggMCAwMC4xMDguMjUxeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzInXG4gICAgICAgICAgZD0nTTkuOTIgNC40NDVhLjE0OC4xNDggMCAwMC4xMDgtLjA0M2wuMjA4LS4yMDhhLjE0OC4xNDggMCAwMC0uMjA4LS4yMDhsLS4yMDguMjA4YS4xNDguMTQ4IDAgMDAuMTA4LjI1MXonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDczJ1xuICAgICAgICAgIGQ9J00xMS45MzIgMy4zMTNhLjE0Ni4xNDYgMCAwMC0uMTkzLS4xOTMuMTUuMTUgMCAwMC0uMDQ0LjAyOWwtLjIwOC4yMDlhLjE0OC4xNDggMCAwMC4yMDkuMjA4bC4yMDgtLjIwOWEuMTQ0LjE0NCAwIDAwLjAyOC0uMDQ0eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzQnXG4gICAgICAgICAgZD0nTTExLjI3NyAzLjc3NWEuMTQ4LjE0OCAwIDAwLS4yMDggMGwtLjIwOC4yMDhhLjE0OC4xNDggMCAwMC4yMDkuMjA4bC4yMDgtLjIwOGEuMTQ4LjE0OCAwIDAwMC0uMjA4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzUnXG4gICAgICAgICAgZD0nTTEwLjY1MiA0LjQwMmEuMTQ4LjE0OCAwIDAwLS4yMDggMGwtLjIwOC4yMDlhLjE0OC4xNDggMCAwMC4yMDkuMjA4bC4yMDgtLjIwOWEuMTQ4LjE0OCAwIDAwMC0uMjA4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzYnXG4gICAgICAgICAgZD0nTTEyLjAwNyA0LjAyOGEuMTQ4LjE0OCAwIDAwLjEwOC0uMDQzbC4yMDgtLjIwOGEuMTQzLjE0MyAwIDAwLjAyOS0uMDQ0LjE0OC4xNDggMCAwMC0uMjM4LS4xNjRsLS4yMDguMjA4YS4xNDguMTQ4IDAgMDAwIC4yMDguMTQ2LjE0NiAwIDAwLjEwMS4wNDN6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA3NydcbiAgICAgICAgICBkPSdNMTEuMzggNC42NTRhLjE0OC4xNDggMCAwMC4xMDgtLjA0M2wuMjA4LS4yMDhhLjE0OC4xNDggMCAwMC0uMjA4LS4yMDhsLS4yMDguMjA4YS4xNDguMTQ4IDAgMDAuMTA4LjI1MXonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDc4J1xuICAgICAgICAgIGQ9J00xMC43NTYgNS4yOGEuMTQ4LjE0OCAwIDAwLjEwOC0uMDQzbC4yMDgtLjIwOGEuMTQ4LjE0OCAwIDAwLS4yMDgtLjIwOGwtLjIwOC4yMDhhLjE0OC4xNDggMCAwMC4xMDguMjUxeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNzknXG4gICAgICAgICAgZD0nTTE3LjQxNCA3LjA4M2gtLjg4NlYuMjk1YS4yOTUuMjk1IDAgMDAtLjMtLjNoLTEuMjc3YS4zLjMgMCAwMC0uMi4wNzhsLTEuMDYxLjk3NmExLjE3NSAxLjE3NSAwIDAwLS42OS4wOTZsMS4wMTMgMS4wMTRhMS4xODcgMS4xODcgMCAwMC4wODMtLjY4bC45NjYtLjg4OGguODcydjYuNDkzSC41OWEuNTkuNTkgMCAwMC0uNTkuNTkxdi41OWEuNTkuNTkgMCAwMC41OS41OWguMzY3Yy4wNDUuMjI5LjEwOC40OTEuMTc2Ljc5NGwuNDEzIDEuOThhMi45IDIuOSAwIDAwMy4xMzggMi41M2MuMTM0IDAgLjI3LjAwNi40MDguMDA2aDguMTkxYTMuODc2IDMuODc2IDAgMDAuNTY1LS4wNDEgMy4xNTcgMy4xNTcgMCAwMDIuNjM3LTIuMzQybC42NzEtMi45MjloLjNBLjU4OC41ODggMCAwMDE4IDguMjY1di0uNTlhLjU5LjU5IDAgMDAtLjU4Ni0uNTkyem0tNC43IDYuMTY4YS4wMzUuMDM1IDAgMDAwIC4wMDV2LS4wMDV6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQmVhdXR5SGVhbHRoID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9JzE3LjExMidcbiAgICAgIGhlaWdodD0nMjQnXG4gICAgICB2aWV3Qm94PScwIDAgMTcuMTEyIDI0J1xuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxnIGlkPSdCZWF1dHknIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xMjc4LjEzOCAtNDkwLjEzOSknPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDQ4J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQ0OCdcbiAgICAgICAgICBkPSdNMTI5NS4yNSw0OTYuODEyYS40MzIuNDMyLDAsMCwwLS40MzItLjQzMmgtMS40NjdhNi42NzEsNi42NzEsMCwwLDAtMTMuMzE0LDBoLTEuNDY3YS40MzMuNDMzLDAsMCwwLS40MzIuNDMyLDguNTY3LDguNTY3LDAsMCwwLDguMTI0LDguNTQ1djYuMzM1aC0zLjZhMS4yMjMsMS4yMjMsMCwxLDAsMCwyLjQ0N2g4LjA2NWExLjIyMywxLjIyMywwLDEsMCwwLTIuNDQ3aC0zLjZ2LTYuMzM1QTguNTY3LDguNTY3LDAsMCwwLDEyOTUuMjUsNDk2LjgxMlptLTQuMTY1LDE2LjFhLjM1OS4zNTksMCwwLDEtLjM1OS4zNThoLTguMDY1YS4zNTkuMzU5LDAsMSwxLDAtLjcxN2g4LjA2NUEuMzU5LjM1OSwwLDAsMSwxMjkxLjA4NSw1MTIuOTE2Wk0xMjg2LjY5NCw0OTFhNS44MDgsNS44MDgsMCwxLDEtNS44MDgsNS44MDhBNS44MTQsNS44MTQsMCwwLDEsMTI4Ni42OTQsNDkxWm0tNy42NzksNi4yNGgxLjAyMmE2LjY3MSw2LjY3MSwwLDAsMCwxMy4zMTQsMGgxLjAyMmE3LjY5MSw3LjY5MSwwLDAsMS0xNS4zNTgsMFonXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDQ5J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQ0OSdcbiAgICAgICAgICBkPSdNMTMzNC40MjMsNTMyLjAxM2EuNDMxLjQzMSwwLDAsMCwuMzA2LS4xMjdsMy4zOTEtMy4zOTJhLjQzMi40MzIsMCwwLDAtLjYxMi0uNjExbC0zLjM5MSwzLjM5MWEuNDMyLjQzMiwwLDAsMCwuMzA2LjczOFonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTUwLjc0OSAtMzQuMTgpJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ1MCdcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NTAnXG4gICAgICAgICAgZD0nTTEzOTAuNTI1LDUzMi45NzRhLjQzMS40MzEsMCwwLDAsLjMwNi0uMTI3bC41NjktLjU2OWEuNDMyLjQzMiwwLDAsMC0uNjEyLS42MTJsLS41NjkuNTY5YS40MzMuNDMzLDAsMCwwLC4zMDYuNzM4WidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMTAxLjcyNSAtMzcuNjE4KSdcbiAgICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0NTEnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDUxJ1xuICAgICAgICAgIGQ9J00xMzM3LjksNTUyLjFhLjQzMi40MzIsMCwwLDAsLjYxMSwwbDMuODk0LTMuODk0YS40MzIuNDMyLDAsMCwwLS42MTEtLjYxMWwtMy44OTQsMy44OTRBLjQzMi40MzIsMCwwLDAsMTMzNy45LDU1Mi4xWidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtNTQuMTg0IC01Mi4wODkpJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IEJldmVyYWdlID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD1cIjE0LjU2OVwiXG4gICAgICBoZWlnaHQ9XCIyNi4wOTlcIlxuICAgICAgdmlld0JveD1cIjAgMCAxNC41NjkgMjYuMDk5XCJcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBpZD1cImJldmFyYWdlXCJcbiAgICAgICAgZD1cIk05MDEuMTgyLDM5NC4zNDN2LS4yNjdjMC0xLjQ1NSwwLTIuOTExLDAtNC4zNjYsMC0uMTkyLS4wMzctLjI3OS0uMjQ2LS4zMzNhNy4xNzksNy4xNzksMCwwLDEtNS40MDUtNy40OGMuMDkzLTEuMjkzLjMtMi41NzkuNDU5LTMuODY3cS4yNDctMiwuNS0zLjk5M2EuNTM2LjUzNiwwLDAsMSwuNjIxLS41NDRxNS42MjYsMCwxMS4yNTIsMGEuNTM2LjUzNiwwLDAsMSwuNjE0LjU1MmMuMzA2LDIuNDMuNiw0Ljg2Mi45Miw3LjI5MWE3LjI1Myw3LjI1MywwLDAsMS01LjEyLDcuOTgyYy0uNDgyLjE0NC0uNDgzLjE0NC0uNDgzLjY2M3EwLDIuMDQsMCw0LjA4di4yN2MuNTA4LjA3MywxLC4xMywxLjUuMjE5YTcuNTY1LDcuNTY1LDAsMCwxLDIuNzM0LjkzLDIuOTIsMi45MiwwLDAsMSwuNTA4LjQsMS4zMjUsMS4zMjUsMCwwLDEsLjAxLDIsMy43MDUsMy43MDUsMCwwLDEtMS4zNDEuODIsMTIuMDE4LDEyLjAxOCwwLDAsMS0zLjQ0My43MjEsMTYuNDQ0LDE2LjQ0NCwwLDAsMS01LjA2Mi0uMzA2LDEyLjY2NiwxMi42NjYsMCwwLDEtMS44ODctLjYzMywyLjkxLDIuOTEsMCwwLDEtLjgzNC0uNTYyLDEuMzIzLDEuMzIzLDAsMCwxLS4wMy0yLjA1NCw0LjI5LDQuMjksMCwwLDEsMS43NjMtLjk1OCwxMi4xMzcsMTIuMTM3LDAsMCwxLDIuNjY3LS41MjdDOTAwLjk3NiwzOTQuMzc2LDkwMS4wNjksMzk0LjM1OSw5MDEuMTgyLDM5NC4zNDNabTcuNTQxLTEzLjk2Yy0uMzI5LjEwNi0uNjM2LjE5LS45MzMuM2E1LjM3Miw1LjM3MiwwLDAsMS0zLjc2LjAxOGMtLjkzMS0uMzIzLTEuODY5LS42MjYtMi44LS45MzdhNC4wMTEsNC4wMTEsMCwwLDAtMi4yNjktLjIyN2MtLjY5NS4xNzQtMS4zNzYuNC0yLjA2MS42MTdhLjIzMS4yMzEsMCwwLDAtLjEyOS4xNTksMTIuMDcyLDEyLjA3MiwwLDAsMC0uMTcxLDIuNzY1LDYuMTgyLDYuMTgyLDAsMCwwLDguNyw0LjkzOCw2LjAzNSw2LjAzNSwwLDAsMCwzLjYyNC01LjI0QTEwLjQyNywxMC40MjcsMCwwLDAsOTA4LjcyMywzODAuMzgzWm0tMTEuMjQzLTUuODQtLjU2LDQuNWMuMi0uMDYxLjM1OS0uMS41MS0uMTU5YTUuODY3LDUuODY3LDAsMCwxLDQuNDUxLDBjLjkxNy4zNTYsMS44NjcuNjI4LDIuODA2LjkyNWEzLjM5MSwzLjM5MSwwLDAsMCwxLjg2OC4xMjljLjY0NC0uMTYzLDEuMjc3LS4zNzIsMS45MDktLjU3Ny4wNTUtLjAxOC4xMDgtLjE2LjEtLjIzNy0uMTI1LTEuMDc0LS4yNjItMi4xNDctLjQtMy4yMnEtLjA4NS0uNjc3LS4xNy0xLjM1NFptMy43LDIwLjc4MmMtLjg5My4xOTEtMS43NDcuMzMyLTIuNTc0LjU2N2E1LjQzMyw1LjQzMywwLDAsMC0xLjM0My42NWMtLjMzMi4yMDYtLjMyNi40NS0uMDA2LjY4MWE0LjE1MSw0LjE1MSwwLDAsMCwuOTcuNTM1LDEyLjksMTIuOSwwLDAsMCw0LjY3Mi42ODMsMTIuNDY2LDEyLjQ2NiwwLDAsMCw0LjQzMy0uNzEyLDMuODY5LDMuODY5LDAsMCwwLC43NzYtLjQxYy40NTctLjMxMi40NTMtLjU1NS4wMDYtLjg2OWEzLjIzMywzLjIzMywwLDAsMC0uNTE3LS4yOTQsMTAuMTIsMTAuMTIsMCwwLDAtMy4zLS43NmMwLC40NzEsMCwuOTI4LDAsMS4zODQsMCwuNDI5LS4xOTIuNjIzLS42MTUuNjI0cS0uOTQ4LDAtMS45LDBhLjUzMS41MzEsMCwwLDEtLjYwNy0uNkM5MDEuMTgsMzk2LjM0Nyw5MDEuMTgyLDM5NS44ODksOTAxLjE4MiwzOTUuMzI2Wm0xLjA1OC01LjcxM3Y2LjczNGgxdi02LjczNFpcIlxuICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTg5NS40NTcgLTM3My40NDMpXCJcbiAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgIHN0cm9rZT1cIiNmZmZcIlxuICAgICAgICBzdHJva2VXaWR0aD1cIjAuMVwiXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQnJlYWtmYXN0ID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9JzI1LjQwOCdcbiAgICAgIGhlaWdodD0nMTguNSdcbiAgICAgIHZpZXdCb3g9JzAgMCAyNS40MDggMTguNSdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8ZyBpZD0nQnJlYWtmYXN0JyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwLjI1IC03MC43NSknPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3Mzg4J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzM4OCdcbiAgICAgICAgICBkPSdNMjQxLjczLDEzMWEuNzMuNzMsMCwwLDAtLjczLjczdjEuOTQ2YS43My43MywwLDAsMCwxLjQ1OSwwVjEzMS43M0EuNzMuNzMsMCwwLDAsMjQxLjczLDEzMVonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTIyOS4yNzYgLTU3LjA4MSknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nI2ZmZidcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMC40J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3Mzg5J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzM4OSdcbiAgICAgICAgICBkPSdNMjkyLjMzNSwxMzEuMzI0YS43My43MywwLDEsMC0xLjIxNC44MWwuOTczLDEuNDU5YS43My43MywwLDAsMCwxLjIxNC0uODFaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0yNzYuODQxIC01Ny4wOCknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nI2ZmZidcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMC40J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3MzkwJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzM5MCdcbiAgICAgICAgICBkPSdNMTczLjEwNSwxMzEuMTIxYS43My43MywwLDAsMC0xLjAxMi4ybC0uOTczLDEuNDU5YS43My43MywwLDEsMCwxLjIxNC44MWwuOTczLTEuNDU5QS43My43MywwLDAsMCwxNzMuMTA1LDEzMS4xMjFaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xNjIuNjc5IC01Ny4wOCknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nI2ZmZidcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMC40J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3MzkxJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzM5MSdcbiAgICAgICAgICBkPSdNMjQuOTA4LDgwLjQ4N0EyLjY4LDIuNjgsMCwwLDAsMjIuOTI2LDc3LjlhNi44NjcsNi44NjcsMCwwLDAtMy4xNTEtNC43NzdBMTIuOTA3LDEyLjkwNywwLDAsMCwxMi40NTQsNzFhMTIuOTA3LDEyLjkwNywwLDAsMC03LjMyMSwyLjEyNUE2Ljg2Nyw2Ljg2NywwLDAsMCwxLjk4Miw3Ny45YTIuNjc2LDIuNjc2LDAsMCwwLC4xNTksNS4yMDdsLjg3NCwzLjVBMy4xNTgsMy4xNTgsMCwwLDAsNi4wODMsODlIMTguODI1YTMuMTU4LDMuMTU4LDAsMCwwLDMuMDY4LTIuNGwuODc0LTMuNUEyLjY4LDIuNjgsMCwwLDAsMjQuOTA4LDgwLjQ4N1pNNC40MzEsODYuMjUxbC0uNzcyLTMuMDg5SDYuOTQ1bC41NDcsNC4zNzhINi4wODNhMS43LDEuNywwLDAsMS0xLjY1Mi0xLjI5Wm0xMi4wNjEtMy4wODktLjU0Nyw0LjM3OEgxMy4xODRWODMuMTYyWm0tNC43NjgsNC4zNzhIOC45NjNsLS41NDctNC4zNzhoMy4zMDlabTguNzUzLTEuMjlhMS43LDEuNywwLDAsMS0xLjY1MiwxLjI5SDE3LjQxNmwuNTQ3LTQuMzc4aDMuMjg2Wk0yMi4yMzIsODEuN0gyLjY3NmExLjIxNiwxLjIxNiwwLDAsMSwwLTIuNDMyLjczLjczLDAsMCwwLC43My0uNzMsNS4yNTUsNS4yNTUsMCwwLDEsMi41NjEtNC4yMTcsMTEuNDQsMTEuNDQsMCwwLDEsNi40ODgtMS44NjQsMTEuNDQsMTEuNDQsMCwwLDEsNi40ODgsMS44NjRBNS4yNTUsNS4yNTUsMCwwLDEsMjEuNSw3OC41NDFhLjczLjczLDAsMCwwLC43My43MywxLjIxNiwxLjIxNiwwLDEsMSwwLDIuNDMyWidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIDApJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2U9JyNmZmYnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuNSdcbiAgICAgICAgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENsb3NlSWNvbiA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScxMC4wMDMnXG4gICAgICBoZWlnaHQ9JzEwJ1xuICAgICAgdmlld0JveD0nMCAwIDEwLjAwMyAxMCdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBkYXRhLW5hbWU9J19pb25pY29uc19zdmdfaW9zLWNsb3NlICg1KSdcbiAgICAgICAgZD0nTTE2Ni42ODYsMTY1LjU1bDMuNTczLTMuNTczYS44MzcuODM3LDAsMCwwLTEuMTg0LTEuMTg0bC0zLjU3MywzLjU3My0zLjU3My0zLjU3M2EuODM3LjgzNywwLDEsMC0xLjE4NCwxLjE4NGwzLjU3MywzLjU3My0zLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NCwxLjE4NGwzLjU3My0zLjU3MywzLjU3MywzLjU3M2EuODM3LjgzNywwLDAsMCwxLjE4NC0xLjE4NFonXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xNjAuNSAtMTYwLjU1KSdcbiAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENvb2tpbmcgPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiMjguOVwiXG4gICAgICBoZWlnaHQ9XCIxNi45XCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMjguOSAxNi45XCJcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8ZyBpZD1cIkNvb2tpbmdcIiB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTYxLjU1IC0xOTUuNTUpXCI+XG4gICAgICAgIDxnXG4gICAgICAgICAgaWQ9XCJHcm91cF8xMjMyMFwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiR3JvdXAgMTIzMjBcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg2MiAxOTYpXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxnXG4gICAgICAgICAgICBpZD1cIkdyb3VwXzEyMzE5XCJcbiAgICAgICAgICAgIGRhdGEtbmFtZT1cIkdyb3VwIDEyMzE5XCJcbiAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgxMS4wMDYgMTAuNTE4KVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGxpbmVcbiAgICAgICAgICAgICAgaWQ9XCJMaW5lXzEwXCJcbiAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiTGluZSAxMFwiXG4gICAgICAgICAgICAgIHgyPVwiMC45NjNcIlxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjAuOVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGxpbmVcbiAgICAgICAgICAgICAgaWQ9XCJMaW5lXzExXCJcbiAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiTGluZSAxMVwiXG4gICAgICAgICAgICAgIHgyPVwiMC45NjNcIlxuICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMi4zNDUpXCJcbiAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIwLjlcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxsaW5lXG4gICAgICAgICAgICAgIGlkPVwiTGluZV8xMlwiXG4gICAgICAgICAgICAgIGRhdGEtbmFtZT1cIkxpbmUgMTJcIlxuICAgICAgICAgICAgICB4Mj1cIjAuOTYzXCJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDQuNjkxKVwiXG4gICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMC45XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9nPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBpZD1cIlBhdGhfMTc0MjhcIlxuICAgICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyOFwiXG4gICAgICAgICAgICBkPVwiTTU3OC4wNzQsNDE0LjQ4NWwzLjE5Mi0uNTl2LTEuMTVoLTMuMTkyWlwiXG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTU1My4yNjYgLTQwNi45NzgpXCJcbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMC45XCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBpZD1cIlBhdGhfMTc0MjlcIlxuICAgICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyOVwiXG4gICAgICAgICAgICBkPVwiTTUwNi42NjgsNDE0LjQ4NWwtMy4xOTItLjU5di0xLjE1aDMuMTkyWlwiXG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTUwMy40NzYgLTQwNi45NzgpXCJcbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMC45XCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBpZD1cIlBhdGhfMTc0MzBcIlxuICAgICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQzMFwiXG4gICAgICAgICAgICBkPVwiTTUyMy44MjMsNDAxLjc0NGExNy4yMTIsMTcuMjEyLDAsMCwwLTEwLjc0OSwzLjgyOWgyMS42MTVBMTcuNzUxLDE3Ljc1MSwwLDAsMCw1MjMuODIzLDQwMS43NDRaXCJcbiAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtNTA5Ljg4MiAtMzk5LjgwNSlcIlxuICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIwLjlcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGxpbmVcbiAgICAgICAgICAgIGlkPVwiTGluZV8xM1wiXG4gICAgICAgICAgICBkYXRhLW5hbWU9XCJMaW5lIDEzXCJcbiAgICAgICAgICAgIHkxPVwiMS45MzlcIlxuICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDEzLjk0MSlcIlxuICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgIHN0cm9rZU1pdGVybGltaXQ9XCIxMFwiXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjAuOVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8bGluZVxuICAgICAgICAgICAgaWQ9XCJMaW5lXzE0XCJcbiAgICAgICAgICAgIGRhdGEtbmFtZT1cIkxpbmUgMTRcIlxuICAgICAgICAgICAgeDI9XCIzLjYwNlwiXG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMTIuMTk3KVwiXG4gICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD1cIjEwXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMC45XCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBpZD1cIlBhdGhfMTc0MzFcIlxuICAgICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQzMVwiXG4gICAgICAgICAgICBkPVwiTTUzNC42OSw0MTIuNjQzcy0uMzMzLDEwLjI2OC01LjMyMSwxMC4yNjhINTE4LjM5NWMtNC45ODgsMC01LjMyMS0xMC4yNjgtNS4zMjEtMTAuMjY4WlwiXG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTUwOS44ODIgLTQwNi45MTEpXCJcbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMC45XCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2c+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBEYWlyeSA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScxNi45NjcnXG4gICAgICBoZWlnaHQ9JzIyLjEnXG4gICAgICB2aWV3Qm94PScwIDAgMTYuOTY3IDIyLjEnXG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPGcgaWQ9J0RhaXJ5JyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtNzEuOTUgLTE1Ljk1KSc+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTczOTUnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3Mzk1J1xuICAgICAgICAgIGQ9J003Mi43MzMsMzYuMTY3di04LjhhOC41MTYsOC41MTYsMCwwLDEsLjY5My0zLjM3NGwuNzU1LTEuNzYyYy4wNjQtLjE1LjEyNi0uMy4xODMtLjQ2YTYuOTQsNi45NCwwLDAsMSwyLjcyMi4wNTUsNy41ODUsNy41ODUsMCwwLDAsMi44NjkuMDg1Yy4wNDEuMTA3LjA4NS4yMTQuMTMuMzIxbC43NTUsMS43NjMuNjc0LS4yODktLjc1NS0xLjc2M2MtLjA4LS4xODgtLjE1NC0uMzc5LS4yMi0uNTY4YTguNTUsOC41NSwwLDAsMS0uNDY1LTIuNDRoLjM1OWEuMzY3LjM2NywwLDAsMCwuMzY3LS4zNjdWMTcuMUExLjEsMS4xLDAsMCwwLDc5LjcsMTZINzQuNTY3YTEuMSwxLjEsMCwwLDAtMS4xLDEuMXYxLjQ2N2EuMzY3LjM2NywwLDAsMCwuMzY3LjM2N2guMzU5YTguNTUyLDguNTUyLDAsMCwxLS40NSwyLjRjLS4wNzEuMjA3LS4xNS40MTItLjIzNS42MUw3Mi43NTIsMjMuN0E5LjI0Nyw5LjI0NywwLDAsMCw3MiwyNy4zNjd2OC44QTEuODM1LDEuODM1LDAsMCwwLDczLjgzMywzOEg3OS43di0uNzMzSDczLjgzM0ExLjEsMS4xLDAsMCwxLDcyLjczMywzNi4xNjdaTTc0LjIsMTcuMWEuMzY3LjM2NywwLDAsMSwuMzY3LS4zNjdINzkuN2EuMzY3LjM2NywwLDAsMSwuMzY3LjM2N3YxLjFINzQuMlptNS4xNDEsMS44MzNhOS4yNzEsOS4yNzEsMCwwLDAsLjM3NSwyLjI3LDYuODU1LDYuODU1LDAsMCwxLTIuNDctLjA5NSw3LjY3Myw3LjY3MywwLDAsMC0yLjYzMy0uMTE4LDkuMjc4LDkuMjc4LDAsMCwwLC4zMTQtMi4wNTdaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDAgMCknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjEnXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTczOTcnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3Mzk3J1xuICAgICAgICAgIGQ9J00yNDEuNTMzLDIwMS44MzNjMC0xLjItMi40LTEuODMzLTQuNzY3LTEuODMzcy00Ljc2Ny42My00Ljc2NywxLjgzM2EuODguODgsMCwwLDAsLjAxLjEzMmwxLjA5MiwxMS4yNzFhLjM2Ny4zNjcsMCwwLDAsLjM2NS4zM2g2LjZhLjM2Ny4zNjcsMCwwLDAsLjM2NS0uMzNsMS4wOTItMTEuMjcxQS44ODQuODg0LDAsMCwwLDI0MS41MzMsMjAxLjgzM1ptLTEsMy0uMTg1LjA2MmE1LjgxMyw1LjgxMywwLDAsMS0zLjUyNi4wNTMsNi41NjYsNi41NjYsMCwwLDAtMy43NzgsMGwtLjAzMy4wMS0uMTgxLTIuMDQ3YTEwLjY2MiwxMC42NjIsMCwwLDAsNy44NzMsMFptLTMuNzY3LTQuMWMyLjU5MywwLDQuMDE1LjcxNyw0LjAzMiwxLjA5M2wwLC4wNDZjLS4wOTEuMzgyLTEuNTA2LDEuMDYxLTQuMDI4LDEuMDYxcy0zLjkzNy0uNjc5LTQuMDI4LTEuMDYxbDAtLjA0NkMyMzIuNzUyLDIwMS40NTEsMjM0LjE3MywyMDAuNzMzLDIzNi43NjcsMjAwLjczM1ptMi45NjgsMTIuMUgyMzMuOGwtLjcxOC03LjEyOC4xNzUtLjA1MmE1Ljg1OSw1Ljg1OSwwLDAsMSwzLjM1NywwLDYuNTM5LDYuNTM5LDAsMCwwLDMuODQ1LS4wMlonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTE1Mi42NjcgLTE3NS41NjcpJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMC4xJ1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRGVvZG9yYW50ID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8ZyBkYXRhLW5hbWU9JzAxOC0tLVJvbGwtT24nIGZpbGw9e2NvbG9yfT5cbiAgICAgICAgPGVsbGlwc2VcbiAgICAgICAgICBjeD0nMS42MDcnXG4gICAgICAgICAgY3k9JzMuNTM1J1xuICAgICAgICAgIHJ4PScxLjYwNydcbiAgICAgICAgICByeT0nMy41MzUnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMi4xNzYgOC42NzgpJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aCBkPSdNNy4yNDQgNC44MjFILjMyMWEuMzIxLjMyMSAwIDAwLS4zMi4zNTZsLjAyNy4yNTRhNzEuODM1IDcxLjgzNSAwIDAxLjMxMSAxMS4yMTVBMS4yODIgMS4yODIgMCAwMDEuNjIxIDE4aDQuMzI1YTEuMjgyIDEuMjgyIDAgMDAxLjI4Mi0xLjM1MyA3MS44MzUgNzEuODM1IDAgMDEuMy0xMS4yMTRsLjAyNy0uMjU0YS4zMjEuMzIxIDAgMDAtLjMxNi0uMzU4em0tNi4zNTUuOTYyYS4zMjEuMzIxIDAgMDEuMzIxLS4zMjFoLjY0MWEuMzIxLjMyMSAwIDExMCAuNjQxSDEuMjFhLjMyMS4zMjEgMCAwMS0uMzIxLS4zMnptMi45IDEwLjYwN2MtMS4yNjEgMC0yLjI1LTEuODMyLTIuMjUtNC4xNzhzLjk4OC00LjE3OCAyLjI1LTQuMTc4IDIuMjUgMS44MzIgMi4yNSA0LjE3OC0uOTk1IDQuMTgxLTIuMjU2IDQuMTgxek02LjM1NCA2LjEwNEgzLjE0YS4zMjEuMzIxIDAgMTEwLS42NDFoMy4yMTRhLjMyMS4zMjEgMCAxMTAgLjY0MXonIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdTaGFwZSdcbiAgICAgICAgICBkPSdNMy43ODMgMGEyLjI1IDIuMjUgMCAwMC0yLjIyNCAxLjkyOWg0LjQ0N0EyLjI1IDIuMjUgMCAwMDMuNzgzIDB6TTYuNDQzIDIuNTcySDEuMTI4YTUuOTQ2IDUuOTQ2IDAgMDAtLjIzNyAxLjYwN2g1Ljc4NWE1Ljk0NiA1Ljk0NiAwIDAwLS4yMzMtMS42MDd6TTExLjgyIDE2LjcxNmgzLjIxNHYtMS4yODRhMi44OTMgMi44OTMgMCAxMC01Ljc4NiAwdjEuMjg0aC45NjRhLjMyMS4zMjEgMCAwMTAgLjY0MWgtLjk2NHYuMzIxYS4zMjEuMzIxIDAgMDAuMzIxLjMyMWg1LjE0M2EuMzIxLjMyMSAwIDAwLjMyMS0uMzIxdi0uMzIxSDExLjgyYS4zMjEuMzIxIDAgMTEwLS42NDF6bS0uOTY0LTEuOTI5YS4zMjEuMzIxIDAgMDEtLjY0MSAwIDEuNTUgMS41NSAwIDAxMS42MDYtMS42MDguMzIxLjMyMSAwIDExMCAuNjQxLjkxNi45MTYgMCAwMC0uOTY2Ljk2NHonXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBFeWVzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8ZyBmaWxsPXtjb2xvcn0+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQ5J1xuICAgICAgICAgIGQ9J00zLjAwMiAwaC0xLjV2Ljc1aC0xLjV2MS41aDEuNVYzaC0xLjV2MS41aDEuNXYuNzVoLTEuNXYxLjVoMS41djMuNzVoLS43NWEuNzUuNzUgMCAwMC0uNzQ0Ljg0MmwuNzUgNmEuNzUuNzUgMCAwMC43NDQuNjU3aDEuNWEuNzUuNzUgMCAwMC43NDQtLjY1N2wuNzUtNmEuNzUuNzUgMCAwMC0uNzQ0LS44NDJoLS43NVY2Ljc0OGgxLjV2LTEuNWgtMS41VjQuNWgxLjVWM2gtMS41di0uNzVoMS41Vi43NWgtMS41eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNTAnXG4gICAgICAgICAgZD0nTTExLjk5NSAxNy4xODdsLS43NDYtOS42OWgtNC41bC0uNzQ3IDkuNjlhLjc1Ljc1IDAgMDAuNzQ4LjgwN2g0LjVhLjc1Ljc1IDAgMDAuNzQ4LS44MDd6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA1MSdcbiAgICAgICAgICBkPSdNMTEuMjUxIDUuMjQ5YS43NS43NSAwIDAwLS43NS0uNzVoLTNhLjc1Ljc1IDAgMDAtLjc1Ljc1djEuNWg0LjV6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRmFjZSA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZmlsbD17Y29sb3J9PlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA0MSdcbiAgICAgICAgICBkPSdNNi4zODggOS4yMzhjLTMuMzE5IDAtNS4xMSAxLjM2LTUuMTEgMS45MTFzMS43OTEgMS45MTEgNS4xMSAxLjkxMWE5Ljk5NSA5Ljk5NSAwIDAwMi42NTMtLjM0NSA1LjEgNS4xIDAgMDExLjM4Ny0yLjYxMiA4Ljg2NSA4Ljg2NSAwIDAwLTQuMDQtLjg2NHonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQyJ1xuICAgICAgICAgIGQ9J004LjM0IDguOTA4YTcuNTE1IDcuNTE1IDAgMDEyLjMuODQxIDUuMTExIDUuMTExIDAgMDEuNTgxLS4zOTEgNyA3IDAgMDAtMS45NjktLjg4NyA1Ljk1NyA1Ljk1NyAwIDAxLS45MTIuNDM4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNDMnXG4gICAgICAgICAgZD0nTTguOTU4IDEzLjM4M2ExMC43NzQgMTAuNzc0IDAgMDEtMi41NzEuM2MtMy4yOSAwLTUuNzQ5LTEuMzQ5LTUuNzQ5LTIuNTU1IDAtLjkwOCAxLjM5NC0xLjkgMy40ODQtMi4zM2E2LjAxNyA2LjAxNyAwIDAxLS45LS40MzNjLTEuOTYuNTcxLTMuMjI0IDEuNjQ3LTMuMjI0IDIuNzYyIDAgMS43MzEgMi45MjIgMy4xOTMgNi4zODggMy4xOTNhMTEuNjQgMTEuNjQgMCAwMDIuNTczLS4yODVjLS4wMDgtLjExMi0uMDE4LS4yMzQtLjAxOC0uMzU0LjAwMi0uMDk3LjAxMS0uMTk3LjAxNy0uMjk4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNDQnXG4gICAgICAgICAgZD0nTTYuMzg4IDguOTUyYTQuODMzIDQuODMzIDAgMDA1LjExLTQuNDcxQTQuODMzIDQuODMzIDAgMDA2LjM4OC4wMWE0LjgzMyA0LjgzMyAwIDAwLTUuMTEgNC40NzEgNC44MzMgNC44MzMgMCAwMDUuMTEgNC40NzF6bTAtOC4zYTQuMTk0IDQuMTk0IDAgMDE0LjQ3MSAzLjgzMyA0LjE5NCA0LjE5NCAwIDAxLTQuNDcxIDMuODMzQTQuMTk0IDQuMTk0IDAgMDExLjkxNyA0LjQ4IDQuMTk0IDQuMTk0IDAgMDE2LjM4OC42NDd6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA0NSdcbiAgICAgICAgICBkPSdNNi4zOTEgNy42NzVhMy41NjEgMy41NjEgMCAwMDMuODMzLTMuMTkzIDMuNTYxIDMuNTYxIDAgMDAtMy44MzMtMy4xOTVBMy41NjEgMy41NjEgMCAwMDIuNTU4IDQuNDhhMy41NjEgMy41NjEgMCAwMDMuODMzIDMuMTk1em0wLTUuNzQ5YTIuOTY5IDIuOTY5IDAgMDEzLjE5MyAyLjU1NWgtLjYzOGMwLTEuMDM5LTEuMTctMS45MTEtMi41NTUtMS45MTF6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA0NidcbiAgICAgICAgICBkPSdNMTcuMzkgMTEuMzA0YTYuOTEgNi45MSAwIDAxLS41OTIuMzE5IDUuNCA1LjQgMCAwMC0yLjUxOCAyLjUxOCA2LjAyNiA2LjAyNiAwIDAxLTIuODEgMi44MSA3LjIyIDcuMjIgMCAwMC0uNDg2LjI1OSA0LjQ2NiA0LjQ2NiAwIDAwNi40MDctNS45em0tMy44NzcgNi4wNTF2LS42MzhhMy4yMzggMy4yMzggMCAwMC41ODEtLjA1M2wuMTEyLjYyOGEzLjg0NyAzLjg0NyAwIDAxLS42OTQuMDYzem0xLjM5NC0uMjYxbC0uMjMzLS41OTVhMy4xNzYgMy4xNzYgMCAwMDIuMDMyLTIuOTc2aC42MzhhMy44MTIgMy44MTIgMCAwMS0yLjQzOCAzLjU3MXonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQ3J1xuICAgICAgICAgIGQ9J00xMi42NiAxNS4zMzJhNC43NCA0Ljc0IDAgMDAxLjA0NC0xLjQ3MiA2LjAyOSA2LjAyOSAwIDAxMi44MDktMi44MTVjLjE3My0uMDg1LjMzNy0uMTcuNTE4LS4yNzhhNC41MjcgNC41MjcgMCAwMC0uNC0uNDUgNi4zNyA2LjM3IDAgMDEtLjczMS40MDcgNS4zODYgNS4zODYgMCAwMC0yLjUxMiAyLjUyMSA2LjAzIDYuMDMgMCAwMS0yLjgxIDIuODEgNi45NjIgNi45NjIgMCAwMC0uNTMyLjI4NSA0LjUwNyA0LjUwNyAwIDAwLjQxNC40MzggNi4zNCA2LjM0IDAgMDEuNzI3LS40MDYgNC43MzMgNC43MzMgMCAwMDEuNDc0LTEuMDQyeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNDgnXG4gICAgICAgICAgZD0nTTExLjc2OSAxNC40MzlhNC43NCA0Ljc0IDAgMDAxLjA0NC0xLjQ3MiA2LjAyMiA2LjAyMiAwIDAxMi44MS0yLjgxYy4xNjYtLjA4Mi4zMjgtLjE2NC41LS4yNjVhNC40NjIgNC40NjIgMCAwMC02LjQzNSA1LjkyMmMuMjE5LS4xMzYuNDE5LS4yMzYuNjE0LS4zMzdhNC43NDcgNC43NDcgMCAwMDEuNDctMS4wMzd6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRmFjaWFsQ2FyZSA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScxOC44MTQnXG4gICAgICBoZWlnaHQ9JzI0J1xuICAgICAgdmlld0JveD0nMCAwIDE4LjgxNCAyNCdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8ZyBpZD0nTWFrdXAnIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC01MDcuODE4IC00ODUuMzg1KSc+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0MjYnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDI2J1xuICAgICAgICAgIGQ9J001MTQuNTgsNTAyLjg2N2EuNzIxLjcyMSwwLDAsMC0uNDQ4LS41NzkuNDExLjQxMSwwLDAsMC0uMTI1LS4wNDF2LTQuNWEuNTkxLjU5MSwwLDAsMC0uMjktLjVWNDk0LjlhNi45NzcsNi45NzcsMCwwLDAtLjY3NS0yLjg2OGwwLS4wMDksMC0uMDA1YTMuMiwzLjIsMCwwLDAtLjI3Mi0uNDQ5LDEuMTg4LDEuMTg4LDAsMCwwLTEuMzQ3LS4zNjIsMi4yNjEsMi4yNjEsMCwwLDAtMS40OTIsMS4yMmwtLjAyMi4wNDVhNi4zMTUsNi4zMTUsMCwwLDAtLjMzOC44NzRjMCwuMDA3LS4wMDYuMDEyLS4wMDguMDE5czAsLjAxLDAsLjAxNWE3LjA3NCw3LjA3NCwwLDAsMC0uMjkyLDIuMDQ0djEuNzA3Yy0uMzM2LjE0NC0uNTA5LjM1LS41MDkuNjEzdjQuNDg2Yy0uMzU0LjE1NS0uNTQ1LjM2NC0uNTcuNjIyLDAsLjAwNiwwLC4wMTEsMCwuMDE3YTcxLjk1Niw3MS45NTYsMCwwLDAtLjI4OSwxMC4zOTFjMCwuNzg3LDEuNSwxLjM4LDMuNDksMS4zOHMzLjQ5LS41OTMsMy40ODktMS4zNTVhNzIuMSw3Mi4xLDAsMCwwLS4yODgtMTAuNDE3Wk01MTIuOCw0OTRhNS4zMzUsNS4zMzUsMCwwLDEsLjA4NS45djIuNzc5YTYuOTYxLDYuOTYxLDAsMCwxLTEuNS4xNDIsNy42MjIsNy42MjIsMCwwLDEtMS4yODQtLjF2LTIuM2E2LjcxNSw2LjcxNSwwLDAsMSwuMDQzLS43NTEsMS45NzQsMS45NzQsMCwwLDAsLjg5MS4yQTIuNTY5LDIuNTY5LDAsMCwwLDUxMi44LDQ5NFptLTMuMjA5LDQuNDY0YTguNjEzLDguNjEzLDAsMCwwLDMuNTg1LDB2NC41MDhhMTAuMiwxMC4yLDAsMCwxLTMuNTg1LDBabTEuMDg3LTUuNjc2YTEuNDQ3LDEuNDQ3LDAsMCwxLC45MzgtLjc3M2MuMTcyLS4wNDIuMzk0LS4wNjcuNDc5LjA0OGEyLjQwNiwyLjQwNiwwLDAsMSwuMjA2LjM0NHYwYS44MzIuODMyLDAsMCwxLS4wMDYuODc2LDEuNzQzLDEuNzQzLDAsMCwxLTEuMjY0Ljc0OS44Ny44NywwLDAsMS0uNjU1LS4yMTNjLS4wMTctLjAyMy0uMDU1LS4wNzctLjAxOS0uMjFhNS40NjIsNS40NjIsMCwwLDEsLjMtLjc4MVptMy4zNjQsMjAuNGE2LjA4MSw2LjA4MSwwLDAsMS01LjMxNiwwLDcxLjU2Nyw3MS41NjcsMCwwLDEsLjIxOS05LjUyOCwxMCwxMCwwLDAsMCw0Ljg3NywwQTcxLjgyOSw3MS44MjksMCwwLDEsNTE0LjAzOCw1MTMuMTk0WidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIC01LjI1NiknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDI3J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQyNydcbiAgICAgICAgICBkPSdNNjE4LjAwNSw0ODcuMzc4Yy0uNjE3LTEuMzIzLTIuMi0xLjk5My00LjctMS45OTNzLTQuMDguNjcxLTQuNywxLjk5NGMtMS4zLDIuNzgxLDIuMzI4LDcuNDEsMi45MjMsOC4xMzlsLS4xOTQsMTIuNTM5YzAsLjUxNC41MjQsMS4yNzksMS45NjksMS4yNzlzMS45NjktLjc2NSwxLjk2OS0xLjI4NmwtLjE5NS0xMi41MzJDNjE1LjY3NSw0OTQuNzkxLDYxOS4zLDQ5MC4xNjEsNjE4LjAwNSw0ODcuMzc4Wm0tNS42NzEsMTAuMzk0LjAyNi0xLjY2YTMuNTU1LDMuNTU1LDAsMCwwLC42NS4xLjQxNS40MTUsMCwwLDAsLjA4OC4wMWMuMDEzLDAsLjAyNCwwLC4wMzcsMCwuMDU4LDAsLjExNiwwLC4xNzQsMGEzLjkxOCwzLjkxOCwwLDAsMCwuOTQ5LS4xMDdsLjAyNiwxLjY2YTIuOTMxLDIuOTMxLDAsMCwxLTEuOTQ5LDBabS0yLjk2Ni0xMC4wNDFjLjQ2OC0xLDEuNzk0LTEuNTExLDMuOTQtMS41MTFzMy40NzIuNTA4LDMuOTQsMS41MTFjLjgzNiwxLjc5Mi0xLjExMiw1LjAwOS0yLjM3NCw2LjdhNi42MzcsNi42MzcsMCwwLDAsLjIzLTEuNzMxLjQxNy40MTcsMCwwLDAtLjQxNy0uNDE3aDBhLjQxOC40MTgsMCwwLDAtLjQxNy40MTdjMCwuNjU3LS4yLDIuNDYxLTEuMDE3LDIuNjY1YTIuMDU2LDIuMDU2LDAsMCwxLS40OS0xLjE3NS40MTcuNDE3LDAsMCwwLS44MjYuMTIzLDQuNDUzLDQuNDUzLDAsMCwwLC4xMTIuNTE4QzYxMC44MzUsNDkzLjMsNjA4LjQ2LDQ4OS42NzgsNjA5LjM2OCw0ODcuNzMxWm0zLjk0LDIwLjc3MWMtLjksMC0xLjEyNi0uMzU5LTEuMTM0LS40MzhsLjE0Ni05LjQwOGE0LjIsNC4yLDAsMCwwLDEuOTc2LDBsLjE0Niw5LjRDNjE0LjQzNSw1MDguMTQzLDYxNC4yMDgsNTA4LjUsNjEzLjMwOCw1MDguNVonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTkxLjY1MSknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRnJ1aXRzVmVnZXRhYmxlID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9JzIwLjM0NydcbiAgICAgIGhlaWdodD0nMjQuMTAxJ1xuICAgICAgdmlld0JveD0nMCAwIDIwLjM0NyAyNC4xMDEnXG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPGcgaWQ9J0dyb2NlcnknIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0zOS40ODEgMC4wNTIpJz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzM4NidcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTczODYnXG4gICAgICAgICAgZD0nTTM0OS4yNjEsMzk5Ljk4OGEuNDY5LjQ2OSwwLDEsMSwuNDYxLS4zODVBLjQ3My40NzMsMCwwLDEsMzQ5LjI2MSwzOTkuOTg4WidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMjk0LjI4OSAtMzgwLjM0NiknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjEnXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTczODcnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3Mzg3J1xuICAgICAgICAgIGQ9J001OC43NDMsOC42MzhBNi4yLDYuMiwwLDAsMCw1NS40LDYuM2E2LjY2Miw2LjY2MiwwLDAsMC0zLjA1OC4wNTVoMGwtLjAzNC4wMDgtLjA5MS4wMmMtLjA3NC4wMTctLjE4OC4wNDUtLjMxLjA3Ni0uMTYuMDQxLS4zMjMuMDc4LS40ODUuMTA4cTAtLjE4Mi0uMDE0LS4zNzRhNi4xNjIsNi4xNjIsMCwwLDEsMS44Ny0zLjk1NkE2LjY0Myw2LjY0MywwLDAsMSw1NS4yMTIuOS40NjkuNDY5LDAsMCwwLDU0Ljg3LjAzMmE3LjQ0OCw3LjQ0OCwwLDAsMC0yLjIyMywxLjUwOSw3LjIyOSw3LjIyOSwwLDAsMC0xLjY1OSwyLjQzNyw0LjgzNyw0LjgzNywwLDAsMC0xLjExOS0xLjgzN0M0Ny43NDQuMDE5LDQzLjc2Mi42OCw0My41MjcuNzIxaDBhLjQ1Ny40NTcsMCwwLDAtLjM2Ny4zMTQuNi42LDAsMCwwLS4wMTcuMDY2Yy0uMDI3LjE1MS0uNTczLDMuMzQ2LjgsNS41NTdhNy4zNTMsNy4zNTMsMCwwLDAtMy45MTQsNi45MjMsMTEuNiwxMS42LDAsMCwwLDEuMTQyLDQuNTgxLDE0LjIsMTQuMiwwLDAsMCwyLjc0NCw0LjA5MUE1LjA0NCw1LjA0NCwwLDAsMCw0Ny4zMDksMjRhNi42LDYuNiwwLDAsMCwxLjg4LS4yNzZBMy4zMzEsMy4zMzEsMCwwLDEsNTEsMjMuNjkxbC4wMDYsMCwuMTEuMDMxQTYuNiw2LjYsMCwwLDAsNTMsMjRhNC45MTIsNC45MTIsMCwwLDAsMy4yNS0xLjYwOCwxMy45ODUsMTMuOTg1LDAsMCwwLDQuMDI5LTguODEyQTguMTYzLDguMTYzLDAsMCwwLDU4Ljc0Myw4LjYzOFpNNDkuMjA2LDIuOGE1LjI0Nyw1LjI0NywwLDAsMSwxLjI1NiwzLjQwOWMtLjAxNy4yMTEtLjAyNSwxLjEzMi0uMDI1LDEuMTMyTDQ2Ljg4MSwzLjc5NGEuNDY5LjQ2OSwwLDAsMC0uNjYzLjY2M0w0OS44LDguMDMzYy0xLjIyNC4wNjYtMy4zNDMtLjAyNy00LjU3Mi0xLjI1NUM0My43NSw1LjMsNDMuOTEyLDIuNTUyLDQ0LjAyLDEuNmMuOTUzLS4xMDgsMy43MDktLjI3LDUuMTg1LDEuMlpNNTUuNiwyMS43MTZBNC4wMzMsNC4wMzMsMCwwLDEsNTMsMjMuMDYyYTUuNzI4LDUuNzI4LDAsMCwxLTEuNjA5LS4yMzZsLS4xNDEtLjA0aDBhNC4yNjksNC4yNjksMCwwLDAtMi4zMjkuMDQsNS43MjgsNS43MjgsMCwwLDEtMS42MDkuMjM2QTQuMTcyLDQuMTcyLDAsMCwxLDQ0LjU4LDIxLjU5YTEzLjA1OCwxMy4wNTgsMCwwLDEtMy42MTItOC4wMDljMC0zLjQ0NSwxLjg3OC01LjQ0NCwzLjU3MS02LjE2M2wuMDI0LjAyNGE2LjYzMiw2LjYzMiwwLDAsMCw0LjY2NSwxLjU0N0E5LjkxLDkuOTEsMCwwLDAsNTAuOSw4Ljg2M2MuMzc0LS4wODIuMzY1LS4yNTYuMzg4LS4zNjRWOC40ODJhOS4yMTksOS4yMTksMCwwLDAsLjEwNy0uOTY1LjQ3NS40NzUsMCwwLDAsLjA4My0uMDA3Yy4yMi0uMDM4LjQ0MS0uMDg1LjY1OC0uMTQyLjA4NC0uMDIyLjE2NS0uMDQyLjIzMi0uMDU4LDEuOTM0LjY3NCwzLjg0NiwyLjg0OSwzLjg0Niw2LjI2OWE5Ljg1Nyw5Ljg1NywwLDAsMS0uNzQ3LDMuNDU1LjQ2OS40NjksMCwxLDAsLjg3NC4zMzksMTAuNzg5LDEwLjc4OSwwLDAsMCwuODExLTMuNzk1LDcuNTk0LDcuNTk0LDAsMCwwLTMuMTYyLTYuNDkzLDQuMzE3LDQuMzE3LDAsMCwxLDEuMTcuMTIyYzIuMDEzLjUyMSw0LjE4LDIuNzM3LDQuMTgsNi4zNzFBMTMuMTM4LDEzLjEzOCwwLDAsMSw1NS42LDIxLjcxNlonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTAuNSknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZT0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjEnXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBIYW5kQmFncyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxMSc+XG4gICAgICAgIDxnXG4gICAgICAgICAgZGF0YS1uYW1lPSdHcm91cCAxMCdcbiAgICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgICAgICBzdHJva2U9JyNmZmYnXG4gICAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD0nMTAnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9Jy4wOTEnXG4gICAgICAgID5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQ1J1xuICAgICAgICAgICAgZD0nTTE3Ljk1NCA3LjI1M3Y4LjU4NWExLjc5MSAxLjc5MSAwIDAxLTEuNzkxIDEuNzkxSDEuODM2YTEuNzkxIDEuNzkxIDAgMDEtMS43OTEtMS43OTFWNy4yNTNjMC0uOTg4IDE3LjkwOS0uOTg4IDE3LjkwOSAweidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoIGRhdGEtbmFtZT0nUmVjdGFuZ2xlIDM2JyBkPSdNLjEwMiA4Ljc3aDE3Ljc5NXYuOTEzSC4xMDJ6JyAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNDYnXG4gICAgICAgICAgICBkPSdNNC43OTMgNy4yNTNDNC45NzYgNC4wNjEgNy4xMTMuNjE0IDkgLjYxNGMyLjQxIDAgNC4wNDkgMy44NCA0LjIwNyA2LjYzOWguNTcyQzEzLjYxOCA0LjE2OCAxMS43OTEuMDQ0IDguOTk5LjA0NGMtMS4xMzEgMC0yLjMzOC45MjItMy4zMTIgMi41MjlhMTAuNDYzIDEwLjQ2MyAwIDAwLTEuNDY2IDQuNjh6J1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IEhvbWVDbGVhbmluZyA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScyMC41OSdcbiAgICAgIGhlaWdodD0nMjUuMDUnXG4gICAgICB2aWV3Qm94PScwIDAgMjAuNTkgMjUuMDUnXG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPGdcbiAgICAgICAgaWQ9J2hvbWVfY2xlYW5lcidcbiAgICAgICAgZGF0YS1uYW1lPSdob21lIGNsZWFuZXInXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0yMTQyLjE5MyAtNzg3LjYzNSknXG4gICAgICA+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0NDAnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDQwJ1xuICAgICAgICAgIGQ9J00yMTg4LjgxNSw4MzEuMzQ2YTIuNTM4LDIuNTM4LDAsMCwxLDIuNi0xLjgxdi0xLjU4NGEyNy42NzYsMjcuNjc2LDAsMCwwLTMuNzM0LS4xMTEsMy45NjIsMy45NjIsMCwwLDAtMy4xNjksMi4wMzRjLS4zMy42ODQsMi40OS0uMzM5LDIuNzE2LDEuNDcxJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0zOS42NjkgLTM3LjU1NCknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ0MSdcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NDEnXG4gICAgICAgICAgZD0nTTIyODkuNDY2LDg2Mi4zMzRhMTAuNzQyLDEwLjc0MiwwLDAsMCwxLjg5LDMuNzY1Yy4wODIuMTE5LS4wMjUuMjgtLjEzNy4yMDdhNi44LDYuOCwwLDAsMS0yLjk0LTMuNSdcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMTM4LjE2NyAtNzAuMzIpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjknXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0NDInXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDQyJ1xuICAgICAgICAgIGQ9J00yMjI2LjA1Miw4OTguNzg4YTIuOTMsMi45MywwLDAsMCwxLjQuMjE0LDMuMzQxLDMuMzQxLDAsMCwwLDEuMzE5LS4yMTR2LTEuNDM2YS4xNy4xNywwLDAsMC0uMTY5LS4xN2gtMi4zNzdhLjE3LjE3LDAsMCwwLS4xNjkuMTdaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC03OS4xMTMgLTEwMy4zOSknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ0MydcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NDMnXG4gICAgICAgICAgZD0nTTIxNTYuOTMsMTE4OS4yMDcnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTEzLjUxNiAtMzgwLjUyMiknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ0NCdcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NDQnXG4gICAgICAgICAgZD0nTTIzMjAuMzUzLDgzMC42MjJoMS4zMjh2MS41ODRoLTEuMzI4J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xNjguNjA1IC00MC4yMjUpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjknXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0NDUnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDQ1J1xuICAgICAgICAgIGQ9J00yMTUzLjQyMSw5MzYuNmExNS4xMTMsMTUuMTEzLDAsMCwxLTEuMTM0LDQuNzA3Ljc0NC43NDQsMCwwLDEtLjY4LjUxNWgtNy40YS43NTEuNzUxLDAsMCwxLS42ODgtLjU0NCwxMi4wNzgsMTIuMDc4LDAsMCwxLDIuMDY1LTEyLjI0MiwzLjUyNywzLjUyNywwLDAsMCwuNjc5LTMuMDU1LDEuMDUyLDEuMDUyLDAsMCwxLC42NzUtMS4xOTUnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMCAtMTI5LjU4OCknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ0NidcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NDYnXG4gICAgICAgICAgZD0nTTIyNzguOTEzLDkyNi4wMjVjMS40NzEuOTA1LS4yNSwxLjk3NC4wMDYsMi4yLjg0Ny43NTctLjAwNiwxLjgtLjAwNiwxLjhhMS40LDEuNCwwLDAsMSwuMzY5LDEuNzQxLDguNzY1LDguNzY1LDAsMCwxLDIuMzkxLDIuMDEnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTEyOS4yNTkgLTEzMC43NjIpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjknXG4gICAgICAgIC8+XG4gICAgICAgIDxsaW5lXG4gICAgICAgICAgaWQ9J0xpbmVfMTUnXG4gICAgICAgICAgZGF0YS1uYW1lPSdMaW5lIDE1J1xuICAgICAgICAgIHkxPScxLjUxMSdcbiAgICAgICAgICB4Mj0nMy4xNidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgyMTU0LjYyOCA3ODguMjM1KSdcbiAgICAgICAgICBmaWxsPSdub25lJ1xuICAgICAgICAgIHN0cm9rZT0nY3VycmVudENvbG9yJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMC45J1xuICAgICAgICAvPlxuICAgICAgICA8bGluZVxuICAgICAgICAgIGlkPSdMaW5lXzE2J1xuICAgICAgICAgIGRhdGEtbmFtZT0nTGluZSAxNidcbiAgICAgICAgICB4Mj0nMy4xNidcbiAgICAgICAgICB5Mj0nMS41MTEnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMjE1NC42MjggNzkyLjYzMiknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPGxpbmVcbiAgICAgICAgICBpZD0nTGluZV8xNydcbiAgICAgICAgICBkYXRhLW5hbWU9J0xpbmUgMTcnXG4gICAgICAgICAgeDI9JzQuMjU5J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDIxNTQuNjI4IDc5MS4xODkpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjknXG4gICAgICAgIC8+XG4gICAgICAgIDxjaXJjbGVcbiAgICAgICAgICBpZD0nRWxsaXBzZV85J1xuICAgICAgICAgIGRhdGEtbmFtZT0nRWxsaXBzZSA5J1xuICAgICAgICAgIGN4PScyLjA0NydcbiAgICAgICAgICBjeT0nMi4wNDcnXG4gICAgICAgICAgcj0nMi4wNDcnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMjE1OC4yMzkgNzk5LjcwOSknXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQ0NydcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0NDcnXG4gICAgICAgICAgZD0nTTIzODMuNzM4LDk1Ny4zODdhMS40ODksMS40ODksMCwwLDAsMi45NzgsMCwxLjQ4OSwxLjQ4OSwwLDAsMC0yLjk3OCwwWidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMjI4Ljc1NyAtMTU5LjExMiknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzAuOSdcbiAgICAgICAgLz5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgIGlkPSdFbGxpcHNlXzEwJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nRWxsaXBzZSAxMCdcbiAgICAgICAgICBjeD0nMi43NjQnXG4gICAgICAgICAgY3k9JzIuNzY0J1xuICAgICAgICAgIHI9JzIuNzY0J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDIxNTIuMjEyIDgwMi4xMDkpJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScwLjknXG4gICAgICAgICAgc3Ryb2tlPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBMYXB0b3BCYWdzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8Z1xuICAgICAgICBkYXRhLW5hbWU9J0dyb3VwIDYnXG4gICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICBzdHJva2U9JyNmZmYnXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9JzEwJ1xuICAgICAgICBzdHJva2VXaWR0aD0nLjA5MSdcbiAgICAgID5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMjInXG4gICAgICAgICAgZD0nTTYuMjI0IDEuNzQxYS40MDguNDA4IDAgMDEtLjI5Mi0uMTc1bC0uMDEzLS4wMTh2LS4wMjJjLS4wOC0uNjEyLjgxOC0uNzQ3Ljg1Ni0uNzUzbC40LS4wNTctLjMzNC4yMjJoMGEuODA3LjgwNyAwIDAwLS4xMjguMzM4Yy0uMTA1LjQyLS4zNzUuNDY1LS40ODkuNDY1em0tLjEzLS4yNjNhLjIxMy4yMTMgMCAwMC4xMy4wODFjLjEwNiAwIC4yNDQtLjA1Ni4zMDUtLjMyM2ExLjY4NiAxLjY4NiAwIDAxLjA3LS4yMzdjLS4yMTQuMDY0LS41MjMuMjA1LS41MDUuNDc5eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMjMnXG4gICAgICAgICAgZD0nTTkgNi40OTZILjA0NnY2LjhhLjgzMy44MzMgMCAwMC44MzMuODMzaDE2LjI0M2EuODMzLjgzMyAwIDAwLjgzMy0uODMzdi02Ljh6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAyNCdcbiAgICAgICAgICBkPSdNMTcuNDQgMi4xMzVILjU2MWEuNTE1LjUxNSAwIDAwLS41MTUuNTE1djYuMjg1YS44MzMuODMzIDAgMDAuODMzLjgzM2gxNi4yNDNhLjgzMy44MzMgMCAwMC44MzMtLjgzM1YyLjY1YS41MTUuNTE1IDAgMDAtLjUxNS0uNTE1eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMjUnXG4gICAgICAgICAgZD0nTTExLjc3NiAxLjc0MWMtLjExMyAwLS4zODctLjA0NS0uNDgyLS40NjRhLjczNC43MzQgMCAwMC0uMTM0LS4zNDJsLS4zMzQtLjIyMi40LjA2MWMuMDM4LjAwNi45MzYuMTQxLjg1Ni43NTN2LjAyMmwtLjAxMy4wMThhLjQwOC40MDggMCAwMS0uMjkzLjE3NHpNMTEuNC45OTlhMS42ODIgMS42ODIgMCAwMS4wNzEuMjM4Yy4wNjEuMjY3LjIuMzIzLjMwNS4zMjNhLjIxNi4yMTYgMCAwMC4xMy0uMDgxYy4wMTktLjI3Ni0uMjkxLS40MTYtLjUwNi0uNDh6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAyNidcbiAgICAgICAgICBkPSdNMTEuMjk1Ljc1MkEzLjMzMyAzLjMzMyAwIDAwOSAuMDQ1YTMuMzMzIDMuMzMzIDAgMDAtMi4yOTUuNzA3LjEzNi4xMzYgMCAwMC4xNTguMjIyQTMuMDM2IDMuMDM2IDAgMDE4Ljk5OS4zMThhMy4wMzcgMy4wMzcgMCAwMTIuMTM2LjY1Ni4xMzYuMTM2IDAgMTAuMTU4LS4yMjJ6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aCBkYXRhLW5hbWU9J1BhdGggMjcnIGQ9J005IDkuNDE5aC0uOTU4di43NTFoMS45MTd2LS43NTF6JyAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAyOCdcbiAgICAgICAgICBkPSdNOC42OTggOC4yMTRoMGEuOS45IDAgMDAtLjY1NyAxLjI0aDEuOTE3YS45LjkgMCAwMC0uNjU3LTEuMjRoMGExLjY1NiAxLjY1NiAwIDAwLS42IDB6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aCBkYXRhLW5hbWU9J1BhdGggMjknIGQ9J005IDEwLjE3aC0uOTU4djEuMDA5aDEuOTE3VjEwLjE3eicgLz5cbiAgICAgICAgPHBhdGggZGF0YS1uYW1lPSdQYXRoIDMwJyBkPSdNOSAxMC40NzNoLS44MDd2LjcwNmgxLjYxNXYtLjcwNnonIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDMxJ1xuICAgICAgICAgIGQ9J000LjcyNSAyLjEzNWgxLjEzNmExLjI4NyAxLjI4NyAwIDAwLjY0OC0uODMuMTE4LjExOCAwIDAwLS4xMTctLjEzOWgwYS4xMTYuMTE2IDAgMDAtLjA5NS4wNDggMS44NzMgMS44NzMgMCAwMS0xLjM4LjcyMS4xMTguMTE4IDAgMDAtLjA4OC4wNXonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDMyJ1xuICAgICAgICAgIGQ9J00xMy4yNzUgMi4xMzVIMTIuMTRhMS4yODcgMS4yODcgMCAwMS0uNjQ4LS44My4xMTguMTE4IDAgMDEuMTE2LS4xMzloMGEuMTE2LjExNiAwIDAxLjA5NS4wNDggMS44NzMgMS44NzMgMCAwMDEuMzguNzIxLjExOC4xMTggMCAwMS4wODguMDV6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTGlwcyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxNCc+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDUyJ1xuICAgICAgICAgIGQ9J002LjAzNSAxNy4zOTJ2LTYuMmEuNTY3LjU2NyAwIDAwLS41MTYtLjYxSDUuNVY1LjI2OWgtLjUyN2MwLS44NzcuMDA4LTEuNjA4LjAxMy0yLjIxMi4wMTktMi4xNDkuMDIzLTIuNjYtLjIzNS0yLjkyM0EuNDU0LjQ1NCAwIDAwNC40MjIgMGExLjI4MiAxLjI4MiAwIDAwLS41NDkuMTkzIDQuMjkgNC4yOSAwIDAxLS43MDguMyAyLjg4MiAyLjg4MiAwIDAwLTIuMTE3IDIuMjM1djIuNTQxSC41NDF2NS4zMDZILjUxOWEuNTY3LjU2NyAwIDAwLS41MTYuNjF2Ni4yYS41NjcuNTY3IDAgMDAuNTE2LjYxaDUuMDA2YS41NjcuNTY3IDAgMDAuNTEtLjYwM3ptLTEuMTQ0LTYuODE3SDEuMTQ4VjUuOTMybDMuNzQzLjA0M3onXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBNZWF0RmlzaCA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPScyNC4wMDMnXG4gICAgICBoZWlnaHQ9JzI0J1xuICAgICAgdmlld0JveD0nMCAwIDI0LjAwMyAyNCdcbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8Z1xuICAgICAgICBpZD0nTWVhdF9GaXNoJ1xuICAgICAgICBkYXRhLW5hbWU9J01lYXQgJmFtcDsgRmlzaCdcbiAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTEwMC4yNzQgLTEyNi43ODYpJ1xuICAgICAgPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDMzJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQzMydcbiAgICAgICAgICBkPSdNMTUyLjE2NSwxNDcuMjM4Yy0uMTg2LDAtLjM2Ni0uMDA1LS41NDItLjAxNmEuNDY1LjQ2NSwwLDAsMS0uMjctLjEwOGMtLjUyNS0uNDQyLTEuMDQ5LS45MTEtMS41NDYtMS4zOC0uNTA4LS41MDgtLjk1Mi0xLjAzNi0xLjM4My0xLjU0NmEuNTQ1LjU0NSwwLDAsMS0uMTI0LS4yODljLS4yMzQtMy44MTEsMi4xMjktMTAuMTQzLDQuNzY5LTEyLjc4NGE5LjUyOCw5LjUyOCwwLDAsMSwxLjgtMS40NTMuNDYzLjQ2MywwLDEsMSwuNS43ODEsOC42MzksOC42MzksMCwwLDAtMS42MjksMS4zMThjLTIuNDIsMi40Mi00LjY2MSw4LjM3NS00LjUxNSwxMS45MjkuNC40NzQuOC45NDQsMS4yMzYsMS4zNzguNDM5LjQxNC45MDcuODM1LDEuMzc5LDEuMjM2LDMuNS4xNTMsOS41MDgtMi4xLDExLjkxOS00LjUwNmE4LjY5MSw4LjY5MSwwLDAsMCwxLjMyOC0xLjYzOC40NjMuNDYzLDAsMSwxLC43ODEuNSw5LjYyNSw5LjYyNSwwLDAsMS0xLjQ2MiwxLjhDMTYxLjg4OCwxNDQuOTczLDE1Ni4wMSwxNDcuMjM4LDE1Mi4xNjUsMTQ3LjIzOFonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTQyLjAwOSAtMi40NTMpJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQzNCdcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0MzQnXG4gICAgICAgICAgZD0nTTEwNS4wNjUsMjQ5Ljk3OGEyLjQ1NywyLjQ1NywwLDAsMS0xLjc0NS0uNzI5LDIuNTQ3LDIuNTQ3LDAsMCwxLS43MDctMS42MSwyLjQ1NCwyLjQ1NCwwLDAsMS0yLjMzOC0yLjQ4MywyLjQ3OSwyLjQ3OSwwLDAsMSwzLjUxMy0yLjIxbDIuNjM3LTIuNjYzYS40NjQuNDY0LDAsMCwxLC42NTkuNjUzbC0yLjg4OSwyLjkxNmEuNDY1LjQ2NSwwLDAsMS0uNTkyLjA1NSwxLjU0NywxLjU0NywwLDAsMC0yLjQsMS4yNTcsMS41NDQsMS41NDQsMCwwLDAsLjQ1NywxLjExNCwxLjU3MiwxLjU3MiwwLDAsMCwxLjM2NS40MTYuNDYzLjQ2MywwLDAsMSwuNTM1LjUzNiwxLjU5MiwxLjU5MiwwLDAsMCwuNDI1LDEuMzc0LDEuNTQsMS41NCwwLDAsMCwyLjM1NS0xLjk2My40NjQuNDY0LDAsMCwxLC4wNjItLjU4M2wyLjkxNi0yLjg4OGEuNDYzLjQ2MywwLDEsMSwuNjUyLjY1OGwtMi42NjgsMi42NDRhMi40ODcsMi40ODcsMCwwLDEtLjQ5MSwyLjc3OEEyLjQ1NCwyLjQ1NCwwLDAsMSwxMDUuMDY1LDI0OS45NzhaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDAgLTk5LjE5MiknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDM1J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQzNSdcbiAgICAgICAgICBkPSdNMjA2LjM3NCwxMzguNzY5YTUuMjM2LDUuMjM2LDAsMCwxLTItLjQ3NUExNC42MDksMTQuNjA5LDAsMCwxLDIwMCwxMzUuMTc3Yy0yLjE5My0yLjE5My0zLjYtNC43MDctMy41OTMtNi40YTEuODYyLDEuODYyLDAsMCwxLDEuOTg5LTEuOTg3aC4wMThjMS43LDAsNC4yLDEuNDA4LDYuMzg1LDMuNTkzbDAsMGMyLjYyOSwyLjY1NSw0LjU5Miw2LjMwOCwzLjA1LDcuODQ4QTIuMDExLDIuMDExLDAsMCwxLDIwNi4zNzQsMTM4Ljc2OVptLTcuOTYtMTEuMDU2SDE5OC40YS45NDguOTQ4LDAsMCwwLTEuMDY3LDEuMDY2Yy0uMDA4LDEuNDM5LDEuMzI3LDMuNzQ3LDMuMzIyLDUuNzQzYTEzLjY2OSwxMy42NjksMCwwLDAsNC4wODQsMi45MmMxLjEzOC40ODMsMi4wNTQuNTMyLDIuNDU1LjEzMy44MTQtLjgxNC0uMjM5LTMuNy0zLjA1NC02LjU0MUMyMDIuMTUzLDEyOS4wNDUsMTk5Ljg1NCwxMjcuNzEzLDE5OC40MTQsMTI3LjcxM1onXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTg0LjExNyAwKSdcbiAgICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0MzYnXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDM2J1xuICAgICAgICAgIGQ9J00yMTYuODQzLDE0OC4yMjNoMGMtMS4wMzksMC0yLjktMS4yMTQtNC43NDktMy4wODQtMS41MzgtMS41MTgtMy4wOS0zLjU4NS0zLjA3OS00Ljc3YS45NjMuOTYzLDAsMCwxLC4yODMtLjcxNS45NS45NSwwLDAsMSwuNy0uMjY2SDIxMGMxLjE4NywwLDMuMjQzLDEuNTQ0LDQuNzYsMy4wODEsMS44NjgsMS44NDUsMy4wNzksMy43MDcsMy4wODIsNC43NDZhLjk0NC45NDQsMCwwLDEtMSwxLjAwOFptLTYuODExLTcuOTE2YS4yNjguMjY4LDAsMCwwLS4xLjAxN2MtLjEzMy4zMy43LDIuMDY5LDIuODE1LDQuMTYxLDIuMjcsMi4zLDMuOTEyLDIuOTMzLDQuMTgxLDIuOC4xMTUtLjI1My0uNTIxLTEuODk1LTIuODE2LTQuMTU5bDAsMEMyMTIuMTc0LDE0MS4xNjMsMjEwLjU0LDE0MC4zMDYsMjEwLjAzMiwxNDAuMzA2WidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtOTUuMTQ2IC0xMS4wMjcpJ1xuICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD0nUGF0aF8xNzQzNydcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0MzcnXG4gICAgICAgICAgZD0nTTE4MS4yNTEsMTY4LjE3NGwtLjgzLS40MWE1LjIyMyw1LjIyMywwLDAsMSwuMzkxLS42ODkuNDY0LjQ2NCwwLDAsMSwuNzU1LjUzOUE0LjE0OCw0LjE0OCwwLDAsMCwxODEuMjUxLDE2OC4xNzRaJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC03MC4xMjkgLTM1LjA4NCknXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDM4J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQzOCdcbiAgICAgICAgICBkPSdNMTY0Ljc4OSwxODkuMTczYS40NzguNDc4LDAsMCwxLS4wOTUtLjAxLjQ2My40NjMsMCwwLDEtLjM1OS0uNTQ4LDE4LjI4NSwxOC4yODUsMCwwLDEsMS4yMy0zLjguNDY0LjQ2NCwwLDAsMSwuODQ1LjM4MSwxNy4zNTgsMTcuMzU4LDAsMCwwLTEuMTY4LDMuNjExQS40NjMuNDYzLDAsMCwxLDE2NC43ODksMTg5LjE3M1onXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTU2LjA0NiAtNTAuNTM1KSdcbiAgICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9J1BhdGhfMTc0MzknXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDM5J1xuICAgICAgICAgIGQ9J00yMzkuOTYsMTcwLjhhLjQ2My40NjMsMCwwLDEtLjMyOC0uMTM2bC0uMzgyLS4zODJhLjQ2My40NjMsMCwwLDEsLjY1NS0uNjU1bC4zODIuMzgyYS40NjQuNDY0LDAsMCwxLS4zMjguNzkxWidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMTIxLjQ4NyAtMzcuMzcyKSdcbiAgICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGNvbnN0IE1pbnVzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMTJweCcsXG4gIGhlaWdodCA9ICcycHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PVwiMCAwIDEyIDJcIlxuICAgID5cbiAgICAgIDxyZWN0XG4gICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSA1MjJcIlxuICAgICAgICB3aWR0aD1cIjEyXCJcbiAgICAgICAgaGVpZ2h0PVwiMlwiXG4gICAgICAgIHJ4PVwiMVwiXG4gICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IE9yYWxDYXJlID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8ZyBmaWxsPXtjb2xvcn0+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDY1J1xuICAgICAgICAgIGQ9J00zLjExOCAxMS4wMjRhMi4yNjcgMi4yNjcgMCAwMS4xNDIgMS40NTRsLS4wMjcuMzMzYy0uMTI3IDEuNjU1LjExMSAzLjgwNyAxLjE1NyA0Ljg4N2EuNDYzLjQ2MyAwIDAwLjEuMDQ2LjI1Mi4yNTIgMCAwMC4zMTctLjEyNy4yNTUuMjU1IDAgMDAuMDE3LS4xNXYtLjAyYy0uMDE3LS4xNTctLjM4NS0zLjg3IDEuMjctNS44ODdhMS4wMzUgMS4wMzUgMCAwMTEuNi4wMDljMS42MjMgMi4wMjUgMS4yNTcgNS43MTkgMS4yNDEgNS44NzV2LjAyYS4yNTUuMjU1IDAgMDAuMDE3LjE1LjI1Mi4yNTIgMCAwMC4zMTcuMTI3LjM4OC4zODggMCAwMC4xMTEtLjA0OWMxLjA0My0xLjA3OCAxLjI4MS0zLjIzMSAxLjE1NC00Ljg4N2EzNS4zODQgMzUuMzg0IDAgMDAtLjAyNy0uMzMzIDIuMjY4IDIuMjY4IDAgMDEuMTQyLTEuNDU1IDMuNzkyIDMuNzkyIDAgMDExLjUxNy0xLjA4NyAyLjIyMSAyLjIyMSAwIDAwMS0xLjUyMiAzLjgxOSAzLjgxOSAwIDAwLS4xNi0yLjE5MmMtLjU1NS0xLjM4OC0xLjgyNy0xLjkyNC0zLjUtMS40NjZhNC41MjEgNC41MjEgMCAwMC0xLjM2OC42MjJjLS4yLjEyNi0uNDA5LjI1My0uNjY2LjM4NGEyLjc2MSAyLjc2MSAwIDAwMS41NjYuMjM3LjI0OC4yNDggMCAxMS4xLjQ4NiAzLjgzNyAzLjgzNyAwIDAxLTIuMzU1LS40OTMgMTAuNDU0IDEwLjQ1NCAwIDAxLS40NzgtLjI2NSA3LjQ2NiA3LjQ2NiAwIDAwLTIuMzM4LTEuMDE0QTIuNzMgMi43MyAwIDAwLjY5OCA2LjU4MWEyLjkwOCAyLjkwOCAwIDAwLjkyIDMuMzQzIDMuNzg0IDMuNzg0IDAgMDExLjUgMS4xeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjYnXG4gICAgICAgICAgZD0nTTE3LjI1Ni45M0g2LjQwOUw2LjAzNi41NThBMS44ODggMS44ODggMCAwMDQuNjkzLjAwM0guNjY0YS42NjYuNjY2IDAgMDAtLjY2Ni42NjZ2MS44ODlhLjI1LjI1IDAgMDAuNSAwVi42NjdBLjE2NS4xNjUgMCAwMS42NjMuNTAyaC4xdjIuMDg3YS4yNS4yNSAwIDEwLjUgMFYuNDk3aC4yMjJ2Mi4wODdhLjI1LjI1IDAgMTAuNSAwVi40OTdoLjIyMnYyLjA4N2EuMjUuMjUgMCAxMC41IDBWLjQ5N2guMjIydjIuMDg3YS4yNS4yNSAwIDEwLjUgMFYuNDk3aC4yMjJ2Mi4wODdhLjI1LjI1IDAgMTAuNSAwVi40OTdoLjIyMnYyLjA4N2EuMjUuMjUgMCAxMC41IDBWLjUwN2ExLjQgMS40IDAgMDEuODIzLjRsLjc5Mi43ODlhMS44ODggMS44ODggMCAwMDEuMzQzLjU1NWg5LjQ0MWEuNjY2LjY2NiAwIDEwMC0xLjMyM3onXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBPdXRlcldlYXIgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMjknIGZpbGw9e2NvbG9yfT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTknXG4gICAgICAgICAgZD0nTTE1LjY0MyA1LjY1OWExLjk5MyAxLjk5MyAwIDAwLjQ1My0uMDYyYy0uMjI0LTEuMi0uNC0xLjktLjQtMS45YTUuNTQ2IDUuNTQ2IDAgMDAtMS43MTMtMS4wNjggMS45NjQgMS45NjQgMCAwMDEuNjYgMy4wM3onXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDEwMCdcbiAgICAgICAgICBkPSdNLjg5NiA1LjU5NmExLjk2MiAxLjk2MiAwIDAwMi4xMTMtMi45NyA1LjU2MSA1LjU2MSAwIDAwLTEuNzEyIDEuMDY4cy0uMTc4LjY5Ny0uNDAxIDEuOTAyeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTAxJ1xuICAgICAgICAgIGQ9J00xNS42NDEgNi4xNDZhMi40NjYgMi40NjYgMCAwMS0yLjQ2My0yLjQ2MyAyLjQzNiAyLjQzNiAwIDAxLjM0OC0xLjI0IDE0LjY2MSAxNC42NjEgMCAwMC0yLjA4LS42MUwxMS40MjIuNjY0QTUuNDg0IDUuNDg0IDAgMDA4Ljk0Ny4wMDhjLS4yMjUtLjAxLS42NzctLjAxLS45MDQgMGE1LjUgNS41IDAgMDAtMi40NzguNjUzbC0uMDIgMS4xNjlhMTQuNzQ2IDE0Ljc0NiAwIDAwLTIuMDguNjEyIDIuNDQ2IDIuNDQ2IDAgMDEtMi42NTggMy42NCA1My42ODYgNTMuNjg2IDAgMDAtLjc3MSAxMS4yNDRILjI2di4xMjNhLjUxMi41MTIgMCAwMC41MzIuNDkzaDEuMjRhLjUxMi41MTIgMCAwMC41MzItLjQ5M3YtLjEyM2guMjNzLS4yMzgtNy4yODEgMS4wMi05LjE0M3Y5LjA4YTIzLjI3NSAyMy4yNzUgMCAwMDQuMzI2LjczNVYxLjE1MWE1LjIyNyA1LjIyNyAwIDAxLTEuNzQ5LS4xOVM2LjUyOS40OTggOC4wNDMuNTE2aC45YzEuNS4wMjMgMS42NTMuNDQ1IDEuNjUzLjQ0NWE1LjIyNiA1LjIyNiAwIDAxLTEuNzUxLjE5djE2Ljg0N2EyMy4yNzQgMjMuMjc0IDAgMDA0LjMyOS0uNzM2VjguMTg0YzEuMjU5IDEuODY2IDEuMDIzIDkuMTQzIDEuMDIzIDkuMTQzaC4yMjl2LjEyM2EuNTExLjUxMSAwIDAwLjUzMi40OTNIMTYuMmEuNTEyLjUxMiAwIDAwLjUzMi0uNDkzdi0uMTIzaC4yMjRhNTMuODI3IDUzLjgyNyAwIDAwLS43NzEtMTEuMjQ2IDIuNDYyIDIuNDYyIDAgMDEtLjU0NC4wNjV6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgUGFudHMgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGZpbGw9e2NvbG9yfT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTAyJ1xuICAgICAgICAgIGQ9J003Ljk5OSAxLjE2NWExMC43MjEgMTAuNzIxIDAgMDAtLjEzOS0uNzFMNy43OTcuMTg3QS4yNDMuMjQzIDAgMDA3LjU2MSAwSC41NTNhLjI0My4yNDMgMCAwMC0uMjM2LjE4N0wuMjUzLjQ1NWMtLjA1Ni4yMzUtLjEuNDcyLS4xMzkuNzF6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxMDMnXG4gICAgICAgICAgZD0nTS4wMTggMi4wNDhhOS45MyA5LjkzIDAgMDAtLjAxNS44MjhsLjM3OSAxMy40NzlhLjI0My4yNDMgMCAwMC4yNDIuMjM2SC44NnYxLjE1NWEuMjU0LjI1NCAwIDAwLjI1NC4yNTRoMS4yODhhLjI1NC4yNTQgMCAwMC4yNTQtLjI1NHYtMS4xNTVoLjE3MmEuMjQzLjI0MyAwIDAwLjI0Mi0uMjI1bC44MzMtMTEuMjI4YS4xNS4xNSAwIDAxLjMgMGwuODI1IDExLjIyOGEuMjQzLjI0MyAwIDAwLjI0Mi4yMjVoLjIzM3YxLjE1NWEuMjU0LjI1NCAwIDAwLjI1NC4yNTRoMS4yODhhLjI1NC4yNTQgMCAwMC4yNTQtLjI1NHYtMS4xNTVoLjE3OWEuMjQzLjI0MyAwIDAwLjI0Mi0uMjM2TDguMSAyLjg3NmMuMDA4LS4yNzYgMC0uNTUzLS4wMTUtLjgyOHonXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBQZXRDYXJlID0gKHByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgdmlld0JveD0nMCAwIDUxMiA1MTInXG4gICAgICB3aWR0aD0nNjAnXG4gICAgICBoZWlnaHQ9JzYwJ1xuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxnIGlkPSdPdXRsaW5lJz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPSdNODMuMjQyLDE5Mi41LDc2Ljc1OCwxNzcuODdjLTE4LjUsOC4yLTI4LjEzMywxNy45ODctMjguNywyOS4wODdMMTYuMTQyLDM3NC41YTgsOCwwLDAsMCwzLjgxMiw4LjRDNDcuMTYxLDM5OC44NSw4Mi43Miw0MTEuMjgsMTI1LjY0Miw0MTkuODQ1LDE2NS40ODcsNDI3LjgsMjEwLjU2NCw0MzIsMjU2LDQzMnM5MC41MTMtNC4yLDEzMC4zNTgtMTIuMTU1YzQyLjkyMi04LjU2NSw3OC40ODEtMjEsMTA1LjY4OC0zNi45NDNhOCw4LDAsMCwwLDMuODEyLTguNGwtMTAuNjY3LTU2TDQ2OS40NzUsMzIxLjVsMy4yNjMsMTcuMTM2LTEwLjY1Niw1LjU1N2EyNzAuNTMsMjcwLjUzLDAsMCwxLTQ4LjA3NiwxOS41NTJDMzY5LjkxNywzNzYuODA2LDMxMy44LDM4NCwyNTYsMzg0Yy01OS4zLDAtMTE2LjUzNC03LjUzMS0xNjEuMTUxLTIxLjIwNmwtNC42OSwxNS4zQzEzNi4yNTUsMzkyLjIxOSwxOTUuMTUxLDQwMCwyNTYsNDAwYzU5LjMsMCwxMTcuMDI4LTcuNDI4LDE2Mi41NTEtMjAuOTE3YTI4Ni42LDI4Ni42LDAsMCwwLDUwLjkyOS0yMC43MDZsNi4zODUtMy4zMjksMy4yLDE2LjgxOWMtMTA3LjIzMiw1OC43NDctMzM4LjksNTguNzQ3LTQ0Ni4xMzcsMEw2MC4yMTQsMjI4LjYzMnExMS43OTMsOS4wNywzNC44NjcsMTYuMjc2QzEzNC4wMzcsMjU3LjA0MSwxOTIuNjg5LDI2NCwyNTYsMjY0czEyMS45NjMtNi45NTksMTYwLjkyLTE5LjA5MnEyMy4wNTYtNy4xODIsMzQuODY3LTE2LjI3Nkw0NjYuNDI4LDMwNS41bDE1LjcxNy0yLjk5NC0xOC4xODctOTUuNDc3Yy0uODgtMTguOC0yNy4yMjktMzMuNTE0LTc4LjM4OC00My43NTRsLTMuMTQsMTUuNjg4QzQzNC4zLDE4OS4zNDIsNDQ4LDIwMi41LDQ0OCwyMDhjMCw0LjY4LTguOTUxLDEyLjE4NC0yOC43MTYsMTkuMjUzYTQ4LjIzNyw0OC4yMzcsMCwwLDAtMzUuODU2LTI2LjY3Miw0OC4xMjIsNDguMTIyLDAsMCwwLTQwLTQwLjAwOCw0OC4xNDcsNDguMTQ3LDAsMCwwLTEzLjQ4OS0yNi41MTEsNDcuNjQ2LDQ3LjY0NiwwLDAsMC0yNi41LTEzLjQ5Myw0OC4wMTUsNDguMDE1LDAsMCwwLTk0Ljg2NCwwLDQ3LjY0Nyw0Ny42NDcsMCwwLDAtMjYuNTA2LDEzLjQ5NCw0OC4xNjcsNDguMTY3LDAsMCwwLTEyLjcsMjIuNjA4Yy0yOS43LDMuMzktNTUuOCw4LjUxOC03NS44LDE0LjkwNWw0Ljg3LDE1LjI0MWEzMTYuOSwzMTYuOSwwLDAsMSw0MC44LTkuNjcsNDcuNTQsNDcuNTQsMCwwLDAtMTAuNjcsMjMuNDIyLDQ3LjY0Nyw0Ny42NDcsMCwwLDAtMjYuNTA2LDEzLjQ5NCw0OC4xNzUsNDguMTc1LDAsMCwwLTkuMzMsMTMuMkM3Mi45NTUsMjIwLjE4OCw2NCwyMTIuNjgxLDY0LDIwOCw2NCwyMDQuNjI5LDY5LjA1NSwxOTguNzg3LDgzLjI0MiwxOTIuNVptMzAuMTM0LDMyLjg4QTMxLjc5MSwzMS43OTEsMCwwLDEsMTM2LDIxNmE4LDgsMCwwLDAsOC04LDMyLjAxMywzMi4wMTMsMCwwLDEsMzItMzIsOCw4LDAsMCwwLDgtOGMwLTEuMDU1LjA1NS0yLjE1LjE2LTMuMjI4QTMyLjAyMywzMi4wMjMsMCwwLDEsMjE2LDEzNmE4LDgsMCwwLDAsOC04LDMyLDMyLDAsMCwxLDY0LDAsOCw4LDAsMCwwLDgsOCwzMi4wMjQsMzIuMDI0LDAsMCwxLDMxLjgzOCwyOC43NDdjLjEwNywxLjEuMTYyLDIuMi4xNjIsMy4yNTNhOCw4LDAsMCwwLDgsOCwzMi4wMzYsMzIuMDM2LDAsMCwxLDMyLDMyLDgsOCwwLDAsMCw4LDgsMzIuMTIsMzIuMTIsMCwwLDEsMjcuNzU0LDE2LjA3M0MzNjYuNDQ2LDI0Mi4yMzIsMzEzLjMxNSwyNDgsMjU2LDI0OHMtMTEwLjQ0LTUuNzY4LTE0Ny43NDgtMTUuOTI1QTMyLjIsMzIuMiwwLDAsMSwxMTMuMzc2LDIyNS4zNzdaTTI0OCwxNzZ2MTZhMjQuMDI3LDI0LjAyNywwLDAsMC0yNCwyNEgyMDhBNDAuMDQ1LDQwLjA0NSwwLDAsMSwyNDgsMTc2Wm0yNC0yNEgyNTZWMTM2aDE2Wm0zMiw2NEgyODhWMjAwaDE2Wk0xNjgsMjAwaDE2djE2SDE2OFpNNzQuMywyOTQuNjQ2bDE1LjcyNiwyLjk0OEw3OS40MzcsMzU0LjA4MSw2My43MSwzNTEuMTM0Wm0xOC4yOTQtMTEuMTc1LTE1Ljc0Mi0yLjg2MiwzLjI4LTE4LjA0LDE1Ljc0MiwyLjg2MlonXG4gICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgUHVyc2UgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMic+XG4gICAgICAgIDxnXG4gICAgICAgICAgZGF0YS1uYW1lPSdHcm91cCAxJ1xuICAgICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICAgIHN0cm9rZT0nI2ZmZidcbiAgICAgICAgICBzdHJva2VNaXRlcmxpbWl0PScxMCdcbiAgICAgICAgICBzdHJva2VXaWR0aD0nLjA5MSdcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtODUuMTY5IC03LjM0OCknXG4gICAgICAgID5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDEnXG4gICAgICAgICAgICBkPSdNOTguOTQ2IDExLjM4MWwuMjE3LS4wNjFhNS4xMjQgNS4xMjQgMCAwMC0uNi0xLjM0MSAxMS4zIDExLjMgMCAwMC0xLjA0LTEuMjc5IDQuNzI0IDQuNzI0IDAgMDAtLjkzLS42NzlsLS4yNjktLjE0M2EzLjczNSAzLjczNSAwIDAwLS44OC0uMzIzIDUuNDM3IDUuNDM3IDAgMDAtMS4yNzQtLjE2N2wtLjMxNy4wMTRhNS4zIDUuMyAwIDAwLS45NTcuMTUyYy0uMS4wMjQtLjIuMDYxLS4zLjA5MmE1LjAwOSA1LjAwOSAwIDAwLS44NDYuMzc0IDQuNzM0IDQuNzM0IDAgMDAtLjkzLjY3OSA1LjcwOSA1LjcwOSAwIDAwLTEuNjM5IDIuNjE1bC4yMTcuMDYxLjIxNy4wNjFhNC43IDQuNyAwIDAxLjk3Mi0xLjggNS4xMDYgNS4xMDYgMCAwMS42LS41MDggNC45ODIgNC45ODIgMCAwMS44NzQtLjUyMSA1LjIgNS4yIDAgMDExLjAxOC0uMzUgNS4zMTUgNS4zMTUgMCAwMTEuMS0uMTIzIDUuNSA1LjUgMCAwMTEuMS4xMjMgNS4yIDUuMiAwIDAxMS4wMTguMzUgNC45OSA0Ljk5IDAgMDEuODc0LjUyMSA1LjA2NiA1LjA2NiAwIDAxLjU4NS41IDQuNyA0LjcgMCAwMS45ODIgMS44MDZ6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAyJ1xuICAgICAgICAgICAgZD0nTTkzLjc4NyAyMi4zOTJhMjIuMTQ5IDIyLjE0OSAwIDAxLTguNTYxLTEuNzI3bDMuMy05LjI4NWgxMS4yODJsMy4zIDkuMjg1YTIyLjE0OSAyMi4xNDkgMCAwMS04LjU2MSAxLjcyN3onXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDMnXG4gICAgICAgICAgICBkPSdNODguNTMxIDExLjM4MWwtMS4zNTMgMy44YTE3LjY0NSAxNy42NDUgMCAwMDYuNjA5IDEuMzUxaC43NjVhMTcuNjQzIDE3LjY0MyAwIDAwNi42MDktMS4zNTFsLTEuMzUzLTMuOHonXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQnXG4gICAgICAgICAgICBkPSdNODguNTMxIDExLjIzbC0xLjIyNSAzLjQ0MmExNC4wNTkgMTQuMDU5IDAgMDA2LjQ4MSAxLjcxaC43NjVhMTQuMDU5IDE0LjA1OSAwIDAwNi40ODEtMS43MWwtMS4yMjQtMy40NDJ6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHJlY3RcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUmVjdGFuZ2xlIDI2J1xuICAgICAgICAgICAgd2lkdGg9JzIuMDEnXG4gICAgICAgICAgICBoZWlnaHQ9JzIuMDEnXG4gICAgICAgICAgICByeD0nLjY3MidcbiAgICAgICAgICAgIHRyYW5zZm9ybT0ncm90YXRlKC00NC45OTkgNjYuMDI2IC0xMDMuOTc2KSdcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNSdcbiAgICAgICAgICAgIGQ9J00xMDEuMTYyIDE1LjE4MmgwbC0uMTczLS40ODZhMTQuMDM0IDE0LjAzNCAwIDAxLTYuNDM2IDEuNjg3aC0uMjczdi4xNWguMjcyYTE3LjY0OSAxNy42NDkgMCAwMDYuNjEtMS4zNTF6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHJlY3RcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUmVjdGFuZ2xlIDI3J1xuICAgICAgICAgICAgd2lkdGg9JzIuMDEnXG4gICAgICAgICAgICBoZWlnaHQ9JzIuMDEnXG4gICAgICAgICAgICByeD0nLjY3MidcbiAgICAgICAgICAgIHRyYW5zZm9ybT0ncm90YXRlKC00NC45OTkgNjYuMDI2IC0xMDMuOTc2KSdcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxyZWN0XG4gICAgICAgICAgICBkYXRhLW5hbWU9J1JlY3RhbmdsZSAyOCdcbiAgICAgICAgICAgIHdpZHRoPScxLjUnXG4gICAgICAgICAgICBoZWlnaHQ9JzEuNSdcbiAgICAgICAgICAgIHJ4PScuNTAxJ1xuICAgICAgICAgICAgdHJhbnNmb3JtPSdyb3RhdGUoLTQ0Ljk5OSA2Ni4yMDYgLTEwNC40MTEpJ1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFNoYXZpbmdOZWVkcyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxNyc+XG4gICAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMTYnPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjAnXG4gICAgICAgICAgICBkPSdNMTcuMjQuNjA5aC01LjIzOWEuNzQxLjc0MSAwIDAwLS43MzEuNzMxdi42NjdhLjc0MS43NDEgMCAwMC43MzEuNzMxaC4xODNhMS4yMjIgMS4yMjIgMCAwMTEuMjIyIDEuMjIydjEuMjIybC0uMTUyIDMuMzUxaDIuNzc3bC0uMTgzLTMuMzUxVjMuOTU5YTEuMjIyIDEuMjIyIDAgMDExLjIyMi0xLjIyMmguMTgzYS43NDEuNzQxIDAgMDAuNzMxLS43MzF2LS42NjdhLjc0MS43NDEgMCAwMC0uNzQ0LS43MzF6bS0yLjAxMSA0LjI2NWgtMS4yMjJ2LS42MDloMS4yMjJ6bS4wMy0xLjIyMmgtMS4yOGExLjc0MSAxLjc0MSAwIDAwLS40NTctLjkxNGgyLjE2M2ExLjk1MiAxLjk1MiAwIDAwLS40MjUuOTJ6J1xuICAgICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9nPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxOSc+XG4gICAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMTgnPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjEnXG4gICAgICAgICAgICBkPSdNMTYuMDIzIDkuMTM4aC0yLjhsLS4wNjEgMS4yMjJoMi45MjR6J1xuICAgICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9nPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAyMSc+XG4gICAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMjAnPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjInXG4gICAgICAgICAgICBkPSdNMTYuNDEzIDE2LjE0NGwtLjI0My01LjE3OGgtMy4wNDZsLS4yNDMgNS4xNzhhMS43NjggMS43NjggMCAxMDMuNTMzIDB6J1xuICAgICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9nPlxuICAgICAgPGcgZGF0YS1uYW1lPSdHcm91cCAyMyc+XG4gICAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMjInPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNjMnXG4gICAgICAgICAgICBkPSdNOC40OTkgMS44MjdWMEgyLjQzNnYyLjc0MmgtLjkxOFY0LjExQTIuMjgzIDIuMjgzIDAgMDAwIDYuMjc0VjcuMzFoNi4wOTJ2Ny4zMUgwdjEuMDY2YTIuMyAyLjMgMCAwMDIuMjg0IDIuMjg1aDMuOTM0YTIuMjgyIDIuMjgyIDAgMDAyLjI4NC0yLjI4NFY2LjI0NGEyLjMxMiAyLjMxMiAwIDAwLTEuNTI2LTIuMTYzVjIuNzQyaC0uOTE1di0uOTE1ek02LjA5MiAzLjM1MWguM3YuNjA5aC00LjI2di0uNjA5eidcbiAgICAgICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZz5cbiAgICAgIDwvZz5cbiAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgMjUnPlxuICAgICAgICA8ZyBkYXRhLW5hbWU9J0dyb3VwIDI0Jz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDY0J1xuICAgICAgICAgICAgZD0nTTAgNy45MnYxLjIyMmgyLjEzMmEuMzA0LjMwNCAwIDExMCAuNjA5SDB2LjkxNGgzLjY1NWEuMzA0LjMwNCAwIDExMCAuNjA5SDB2LjkxNGgzLjY1NWEuMzA0LjMwNCAwIDExMCAuNjA5SDB2MS4yMjJoNS40ODJWNy45Mjd6J1xuICAgICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgU2hpcnRzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8ZyBmaWxsPXtjb2xvcn0+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDEwOSdcbiAgICAgICAgICBkPSdNNi43NTEgMi41NDZhLjE3Mi4xNzIgMCAwMC4wNCAwbDIuMjA2LS41MjUgMi4yLjU0M2EuMTcxLjE3MSAwIDAwLjA0MSAwIC4xNDIuMTQyIDAgMDAuMTExLS4wNTEuMTQ5LjE0OSAwIDAwLjAyNy0uMTI4bC0uMjEtLjk4M2EuMzYyLjM2MiAwIDAxMC0uMTE1bC4yMjEtMS4xYS4xNDQuMTQ0IDAgMDAtLjAyNi0uMTIyLjEzOC4xMzggMCAwMC0uMTY4LS4wMjlsLTIuMTkyIDEuMDVMNi44MTMuMDE3YS4xMzcuMTM3IDAgMDAtLjE2OS4wMjguMTQ0LjE0NCAwIDAwLS4wMjcuMTIybC4yMSAxLjFhLjM2Mi4zNjIgMCAwMTAgLjExNWwtLjIxNy45NzlhLjE0OS4xNDkgMCAwMC4wMjcuMTI4LjE0Mi4xNDIgMCAwMC4xMS4wNTN6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxMTAnXG4gICAgICAgICAgZD0nTTIuNTYzIDE1LjEyNmwtMS44MDYtLjE1M2EuNC40IDAgMDAtLjQuMjc4bC0uMzQyIDEuMjE0YS4yODUuMjg1IDAgMDAuMDM5LjI0OC4yODUuMjg1IDAgMDAuMjI0LjExMmwxLjguMDU4aC4wMTNhLjQyOC40MjggMCAwMC4zOTEtLjI4OGwuMzM0LTEuMWEuMjgyLjI4MiAwIDAwLS4yNTItLjM3MnonXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDExMSdcbiAgICAgICAgICBkPSdNMTcuOTg1IDE2LjQ2NmwtLjMzOC0xLjJhLjQuNCAwIDAwLS40LS4yNzhsLTEuODA2LjE1MmEuMjgyLjI4MiAwIDAwLS4yNTIuMzcybC4zMyAxLjA4M2EuNDI4LjQyOCAwIDAwLjM5MS4yODhsMS44MTUtLjA1OGEuMjc0LjI3NCAwIDAwLjI2NC0uMzU5eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTEyJ1xuICAgICAgICAgIGQ9J00xNy4wMjQgMTQuMzQyYS4yODYuMjg2IDAgMDAuMjU3LS4zNzJsLS43NTYtMi42NzhhNS40NTIgNS40NTIgMCAwMS0uMTA1LS40NTFsLTEuMzIxLTYuNjI3YS42MS42MSAwIDAwLS4zMTUtLjRsLTIuMTM5LS45NDVhLjYzLjYzIDAgMDAtLjI0OC0uMDQ2LjYzOC42MzggMCAwMC0uMjYzLjA1MUw5LjE3NiA0LjI0OGEuNDgzLjQ4MyAwIDAxLS4zNDYgMEw1Ljg2NSAyLjg3NmEuNjQuNjQgMCAwMC0uMjYzLS4wNTEuNjMuNjMgMCAwMC0uMjQ4LjA0NmwtMi4xMzkuOTQ1YS42MS42MSAwIDAwLS4zMTUuNGwtMS4zMTggNi42MjZjLS4wMjUuMTI1LS4wNzQuMzI4LS4xMDUuNDUxbC0uNzU5IDIuNjYyYS4yODYuMjg2IDAgMDAuMjU3LjM3MmwxLjgyNC4xNTRhLjQwNS40MDUgMCAwMC40MDctLjI3NWwuODc0LTIuODU3YTMuNTg3IDMuNTg3IDAgMDAuMTA1LS40NzZsLjI3OC0yLjEtLjI1NCA4LjE2MmEuMzI2LjMyNiAwIDAwLjMyNy4zMzdoOC45OWEuMzI1LjMyNSAwIDAwLjMyNi0uMzM4bC0uMjkyLTguMDU4LjI2NSAyLjAwNmEzLjU4MiAzLjU4MiAwIDAwLjEwNS40NzZsLjg3NSAyLjg3NGEuNDA1LjQwNSAwIDAwLjQwNy4yNzV6TTguOTk4IDE2LjNhLjU1OC41NTggMCAxMS41NTgtLjU1OC41NTguNTU4IDAgMDEtLjU1OC41NTh6bTAtMi40MjJhLjU1OC41NTggMCAxMS41NTgtLjU1OC41NTguNTU4IDAgMDEtLjU1OC41NTh6bTAtMi40MjJhLjU1OC41NTggMCAxMS41NTgtLjU1OC41NTguNTU4IDAgMDEtLjU1OC41NTh6bTAtMi40MjJhLjU1OC41NTggMCAxMS41NTgtLjU1OC41NTguNTU4IDAgMDEtLjU1OC41NTh6bTAtMi40MjJhLjU1OC41NTggMCAxMS41NTgtLjU1OC41NTguNTU4IDAgMDEtLjU1OC41NjJ6J1xuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgU2hvdWxkZXJCYWdzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8Z1xuICAgICAgICBkYXRhLW5hbWU9J0dyb3VwIDMnXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0xMDAuNTQ4IC02Ni4xODcpJ1xuICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgICAgc3Ryb2tlPScjZmZmJ1xuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PScxMCdcbiAgICAgICAgc3Ryb2tlV2lkdGg9Jy4wNzYnXG4gICAgICA+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDYnXG4gICAgICAgICAgZD0nTTEwNS4wODMgNjkuNTMxbC0uOTE3LjI0My0uODQ4LTMuMTk1YS4xNDkuMTQ5IDAgMDEuMDY4LS4xNjZoMGExLjM0MyAxLjM0MyAwIDAxLjcwOC0uMTg4aDBhLjE0OS4xNDkgMCAwMS4xNDEuMTExeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggNydcbiAgICAgICAgICBkPSdNMTA0LjE2NyA2OS43NzRsLS45MTcuMjQzLS44NDgtMy4xOTVhLjE0OS4xNDkgMCAwMS4wNjgtLjE2NmgwYTEuMzQyIDEuMzQyIDAgMDEuNzA4LS4xODhoMGEuMTQ5LjE0OSAwIDAxLjE0MS4xMTF6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA4J1xuICAgICAgICAgIGQ9J00xMDYuNSA2OS41MzFsLjkxNy4yNDMuODQ4LTMuMTk1YS4xNDkuMTQ5IDAgMDAtLjA2OC0uMTY2aDBhMS4zNDMgMS4zNDMgMCAwMC0uNzA4LS4xODhoMGEuMTQ5LjE0OSAwIDAwLS4xNDEuMTExeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOSdcbiAgICAgICAgICBkPSdNMTA3LjQyMSA2OS43NzRsLjkxNy4yNDMuODQ4LTMuMTk1YS4xNDkuMTQ5IDAgMDAtLjA2OC0uMTY2aDBhMS4zNDIgMS4zNDIgMCAwMC0uNzA4LS4xODhoMGEuMTQ5LjE0OSAwIDAwLS4xNDEuMTExeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTAnXG4gICAgICAgICAgZD0nTTExMC45ODcgODAuMTVsLS42NDUtNy41NDVhMy43ODEgMy43ODEgMCAwMC0zLjc2OC0zLjQ1OWgtLjc4djEuMjNoMHYtMS4yM2gtLjc4YTMuNzgxIDMuNzgxIDAgMDAtMy43NjggMy40NTlsLS42NDYgNy41NDVhMy40MDcgMy40MDcgMCAwMDMuMzk1IDMuN2gzLjU5OGEzLjQwNyAzLjQwNyAwIDAwMy4zOTUtMy43eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTEnXG4gICAgICAgICAgZD0nTTEwOC40OTQgNjkuNjY4Yy0xLjMzNi0uNjY5LTEuNDI2LTEuNjUyLTIuNy0xLjY1NGgwYy0xLjI3MiAwLTEuMzYyLjk4NS0yLjcgMS42NTRsLjI5NC0uMDQ2YzEuMTkxLS41MTkgMS4yNzEtMS4yODIgMi40MDYtMS4yODNzMS4yMTUuNzY0IDIuNDA2IDEuMjgzeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTInXG4gICAgICAgICAgZD0nTTEwNS43OTUgNzcuODY4bC4xMzItLjAwNiA0LjM4NS0uMTkyLjIzOSAyLjc5MmgwYTE2LjggMTYuOCAwIDAxLTQuNTc5LjYzNmgtLjE3NydcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTMnXG4gICAgICAgICAgZD0nTTEwNS43ODggNzcuODY4bC0uMTMyLS4wMDYtNC4zODUtLjE5Mi0uMjM5IDIuNzkyaDBhMTYuOCAxNi44IDAgMDA0LjU3OS42MzZoLjE3NydcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTQnXG4gICAgICAgICAgZD0nTTExMC42MjUgODAuNDU1bC0uNTkxLTYuOTE2YTMuNTQgMy41NCAwIDAwLTMuNTI3LTMuMjM5aC0xLjQyN2EzLjU0IDMuNTQgMCAwMC0zLjUyNyAzLjIzOGwtLjU5MSA2LjkxNmEzLjIgMy4yIDAgMDAxLjM5MyAyLjkybC4wODMtLjEyM2EzLjA1NiAzLjA1NiAwIDAxLTEuMzI4LTIuNzg1bC41OTEtNi45MTZhMy4zNzIgMy4zNzIgMCAwMTMuMzgtMy4xaDEuNDI2YTMuMzcyIDMuMzcyIDAgMDEzLjM3OSAzLjFsLjU5MSA2LjkxNmEzLjA1NiAzLjA1NiAwIDAxLTEuMzI4IDIuNzg1bC4wODMuMTIzYTMuMiAzLjIgMCAwMDEuMzkyLTIuOTIxeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTUnXG4gICAgICAgICAgZD0nTTEwNS43OTIgODQuMTQ5di0zLjAwOGgwYTI1LjA0OSAyNS4wNDkgMCAwMS00Ljc1Ni0uNjc2bC0uNDQ3LS4wMzlBMy41NjggMy41NjggMCAwMDEwNCA4NC4xNDl6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNidcbiAgICAgICAgICBkPSdNMTA1Ljc5NSA4MS4xNDF2My4wMDhoMS44QTMuNTY4IDMuNTY4IDAgMDAxMTEgODAuNDI2bC0uNDQ3LjAzOWEyNS4wODMgMjUuMDgzIDAgMDEtNC43NTguNjc2eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTcnXG4gICAgICAgICAgZD0nTTEwNS43OTIgODEuMDgzdjIuNzY3aDEuNjQ3YTMuMTIzIDMuMTIzIDAgMDAzLjExMi0zLjM4OSAyNy4yIDI3LjIgMCAwMS00Ljc1Ny42MjJ6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxOCdcbiAgICAgICAgICBkPSdNMTA1Ljc5NSA4My44NXYtMi43NjVoMGEyNy4xNTcgMjcuMTU3IDAgMDEtNC43NTktLjYyMmgwYTMuMTIzIDMuMTIzIDAgMDAzLjExMiAzLjM4OXonXG4gICAgICAgIC8+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgZGF0YS1uYW1lPSdSZWN0YW5nbGUgMzQnXG4gICAgICAgICAgd2lkdGg9JzIuMTc3J1xuICAgICAgICAgIGhlaWdodD0nMS4wODYnXG4gICAgICAgICAgcng9Jy4yODEnXG4gICAgICAgICAgdHJhbnNmb3JtPSdyb3RhdGUoLTMuMjEgMTQ2MC4xMzggLTE4NzMuODM0KSdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTknXG4gICAgICAgICAgZD0nTTEwMy4yNTEgODAuMTJoMGEuMTU4LjE1OCAwIDAxLS4xNTgtLjE1OHYtNi42NzlhLjE1OC4xNTggMCAwMS4xNTgtLjE1OGgwYS4xNTguMTU4IDAgMDEuMTU4LjE1OHY2LjY3OWEuMTU4LjE1OCAwIDAxLS4xNTguMTU4eidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGggZGF0YS1uYW1lPSdSZWN0YW5nbGUgMzUnIGQ9J00xMDMuMDkzIDc0Ljg3NGguMzE2djEuMDM2aC0uMzE2eicgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFNraXJ0cyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJ1xuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PScwIDAgMTggMTgnXG4gICAgPlxuICAgICAgPGcgZmlsbD17Y29sb3J9PlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxMDcnXG4gICAgICAgICAgZD0nTTE3LjY4OCAxNi41ODVMMTQuODI2IDUuNDU0YTMuOTUgMy45NSAwIDAwLS4yNi0uNjgybC0uODIyLTEuNmEuNzQ5Ljc0OSAwIDAwLS42MTYtLjM3Nkg0LjU3NmEuNzQ2Ljc0NiAwIDAwLS42MTUuMzc3bC0uODQxIDEuNjVhNC4wMTcgNC4wMTcgMCAwMC0uMjU4LjY4M0wuMDE3IDE2LjU4NWEuMzczLjM3MyAwIDAwLjM3NC40ODJoLjY0YTEuNTIgMS41MiAwIDAxLjYxMi4xNThsMS4yNDYuNjkxYS44MjQuODI0IDAgMDAuNzI4IDBsMS4yNC0uNjkxYS42MDcuNjA3IDAgMDEuNTE0IDBsMS4yNDYuNjkxYS44MjQuODI0IDAgMDAuNzI4IDBsMS4yNDYtLjY5MWEuNjA3LjYwNyAwIDAxLjUxNCAwbDEuMjQ2LjY5MWEuODI0LjgyNCAwIDAwLjcyOCAwbDEuMjQ2LS42OTFhLjYwNy42MDcgMCAwMS41MTQgMGwxLjI0Ni42OTFhLjgyNC44MjQgMCAwMC43MjggMGwxLjI0Ni0uNjkxYTEuNTIgMS41MiAwIDAxLjYxMi0uMTU4aC42NGEuMzczLjM3MyAwIDAwLjM3NC0uNDgyeidcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTA4J1xuICAgICAgICAgIGQ9J000LjUyNSAyLjFoOC42NTZhLjMzMy4zMzMgMCAwMC4zMzMtLjMzM1YuMzMzQS4zMzMuMzMzIDAgMDAxMy4xODEgMEg0LjUyNWEuMzMzLjMzMyAwIDAwLS4zMzEuMzMzdjEuNDM4YS4zMzMuMzMzIDAgMDAuMzMxLjMzMXpNNy44MzMuNjUyYS4yNjcuMjY3IDAgMDEuMjYyLS4yNjZoMS41MDhhLjI2Ny4yNjcgMCAwMS4yNjYuMjY2di44YS4yNjcuMjY3IDAgMDEtLjI2Ni4yNjZIOC4wOTVhLjI2Ny4yNjcgMCAwMS0uMjY2LS4yNjZ6J1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aCBkYXRhLW5hbWU9J1JlY3RhbmdsZSAyJyBkPSdNOC4yNzUuODNoMS4xNTN2LjQ0NEg4LjI3NXonIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBTbmFja3MgPSAocHJvcHMpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD0nMjUuMTQzJ1xuICAgICAgaGVpZ2h0PScyMidcbiAgICAgIHZpZXdCb3g9JzAgMCAyNS4xNDMgMjInXG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPGcgaWQ9J1NuYWNrcycgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMCAtMzIuMDAxKSc+XG4gICAgICAgIDxnXG4gICAgICAgICAgaWQ9J0dyb3VwXzU3MTQnXG4gICAgICAgICAgZGF0YS1uYW1lPSdHcm91cCA1NzE0J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDMuMTQyIDQwLjM4MSknXG4gICAgICAgID5cbiAgICAgICAgICA8ZyBpZD0nR3JvdXBfNTcxMycgZGF0YS1uYW1lPSdHcm91cCA1NzEzJyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIDApJz5cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGlkPSdQYXRoXzE3Mzk4J1xuICAgICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTczOTgnXG4gICAgICAgICAgICAgIGQ9J004MC4yMjcsMjAyLjY1NEg2NS41NTlhMS41NzMsMS41NzMsMCwwLDAtMS41NzEsMS41NzF2MS4wNDhhOS45MjgsOS45MjgsMCwwLDAsNS4zODgsOC44NDcuNTI0LjUyNCwwLDEsMCwuNDgxLS45MzEsOC44ODMsOC44ODMsMCwwLDEtNC44MjEtNy45MTZ2LTEuMDQ4YS41MjQuNTI0LDAsMCwxLC41MjQtLjUyNEg4MC4yMjdhLjUyNC41MjQsMCwwLDEsLjUyNC41MjR2MS4wNDhhOC44NzksOC44NzksMCwwLDEtNC44MjIsNy45MTUuNTI0LjUyNCwwLDAsMCwuMjQxLjk5LjUxNy41MTcsMCwwLDAsLjI0LS4wNTksOS45MjMsOS45MjMsMCwwLDAsNS4zODktOC44NDZ2LTEuMDQ4QTEuNTczLDEuNTczLDAsMCwwLDgwLjIyNywyMDIuNjU0WidcbiAgICAgICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTYzLjk4OCAtMjAyLjY1NCknXG4gICAgICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9nPlxuICAgICAgICA8L2c+XG4gICAgICAgIDxnXG4gICAgICAgICAgaWQ9J0dyb3VwXzU3MTYnXG4gICAgICAgICAgZGF0YS1uYW1lPSdHcm91cCA1NzE2J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDAgNTAuODU3KSdcbiAgICAgICAgPlxuICAgICAgICAgIDxnIGlkPSdHcm91cF81NzE1JyBkYXRhLW5hbWU9J0dyb3VwIDU3MTUnIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDAgMCknPlxuICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgaWQ9J1BhdGhfMTczOTknXG4gICAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzM5OSdcbiAgICAgICAgICAgICAgZD0nTTI0LjA1Niw0MTYuMjlhLjUyNS41MjUsMCwwLDAtLjQ4NC0uMzI0SC41MjRhLjUyNC41MjQsMCwwLDAtLjM3MS44OTVsMS4xNzQsMS4xNzVhMy42NDUsMy42NDUsMCwwLDAsMi41OTMsMS4wNzRIMjAuMTc0YTMuNjUxLDMuNjUxLDAsMCwwLDIuNi0xLjA3NGwxLjE3NC0xLjE3NUEuNTIzLjUyMywwLDAsMCwyNC4wNTYsNDE2LjI5Wk0yMi4wMjcsNDE3LjNhMi42LDIuNiwwLDAsMS0xLjg1Mi43NjdIMy45MjFhMi42LDIuNiwwLDAsMS0xLjg1Mi0uNzY3bC0uMjgxLS4yODFoMjAuNTJaJ1xuICAgICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIC00MTUuOTY2KSdcbiAgICAgICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgIDwvZz5cbiAgICAgICAgPGdcbiAgICAgICAgICBpZD0nR3JvdXBfNTcxOCdcbiAgICAgICAgICBkYXRhLW5hbWU9J0dyb3VwIDU3MTgnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMTcuNDM4IDQyLjQ3NCknXG4gICAgICAgID5cbiAgICAgICAgICA8ZyBpZD0nR3JvdXBfNTcxNycgZGF0YS1uYW1lPSdHcm91cCA1NzE3Jz5cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGlkPSdQYXRoXzE3NDAwJ1xuICAgICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTc0MDAnXG4gICAgICAgICAgICAgIGQ9J00zNjEuNzg1LDI0NS42NTNjLTEuNDExLS45MDctMy42NjYuMDc4LTMuOTE4LjE5MmEuNTI0LjUyNCwwLDAsMCwuNDM1Ljk1NGMuNTA1LS4yMjksMi4xMjUtLjc3MywyLjkxNy0uMjYzYTEuNDg4LDEuNDg4LDAsMCwxLC41MzIsMS4zNThjMCwyLjEtNC4yMywzLjM2NS01Ljg2NCwzLjY3N2wtLjM3MS4wNzNhLjUyMy41MjMsMCwwLDAsLjEsMS4wMzcuNDg2LjQ4NiwwLDAsMCwuMS0uMDFsLjM2OC0uMDcyYy4yNzQtLjA1Miw2LjcxMi0xLjMxNSw2LjcxMi00LjcwNUEyLjQ3MSwyLjQ3MSwwLDAsMCwzNjEuNzg1LDI0NS42NTNaJ1xuICAgICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMzU1LjA5MyAtMjQ1LjI3MiknXG4gICAgICAgICAgICAgIGZpbGw9J2N1cnJlbnRDb2xvcidcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9nPlxuICAgICAgICA8L2c+XG4gICAgICAgIDxnXG4gICAgICAgICAgaWQ9J0dyb3VwXzU3MjAnXG4gICAgICAgICAgZGF0YS1uYW1lPSdHcm91cCA1NzIwJ1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDE0LjY2NyAzMi4wMDEpJ1xuICAgICAgICA+XG4gICAgICAgICAgPGcgaWQ9J0dyb3VwXzU3MTknIGRhdGEtbmFtZT0nR3JvdXAgNTcxOScgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMCAwKSc+XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBpZD0nUGF0aF8xNzQwMSdcbiAgICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDAxJ1xuICAgICAgICAgICAgICBkPSdNMzAwLjEyNSwzNS45OTRhMy4xMzksMy4xMzksMCwwLDAsMC0zLjguNTI0LjUyNCwwLDEsMC0uODE4LjY1NSwyLjExMywyLjExMywwLDAsMSwwLDIuNDg4LDMuMTM1LDMuMTM1LDAsMCwwLDAsMy44LjUyNC41MjQsMCwxLDAsLjgxOC0uNjU1QTIuMTEsMi4xMSwwLDAsMSwzMDAuMTI1LDM1Ljk5NFonXG4gICAgICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0yOTguNjY2IC0zMi4wMDEpJ1xuICAgICAgICAgICAgICBmaWxsPSdjdXJyZW50Q29sb3InXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZz5cbiAgICAgICAgPC9nPlxuICAgICAgICA8Z1xuICAgICAgICAgIGlkPSdHcm91cF81NzIyJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nR3JvdXAgNTcyMidcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgxMS41MiAzMi4wMDEpJ1xuICAgICAgICA+XG4gICAgICAgICAgPGcgaWQ9J0dyb3VwXzU3MjEnIGRhdGEtbmFtZT0nR3JvdXAgNTcyMScgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMCAwKSc+XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBpZD0nUGF0aF8xNzQwMidcbiAgICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE3NDAyJ1xuICAgICAgICAgICAgICBkPSdNMjM2LjA1NSwzNmEzLjEzNSwzLjEzNSwwLDAsMCwwLTMuOC41MjQuNTI0LDAsMSwwLS44MTguNjU1LDIuMTEsMi4xMSwwLDAsMSwwLDIuNDg4LDMuMTM5LDMuMTM5LDAsMCwwLDAsMy44LjUyNC41MjQsMCwxLDAsLjgxOC0uNjU1QTIuMTEzLDIuMTEzLDAsMCwxLDIzNi4wNTUsMzZaJ1xuICAgICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMjM0LjU5NyAtMzIuMDA5KSdcbiAgICAgICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgIDwvZz5cbiAgICAgICAgPGdcbiAgICAgICAgICBpZD0nR3JvdXBfNTcyNCdcbiAgICAgICAgICBkYXRhLW5hbWU9J0dyb3VwIDU3MjQnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoOC4zODEgMzIuMDAyKSdcbiAgICAgICAgPlxuICAgICAgICAgIDxnIGlkPSdHcm91cF81NzIzJyBkYXRhLW5hbWU9J0dyb3VwIDU3MjMnIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDAgMCknPlxuICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgaWQ9J1BhdGhfMTc0MDMnXG4gICAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQwMydcbiAgICAgICAgICAgICAgZD0nTTE3Mi4xMjUsMzYuMDE1YTMuMTM5LDMuMTM5LDAsMCwwLDAtMy44LjUyNC41MjQsMCwwLDAtLjgxOC42NTQsMi4xMTMsMi4xMTMsMCwwLDEsMCwyLjQ4OCwzLjEzNSwzLjEzNSwwLDAsMCwwLDMuOC41MjQuNTI0LDAsMSwwLC44MTgtLjY1NEEyLjExLDIuMTEsMCwwLDEsMTcyLjEyNSwzNi4wMTVaJ1xuICAgICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMTcwLjY2NiAtMzIuMDIyKSdcbiAgICAgICAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgIDwvZz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFRvcHMgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGZpbGw9e2NvbG9yfT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTA0J1xuICAgICAgICAgIGQ9J002Ljk5NCAyLjgzTDUuOTI4IDUuOTkxYS4zMTUuMzE1IDAgMDEtLjYgMEw0LjI3MyAyLjgzYTIuNCAyLjQgMCAwMC0yLjkwOS0uMDI2TDAgMy44MjJsLjA4Ny4zMjlhMzIuNjQ3IDMyLjY0NyAwIDAxLjkwOSAxMS45MjFMLjc5IDE4aDkuN2wtLjIxNS0xLjkwOWEzMi42NjcgMzIuNjY3IDAgMDEuOTEyLTExLjk2bC4wODMtLjMxLTEuMzY2LTEuMDEzYTIuNCAyLjQgMCAwMC0yLjkwOS4wMjZ6bTAgMCdcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggMTA1J1xuICAgICAgICAgIGQ9J00uNTQ5IDIuODQzbC42Mi0uMTE0TC43MTQuMjYxYS4zMTUuMzE1IDAgMDAtLjYyLjExNHptMCAwJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxMDYnXG4gICAgICAgICAgZD0nTTEwLjk3OC4zNjlhLjMxNi4zMTYgMCAwMC0uNjIyLS4xMDhMOS45NjYgMi42bC42MjIuMTA4em0wIDAnXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXYWxsZXQgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD0nMCAwIDE4IDE4J1xuICAgID5cbiAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgOSc+XG4gICAgICAgIDxnIGRhdGEtbmFtZT0nR3JvdXAgOCc+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA0MidcbiAgICAgICAgICAgIGQ9J00xMi4zNjIgMS4xMjlhMS40MTUgMS40MTUgMCAwMC0xLjY3Mi0xLjFMMS40MjggMS45NDJoMTEuMXonXG4gICAgICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2c+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQzJ1xuICAgICAgICAgIGQ9J00xMS41NzkgMTEuMjQydi0yLjJhMS44MjIgMS44MjIgMCAwMTEuODItMS44MmgyLjc4NHYtMi43OGExLjQxNSAxLjQxNSAwIDAwLTEuNDE1LTEuNDE1SDEuNDE1QTEuNDE1IDEuNDE1IDAgMDAwIDQuNDQydjExLjRhMS40MTUgMS40MTUgMCAwMDEuNDE1IDEuNDE1aDEzLjM1NGExLjQxNSAxLjQxNSAwIDAwMS40MTUtMS40MTV2LTIuNzc2aC0yLjc4NWExLjgyMiAxLjgyMiAwIDAxLTEuODItMS44MnonXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDQ0J1xuICAgICAgICAgIGQ9J00xNi45ODkgOC4wM2gtMy41OWExLjAxMSAxLjAxMSAwIDAwLTEuMDEgMS4wMXYyLjJhMS4wMTIgMS4wMTIgMCAwMDEuMDEgMS4wMWgzLjU5YTEuMDEyIDEuMDEyIDAgMDAxLjAxLTEuMDF2LTIuMmExLjAxMiAxLjAxMiAwIDAwLTEuMDEtMS4wMXptLTIuOCAzLjEyOGExLjAwNiAxLjAwNiAwIDExMS4wMDYtMS4wMDYgMS4wMDYgMS4wMDYgMCAwMS0xLjAwNiAxLjAwNnonXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBXb21lbkRyZXNzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxOCAxOCdcbiAgICA+XG4gICAgICA8ZGVmcz5cbiAgICAgICAgPGNsaXBQYXRoIGlkPSdhJz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdSZWN0YW5nbGUgMjAnXG4gICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgyMjYgMTA3MyknXG4gICAgICAgICAgICBmaWxsPScjZWJlN2U3J1xuICAgICAgICAgICAgZD0nTTAgMGgxOHYxOEgweidcbiAgICAgICAgICAvPlxuICAgICAgICA8L2NsaXBQYXRoPlxuICAgICAgPC9kZWZzPlxuICAgICAgPGdcbiAgICAgICAgZGF0YS1uYW1lPSdXb21lbiBEcmVzcydcbiAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTIyNiAtMTA3MyknXG4gICAgICAgIGNsaXBQYXRoPSd1cmwoI2EpJ1xuICAgICAgPlxuICAgICAgICA8Z1xuICAgICAgICAgIGRhdGEtbmFtZT0nR3JvdXAgMjgnXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoMjMwLjQ2MSAxMDczKSdcbiAgICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgICAgPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggODAnXG4gICAgICAgICAgICBkPSdNOC4yMzYgMTIuNjE5Yy0uMTItLjYtLjM4NC0zLjQyMi0xLjAwOC00LjM1OGExLjQ0NiAxLjQ0NiAwIDAxLS4xOS0uOC4wMzkuMDM5IDAgMDAwLS4wMDdjLjAyLS4yOS4wNTItLjYuMDczLS43NjJhLjQ5My40OTMgMCAwMS4wMS0uMDc2Yy4wMTYtLjEuMDM2LS4xOTIuMDU3LS4yODlhMTYuMDY1IDE2LjA2NSAwIDAwLjUxNS0yLjc0NmMwLTEuNDI5LS43MzMtMS44NDktLjczMy0xLjg0OS4yNTEtMS4wNjkuNDM0LTEuNjQ3LjQzNC0xLjY0N0w3LjE3OSAwQTEwLjU1OCAxMC41NTggMCAwMDYuNyAxLjcxN2EyLjkxMSAyLjkxMSAwIDAxLTIuMTYxLjY5NCAyLjkxMyAyLjkxMyAwIDAxLTIuMTYxLS42OTRBMTAuNTc4IDEwLjU3OCAwIDAwMS44OTcgMGwtLjIxNi4wODdzLjE4LjU3Ny40MzQgMS42NDdjMCAwLS43MzMuNDIxLS43MzMgMS44NDlhMTQuNjcyIDE0LjY3MiAwIDAwLjQ5MSAyLjYzMS4xLjEgMCAwMDAgLjAzOS4yLjIgMCAwMC4wMS4wMzVsLjAwNy4wMjhjLjAzLjEyMy4wNzQuMzQ3LjA4MS4zNDcuMDE0LjA4Ny4wMjkuMjQzLjA0My40LjAwNi4wNTUuMDEuMTA5LjAxNC4xNjNsLjAxNi4yMDdoLS4wMDdhMS40NjIgMS40NjIgMCAwMS0uMTkxLjgyNmMtLjYyNC45MzYtLjg4OSAzLjc1OC0xLjAwOCA0LjM1OHMtLjQwOCAyLjgxLS41NTIgMy40NTktLjI4OCAxLjUzNy0uMjg4IDEuNTM3YTMuNyAzLjcgMCAwMDEuMi4xNDRzLS4wODcuMjUyLjY0OS4xOGExNC40MzMgMTQuNDMzIDAgMDExLjk2OS0uMDZjLjUuMDI0LjE1My4xMi43Mi4xMnMuMjE2LS4xLjcyLS4xMmExNC4zODggMTQuMzg4IDAgMDExLjk2OS4wNmMuNzMzLjA3Mi42NDktLjE4LjY0OS0uMThhMy43MDggMy43MDggMCAwMDEuMi0uMTQ0cy0uMTQ0LS44ODktLjI4OS0xLjUzNy0uNDI4LTIuODU3LS41NDktMy40NTd6TTYuOTU1IDYuNDY4Yy0uMDU2LjA3Ny0uMTA2LjItLjA0MS4yNTEtLjAxNy4xMTUtLjAyNy4yMzEtLjAzOS4zNDctLjA2NS0uMDc1LS4yNzQtLjAwNi0uMjc0LS4wMDYtLjE1NS0uMDY4LjEzNy4zMzUuMjU0LjE4MS0uMDA1LjA2NS0uMDA3LjEzLS4wMS4yLS4xNDItLjAxLS4yODQtLjAyLS40MjctLjAyOGEuNjYuNjYgMCAwMC0uMDY4LS4xNDljLjAxNi0uMTA4LS4xMDguMDE2LS4xNS4xMzdhMjUuODQ3IDI1Ljg0NyAwIDAwLS45MjUtLjAyQzUuMjExIDcuMzA0IDUgNy4zNzMgNSA3LjM3M2MtLjAzMS0uMDE0LS4wNDQtLjAwOC0uMDQ0LjAwOWgtLjAzMmEuMTQ3LjE0NyAwIDAwLjAxNi0uMDY3LjE1Mi4xNTIgMCAwMC0uMyAwIC4xNDkuMTQ5IDAgMDAuMDE3LjA2N2MtLjQwNiAwLS44MTIuMDEzLTEuMjE0LjAyM2EuNzkxLjc5MSAwIDAwLS4wNDItLjA3N2MuMDE0LS4wOTItLjA3NC0uMDE3LS4xMjYuMDgxbC0uMjA3LjAwNWEuNDkxLjQ5MSAwIDAwLjExMi0uMmMuMTU0LS4xLS40MzQtLjA3NC0uMjcxLjE1MWEuMi4yIDAgMDAuMDUxLjA1MWgtLjE3M2EuMDg3LjA4NyAwIDAwMC0uMTIyYy0uMTM2LS4yLS4yMzguMDk0LS4yNS4xMjdsLS4zLjAwNmEuNDMuNDMgMCAwMC0uMDA1LS4wODFjLjA3My0uMDExLjMxNS0uMzA4LjA4Ny0uMzU0YS4xNzMuMTczIDAgMDAtLjEwOS4wMDUgNC44MTggNC44MTggMCAwMC0uMDQ4LS4zODUuNjc0LjY3NCAwIDAwLjA1OS0uMTM1Yy4wNjctLjA0Mi0uMDA1LS4wNjItLjEtLjA1MWEyLjI2IDIuMjYgMCAwMC0uMDM5LS4xNDdoLjIyNGEuMTUyLjE1MiAwIDEwLjI5Mi4wNTcuMTQ4LjE0OCAwIDAwLS4wMTQtLjA2MmwxLjA0LS4wMTlhLjEuMSAwIDAwMCAuMTMyYy4xNDMuMi4yNDQtLjA3Mi4yNjYtLjEzN2wuNDc5LS4wMDVjLjA3NS4wOTUuMjIuMi4yNzcuMDQzYS4yMDcuMjA3IDAgMDAuMDA5LS4wNDZoLjdhLjE1LjE1IDAgMDAtLjAzNC4wOTIuMTUyLjE1MiAwIDEwLjMgMCAuMTQ5LjE0OSAwIDAwLS4wMzMtLjA4N2MuMzg0LjAwNy43NjYuMDI0IDEuMTQ4LjA0OC0uMTE2LjAxNS0uMjU0LjA3Ny0uMTY2LjIuMTYxLjIyNS4yNzEtLjE1MS4yNzEtLjE1MS4wMjktLjAxOC4wMzItLjAzMi4wMTgtLjA0MmwuMS4wMDdhLjA0Mi4wNDIgMCAwMC4wMDkuMDA4Yy0uMDA3LjA1Mi0uMDE2LjEtLjAyNi4xNTN6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA4MSdcbiAgICAgICAgICAgIGQ9J000Ljk1MSA3LjE2MWMtLjE0NC4wODcuNC4wNzYuMjUyLS4xMzRzLS4yNTIuMTM0LS4yNTIuMTM0eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggODInXG4gICAgICAgICAgICBkPSdNNC4yODYgNy4wNTJjLS4xLjIzNS4yNDkuMTQuMjQ5LjE0LjE1LjA3NS0uMTQ5LS4zNzUtLjI0OS0uMTR6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA4MydcbiAgICAgICAgICAgIGQ9J000Ljc2OCA2LjcyMWMtLjI4NC0uMDU3LS4xLjMxLS4xLjMxLS4wNDkuMTkuMzg0LS4yNDkuMS0uMzF6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA4NCdcbiAgICAgICAgICAgIGQ9J001Ljk3MyA2LjUzM2MuMDk1LS4yNi0uMjc3LS4xMzgtLjI3Ny0uMTM4LS4xNjctLjA3My4xODMuMzk4LjI3Ny4xMzh6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA4NSdcbiAgICAgICAgICAgIGQ9J001LjM4MiA2Ljg5OGMuMjc2LjAyMy4wNjEtLjMuMDYxLS4zLjAyNy0uMTg0LS4zNC4yNzktLjA2MS4zeidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggODYnXG4gICAgICAgICAgICBkPSdNNC45ODUgNi42MzJjLjE2MS4yMjUuMjcxLS4xNTEuMjcxLS4xNTEuMTU0LS4wOTctLjQzMy0uMDc2LS4yNzEuMTUxeidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nRWxsaXBzZSAzJ1xuICAgICAgICAgICAgY3g9Jy4xNTInXG4gICAgICAgICAgICBjeT0nLjE1MidcbiAgICAgICAgICAgIHI9Jy4xNTInXG4gICAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgzLjI1MyA2LjkxNiknXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDg3J1xuICAgICAgICAgICAgZD0nTTMuODUxIDYuNzgyYy0uMTQ0LS4yMS0uMjUyLjEzNC0uMjUyLjEzNC0uMTQ0LjA4Ni4zOTYuMDc2LjI1Mi0uMTM0eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggODgnXG4gICAgICAgICAgICBkPSdNMy42NDkgNy4xMjZjLS4xNjctLjA3My4xODMuNC4yNzcuMTM4cy0uMjc3LS4xMzgtLjI3Ny0uMTM4eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggODknXG4gICAgICAgICAgICBkPSdNMi45MDMgNi44MDhjLS4xLjIzNS4yNDkuMTQuMjQ5LjE0LjE1MS4wNzUtLjE0OS0uMzc0LS4yNDktLjE0eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTAnXG4gICAgICAgICAgICBkPSdNMy4zODQgNi40OGMtLjI4NC0uMDU3LS4xLjMxLS4xLjMxLS4wNDYuMTg1LjM4NS0uMjU2LjEtLjMxeidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTEnXG4gICAgICAgICAgICBkPSdNNi4zNTkgNi44NTJhLjE1Mi4xNTIgMCAxMS0uMTUyLjE1Mi4xNTIuMTUyIDAgMDEuMTUyLS4xNTJ6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA5MidcbiAgICAgICAgICAgIGQ9J002LjU1MyA2Ljg1M2MtLjE0NC4wODcuNC4wNzYuMjUyLS4xMzRzLS4yNTIuMTM0LS4yNTIuMTM0eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTMnXG4gICAgICAgICAgICBkPSdNNS44NjEgNy4zYy4xNjEuMjI1LjI3MS0uMTUxLjI3MS0uMTUxLjE1Mi0uMS0uNDM1LS4wNzQtLjI3MS4xNTF6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA5NCdcbiAgICAgICAgICAgIGQ9J001Ljg1NiA2Ljc0NGMtLjEuMjM1LjI0OS4xNC4yNDkuMTQuMTUuMDc1LS4xNS0uMzc1LS4yNDktLjE0eidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTUnXG4gICAgICAgICAgICBkPSdNNi4zMzggNi40MTNjLS4yODQtLjA1Ny0uMS4zMS0uMS4zMS0uMDQ5LjE4Ny4zODUtLjI1LjEtLjMxeidcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICBkYXRhLW5hbWU9J1BhdGggOTYnXG4gICAgICAgICAgICBkPSdNNC4wNjQgNi42NTRjLjI3Ni4wMjMuMDYxLS4zLjA2MS0uMy4wMjctLjE4NC0uMzM5LjI3Ni0uMDYxLjN6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA5NydcbiAgICAgICAgICAgIGQ9J00yLjk3MiA2LjUzM2MuMDk0LS4yNi0uMjc3LS4xMzgtLjI3Ny0uMTM4LS4xNjgtLjA3My4xODIuMzk4LjI3Ny4xMzh6J1xuICAgICAgICAgIC8+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCA5OCdcbiAgICAgICAgICAgIGQ9J00yLjM4MSA2Ljg5OGMuMjc2LjAyMy4wNjEtLjMuMDYxLS4zLjAyNi0uMTg0LS4zMzYuMjc5LS4wNjEuM3onXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCB7IEFjY2Vzc29yaWVzIH0gZnJvbSAnLi9BY2Nlc3Nvcmllcyc7XG5leHBvcnQgeyBGcnVpdHNWZWdldGFibGUgfSBmcm9tICcuL0ZydWl0c1ZlZ2V0YWJsZSc7XG5leHBvcnQgeyBNZWF0RmlzaCB9IGZyb20gJy4vTWVhdEZpc2gnO1xuZXhwb3J0IHsgUHVyc2UgfSBmcm9tICcuL1B1cnNlJztcbmV4cG9ydCB7IEhhbmRCYWdzIH0gZnJvbSAnLi9IYW5kQmFncyc7XG5leHBvcnQgeyBTaG91bGRlckJhZ3MgfSBmcm9tICcuL1Nob3VsZGVyQmFncyc7XG5leHBvcnQgeyBXYWxsZXQgfSBmcm9tICcuL1dhbGxldCc7XG5leHBvcnQgeyBMYXB0b3BCYWdzIH0gZnJvbSAnLi9MYXB0b3BCYWdzJztcbmV4cG9ydCB7IFdvbWVuRHJlc3MgfSBmcm9tICcuL1dvbWVuRHJlc3MnO1xuZXhwb3J0IHsgT3V0ZXJXZWFyIH0gZnJvbSAnLi9PdXRlcldlYXInO1xuZXhwb3J0IHsgUGFudHMgfSBmcm9tICcuL1BhbnRzJztcbmV4cG9ydCB7IFRvcHMgfSBmcm9tICcuL1RvcHMnO1xuZXhwb3J0IHsgU2tpcnRzIH0gZnJvbSAnLi9Ta2lydHMnO1xuZXhwb3J0IHsgU2hpcnRzIH0gZnJvbSAnLi9TaGlydHMnO1xuZXhwb3J0IHsgRmFjZSB9IGZyb20gJy4vRmFjZSc7XG5leHBvcnQgeyBFeWVzIH0gZnJvbSAnLi9FeWVzJztcbmV4cG9ydCB7IExpcHMgfSBmcm9tICcuL0xpcHMnO1xuZXhwb3J0IHsgU25hY2tzIH0gZnJvbSAnLi9TbmFja3MnO1xuZXhwb3J0IHsgUGV0Q2FyZSB9IGZyb20gJy4vUGV0Q2FyZSc7XG5leHBvcnQgeyBIb21lQ2xlYW5pbmcgfSBmcm9tICcuL0hvbWVDbGVhbmluZyc7XG5leHBvcnQgeyBEYWlyeSB9IGZyb20gJy4vRGFpcnknO1xuZXhwb3J0IHsgQ29va2luZyB9IGZyb20gJy4vQ29va2luZyc7XG5leHBvcnQgeyBCcmVha2Zhc3QgfSBmcm9tICcuL0JyZWFrZmFzdCc7XG5leHBvcnQgeyBCZXZlcmFnZSB9IGZyb20gJy4vQmV2ZXJhZ2UnO1xuZXhwb3J0IHsgQmVhdXR5SGVhbHRoIH0gZnJvbSAnLi9CZWF1dHlIZWFsdGgnO1xuZXhwb3J0IHsgU2hhdmluZ05lZWRzIH0gZnJvbSAnLi9TaGF2aW5nTmVlZHMnO1xuZXhwb3J0IHsgT3JhbENhcmUgfSBmcm9tICcuL09yYWxDYXJlJztcbmV4cG9ydCB7IEZhY2lhbENhcmUgfSBmcm9tICcuL0ZhY2lhbENhcmUnO1xuZXhwb3J0IHsgRGVvZG9yYW50IH0gZnJvbSAnLi9EZW9kb3JhbnQnO1xuZXhwb3J0IHsgQmF0aE9pbCB9IGZyb20gJy4vQmF0aE9pbCc7XG5leHBvcnQgeyBNaW51cyB9IGZyb20gJy4vTWludXMnO1xuZXhwb3J0IHsgQ2hhaXIgfSBmcm9tICdhc3NldHMvaWNvbnMvY2F0ZWdvcnkvY2hhaXInO1xuZXhwb3J0IHsgQmVkIH0gZnJvbSAnYXNzZXRzL2ljb25zL2NhdGVnb3J5L2JlZCc7XG5leHBvcnQgeyBCb29rc2hlbGYgfSBmcm9tICdhc3NldHMvaWNvbnMvY2F0ZWdvcnkvYm9vay1zaGVsZic7XG5leHBvcnQgeyBDZW50ZXJUYWJsZSB9IGZyb20gJ2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9jZW50ZXItdGFibGUnO1xuZXhwb3J0IHsgRHJlc3NpbmdUYWJsZSB9IGZyb20gJ2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9kcmVzc2luZy10YWJsZSc7XG5leHBvcnQgeyBSZWFkaW5nVGFibGUgfSBmcm9tICdhc3NldHMvaWNvbnMvY2F0ZWdvcnkvcmVhZGluZy10YWJsZSc7XG5leHBvcnQgeyBTb2ZhIH0gZnJvbSAnYXNzZXRzL2ljb25zL2NhdGVnb3J5L3NvZmEnO1xuZXhwb3J0IHsgUmVsYXhDaGFpciB9IGZyb20gJ2Fzc2V0cy9pY29ucy9jYXRlZ29yeS9yZWxheC1jaGFpcic7XG5leHBvcnQgeyBTdG9yYWdlIH0gZnJvbSAnYXNzZXRzL2ljb25zL2NhdGVnb3J5L3N0b3JhZ2UnO1xuZXhwb3J0IHsgVG9vbHMgfSBmcm9tICdhc3NldHMvaWNvbnMvY2F0ZWdvcnkvdG9vbHMnO1xuZXhwb3J0IHsgVGFibGUgfSBmcm9tICdhc3NldHMvaWNvbnMvY2F0ZWdvcnkvdGFibGUnO1xuIiwiZXhwb3J0IGNvbnN0IEJlZCA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD1cIjYwXCJcbiAgICAgIGhlaWdodD1cIjYwXCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgNjAgNjBcIlxuICAgID5cbiAgICAgIDxwYXRoXG4gICAgICAgIGlkPVwiQmVkXCJcbiAgICAgICAgZD1cIk0yMjguNSw0NjYuNzVWNDU1LjVBNy41LDcuNSwwLDAsMCwyMjEsNDQ4SDE5MWE3LjUsNy41LDAsMCwwLTcuNSw3LjV2MTEuMjVMMTc2LDQ5MS4xMjV2MTEuMjVhMS44NzQsMS44NzQsMCwwLDAsMS44NzUsMS44NzVoMy43NVY1MDhIMTgzLjV2LTMuNzVoNDVWNTA4aDEuODc1di0zLjc1aDMuNzVBMS44NzQsMS44NzQsMCwwLDAsMjM2LDUwMi4zNzV2LTExLjI1Wk0xODUuMzc1LDQ1NS41QTUuNjMyLDUuNjMyLDAsMCwxLDE5MSw0NDkuODc1aDMwYTUuNjMyLDUuNjMyLDAsMCwxLDUuNjI1LDUuNjI1djExLjFxLS45MzgtLjA3Mi0xLjg3NS0uMTM3VjQ2M2EzLjc1LDMuNzUsMCwwLDAtMy43NS0zLjc1aC05LjM3NWEzLjc1LDMuNzUsMCwwLDAtMy43NSwzLjc1djIuODI0Yy0uNjI1LDAtMS4yNS0uMDA5LTEuODc1LS4wMDlzLTEuMjUsMC0xLjg3NS4wMDlWNDYzYTMuNzUsMy43NSwwLDAsMC0zLjc1LTMuNzVIMTkxYTMuNzUsMy43NSwwLDAsMC0zLjc1LDMuNzV2My40NjdxLS45MzguMDY1LTEuODc1LjEzN1ptMzcuNSwxMC44NHEtNi41NTctLjQwOS0xMy4xMjUtLjVWNDYzYTEuODc3LDEuODc3LDAsMCwxLDEuODc1LTEuODc1SDIyMUExLjg3NywxLjg3NywwLDAsMSwyMjIuODc1LDQ2M1ptLTMzLjc1LDBWNDYzQTEuODc3LDEuODc3LDAsMCwxLDE5MSw0NjEuMTI1aDkuMzc1QTEuODc3LDEuODc3LDAsMCwxLDIwMi4yNSw0NjN2Mi44NDNRMTk1LjY4NCw0NjUuOTMzLDE4OS4xMjUsNDY2LjM0Wm0tNC4yMDcsMi4xNzZjNi45OTItLjU0OSwxNC4wNzctLjgyNywyMS4wODItLjgyN3MxNC4wOS4yNzcsMjEuMDgyLjgyN2w2LjMzMSwyMC41NzZjLTkuMS0uNTE3LTE4LjMxMy0uNzc5LTI3LjQxMy0uNzc5cy0xOC4zMDguMjYyLTI3LjQxMy43NzlabTQ5LjIwNywzMy44NTloLTU2LjI1di0xMS4zNnExNC4wNS0uODIzLDI4LjEyNS0uODI3dDI4LjEyNS44MjdaXCJcbiAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0xNzYgLTQ0OClcIlxuICAgICAgICBmaWxsPVwiIzIxMjEyMVwiXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBCb29rc2hlbGYgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9XCI0OC43NVwiXG4gICAgICBoZWlnaHQ9XCI2MFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDQ4Ljc1IDYwXCJcbiAgICA+XG4gICAgICA8cGF0aFxuICAgICAgICBpZD1cIkJvb2tfc2VsZlwiXG4gICAgICAgIGRhdGEtbmFtZT1cIkJvb2sgc2VsZlwiXG4gICAgICAgIGQ9XCJNMjI4Ljg3NSwxNzZoLTQ1QTEuODc0LDEuODc0LDAsMCwwLDE4MiwxNzcuODc1djUyLjVhMS44NzQsMS44NzQsMCwwLDAsMS44NzUsMS44NzVoMy43NVYyMzZIMTg5LjV2LTMuNzVoMzMuNzVWMjM2aDEuODc1di0zLjc1aDMuNzVhMS44NzQsMS44NzQsMCwwLDAsMS44NzUtMS44NzV2LTUyLjVBMS44NzQsMS44NzQsMCwwLDAsMjI4Ljg3NSwxNzZabS0yMy40MzcsNTQuMzc1aC0yLjgxMnYtMTEuMjVIMjAwLjc1djExLjI1aC0xLjg3NXYtMTEuMjVIMTk3djExLjI1aC0xLjg3NXYtMTEuMjVIMTkzLjI1djExLjI1aC0xLjg3NXYtMTEuMjVIMTg5LjV2MTEuMjVoLTEuODc1di0xMS4yNUgxODUuNzV2MTEuMjVoLTEuODc1VjIxMy41aDIxLjU2M1ptMC0xOC43NWgtNi41NjJ2LTExLjI1SDE5N3YxMS4yNWgtMS44NzV2LTExLjI1SDE5My4yNXYxMS4yNWgtMS44NzV2LTExLjI1SDE4OS41djExLjI1aC0xLjg3NXYtMTEuMjVIMTg1Ljc1djExLjI1aC0xLjg3NVYxOTQuNzVoMjEuNTYzWm0wLTE4Ljc1aC02LjQ1MmwxLjc2NC0uNi0zLjYtMTAuNjU4LTEuNzc3LjYsMy42LDEwLjY1NGgtMy44NDh2LTExLjI1SDE5My4yNXYxMS4yNWgtMS44NzV2LTExLjI1SDE4OS41djExLjI1aC0xLjg3NXYtMTEuMjVIMTg1Ljc1djExLjI1aC0xLjg3NXYtMTVoMjEuNTYzWm0yMy40MzgsMzcuNWgtNy41di0xMS4yNUgyMTkuNXYxMS4yNUgyMTJ2LTExLjI1aC0xLjg3NXYxMS4yNWgtMi44MTJWMjEzLjVoMjEuNTYzWm0wLTE4Ljc1aC01LjVsMS43NTItLjU5Mi0zLjYtMTAuNjU4LTEuNzc3LjYsMy42LDEwLjY1SDIxOS41VjIwMC4zNzloLTEuODc1djExLjI0NkgyMTUuNzVWMjAwLjM3OWgtMS44NzV2MTEuMjQ2SDIxMlYyMDAuMzc5aC0xLjg3NXYxMS4yNDZoLTIuODEyVjE5NC43NWgyMS41NjNabTAtMTguNzVIMjI3di0xMS4yNWgtMS44NzV2MTEuMjVIMjIzLjI1di0xMS4yNWgtMS44NzV2MTEuMjVIMjE5LjV2LTExLjI1aC0xLjg3NXYxMS4yNUgyMTUuNzV2LTExLjI1aC0xLjg3NXYxMS4yNUgyMTJ2LTExLjI1aC0xLjg3NXYxMS4yNWgtMi44MTJ2LTE1aDIxLjU2M1pcIlxuICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTE4MiAtMTc2KVwiXG4gICAgICAgIGZpbGw9XCIjMjEyMTIxXCJcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiZXhwb3J0IGNvbnN0IENlbnRlclRhYmxlID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiNjBcIlxuICAgICAgaGVpZ2h0PVwiNDguNzVcIlxuICAgICAgdmlld0JveD1cIjAgMCA2MCA0OC43NVwiXG4gICAgPlxuICAgICAgPHBhdGhcbiAgICAgICAgaWQ9XCJDZW50ZXJfdGFibGVcIlxuICAgICAgICBkYXRhLW5hbWU9XCJDZW50ZXIgdGFibGVcIlxuICAgICAgICBkPVwiTTIyNi43NTcsNTkxLjk0NUE5OC44NDIsOTguODQyLDAsMCwwLDIwNiw1OTBhOTguODQyLDk4Ljg0MiwwLDAsMC0yMC43NTcsMS45NDVDMTc5LjExLDU5My4zMywxNzYsNTk1LjIsMTc2LDU5Ny41czMuMTEsNC4xNyw5LjI0Myw1LjU1NWE5My44NjgsOTMuODY4LDAsMCwwLDE3Ljk0NSwxLjkxNXY0LjcyNGE0LjY3NCw0LjY3NCwwLDAsMCwwLDcuNDg3djguNDQ0aC0xLjg3NWE0LjcsNC43LDAsMCwwLTQuNTk0LDMuNzVoLTEuMDMxQTQuNjkzLDQuNjkzLDAsMCwwLDE5MSw2MzQuMDYzdjMuNzVhLjkzOC45MzgsMCwwLDAsLjkzOC45MzhoMy43NWEuOTM4LjkzOCwwLDAsMCwuOTM4LS45MzdWNjM1aC45MzhhNC43LDQuNywwLDAsMCw0LjU5NC0zLjc1aDEuMDMxdi45MzhhMi44MTMsMi44MTMsMCwwLDAsNS42MjUsMHYtLjkzN2gxLjAzMWE0LjcsNC43LDAsMCwwLDQuNTk0LDMuNzVoLjkzOHYyLjgxM2EuOTM4LjkzOCwwLDAsMCwuOTM4LjkzOGgzLjc1YS45MzguOTM4LDAsMCwwLC45MzgtLjkzN3YtMy43NWE0LjY5Myw0LjY5MywwLDAsMC00LjY4Ny00LjY4N2gtMS4wMzFhNC43LDQuNywwLDAsMC00LjU5NC0zLjc1aC0xLjg3NXYtOC40NDRhNC42NzQsNC42NzQsMCwwLDAsMC03LjQ4N1Y2MDQuOTdhOTMuODc3LDkzLjg3NywwLDAsMCwxNy45NDUtMS45MTVDMjMyLjg5LDYwMS42NywyMzYsNTk5LjgsMjM2LDU5Ny41UzIzMi44OSw1OTMuMzMsMjI2Ljc1Nyw1OTEuOTQ1Wm0tMjMuNTcsMzcuNDNoLTEuODc1YS45MzguOTM4LDAsMCwwLS45MzcuOTM4LDIuODE2LDIuODE2LDAsMCwxLTIuODEyLDIuODEzaC0xLjg3NWEuOTM4LjkzOCwwLDAsMC0uOTM3LjkzOHYyLjgxM2gtMS44NzV2LTIuODEyYTIuODE2LDIuODE2LDAsMCwxLDIuODEzLTIuODEyaDEuODc1YS45MzguOTM4LDAsMCwwLC45MzgtLjkzNywyLjgxNiwyLjgxNiwwLDAsMSwyLjgxMy0yLjgxMmgxLjg3NVptNy41LTEuODc1YTIuODE2LDIuODE2LDAsMCwxLDIuODEzLDIuODEzLjkzOC45MzgsMCwwLDAsLjkzOC45MzhoMS44NzVhMi44MTYsMi44MTYsMCwwLDEsMi44MTMsMi44MTN2Mi44MTNIMjE3LjI1di0yLjgxMmEuOTM4LjkzOCwwLDAsMC0uOTM3LS45MzdoLTEuODc1YTIuODE2LDIuODE2LDAsMCwxLTIuODEyLTIuODEyLjkzOC45MzgsMCwwLDAtLjkzNy0uOTM3aC0xLjg3NVY2MjcuNVptLTMtMTEuODE3LS43NDcuNTYydjE1Ljk0MmEuOTM4LjkzOCwwLDAsMS0xLjg3NSwwVjYxNi4yNDVsLS43NDctLjU2MmEyLjgsMi44LDAsMCwxLDAtNC40OTFsLjc0Ny0uNTYyVjYwNWgxLjg3NXY1LjYzbC43NDcuNTYyYTIuOCwyLjgsMCwwLDEsMCw0LjQ5MVptMTguNjU5LTE0LjQ1N2E5Ni45LDk2LjksMCwwLDEtMjAuMzQ0LDEuOSw5Ni45LDk2LjksMCwwLDEtMjAuMzQ0LTEuOWMtNi4xNDMtMS4zODctNy43ODEtMi45OTQtNy43ODEtMy43MjZzMS42MzktMi4zMzksNy43ODEtMy43MjZhOTYuOSw5Ni45LDAsMCwxLDIwLjM0NC0xLjksOTYuOSw5Ni45LDAsMCwxLDIwLjM0NCwxLjljNi4xNDMsMS4zODcsNy43ODEsMi45OTQsNy43ODEsMy43MjZTMjMyLjQ4Niw1OTkuODM5LDIyNi4zNDQsNjAxLjIyNlpcIlxuICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTE3NiAtNTkwKVwiXG4gICAgICAgIGZpbGw9XCIjMjEyMTIxXCJcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiZXhwb3J0IGNvbnN0IENoYWlyID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiNDAuNFwiXG4gICAgICBoZWlnaHQ9XCI2MlwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDQwLjQgNjJcIlxuICAgID5cbiAgICAgIDxnIGlkPVwiQ2hhaXJcIiB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTMxMiAtMzA4KVwiPlxuICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgaWQ9XCJFbGxpcHNlXzExMVwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiRWxsaXBzZSAxMTFcIlxuICAgICAgICAgIGN4PVwiMC42XCJcbiAgICAgICAgICBjeT1cIjAuNlwiXG4gICAgICAgICAgcj1cIjAuNlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDMyMiAzMTQuNClcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgc3Ryb2tlPVwiIzIxMjEyMVwiXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxjaXJjbGVcbiAgICAgICAgICBpZD1cIkVsbGlwc2VfMTEyXCJcbiAgICAgICAgICBkYXRhLW5hbWU9XCJFbGxpcHNlIDExMlwiXG4gICAgICAgICAgY3g9XCIwLjZcIlxuICAgICAgICAgIGN5PVwiMC42XCJcbiAgICAgICAgICByPVwiMC42XCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMzQxLjIgMzE0LjQpXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgIHN0cm9rZT1cIiMyMTIxMjFcIlxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAvPlxuICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgaWQ9XCJFbGxpcHNlXzExM1wiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiRWxsaXBzZSAxMTNcIlxuICAgICAgICAgIGN4PVwiMC42XCJcbiAgICAgICAgICBjeT1cIjAuNlwiXG4gICAgICAgICAgcj1cIjAuNlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDMzMS42IDMxNC40KVwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgLz5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgIGlkPVwiRWxsaXBzZV8xMTRcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIkVsbGlwc2UgMTE0XCJcbiAgICAgICAgICBjeD1cIjAuNlwiXG4gICAgICAgICAgY3k9XCIwLjZcIlxuICAgICAgICAgIHI9XCIwLjZcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgzMjIgMzI0KVwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgLz5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgIGlkPVwiRWxsaXBzZV8xMTVcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIkVsbGlwc2UgMTE1XCJcbiAgICAgICAgICBjeD1cIjAuNlwiXG4gICAgICAgICAgY3k9XCIwLjZcIlxuICAgICAgICAgIHI9XCIwLjZcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgzNDEuMiAzMjQpXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgIHN0cm9rZT1cIiMyMTIxMjFcIlxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAvPlxuICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgaWQ9XCJFbGxpcHNlXzExNlwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiRWxsaXBzZSAxMTZcIlxuICAgICAgICAgIGN4PVwiMC42XCJcbiAgICAgICAgICBjeT1cIjAuNlwiXG4gICAgICAgICAgcj1cIjAuNlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDMzMS42IDMyNClcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgc3Ryb2tlPVwiIzIxMjEyMVwiXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxjaXJjbGVcbiAgICAgICAgICBpZD1cIkVsbGlwc2VfMTE3XCJcbiAgICAgICAgICBkYXRhLW5hbWU9XCJFbGxpcHNlIDExN1wiXG4gICAgICAgICAgY3g9XCIwLjZcIlxuICAgICAgICAgIGN5PVwiMC42XCJcbiAgICAgICAgICByPVwiMC42XCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMzIyIDMzMy42KVwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgLz5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgIGlkPVwiRWxsaXBzZV8xMThcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIkVsbGlwc2UgMTE4XCJcbiAgICAgICAgICBjeD1cIjAuNlwiXG4gICAgICAgICAgY3k9XCIwLjZcIlxuICAgICAgICAgIHI9XCIwLjZcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgzNDEuMiAzMzMuNilcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgc3Ryb2tlPVwiIzIxMjEyMVwiXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxjaXJjbGVcbiAgICAgICAgICBpZD1cIkVsbGlwc2VfMTE5XCJcbiAgICAgICAgICBkYXRhLW5hbWU9XCJFbGxpcHNlIDExOVwiXG4gICAgICAgICAgY3g9XCIwLjZcIlxuICAgICAgICAgIGN5PVwiMC42XCJcbiAgICAgICAgICByPVwiMC42XCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMzMxLjYgMzMzLjYpXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgIHN0cm9rZT1cIiMyMTIxMjFcIlxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQyN1wiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyN1wiXG4gICAgICAgICAgZD1cIk0zNTEuNCwzMzkuOEgzMTN2LTIuNGEyLjQsMi40LDAsMCwxLDIuNC0yLjRIMzQ5YTIuNCwyLjQsMCwwLDEsMi40LDIuNFpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwIDUuMilcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgIC8+XG4gICAgICAgIDxsaW5lXG4gICAgICAgICAgaWQ9XCJMaW5lXzdcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIkxpbmUgN1wiXG4gICAgICAgICAgeTE9XCIyNFwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDMxNS40IDM0NSlcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgIC8+XG4gICAgICAgIDxsaW5lXG4gICAgICAgICAgaWQ9XCJMaW5lXzhcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIkxpbmUgOFwiXG4gICAgICAgICAgeTI9XCIyNFwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDM0OSAzNDUpXCJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgc3Ryb2tlPVwiIzIxMjEyMVwiXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQyOFwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyOFwiXG4gICAgICAgICAgZD1cIk0zNDguNiwzNDAuMkgzMTVWMzEzLjhhNC44LDQuOCwwLDAsMSw0LjgtNC44aDI0YTQuOCw0LjgsMCwwLDEsNC44LDQuOFpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwLjQgMClcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICBzdHJva2U9XCIjMjEyMTIxXCJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiZXhwb3J0IGNvbnN0IERyZXNzaW5nVGFibGUgPSAoe1xuICBjb2xvciA9ICdjdXJyZW50Q29sb3InLFxuICB3aWR0aCA9ICcxOHB4JyxcbiAgaGVpZ2h0ID0gJzE4cHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZydcbiAgICAgIHdpZHRoPSczOS44NjcnXG4gICAgICBoZWlnaHQ9JzYyJ1xuICAgICAgdmlld0JveD0nMCAwIDM5Ljg2NyA2MidcbiAgICA+XG4gICAgICA8Z1xuICAgICAgICBpZD0nRHJlc3NpbmdfVGFibGUnXG4gICAgICAgIGRhdGEtbmFtZT0nRHJlc3NpbmcgVGFibGUnXG4gICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC05NDIuNjM0IC0zNDYuMDA4KSdcbiAgICAgID5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBpZD0nUmVjdGFuZ2xlXzEwNjQnXG4gICAgICAgICAgZGF0YS1uYW1lPSdSZWN0YW5nbGUgMTA2NCdcbiAgICAgICAgICB3aWR0aD0nMTguOTM0J1xuICAgICAgICAgIGhlaWdodD0nMTkuODM1J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDk0My42MzQgMzg0LjA4MyknXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzInXG4gICAgICAgICAgc3Ryb2tlPScjMjEyMTIxJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBmaWxsPSdub25lJ1xuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPSdQYXRoXzE3NDI2J1xuICAgICAgICAgIGRhdGEtbmFtZT0nUGF0aCAxNzQyNidcbiAgICAgICAgICBkPSdNOTcwLjk0NywzNDcuMDA4aDBhMTQuNTE5LDE0LjUxOSwwLDAsMSwxNC40NzYsMTQuNDc2djIyLjZIOTU2LjQ3MXYtMjIuNkExNC41MTksMTQuNTE5LDAsMCwxLDk3MC45NDcsMzQ3LjAwOFonXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoLTguMzgpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPScjMjEyMTIxJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMidcbiAgICAgICAgLz5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBpZD0nUmVjdGFuZ2xlXzEwNjUnXG4gICAgICAgICAgZGF0YS1uYW1lPSdSZWN0YW5nbGUgMTA2NSdcbiAgICAgICAgICB3aWR0aD0nMTguOTM0J1xuICAgICAgICAgIGhlaWdodD0nMTkuODM1J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDk2Mi41NjggMzg0LjA4MyknXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzInXG4gICAgICAgICAgc3Ryb2tlPScjMjEyMTIxJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBmaWxsPSdub25lJ1xuICAgICAgICAvPlxuICAgICAgICA8bGluZVxuICAgICAgICAgIGlkPSdMaW5lXzEnXG4gICAgICAgICAgZGF0YS1uYW1lPSdMaW5lIDEnXG4gICAgICAgICAgeTI9JzMuMDknXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoOTU4Ljc4MSAzOTIuNDU1KSdcbiAgICAgICAgICBmaWxsPSdub25lJ1xuICAgICAgICAgIHN0cm9rZT0nIzIxMjEyMSdcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzInXG4gICAgICAgIC8+XG4gICAgICAgIDxsaW5lXG4gICAgICAgICAgaWQ9J0xpbmVfMidcbiAgICAgICAgICBkYXRhLW5hbWU9J0xpbmUgMidcbiAgICAgICAgICB5Mj0nMy4wOSdcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSg5NjYuMzU1IDM5Mi40NTUpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPScjMjEyMTIxJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMidcbiAgICAgICAgLz5cbiAgICAgICAgPGxpbmVcbiAgICAgICAgICBpZD0nTGluZV8zJ1xuICAgICAgICAgIGRhdGEtbmFtZT0nTGluZSAzJ1xuICAgICAgICAgIHkyPSczLjA5J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDk0NS43MjkgNDAzLjkxOCknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9JyMyMTIxMjEnXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScyJ1xuICAgICAgICAvPlxuICAgICAgICA8bGluZVxuICAgICAgICAgIGlkPSdMaW5lXzQnXG4gICAgICAgICAgZGF0YS1uYW1lPSdMaW5lIDQnXG4gICAgICAgICAgeTI9JzMuMDknXG4gICAgICAgICAgdHJhbnNmb3JtPSd0cmFuc2xhdGUoOTc5LjAzNCA0MDMuOTE4KSdcbiAgICAgICAgICBmaWxsPSdub25lJ1xuICAgICAgICAgIHN0cm9rZT0nIzIxMjEyMSdcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9JzInXG4gICAgICAgIC8+XG4gICAgICAgIDxsaW5lXG4gICAgICAgICAgaWQ9J0xpbmVfNSdcbiAgICAgICAgICBkYXRhLW5hbWU9J0xpbmUgNSdcbiAgICAgICAgICB4MT0nMTUuMzknXG4gICAgICAgICAgeTI9JzE1LjM5J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDk1NC44NzMgMzU5Ljc0NiknXG4gICAgICAgICAgZmlsbD0nbm9uZSdcbiAgICAgICAgICBzdHJva2U9JyMyMTIxMjEnXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD0ncm91bmQnXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZVdpZHRoPScyJ1xuICAgICAgICAvPlxuICAgICAgICA8bGluZVxuICAgICAgICAgIGlkPSdMaW5lXzYnXG4gICAgICAgICAgZGF0YS1uYW1lPSdMaW5lIDYnXG4gICAgICAgICAgeDE9JzguNDM3J1xuICAgICAgICAgIHkyPSc4LjQzNydcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSg5NTUuNzA2IDM2MC41NzgpJ1xuICAgICAgICAgIGZpbGw9J25vbmUnXG4gICAgICAgICAgc3Ryb2tlPScjMjEyMTIxJ1xuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9J3JvdW5kJ1xuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPSdyb3VuZCdcbiAgICAgICAgICBzdHJva2VXaWR0aD0nMidcbiAgICAgICAgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJleHBvcnQgY29uc3QgUmVhZGluZ1RhYmxlID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiNjBcIlxuICAgICAgaGVpZ2h0PVwiNjBcIlxuICAgICAgdmlld0JveD1cIjAgMCA2MCA2MFwiXG4gICAgPlxuICAgICAgPGdcbiAgICAgICAgaWQ9XCJSZWFkaW5nX1RhYmxlXCJcbiAgICAgICAgZGF0YS1uYW1lPVwiUmVhZGluZyBUYWJsZVwiXG4gICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtNDQ4IC01ODQpXCJcbiAgICAgID5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD1cIlBhdGhfMTc0MTdcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIlBhdGggMTc0MTdcIlxuICAgICAgICAgIGQ9XCJNNTA2LjEyNSw2MDguMzc1SDQ1OS4yNWEzLjc0OSwzLjc0OSwwLDAsMC0yLjgxMi0zLjYyN3YtMy44NzNhLjkzOC45MzgsMCwwLDAtLjIzMi0uNjE3bC01Ljg0My02LjY3OSw5LjE2LTUuODI5SDQ2M3YuOTQ0YTQuNjc2LDQuNjc2LDAsMCwwLTEuODc1LDMuNzQzdi45MzhINDcwLjV2LS45MzdhNC42NzYsNC42NzYsMCwwLDAtMS44NzUtMy43NDN2LTEuODgyYTIuODExLDIuODExLDAsMCwwLTUuNDYyLS45MzdINDU5LjI1YS45MzguOTM4LDAsMCwwLS41LjE0NmwtMTAuMzEyLDYuNTYzYS45MzguOTM4LDAsMCwwLS4yLDEuNDA4bDYuMzMxLDcuMjM2djMuNTJhMy43NDksMy43NDksMCwwLDAtMi44MTIsMy42MjdoLTEuODc1QTEuODc1LDEuODc1LDAsMCwwLDQ0OCw2MTAuMjV2MzEuODc1QTEuODc1LDEuODc1LDAsMCwwLDQ0OS44NzUsNjQ0aDEuODc1YTEuODc1LDEuODc1LDAsMCwwLDEuODc1LTEuODc1VjYxNEg0Nzh2MjguMTI1QTEuODc1LDEuODc1LDAsMCwwLDQ3OS44NzUsNjQ0aDI2LjI1QTEuODc1LDEuODc1LDAsMCwwLDUwOCw2NDIuMTI1VjYxMC4yNUExLjg3NSwxLjg3NSwwLDAsMCw1MDYuMTI1LDYwOC4zNzVabS00MC4zMTItMjIuNWEuOTM5LjkzOSwwLDAsMSwuOTM4LjkzOHYyLjgxN2wuNzQ3LjU2MmEyLjgwNSwyLjgwNSwwLDAsMSwuOTY3LDEuMzA4aC01LjNhMi44MDUsMi44MDUsMCwwLDEsLjk2Ny0xLjMwOGwuNzQ3LS41NjJ2LTIuODE3QS45MzkuOTM5LDAsMCwxLDQ2NS44MTMsNTg1Ljg3NVpNNDU1LjUsNjA2LjVhMS44NzcsMS44NzcsMCwwLDEsMS44NzUsMS44NzVoLTMuNzVBMS44NzcsMS44NzcsMCwwLDEsNDU1LjUsNjA2LjVabTUwLjYyNSwzNS42MjVoLTI2LjI1VjYyOWgyNi4yNVptMC0xNWgtMjYuMjVWNjE0aDI2LjI1Wm0wLTE1SDQ1MS43NXYzMGgtMS44NzVWNjEwLjI1aDU2LjI1WlwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQxOFwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQxOFwiXG4gICAgICAgICAgZD1cIk00OTIuOTM4LDYxOS44NzVoMy43NWEuOTM4LjkzOCwwLDAsMCwwLTEuODc1aC0zLjc1YS45MzguOTM4LDAsMCwwLDAsMS44NzVaXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTIuNzUgLTIuMTI1KVwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQxOVwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQxOVwiXG4gICAgICAgICAgZD1cIk00OTIuOTM4LDYzNS44NzVoMy43NWEuOTM4LjkzOCwwLDAsMCwwLTEuODc1aC0zLjc1YS45MzguOTM4LDAsMCwwLDAsMS44NzVaXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTIuNzUgLTMuMTI1KVwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBSZWxheENoYWlyID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiNDVcIlxuICAgICAgaGVpZ2h0PVwiNjBcIlxuICAgICAgdmlld0JveD1cIjAgMCA0NSA2MFwiXG4gICAgPlxuICAgICAgPGdcbiAgICAgICAgaWQ9XCJSZWxheF9jaGFpclwiXG4gICAgICAgIGRhdGEtbmFtZT1cIlJlbGF4IGNoYWlyXCJcbiAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC00OCAtNTg0KVwiXG4gICAgICA+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9XCJQYXRoXzE3NDE1XCJcbiAgICAgICAgICBkYXRhLW5hbWU9XCJQYXRoIDE3NDE1XCJcbiAgICAgICAgICBkPVwiTTgyLjcxLDU4Ny4yMTlBMy43NTEsMy43NTEsMCwwLDAsNzksNTg0SDYzYTMuNzUxLDMuNzUxLDAsMCwwLTMuNzEzLDMuMjE5TDU2LDYxNEg4NlptLTIxLjU2Mi4yNUExLjg4MywxLjg4MywwLDAsMSw2Myw1ODUuODc1SDc5YTEuODgzLDEuODgzLDAsMCwxLDEuODUzLDEuNTk1bDMuMDI5LDI0LjY1NUg1OC4xMlpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtMC41KVwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQxNlwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQxNlwiXG4gICAgICAgICAgZD1cIk05MS4xMjUsNjA4SDg5LjI1YTEuODc1LDEuODc1LDAsMCwwLTEuODc1LDEuODc1djEuODc1YTEuODc1LDEuODc1LDAsMCwwLDEuODc1LDEuODc1djcuNUg4Ny4zNzVhMy43NSwzLjc1LDAsMCwwLTMuNzUtMy43NUg1Ny4zNzVhMy43NSwzLjc1LDAsMCwwLTMuNzUsMy43NUg1MS43NXYtNy41YTEuODc1LDEuODc1LDAsMCwwLDEuODc1LTEuODc1di0xLjg3NUExLjg3NSwxLjg3NSwwLDAsMCw1MS43NSw2MDhINDkuODc1QTEuODc1LDEuODc1LDAsMCwwLDQ4LDYwOS44NzV2MS44NzVhMS44NzUsMS44NzUsMCwwLDAsMS44NzUsMS44NzV2Ny41QTEuODc1LDEuODc1LDAsMCwwLDUxLjc1LDYyM2gyLjM4YTMuNzQ3LDMuNzQ3LDAsMCwwLDMuMjQ1LDEuODc1SDY2Ljc1djMuNzVhMS44NzUsMS44NzUsMCwwLDAsMS44NzUsMS44NzVoLjkzOHYxLjg3NUg2My45MzhhNC42OTMsNC42OTMsMCwwLDAtNC42ODcsNC42ODh2Mi45NzZhMi44MTMsMi44MTMsMCwxLDAsMS44NzUsMHYtMi45NzZhMi44MTYsMi44MTYsMCwwLDEsMi44MTMtMi44MTJoNS42MjV2NS43ODhhMi44MTMsMi44MTMsMCwxLDAsMS44NzUsMFY2MzQuMjVoNS42MjVhMi44MTYsMi44MTYsMCwwLDEsMi44MTMsMi44MTN2Mi45NzZhMi44MTMsMi44MTMsMCwxLDAsMS44NzUsMHYtMi45NzZhNC42OTMsNC42OTMsMCwwLDAtNC42ODctNC42ODdINzEuNDM4VjYzMC41aC45MzhhMS44NzUsMS44NzUsMCwwLDAsMS44NzUtMS44NzV2LTMuNzVoOS4zNzVBMy43NDQsMy43NDQsMCwwLDAsODYuODY5LDYyM0g4OS4yNWExLjg3NSwxLjg3NSwwLDAsMCwxLjg3NS0xLjg3NXYtNy41QTEuODc1LDEuODc1LDAsMCwwLDkzLDYxMS43NXYtMS44NzVBMS44NzUsMS44NzUsMCwwLDAsOTEuMTI1LDYwOFptLTQxLjI1LDMuNzV2LTEuODc1SDUxLjc1djEuODc1Wm0xMC4zMTMsMzEuODc1YS45MzguOTM4LDAsMSwxLC45MzgtLjkzN0EuOTM5LjkzOSwwLDAsMSw2MC4xODgsNjQzLjYyNVptMjAuNjI1LTEuODc1YS45MzguOTM4LDAsMSwxLS45MzcuOTM4QS45MzkuOTM5LDAsMCwxLDgwLjgxMyw2NDEuNzVaTTcwLjUsNjQzLjYyNWEuOTM4LjkzOCwwLDEsMSwuOTM4LS45MzdBLjkzOS45MzksMCwwLDEsNzAuNSw2NDMuNjI1Wm0xLjg3NS0xNWgtMy43NXYtMy43NWgzLjc1Wk04My42MjUsNjIzSDU3LjM3NWExLjg3NSwxLjg3NSwwLDAsMSwwLTMuNzVoMjYuMjVhMS44NzUsMS44NzUsMCwwLDEsMCwzLjc1Wm03LjUtMTEuMjVIODkuMjV2LTEuODc1aDEuODc1WlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDAgLTEuNSlcIlxuICAgICAgICAgIGZpbGw9XCIjMjEyMTIxXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJleHBvcnQgY29uc3QgU29mYSA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD1cIjY2Ljc4MlwiXG4gICAgICBoZWlnaHQ9XCI0OFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDY2Ljc4MiA0OFwiXG4gICAgPlxuICAgICAgPHBhdGhcbiAgICAgICAgaWQ9XCJTb2ZhXCJcbiAgICAgICAgZD1cIk0xMDAuNjQzLDE5Ni41MjNoLS4xMTZhNi4wNCw2LjA0LDAsMCwwLTIuMDkyLjM3NXYtNC41NDlBOC4zNDgsOC4zNDgsMCwwLDAsOTAuMDg3LDE4NEg1Ni43YTguMzQ4LDguMzQ4LDAsMCwwLTguMzQ4LDguMzQ4djQuNTMyYTYuMjU4LDYuMjU4LDAsMCwwLTIuMDg3LS4zNThjLS4xMzMsMC0uMjY2LDAtLjQuMDEzYTYuMjYxLDYuMjYxLDAsMCwwLTEuNjg3LDEyLjE1MXYyMS4yMjdBMi4wODYsMi4wODYsMCwwLDAsNDYuMjYxLDIzMmg0LjE3NGEyLjA4NiwyLjA4NiwwLDAsMCwyLjA4Ny0yLjA4N0g5NC4yNjFBMi4wODYsMi4wODYsMCwwLDAsOTYuMzQ4LDIzMmg0LjE3NGEyLjA4NiwyLjA4NiwwLDAsMCwyLjA4Ny0yLjA4N1YyMDguNjg2YTYuMjYxLDYuMjYxLDAsMCwwLTEuOTY2LTEyLjE2M1ptLTUwLjIwOCwzMy4zOUg0Ni4yNjFWMjA4LjY4NmEyLjA4NiwyLjA4NiwwLDAsMC0xLjM5MS0xLjk2Nyw0LjE1NCw0LjE1NCwwLDAsMS0yLjc3OC00LjE1MSw0LjIxMSw0LjIxMSwwLDAsMSwzLjktMy45NTFjLjA5LS4wMDUuMTgxLS4wMDguMjctLjAwOGE0LjE3OCw0LjE3OCwwLDAsMSw0LjE3NCw0LjE3NFptNDMuODI2LTIuMDg3SDUyLjUyMnYtNi4yNjFIOTQuMjYxWm0tNDEuNzM5LTguMzQ4di02LjI2MUg3MC4yNjFhMi4wODksMi4wODksMCwwLDEsMi4wODcsMi4wODd2NC4xNzRabTQxLjczOSwwSDc0LjQzNVYyMTUuM2EyLjA4OSwyLjA4OSwwLDAsMSwyLjA4Ny0yLjA4N0g5NC4yNjFabTAtMTYuNTU1djguMjA3SDc2LjUyMmE0LjE2MSw0LjE2MSwwLDAsMC0zLjEzLDEuNDE5LDQuMTYxLDQuMTYxLDAsMCwwLTMuMTMtMS40MTlINTIuNTIydi04LjM0OGE2LjI0NSw2LjI0NSwwLDAsMC0yLjA4Ny00LjY2NXYtNS43NjlhNi4yNjksNi4yNjksMCwwLDEsNi4yNjEtNi4yNjFIOTAuMDg3YTYuMjY5LDYuMjY5LDAsMCwxLDYuMjYxLDYuMjYxdjUuODMxQTYuNDY3LDYuNDY3LDAsMCwwLDk0LjI2MSwyMDIuOTIzWm03LjY1MiwzLjhhMi4wODYsMi4wODYsMCwwLDAtMS4zOTEsMS45Njd2MjEuMjI3SDk2LjM0OHYtMjYuOTlhNC4zMDYsNC4zMDYsMCwwLDEsNC4xNzktNC4zMTVoLjA3NmE0LjE3NCw0LjE3NCwwLDAsMSwxLjMxLDguMTA5WlwiXG4gICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtNDAgLTE4NClcIlxuICAgICAgICBmaWxsPVwiIzIxMjEyMVwiXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBTdG9yYWdlID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMThweCcsXG4gIGhlaWdodCA9ICcxOHB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPVwiNDguNzVcIlxuICAgICAgaGVpZ2h0PVwiNjBcIlxuICAgICAgdmlld0JveD1cIjAgMCA0OC43NSA2MFwiXG4gICAgPlxuICAgICAgPGcgaWQ9XCJTdG9yYWdlXCIgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0zMTggLTQ0OClcIj5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD1cIlBhdGhfMTc0MjJcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIlBhdGggMTc0MjJcIlxuICAgICAgICAgIGQ9XCJNMzY0Ljg3NSw0NDhoLTQ1QTEuODc0LDEuODc0LDAsMCwwLDMxOCw0NDkuODc1djUyLjVhMS44NzQsMS44NzQsMCwwLDAsMS44NzUsMS44NzVoMy43NVY1MDhIMzI1LjV2LTMuNzVoMzMuNzVWNTA4aDEuODc1di0zLjc1aDMuNzVhMS44NzQsMS44NzQsMCwwLDAsMS44NzUtMS44NzV2LTUyLjVBMS44NzQsMS44NzQsMCwwLDAsMzY0Ljg3NSw0NDhabS0yMi41LDU0LjM3NWgtMjIuNVY0OTNoMjIuNVptMC0xMS4yNWgtMjIuNVY0NTkuMjVoMTAuMzEzdjIuMzExbC04LjAyLDUuMzQ3YS45MzguOTM4LDAsMCwwLC41MiwxLjcxN2gxNi44NzVhLjkzOC45MzgsMCwwLDAsLjUyLTEuNzE3bC04LjAyLTUuMzQ3VjQ1OS4yNWgxMC4zMTNabS0xMS4yNS0yNy45MzYsNS4zNDEsMy41NjFIMzI1Ljc4NFptMTEuMjUtNS44MTRoLTIyLjV2LTcuNWgyMi41Wm0yMi41LDQ1SDM0NC4yNVY0OTNoMjAuNjI1Wm0wLTExLjI1SDM0NC4yNXYtNDEuMjVoMjAuNjI1WlwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQyM1wiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyM1wiXG4gICAgICAgICAgZD1cIk0zNTUsNTAyaDRhMSwxLDAsMCwwLDAtMmgtNGExLDEsMCwwLDAsMCwyWlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0yLjU0MyAtNClcIlxuICAgICAgICAgIGZpbGw9XCIjMjEyMTIxXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD1cIlBhdGhfMTc0MjRcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIlBhdGggMTc0MjRcIlxuICAgICAgICAgIGQ9XCJNMzI5LDUwMmg0YTEsMSwwLDAsMCwwLTJoLTRhMSwxLDAsMCwwLDAsMlpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtMC43MDcgLTQpXCJcbiAgICAgICAgICBmaWxsPVwiIzIxMjEyMVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgaWQ9XCJQYXRoXzE3NDI1XCJcbiAgICAgICAgICBkYXRhLW5hbWU9XCJQYXRoIDE3NDI1XCJcbiAgICAgICAgICBkPVwiTTM0OSw0NzhhMSwxLDAsMCwwLDEtMXYtNGExLDEsMCwwLDAtMiwwdjRBMSwxLDAsMCwwLDM0OSw0NzhaXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTEuOTUgLTEuNjU1KVwiXG4gICAgICAgICAgZmlsbD1cIiMyMTIxMjFcIlxuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBUYWJsZSA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD1cIjYwXCJcbiAgICAgIGhlaWdodD1cIjQ4Ljc1XCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgNjAgNDguNzVcIlxuICAgID5cbiAgICAgIDxwYXRoXG4gICAgICAgIGlkPVwiQ2VudGVyX3RhYmxlXCJcbiAgICAgICAgZGF0YS1uYW1lPVwiQ2VudGVyIHRhYmxlXCJcbiAgICAgICAgZD1cIk0yMjYuNzU3LDU5MS45NDVBOTguODQyLDk4Ljg0MiwwLDAsMCwyMDYsNTkwYTk4Ljg0Miw5OC44NDIsMCwwLDAtMjAuNzU3LDEuOTQ1QzE3OS4xMSw1OTMuMzMsMTc2LDU5NS4yLDE3Niw1OTcuNXMzLjExLDQuMTcsOS4yNDMsNS41NTVhOTMuODY4LDkzLjg2OCwwLDAsMCwxNy45NDUsMS45MTV2NC43MjRhNC42NzQsNC42NzQsMCwwLDAsMCw3LjQ4N3Y4LjQ0NGgtMS44NzVhNC43LDQuNywwLDAsMC00LjU5NCwzLjc1aC0xLjAzMUE0LjY5Myw0LjY5MywwLDAsMCwxOTEsNjM0LjA2M3YzLjc1YS45MzguOTM4LDAsMCwwLC45MzguOTM4aDMuNzVhLjkzOC45MzgsMCwwLDAsLjkzOC0uOTM3VjYzNWguOTM4YTQuNyw0LjcsMCwwLDAsNC41OTQtMy43NWgxLjAzMXYuOTM4YTIuODEzLDIuODEzLDAsMCwwLDUuNjI1LDB2LS45MzdoMS4wMzFhNC43LDQuNywwLDAsMCw0LjU5NCwzLjc1aC45Mzh2Mi44MTNhLjkzOC45MzgsMCwwLDAsLjkzOC45MzhoMy43NWEuOTM4LjkzOCwwLDAsMCwuOTM4LS45Mzd2LTMuNzVhNC42OTMsNC42OTMsMCwwLDAtNC42ODctNC42ODdoLTEuMDMxYTQuNyw0LjcsMCwwLDAtNC41OTQtMy43NWgtMS44NzV2LTguNDQ0YTQuNjc0LDQuNjc0LDAsMCwwLDAtNy40ODdWNjA0Ljk3YTkzLjg3Nyw5My44NzcsMCwwLDAsMTcuOTQ1LTEuOTE1QzIzMi44OSw2MDEuNjcsMjM2LDU5OS44LDIzNiw1OTcuNVMyMzIuODksNTkzLjMzLDIyNi43NTcsNTkxLjk0NVptLTIzLjU3LDM3LjQzaC0xLjg3NWEuOTM4LjkzOCwwLDAsMC0uOTM3LjkzOCwyLjgxNiwyLjgxNiwwLDAsMS0yLjgxMiwyLjgxM2gtMS44NzVhLjkzOC45MzgsMCwwLDAtLjkzNy45Mzh2Mi44MTNoLTEuODc1di0yLjgxMmEyLjgxNiwyLjgxNiwwLDAsMSwyLjgxMy0yLjgxMmgxLjg3NWEuOTM4LjkzOCwwLDAsMCwuOTM4LS45MzcsMi44MTYsMi44MTYsMCwwLDEsMi44MTMtMi44MTJoMS44NzVabTcuNS0xLjg3NWEyLjgxNiwyLjgxNiwwLDAsMSwyLjgxMywyLjgxMy45MzguOTM4LDAsMCwwLC45MzguOTM4aDEuODc1YTIuODE2LDIuODE2LDAsMCwxLDIuODEzLDIuODEzdjIuODEzSDIxNy4yNXYtMi44MTJhLjkzOC45MzgsMCwwLDAtLjkzNy0uOTM3aC0xLjg3NWEyLjgxNiwyLjgxNiwwLDAsMS0yLjgxMi0yLjgxMi45MzguOTM4LDAsMCwwLS45MzctLjkzN2gtMS44NzVWNjI3LjVabS0zLTExLjgxNy0uNzQ3LjU2MnYxNS45NDJhLjkzOC45MzgsMCwwLDEtMS44NzUsMFY2MTYuMjQ1bC0uNzQ3LS41NjJhMi44LDIuOCwwLDAsMSwwLTQuNDkxbC43NDctLjU2MlY2MDVoMS44NzV2NS42M2wuNzQ3LjU2MmEyLjgsMi44LDAsMCwxLDAsNC40OTFabTE4LjY1OS0xNC40NTdhOTYuOSw5Ni45LDAsMCwxLTIwLjM0NCwxLjksOTYuOSw5Ni45LDAsMCwxLTIwLjM0NC0xLjljLTYuMTQzLTEuMzg3LTcuNzgxLTIuOTk0LTcuNzgxLTMuNzI2czEuNjM5LTIuMzM5LDcuNzgxLTMuNzI2YTk2LjksOTYuOSwwLDAsMSwyMC4zNDQtMS45LDk2LjksOTYuOSwwLDAsMSwyMC4zNDQsMS45YzYuMTQzLDEuMzg3LDcuNzgxLDIuOTk0LDcuNzgxLDMuNzI2UzIzMi40ODYsNTk5LjgzOSwyMjYuMzQ0LDYwMS4yMjZaXCJcbiAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0xNzYgLTU5MClcIlxuICAgICAgICBmaWxsPVwiIzIxMjEyMVwiXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBUb29scyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzE4cHgnLFxuICBoZWlnaHQgPSAnMThweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD1cIjYwXCJcbiAgICAgIGhlaWdodD1cIjYwXCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgNjAgNjBcIlxuICAgID5cbiAgICAgIDxnIGlkPVwiVG9vbHNcIiB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTQ0OCAtNzIwKVwiPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGlkPVwiUGF0aF8xNzQyOVwiXG4gICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNzQyOVwiXG4gICAgICAgICAgZD1cIk00NzcuMDYzLDc2NWgtLjg4bC44NTEtMy40LS45NjctMy44NjVMNDc0LjI1LDc2NUg0NTUuNWwzLjI4MS0xMy4xMjVINDc0LjZMNDc0LjEzNSw3NTBINDU5LjI1bDMuMjgxLTEzLjEyNWg4LjMyMkw0NzAuMzg1LDczNUg0NjNsMy43NS0xNWgtMS45MzNsLTE0LjUzMSw1OC4xMjVoLTEuMzQ4YS45MzguOTM4LDAsMCwwLDAsMS44NzVoMy43NWEuOTM4LjkzOCwwLDAsMCwwLTEuODc1aC0uNDY5bDIuODEzLTExLjI1aDE4Ljc1bC0yLjgxMiwxMS4yNWgtMS40MDZhLjkzOC45MzgsMCwwLDAsMCwxLjg3NWgzLjc1YS45MzguOTM4LDAsMCwwLDAtMS44NzVINDcyLjlsMi44MTMtMTEuMjVoMS4zNDlhLjkzOC45MzgsMCwwLDAsMC0xLjg3NVpcIlxuICAgICAgICAgIGZpbGw9XCIjMjEyMTIxXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBpZD1cIlBhdGhfMTc0MzBcIlxuICAgICAgICAgIGRhdGEtbmFtZT1cIlBhdGggMTc0MzBcIlxuICAgICAgICAgIGQ9XCJNNTA4LjQzNCw3NzguMTI1aC0xLjM0OWwtMi44MTItMTEuMjVoLjQxMmEuOTM4LjkzOCwwLDAsMCwwLTEuODc1aC0uODhsLTMuMjgxLTEzLjEyNWguNDEyYS45MzguOTM4LDAsMCwwLDAtMS44NzVoLS44OGwtMy4yODEtMTMuMTI1aC40MTJhLjkzOC45MzgsMCwwLDAsMC0xLjg3NWgtLjg4bC0zLjI4MS0xMy4xMjVoMi4yODdhLjkzOC45MzgsMCwwLDAsMC0xLjg3NUg0NjkuOTM4bC4xMTQuNDU1LDE0LjQxNyw1Ny42N2gtLjQxMWEuOTM4LjkzOCwwLDAsMCwwLDEuODc1aDMuNzVhLjkzOC45MzgsMCwwLDAsMC0xLjg3NUg0ODYuNGwtMi44MTItMTEuMjVoMTguNzVsMi44MTMsMTEuMjVoLS40NjlhLjkzOC45MzgsMCwwLDAsMCwxLjg3NWgzLjc1YS45MzguOTM4LDAsMCwwLDAtMS44NzVabS0zNi4wOTQtNTYuMjVoMTguNzVMNDk0LjM3MSw3MzVoLTE4Ljc1Wm0zLjc1LDE1aDE4Ljc1TDQ5OC4xMjEsNzUwaC0xOC43NVpNNDgzLjEyMSw3NjVsLTMuMjgxLTEzLjEyNWgxOC43NUw1MDEuODcxLDc2NVpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtMS4zNzEpXCJcbiAgICAgICAgICBmaWxsPVwiIzIxMjEyMVwiXG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgY3NzIGZyb20gJ0BzdHlsZWQtc3lzdGVtL2Nzcyc7XG5cbmV4cG9ydCBjb25zdCBXYWxrZXJXcmFwcGVyID0gc3R5bGVkLmRpdihcbiAgY3NzKHtcbiAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgICB3aWR0aDogJzEwMCUnLFxuICAgIHBhZGRpbmc6ICcwcHggMjBweCAxNXB4JyxcblxuICAgIGJ1dHRvbjoge1xuICAgICAgcGFkZGluZzogMCxcbiAgICB9LFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IENhdGVnb3J5V3JhcHBlciA9IHN0eWxlZC5kaXYoXG4gIGNzcyh7XG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGFsaWduSXRlbXM6ICdiYXNlbGluZScsXG4gICAgd2lkdGg6ICcxMDAlJyxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBDYXRlZ29yeSA9IHN0eWxlZC5zcGFuKFxuICBjc3Moe1xuICAgIGZvbnRTaXplOiAnc20nLFxuICAgIGNvbG9yOiAndGV4dC5ib2xkJyxcbiAgICBmb250V2VpZ2h0OiAnYm9sZCcsXG4gICAgcGFkZGluZzogJzVweCAxMHB4JyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdncmF5LjUwMCcsXG4gICAgYm9yZGVyUmFkaXVzOiAnYmFzZScsXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgTm9DYXRlZ29yeSA9IHN0eWxlZC5zcGFuKFxuICBjc3Moe1xuICAgIGZvbnRTaXplOiAnYmFzZScsXG4gICAgY29sb3I6ICd0ZXh0LmJvbGQnLFxuICAgIGZvbnRXZWlnaHQ6ICdib2xkJyxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBJY29uV3JhcHBlciA9IHN0eWxlZC5zcGFuKFxuICBjc3Moe1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBwYWRkaW5nOiAnMCA4cHgnLFxuICAgIGNvbG9yOiAnZ3JheS45MDAnLFxuICB9KVxuKTtcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgV2Fsa2VyV3JhcHBlcixcbiAgQ2F0ZWdvcnksXG4gIE5vQ2F0ZWdvcnksXG4gIEljb25XcmFwcGVyLFxuICBDYXRlZ29yeVdyYXBwZXIsXG59IGZyb20gJy4vY2F0ZWdvcnktd2Fsa2VyLnN0eWxlJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ2NvbXBvbmVudHMvYnV0dG9uL2J1dHRvbic7XG5pbXBvcnQgeyBBcnJvd05leHQgfSBmcm9tICdhc3NldHMvaWNvbnMvQXJyb3dOZXh0JztcbmltcG9ydCBTcHJpbmdNb2RhbCBmcm9tICdjb21wb25lbnRzL3NwcmluZy1tb2RhbC9zcHJpbmctbW9kYWwnO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuLy8gaW1wb3J0IHsgVHJlZU1lbnUgfSBmcm9tICdjb21wb25lbnRzL3RyZWUtbWVudS90cmVlLW1lbnUnO1xuaW1wb3J0IHN0YXJ0Q2FzZSBmcm9tICdsb2Rhc2gvc3RhcnRDYXNlJztcblxudHlwZSBXYWxrZXJQcm9wcyA9IHtcbiAgc3R5bGU/OiBhbnk7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbiAgLy8gb25DbGljazogKCkgPT4gdm9pZDtcbn07XG5cbmNvbnN0IENhdGVnb3J5V2Fsa2VyOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudDxXYWxrZXJQcm9wcz4gPSAoe1xuICBzdHlsZSxcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbn0pID0+IHtcbiAgY29uc3QgW2lzT3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHsgcXVlcnkgfSA9IHVzZVJvdXRlcigpO1xuICByZXR1cm4gKFxuICAgIDxXYWxrZXJXcmFwcGVyIHN0eWxlPXtzdHlsZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9PlxuICAgICAgPENhdGVnb3J5V3JhcHBlcj5cbiAgICAgICAge3F1ZXJ5LmNhdGVnb3J5ID8gKFxuICAgICAgICAgIDxDYXRlZ29yeT57c3RhcnRDYXNlKHF1ZXJ5LmNhdGVnb3J5IGFzIHN0cmluZyl9PC9DYXRlZ29yeT5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8Tm9DYXRlZ29yeT5ObyBDYXRlZ29yeSBTZWxlY3RlZDwvTm9DYXRlZ29yeT5cbiAgICAgICAgKX1cbiAgICAgICAgey8qIDxJY29uV3JhcHBlcj5cbiAgICAgICAgICA8QXJyb3dOZXh0IHdpZHRoPVwiMTNweFwiIC8+XG4gICAgICAgIDwvSWNvbldyYXBwZXI+XG4gICAgICAgIDxDYXRlZ29yeT57Y2hpbGR9PC9DYXRlZ29yeT4gKi99XG4gICAgICA8L0NhdGVnb3J5V3JhcHBlcj5cblxuICAgICAgPEJ1dHRvbiB2YXJpYW50PSd0ZXh0JyBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5cbiAgICAgICAgRmlsdGVyXG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxTcHJpbmdNb2RhbCBpc09wZW49e2lzT3Blbn0gb25SZXF1ZXN0Q2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfT5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9TcHJpbmdNb2RhbD5cbiAgICA8L1dhbGtlcldyYXBwZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDYXRlZ29yeVdhbGtlcjtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgQ29udGVudExvYWRlciBmcm9tICdyZWFjdC1jb250ZW50LWxvYWRlcic7XG5cbmNvbnN0IFBvc3RMb2FkZXIgPSAocHJvcHMpID0+IChcbiAgPENvbnRlbnRMb2FkZXJcbiAgICBoZWlnaHQ9ezM1MH1cbiAgICB3aWR0aD17MjQ1fVxuICAgIHNwZWVkPXsyfVxuICAgIGJhY2tncm91bmRDb2xvcj1cIiNmM2YzZjNcIlxuICAgIGZvcmVncm91bmRDb2xvcj1cIiNlY2ViZWJcIlxuICAgIHsuLi5wcm9wc31cbiAgPlxuICAgIDxyZWN0IHg9XCIyXCIgeT1cIjJcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjI0MFwiIGhlaWdodD1cIjE5N1wiIC8+XG4gICAgPHJlY3QgeD1cIjE1XCIgeT1cIjIyMFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMTQwXCIgaGVpZ2h0PVwiMjVcIiAvPlxuICAgIDxyZWN0IHg9XCIxNVwiIHk9XCIyNTRcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjY1XCIgaGVpZ2h0PVwiMTVcIiAvPlxuICAgIDxyZWN0IHg9XCIxNVwiIHk9XCIzMDBcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjY3XCIgaGVpZ2h0PVwiMjBcIiAvPlxuICAgIDxyZWN0IHg9XCIxNzBcIiB5PVwiMzAwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCI2MFwiIGhlaWdodD1cIjIwXCIgLz5cbiAgPC9Db250ZW50TG9hZGVyPlxuKTtcbmV4cG9ydCBjb25zdCBTaWRlYmFyTW9iaWxlTG9hZGVyID0gKCkgPT4gKFxuICA8Q29udGVudExvYWRlclxuICAgIGhlaWdodD17NDZ9XG4gICAgd2lkdGg9ezQwMH1cbiAgICBzcGVlZD17Mn1cbiAgICBiYWNrZ3JvdW5kQ29sb3I9XCIjZjNmM2YzXCJcbiAgICBmb3JlZ3JvdW5kQ29sb3I9XCIjZWNlYmViXCJcbiAgPlxuICAgIDxyZWN0IHg9XCI1OFwiIHk9XCIxMFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjg3XCIgaGVpZ2h0PVwiMjZcIiAvPlxuICAgIDxyZWN0IHg9XCIzNjRcIiB5PVwiMTBcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjI2XCIgaGVpZ2h0PVwiMjZcIiAvPlxuICAgIDxyZWN0IHg9XCIxNlwiIHk9XCIxMFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjZcIiBoZWlnaHQ9XCIyNlwiIC8+XG4gIDwvQ29udGVudExvYWRlcj5cbik7XG5cbmV4cG9ydCBjb25zdCBTaWRlYmFyTG9hZGVyID0gKHByb3BzKSA9PiAoXG4gIDxDb250ZW50TG9hZGVyXG4gICAgaGVpZ2h0PXs0MDB9XG4gICAgd2lkdGg9XCJjYWxjKDEwMCUgLSAzMHB4KVwiXG4gICAgc3BlZWQ9ezJ9XG4gICAgYmFja2dyb3VuZENvbG9yPVwiI2YzZjNmM1wiXG4gICAgZm9yZWdyb3VuZENvbG9yPVwiI2VjZWJlYlwiXG4gICAgey4uLnByb3BzfVxuICA+XG4gICAgPHJlY3QgeD1cIjM3NlwiIHk9XCIyMlwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMFwiIGhlaWdodD1cIjBcIiAvPlxuICAgIDxyZWN0IHg9XCIyN1wiIHk9XCI1MFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjUwXCIgcng9XCIwXCIgcnk9XCIwXCIgd2lkdGg9XCIyNjBcIiBoZWlnaHQ9XCIyNFwiIC8+XG5cbiAgICA8cmVjdCB4PVwiMjdcIiB5PVwiODlcIiByeD1cIjBcIiByeT1cIjBcIiB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiAvPlxuICAgIDxyZWN0IHg9XCI2OVwiIHk9XCI4OVwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjEyOFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjEyOFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjE2N1wiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjE2N1wiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjIwNlwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjIwNlwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjI0NVwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjI0NVwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjI4NFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjI4NFwiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuXG4gICAgPHJlY3QgeD1cIjI3XCIgeT1cIjMyM1wiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIC8+XG4gICAgPHJlY3QgeD1cIjY5XCIgeT1cIjMyM1wiIHJ4PVwiMFwiIHJ5PVwiMFwiIHdpZHRoPVwiMjYwXCIgaGVpZ2h0PVwiMjRcIiAvPlxuICA8L0NvbnRlbnRMb2FkZXI+XG4pO1xuZXhwb3J0IGRlZmF1bHQgUG9zdExvYWRlcjtcbiIsImltcG9ydCB7IE92ZXJsYXlTY3JvbGxiYXJzQ29tcG9uZW50IH0gZnJvbSAnb3ZlcmxheXNjcm9sbGJhcnMtcmVhY3QnO1xuXG50eXBlIFNjcm9sbGJhclByb3BzID0ge1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIG9wdGlvbnM/OiBhbnk7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IFNjcm9sbGJhcjogUmVhY3QuRkM8U2Nyb2xsYmFyUHJvcHM+ID0gKHtcbiAgY2hpbGRyZW4sXG4gIGNsYXNzTmFtZSxcbiAgb3B0aW9ucyxcbiAgc3R5bGUsXG4gIC4uLnByb3BzXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPE92ZXJsYXlTY3JvbGxiYXJzQ29tcG9uZW50XG4gICAgICBvcHRpb25zPXt7XG4gICAgICAgIGNsYXNzTmFtZTogYCR7Y2xhc3NOYW1lfSBvcy10aGVtZS10aGluYCxcbiAgICAgICAgc2Nyb2xsYmFyczoge1xuICAgICAgICAgIGF1dG9IaWRlOiAnbGVhdmUnLFxuICAgICAgICB9LFxuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgfX1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9PdmVybGF5U2Nyb2xsYmFyc0NvbXBvbmVudD5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVHJhbnNpdGlvbiwgYW5pbWF0ZWQgfSBmcm9tICdyZWFjdC1zcHJpbmcnO1xuaW1wb3J0IHsgQmFzZU1vZGFsIH0gZnJvbSAncmVhY3Qtc3ByaW5nLW1vZGFsJztcbmltcG9ydCB7IENsb3NlSWNvbiB9IGZyb20gJ2Fzc2V0cy9pY29ucy9DbG9zZUljb24nO1xuaW1wb3J0IHsgU2Nyb2xsYmFyIH0gZnJvbSAnY29tcG9uZW50cy9zY3JvbGxiYXIvc2Nyb2xsYmFyJztcblxudHlwZSBTcHJpbmdNb2RhbFByb3BzID0ge1xuICBpc09wZW4/OiBib29sZWFuO1xuICBvblJlcXVlc3RDbG9zZT86ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIHN0eWxlPzogYW55O1xufTtcblxuY29uc3QgU3ByaW5nTW9kYWw6IFJlYWN0LkZDPFNwcmluZ01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvblJlcXVlc3RDbG9zZSxcbiAgY2hpbGRyZW4sXG4gIHN0eWxlID0ge30sXG59KSA9PiB7XG4gIGNvbnN0IHRyYW5zaXRpb24gPSB1c2VUcmFuc2l0aW9uKGlzT3BlbiwgbnVsbCwge1xuICAgIGZyb206IHsgdHJhbnNmb3JtOiAndHJhbnNsYXRlWSgxMDAlKSB0cmFuc2xhdGVZKDU1cHgpIHRyYW5zbGF0ZVgoLTUwJSknIH0sXG4gICAgZW50ZXI6IHsgdHJhbnNmb3JtOiAndHJhbnNsYXRlWSgwJSkgdHJhbnNsYXRlWSgwKSB0cmFuc2xhdGVYKC01MCUpJyB9LFxuICAgIGxlYXZlOiB7IHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoMTAwJSkgdHJhbnNsYXRlWSg1NXB4KSB0cmFuc2xhdGVYKC01MCUpJyB9LFxuICB9KTtcblxuICBjb25zdCBzdGF0aWNTdHlsZXMgPSB7XG4gICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgYm90dG9tOiAwLFxuICAgIGxlZnQ6ICc1MCUnLFxuICAgIHBhZGRpbmc6ICcwJyxcbiAgICB3aWR0aDogJ2NhbGMoMTAwJSArIDFweCknLFxuICAgIGhlaWdodDogJzEwMCUnLFxuICAgIG1heEhlaWdodDogJzcwdmgnLFxuICAgIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLFxuICAgIGJvcmRlclJhZGl1czogJzBweCcsXG4gICAgYm9yZGVyVG9wTGVmdFJhZGl1czogJzIwcHgnLFxuICAgIGJvcmRlclRvcFJpZ2h0UmFkaXVzOiAnMjBweCcsXG4gICAgekluZGV4OiA5OTk5OSxcbiAgfTtcblxuICBjb25zdCBidXR0b25TdHlsZSA9IHtcbiAgICB3aWR0aDogNDAsXG4gICAgaGVpZ2h0OiA0MCxcbiAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLFxuICAgIGNvbG9yOiAnIzBEMTEzNicsXG4gICAgYm9yZGVyOiAwLFxuICAgIG91dGxpbmU6IDAsXG4gICAgYm94U2hhZG93OiAnbm9uZScsXG4gICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyBhcyAnYWJzb2x1dGUnLFxuICAgIHRvcDogLTU1LFxuICAgIGxlZnQ6ICc1MCUnLFxuICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoLTUwJSknLFxuICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuXG4gICAgJzpmb2N1cyc6IHtcbiAgICAgIG91dGxpbmU6IDAsXG4gICAgICBib3hTaGFkb3c6ICdub25lJyxcbiAgICB9LFxuICB9O1xuXG4gIGNvbnN0IHNjcm9sbGJhclN0eWxlID0ge1xuICAgIGhlaWdodDogJzEwMCUnLFxuICAgIG1heEhlaWdodDogJzEwMCUnLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPEJhc2VNb2RhbCBpc09wZW49e2lzT3Blbn0gb25SZXF1ZXN0Q2xvc2U9e29uUmVxdWVzdENsb3NlfT5cbiAgICAgIHt0cmFuc2l0aW9uLm1hcChcbiAgICAgICAgKHsgaXRlbSwga2V5LCBwcm9wczogdHJhbnNpdGlvblN0eWxlcyB9KSA9PlxuICAgICAgICAgIGl0ZW0gJiYgKFxuICAgICAgICAgICAgPGFuaW1hdGVkLmRpdlxuICAgICAgICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgICAgICAgc3R5bGU9e3sgLi4udHJhbnNpdGlvblN0eWxlcywgLi4uc3RhdGljU3R5bGVzLCAuLi5zdHlsZSB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25SZXF1ZXN0Q2xvc2V9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgLi4uYnV0dG9uU3R5bGUgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDbG9zZUljb24gc3R5bGU9e3sgd2lkdGg6IDEyLCBoZWlnaHQ6IDEyIH19IC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8U2Nyb2xsYmFyIHN0eWxlPXt7IC4uLnNjcm9sbGJhclN0eWxlIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzMwcHgnIH19PntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAgICAgICAgPC9TY3JvbGxiYXI+XG4gICAgICAgICAgICA8L2FuaW1hdGVkLmRpdj5cbiAgICAgICAgICApXG4gICAgICApfVxuICAgIDwvQmFzZU1vZGFsPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU3ByaW5nTW9kYWw7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCBjc3MgZnJvbSAnQHN0eWxlZC1zeXN0ZW0vY3NzJztcbmltcG9ydCB7IGFuaW1hdGVkIH0gZnJvbSAncmVhY3Qtc3ByaW5nJztcbmV4cG9ydCBjb25zdCBIZWFkZXIgPSBzdHlsZWQuaGVhZGVyPGFueT4oXG4gIChwcm9wcykgPT5cbiAgICBjc3Moe1xuICAgICAgZm9udFNpemU6IHByb3BzLmRlcHRoID09PSAncGFyZW50JyA/IFsnYmFzZSddIDogWydzbSddLFxuICAgICAgZm9udFdlaWdodDogJ21lZGl1bScsXG4gICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgIG1hcmdpbkJvdHRvbTogcHJvcHMuZGVwdGggPT09ICdwYXJlbnQnID8gMTIgOiAwLFxuICAgICAgY29sb3I6XG4gICAgICAgIHByb3BzLmRlcHRoID09PSAncGFyZW50J1xuICAgICAgICAgID8gcHJvcHMub3BlblxuICAgICAgICAgICAgPyAncHJpbWFyeS5yZWd1bGFyJ1xuICAgICAgICAgICAgOiAndGV4dC5ib2xkJ1xuICAgICAgICAgIDogcHJvcHMub3BlblxuICAgICAgICAgID8gJ3ByaW1hcnkucmVndWxhcidcbiAgICAgICAgICA6ICd0ZXh0LnJlZ3VsYXInLFxuICAgICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICB0cmFuc2l0aW9uOiAnMC4xNXMgZWFzZS1pbi1vdXQnLFxuICAgICAgcGFkZGluZzogcHJvcHMuZGVwdGggPT09ICdwYXJlbnQnID8gJzVweCAwJyA6ICc1cHggMTBweCcsXG4gICAgICBtYXJnaW5MZWZ0OiBwcm9wcy5kZXB0aCA9PT0gJ2NoaWxkJyA/ICctMTBweCcgOiBudWxsLFxuICAgICAgYm9yZGVyUmFkaXVzOiBwcm9wcy5kZXB0aCA9PT0gJ2NoaWxkJyA/ICdiYXNlJyA6IG51bGwsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6XG4gICAgICAgIHByb3BzLmRlcHRoID09PSAnY2hpbGQnID8gcHJvcHMub3BlbiAmJiAnZ3JheS4yMDAnIDogbnVsbCxcblxuICAgICAgJy50b2dnbGVCdXR0b24nOiB7XG4gICAgICAgIGNvbG9yOiBwcm9wcy5vcGVuID8gJ3ByaW1hcnkucmVndWxhcicgOiAndGV4dC5ib2xkJyxcbiAgICAgICAgcGFkZGluZzogJzAgNXB4JyxcbiAgICAgICAgbWFyZ2luTGVmdDogJ2F1dG8nLFxuICAgICAgICBoZWlnaHQ6ICdhdXRvJyxcbiAgICAgICAgdHJhbnNpdGlvbjogJ3RyYW5zZm9ybSAwLjNzJyxcbiAgICAgICAgdHJhbnNmb3JtOiBwcm9wcy5vcGVuID8gJ3JvdGF0ZSg5MGRlZyknIDogJycsXG4gICAgICB9LFxuXG4gICAgICAnJjpob3Zlcic6IHtcbiAgICAgICAgY29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuXG4gICAgICAgICcudG9nZ2xlQnV0dG9uJzoge1xuICAgICAgICAgIGNvbG9yOiAncHJpbWFyeS5yZWd1bGFyJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSksXG4gIHtcbiAgICBvdXRsaW5lOiAwLFxuICB9XG4pO1xuXG5leHBvcnQgY29uc3QgSWNvbldyYXBwZXIgPSBzdHlsZWQuZGl2PGFueT4oXG4gIChwcm9wcykgPT5cbiAgICBjc3Moe1xuICAgICAgd2lkdGg6IHByb3BzLmRlcHRoID09PSAnY2hpbGQnID8gMTAgOiAyMCxcbiAgICAgIGhlaWdodDogJ2F1dG8nLFxuICAgICAgbWFyZ2luUmlnaHQ6IHByb3BzLmRlcHRoID09PSAnY2hpbGQnID8gJzhweCcgOiAxNSxcblxuICAgICAgc3ZnOiB7XG4gICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgIG1heEhlaWdodDogMjAsXG4gICAgICAgIGhlaWdodDogcHJvcHMuZGVwdGggPT09ICdjaGlsZCcgPyAnMnB4JyA6ICdhdXRvJyxcbiAgICAgIH0sXG4gICAgfSksXG4gIHtcbiAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICBmbGV4U2hyaW5rOiAwLFxuICB9XG4pO1xuXG5leHBvcnQgY29uc3QgVGl0bGUgPSBzdHlsZWQuc3Bhbih7XG4gIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcbiAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXG4gIHZlcnRpY2FsQWxpZ246ICdtaWRkbGUnLFxuICBvdmVyZmxvdzogJ2hpZGRlbicsXG59KTtcblxuZXhwb3J0IGNvbnN0IENvbnRlbnQgPSBzdHlsZWQoYW5pbWF0ZWQuZGl2KSh7XG4gIHdpbGxDaGFuZ2U6ICd0cmFuc2Zvcm0sIG9wYWNpdHksIGhlaWdodCcsXG4gIGJvcmRlckxlZnQ6IDAsXG4gIG92ZXJmbG93OiAnaGlkZGVuJyxcbn0pO1xuXG5leHBvcnQgY29uc3QgRnJhbWUgPSBzdHlsZWQuZGl2PGFueT4oXG4gIChwcm9wcykgPT5cbiAgICBjc3Moe1xuICAgICAgbWFyZ2luQm90dG9tOiBwcm9wcy5kZXB0aCA9PT0gJ3BhcmVudCcgPyAxNSA6IDEwLFxuICAgICAgcGFkZGluZ0xlZnQ6IHByb3BzLmRlcHRoID09PSAnY2hpbGQnID8gMzIgOiAwLFxuICAgIH0pLFxuICB7XG4gICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG5cbiAgICBvdmVyZmxvd1g6ICdoaWRkZW4nLFxuICB9XG4pO1xuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQcmV2aW91cywgdXNlTWVhc3VyZSB9IGZyb20gJ3V0aWxzL2hvb2tzJztcbmltcG9ydCB7IHVzZVNwcmluZywgYW5pbWF0ZWQgfSBmcm9tICdyZWFjdC1zcHJpbmcnO1xuaW1wb3J0IHsgRnJhbWUsIFRpdGxlLCBDb250ZW50LCBIZWFkZXIsIEljb25XcmFwcGVyIH0gZnJvbSAnLi90cmVlLW1lbnUuc3R5bGUnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnY29tcG9uZW50cy9idXR0b24vYnV0dG9uJztcbmltcG9ydCB7IEFycm93TmV4dCB9IGZyb20gJ2Fzc2V0cy9pY29ucy9BcnJvd05leHQnO1xuaW1wb3J0ICogYXMgaWNvbnMgZnJvbSAnYXNzZXRzL2ljb25zL2NhdGVnb3J5LWljb25zJztcblxuY29uc3QgVHJlZSA9IFJlYWN0Lm1lbW8oXG4gICh7XG4gICAgY2hpbGRyZW4sXG4gICAgbmFtZSxcbiAgICBpY29uLFxuICAgIC8vIGlzT3BlbixcbiAgICBvbkNsaWNrLFxuICAgIGRyb3Bkb3duLFxuICAgIG9uVG9nZ2xlQnRuQ2xpY2ssXG4gICAgZGVwdGgsXG4gICAgZGVmYXVsdE9wZW4gPSBmYWxzZSxcbiAgfTogYW55KSA9PiB7XG4gICAgY29uc3QgW2lzT3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShkZWZhdWx0T3Blbik7XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIHNldE9wZW4oZGVmYXVsdE9wZW4pO1xuICAgIH0sIFtkZWZhdWx0T3Blbl0pO1xuICAgIGNvbnN0IHByZXZpb3VzID0gdXNlUHJldmlvdXMoaXNPcGVuKTtcbiAgICBjb25zdCBbYmluZCwgeyBoZWlnaHQ6IHZpZXdIZWlnaHQgfV0gPSB1c2VNZWFzdXJlKCk7XG4gICAgY29uc3QgeyBoZWlnaHQsIG9wYWNpdHksIHRyYW5zZm9ybSB9ID0gdXNlU3ByaW5nPGFueT4oe1xuICAgICAgZnJvbTogeyBoZWlnaHQ6IDAsIG9wYWNpdHk6IDAsIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZTNkKDIwcHgsMCwwKScgfSxcbiAgICAgIHRvOiB7XG4gICAgICAgIGhlaWdodDogaXNPcGVuID8gdmlld0hlaWdodCA6IDAsXG4gICAgICAgIG9wYWNpdHk6IGlzT3BlbiA/IDEgOiAwLFxuICAgICAgICB0cmFuc2Zvcm06IGB0cmFuc2xhdGUzZCgke2lzT3BlbiA/IDAgOiAyMH1weCwwLDApYCxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgLy8gY29uc3QgSWNvbiA9IGljb24gPyBJY29uc1tpY29uXSA6IGRlcHRoID09PSAnY2hpbGQnID8gSWNvbnNbJ01pbnVzJ10gOiBudWxsO1xuICAgIC8vIGNvbnN0IEljb24gPSBpY29uID8gSWNvbnNbaWNvbl0gOiBudWxsO1xuICAgIGNvbnN0IEljb24gPSAoeyBpY29uTmFtZSwgc3R5bGUgfTogeyBpY29uTmFtZTogYW55OyBzdHlsZT86IGFueSB9KSA9PiB7XG4gICAgICBjb25zdCBUYWdOYW1lID0gaWNvbnNbaWNvbk5hbWVdO1xuICAgICAgcmV0dXJuICEhVGFnTmFtZSA/IChcbiAgICAgICAgPFRhZ05hbWUgc3R5bGU9e3N0eWxlfSAvPlxuICAgICAgKSA6IChcbiAgICAgICAgPHA+SW52YWxpZCBpY29uIHtpY29uTmFtZX08L3A+XG4gICAgICApO1xuICAgIH07XG4gICAgcmV0dXJuIChcbiAgICAgIDxGcmFtZSBkZXB0aD17ZGVwdGh9PlxuICAgICAgICA8SGVhZGVyIG9wZW49e2lzT3Blbn0gZGVwdGg9e2RlcHRofSBjbGFzc05hbWU9e2RlcHRofT5cbiAgICAgICAgICB7aWNvbiAmJiAoXG4gICAgICAgICAgICA8SWNvbldyYXBwZXIgZGVwdGg9e2RlcHRofT5cbiAgICAgICAgICAgICAgPEljb24gaWNvbk5hbWU9e2ljb259IC8+XG4gICAgICAgICAgICA8L0ljb25XcmFwcGVyPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPFRpdGxlIG9uQ2xpY2s9e29uQ2xpY2t9PntuYW1lfTwvVGl0bGU+XG5cbiAgICAgICAgICB7ZHJvcGRvd24gPT09IHRydWUgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFpc09wZW4pfVxuICAgICAgICAgICAgICB2YXJpYW50PVwidGV4dFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRvZ2dsZUJ1dHRvblwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxBcnJvd05leHQgd2lkdGg9XCIxNnB4XCIgLz5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvSGVhZGVyPlxuICAgICAgICA8Q29udGVudFxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBvcGFjaXR5LFxuICAgICAgICAgICAgaGVpZ2h0OiBpc09wZW4gJiYgcHJldmlvdXMgPT09IGlzT3BlbiA/ICdhdXRvJyA6IGhlaWdodCxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGFuaW1hdGVkLmRpdiBzdHlsZT17eyB0cmFuc2Zvcm0gfX0gey4uLmJpbmR9IGNoaWxkcmVuPXtjaGlsZHJlbn0gLz5cbiAgICAgICAgPC9Db250ZW50PlxuICAgICAgPC9GcmFtZT5cbiAgICApO1xuICB9XG4pO1xuXG50eXBlIFByb3BzID0ge1xuICBjbGFzc05hbWU/OiBhbnk7XG4gIGRhdGE6IGFueTtcbiAgb25DbGljazogKHNsdWc6IHN0cmluZykgPT4gdm9pZDtcbiAgYWN0aXZlOiBzdHJpbmcgfCBzdHJpbmdbXTtcbn07XG5leHBvcnQgY29uc3QgVHJlZU1lbnU6IFJlYWN0LkZDPFByb3BzPiA9ICh7XG4gIGRhdGEsXG4gIGNsYXNzTmFtZSxcbiAgb25DbGljayxcbiAgYWN0aXZlLFxufSkgPT4ge1xuICBjb25zdCBoYW5kbGVyID0gKGNoaWxkcmVuKSA9PiB7XG4gICAgcmV0dXJuIGNoaWxkcmVuLm1hcCgoc3ViT3B0aW9uKSA9PiB7XG4gICAgICBpZiAoIXN1Yk9wdGlvbi5jaGlsZHJlbikge1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxUcmVlXG4gICAgICAgICAgICBrZXk9e3N1Yk9wdGlvbi50aXRsZX1cbiAgICAgICAgICAgIG5hbWU9e3N1Yk9wdGlvbi50aXRsZX1cbiAgICAgICAgICAgIGljb249e3N1Yk9wdGlvbi5pY29ufVxuICAgICAgICAgICAgZGVwdGg9XCJjaGlsZFwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNsaWNrKHN1Yk9wdGlvbi5zbHVnKX1cbiAgICAgICAgICAgIGRlZmF1bHRPcGVuPXthY3RpdmUgPT09IHN1Yk9wdGlvbi5zbHVnfVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8VHJlZVxuICAgICAgICAgIGtleT17c3ViT3B0aW9uLnRpdGxlfVxuICAgICAgICAgIG5hbWU9e3N1Yk9wdGlvbi50aXRsZX1cbiAgICAgICAgICBpY29uPXtzdWJPcHRpb24uaWNvbn1cbiAgICAgICAgICBkcm9wZG93bj17IXN1Yk9wdGlvbi5jaGlsZHJlbi5sZW5ndGggPyBmYWxzZSA6IHRydWV9XG4gICAgICAgICAgZGVwdGg9XCJwYXJlbnRcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2xpY2soc3ViT3B0aW9uLnNsdWcpfVxuICAgICAgICAgIGRlZmF1bHRPcGVuPXtcbiAgICAgICAgICAgIGFjdGl2ZSA9PT0gc3ViT3B0aW9uLnNsdWcgfHxcbiAgICAgICAgICAgIHN1Yk9wdGlvbi5jaGlsZHJlbi5zb21lKChpdGVtKSA9PiBpdGVtLnNsdWcgPT09IGFjdGl2ZSlcbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICB7aGFuZGxlcihzdWJPcHRpb24uY2hpbGRyZW4pfVxuICAgICAgICA8L1RyZWU+XG4gICAgICApO1xuICAgIH0pO1xuICB9O1xuICByZXR1cm4gPD57aGFuZGxlcihkYXRhKX08Lz47XG59O1xuIiwiaW1wb3J0IHN0eWxlZCwgeyBrZXlmcmFtZXMgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQgeyB0aGVtZUdldCB9IGZyb20gJ0BzdHlsZWQtc3lzdGVtL3RoZW1lLWdldCc7XG5jb25zdCBGYWRlID0ga2V5ZnJhbWVzYFxuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIHRvIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUG9wb3ZlcldyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBAbWVkaWEgKG1pbi13aWR0aDogOTkxcHgpIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLnBvcG92ZXItaGFuZGxlciB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgcGFkZGluZzogMTVweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnBvcG92ZXItY29udGVudCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogYXV0bztcbiAgICBsZWZ0OiBhdXRvO1xuICAgIHJpZ2h0OiBhdXRvO1xuICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gICAgYm94LXNoYWRvdzogbm9uZTtcbiAgICBwYWRkaW5nOiAyNXB4IDM1cHg7XG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICR7dGhlbWVHZXQoJ2NvbG9ycy5ncmF5LjUwMCcsICcjZjFmMWYxJyl9O1xuXG4gICAgJjo6YmVmb3JlIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuICAgIC5jYXRlZ29yeS1kcm9wZG93biB7XG4gICAgICBhbmltYXRpb246ICR7RmFkZX0gMC42cztcbiAgICB9XG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MHB4KSB7XG4gICAgICBwYWRkaW5nOiAyNXB4O1xuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFJlcXVlc3RNZWRpY2luZSA9IHN0eWxlZC5zcGFuYFxuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDUwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1cHgnKX0gLSAxcHgpO1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBTaWRlYmFyV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDQ1cHggMHB4O1xuICBwYWRkaW5nLXRvcDogMzVweDtcbiAgcGFkZGluZy1yaWdodDogMDtcblxuICBAbWVkaWEgKG1heC13aWR0aDogMTE5OXB4KSB7XG4gICAgcGFkZGluZzogNDBweCAwcHg7XG4gICAgcGFkZGluZy1yaWdodDogMDtcbiAgfVxuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgcGFkZGluZzogMDtcbiAgfVxuXG4gIC5zaWRlYmFyLXNjcm9sbGJhciB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1heC1oZWlnaHQ6IGNhbGMoMTAwdmggLSAxMDhweCk7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBDYXRlZ29yeVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xuYDtcblxuZXhwb3J0IGNvbnN0IFRyZWVXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IFBvcG92ZXJIYW5kbGVyID0gc3R5bGVkLmRpdmBcbiAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1cHgnKX0gLSAxcHgpO1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuICA+IGRpdiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICY6Zmlyc3QtY2hpbGQge1xuICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgc3ZnIHtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgfVxuICAgIH1cbiAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBMb2FkaW5nID0gc3R5bGVkLmRpdmBcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTVweCcpfSAtIDFweCk7XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG5gO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XG5pbXBvcnQgeyBGb3JtYXR0ZWRNZXNzYWdlIH0gZnJvbSAncmVhY3QtaW50bCc7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0BhcG9sbG8vY2xpZW50JztcbmltcG9ydCBTdGlja3kgZnJvbSAncmVhY3Qtc3RpY2t5bm9kZSc7XG5pbXBvcnQgeyBTY3JvbGxiYXIgfSBmcm9tICdjb21wb25lbnRzL3Njcm9sbGJhci9zY3JvbGxiYXInO1xuaW1wb3J0IHsgdXNlQXBwU3RhdGUgfSBmcm9tICdjb250ZXh0cy9hcHAvYXBwLnByb3ZpZGVyJztcbmltcG9ydCB7XG4gIFNpZGViYXJNb2JpbGVMb2FkZXIsXG4gIFNpZGViYXJMb2FkZXIsXG59IGZyb20gJ2NvbXBvbmVudHMvcGxhY2Vob2xkZXIvcGxhY2Vob2xkZXInO1xuaW1wb3J0IHtcbiAgQ2F0ZWdvcnlXcmFwcGVyLFxuICBUcmVlV3JhcHBlcixcbiAgUG9wb3ZlcldyYXBwZXIsXG4gIFNpZGViYXJXcmFwcGVyLFxuICBSZXF1ZXN0TWVkaWNpbmUsXG59IGZyb20gJy4vc2lkZWJhci5zdHlsZSc7XG5cbmltcG9ydCB7IFRyZWVNZW51IH0gZnJvbSAnY29tcG9uZW50cy90cmVlLW1lbnUvdHJlZS1tZW51JztcbmltcG9ydCB7IEdFVF9DQVRFR09SSUVTIH0gZnJvbSAnZ3JhcGhxbC9xdWVyeS9jYXRlZ29yeS5xdWVyeSc7XG5cbmltcG9ydCB7IFJFUVVFU1RfTUVESUNJTkVfTUVOVV9JVEVNIH0gZnJvbSAnc2l0ZS1zZXR0aW5ncy9zaXRlLW5hdmlnYXRpb24nO1xuaW1wb3J0IENhdGVnb3J5V2Fsa2VyIGZyb20gJ2NvbXBvbmVudHMvY2F0ZWdvcnktd2Fsa2VyL2NhdGVnb3J5LXdhbGtlcic7XG5cbnR5cGUgU2lkZWJhckNhdGVnb3J5UHJvcHMgPSB7XG4gIGRldmljZVR5cGU6IHtcbiAgICBtb2JpbGU6IHN0cmluZztcbiAgICB0YWJsZXQ6IHN0cmluZztcbiAgICBkZXNrdG9wOiBib29sZWFuO1xuICB9O1xuICB0eXBlOiBzdHJpbmc7XG59O1xuXG5jb25zdCBTaWRlYmFyQ2F0ZWdvcnk6IFJlYWN0LkZDPFNpZGViYXJDYXRlZ29yeVByb3BzPiA9ICh7XG4gIGRldmljZVR5cGU6IHsgbW9iaWxlLCB0YWJsZXQsIGRlc2t0b3AgfSxcbiAgdHlwZSxcbn0pID0+IHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IHsgZGF0YSwgbG9hZGluZyB9ID0gdXNlUXVlcnkoR0VUX0NBVEVHT1JJRVMsIHtcbiAgICB2YXJpYWJsZXM6IHsgdHlwZSB9LFxuICB9KTtcbiAgY29uc3QgeyBwYXRobmFtZSwgcXVlcnkgfSA9IHJvdXRlcjtcbiAgY29uc3Qgc2VsZWN0ZWRRdWVyaWVzID0gcXVlcnkuY2F0ZWdvcnk7XG5cbiAgY29uc3Qgb25DYXRlZ29yeUNsaWNrID0gKHNsdWc6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHsgdHlwZSwgLi4ucmVzdCB9ID0gcXVlcnk7XG4gICAgaWYgKHR5cGUpIHtcbiAgICAgIHJvdXRlci5wdXNoKFxuICAgICAgICB7XG4gICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgcXVlcnk6IHsgLi4ucmVzdCwgY2F0ZWdvcnk6IHNsdWcgfSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHBhdGhuYW1lOiBgLyR7dHlwZX1gLFxuICAgICAgICAgIHF1ZXJ5OiB7IC4uLnJlc3QsIGNhdGVnb3J5OiBzbHVnIH0sXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgIHF1ZXJ5OiB7IC4uLnJlc3QsIGNhdGVnb3J5OiBzbHVnIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IGlzU2lkZWJhclN0aWNreSA9IHVzZUFwcFN0YXRlKCdpc1NpZGViYXJTdGlja3knKTtcblxuICBpZiAoIWRhdGEgfHwgbG9hZGluZykge1xuICAgIGlmIChtb2JpbGUgfHwgdGFibGV0KSB7XG4gICAgICByZXR1cm4gPFNpZGViYXJNb2JpbGVMb2FkZXIgLz47XG4gICAgfVxuICAgIHJldHVybiA8U2lkZWJhckxvYWRlciAvPjtcbiAgfVxuICByZXR1cm4gKFxuICAgIDxDYXRlZ29yeVdyYXBwZXI+XG4gICAgICA8UG9wb3ZlcldyYXBwZXI+XG4gICAgICAgIDxDYXRlZ29yeVdhbGtlcj5cbiAgICAgICAgICB7dHlwZSA9PT0gJ21lZGljaW5lJyAmJiAoXG4gICAgICAgICAgICA8TGluayBocmVmPXtSRVFVRVNUX01FRElDSU5FX01FTlVfSVRFTS5ocmVmfT5cbiAgICAgICAgICAgICAgPFJlcXVlc3RNZWRpY2luZT5cbiAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZVxuICAgICAgICAgICAgICAgICAgaWQ9e1JFUVVFU1RfTUVESUNJTkVfTUVOVV9JVEVNLmlkfVxuICAgICAgICAgICAgICAgICAgZGVmYXVsdE1lc3NhZ2U9e1JFUVVFU1RfTUVESUNJTkVfTUVOVV9JVEVNLmRlZmF1bHRNZXNzYWdlfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvUmVxdWVzdE1lZGljaW5lPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPFRyZWVNZW51XG4gICAgICAgICAgICBkYXRhPXtkYXRhLmNhdGVnb3JpZXN9XG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNhdGVnb3J5Q2xpY2t9XG4gICAgICAgICAgICBhY3RpdmU9e3NlbGVjdGVkUXVlcmllc31cbiAgICAgICAgICAvPlxuICAgICAgICA8L0NhdGVnb3J5V2Fsa2VyPlxuICAgICAgPC9Qb3BvdmVyV3JhcHBlcj5cblxuICAgICAgPFNpZGViYXJXcmFwcGVyIHN0eWxlPXt7IHBhZGRpbmdUb3A6IHR5cGUgPT09ICdtZWRpY2luZScgPyAwIDogNDUgfX0+XG4gICAgICAgIDxTdGlja3kgZW5hYmxlZD17aXNTaWRlYmFyU3RpY2t5fSB0b3A9e3R5cGUgPT09ICdtZWRpY2luZScgPyA4OSA6IDExMH0+XG4gICAgICAgICAge3R5cGUgPT09ICdtZWRpY2luZScgJiYgKFxuICAgICAgICAgICAgPExpbmsgaHJlZj17UkVRVUVTVF9NRURJQ0lORV9NRU5VX0lURU0uaHJlZn0+XG4gICAgICAgICAgICAgIDxSZXF1ZXN0TWVkaWNpbmU+XG4gICAgICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgIGlkPXtSRVFVRVNUX01FRElDSU5FX01FTlVfSVRFTS5pZH1cbiAgICAgICAgICAgICAgICAgIGRlZmF1bHRNZXNzYWdlPXtSRVFVRVNUX01FRElDSU5FX01FTlVfSVRFTS5kZWZhdWx0TWVzc2FnZX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L1JlcXVlc3RNZWRpY2luZT5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPFNjcm9sbGJhciBjbGFzc05hbWU9XCJzaWRlYmFyLXNjcm9sbGJhclwiPlxuICAgICAgICAgICAgPFRyZWVXcmFwcGVyPlxuICAgICAgICAgICAgICA8VHJlZU1lbnVcbiAgICAgICAgICAgICAgICBkYXRhPXtkYXRhLmNhdGVnb3JpZXN9XG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DYXRlZ29yeUNsaWNrfVxuICAgICAgICAgICAgICAgIGFjdGl2ZT17c2VsZWN0ZWRRdWVyaWVzfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9UcmVlV3JhcHBlcj5cbiAgICAgICAgICA8L1Njcm9sbGJhcj5cbiAgICAgICAgPC9TdGlja3k+XG4gICAgICA8L1NpZGViYXJXcmFwcGVyPlxuICAgIDwvQ2F0ZWdvcnlXcmFwcGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU2lkZWJhckNhdGVnb3J5O1xuIiwiZXhwb3J0IGNvbnN0IEhPTUVfUEFHRSA9ICcvJztcbmV4cG9ydCBjb25zdCBHUk9DRVJZX1BBR0UgPSAnL2dyb2NlcnknO1xuZXhwb3J0IGNvbnN0IEdST0NFUllfUEFHRV9UV08gPSAnL2dyb2NlcnktdHdvJztcbmV4cG9ydCBjb25zdCBCQUtFUllfUEFHRSA9ICcvYmFrZXJ5JztcbmV4cG9ydCBjb25zdCBNQUtFVVBfUEFHRSA9ICcvbWFrZXVwJztcbmV4cG9ydCBjb25zdCBDTE9USElOR19QQUdFID0gJy9jbG90aGluZyc7XG5leHBvcnQgY29uc3QgQkFHU19QQUdFID0gJy9iYWdzJztcbmV4cG9ydCBjb25zdCBCT09LX1BBR0UgPSAnL2Jvb2snO1xuZXhwb3J0IGNvbnN0IEZVUk5JVFVSRV9QQUdFID0gJy9mdXJuaXR1cmUnO1xuZXhwb3J0IGNvbnN0IEZVUk5JVFVSRV9QQUdFX1RXTyA9ICcvZnVybml0dXJlLXR3byc7XG5leHBvcnQgY29uc3QgTUVESUNJTkVfUEFHRSA9ICcvbWVkaWNpbmUnO1xuLy8gZXhwb3J0IGNvbnN0IFJFU1RBVVJBTlRfUEFHRSA9ICcvcmVzdGF1cmFudCc7XG5leHBvcnQgY29uc3QgUkVRVUVTVF9NRURJQ0lORV9QQUdFID0gJy9yZXF1ZXN0LW1lZGljaW5lJztcbmV4cG9ydCBjb25zdCBDSEVDS09VVF9QQUdFID0gJy9jaGVja291dCc7XG5leHBvcnQgY29uc3QgQ0hFQ0tPVVRfUEFHRV9UV08gPSAnL2NoZWNrb3V0LWFsdGVybmF0aXZlJztcbmV4cG9ydCBjb25zdCBQUk9GSUxFX1BBR0UgPSAnL3Byb2ZpbGUnO1xuZXhwb3J0IGNvbnN0IFlPVVJfT1JERVJfUEFHRSA9ICcvb3JkZXInO1xuZXhwb3J0IGNvbnN0IE9SREVSX1JFQ0VJVkVEX1BBR0UgPSAnL29yZGVyLXJlY2VpdmVkJztcbmV4cG9ydCBjb25zdCBPRkZFUl9QQUdFID0gJy9vZmZlcic7XG5leHBvcnQgY29uc3QgSEVMUF9QQUdFID0gJy9oZWxwJztcbmV4cG9ydCBjb25zdCBURVJNU19BTkRfU0VSVklDRVNfUEFHRSA9ICcvdGVybXMnO1xuZXhwb3J0IGNvbnN0IFBSSVZBQ1lfUE9MSUNZX1BBR0UgPSAnL3ByaXZhY3knO1xuLy8gTW9iaWxlIERyYXdlciBNZW51c1xuXG5leHBvcnQgY29uc3QgSE9NRV9NRU5VX0lURU0gPSB7XG4gIGlkOiAnbmF2LmhvbWUnLFxuICBkZWZhdWx0TWVzc2FnZTogJ0hvbWUnLFxuICBocmVmOiBIT01FX1BBR0UsXG59O1xuXG5leHBvcnQgY29uc3QgSEVMUF9NRU5VX0lURU0gPSB7XG4gIGlkOiAnbmF2LmhlbHAnLFxuICBkZWZhdWx0TWVzc2FnZTogJ0hlbHAnLFxuICBocmVmOiBIRUxQX1BBR0UsXG59O1xuZXhwb3J0IGNvbnN0IE9GRkVSX01FTlVfSVRFTSA9IHtcbiAgaWQ6ICduYXYub2ZmZXInLFxuICBkZWZhdWx0TWVzc2FnZTogJ09mZmVyJyxcbiAgaHJlZjogT0ZGRVJfUEFHRSxcbn07XG5leHBvcnQgY29uc3QgT1JERVJfTUVOVV9JVEVNID0ge1xuICBpZDogJ25hdi5vcmRlcicsXG4gIGhyZWY6IFlPVVJfT1JERVJfUEFHRSxcbiAgZGVmYXVsdE1lc3NhZ2U6ICdPcmRlcicsXG59O1xuZXhwb3J0IGNvbnN0IFJFUVVFU1RfTUVESUNJTkVfTUVOVV9JVEVNID0ge1xuICBpZDogJ25hdi5yZXF1ZXN0X21lZGljaW5lJyxcbiAgZGVmYXVsdE1lc3NhZ2U6ICdSZXF1ZXN0IE1lZGljaW5lJyxcbiAgaHJlZjogUkVRVUVTVF9NRURJQ0lORV9QQUdFLFxufTtcbmV4cG9ydCBjb25zdCBQUk9GSUxFX01FTlVfSVRFTSA9IHtcbiAgaWQ6ICduYXYucHJvZmlsZScsXG4gIGRlZmF1bHRNZXNzYWdlOiAnUHJvZmlsZScsXG4gIGhyZWY6IFBST0ZJTEVfUEFHRSxcbn07XG5leHBvcnQgY29uc3QgQVVUSE9SSVpFRF9NRU5VX0lURU1TID0gW1xuICBQUk9GSUxFX01FTlVfSVRFTSxcbiAge1xuICAgIGlkOiAnbmF2LmNoZWNrb3V0JyxcbiAgICBkZWZhdWx0TWVzc2FnZTogJ0NoZWNrb3V0JyxcbiAgICBocmVmOiBDSEVDS09VVF9QQUdFLFxuICB9LFxuICB7XG4gICAgaWQ6ICdhbHRlcm5hdGl2ZUNoZWNrb3V0JyxcbiAgICBocmVmOiBDSEVDS09VVF9QQUdFX1RXTyxcbiAgICBkZWZhdWx0TWVzc2FnZTogJ0NoZWNrb3V0IEFsdGVybmF0aXZlJyxcbiAgfSxcbiAgT1JERVJfTUVOVV9JVEVNLFxuICB7XG4gICAgaWQ6ICduYXYub3JkZXJfcmVjZWl2ZWQnLFxuICAgIGhyZWY6IE9SREVSX1JFQ0VJVkVEX1BBR0UsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdPcmRlciBpbnZvaWNlJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnbmF2LnRlcm1zX2FuZF9zZXJ2aWNlcycsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdUZXJtcyBhbmQgU2VydmljZXMnLFxuICAgIGhyZWY6IFRFUk1TX0FORF9TRVJWSUNFU19QQUdFLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYucHJpdmFjeV9wb2xpY3knLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnUHJpdmFjeSBQb2xpY3knLFxuICAgIGhyZWY6IFBSSVZBQ1lfUE9MSUNZX1BBR0UsXG4gIH0sXG5dO1xuLy8gY2F0ZWdvcnkgbWVudSBpdGVtcyBmb3IgaGVhZGVyIG5hdmlnYXRpb25cbmV4cG9ydCBjb25zdCBDQVRFR09SWV9NRU5VX0lURU1TID0gW1xuICB7XG4gICAgaWQ6ICduYXYuZ3JvY2VyeScsXG4gICAgaHJlZjogR1JPQ0VSWV9QQUdFLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnR3JvY2VyeScsXG4gICAgaWNvbjogJ0ZydWl0c1ZlZ2V0YWJsZScsXG4gICAgZHluYW1pYzogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnbmF2Lmdyb2NlcnktdHdvJyxcbiAgICBocmVmOiBHUk9DRVJZX1BBR0VfVFdPLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnR3JvY2VyeSBUd28nLFxuICAgIGljb246ICdGcnVpdHNWZWdldGFibGUnLFxuICAgIGR5bmFtaWM6IGZhbHNlLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYuYmFrZXJ5JyxcbiAgICBocmVmOiBCQUtFUllfUEFHRSxcbiAgICBkZWZhdWx0TWVzc2FnZTogJ0Jha2VyeScsXG4gICAgaWNvbjogJ0Jha2VyeScsXG4gICAgZHluYW1pYzogZmFsc2UsXG4gIH0sXG4gIHtcbiAgICBpZDogJ25hdi5tYWtldXAnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnTWFrZXVwJyxcbiAgICBocmVmOiBNQUtFVVBfUEFHRSxcbiAgICBpY29uOiAnRmFjaWFsQ2FyZScsXG4gICAgZHluYW1pYzogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnbmF2LmJhZ3MnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnQmFncycsXG4gICAgaHJlZjogQkFHU19QQUdFLFxuICAgIGljb246ICdIYW5kYmFnJyxcbiAgICBkeW5hbWljOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYuY2xvdGhpbmcnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnQ2xvdGhpbmcnLFxuICAgIGhyZWY6IENMT1RISU5HX1BBR0UsXG4gICAgaWNvbjogJ0RyZXNzSWNvbicsXG4gICAgZHluYW1pYzogdHJ1ZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnbmF2LmZ1cm5pdHVyZScsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdGdXJuaXR1cmUnLFxuICAgIGhyZWY6IEZVUk5JVFVSRV9QQUdFLFxuICAgIGljb246ICdGdXJuaXR1cmVJY29uJyxcbiAgICBkeW5hbWljOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYuZnVybml0dXJlLXR3bycsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdGdXJuaXR1cmUgVHdvJyxcbiAgICBocmVmOiBGVVJOSVRVUkVfUEFHRV9UV08sXG4gICAgaWNvbjogJ0Z1cm5pdHVyZUljb24nLFxuICAgIGR5bmFtaWM6IGZhbHNlLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYuYm9vaycsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdCb29rJyxcbiAgICBocmVmOiBCT09LX1BBR0UsXG4gICAgaWNvbjogJ0Jvb2tJY29uJyxcbiAgICBkeW5hbWljOiB0cnVlLFxuICB9LFxuICB7XG4gICAgaWQ6ICduYXYubWVkaWNpbmUnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnTWVkaWNpbmUnLFxuICAgIGhyZWY6IE1FRElDSU5FX1BBR0UsXG4gICAgaWNvbjogJ01lZGljaW5lSWNvbicsXG4gICAgZHluYW1pYzogdHJ1ZSxcbiAgfSxcbiAgLy8ge1xuICAvLyAgIGlkOiAnbmF2LmZvb2RzJyxcbiAgLy8gICBkZWZhdWx0TWVzc2FnZTogJ0Zvb2RzJyxcbiAgLy8gICBocmVmOiBSRVNUQVVSQU5UX1BBR0UsXG4gIC8vICAgaWNvbjogJ1Jlc3RhdXJhbnQnLFxuICAvLyB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IE1PQklMRV9EUkFXRVJfTUVOVSA9IFtcbiAgSE9NRV9NRU5VX0lURU0sXG4gIC4uLkFVVEhPUklaRURfTUVOVV9JVEVNUyxcbiAgSEVMUF9NRU5VX0lURU0sXG4gIE9GRkVSX01FTlVfSVRFTSxcbl07XG5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX1NJREVCQVJfVE9QX01FTlUgPSBbT1JERVJfTUVOVV9JVEVNLCBIRUxQX01FTlVfSVRFTV07XG5leHBvcnQgY29uc3QgUFJPRklMRV9TSURFQkFSX0JPVFRPTV9NRU5VID0gW1BST0ZJTEVfTUVOVV9JVEVNXTtcblxuZXhwb3J0IGNvbnN0IExBTkdVQUdFX01FTlUgPSBbXG4gIHtcbiAgICBpZDogJ2FyJyxcbiAgICBkZWZhdWx0TWVzc2FnZTogJ0FyYWJpYycsXG4gICAgaWNvbjogJ1NBRmxhZycsXG4gIH0sXG4gIHtcbiAgICBpZDogJ3poJyxcbiAgICBkZWZhdWx0TWVzc2FnZTogJ0NoaW5lc2UnLFxuICAgIGljb246ICdDTkZsYWcnLFxuICB9LFxuICB7XG4gICAgaWQ6ICdlbicsXG4gICAgZGVmYXVsdE1lc3NhZ2U6ICdFbmdsaXNoJyxcbiAgICBpY29uOiAnVVNGbGFnJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnZGUnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnR2VybWFuJyxcbiAgICBpY29uOiAnREVGbGFnJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnaGUnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnSGVicmV3JyxcbiAgICBpY29uOiAnSUxGbGFnJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnZXMnLFxuICAgIGRlZmF1bHRNZXNzYWdlOiAnU3BhbmlzaCcsXG4gICAgaWNvbjogJ0VTRmxhZycsXG4gIH0sXG5dO1xuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFJlc2l6ZU9ic2VydmVyIGZyb20gXCJyZXNpemUtb2JzZXJ2ZXItcG9seWZpbGxcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVByZXZpb3VzKHZhbHVlKSB7XG4gIGNvbnN0IHJlZiA9IHVzZVJlZigpO1xuICB1c2VFZmZlY3QoKCkgPT4gdm9pZCAocmVmLmN1cnJlbnQgPSB2YWx1ZSksIFt2YWx1ZV0pO1xuICByZXR1cm4gcmVmLmN1cnJlbnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZWFzdXJlKCkge1xuICBjb25zdCByZWYgPSB1c2VSZWYoKTtcbiAgY29uc3QgW2JvdW5kcywgc2V0XSA9IHVzZVN0YXRlPGFueT4oeyBsZWZ0OiAwLCB0b3A6IDAsIHdpZHRoOiAwLCBoZWlnaHQ6IDAgfSk7XG4gIGNvbnN0IFtyb10gPSB1c2VTdGF0ZShcbiAgICAoKSA9PiBuZXcgUmVzaXplT2JzZXJ2ZXIoKFtlbnRyeV0pID0+IHNldChlbnRyeS5jb250ZW50UmVjdCkpXG4gICk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHJlZi5jdXJyZW50KSByby5vYnNlcnZlKHJlZi5jdXJyZW50KTtcbiAgICByZXR1cm4gKCkgPT4gcm8uZGlzY29ubmVjdCgpO1xuICB9LCBbXSk7XG4gIHJldHVybiBbeyByZWYgfSwgYm91bmRzXTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=