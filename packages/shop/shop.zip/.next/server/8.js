exports.ids = [8];
exports.modules = {

/***/ "./src/assets/icons/CartIcon.tsx":
/*!***************************************!*\
  !*** ./src/assets/icons/CartIcon.tsx ***!
  \***************************************/
/*! exports provided: CartIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartIcon", function() { return CartIcon; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/svg */ "./src/components/svg.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\CartIcon.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CartIcon = props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_svg__WEBPACK_IMPORTED_MODULE_1__["Svg"], _objectSpread(_objectSpread({}, props), {}, {
  width: "14.4px",
  height: "12px",
  viewBox: "0 0 14.4 12",
  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
    "data-name": "Group 120",
    transform: "translate(-288 -413.89)",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
      "data-name": "Path 154",
      fill: "currentColor",
      d: "M298.7,418.289l-2.906-4.148a.835.835,0,0,0-.528-.251.607.607,0,0,0-.529.251l-2.905,4.148h-3.17a.609.609,0,0,0-.661.625v.191l1.651,5.84a1.336,1.336,0,0,0,1.255.945h8.588a1.261,1.261,0,0,0,1.254-.945l1.651-5.84v-.191a.609.609,0,0,0-.661-.625Zm-5.419,0,1.984-2.767,1.98,2.767Zm1.984,5.024a1.258,1.258,0,1,1,1.319-1.258,1.3,1.3,0,0,1-1.319,1.258Zm0,0"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 5
  }, undefined)
}), void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 3,
  columnNumber: 3
}, undefined);

/***/ }),

/***/ "./src/assets/icons/PlusMinus.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/PlusMinus.tsx ***!
  \****************************************/
/*! exports provided: Plus, Minus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Plus", function() { return Plus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Minus", function() { return Minus; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\PlusMinus.tsx";
 // SVG plus icon

const Plus = ({
  color = 'currentColor',
  width = '12px',
  height = '12px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 12",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Group_3351",
      "data-name": "Group 3351",
      transform: "translate(-1367 -190)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 520",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1367 195)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 521",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1374 190) rotate(90)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
}; // SVG minus icon

const Minus = ({
  color = 'currentColor',
  width = '12px',
  height = '2px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 2",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
      "data-name": "Rectangle 522",
      width: "12",
      height: "2",
      rx: "1",
      fill: color
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/box.tsx":
/*!********************************!*\
  !*** ./src/components/box.tsx ***!
  \********************************/
/*! exports provided: Box */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Box", function() { return Box; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_1__);


const Box = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "box__Box",
  componentId: "sc-5533u7-0"
})({
  boxSizing: 'border-box',
  minWidth: 0,
  margin: 0
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_1__["compose"])(styled_system__WEBPACK_IMPORTED_MODULE_1__["space"], styled_system__WEBPACK_IMPORTED_MODULE_1__["color"], styled_system__WEBPACK_IMPORTED_MODULE_1__["layout"], styled_system__WEBPACK_IMPORTED_MODULE_1__["flexbox"], styled_system__WEBPACK_IMPORTED_MODULE_1__["position"]));

/***/ }),

/***/ "./src/components/counter/counter.style.tsx":
/*!**************************************************!*\
  !*** ./src/components/counter/counter.style.tsx ***!
  \**************************************************/
/*! exports provided: CounterBox, CounterButton, CounterValue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterBox", function() { return CounterBox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterButton", function() { return CounterButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterValue", function() { return CounterValue; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_2__);



const CounterBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "counterstyle__CounterBox",
  componentId: "sc-8iu0h2-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  backgroundColor: 'primary.regular',
  color: 'white',
  fontSize: 'base',
  fontWeight: 'bold'
}), {
  borderRadius: 200,
  justifyContent: 'space-between',
  alignItems: 'center',
  overflow: 'hidden',
  flexShrink: 0,
  '&:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    horizontal: {
      width: 104,
      height: 36
    },
    vertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse'
    },
    lightHorizontal: {
      width: 104,
      height: 36,
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    lightVertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    altHorizontal: {
      width: 104,
      height: 36,
      borderRadius: '6px'
    },
    altVertical: {
      width: 30,
      height: 90,
      borderRadius: '6px'
    },
    full: {
      width: '100%',
      height: 36,
      borderRadius: '6px'
    }
  }
}));
const CounterButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "counterstyle__CounterButton",
  componentId: "sc-8iu0h2-1"
})({
  border: 'none',
  backgroundColor: 'transparent',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  padding: 10,
  cursor: 'pointer',
  '&:hover, &:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    lightHorizontal: {
      color: 'text.regular'
    },
    lightVertical: {
      color: 'text.regular'
    }
  }
}));
const CounterValue = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "counterstyle__CounterValue",
  componentId: "sc-8iu0h2-2"
})({
  pointerEvents: 'none'
});
CounterValue.displayName = 'CounterValue';
CounterButton.displayName = 'CounterButton';
CounterBox.displayName = 'CounterBox';
CounterBox.defaultProps = {
  variant: 'horizontal'
};

/***/ }),

/***/ "./src/components/counter/counter.tsx":
/*!********************************************!*\
  !*** ./src/components/counter/counter.tsx ***!
  \********************************************/
/*! exports provided: Counter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Counter", function() { return Counter; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! assets/icons/PlusMinus */ "./src/assets/icons/PlusMinus.tsx");
/* harmony import */ var _counter_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./counter.style */ "./src/components/counter/counter.style.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\counter\\counter.tsx";



const Counter = ({
  onDecrement,
  onIncrement,
  value,
  variant,
  className
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterBox"], {
    variant: variant,
    className: className,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onDecrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Minus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterValue"], {
      children: value
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onIncrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Plus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/multi-carousel/multi-carousel.tsx":
/*!**********************************************************!*\
  !*** ./src/components/multi-carousel/multi-carousel.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-multi-carousel */ "react-multi-carousel");
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\multi-carousel\\multi-carousel.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const SingleItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default.a.li.withConfig({
  displayName: "multi-carousel__SingleItem",
  componentId: "sc-1is9f8u-0"
})(["border:1px solid ", ";border-radius:", ";margin-right:20px;padding:0;outline:none;width:70px;height:auto;overflow:hidden;&:last-child{margin-right:0;}&.custom-dot--active{border:2px solid ", ";}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('colors.gray.500', '#f1f1f1'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('radii.base', '6px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_2__["themeGet"])('colors.primary.regular', '#F39C12'));
const responsive = {
  desktop: {
    breakpoint: {
      max: 3000,
      min: 1024
    },
    items: 1
  },
  mobile: {
    breakpoint: {
      max: 464,
      min: 0
    },
    items: 1
  },
  tablet: {
    breakpoint: {
      max: 1024,
      min: 200
    },
    items: 1
  }
};

const CarouselWithCustomDots = (_ref) => {
  let {
    items = [],
    title,
    deviceType: {
      mobile,
      tablet,
      desktop
    }
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["items", "title", "deviceType"]);

  const children = items.slice(0, 6).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: item.url,
    alt: title,
    style: {
      minWidth: 'auto',
      height: 'auto',
      position: 'relative',
      margin: 'auto'
    },
    className: "product-image"
  }, index, false, {
    fileName: _jsxFileName,
    lineNumber: 55,
    columnNumber: 5
  }, undefined));
  const images = items.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: item.url,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      position: 'relative'
    }
  }, index, false, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 5
  }, undefined));

  const CustomDot = ({
    index,
    onClick,
    active
  }) => {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(SingleItem, {
      "data-index": index,
      onClick: () => onClick(),
      className: `custom-dot ${active && 'custom-dot--active'}`,
      children: react__WEBPACK_IMPORTED_MODULE_1___default.a.Children.toArray(images)[index]
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, undefined);
  };

  let deviceType = 'desktop';

  if (mobile) {
    deviceType = 'mobile';
  }

  if (tablet) {
    deviceType = 'tablet';
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_multi_carousel__WEBPACK_IMPORTED_MODULE_3___default.a, _objectSpread(_objectSpread({
    showDots: true,
    ssr: true,
    infinite: true,
    slidesToSlide: 1,
    containerClass: "carousel-with-custom-dots",
    responsive: responsive,
    deviceType: deviceType,
    autoPlay: false,
    arrows: false,
    customDot: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CustomDot, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 18
    }, undefined)
  }, rest), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 102,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (CarouselWithCustomDots);

/***/ }),

/***/ "./src/components/svg.tsx":
/*!********************************!*\
  !*** ./src/components/svg.tsx ***!
  \********************************/
/*! exports provided: Svg */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Svg", function() { return Svg; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./box */ "./src/components/box.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\svg.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Svg = (_ref) => {
  let {
    size = 18
  } = _ref,
      props = _objectWithoutProperties(_ref, ["size"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_box__WEBPACK_IMPORTED_MODULE_1__["Box"], _objectSpread({
    as: "svg",
    xmlns: "http://www.w3.org/2000/svg",
    width: size + '',
    height: size + '',
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 3
  }, undefined);
};

/***/ }),

/***/ "./src/components/truncate/truncate.tsx":
/*!**********************************************!*\
  !*** ./src/components/truncate/truncate.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\truncate\\truncate.tsx";


const ReadMore = ({
  children,
  more,
  less,
  character
}) => {
  const {
    0: expanded,
    1: setExpanded
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);

  const toggleLines = event => {
    event.preventDefault();
    setExpanded(!expanded);
  };

  if (!children) return null;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [children && children.length < character || expanded ? children : children.substring(0, character), children && children.length > character && !expanded && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "#",
          onClick: toggleLines,
          style: {
            color: '#F39C12',
            fontWeight: 700
          },
          children: more
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 11
      }, undefined)]
    }, void 0, true), children && children.length > character && expanded && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "#",
          onClick: toggleLines,
          style: {
            color: '#F39C12',
            fontWeight: 700
          },
          children: less
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 11
      }, undefined)]
    }, void 0, true)]
  }, void 0, true);
};

ReadMore.defaultProps = {
  character: 150,
  more: 'Read more',
  less: 'less'
};
/* harmony default export */ __webpack_exports__["default"] = (ReadMore);

/***/ }),

/***/ "./src/contexts/cart/cart.reducer.tsx":
/*!********************************************!*\
  !*** ./src/contexts/cart/cart.reducer.tsx ***!
  \********************************************/
/*! exports provided: cartItemsTotalPrice, reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartItemsTotalPrice", function() { return cartItemsTotalPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// export const cartItemsTotalPrice = (items, { discountInPercent = 0 } = {}) => {
const cartItemsTotalPrice = (items, coupon = null) => {
  if (items === null || items.length === 0) return 0;
  const itemCost = items.reduce((total, item) => {
    if (item.salePrice) {
      return total + item.salePrice * item.quantity;
    }

    return total + item.price * item.quantity;
  }, 0); // const discountRate = 1 - discountInPercent;

  const discount = coupon ? itemCost * Number(coupon.discountInPercent) / 100 : 0; // itemCost * discountRate * TAX_RATE + shipping;
  // return itemCost * discountRate;

  return itemCost - discount;
}; // cartItems, cartItemToAdd

const addItemToCart = (state, action) => {
  const existingCartItemIndex = state.items.findIndex(item => item.id === action.payload.id);

  if (existingCartItemIndex > -1) {
    const newState = [...state.items];
    newState[existingCartItemIndex].quantity += action.payload.quantity;
    return newState;
  }

  return [...state.items, action.payload];
}; // cartItems, cartItemToRemove


const removeItemFromCart = (state, action) => {
  return state.items.reduce((acc, item) => {
    if (item.id === action.payload.id) {
      const newQuantity = item.quantity - action.payload.quantity;
      return newQuantity > 0 ? [...acc, _objectSpread(_objectSpread({}, item), {}, {
        quantity: newQuantity
      })] : [...acc];
    }

    return [...acc, item];
  }, []);
};

const clearItemFromCart = (state, action) => {
  return state.items.filter(item => item.id !== action.payload.id);
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'REHYDRATE':
      return _objectSpread(_objectSpread({}, state), action.payload);

    case 'TOGGLE_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        isOpen: !state.isOpen
      });

    case 'ADD_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: addItemToCart(state, action)
      });

    case 'REMOVE_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: removeItemFromCart(state, action)
      });

    case 'CLEAR_ITEM_FROM_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: clearItemFromCart(state, action)
      });

    case 'CLEAR_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: []
      });

    case 'APPLY_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: action.payload
      });

    case 'REMOVE_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: null
      });

    case 'TOGGLE_RESTAURANT':
      return _objectSpread(_objectSpread({}, state), {}, {
        isRestaurant: !state.isRestaurant
      });

    default:
      throw new Error(`Unknown action: ${action.type}`);
  }
};

/***/ }),

/***/ "./src/contexts/cart/use-cart.tsx":
/*!****************************************!*\
  !*** ./src/contexts/cart/use-cart.tsx ***!
  \****************************************/
/*! exports provided: CartProvider, useCart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartProvider", function() { return CartProvider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useCart", function() { return useCart; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _cart_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cart.reducer */ "./src/contexts/cart/cart.reducer.tsx");
/* harmony import */ var utils_use_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! utils/use-storage */ "./src/utils/use-storage.ts");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\contexts\\cart\\use-cart.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const CartContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])({});
const INITIAL_STATE = {
  isOpen: false,
  items: [],
  isRestaurant: false,
  coupon: null
};

const useCartActions = (initialCart = INITIAL_STATE) => {
  var _state$items3;

  const {
    0: state,
    1: dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useReducer"])(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["reducer"], initialCart);

  const addItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const removeItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'REMOVE_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const clearItemFromCartHandler = item => {
    dispatch({
      type: 'CLEAR_ITEM_FROM_CART',
      payload: item
    });
  };

  const clearCartHandler = () => {
    dispatch({
      type: 'CLEAR_CART'
    });
  };

  const toggleCartHandler = () => {
    dispatch({
      type: 'TOGGLE_CART'
    });
  };

  const couponHandler = coupon => {
    dispatch({
      type: 'APPLY_COUPON',
      payload: coupon
    });
  };

  const removeCouponHandler = () => {
    dispatch({
      type: 'REMOVE_COUPON'
    });
  };

  const rehydrateLocalState = payload => {
    dispatch({
      type: 'REHYDRATE',
      payload
    });
  };

  const toggleRestaurant = () => {
    dispatch({
      type: 'TOGGLE_RESTAURANT'
    });
  };

  const isInCartHandler = id => {
    var _state$items;

    return (_state$items = state.items) === null || _state$items === void 0 ? void 0 : _state$items.some(item => item.id === id);
  };

  const getItemHandler = id => {
    var _state$items2;

    return (_state$items2 = state.items) === null || _state$items2 === void 0 ? void 0 : _state$items2.find(item => item.id === id);
  };

  const getCartItemsPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items).toFixed(2);

  const getCartItemsTotalPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items, state.coupon).toFixed(2);

  const getDiscount = () => {
    var _state$coupon;

    const total = Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items);
    const discount = state.coupon ? total * Number((_state$coupon = state.coupon) === null || _state$coupon === void 0 ? void 0 : _state$coupon.discountInPercent) / 100 : 0;
    return discount.toFixed(2);
  };

  const getItemsCount = (_state$items3 = state.items) === null || _state$items3 === void 0 ? void 0 : _state$items3.reduce((acc, item) => acc + item.quantity, 0);
  return {
    state,
    getItemsCount,
    rehydrateLocalState,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    getCartItemsPrice,
    couponHandler,
    removeCouponHandler,
    getDiscount,
    toggleRestaurant
  };
};

const CartProvider = ({
  children
}) => {
  var _state$items4;

  const {
    state,
    rehydrateLocalState,
    getItemsCount,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    couponHandler,
    removeCouponHandler,
    getCartItemsPrice,
    getDiscount,
    toggleRestaurant
  } = useCartActions();
  const {
    rehydrated,
    error
  } = Object(utils_use_storage__WEBPACK_IMPORTED_MODULE_3__["useStorage"])(state, rehydrateLocalState);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CartContext.Provider, {
    value: {
      isOpen: state.isOpen,
      items: state.items,
      coupon: state.coupon,
      isRestaurant: state.isRestaurant,
      cartItemsCount: (_state$items4 = state.items) === null || _state$items4 === void 0 ? void 0 : _state$items4.length,
      itemsCount: getItemsCount,
      addItem: addItemHandler,
      removeItem: removeItemHandler,
      removeItemFromCart: clearItemFromCartHandler,
      clearCart: clearCartHandler,
      isInCart: isInCartHandler,
      getItem: getItemHandler,
      toggleCart: toggleCartHandler,
      calculatePrice: getCartItemsTotalPrice,
      calculateSubTotalPrice: getCartItemsPrice,
      applyCoupon: couponHandler,
      removeCoupon: removeCouponHandler,
      calculateDiscount: getDiscount,
      toggleRestaurant
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 108,
    columnNumber: 5
  }, undefined);
};
const useCart = () => Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(CartContext);

/***/ }),

/***/ "./src/features/quick-view/quick-view-mobile.tsx":
/*!*******************************************************!*\
  !*** ./src/features/quick-view/quick-view-mobile.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var _quick_view_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./quick-view.style */ "./src/features/quick-view/quick-view.style.tsx");
/* harmony import */ var assets_icons_CartIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! assets/icons/CartIcon */ "./src/assets/icons/CartIcon.tsx");
/* harmony import */ var utils_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! utils/constant */ "./src/utils/constant.ts");
/* harmony import */ var components_truncate_truncate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/truncate/truncate */ "./src/components/truncate/truncate.tsx");
/* harmony import */ var components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/multi-carousel/multi-carousel */ "./src/components/multi-carousel/multi-carousel.tsx");
/* harmony import */ var contexts_language_language_provider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! contexts/language/language.provider */ "./src/contexts/language/language.provider.tsx");
/* harmony import */ var contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! contexts/cart/use-cart */ "./src/contexts/cart/use-cart.tsx");
/* harmony import */ var components_counter_counter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! components/counter/counter */ "./src/components/counter/counter.tsx");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_12__);


var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\features\\quick-view\\quick-view-mobile.tsx";

 // import { closeModal } from '@redq/reuse-modal';












const QuickViewMobile = ({
  modalProps,
  onModalClose,
  hideModal,
  deviceType
}) => {
  const {
    addItem,
    removeItem,
    isInCart,
    getItem
  } = Object(contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_10__["useCart"])();
  const {
    id,
    type,
    title,
    unit,
    price,
    discountInPercent,
    salePrice,
    description,
    gallery,
    categories
  } = modalProps;
  const {
    isRtl
  } = Object(contexts_language_language_provider__WEBPACK_IMPORTED_MODULE_9__["useLocale"])();

  const handleAddClick = e => {
    e.stopPropagation();
    addItem(modalProps);
  };

  const handleRemoveClick = e => {
    e.stopPropagation();
    removeItem(modalProps);
  };

  function onCategoryClick(slug) {
    next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push({
      pathname: `/${type.toLowerCase()}`,
      query: {
        category: slug
      }
    }).then(() => window.scrollTo(0, 0));
    hideModal();
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["QuickViewWrapper"], {
      className: "quick-view-mobile-wrapper",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductDetailsWrapper"], {
        className: "product-card",
        dir: "ltr",
        children: [!isRtl && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPreview"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
            items: gallery,
            deviceType: deviceType
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 15
          }, undefined), !!discountInPercent && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["DiscountPercent"], {
            children: [discountInPercent, "%"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 95,
            columnNumber: 17
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductInfoWrapper"], {
          dir: isRtl ? 'rtl' : 'ltr',
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductInfo"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductTitlePriceWrapper"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductTitle"], {
                children: title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 101,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductWeight"], {
              children: unit
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 105,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductDescription"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_truncate_truncate__WEBPACK_IMPORTED_MODULE_7__["default"], {
                character: 600,
                children: description
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 107,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 106,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductMeta"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["MetaSingle"], {
                children: categories ? categories.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["MetaItem"], {
                  onClick: () => onCategoryClick(item.slug),
                  children: item.title
                }, item.id, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 25
                }, undefined)) : ''
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 110,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductCartWrapper"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPriceWrapper"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPrice"], {
                  children: [utils_constant__WEBPACK_IMPORTED_MODULE_6__["CURRENCY"], salePrice ? salePrice : price]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 127,
                  columnNumber: 19
                }, undefined), discountInPercent ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["SalePrice"], {
                  children: [utils_constant__WEBPACK_IMPORTED_MODULE_6__["CURRENCY"], price]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 133,
                  columnNumber: 21
                }, undefined) : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 126,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductCartBtn"], {
                children: !isInCart(id) ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_button_button__WEBPACK_IMPORTED_MODULE_3__["Button"], {
                  className: "cart-button",
                  variant: "secondary",
                  borderRadius: 100,
                  onClick: handleAddClick,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_CartIcon__WEBPACK_IMPORTED_MODULE_5__["CartIcon"], {
                    mr: 2
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 148,
                    columnNumber: 23
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ButtonText"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_intl__WEBPACK_IMPORTED_MODULE_12__["FormattedMessage"], {
                      id: "addCartButton",
                      defaultMessage: "Cart"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 150,
                      columnNumber: 25
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 149,
                    columnNumber: 23
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 142,
                  columnNumber: 21
                }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_counter_counter__WEBPACK_IMPORTED_MODULE_11__["Counter"], {
                  value: getItem(id).quantity,
                  onDecrement: handleRemoveClick,
                  onIncrement: handleAddClick
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 157,
                  columnNumber: 21
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 100,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 99,
          columnNumber: 11
        }, undefined), isRtl && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["ProductPreview"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_multi_carousel_multi_carousel__WEBPACK_IMPORTED_MODULE_8__["default"], {
            items: gallery,
            deviceType: deviceType
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 15
          }, undefined), !!discountInPercent && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_quick_view_style__WEBPACK_IMPORTED_MODULE_4__["DiscountPercent"], {
            children: [discountInPercent, "%"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 172,
            columnNumber: 17
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 169,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 89,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ __webpack_exports__["default"] = (QuickViewMobile);

/***/ }),

/***/ "./src/features/quick-view/quick-view.style.tsx":
/*!******************************************************!*\
  !*** ./src/features/quick-view/quick-view.style.tsx ***!
  \******************************************************/
/*! exports provided: ProductDetailsWrapper, ProductPreview, SaleTag, DiscountPercent, ProductInfoWrapper, ProductInfo, ProductTitlePriceWrapper, ProductTitle, ProductPriceWrapper, ProductPrice, SalePrice, ProductWeight, ProductDescription, ProductCartBtn, ButtonText, ProductCartWrapper, ProductMeta, MetaSingle, MetaItem, ModalClose, QuickViewWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsWrapper", function() { return ProductDetailsWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPreview", function() { return ProductPreview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleTag", function() { return SaleTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPercent", function() { return DiscountPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfoWrapper", function() { return ProductInfoWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductInfo", function() { return ProductInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductTitlePriceWrapper", function() { return ProductTitlePriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductTitle", function() { return ProductTitle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPriceWrapper", function() { return ProductPriceWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductPrice", function() { return ProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalePrice", function() { return SalePrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductWeight", function() { return ProductWeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDescription", function() { return ProductDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCartBtn", function() { return ProductCartBtn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonText", function() { return ButtonText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCartWrapper", function() { return ProductCartWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductMeta", function() { return ProductMeta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetaSingle", function() { return MetaSingle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MetaItem", function() { return MetaItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalClose", function() { return ModalClose; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuickViewWrapper", function() { return QuickViewWrapper; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);


const ProductDetailsWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductDetailsWrapper",
  componentId: "d67ysb-0"
})(["background-color:", ";position:relative;display:flex;flex-wrap:wrap;align-items:stretch;min-height:100%;border-radius:", ";overflow:hidden;box-sizing:border-box;@media (max-width:767px){box-shadow:none;}*{box-sizing:border-box;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const ProductPreview = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPreview",
  componentId: "d67ysb-1"
})(["width:50%;max-width:50%;padding:30px 60px;display:flex;align-items:center;justify-content:center;position:relative;@media (max-width:767px){width:100%;max-width:100%;padding:20px 0px;order:0;}img{width:100%;@media (max-width:767px){min-width:auto !important;}}"]);
const SaleTag = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__SaleTag",
  componentId: "d67ysb-2"
})(["font-size:", "px;font-weight:", ";color:", ";background-color:", ";padding:0 10px;line-height:24px;border-radius:", ";display:inline-block;position:absolute;top:40px;right:30px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const DiscountPercent = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__DiscountPercent",
  componentId: "d67ysb-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:24px;background-color:", ";padding-left:10px;padding-right:10px;position:relative;display:inline-block;position:absolute;top:30px;right:30px;border-radius:", ";-webkit-transform:translate3d(0,0,1px);transform:translate3d(0,0,1px);"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.medium', '12px'));
const ProductInfoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductInfoWrapper",
  componentId: "d67ysb-4"
})(["width:50%;max-width:50%;border-left:1px solid ", ";@media (max-width:767px){width:100%;max-width:100%;padding:30px 0 0;order:1;border:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.lightMediumColor', '#f3f3f3'));
const ProductInfo = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductInfo",
  componentId: "d67ysb-5"
})(["padding:50px;@media (max-width:767px){padding:0;}"]);
const ProductTitlePriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductTitlePriceWrapper",
  componentId: "d67ysb-6"
})(["width:100%;display:flex;align-items:flex-start;justify-content:flex-start;margin-bottom:10px;"]);
const ProductTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.h1.withConfig({
  displayName: "quick-viewstyle__ProductTitle",
  componentId: "d67ysb-7"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:1.5;display:flex;@media (max-width:767px){word-break:break-word;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.heading', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.semiBold', '600'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'));
const ProductPriceWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPriceWrapper",
  componentId: "d67ysb-8"
})(["display:flex;align-items:center;flex-shrink:0;margin-left:25px;line-height:31px;@media (max-width:767px){margin-left:15px;}"]);
const ProductPrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductPrice",
  componentId: "d67ysb-9"
})(["font-family:", ";font-size:calc(", "px + 1px);font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const SalePrice = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__SalePrice",
  componentId: "d67ysb-10"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";font-style:italic;padding:0 5px;overflow:hidden;position:relative;margin-left:10px;&:before{content:'';width:100%;height:1px;display:inline-block;background-color:", ";position:absolute;top:50%;left:0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.yellow.hover', '#FBB979'));
const ProductWeight = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductWeight",
  componentId: "d67ysb-11"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const ProductDescription = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.p.withConfig({
  displayName: "quick-viewstyle__ProductDescription",
  componentId: "d67ysb-12"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";line-height:2;margin-top:30px;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.medium', '#424561'));
const ProductCartBtn = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductCartBtn",
  componentId: "d67ysb-13"
})(["margin-top:60px;@media (max-width:767px){margin-top:40px;}.cart-button{font-family:", ";font-size:", "px;font-weight:", ";color:", ";height:36px;border-radius:4rem;.btn-icon{margin-right:5px;}&:hover{color:", ";background-color:", ";border-color:", ";}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__ButtonText",
  componentId: "d67ysb-14"
})([""]);
const ProductCartWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductCartWrapper",
  componentId: "d67ysb-15"
})(["display:flex;flex-direction:column;"]);
const ProductMeta = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__ProductMeta",
  componentId: "d67ysb-16"
})(["margin-top:30px;"]);
const MetaSingle = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__MetaSingle",
  componentId: "d67ysb-17"
})(["display:flex;flex-wrap:wrap;align-items:center;margin-bottom:10px;&:last-child{margin-bottom:0;}"]);
const MetaItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "quick-viewstyle__MetaItem",
  componentId: "d67ysb-18"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin-right:10px;margin-bottom:10px;background-color:", ";padding:0 15px;border-radius:", ";cursor:pointer;height:30px;display:flex;align-items:center;justify-content:center;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'Lato'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.gray.200', '#f7f7f7'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.base', '6px'));
const ModalClose = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "quick-viewstyle__ModalClose",
  componentId: "d67ysb-19"
})(["position:fixed;top:20px;right:15px;padding:10px 15px;z-index:1;cursor:pointer;display:block;color:rgba(0,0,0,0.5);background:transparent;border:0;outline:none;display:inline-block;svg{width:12px;height:12px;}@media (max-width:767px){top:5px;right:0;}"]);
const QuickViewWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "quick-viewstyle__QuickViewWrapper",
  componentId: "d67ysb-20"
})(["width:1020px;max-width:100%;height:100%;&.quick-view-mobile-wrapper{", "{display:flex;flex-direction:row;justify-content:space-between;margin-top:30px;margin-bottom:15px;}", "{font-size:", "px;}", "{font-size:", "px;}", "{margin-top:0px;@media (max-width:767px){margin-top:0px;}}", "{font-size:", "px;}", "{margin-left:0;@media (max-width:767px){margin-left:0;}}}"], ProductCartWrapper, SalePrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), ProductPrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), ProductCartBtn, ProductPrice, Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.lg', '21'), ProductPriceWrapper);

/***/ }),

/***/ "./src/utils/use-storage.ts":
/*!**********************************!*\
  !*** ./src/utils/use-storage.ts ***!
  \**********************************/
/*! exports provided: useStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useStorage", function() { return useStorage; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! localforage */ "localforage");
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(localforage__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const isObjectLiked = value => value.constructor.name === 'Array' || value.constructor.name === 'Object';

const rehydrate = (value, defaultValue) => {
  if (!value) return defaultValue; // if (value === 'false') str = false;
  // if (value === 'true') str = true;
  // if (!isObjectLiked(value)) {
  //   return value;
  // }

  try {
    const parse = JSON.parse(value);
    return parse;
  } catch (err) {
    return defaultValue;
  }
};

const hydrate = value => {
  if (!isObjectLiked(value)) {
    return value;
  }

  return JSON.stringify(value);
};

const createMigration = (opts, data) => {
  return new Promise((resolve, reject) => {
    const key = `${opts.key}-version`;
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(key, (err, version) => {
      if (version !== opts.version) {
        data = opts.migrate(data);
        localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(opts.key, rehydrate(data), err => {
          if (err) return reject(err);
          localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(key, opts.version, err => {
            if (err) return reject(err);
            return resolve(data);
          });
        });
      } else {
        resolve(data);
      }
    });
  });
};

const config = {
  key: '@session',
  version: 1,
  migrate: state => {
    return _objectSpread({}, state);
  }
};
const useStorage = (state, setState) => {
  const {
    0: rehydrated,
    1: setRehydrated
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const {
    0: error,
    1: setError
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function init() {
      await localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(config.key, (err, value) => {
        if (err) {
          setRehydrated(true);
          return setError(err);
        } // Migrate persisted data


        const restoredValue = rehydrate(value);

        if (typeof config.migrate === 'function') {
          createMigration(config, restoredValue).then(data => setState(data)).then(() => setRehydrated(true));
        } else {
          setState(restoredValue);
          setRehydrated(true);
        }
      });
    }

    init();
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    // if (isNil(state) || isEmpty(state)) {
    //   localForage.removeItem(config.key);
    // }
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(config.key, hydrate(state));
  }, [state]);
  return {
    rehydrated,
    error
  };
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL0NhcnRJY29uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1BsdXNNaW51cy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvYm94LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jb3VudGVyL2NvdW50ZXIuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NvdW50ZXIvY291bnRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbXVsdGktY2Fyb3VzZWwvbXVsdGktY2Fyb3VzZWwudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3N2Zy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvdHJ1bmNhdGUvdHJ1bmNhdGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb250ZXh0cy9jYXJ0L2NhcnQucmVkdWNlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRleHRzL2NhcnQvdXNlLWNhcnQudHN4Iiwid2VicGFjazovLy8uL3NyYy9mZWF0dXJlcy9xdWljay12aWV3L3F1aWNrLXZpZXctbW9iaWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvZmVhdHVyZXMvcXVpY2stdmlldy9xdWljay12aWV3LnN0eWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvdXNlLXN0b3JhZ2UudHMiXSwibmFtZXMiOlsiQ2FydEljb24iLCJwcm9wcyIsIlBsdXMiLCJjb2xvciIsIndpZHRoIiwiaGVpZ2h0IiwiTWludXMiLCJCb3giLCJzdHlsZWQiLCJkaXYiLCJib3hTaXppbmciLCJtaW5XaWR0aCIsIm1hcmdpbiIsImNvbXBvc2UiLCJzcGFjZSIsImxheW91dCIsImZsZXhib3giLCJwb3NpdGlvbiIsIkNvdW50ZXJCb3giLCJjc3MiLCJkaXNwbGF5IiwiYmFja2dyb3VuZENvbG9yIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiYm9yZGVyUmFkaXVzIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwib3ZlcmZsb3ciLCJmbGV4U2hyaW5rIiwib3V0bGluZSIsInZhcmlhbnQiLCJ2YXJpYW50cyIsImhvcml6b250YWwiLCJ2ZXJ0aWNhbCIsImZsZXhEaXJlY3Rpb24iLCJsaWdodEhvcml6b250YWwiLCJsaWdodFZlcnRpY2FsIiwiYWx0SG9yaXpvbnRhbCIsImFsdFZlcnRpY2FsIiwiZnVsbCIsIkNvdW50ZXJCdXR0b24iLCJidXR0b24iLCJib3JkZXIiLCJwYWRkaW5nIiwiY3Vyc29yIiwiQ291bnRlclZhbHVlIiwic3BhbiIsInBvaW50ZXJFdmVudHMiLCJkaXNwbGF5TmFtZSIsImRlZmF1bHRQcm9wcyIsIkNvdW50ZXIiLCJvbkRlY3JlbWVudCIsIm9uSW5jcmVtZW50IiwidmFsdWUiLCJjbGFzc05hbWUiLCJTaW5nbGVJdGVtIiwibGkiLCJ0aGVtZUdldCIsInJlc3BvbnNpdmUiLCJkZXNrdG9wIiwiYnJlYWtwb2ludCIsIm1heCIsIm1pbiIsIml0ZW1zIiwibW9iaWxlIiwidGFibGV0IiwiQ2Fyb3VzZWxXaXRoQ3VzdG9tRG90cyIsInRpdGxlIiwiZGV2aWNlVHlwZSIsInJlc3QiLCJjaGlsZHJlbiIsInNsaWNlIiwibWFwIiwiaXRlbSIsImluZGV4IiwidXJsIiwiaW1hZ2VzIiwiQ3VzdG9tRG90Iiwib25DbGljayIsImFjdGl2ZSIsIlJlYWN0IiwiQ2hpbGRyZW4iLCJ0b0FycmF5IiwiU3ZnIiwic2l6ZSIsIlJlYWRNb3JlIiwibW9yZSIsImxlc3MiLCJjaGFyYWN0ZXIiLCJleHBhbmRlZCIsInNldEV4cGFuZGVkIiwidXNlU3RhdGUiLCJ0b2dnbGVMaW5lcyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsZW5ndGgiLCJzdWJzdHJpbmciLCJjYXJ0SXRlbXNUb3RhbFByaWNlIiwiY291cG9uIiwiaXRlbUNvc3QiLCJyZWR1Y2UiLCJ0b3RhbCIsInNhbGVQcmljZSIsInF1YW50aXR5IiwicHJpY2UiLCJkaXNjb3VudCIsIk51bWJlciIsImRpc2NvdW50SW5QZXJjZW50IiwiYWRkSXRlbVRvQ2FydCIsInN0YXRlIiwiYWN0aW9uIiwiZXhpc3RpbmdDYXJ0SXRlbUluZGV4IiwiZmluZEluZGV4IiwiaWQiLCJwYXlsb2FkIiwibmV3U3RhdGUiLCJyZW1vdmVJdGVtRnJvbUNhcnQiLCJhY2MiLCJuZXdRdWFudGl0eSIsImNsZWFySXRlbUZyb21DYXJ0IiwiZmlsdGVyIiwicmVkdWNlciIsInR5cGUiLCJpc09wZW4iLCJpc1Jlc3RhdXJhbnQiLCJFcnJvciIsIkNhcnRDb250ZXh0IiwiY3JlYXRlQ29udGV4dCIsIklOSVRJQUxfU1RBVEUiLCJ1c2VDYXJ0QWN0aW9ucyIsImluaXRpYWxDYXJ0IiwiZGlzcGF0Y2giLCJ1c2VSZWR1Y2VyIiwiYWRkSXRlbUhhbmRsZXIiLCJyZW1vdmVJdGVtSGFuZGxlciIsImNsZWFySXRlbUZyb21DYXJ0SGFuZGxlciIsImNsZWFyQ2FydEhhbmRsZXIiLCJ0b2dnbGVDYXJ0SGFuZGxlciIsImNvdXBvbkhhbmRsZXIiLCJyZW1vdmVDb3Vwb25IYW5kbGVyIiwicmVoeWRyYXRlTG9jYWxTdGF0ZSIsInRvZ2dsZVJlc3RhdXJhbnQiLCJpc0luQ2FydEhhbmRsZXIiLCJzb21lIiwiZ2V0SXRlbUhhbmRsZXIiLCJmaW5kIiwiZ2V0Q2FydEl0ZW1zUHJpY2UiLCJ0b0ZpeGVkIiwiZ2V0Q2FydEl0ZW1zVG90YWxQcmljZSIsImdldERpc2NvdW50IiwiZ2V0SXRlbXNDb3VudCIsIkNhcnRQcm92aWRlciIsInJlaHlkcmF0ZWQiLCJlcnJvciIsInVzZVN0b3JhZ2UiLCJjYXJ0SXRlbXNDb3VudCIsIml0ZW1zQ291bnQiLCJhZGRJdGVtIiwicmVtb3ZlSXRlbSIsImNsZWFyQ2FydCIsImlzSW5DYXJ0IiwiZ2V0SXRlbSIsInRvZ2dsZUNhcnQiLCJjYWxjdWxhdGVQcmljZSIsImNhbGN1bGF0ZVN1YlRvdGFsUHJpY2UiLCJhcHBseUNvdXBvbiIsInJlbW92ZUNvdXBvbiIsImNhbGN1bGF0ZURpc2NvdW50IiwidXNlQ2FydCIsInVzZUNvbnRleHQiLCJRdWlja1ZpZXdNb2JpbGUiLCJtb2RhbFByb3BzIiwib25Nb2RhbENsb3NlIiwiaGlkZU1vZGFsIiwidW5pdCIsImRlc2NyaXB0aW9uIiwiZ2FsbGVyeSIsImNhdGVnb3JpZXMiLCJpc1J0bCIsInVzZUxvY2FsZSIsImhhbmRsZUFkZENsaWNrIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsImhhbmRsZVJlbW92ZUNsaWNrIiwib25DYXRlZ29yeUNsaWNrIiwic2x1ZyIsIlJvdXRlciIsInB1c2giLCJwYXRobmFtZSIsInRvTG93ZXJDYXNlIiwicXVlcnkiLCJjYXRlZ29yeSIsInRoZW4iLCJ3aW5kb3ciLCJzY3JvbGxUbyIsIkNVUlJFTkNZIiwiUHJvZHVjdERldGFpbHNXcmFwcGVyIiwiUHJvZHVjdFByZXZpZXciLCJTYWxlVGFnIiwiRGlzY291bnRQZXJjZW50IiwiUHJvZHVjdEluZm9XcmFwcGVyIiwiUHJvZHVjdEluZm8iLCJQcm9kdWN0VGl0bGVQcmljZVdyYXBwZXIiLCJQcm9kdWN0VGl0bGUiLCJoMSIsIlByb2R1Y3RQcmljZVdyYXBwZXIiLCJQcm9kdWN0UHJpY2UiLCJTYWxlUHJpY2UiLCJQcm9kdWN0V2VpZ2h0IiwiUHJvZHVjdERlc2NyaXB0aW9uIiwicCIsIlByb2R1Y3RDYXJ0QnRuIiwiQnV0dG9uVGV4dCIsIlByb2R1Y3RDYXJ0V3JhcHBlciIsIlByb2R1Y3RNZXRhIiwiTWV0YVNpbmdsZSIsIk1ldGFJdGVtIiwiTW9kYWxDbG9zZSIsIlF1aWNrVmlld1dyYXBwZXIiLCJpc09iamVjdExpa2VkIiwiY29uc3RydWN0b3IiLCJuYW1lIiwicmVoeWRyYXRlIiwiZGVmYXVsdFZhbHVlIiwicGFyc2UiLCJKU09OIiwiZXJyIiwiaHlkcmF0ZSIsInN0cmluZ2lmeSIsImNyZWF0ZU1pZ3JhdGlvbiIsIm9wdHMiLCJkYXRhIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJrZXkiLCJsb2NhbEZvcmFnZSIsInZlcnNpb24iLCJtaWdyYXRlIiwic2V0SXRlbSIsImNvbmZpZyIsInNldFN0YXRlIiwic2V0UmVoeWRyYXRlZCIsInNldEVycm9yIiwidXNlRWZmZWN0IiwiaW5pdCIsInJlc3RvcmVkVmFsdWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNPLE1BQU1BLFFBQVEsR0FBSUMsS0FBRCxpQkFDdEIscUVBQUMsa0RBQUQsa0NBQVNBLEtBQVQ7QUFBZ0IsT0FBSyxFQUFDLFFBQXRCO0FBQStCLFFBQU0sRUFBQyxNQUF0QztBQUE2QyxTQUFPLEVBQUMsYUFBckQ7QUFBQSx5QkFDRTtBQUFHLGlCQUFVLFdBQWI7QUFBeUIsYUFBUyxFQUFDLHlCQUFuQztBQUFBLDJCQUNFO0FBQ0UsbUJBQVUsVUFEWjtBQUVFLFVBQUksRUFBQyxjQUZQO0FBR0UsT0FBQyxFQUFDO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREssQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NDQVA7O0FBQ08sTUFBTUMsSUFBSSxHQUFHLENBQUM7QUFDbkJDLE9BQUssR0FBRyxjQURXO0FBRW5CQyxPQUFLLEdBQUcsTUFGVztBQUduQkMsUUFBTSxHQUFHO0FBSFUsQ0FBRCxLQUlkO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsV0FKVjtBQUFBLDJCQU1FO0FBQ0UsUUFBRSxFQUFDLFlBREw7QUFFRSxtQkFBVSxZQUZaO0FBR0UsZUFBUyxFQUFDLHVCQUhaO0FBQUEsOEJBS0U7QUFDRSxxQkFBVSxlQURaO0FBRUUsYUFBSyxFQUFDLElBRlI7QUFHRSxjQUFNLEVBQUMsR0FIVDtBQUlFLFVBQUUsRUFBQyxHQUpMO0FBS0UsaUJBQVMsRUFBQyxxQkFMWjtBQU1FLFlBQUksRUFBRUY7QUFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBYUU7QUFDRSxxQkFBVSxlQURaO0FBRUUsYUFBSyxFQUFDLElBRlI7QUFHRSxjQUFNLEVBQUMsR0FIVDtBQUlFLFVBQUUsRUFBQyxHQUpMO0FBS0UsaUJBQVMsRUFBQyxnQ0FMWjtBQU1FLFlBQUksRUFBRUE7QUFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQStCRCxDQXBDTSxDLENBc0NQOztBQUNPLE1BQU1HLEtBQUssR0FBRyxDQUFDO0FBQ3BCSCxPQUFLLEdBQUcsY0FEWTtBQUVwQkMsT0FBSyxHQUFHLE1BRlk7QUFHcEJDLFFBQU0sR0FBRztBQUhXLENBQUQsS0FJZjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFVBSlY7QUFBQSwyQkFNRTtBQUNFLG1CQUFVLGVBRFo7QUFFRSxXQUFLLEVBQUMsSUFGUjtBQUdFLFlBQU0sRUFBQyxHQUhUO0FBSUUsUUFBRSxFQUFDLEdBSkw7QUFLRSxVQUFJLEVBQUVGO0FBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdCRCxDQXJCTSxDOzs7Ozs7Ozs7Ozs7QUN6Q1A7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQVNPLE1BQU1JLEdBQUcsR0FBR0Msd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNkO0FBQ0VDLFdBQVMsRUFBRSxZQURiO0FBRUVDLFVBQVEsRUFBRSxDQUZaO0FBR0VDLFFBQU0sRUFBRTtBQUhWLENBRGMsRUFNZEMsNkRBQU8sQ0FBQ0MsbURBQUQsRUFBUVgsbURBQVIsRUFBZVksb0RBQWYsRUFBdUJDLHFEQUF2QixFQUFnQ0Msc0RBQWhDLENBTk8sQ0FBVCxDOzs7Ozs7Ozs7Ozs7QUNWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNPLE1BQU1DLFVBQVUsR0FBR1Ysd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxHQUNyQlUseURBQUcsQ0FBQztBQUNGQyxTQUFPLEVBQUUsTUFEUDtBQUVGQyxpQkFBZSxFQUFFLGlCQUZmO0FBR0ZsQixPQUFLLEVBQUUsT0FITDtBQUlGbUIsVUFBUSxFQUFFLE1BSlI7QUFLRkMsWUFBVSxFQUFFO0FBTFYsQ0FBRCxDQURrQixFQVFyQjtBQUNFQyxjQUFZLEVBQUUsR0FEaEI7QUFFRUMsZ0JBQWMsRUFBRSxlQUZsQjtBQUdFQyxZQUFVLEVBQUUsUUFIZDtBQUlFQyxVQUFRLEVBQUUsUUFKWjtBQUtFQyxZQUFVLEVBQUUsQ0FMZDtBQU1FLGFBQVc7QUFDVEMsV0FBTyxFQUFFO0FBREE7QUFOYixDQVJxQixFQWtCckJDLDZEQUFPLENBQUM7QUFDTkMsVUFBUSxFQUFFO0FBQ1JDLGNBQVUsRUFBRTtBQUNWNUIsV0FBSyxFQUFFLEdBREc7QUFFVkMsWUFBTSxFQUFFO0FBRkUsS0FESjtBQUtSNEIsWUFBUSxFQUFFO0FBQ1I3QixXQUFLLEVBQUUsRUFEQztBQUVSQyxZQUFNLEVBQUUsRUFGQTtBQUdSNkIsbUJBQWEsRUFBRTtBQUhQLEtBTEY7QUFVUkMsbUJBQWUsRUFBRTtBQUNmL0IsV0FBSyxFQUFFLEdBRFE7QUFFZkMsWUFBTSxFQUFFLEVBRk87QUFHZmdCLHFCQUFlLEVBQUUsVUFIRjtBQUlmbEIsV0FBSyxFQUFFO0FBSlEsS0FWVDtBQWdCUmlDLGlCQUFhLEVBQUU7QUFDYmhDLFdBQUssRUFBRSxFQURNO0FBRWJDLFlBQU0sRUFBRSxFQUZLO0FBR2I2QixtQkFBYSxFQUFFLGdCQUhGO0FBSWJiLHFCQUFlLEVBQUUsVUFKSjtBQUtibEIsV0FBSyxFQUFFO0FBTE0sS0FoQlA7QUF1QlJrQyxpQkFBYSxFQUFFO0FBQ2JqQyxXQUFLLEVBQUUsR0FETTtBQUViQyxZQUFNLEVBQUUsRUFGSztBQUdibUIsa0JBQVksRUFBRTtBQUhELEtBdkJQO0FBNEJSYyxlQUFXLEVBQUU7QUFDWGxDLFdBQUssRUFBRSxFQURJO0FBRVhDLFlBQU0sRUFBRSxFQUZHO0FBR1htQixrQkFBWSxFQUFFO0FBSEgsS0E1Qkw7QUFpQ1JlLFFBQUksRUFBRTtBQUNKbkMsV0FBSyxFQUFFLE1BREg7QUFFSkMsWUFBTSxFQUFFLEVBRko7QUFHSm1CLGtCQUFZLEVBQUU7QUFIVjtBQWpDRTtBQURKLENBQUQsQ0FsQmMsQ0FBaEI7QUE2REEsTUFBTWdCLGFBQWEsR0FBR2hDLHdEQUFNLENBQUNpQyxNQUFWO0FBQUE7QUFBQTtBQUFBLEdBQ3hCO0FBQ0VDLFFBQU0sRUFBRSxNQURWO0FBRUVyQixpQkFBZSxFQUFFLGFBRm5CO0FBR0VsQixPQUFLLEVBQUUsT0FIVDtBQUlFaUIsU0FBTyxFQUFFLE1BSlg7QUFLRU0sWUFBVSxFQUFFLFFBTGQ7QUFNRUQsZ0JBQWMsRUFBRSxRQU5sQjtBQU9FcEIsUUFBTSxFQUFFLE1BUFY7QUFRRXNDLFNBQU8sRUFBRSxFQVJYO0FBU0VDLFFBQU0sRUFBRSxTQVRWO0FBVUUsc0JBQW9CO0FBQ2xCZixXQUFPLEVBQUU7QUFEUztBQVZ0QixDQUR3QixFQWV4QkMsNkRBQU8sQ0FBQztBQUNOQyxVQUFRLEVBQUU7QUFDUkksbUJBQWUsRUFBRTtBQUNmaEMsV0FBSyxFQUFFO0FBRFEsS0FEVDtBQUlSaUMsaUJBQWEsRUFBRTtBQUNiakMsV0FBSyxFQUFFO0FBRE07QUFKUDtBQURKLENBQUQsQ0FmaUIsQ0FBbkI7QUEyQkEsTUFBTTBDLFlBQVksR0FBR3JDLHdEQUFNLENBQUNzQyxJQUFWO0FBQUE7QUFBQTtBQUFBLEdBQWU7QUFDdENDLGVBQWEsRUFBRTtBQUR1QixDQUFmLENBQWxCO0FBR1BGLFlBQVksQ0FBQ0csV0FBYixHQUEyQixjQUEzQjtBQUNBUixhQUFhLENBQUNRLFdBQWQsR0FBNEIsZUFBNUI7QUFDQTlCLFVBQVUsQ0FBQzhCLFdBQVgsR0FBeUIsWUFBekI7QUFDQTlCLFVBQVUsQ0FBQytCLFlBQVgsR0FBMEI7QUFDeEJuQixTQUFPLEVBQUU7QUFEZSxDQUExQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakdBO0FBQ0E7QUFDQTtBQVNPLE1BQU1vQixPQUF3QixHQUFHLENBQUM7QUFDdkNDLGFBRHVDO0FBRXZDQyxhQUZ1QztBQUd2Q0MsT0FIdUM7QUFJdkN2QixTQUp1QztBQUt2Q3dCO0FBTHVDLENBQUQsS0FNbEM7QUFDSixzQkFDRSxxRUFBQyx5REFBRDtBQUFZLFdBQU8sRUFBRXhCLE9BQXJCO0FBQThCLGFBQVMsRUFBRXdCLFNBQXpDO0FBQUEsNEJBQ0UscUVBQUMsNERBQUQ7QUFDRSxhQUFPLEVBQUVILFdBRFg7QUFFRSxhQUFPLEVBQUVyQixPQUZYO0FBR0UsZUFBUyxFQUFDLGdCQUhaO0FBQUEsNkJBS0UscUVBQUMsNERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFRRSxxRUFBQywyREFBRDtBQUFBLGdCQUFldUI7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVJGLGVBU0UscUVBQUMsNERBQUQ7QUFDRSxhQUFPLEVBQUVELFdBRFg7QUFFRSxhQUFPLEVBQUV0QixPQUZYO0FBR0UsZUFBUyxFQUFDLGdCQUhaO0FBQUEsNkJBS0UscUVBQUMsMkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFtQkQsQ0ExQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWFA7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNeUIsVUFBVSxHQUFHL0Msd0RBQU0sQ0FBQ2dELEVBQVY7QUFBQTtBQUFBO0FBQUEsMk1BQ01DLHlFQUFRLENBQUMsaUJBQUQsRUFBb0IsU0FBcEIsQ0FEZCxFQUVHQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBRlgsRUFlUUEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQWZoQixDQUFoQjtBQWtCQSxNQUFNQyxVQUFVLEdBQUc7QUFDakJDLFNBQU8sRUFBRTtBQUNQQyxjQUFVLEVBQUU7QUFDVkMsU0FBRyxFQUFFLElBREs7QUFFVkMsU0FBRyxFQUFFO0FBRkssS0FETDtBQUtQQyxTQUFLLEVBQUU7QUFMQSxHQURRO0FBUWpCQyxRQUFNLEVBQUU7QUFDTkosY0FBVSxFQUFFO0FBQ1ZDLFNBQUcsRUFBRSxHQURLO0FBRVZDLFNBQUcsRUFBRTtBQUZLLEtBRE47QUFLTkMsU0FBSyxFQUFFO0FBTEQsR0FSUztBQWVqQkUsUUFBTSxFQUFFO0FBQ05MLGNBQVUsRUFBRTtBQUNWQyxTQUFHLEVBQUUsSUFESztBQUVWQyxTQUFHLEVBQUU7QUFGSyxLQUROO0FBS05DLFNBQUssRUFBRTtBQUxEO0FBZlMsQ0FBbkI7O0FBd0JBLE1BQU1HLHNCQUFzQixHQUFHLFVBS3BCO0FBQUEsTUFMcUI7QUFDOUJILFNBQUssR0FBRyxFQURzQjtBQUU5QkksU0FGOEI7QUFHOUJDLGNBQVUsRUFBRTtBQUFFSixZQUFGO0FBQVVDLFlBQVY7QUFBa0JOO0FBQWxCO0FBSGtCLEdBS3JCO0FBQUEsTUFETlUsSUFDTTs7QUFDVCxRQUFNQyxRQUFRLEdBQUdQLEtBQUssQ0FBQ1EsS0FBTixDQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCQyxHQUFsQixDQUFzQixDQUFDQyxJQUFELEVBQVlDLEtBQVosa0JBQ3JDO0FBQ0UsT0FBRyxFQUFFRCxJQUFJLENBQUNFLEdBRFo7QUFHRSxPQUFHLEVBQUVSLEtBSFA7QUFJRSxTQUFLLEVBQUU7QUFDTHhELGNBQVEsRUFBRSxNQURMO0FBRUxOLFlBQU0sRUFBRSxNQUZIO0FBR0xZLGNBQVEsRUFBRSxVQUhMO0FBSUxMLFlBQU0sRUFBRTtBQUpILEtBSlQ7QUFVRSxhQUFTLEVBQUM7QUFWWixLQUVPOEQsS0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRGUsQ0FBakI7QUFjQSxRQUFNRSxNQUFNLEdBQUdiLEtBQUssQ0FBQ1MsR0FBTixDQUFVLENBQUNDLElBQUQsRUFBWUMsS0FBWixrQkFDdkI7QUFDRSxPQUFHLEVBQUVELElBQUksQ0FBQ0UsR0FEWjtBQUdFLE9BQUcsRUFBRVIsS0FIUDtBQUlFLFNBQUssRUFBRTtBQUFFL0QsV0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFlBQU0sRUFBRSxNQUF6QjtBQUFpQ1ksY0FBUSxFQUFFO0FBQTNDO0FBSlQsS0FFT3lELEtBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURhLENBQWY7O0FBUUEsUUFBTUcsU0FBUyxHQUFHLENBQUM7QUFDakJILFNBRGlCO0FBRWpCSSxXQUZpQjtBQUdqQkM7QUFIaUIsR0FBRCxLQUtWO0FBQ04sd0JBQ0UscUVBQUMsVUFBRDtBQUNFLG9CQUFZTCxLQURkO0FBR0UsYUFBTyxFQUFFLE1BQU1JLE9BQU8sRUFIeEI7QUFJRSxlQUFTLEVBQUcsY0FBYUMsTUFBTSxJQUFJLG9CQUFxQixFQUoxRDtBQUFBLGdCQU1HQyw0Q0FBSyxDQUFDQyxRQUFOLENBQWVDLE9BQWYsQ0FBdUJOLE1BQXZCLEVBQStCRixLQUEvQjtBQU5ILE9BRU9BLEtBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQVVELEdBaEJEOztBQWtCQSxNQUFJTixVQUFVLEdBQUcsU0FBakI7O0FBQ0EsTUFBSUosTUFBSixFQUFZO0FBQ1ZJLGNBQVUsR0FBRyxRQUFiO0FBQ0Q7O0FBQ0QsTUFBSUgsTUFBSixFQUFZO0FBQ1ZHLGNBQVUsR0FBRyxRQUFiO0FBQ0Q7O0FBQ0Qsc0JBQ0UscUVBQUMsMkRBQUQ7QUFDRSxZQUFRLE1BRFY7QUFFRSxPQUFHLE1BRkw7QUFHRSxZQUFRLEVBQUUsSUFIWjtBQUlFLGlCQUFhLEVBQUUsQ0FKakI7QUFLRSxrQkFBYyxFQUFDLDJCQUxqQjtBQU1FLGNBQVUsRUFBRVYsVUFOZDtBQU9FLGNBQVUsRUFBRVUsVUFQZDtBQVFFLFlBQVEsRUFBRSxLQVJaO0FBU0UsVUFBTSxFQUFFLEtBVFY7QUFVRSxhQUFTLGVBQUUscUVBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVmIsS0FXTUMsSUFYTjtBQUFBLGNBYUdDO0FBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBaUJELENBdEVEOztBQXdFZUoscUZBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkhBO0FBRU8sTUFBTWlCLEdBQUcsR0FBRztBQUFBLE1BQUM7QUFBRUMsUUFBSSxHQUFHO0FBQVQsR0FBRDtBQUFBLE1BQWlCbkYsS0FBakI7O0FBQUEsc0JBQ2pCLHFFQUFDLHdDQUFEO0FBQ0UsTUFBRSxFQUFDLEtBREw7QUFFRSxTQUFLLEVBQUMsNEJBRlI7QUFHRSxTQUFLLEVBQUVtRixJQUFJLEdBQUcsRUFIaEI7QUFJRSxVQUFNLEVBQUVBLElBQUksR0FBRyxFQUpqQjtBQUtFLFdBQU8sRUFBQyxXQUxWO0FBTUUsUUFBSSxFQUFDO0FBTlAsS0FPTW5GLEtBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURpQjtBQUFBLENBQVosQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDs7QUFRQSxNQUFNb0YsUUFBUSxHQUFHLENBQUM7QUFBRWYsVUFBRjtBQUFZZ0IsTUFBWjtBQUFrQkMsTUFBbEI7QUFBd0JDO0FBQXhCLENBQUQsS0FBeUM7QUFDeEQsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCQyxzREFBUSxDQUFDLEtBQUQsQ0FBeEM7O0FBRUEsUUFBTUMsV0FBVyxHQUFHQyxLQUFLLElBQUk7QUFDM0JBLFNBQUssQ0FBQ0MsY0FBTjtBQUNBSixlQUFXLENBQUMsQ0FBQ0QsUUFBRixDQUFYO0FBQ0QsR0FIRDs7QUFLQSxNQUFJLENBQUNuQixRQUFMLEVBQWUsT0FBTyxJQUFQO0FBRWYsc0JBQ0U7QUFBQSxlQUNJQSxRQUFRLElBQUlBLFFBQVEsQ0FBQ3lCLE1BQVQsR0FBa0JQLFNBQS9CLElBQTZDQyxRQUE3QyxHQUNHbkIsUUFESCxHQUVHQSxRQUFRLENBQUMwQixTQUFULENBQW1CLENBQW5CLEVBQXNCUixTQUF0QixDQUhOLEVBSUdsQixRQUFRLElBQUlBLFFBQVEsQ0FBQ3lCLE1BQVQsR0FBa0JQLFNBQTlCLElBQTJDLENBQUNDLFFBQTVDLGlCQUNDO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUEsK0JBQ0U7QUFDRSxjQUFJLEVBQUMsR0FEUDtBQUVFLGlCQUFPLEVBQUVHLFdBRlg7QUFHRSxlQUFLLEVBQUU7QUFBRXpGLGlCQUFLLEVBQUUsU0FBVDtBQUFvQm9CLHNCQUFVLEVBQUU7QUFBaEMsV0FIVDtBQUFBLG9CQUtHK0Q7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBLG9CQUxKLEVBa0JHaEIsUUFBUSxJQUFJQSxRQUFRLENBQUN5QixNQUFULEdBQWtCUCxTQUE5QixJQUEyQ0MsUUFBM0MsaUJBQ0M7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQSwrQkFDRTtBQUNFLGNBQUksRUFBQyxHQURQO0FBRUUsaUJBQU8sRUFBRUcsV0FGWDtBQUdFLGVBQUssRUFBRTtBQUFFekYsaUJBQUssRUFBRSxTQUFUO0FBQW9Cb0Isc0JBQVUsRUFBRTtBQUFoQyxXQUhUO0FBQUEsb0JBS0dnRTtBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUEsb0JBbkJKO0FBQUEsa0JBREY7QUFtQ0QsQ0E3Q0Q7O0FBK0NBRixRQUFRLENBQUNwQyxZQUFULEdBQXdCO0FBQ3RCdUMsV0FBUyxFQUFFLEdBRFc7QUFFdEJGLE1BQUksRUFBRSxXQUZnQjtBQUd0QkMsTUFBSSxFQUFFO0FBSGdCLENBQXhCO0FBTWVGLHVFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdEQTtBQUNPLE1BQU1ZLG1CQUFtQixHQUFHLENBQUNsQyxLQUFELEVBQVFtQyxNQUFNLEdBQUcsSUFBakIsS0FBMEI7QUFDM0QsTUFBSW5DLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLENBQUNnQyxNQUFOLEtBQWlCLENBQXZDLEVBQTBDLE9BQU8sQ0FBUDtBQUMxQyxRQUFNSSxRQUFRLEdBQUdwQyxLQUFLLENBQUNxQyxNQUFOLENBQWEsQ0FBQ0MsS0FBRCxFQUFRNUIsSUFBUixLQUFpQjtBQUM3QyxRQUFJQSxJQUFJLENBQUM2QixTQUFULEVBQW9CO0FBQ2xCLGFBQU9ELEtBQUssR0FBRzVCLElBQUksQ0FBQzZCLFNBQUwsR0FBaUI3QixJQUFJLENBQUM4QixRQUFyQztBQUNEOztBQUNELFdBQU9GLEtBQUssR0FBRzVCLElBQUksQ0FBQytCLEtBQUwsR0FBYS9CLElBQUksQ0FBQzhCLFFBQWpDO0FBQ0QsR0FMZ0IsRUFLZCxDQUxjLENBQWpCLENBRjJELENBUTNEOztBQUNBLFFBQU1FLFFBQVEsR0FBR1AsTUFBTSxHQUNsQkMsUUFBUSxHQUFHTyxNQUFNLENBQUNSLE1BQU0sQ0FBQ1MsaUJBQVIsQ0FBbEIsR0FBZ0QsR0FEN0IsR0FFbkIsQ0FGSixDQVQyRCxDQVkzRDtBQUNBOztBQUNBLFNBQU9SLFFBQVEsR0FBR00sUUFBbEI7QUFDRCxDQWZNLEMsQ0FnQlA7O0FBQ0EsTUFBTUcsYUFBYSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUN2QyxRQUFNQyxxQkFBcUIsR0FBR0YsS0FBSyxDQUFDOUMsS0FBTixDQUFZaUQsU0FBWixDQUMzQnZDLElBQUQsSUFBVUEsSUFBSSxDQUFDd0MsRUFBTCxLQUFZSCxNQUFNLENBQUNJLE9BQVAsQ0FBZUQsRUFEVCxDQUE5Qjs7QUFJQSxNQUFJRixxQkFBcUIsR0FBRyxDQUFDLENBQTdCLEVBQWdDO0FBQzlCLFVBQU1JLFFBQVEsR0FBRyxDQUFDLEdBQUdOLEtBQUssQ0FBQzlDLEtBQVYsQ0FBakI7QUFDQW9ELFlBQVEsQ0FBQ0oscUJBQUQsQ0FBUixDQUFnQ1IsUUFBaEMsSUFBNENPLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlWCxRQUEzRDtBQUNBLFdBQU9ZLFFBQVA7QUFDRDs7QUFDRCxTQUFPLENBQUMsR0FBR04sS0FBSyxDQUFDOUMsS0FBVixFQUFpQitDLE1BQU0sQ0FBQ0ksT0FBeEIsQ0FBUDtBQUNELENBWEQsQyxDQWFBOzs7QUFDQSxNQUFNRSxrQkFBa0IsR0FBRyxDQUFDUCxLQUFELEVBQVFDLE1BQVIsS0FBbUI7QUFDNUMsU0FBT0QsS0FBSyxDQUFDOUMsS0FBTixDQUFZcUMsTUFBWixDQUFtQixDQUFDaUIsR0FBRCxFQUFNNUMsSUFBTixLQUFlO0FBQ3ZDLFFBQUlBLElBQUksQ0FBQ3dDLEVBQUwsS0FBWUgsTUFBTSxDQUFDSSxPQUFQLENBQWVELEVBQS9CLEVBQW1DO0FBQ2pDLFlBQU1LLFdBQVcsR0FBRzdDLElBQUksQ0FBQzhCLFFBQUwsR0FBZ0JPLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlWCxRQUFuRDtBQUVBLGFBQU9lLFdBQVcsR0FBRyxDQUFkLEdBQ0gsQ0FBQyxHQUFHRCxHQUFKLGtDQUFjNUMsSUFBZDtBQUFvQjhCLGdCQUFRLEVBQUVlO0FBQTlCLFNBREcsR0FFSCxDQUFDLEdBQUdELEdBQUosQ0FGSjtBQUdEOztBQUNELFdBQU8sQ0FBQyxHQUFHQSxHQUFKLEVBQVM1QyxJQUFULENBQVA7QUFDRCxHQVRNLEVBU0osRUFUSSxDQUFQO0FBVUQsQ0FYRDs7QUFhQSxNQUFNOEMsaUJBQWlCLEdBQUcsQ0FBQ1YsS0FBRCxFQUFRQyxNQUFSLEtBQW1CO0FBQzNDLFNBQU9ELEtBQUssQ0FBQzlDLEtBQU4sQ0FBWXlELE1BQVosQ0FBb0IvQyxJQUFELElBQVVBLElBQUksQ0FBQ3dDLEVBQUwsS0FBWUgsTUFBTSxDQUFDSSxPQUFQLENBQWVELEVBQXhELENBQVA7QUFDRCxDQUZEOztBQUlPLE1BQU1RLE9BQU8sR0FBRyxDQUFDWixLQUFELEVBQVFDLE1BQVIsS0FBbUI7QUFDeEMsVUFBUUEsTUFBTSxDQUFDWSxJQUFmO0FBQ0UsU0FBSyxXQUFMO0FBQ0UsNkNBQVliLEtBQVosR0FBc0JDLE1BQU0sQ0FBQ0ksT0FBN0I7O0FBQ0YsU0FBSyxhQUFMO0FBQ0UsNkNBQVlMLEtBQVo7QUFBbUJjLGNBQU0sRUFBRSxDQUFDZCxLQUFLLENBQUNjO0FBQWxDOztBQUNGLFNBQUssVUFBTDtBQUNFLDZDQUFZZCxLQUFaO0FBQW1COUMsYUFBSyxFQUFFNkMsYUFBYSxDQUFDQyxLQUFELEVBQVFDLE1BQVI7QUFBdkM7O0FBQ0YsU0FBSyxhQUFMO0FBQ0UsNkNBQVlELEtBQVo7QUFBbUI5QyxhQUFLLEVBQUVxRCxrQkFBa0IsQ0FBQ1AsS0FBRCxFQUFRQyxNQUFSO0FBQTVDOztBQUNGLFNBQUssc0JBQUw7QUFDRSw2Q0FBWUQsS0FBWjtBQUFtQjlDLGFBQUssRUFBRXdELGlCQUFpQixDQUFDVixLQUFELEVBQVFDLE1BQVI7QUFBM0M7O0FBQ0YsU0FBSyxZQUFMO0FBQ0UsNkNBQVlELEtBQVo7QUFBbUI5QyxhQUFLLEVBQUU7QUFBMUI7O0FBQ0YsU0FBSyxjQUFMO0FBQ0UsNkNBQVk4QyxLQUFaO0FBQW1CWCxjQUFNLEVBQUVZLE1BQU0sQ0FBQ0k7QUFBbEM7O0FBQ0YsU0FBSyxlQUFMO0FBQ0UsNkNBQVlMLEtBQVo7QUFBbUJYLGNBQU0sRUFBRTtBQUEzQjs7QUFDRixTQUFLLG1CQUFMO0FBQ0UsNkNBQVlXLEtBQVo7QUFBbUJlLG9CQUFZLEVBQUUsQ0FBQ2YsS0FBSyxDQUFDZTtBQUF4Qzs7QUFDRjtBQUNFLFlBQU0sSUFBSUMsS0FBSixDQUFXLG1CQUFrQmYsTUFBTSxDQUFDWSxJQUFLLEVBQXpDLENBQU47QUFwQko7QUFzQkQsQ0F2Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakRQO0FBQ0E7QUFDQTtBQUNBLE1BQU1JLFdBQVcsZ0JBQUdDLDJEQUFhLENBQUMsRUFBRCxDQUFqQztBQUNBLE1BQU1DLGFBQWEsR0FBRztBQUNwQkwsUUFBTSxFQUFFLEtBRFk7QUFFcEI1RCxPQUFLLEVBQUUsRUFGYTtBQUdwQjZELGNBQVksRUFBRSxLQUhNO0FBSXBCMUIsUUFBTSxFQUFFO0FBSlksQ0FBdEI7O0FBT0EsTUFBTStCLGNBQWMsR0FBRyxDQUFDQyxXQUFXLEdBQUdGLGFBQWYsS0FBaUM7QUFBQTs7QUFDdEQsUUFBTTtBQUFBLE9BQUNuQixLQUFEO0FBQUEsT0FBUXNCO0FBQVIsTUFBb0JDLHdEQUFVLENBQUNYLHFEQUFELEVBQVVTLFdBQVYsQ0FBcEM7O0FBRUEsUUFBTUcsY0FBYyxHQUFHLENBQUM1RCxJQUFELEVBQU84QixRQUFRLEdBQUcsQ0FBbEIsS0FBd0I7QUFDN0M0QixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLFVBQVI7QUFBb0JSLGFBQU8sa0NBQU96QyxJQUFQO0FBQWE4QjtBQUFiO0FBQTNCLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBSUEsUUFBTStCLGlCQUFpQixHQUFHLENBQUM3RCxJQUFELEVBQU84QixRQUFRLEdBQUcsQ0FBbEIsS0FBd0I7QUFDaEQ0QixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLGFBQVI7QUFBdUJSLGFBQU8sa0NBQU96QyxJQUFQO0FBQWE4QjtBQUFiO0FBQTlCLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBSUEsUUFBTWdDLHdCQUF3QixHQUFJOUQsSUFBRCxJQUFVO0FBQ3pDMEQsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRSxzQkFBUjtBQUFnQ1IsYUFBTyxFQUFFekM7QUFBekMsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFJQSxRQUFNK0QsZ0JBQWdCLEdBQUcsTUFBTTtBQUM3QkwsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWUsaUJBQWlCLEdBQUcsTUFBTTtBQUM5Qk4sWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWdCLGFBQWEsR0FBSXhDLE1BQUQsSUFBWTtBQUNoQ2lDLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUUsY0FBUjtBQUF3QlIsYUFBTyxFQUFFaEI7QUFBakMsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNeUMsbUJBQW1CLEdBQUcsTUFBTTtBQUNoQ1IsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWtCLG1CQUFtQixHQUFJMUIsT0FBRCxJQUFhO0FBQ3ZDaUIsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRSxXQUFSO0FBQXFCUjtBQUFyQixLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU0yQixnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCVixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFO0FBQVIsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNb0IsZUFBZSxHQUFJN0IsRUFBRCxJQUFRO0FBQUE7O0FBQzlCLDJCQUFPSixLQUFLLENBQUM5QyxLQUFiLGlEQUFPLGFBQWFnRixJQUFiLENBQW1CdEUsSUFBRCxJQUFVQSxJQUFJLENBQUN3QyxFQUFMLEtBQVlBLEVBQXhDLENBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU0rQixjQUFjLEdBQUkvQixFQUFELElBQVE7QUFBQTs7QUFDN0IsNEJBQU9KLEtBQUssQ0FBQzlDLEtBQWIsa0RBQU8sY0FBYWtGLElBQWIsQ0FBbUJ4RSxJQUFELElBQVVBLElBQUksQ0FBQ3dDLEVBQUwsS0FBWUEsRUFBeEMsQ0FBUDtBQUNELEdBRkQ7O0FBR0EsUUFBTWlDLGlCQUFpQixHQUFHLE1BQU1qRCx5RUFBbUIsQ0FBQ1ksS0FBSyxDQUFDOUMsS0FBUCxDQUFuQixDQUFpQ29GLE9BQWpDLENBQXlDLENBQXpDLENBQWhDOztBQUNBLFFBQU1DLHNCQUFzQixHQUFHLE1BQzdCbkQseUVBQW1CLENBQUNZLEtBQUssQ0FBQzlDLEtBQVAsRUFBYzhDLEtBQUssQ0FBQ1gsTUFBcEIsQ0FBbkIsQ0FBK0NpRCxPQUEvQyxDQUF1RCxDQUF2RCxDQURGOztBQUdBLFFBQU1FLFdBQVcsR0FBRyxNQUFNO0FBQUE7O0FBQ3hCLFVBQU1oRCxLQUFLLEdBQUdKLHlFQUFtQixDQUFDWSxLQUFLLENBQUM5QyxLQUFQLENBQWpDO0FBQ0EsVUFBTTBDLFFBQVEsR0FBR0ksS0FBSyxDQUFDWCxNQUFOLEdBQ1pHLEtBQUssR0FBR0ssTUFBTSxrQkFBQ0csS0FBSyxDQUFDWCxNQUFQLGtEQUFDLGNBQWNTLGlCQUFmLENBQWYsR0FBb0QsR0FEdkMsR0FFYixDQUZKO0FBR0EsV0FBT0YsUUFBUSxDQUFDMEMsT0FBVCxDQUFpQixDQUFqQixDQUFQO0FBQ0QsR0FORDs7QUFPQSxRQUFNRyxhQUFhLG9CQUFHekMsS0FBSyxDQUFDOUMsS0FBVCxrREFBRyxjQUFhcUMsTUFBYixDQUNwQixDQUFDaUIsR0FBRCxFQUFNNUMsSUFBTixLQUFlNEMsR0FBRyxHQUFHNUMsSUFBSSxDQUFDOEIsUUFETixFQUVwQixDQUZvQixDQUF0QjtBQUlBLFNBQU87QUFDTE0sU0FESztBQUVMeUMsaUJBRks7QUFHTFYsdUJBSEs7QUFJTFAsa0JBSks7QUFLTEMscUJBTEs7QUFNTEMsNEJBTks7QUFPTEMsb0JBUEs7QUFRTE0sbUJBUks7QUFTTEUsa0JBVEs7QUFVTFAscUJBVks7QUFXTFcsMEJBWEs7QUFZTEYscUJBWks7QUFhTFIsaUJBYks7QUFjTEMsdUJBZEs7QUFlTFUsZUFmSztBQWdCTFI7QUFoQkssR0FBUDtBQWtCRCxDQXhFRDs7QUEwRU8sTUFBTVUsWUFBWSxHQUFHLENBQUM7QUFBRWpGO0FBQUYsQ0FBRCxLQUFrQjtBQUFBOztBQUM1QyxRQUFNO0FBQ0p1QyxTQURJO0FBRUorQix1QkFGSTtBQUdKVSxpQkFISTtBQUlKakIsa0JBSkk7QUFLSkMscUJBTEk7QUFNSkMsNEJBTkk7QUFPSkMsb0JBUEk7QUFRSk0sbUJBUkk7QUFTSkUsa0JBVEk7QUFVSlAscUJBVkk7QUFXSlcsMEJBWEk7QUFZSlYsaUJBWkk7QUFhSkMsdUJBYkk7QUFjSk8scUJBZEk7QUFlSkcsZUFmSTtBQWdCSlI7QUFoQkksTUFpQkZaLGNBQWMsRUFqQmxCO0FBa0JBLFFBQU07QUFBRXVCLGNBQUY7QUFBY0M7QUFBZCxNQUF3QkMsb0VBQVUsQ0FBQzdDLEtBQUQsRUFBUStCLG1CQUFSLENBQXhDO0FBRUEsc0JBQ0UscUVBQUMsV0FBRCxDQUFhLFFBQWI7QUFDRSxTQUFLLEVBQUU7QUFDTGpCLFlBQU0sRUFBRWQsS0FBSyxDQUFDYyxNQURUO0FBRUw1RCxXQUFLLEVBQUU4QyxLQUFLLENBQUM5QyxLQUZSO0FBR0xtQyxZQUFNLEVBQUVXLEtBQUssQ0FBQ1gsTUFIVDtBQUlMMEIsa0JBQVksRUFBRWYsS0FBSyxDQUFDZSxZQUpmO0FBS0wrQixvQkFBYyxtQkFBRTlDLEtBQUssQ0FBQzlDLEtBQVIsa0RBQUUsY0FBYWdDLE1BTHhCO0FBTUw2RCxnQkFBVSxFQUFFTixhQU5QO0FBT0xPLGFBQU8sRUFBRXhCLGNBUEo7QUFRTHlCLGdCQUFVLEVBQUV4QixpQkFSUDtBQVNMbEIsd0JBQWtCLEVBQUVtQix3QkFUZjtBQVVMd0IsZUFBUyxFQUFFdkIsZ0JBVk47QUFXTHdCLGNBQVEsRUFBRWxCLGVBWEw7QUFZTG1CLGFBQU8sRUFBRWpCLGNBWko7QUFhTGtCLGdCQUFVLEVBQUV6QixpQkFiUDtBQWNMMEIsb0JBQWMsRUFBRWYsc0JBZFg7QUFlTGdCLDRCQUFzQixFQUFFbEIsaUJBZm5CO0FBZ0JMbUIsaUJBQVcsRUFBRTNCLGFBaEJSO0FBaUJMNEIsa0JBQVksRUFBRTNCLG1CQWpCVDtBQWtCTDRCLHVCQUFpQixFQUFFbEIsV0FsQmQ7QUFtQkxSO0FBbkJLLEtBRFQ7QUFBQSxjQXVCR3ZFO0FBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTJCRCxDQWhETTtBQWtEQSxNQUFNa0csT0FBTyxHQUFHLE1BQU1DLHdEQUFVLENBQUMzQyxXQUFELENBQWhDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZJUDtDQUVBOztBQUNBO0FBQ0E7QUF1QkE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFTQSxNQUFNNEMsZUFBd0QsR0FBRyxDQUFDO0FBQ2hFQyxZQURnRTtBQUVoRUMsY0FGZ0U7QUFHaEVDLFdBSGdFO0FBSWhFekc7QUFKZ0UsQ0FBRCxLQUszRDtBQUNKLFFBQU07QUFBRXlGLFdBQUY7QUFBV0MsY0FBWDtBQUF1QkUsWUFBdkI7QUFBaUNDO0FBQWpDLE1BQTZDTyx1RUFBTyxFQUExRDtBQUNBLFFBQU07QUFDSnZELE1BREk7QUFFSlMsUUFGSTtBQUdKdkQsU0FISTtBQUlKMkcsUUFKSTtBQUtKdEUsU0FMSTtBQU1KRyxxQkFOSTtBQU9KTCxhQVBJO0FBUUp5RSxlQVJJO0FBU0pDLFdBVEk7QUFVSkM7QUFWSSxNQVdGTixVQVhKO0FBYUEsUUFBTTtBQUFFTztBQUFGLE1BQVlDLHFGQUFTLEVBQTNCOztBQUVBLFFBQU1DLGNBQWMsR0FBSUMsQ0FBRCxJQUFZO0FBQ2pDQSxLQUFDLENBQUNDLGVBQUY7QUFDQXpCLFdBQU8sQ0FBQ2MsVUFBRCxDQUFQO0FBQ0QsR0FIRDs7QUFLQSxRQUFNWSxpQkFBaUIsR0FBSUYsQ0FBRCxJQUFZO0FBQ3BDQSxLQUFDLENBQUNDLGVBQUY7QUFDQXhCLGNBQVUsQ0FBQ2EsVUFBRCxDQUFWO0FBQ0QsR0FIRDs7QUFJQSxXQUFTYSxlQUFULENBQXlCQyxJQUF6QixFQUErQjtBQUM3QkMsc0RBQU0sQ0FBQ0MsSUFBUCxDQUFZO0FBQ1ZDLGNBQVEsRUFBRyxJQUFHbEUsSUFBSSxDQUFDbUUsV0FBTCxFQUFtQixFQUR2QjtBQUVWQyxXQUFLLEVBQUU7QUFBRUMsZ0JBQVEsRUFBRU47QUFBWjtBQUZHLEtBQVosRUFHR08sSUFISCxDQUdRLE1BQU1DLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQixDQUFoQixFQUFtQixDQUFuQixDQUhkO0FBSUFyQixhQUFTO0FBQ1Y7O0FBRUQsc0JBQ0U7QUFBQSwyQkFJRSxxRUFBQyxrRUFBRDtBQUFrQixlQUFTLEVBQUMsMkJBQTVCO0FBQUEsNkJBQ0UscUVBQUMsdUVBQUQ7QUFBdUIsaUJBQVMsRUFBQyxjQUFqQztBQUFnRCxXQUFHLEVBQUMsS0FBcEQ7QUFBQSxtQkFDRyxDQUFDSyxLQUFELGlCQUNDLHFFQUFDLGdFQUFEO0FBQUEsa0NBQ0UscUVBQUMsZ0ZBQUQ7QUFBd0IsaUJBQUssRUFBRUYsT0FBL0I7QUFBd0Msc0JBQVUsRUFBRTVHO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsRUFFRyxDQUFDLENBQUN1QyxpQkFBRixpQkFDQyxxRUFBQyxpRUFBRDtBQUFBLHVCQUFrQkEsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkosZUFTRSxxRUFBQyxvRUFBRDtBQUFvQixhQUFHLEVBQUV1RSxLQUFLLEdBQUcsS0FBSCxHQUFXLEtBQXpDO0FBQUEsaUNBQ0UscUVBQUMsNkRBQUQ7QUFBQSxvQ0FDRSxxRUFBQywwRUFBRDtBQUFBLHFDQUNFLHFFQUFDLDhEQUFEO0FBQUEsMEJBQWUvRztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBS0UscUVBQUMsK0RBQUQ7QUFBQSx3QkFBZ0IyRztBQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUxGLGVBTUUscUVBQUMsb0VBQUQ7QUFBQSxxQ0FDRSxxRUFBQyxvRUFBRDtBQUFVLHlCQUFTLEVBQUUsR0FBckI7QUFBQSwwQkFBMkJDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5GLGVBVUUscUVBQUMsNkRBQUQ7QUFBQSxxQ0FDRSxxRUFBQyw0REFBRDtBQUFBLDBCQUNHRSxVQUFVLEdBQ1BBLFVBQVUsQ0FBQ3pHLEdBQVgsQ0FBZ0JDLElBQUQsaUJBQ2IscUVBQUMsMERBQUQ7QUFDRSx5QkFBTyxFQUFFLE1BQU0rRyxlQUFlLENBQUMvRyxJQUFJLENBQUNnSCxJQUFOLENBRGhDO0FBQUEsNEJBSUdoSCxJQUFJLENBQUNOO0FBSlIsbUJBRU9NLElBQUksQ0FBQ3dDLEVBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixDQURPLEdBU1A7QUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFWRixlQXlCRSxxRUFBQyxvRUFBRDtBQUFBLHNDQUNFLHFFQUFDLHFFQUFEO0FBQUEsd0NBQ0UscUVBQUMsOERBQUQ7QUFBQSw2QkFDR2tGLHVEQURILEVBRUc3RixTQUFTLEdBQUdBLFNBQUgsR0FBZUUsS0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLEVBTUdHLGlCQUFpQixnQkFDaEIscUVBQUMsMkRBQUQ7QUFBQSw2QkFDR3dGLHVEQURILEVBRUczRixLQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFEZ0IsR0FLZCxJQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQWVFLHFFQUFDLGdFQUFEO0FBQUEsMEJBQ0csQ0FBQ3dELFFBQVEsQ0FBQy9DLEVBQUQsQ0FBVCxnQkFDQyxxRUFBQywrREFBRDtBQUNFLDJCQUFTLEVBQUMsYUFEWjtBQUVFLHlCQUFPLEVBQUMsV0FGVjtBQUdFLDhCQUFZLEVBQUUsR0FIaEI7QUFJRSx5QkFBTyxFQUFFbUUsY0FKWDtBQUFBLDBDQU1FLHFFQUFDLDhEQUFEO0FBQVUsc0JBQUUsRUFBRTtBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBTkYsZUFPRSxxRUFBQyw0REFBRDtBQUFBLDJDQUNFLHFFQUFDLDREQUFEO0FBQ0Usd0JBQUUsRUFBQyxlQURMO0FBRUUsb0NBQWMsRUFBQztBQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREQsZ0JBZ0JDLHFFQUFDLG1FQUFEO0FBQ0UsdUJBQUssRUFBRW5CLE9BQU8sQ0FBQ2hELEVBQUQsQ0FBUCxDQUFZVixRQURyQjtBQUVFLDZCQUFXLEVBQUVnRixpQkFGZjtBQUdFLDZCQUFXLEVBQUVIO0FBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURixFQThFR0YsS0FBSyxpQkFDSixxRUFBQyxnRUFBRDtBQUFBLGtDQUNFLHFFQUFDLGdGQUFEO0FBQXdCLGlCQUFLLEVBQUVGLE9BQS9CO0FBQXdDLHNCQUFVLEVBQUU1RztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLEVBRUcsQ0FBQyxDQUFDdUMsaUJBQUYsaUJBQ0MscUVBQUMsaUVBQUQ7QUFBQSx1QkFBa0JBLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkYsbUJBREY7QUFnR0QsQ0F2SUQ7O0FBeUllK0QsOEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDckxBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRU8sTUFBTTBCLHFCQUFxQixHQUFHNUwsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw2T0FDWmdELHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQURJLEVBT2ZBLHlFQUFRLENBQUMsWUFBRCxFQUFlLEtBQWYsQ0FQTyxDQUEzQjtBQXFCQSxNQUFNNEksY0FBYyxHQUFHN0wsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSw0UUFBcEI7QUF5QkEsTUFBTTZMLE9BQU8sR0FBRzlMLHdEQUFNLENBQUNzQyxJQUFWO0FBQUE7QUFBQTtBQUFBLDBMQUNMVyx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FESCxFQUVIQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBRkwsRUFHVEEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBSEMsRUFJRUEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpWLEVBT0RBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixNQUFqQixDQVBQLENBQWI7QUFjQSxNQUFNOEksZUFBZSxHQUFHL0wsd0RBQU0sQ0FBQ3NDLElBQVY7QUFBQTtBQUFBO0FBQUEseVRBQ1hXLHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FERyxFQUViQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGSyxFQUdYQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEcsRUFJakJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQUpTLEVBTU5BLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FORixFQWNUQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsTUFBakIsQ0FkQyxDQUFyQjtBQW1CQSxNQUFNK0ksa0JBQWtCLEdBQUdoTSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLGtKQUdKZ0QseUVBQVEsQ0FBQyx5QkFBRCxFQUE0QixTQUE1QixDQUhKLENBQXhCO0FBY0EsTUFBTWdKLFdBQVcsR0FBR2pNLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEseURBQWpCO0FBUUEsTUFBTWlNLHdCQUF3QixHQUFHbE0sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxxR0FBOUI7QUFRQSxNQUFNa00sWUFBWSxHQUFHbk0sd0RBQU0sQ0FBQ29NLEVBQVY7QUFBQTtBQUFBO0FBQUEsb0pBQ1JuSix5RUFBUSxDQUFDLGVBQUQsRUFBa0IsWUFBbEIsQ0FEQSxFQUVWQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRSxFQUdSQSx5RUFBUSxDQUFDLHNCQUFELEVBQXlCLEtBQXpCLENBSEEsRUFJZEEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixTQUFyQixDQUpNLENBQWxCO0FBYUEsTUFBTW9KLG1CQUFtQixHQUFHck0sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxtSUFBekI7QUFZQSxNQUFNcU0sWUFBWSxHQUFHdE0sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxtRkFDUmdELHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FEQSxFQUVMQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBRkgsRUFHUkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhBLEVBSWRBLHlFQUFRLENBQUMsd0JBQUQsRUFBMkIsU0FBM0IsQ0FKTSxDQUFsQjtBQU9BLE1BQU1zSixTQUFTLEdBQUd2TSx3REFBTSxDQUFDc0MsSUFBVjtBQUFBO0FBQUE7QUFBQSxpUkFDTFcseUVBQVEsQ0FBQyxZQUFELEVBQWUsTUFBZixDQURILEVBRVBBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQUZELEVBR0xBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0FISCxFQUlYQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBSkcsRUFnQkVBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsU0FBeEIsQ0FoQlYsQ0FBZjtBQXVCQSxNQUFNdUosYUFBYSxHQUFHeE0sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSx1RUFDVGdELHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FEQyxFQUVYQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRyxFQUdUQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSEMsRUFJZkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpPLENBQW5CO0FBT0EsTUFBTXdKLGtCQUFrQixHQUFHek0sd0RBQU0sQ0FBQzBNLENBQVY7QUFBQTtBQUFBO0FBQUEscUdBQ2R6Six5RUFBUSxDQUFDLFlBQUQsRUFBZSxNQUFmLENBRE0sRUFFaEJBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FGUSxFQUdkQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSE0sRUFJcEJBLHlFQUFRLENBQUMsb0JBQUQsRUFBdUIsU0FBdkIsQ0FKWSxDQUF4QjtBQVNBLE1BQU0wSixjQUFjLEdBQUczTSx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHNRQVFSZ0QseUVBQVEsQ0FBQyxZQUFELEVBQWUsTUFBZixDQVJBLEVBU1ZBLHlFQUFRLENBQUMsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FURSxFQVVSQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBVkEsRUFXZEEseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQVhNLEVBb0JaQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsU0FBakIsQ0FwQkksRUFxQkRBLHlFQUFRLENBQUMsd0JBQUQsRUFBMkIsU0FBM0IsQ0FyQlAsRUFzQkxBLHlFQUFRLENBQUMsd0JBQUQsRUFBMkIsU0FBM0IsQ0F0QkgsQ0FBcEI7QUEyQkEsTUFBTTJKLFVBQVUsR0FBRzVNLHdEQUFNLENBQUNzQyxJQUFWO0FBQUE7QUFBQTtBQUFBLFFBQWhCO0FBTUEsTUFBTXVLLGtCQUFrQixHQUFHN00sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSwyQ0FBeEI7QUFLQSxNQUFNNk0sV0FBVyxHQUFHOU0sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSx3QkFBakI7QUFJQSxNQUFNOE0sVUFBVSxHQUFHL00sd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSx3R0FBaEI7QUFVQSxNQUFNK00sUUFBUSxHQUFHaE4sd0RBQU0sQ0FBQ3NDLElBQVY7QUFBQTtBQUFBO0FBQUEsc1BBQ0pXLHlFQUFRLENBQUMsWUFBRCxFQUFlLE1BQWYsQ0FESixFQUVOQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGRixFQUdKQSx5RUFBUSxDQUFDLGtCQUFELEVBQXFCLEtBQXJCLENBSEosRUFJVkEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixTQUFyQixDQUpFLEVBT0NBLHlFQUFRLENBQUMsaUJBQUQsRUFBb0IsU0FBcEIsQ0FQVCxFQVNGQSx5RUFBUSxDQUFDLFlBQUQsRUFBZSxLQUFmLENBVE4sQ0FBZDtBQWlCQSxNQUFNZ0ssVUFBVSxHQUFHak4sd0RBQU0sQ0FBQ2lDLE1BQVY7QUFBQTtBQUFBO0FBQUEsa1FBQWhCO0FBd0JBLE1BQU1pTCxnQkFBZ0IsR0FBR2xOLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsb1hBTXZCNE0sa0JBTnVCLEVBY3ZCTixTQWR1QixFQWVWdEoseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQWZFLEVBa0J2QnFKLFlBbEJ1QixFQW1CVnJKLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQW5CRSxFQXNCdkIwSixjQXRCdUIsRUE4QnZCTCxZQTlCdUIsRUErQlZySix5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0EvQkUsRUFrQ3ZCb0osbUJBbEN1QixDQUF0QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwUlA7QUFDQTs7QUFDQSxNQUFNYyxhQUFhLEdBQUl0SyxLQUFELElBQ3BCQSxLQUFLLENBQUN1SyxXQUFOLENBQWtCQyxJQUFsQixLQUEyQixPQUEzQixJQUFzQ3hLLEtBQUssQ0FBQ3VLLFdBQU4sQ0FBa0JDLElBQWxCLEtBQTJCLFFBRG5FOztBQUdBLE1BQU1DLFNBQVMsR0FBRyxDQUFDekssS0FBRCxFQUFhMEssWUFBYixLQUFvQztBQUNwRCxNQUFJLENBQUMxSyxLQUFMLEVBQVksT0FBTzBLLFlBQVAsQ0FEd0MsQ0FFcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFJO0FBQ0YsVUFBTUMsS0FBSyxHQUFHQyxJQUFJLENBQUNELEtBQUwsQ0FBVzNLLEtBQVgsQ0FBZDtBQUNBLFdBQU8ySyxLQUFQO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaLFdBQU9ILFlBQVA7QUFDRDtBQUNGLENBYkQ7O0FBZUEsTUFBTUksT0FBTyxHQUFJOUssS0FBRCxJQUFXO0FBQ3pCLE1BQUksQ0FBQ3NLLGFBQWEsQ0FBQ3RLLEtBQUQsQ0FBbEIsRUFBMkI7QUFDekIsV0FBT0EsS0FBUDtBQUNEOztBQUNELFNBQU80SyxJQUFJLENBQUNHLFNBQUwsQ0FBZS9LLEtBQWYsQ0FBUDtBQUNELENBTEQ7O0FBTUEsTUFBTWdMLGVBQWUsR0FBRyxDQUFDQyxJQUFELEVBQU9DLElBQVAsS0FBZ0I7QUFDdEMsU0FBTyxJQUFJQyxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3RDLFVBQU1DLEdBQUcsR0FBSSxHQUFFTCxJQUFJLENBQUNLLEdBQUksVUFBeEI7QUFDQUMsc0RBQVcsQ0FBQzNFLE9BQVosQ0FBb0IwRSxHQUFwQixFQUF5QixDQUFDVCxHQUFELEVBQU1XLE9BQU4sS0FBa0I7QUFDekMsVUFBSUEsT0FBTyxLQUFLUCxJQUFJLENBQUNPLE9BQXJCLEVBQThCO0FBQzVCTixZQUFJLEdBQUdELElBQUksQ0FBQ1EsT0FBTCxDQUFhUCxJQUFiLENBQVA7QUFDQUssMERBQVcsQ0FBQ0csT0FBWixDQUFvQlQsSUFBSSxDQUFDSyxHQUF6QixFQUE4QmIsU0FBUyxDQUFDUyxJQUFELENBQXZDLEVBQWdETCxHQUFELElBQVM7QUFDdEQsY0FBSUEsR0FBSixFQUFTLE9BQU9RLE1BQU0sQ0FBQ1IsR0FBRCxDQUFiO0FBQ1RVLDREQUFXLENBQUNHLE9BQVosQ0FBb0JKLEdBQXBCLEVBQXlCTCxJQUFJLENBQUNPLE9BQTlCLEVBQXdDWCxHQUFELElBQVM7QUFDOUMsZ0JBQUlBLEdBQUosRUFBUyxPQUFPUSxNQUFNLENBQUNSLEdBQUQsQ0FBYjtBQUNULG1CQUFPTyxPQUFPLENBQUNGLElBQUQsQ0FBZDtBQUNELFdBSEQ7QUFJRCxTQU5EO0FBT0QsT0FURCxNQVNPO0FBQ0xFLGVBQU8sQ0FBQ0YsSUFBRCxDQUFQO0FBQ0Q7QUFDRixLQWJEO0FBY0QsR0FoQk0sQ0FBUDtBQWlCRCxDQWxCRDs7QUFvQkEsTUFBTVMsTUFBTSxHQUFHO0FBQ2JMLEtBQUcsRUFBRSxVQURRO0FBRWJFLFNBQU8sRUFBRSxDQUZJO0FBR2JDLFNBQU8sRUFBR2pJLEtBQUQsSUFBVztBQUNsQiw2QkFBWUEsS0FBWjtBQUNEO0FBTFksQ0FBZjtBQVFPLE1BQU02QyxVQUFVLEdBQUcsQ0FBQzdDLEtBQUQsRUFBUW9JLFFBQVIsS0FBcUI7QUFDN0MsUUFBTTtBQUFBLE9BQUN6RixVQUFEO0FBQUEsT0FBYTBGO0FBQWIsTUFBOEJ2SixzREFBUSxDQUFDLEtBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQzhELEtBQUQ7QUFBQSxPQUFRMEY7QUFBUixNQUFvQnhKLHNEQUFRLENBQUMsSUFBRCxDQUFsQztBQUVBeUoseURBQVMsQ0FBQyxNQUFNO0FBQ2QsbUJBQWVDLElBQWYsR0FBc0I7QUFDcEIsWUFBTVQsa0RBQVcsQ0FBQzNFLE9BQVosQ0FBb0IrRSxNQUFNLENBQUNMLEdBQTNCLEVBQWdDLENBQUNULEdBQUQsRUFBTTdLLEtBQU4sS0FBZ0I7QUFDcEQsWUFBSTZLLEdBQUosRUFBUztBQUNQZ0IsdUJBQWEsQ0FBQyxJQUFELENBQWI7QUFDQSxpQkFBT0MsUUFBUSxDQUFDakIsR0FBRCxDQUFmO0FBQ0QsU0FKbUQsQ0FLcEQ7OztBQUNBLGNBQU1vQixhQUFhLEdBQUd4QixTQUFTLENBQUN6SyxLQUFELENBQS9COztBQUNBLFlBQUksT0FBTzJMLE1BQU0sQ0FBQ0YsT0FBZCxLQUEwQixVQUE5QixFQUEwQztBQUN4Q1QseUJBQWUsQ0FBQ1csTUFBRCxFQUFTTSxhQUFULENBQWYsQ0FDR3RELElBREgsQ0FDU3VDLElBQUQsSUFBVVUsUUFBUSxDQUFDVixJQUFELENBRDFCLEVBRUd2QyxJQUZILENBRVEsTUFBTWtELGFBQWEsQ0FBQyxJQUFELENBRjNCO0FBR0QsU0FKRCxNQUlPO0FBQ0xELGtCQUFRLENBQUNLLGFBQUQsQ0FBUjtBQUNBSix1QkFBYSxDQUFDLElBQUQsQ0FBYjtBQUNEO0FBQ0YsT0FmSyxDQUFOO0FBZ0JEOztBQUNERyxRQUFJO0FBQ0wsR0FwQlEsRUFvQk4sRUFwQk0sQ0FBVDtBQXNCQUQseURBQVMsQ0FBQyxNQUFNO0FBQ2Q7QUFDQTtBQUNBO0FBQ0FSLHNEQUFXLENBQUNHLE9BQVosQ0FBb0JDLE1BQU0sQ0FBQ0wsR0FBM0IsRUFBZ0NSLE9BQU8sQ0FBQ3RILEtBQUQsQ0FBdkM7QUFDRCxHQUxRLEVBS04sQ0FBQ0EsS0FBRCxDQUxNLENBQVQ7QUFPQSxTQUFPO0FBQ0wyQyxjQURLO0FBRUxDO0FBRkssR0FBUDtBQUlELENBckNNLEMiLCJmaWxlIjoiOC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN2ZyB9IGZyb20gJ2NvbXBvbmVudHMvc3ZnJztcbmV4cG9ydCBjb25zdCBDYXJ0SWNvbiA9IChwcm9wcykgPT4gKFxuICA8U3ZnIHsuLi5wcm9wc30gd2lkdGg9JzE0LjRweCcgaGVpZ2h0PScxMnB4JyB2aWV3Qm94PScwIDAgMTQuNCAxMic+XG4gICAgPGcgZGF0YS1uYW1lPSdHcm91cCAxMjAnIHRyYW5zZm9ybT0ndHJhbnNsYXRlKC0yODggLTQxMy44OSknPlxuICAgICAgPHBhdGhcbiAgICAgICAgZGF0YS1uYW1lPSdQYXRoIDE1NCdcbiAgICAgICAgZmlsbD0nY3VycmVudENvbG9yJ1xuICAgICAgICBkPSdNMjk4LjcsNDE4LjI4OWwtMi45MDYtNC4xNDhhLjgzNS44MzUsMCwwLDAtLjUyOC0uMjUxLjYwNy42MDcsMCwwLDAtLjUyOS4yNTFsLTIuOTA1LDQuMTQ4aC0zLjE3YS42MDkuNjA5LDAsMCwwLS42NjEuNjI1di4xOTFsMS42NTEsNS44NGExLjMzNiwxLjMzNiwwLDAsMCwxLjI1NS45NDVoOC41ODhhMS4yNjEsMS4yNjEsMCwwLDAsMS4yNTQtLjk0NWwxLjY1MS01Ljg0di0uMTkxYS42MDkuNjA5LDAsMCwwLS42NjEtLjYyNVptLTUuNDE5LDAsMS45ODQtMi43NjcsMS45OCwyLjc2N1ptMS45ODQsNS4wMjRhMS4yNTgsMS4yNTgsMCwxLDEsMS4zMTktMS4yNTgsMS4zLDEuMywwLDAsMS0xLjMxOSwxLjI1OFptMCwwJ1xuICAgICAgLz5cbiAgICA8L2c+XG4gIDwvU3ZnPlxuKTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG4vLyBTVkcgcGx1cyBpY29uXG5leHBvcnQgY29uc3QgUGx1cyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzEycHgnLFxuICBoZWlnaHQgPSAnMTJweCcsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9XCIwIDAgMTIgMTJcIlxuICAgID5cbiAgICAgIDxnXG4gICAgICAgIGlkPVwiR3JvdXBfMzM1MVwiXG4gICAgICAgIGRhdGEtbmFtZT1cIkdyb3VwIDMzNTFcIlxuICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTEzNjcgLTE5MClcIlxuICAgICAgPlxuICAgICAgICA8cmVjdFxuICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSA1MjBcIlxuICAgICAgICAgIHdpZHRoPVwiMTJcIlxuICAgICAgICAgIGhlaWdodD1cIjJcIlxuICAgICAgICAgIHJ4PVwiMVwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDEzNjcgMTk1KVwiXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDUyMVwiXG4gICAgICAgICAgd2lkdGg9XCIxMlwiXG4gICAgICAgICAgaGVpZ2h0PVwiMlwiXG4gICAgICAgICAgcng9XCIxXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMTM3NCAxOTApIHJvdGF0ZSg5MClcIlxuICAgICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcblxuLy8gU1ZHIG1pbnVzIGljb25cbmV4cG9ydCBjb25zdCBNaW51cyA9ICh7XG4gIGNvbG9yID0gJ2N1cnJlbnRDb2xvcicsXG4gIHdpZHRoID0gJzEycHgnLFxuICBoZWlnaHQgPSAnMnB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD1cIjAgMCAxMiAyXCJcbiAgICA+XG4gICAgICA8cmVjdFxuICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgNTIyXCJcbiAgICAgICAgd2lkdGg9XCIxMlwiXG4gICAgICAgIGhlaWdodD1cIjJcIlxuICAgICAgICByeD1cIjFcIlxuICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cyc7XG5pbXBvcnQge1xuICBjb21wb3NlLFxuICBzcGFjZSxcbiAgY29sb3IsXG4gIGxheW91dCxcbiAgZmxleGJveCxcbiAgcG9zaXRpb24sXG59IGZyb20gJ3N0eWxlZC1zeXN0ZW0nO1xuXG5leHBvcnQgY29uc3QgQm94ID0gc3R5bGVkLmRpdjxhbnk+KFxuICB7XG4gICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgbWluV2lkdGg6IDAsXG4gICAgbWFyZ2luOiAwLFxuICB9LFxuICBjb21wb3NlKHNwYWNlLCBjb2xvciwgbGF5b3V0LCBmbGV4Ym94LCBwb3NpdGlvbilcbik7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCBjc3MgZnJvbSAnQHN0eWxlZC1zeXN0ZW0vY3NzJztcbmltcG9ydCB7IHZhcmlhbnQgfSBmcm9tICdzdHlsZWQtc3lzdGVtJztcbmV4cG9ydCBjb25zdCBDb3VudGVyQm94ID0gc3R5bGVkLmRpdjxhbnk+KFxuICBjc3Moe1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdwcmltYXJ5LnJlZ3VsYXInLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGZvbnRTaXplOiAnYmFzZScsXG4gICAgZm9udFdlaWdodDogJ2JvbGQnLFxuICB9KSxcbiAge1xuICAgIGJvcmRlclJhZGl1czogMjAwLFxuICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgIGZsZXhTaHJpbms6IDAsXG4gICAgJyY6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAnbm9uZScsXG4gICAgfSxcbiAgfSxcbiAgdmFyaWFudCh7XG4gICAgdmFyaWFudHM6IHtcbiAgICAgIGhvcml6b250YWw6IHtcbiAgICAgICAgd2lkdGg6IDEwNCxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgIH0sXG4gICAgICB2ZXJ0aWNhbDoge1xuICAgICAgICB3aWR0aDogMzAsXG4gICAgICAgIGhlaWdodDogOTAsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4tcmV2ZXJzZScsXG4gICAgICB9LFxuICAgICAgbGlnaHRIb3Jpem9udGFsOiB7XG4gICAgICAgIHdpZHRoOiAxMDQsXG4gICAgICAgIGhlaWdodDogMzYsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ2dyYXkuMjAwJyxcbiAgICAgICAgY29sb3I6ICd0ZXh0LmJvbGQnLFxuICAgICAgfSxcbiAgICAgIGxpZ2h0VmVydGljYWw6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uLXJldmVyc2UnLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdncmF5LjIwMCcsXG4gICAgICAgIGNvbG9yOiAndGV4dC5ib2xkJyxcbiAgICAgIH0sXG4gICAgICBhbHRIb3Jpem9udGFsOiB7XG4gICAgICAgIHdpZHRoOiAxMDQsXG4gICAgICAgIGhlaWdodDogMzYsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzZweCcsXG4gICAgICB9LFxuICAgICAgYWx0VmVydGljYWw6IHtcbiAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxuICAgICAgfSxcbiAgICAgIGZ1bGw6IHtcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBDb3VudGVyQnV0dG9uID0gc3R5bGVkLmJ1dHRvbjxhbnk+KFxuICB7XG4gICAgYm9yZGVyOiAnbm9uZScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgcGFkZGluZzogMTAsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgJyY6aG92ZXIsICY6Zm9jdXMnOiB7XG4gICAgICBvdXRsaW5lOiAnbm9uZScsXG4gICAgfSxcbiAgfSxcbiAgdmFyaWFudCh7XG4gICAgdmFyaWFudHM6IHtcbiAgICAgIGxpZ2h0SG9yaXpvbnRhbDoge1xuICAgICAgICBjb2xvcjogJ3RleHQucmVndWxhcicsXG4gICAgICB9LFxuICAgICAgbGlnaHRWZXJ0aWNhbDoge1xuICAgICAgICBjb2xvcjogJ3RleHQucmVndWxhcicsXG4gICAgICB9LFxuICAgIH0sXG4gIH0pXG4pO1xuXG5leHBvcnQgY29uc3QgQ291bnRlclZhbHVlID0gc3R5bGVkLnNwYW4oe1xuICBwb2ludGVyRXZlbnRzOiAnbm9uZScsXG59KTtcbkNvdW50ZXJWYWx1ZS5kaXNwbGF5TmFtZSA9ICdDb3VudGVyVmFsdWUnO1xuQ291bnRlckJ1dHRvbi5kaXNwbGF5TmFtZSA9ICdDb3VudGVyQnV0dG9uJztcbkNvdW50ZXJCb3guZGlzcGxheU5hbWUgPSAnQ291bnRlckJveCc7XG5Db3VudGVyQm94LmRlZmF1bHRQcm9wcyA9IHtcbiAgdmFyaWFudDogJ2hvcml6b250YWwnLFxufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBQbHVzLCBNaW51cyB9IGZyb20gJ2Fzc2V0cy9pY29ucy9QbHVzTWludXMnO1xuaW1wb3J0IHsgQ291bnRlckJveCwgQ291bnRlckJ1dHRvbiwgQ291bnRlclZhbHVlIH0gZnJvbSAnLi9jb3VudGVyLnN0eWxlJztcbmludGVyZmFjZSBQcm9wcyB7XG4gIG9uRGVjcmVtZW50OiAoZTogRXZlbnQpID0+IHZvaWQ7XG4gIG9uSW5jcmVtZW50OiAoZTogRXZlbnQpID0+IHZvaWQ7XG4gIHZhbHVlOiBudW1iZXI7XG4gIHZhcmlhbnQ/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IENvdW50ZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7XG4gIG9uRGVjcmVtZW50LFxuICBvbkluY3JlbWVudCxcbiAgdmFsdWUsXG4gIHZhcmlhbnQsXG4gIGNsYXNzTmFtZSxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q291bnRlckJveCB2YXJpYW50PXt2YXJpYW50fSBjbGFzc05hbWU9e2NsYXNzTmFtZX0+XG4gICAgICA8Q291bnRlckJ1dHRvblxuICAgICAgICBvbkNsaWNrPXtvbkRlY3JlbWVudH1cbiAgICAgICAgdmFyaWFudD17dmFyaWFudH1cbiAgICAgICAgY2xhc3NOYW1lPSdjb250cm9sLWJ1dHRvbidcbiAgICAgID5cbiAgICAgICAgPE1pbnVzIC8+XG4gICAgICA8L0NvdW50ZXJCdXR0b24+XG4gICAgICA8Q291bnRlclZhbHVlPnt2YWx1ZX08L0NvdW50ZXJWYWx1ZT5cbiAgICAgIDxDb3VudGVyQnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9e29uSW5jcmVtZW50fVxuICAgICAgICB2YXJpYW50PXt2YXJpYW50fVxuICAgICAgICBjbGFzc05hbWU9J2NvbnRyb2wtYnV0dG9uJ1xuICAgICAgPlxuICAgICAgICA8UGx1cyAvPlxuICAgICAgPC9Db3VudGVyQnV0dG9uPlxuICAgIDwvQ291bnRlckJveD5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdGhlbWVHZXQgfSBmcm9tICdAc3R5bGVkLXN5c3RlbS90aGVtZS1nZXQnO1xuaW1wb3J0IENhcm91c2VsIGZyb20gJ3JlYWN0LW11bHRpLWNhcm91c2VsJztcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xuXG5jb25zdCBTaW5nbGVJdGVtID0gc3R5bGVkLmxpYFxuICBib3JkZXI6IDFweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMuZ3JheS41MDAnLCAnI2YxZjFmMScpfTtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkuYmFzZScsICc2cHgnKX07XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgcGFkZGluZzogMDtcbiAgb3V0bGluZTogbm9uZTtcbiAgd2lkdGg6IDcwcHg7XG4gIGhlaWdodDogYXV0bztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAmOmxhc3QtY2hpbGQge1xuICAgIG1hcmdpbi1yaWdodDogMDtcbiAgfVxuXG4gICYuY3VzdG9tLWRvdC0tYWN0aXZlIHtcbiAgICBib3JkZXI6IDJweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gIH1cbmA7XG5jb25zdCByZXNwb25zaXZlID0ge1xuICBkZXNrdG9wOiB7XG4gICAgYnJlYWtwb2ludDoge1xuICAgICAgbWF4OiAzMDAwLFxuICAgICAgbWluOiAxMDI0LFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG4gIG1vYmlsZToge1xuICAgIGJyZWFrcG9pbnQ6IHtcbiAgICAgIG1heDogNDY0LFxuICAgICAgbWluOiAwLFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG4gIHRhYmxldDoge1xuICAgIGJyZWFrcG9pbnQ6IHtcbiAgICAgIG1heDogMTAyNCxcbiAgICAgIG1pbjogMjAwLFxuICAgIH0sXG4gICAgaXRlbXM6IDEsXG4gIH0sXG59O1xuXG5jb25zdCBDYXJvdXNlbFdpdGhDdXN0b21Eb3RzID0gKHtcbiAgaXRlbXMgPSBbXSxcbiAgdGl0bGUsXG4gIGRldmljZVR5cGU6IHsgbW9iaWxlLCB0YWJsZXQsIGRlc2t0b3AgfSxcbiAgLi4ucmVzdFxufTogYW55KSA9PiB7XG4gIGNvbnN0IGNoaWxkcmVuID0gaXRlbXMuc2xpY2UoMCwgNikubWFwKChpdGVtOiBhbnksIGluZGV4OiBudW1iZXIpID0+IChcbiAgICA8aW1nXG4gICAgICBzcmM9e2l0ZW0udXJsfVxuICAgICAga2V5PXtpbmRleH1cbiAgICAgIGFsdD17dGl0bGV9XG4gICAgICBzdHlsZT17e1xuICAgICAgICBtaW5XaWR0aDogJ2F1dG8nLFxuICAgICAgICBoZWlnaHQ6ICdhdXRvJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgIG1hcmdpbjogJ2F1dG8nLFxuICAgICAgfX1cbiAgICAgIGNsYXNzTmFtZT1cInByb2R1Y3QtaW1hZ2VcIlxuICAgIC8+XG4gICkpO1xuICBjb25zdCBpbWFnZXMgPSBpdGVtcy5tYXAoKGl0ZW06IGFueSwgaW5kZXg6IG51bWJlcikgPT4gKFxuICAgIDxpbWdcbiAgICAgIHNyYz17aXRlbS51cmx9XG4gICAgICBrZXk9e2luZGV4fVxuICAgICAgYWx0PXt0aXRsZX1cbiAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScsIGhlaWdodDogJzEwMCUnLCBwb3NpdGlvbjogJ3JlbGF0aXZlJyB9fVxuICAgIC8+XG4gICkpO1xuICBjb25zdCBDdXN0b21Eb3QgPSAoe1xuICAgIGluZGV4LFxuICAgIG9uQ2xpY2ssXG4gICAgYWN0aXZlLFxuICB9OiAvLyBjYXJvdXNlbFN0YXRlOiB7IGN1cnJlbnRTbGlkZSwgZGV2aWNlVHlwZSB9LFxuICBhbnkpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgPFNpbmdsZUl0ZW1cbiAgICAgICAgZGF0YS1pbmRleD17aW5kZXh9XG4gICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2xpY2soKX1cbiAgICAgICAgY2xhc3NOYW1lPXtgY3VzdG9tLWRvdCAke2FjdGl2ZSAmJiAnY3VzdG9tLWRvdC0tYWN0aXZlJ31gfVxuICAgICAgPlxuICAgICAgICB7UmVhY3QuQ2hpbGRyZW4udG9BcnJheShpbWFnZXMpW2luZGV4XX1cbiAgICAgIDwvU2luZ2xlSXRlbT5cbiAgICApO1xuICB9O1xuXG4gIGxldCBkZXZpY2VUeXBlID0gJ2Rlc2t0b3AnO1xuICBpZiAobW9iaWxlKSB7XG4gICAgZGV2aWNlVHlwZSA9ICdtb2JpbGUnO1xuICB9XG4gIGlmICh0YWJsZXQpIHtcbiAgICBkZXZpY2VUeXBlID0gJ3RhYmxldCc7XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8Q2Fyb3VzZWxcbiAgICAgIHNob3dEb3RzXG4gICAgICBzc3JcbiAgICAgIGluZmluaXRlPXt0cnVlfVxuICAgICAgc2xpZGVzVG9TbGlkZT17MX1cbiAgICAgIGNvbnRhaW5lckNsYXNzPVwiY2Fyb3VzZWwtd2l0aC1jdXN0b20tZG90c1wiXG4gICAgICByZXNwb25zaXZlPXtyZXNwb25zaXZlfVxuICAgICAgZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX1cbiAgICAgIGF1dG9QbGF5PXtmYWxzZX1cbiAgICAgIGFycm93cz17ZmFsc2V9XG4gICAgICBjdXN0b21Eb3Q9ezxDdXN0b21Eb3QgLz59XG4gICAgICB7Li4ucmVzdH1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9DYXJvdXNlbD5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENhcm91c2VsV2l0aEN1c3RvbURvdHM7XG4iLCJpbXBvcnQgeyBCb3ggfSBmcm9tICcuL2JveCc7XG5cbmV4cG9ydCBjb25zdCBTdmcgPSAoeyBzaXplID0gMTgsIC4uLnByb3BzIH0pID0+IChcbiAgPEJveFxuICAgIGFzPVwic3ZnXCJcbiAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICB3aWR0aD17c2l6ZSArICcnfVxuICAgIGhlaWdodD17c2l6ZSArICcnfVxuICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuICAgIHsuLi5wcm9wc31cbiAgLz5cbik7XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbnR5cGUgUmVhZE1vcmVQcm9wcyA9IHtcbiAgbW9yZT86IHN0cmluZztcbiAgbGVzcz86IHN0cmluZztcbiAgY2hhcmFjdGVyPzogbnVtYmVyO1xufTtcblxuY29uc3QgUmVhZE1vcmUgPSAoeyBjaGlsZHJlbiwgbW9yZSwgbGVzcywgY2hhcmFjdGVyIH0pID0+IHtcbiAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgdG9nZ2xlTGluZXMgPSBldmVudCA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFeHBhbmRlZCghZXhwYW5kZWQpO1xuICB9O1xuXG4gIGlmICghY2hpbGRyZW4pIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsoY2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoIDwgY2hhcmFjdGVyKSB8fCBleHBhbmRlZFxuICAgICAgICA/IGNoaWxkcmVuXG4gICAgICAgIDogY2hpbGRyZW4uc3Vic3RyaW5nKDAsIGNoYXJhY3Rlcil9XG4gICAgICB7Y2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID4gY2hhcmFjdGVyICYmICFleHBhbmRlZCAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPVwiI1wiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUxpbmVzfVxuICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogJyNGMzlDMTInLCBmb250V2VpZ2h0OiA3MDAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge21vcmV9XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgICB7Y2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID4gY2hhcmFjdGVyICYmIGV4cGFuZGVkICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9XCIjXCJcbiAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlTGluZXN9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiAnI0YzOUMxMicsIGZvbnRXZWlnaHQ6IDcwMCB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bGVzc31cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn07XG5cblJlYWRNb3JlLmRlZmF1bHRQcm9wcyA9IHtcbiAgY2hhcmFjdGVyOiAxNTAsXG4gIG1vcmU6ICdSZWFkIG1vcmUnLFxuICBsZXNzOiAnbGVzcycsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBSZWFkTW9yZTtcbiIsIi8vIGV4cG9ydCBjb25zdCBjYXJ0SXRlbXNUb3RhbFByaWNlID0gKGl0ZW1zLCB7IGRpc2NvdW50SW5QZXJjZW50ID0gMCB9ID0ge30pID0+IHtcbmV4cG9ydCBjb25zdCBjYXJ0SXRlbXNUb3RhbFByaWNlID0gKGl0ZW1zLCBjb3Vwb24gPSBudWxsKSA9PiB7XG4gIGlmIChpdGVtcyA9PT0gbnVsbCB8fCBpdGVtcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICBjb25zdCBpdGVtQ29zdCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHtcbiAgICBpZiAoaXRlbS5zYWxlUHJpY2UpIHtcbiAgICAgIHJldHVybiB0b3RhbCArIGl0ZW0uc2FsZVByaWNlICogaXRlbS5xdWFudGl0eTtcbiAgICB9XG4gICAgcmV0dXJuIHRvdGFsICsgaXRlbS5wcmljZSAqIGl0ZW0ucXVhbnRpdHk7XG4gIH0sIDApO1xuICAvLyBjb25zdCBkaXNjb3VudFJhdGUgPSAxIC0gZGlzY291bnRJblBlcmNlbnQ7XG4gIGNvbnN0IGRpc2NvdW50ID0gY291cG9uXG4gICAgPyAoaXRlbUNvc3QgKiBOdW1iZXIoY291cG9uLmRpc2NvdW50SW5QZXJjZW50KSkgLyAxMDBcbiAgICA6IDA7XG4gIC8vIGl0ZW1Db3N0ICogZGlzY291bnRSYXRlICogVEFYX1JBVEUgKyBzaGlwcGluZztcbiAgLy8gcmV0dXJuIGl0ZW1Db3N0ICogZGlzY291bnRSYXRlO1xuICByZXR1cm4gaXRlbUNvc3QgLSBkaXNjb3VudDtcbn07XG4vLyBjYXJ0SXRlbXMsIGNhcnRJdGVtVG9BZGRcbmNvbnN0IGFkZEl0ZW1Ub0NhcnQgPSAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICBjb25zdCBleGlzdGluZ0NhcnRJdGVtSW5kZXggPSBzdGF0ZS5pdGVtcy5maW5kSW5kZXgoXG4gICAgKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGFjdGlvbi5wYXlsb2FkLmlkXG4gICk7XG5cbiAgaWYgKGV4aXN0aW5nQ2FydEl0ZW1JbmRleCA+IC0xKSB7XG4gICAgY29uc3QgbmV3U3RhdGUgPSBbLi4uc3RhdGUuaXRlbXNdO1xuICAgIG5ld1N0YXRlW2V4aXN0aW5nQ2FydEl0ZW1JbmRleF0ucXVhbnRpdHkgKz0gYWN0aW9uLnBheWxvYWQucXVhbnRpdHk7XG4gICAgcmV0dXJuIG5ld1N0YXRlO1xuICB9XG4gIHJldHVybiBbLi4uc3RhdGUuaXRlbXMsIGFjdGlvbi5wYXlsb2FkXTtcbn07XG5cbi8vIGNhcnRJdGVtcywgY2FydEl0ZW1Ub1JlbW92ZVxuY29uc3QgcmVtb3ZlSXRlbUZyb21DYXJ0ID0gKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgcmV0dXJuIHN0YXRlLml0ZW1zLnJlZHVjZSgoYWNjLCBpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0uaWQgPT09IGFjdGlvbi5wYXlsb2FkLmlkKSB7XG4gICAgICBjb25zdCBuZXdRdWFudGl0eSA9IGl0ZW0ucXVhbnRpdHkgLSBhY3Rpb24ucGF5bG9hZC5xdWFudGl0eTtcblxuICAgICAgcmV0dXJuIG5ld1F1YW50aXR5ID4gMFxuICAgICAgICA/IFsuLi5hY2MsIHsgLi4uaXRlbSwgcXVhbnRpdHk6IG5ld1F1YW50aXR5IH1dXG4gICAgICAgIDogWy4uLmFjY107XG4gICAgfVxuICAgIHJldHVybiBbLi4uYWNjLCBpdGVtXTtcbiAgfSwgW10pO1xufTtcblxuY29uc3QgY2xlYXJJdGVtRnJvbUNhcnQgPSAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICByZXR1cm4gc3RhdGUuaXRlbXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBhY3Rpb24ucGF5bG9hZC5pZCk7XG59O1xuXG5leHBvcnQgY29uc3QgcmVkdWNlciA9IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcbiAgICBjYXNlICdSRUhZRFJBVEUnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIC4uLmFjdGlvbi5wYXlsb2FkIH07XG4gICAgY2FzZSAnVE9HR0xFX0NBUlQnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGlzT3BlbjogIXN0YXRlLmlzT3BlbiB9O1xuICAgIGNhc2UgJ0FERF9JVEVNJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogYWRkSXRlbVRvQ2FydChzdGF0ZSwgYWN0aW9uKSB9O1xuICAgIGNhc2UgJ1JFTU9WRV9JVEVNJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogcmVtb3ZlSXRlbUZyb21DYXJ0KHN0YXRlLCBhY3Rpb24pIH07XG4gICAgY2FzZSAnQ0xFQVJfSVRFTV9GUk9NX0NBUlQnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGl0ZW1zOiBjbGVhckl0ZW1Gcm9tQ2FydChzdGF0ZSwgYWN0aW9uKSB9O1xuICAgIGNhc2UgJ0NMRUFSX0NBUlQnOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGl0ZW1zOiBbXSB9O1xuICAgIGNhc2UgJ0FQUExZX0NPVVBPTic6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgY291cG9uOiBhY3Rpb24ucGF5bG9hZCB9O1xuICAgIGNhc2UgJ1JFTU9WRV9DT1VQT04nOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGNvdXBvbjogbnVsbCB9O1xuICAgIGNhc2UgJ1RPR0dMRV9SRVNUQVVSQU5UJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpc1Jlc3RhdXJhbnQ6ICFzdGF0ZS5pc1Jlc3RhdXJhbnQgfTtcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGFjdGlvbjogJHthY3Rpb24udHlwZX1gKTtcbiAgfVxufTtcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VSZWR1Y2VyLCB1c2VDb250ZXh0LCBjcmVhdGVDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgcmVkdWNlciwgY2FydEl0ZW1zVG90YWxQcmljZSB9IGZyb20gJy4vY2FydC5yZWR1Y2VyJztcbmltcG9ydCB7IHVzZVN0b3JhZ2UgfSBmcm9tICd1dGlscy91c2Utc3RvcmFnZSc7XG5jb25zdCBDYXJ0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30gYXMgYW55KTtcbmNvbnN0IElOSVRJQUxfU1RBVEUgPSB7XG4gIGlzT3BlbjogZmFsc2UsXG4gIGl0ZW1zOiBbXSxcbiAgaXNSZXN0YXVyYW50OiBmYWxzZSxcbiAgY291cG9uOiBudWxsLFxufTtcblxuY29uc3QgdXNlQ2FydEFjdGlvbnMgPSAoaW5pdGlhbENhcnQgPSBJTklUSUFMX1NUQVRFKSA9PiB7XG4gIGNvbnN0IFtzdGF0ZSwgZGlzcGF0Y2hdID0gdXNlUmVkdWNlcihyZWR1Y2VyLCBpbml0aWFsQ2FydCk7XG5cbiAgY29uc3QgYWRkSXRlbUhhbmRsZXIgPSAoaXRlbSwgcXVhbnRpdHkgPSAxKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnQUREX0lURU0nLCBwYXlsb2FkOiB7IC4uLml0ZW0sIHF1YW50aXR5IH0gfSk7XG4gIH07XG5cbiAgY29uc3QgcmVtb3ZlSXRlbUhhbmRsZXIgPSAoaXRlbSwgcXVhbnRpdHkgPSAxKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnUkVNT1ZFX0lURU0nLCBwYXlsb2FkOiB7IC4uLml0ZW0sIHF1YW50aXR5IH0gfSk7XG4gIH07XG5cbiAgY29uc3QgY2xlYXJJdGVtRnJvbUNhcnRIYW5kbGVyID0gKGl0ZW0pID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdDTEVBUl9JVEVNX0ZST01fQ0FSVCcsIHBheWxvYWQ6IGl0ZW0gfSk7XG4gIH07XG5cbiAgY29uc3QgY2xlYXJDYXJ0SGFuZGxlciA9ICgpID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdDTEVBUl9DQVJUJyB9KTtcbiAgfTtcbiAgY29uc3QgdG9nZ2xlQ2FydEhhbmRsZXIgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnVE9HR0xFX0NBUlQnIH0pO1xuICB9O1xuICBjb25zdCBjb3Vwb25IYW5kbGVyID0gKGNvdXBvbikgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ0FQUExZX0NPVVBPTicsIHBheWxvYWQ6IGNvdXBvbiB9KTtcbiAgfTtcbiAgY29uc3QgcmVtb3ZlQ291cG9uSGFuZGxlciA9ICgpID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdSRU1PVkVfQ09VUE9OJyB9KTtcbiAgfTtcbiAgY29uc3QgcmVoeWRyYXRlTG9jYWxTdGF0ZSA9IChwYXlsb2FkKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnUkVIWURSQVRFJywgcGF5bG9hZCB9KTtcbiAgfTtcbiAgY29uc3QgdG9nZ2xlUmVzdGF1cmFudCA9ICgpID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdUT0dHTEVfUkVTVEFVUkFOVCcgfSk7XG4gIH07XG4gIGNvbnN0IGlzSW5DYXJ0SGFuZGxlciA9IChpZCkgPT4ge1xuICAgIHJldHVybiBzdGF0ZS5pdGVtcz8uc29tZSgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gaWQpO1xuICB9O1xuICBjb25zdCBnZXRJdGVtSGFuZGxlciA9IChpZCkgPT4ge1xuICAgIHJldHVybiBzdGF0ZS5pdGVtcz8uZmluZCgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gaWQpO1xuICB9O1xuICBjb25zdCBnZXRDYXJ0SXRlbXNQcmljZSA9ICgpID0+IGNhcnRJdGVtc1RvdGFsUHJpY2Uoc3RhdGUuaXRlbXMpLnRvRml4ZWQoMik7XG4gIGNvbnN0IGdldENhcnRJdGVtc1RvdGFsUHJpY2UgPSAoKSA9PlxuICAgIGNhcnRJdGVtc1RvdGFsUHJpY2Uoc3RhdGUuaXRlbXMsIHN0YXRlLmNvdXBvbikudG9GaXhlZCgyKTtcblxuICBjb25zdCBnZXREaXNjb3VudCA9ICgpID0+IHtcbiAgICBjb25zdCB0b3RhbCA9IGNhcnRJdGVtc1RvdGFsUHJpY2Uoc3RhdGUuaXRlbXMpO1xuICAgIGNvbnN0IGRpc2NvdW50ID0gc3RhdGUuY291cG9uXG4gICAgICA/ICh0b3RhbCAqIE51bWJlcihzdGF0ZS5jb3Vwb24/LmRpc2NvdW50SW5QZXJjZW50KSkgLyAxMDBcbiAgICAgIDogMDtcbiAgICByZXR1cm4gZGlzY291bnQudG9GaXhlZCgyKTtcbiAgfTtcbiAgY29uc3QgZ2V0SXRlbXNDb3VudCA9IHN0YXRlLml0ZW1zPy5yZWR1Y2UoXG4gICAgKGFjYywgaXRlbSkgPT4gYWNjICsgaXRlbS5xdWFudGl0eSxcbiAgICAwXG4gICk7XG4gIHJldHVybiB7XG4gICAgc3RhdGUsXG4gICAgZ2V0SXRlbXNDb3VudCxcbiAgICByZWh5ZHJhdGVMb2NhbFN0YXRlLFxuICAgIGFkZEl0ZW1IYW5kbGVyLFxuICAgIHJlbW92ZUl0ZW1IYW5kbGVyLFxuICAgIGNsZWFySXRlbUZyb21DYXJ0SGFuZGxlcixcbiAgICBjbGVhckNhcnRIYW5kbGVyLFxuICAgIGlzSW5DYXJ0SGFuZGxlcixcbiAgICBnZXRJdGVtSGFuZGxlcixcbiAgICB0b2dnbGVDYXJ0SGFuZGxlcixcbiAgICBnZXRDYXJ0SXRlbXNUb3RhbFByaWNlLFxuICAgIGdldENhcnRJdGVtc1ByaWNlLFxuICAgIGNvdXBvbkhhbmRsZXIsXG4gICAgcmVtb3ZlQ291cG9uSGFuZGxlcixcbiAgICBnZXREaXNjb3VudCxcbiAgICB0b2dnbGVSZXN0YXVyYW50LFxuICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IENhcnRQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3Qge1xuICAgIHN0YXRlLFxuICAgIHJlaHlkcmF0ZUxvY2FsU3RhdGUsXG4gICAgZ2V0SXRlbXNDb3VudCxcbiAgICBhZGRJdGVtSGFuZGxlcixcbiAgICByZW1vdmVJdGVtSGFuZGxlcixcbiAgICBjbGVhckl0ZW1Gcm9tQ2FydEhhbmRsZXIsXG4gICAgY2xlYXJDYXJ0SGFuZGxlcixcbiAgICBpc0luQ2FydEhhbmRsZXIsXG4gICAgZ2V0SXRlbUhhbmRsZXIsXG4gICAgdG9nZ2xlQ2FydEhhbmRsZXIsXG4gICAgZ2V0Q2FydEl0ZW1zVG90YWxQcmljZSxcbiAgICBjb3Vwb25IYW5kbGVyLFxuICAgIHJlbW92ZUNvdXBvbkhhbmRsZXIsXG4gICAgZ2V0Q2FydEl0ZW1zUHJpY2UsXG4gICAgZ2V0RGlzY291bnQsXG4gICAgdG9nZ2xlUmVzdGF1cmFudCxcbiAgfSA9IHVzZUNhcnRBY3Rpb25zKCk7XG4gIGNvbnN0IHsgcmVoeWRyYXRlZCwgZXJyb3IgfSA9IHVzZVN0b3JhZ2Uoc3RhdGUsIHJlaHlkcmF0ZUxvY2FsU3RhdGUpO1xuXG4gIHJldHVybiAoXG4gICAgPENhcnRDb250ZXh0LlByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICBpc09wZW46IHN0YXRlLmlzT3BlbixcbiAgICAgICAgaXRlbXM6IHN0YXRlLml0ZW1zLFxuICAgICAgICBjb3Vwb246IHN0YXRlLmNvdXBvbixcbiAgICAgICAgaXNSZXN0YXVyYW50OiBzdGF0ZS5pc1Jlc3RhdXJhbnQsXG4gICAgICAgIGNhcnRJdGVtc0NvdW50OiBzdGF0ZS5pdGVtcz8ubGVuZ3RoLFxuICAgICAgICBpdGVtc0NvdW50OiBnZXRJdGVtc0NvdW50LFxuICAgICAgICBhZGRJdGVtOiBhZGRJdGVtSGFuZGxlcixcbiAgICAgICAgcmVtb3ZlSXRlbTogcmVtb3ZlSXRlbUhhbmRsZXIsXG4gICAgICAgIHJlbW92ZUl0ZW1Gcm9tQ2FydDogY2xlYXJJdGVtRnJvbUNhcnRIYW5kbGVyLFxuICAgICAgICBjbGVhckNhcnQ6IGNsZWFyQ2FydEhhbmRsZXIsXG4gICAgICAgIGlzSW5DYXJ0OiBpc0luQ2FydEhhbmRsZXIsXG4gICAgICAgIGdldEl0ZW06IGdldEl0ZW1IYW5kbGVyLFxuICAgICAgICB0b2dnbGVDYXJ0OiB0b2dnbGVDYXJ0SGFuZGxlcixcbiAgICAgICAgY2FsY3VsYXRlUHJpY2U6IGdldENhcnRJdGVtc1RvdGFsUHJpY2UsXG4gICAgICAgIGNhbGN1bGF0ZVN1YlRvdGFsUHJpY2U6IGdldENhcnRJdGVtc1ByaWNlLFxuICAgICAgICBhcHBseUNvdXBvbjogY291cG9uSGFuZGxlcixcbiAgICAgICAgcmVtb3ZlQ291cG9uOiByZW1vdmVDb3Vwb25IYW5kbGVyLFxuICAgICAgICBjYWxjdWxhdGVEaXNjb3VudDogZ2V0RGlzY291bnQsXG4gICAgICAgIHRvZ2dsZVJlc3RhdXJhbnQsXG4gICAgICB9fVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0NhcnRDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IHVzZUNhcnQgPSAoKSA9PiB1c2VDb250ZXh0KENhcnRDb250ZXh0KTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcbi8vIGltcG9ydCB7IGNsb3NlTW9kYWwgfSBmcm9tICdAcmVkcS9yZXVzZS1tb2RhbCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdjb21wb25lbnRzL2J1dHRvbi9idXR0b24nO1xuaW1wb3J0IHtcbiAgUXVpY2tWaWV3V3JhcHBlcixcbiAgUHJvZHVjdERldGFpbHNXcmFwcGVyLFxuICBQcm9kdWN0UHJldmlldyxcbiAgRGlzY291bnRQZXJjZW50LFxuICBQcm9kdWN0SW5mb1dyYXBwZXIsXG4gIFByb2R1Y3RJbmZvLFxuICBQcm9kdWN0VGl0bGVQcmljZVdyYXBwZXIsXG4gIFByb2R1Y3RUaXRsZSxcbiAgUHJvZHVjdFdlaWdodCxcbiAgUHJvZHVjdERlc2NyaXB0aW9uLFxuICBCdXR0b25UZXh0LFxuICBQcm9kdWN0TWV0YSxcbiAgUHJvZHVjdENhcnRXcmFwcGVyLFxuICBQcm9kdWN0UHJpY2VXcmFwcGVyLFxuICBQcm9kdWN0UHJpY2UsXG4gIFNhbGVQcmljZSxcbiAgUHJvZHVjdENhcnRCdG4sXG4gIE1ldGFTaW5nbGUsXG4gIE1ldGFJdGVtLFxuICBNb2RhbENsb3NlLFxufSBmcm9tICcuL3F1aWNrLXZpZXcuc3R5bGUnO1xuaW1wb3J0IHsgQ2xvc2VJY29uIH0gZnJvbSAnYXNzZXRzL2ljb25zL0Nsb3NlSWNvbic7XG5pbXBvcnQgeyBDYXJ0SWNvbiB9IGZyb20gJ2Fzc2V0cy9pY29ucy9DYXJ0SWNvbic7XG5pbXBvcnQgeyBDVVJSRU5DWSB9IGZyb20gJ3V0aWxzL2NvbnN0YW50JztcblxuaW1wb3J0IFJlYWRNb3JlIGZyb20gJ2NvbXBvbmVudHMvdHJ1bmNhdGUvdHJ1bmNhdGUnO1xuaW1wb3J0IENhcm91c2VsV2l0aEN1c3RvbURvdHMgZnJvbSAnY29tcG9uZW50cy9tdWx0aS1jYXJvdXNlbC9tdWx0aS1jYXJvdXNlbCc7XG5pbXBvcnQgeyB1c2VMb2NhbGUgfSBmcm9tICdjb250ZXh0cy9sYW5ndWFnZS9sYW5ndWFnZS5wcm92aWRlcic7XG5pbXBvcnQgeyB1c2VDYXJ0IH0gZnJvbSAnY29udGV4dHMvY2FydC91c2UtY2FydCc7XG5pbXBvcnQgeyBDb3VudGVyIH0gZnJvbSAnY29tcG9uZW50cy9jb3VudGVyL2NvdW50ZXInO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuXG50eXBlIFF1aWNrVmlld1Byb3BzID0ge1xuICBtb2RhbFByb3BzOiBhbnk7XG4gIG9uTW9kYWxDbG9zZT86IGFueTtcbiAgaGlkZU1vZGFsOiAoKSA9PiB2b2lkO1xuICBkZXZpY2VUeXBlOiBhbnk7XG59O1xuXG5jb25zdCBRdWlja1ZpZXdNb2JpbGU6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PFF1aWNrVmlld1Byb3BzPiA9ICh7XG4gIG1vZGFsUHJvcHMsXG4gIG9uTW9kYWxDbG9zZSxcbiAgaGlkZU1vZGFsLFxuICBkZXZpY2VUeXBlLFxufSkgPT4ge1xuICBjb25zdCB7IGFkZEl0ZW0sIHJlbW92ZUl0ZW0sIGlzSW5DYXJ0LCBnZXRJdGVtIH0gPSB1c2VDYXJ0KCk7XG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICB0eXBlLFxuICAgIHRpdGxlLFxuICAgIHVuaXQsXG4gICAgcHJpY2UsXG4gICAgZGlzY291bnRJblBlcmNlbnQsXG4gICAgc2FsZVByaWNlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGdhbGxlcnksXG4gICAgY2F0ZWdvcmllcyxcbiAgfSA9IG1vZGFsUHJvcHM7XG5cbiAgY29uc3QgeyBpc1J0bCB9ID0gdXNlTG9jYWxlKCk7XG5cbiAgY29uc3QgaGFuZGxlQWRkQ2xpY2sgPSAoZTogYW55KSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBhZGRJdGVtKG1vZGFsUHJvcHMpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUNsaWNrID0gKGU6IGFueSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgcmVtb3ZlSXRlbShtb2RhbFByb3BzKTtcbiAgfTtcbiAgZnVuY3Rpb24gb25DYXRlZ29yeUNsaWNrKHNsdWcpIHtcbiAgICBSb3V0ZXIucHVzaCh7XG4gICAgICBwYXRobmFtZTogYC8ke3R5cGUudG9Mb3dlckNhc2UoKX1gLFxuICAgICAgcXVlcnk6IHsgY2F0ZWdvcnk6IHNsdWcgfSxcbiAgICB9KS50aGVuKCgpID0+IHdpbmRvdy5zY3JvbGxUbygwLCAwKSk7XG4gICAgaGlkZU1vZGFsKCk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogPE1vZGFsQ2xvc2Ugb25DbGljaz17b25Nb2RhbENsb3NlfT5cbiAgICAgICAgPENsb3NlSWNvbiAvPlxuICAgICAgPC9Nb2RhbENsb3NlPiAqL31cbiAgICAgIDxRdWlja1ZpZXdXcmFwcGVyIGNsYXNzTmFtZT0ncXVpY2stdmlldy1tb2JpbGUtd3JhcHBlcic+XG4gICAgICAgIDxQcm9kdWN0RGV0YWlsc1dyYXBwZXIgY2xhc3NOYW1lPSdwcm9kdWN0LWNhcmQnIGRpcj0nbHRyJz5cbiAgICAgICAgICB7IWlzUnRsICYmIChcbiAgICAgICAgICAgIDxQcm9kdWN0UHJldmlldz5cbiAgICAgICAgICAgICAgPENhcm91c2VsV2l0aEN1c3RvbURvdHMgaXRlbXM9e2dhbGxlcnl9IGRldmljZVR5cGU9e2RldmljZVR5cGV9IC8+XG4gICAgICAgICAgICAgIHshIWRpc2NvdW50SW5QZXJjZW50ICYmIChcbiAgICAgICAgICAgICAgICA8RGlzY291bnRQZXJjZW50PntkaXNjb3VudEluUGVyY2VudH0lPC9EaXNjb3VudFBlcmNlbnQ+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L1Byb2R1Y3RQcmV2aWV3PlxuICAgICAgICAgICl9XG4gICAgICAgICAgPFByb2R1Y3RJbmZvV3JhcHBlciBkaXI9e2lzUnRsID8gJ3J0bCcgOiAnbHRyJ30+XG4gICAgICAgICAgICA8UHJvZHVjdEluZm8+XG4gICAgICAgICAgICAgIDxQcm9kdWN0VGl0bGVQcmljZVdyYXBwZXI+XG4gICAgICAgICAgICAgICAgPFByb2R1Y3RUaXRsZT57dGl0bGV9PC9Qcm9kdWN0VGl0bGU+XG4gICAgICAgICAgICAgIDwvUHJvZHVjdFRpdGxlUHJpY2VXcmFwcGVyPlxuXG4gICAgICAgICAgICAgIDxQcm9kdWN0V2VpZ2h0Pnt1bml0fTwvUHJvZHVjdFdlaWdodD5cbiAgICAgICAgICAgICAgPFByb2R1Y3REZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICA8UmVhZE1vcmUgY2hhcmFjdGVyPXs2MDB9PntkZXNjcmlwdGlvbn08L1JlYWRNb3JlPlxuICAgICAgICAgICAgICA8L1Byb2R1Y3REZXNjcmlwdGlvbj5cblxuICAgICAgICAgICAgICA8UHJvZHVjdE1ldGE+XG4gICAgICAgICAgICAgICAgPE1ldGFTaW5nbGU+XG4gICAgICAgICAgICAgICAgICB7Y2F0ZWdvcmllc1xuICAgICAgICAgICAgICAgICAgICA/IGNhdGVnb3JpZXMubWFwKChpdGVtOiBhbnkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZXRhSXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNhdGVnb3J5Q2xpY2soaXRlbS5zbHVnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTWV0YUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgOiAnJ31cbiAgICAgICAgICAgICAgICA8L01ldGFTaW5nbGU+XG4gICAgICAgICAgICAgIDwvUHJvZHVjdE1ldGE+XG5cbiAgICAgICAgICAgICAgPFByb2R1Y3RDYXJ0V3JhcHBlcj5cbiAgICAgICAgICAgICAgICA8UHJvZHVjdFByaWNlV3JhcHBlcj5cbiAgICAgICAgICAgICAgICAgIDxQcm9kdWN0UHJpY2U+XG4gICAgICAgICAgICAgICAgICAgIHtDVVJSRU5DWX1cbiAgICAgICAgICAgICAgICAgICAge3NhbGVQcmljZSA/IHNhbGVQcmljZSA6IHByaWNlfVxuICAgICAgICAgICAgICAgICAgPC9Qcm9kdWN0UHJpY2U+XG5cbiAgICAgICAgICAgICAgICAgIHtkaXNjb3VudEluUGVyY2VudCA/IChcbiAgICAgICAgICAgICAgICAgICAgPFNhbGVQcmljZT5cbiAgICAgICAgICAgICAgICAgICAgICB7Q1VSUkVOQ1l9XG4gICAgICAgICAgICAgICAgICAgICAge3ByaWNlfVxuICAgICAgICAgICAgICAgICAgICA8L1NhbGVQcmljZT5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgIDwvUHJvZHVjdFByaWNlV3JhcHBlcj5cblxuICAgICAgICAgICAgICAgIDxQcm9kdWN0Q2FydEJ0bj5cbiAgICAgICAgICAgICAgICAgIHshaXNJbkNhcnQoaWQpID8gKFxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdjYXJ0LWJ1dHRvbidcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PSdzZWNvbmRhcnknXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPXsxMDB9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkQ2xpY2t9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FydEljb24gbXI9ezJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybWF0dGVkTWVzc2FnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD0nYWRkQ2FydEJ1dHRvbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdE1lc3NhZ2U9J0NhcnQnXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uVGV4dD5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8Q291bnRlclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXRJdGVtKGlkKS5xdWFudGl0eX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkRlY3JlbWVudD17aGFuZGxlUmVtb3ZlQ2xpY2t9XG4gICAgICAgICAgICAgICAgICAgICAgb25JbmNyZW1lbnQ9e2hhbmRsZUFkZENsaWNrfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L1Byb2R1Y3RDYXJ0QnRuPlxuICAgICAgICAgICAgICA8L1Byb2R1Y3RDYXJ0V3JhcHBlcj5cbiAgICAgICAgICAgIDwvUHJvZHVjdEluZm8+XG4gICAgICAgICAgPC9Qcm9kdWN0SW5mb1dyYXBwZXI+XG5cbiAgICAgICAgICB7aXNSdGwgJiYgKFxuICAgICAgICAgICAgPFByb2R1Y3RQcmV2aWV3PlxuICAgICAgICAgICAgICA8Q2Fyb3VzZWxXaXRoQ3VzdG9tRG90cyBpdGVtcz17Z2FsbGVyeX0gZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX0gLz5cbiAgICAgICAgICAgICAgeyEhZGlzY291bnRJblBlcmNlbnQgJiYgKFxuICAgICAgICAgICAgICAgIDxEaXNjb3VudFBlcmNlbnQ+e2Rpc2NvdW50SW5QZXJjZW50fSU8L0Rpc2NvdW50UGVyY2VudD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvUHJvZHVjdFByZXZpZXc+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9Qcm9kdWN0RGV0YWlsc1dyYXBwZXI+XG4gICAgICA8L1F1aWNrVmlld1dyYXBwZXI+XG4gICAgPC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBRdWlja1ZpZXdNb2JpbGU7XG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJztcbmltcG9ydCB7IHRoZW1lR2V0IH0gZnJvbSAnQHN0eWxlZC1zeXN0ZW0vdGhlbWUtZ2V0JztcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3REZXRhaWxzV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IHN0cmV0Y2g7XG4gIG1pbi1oZWlnaHQ6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAvKiBib3gtc2hhZG93OiAwIDEwcHggNDBweCByZ2JhKDAsIDAsIDAsIDAuMTYpOyAqL1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gIH1cblxuICAqIHtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFByZXZpZXcgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogNTAlO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgcGFkZGluZzogMzBweCA2MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAyMHB4IDBweDtcbiAgICBvcmRlcjogMDtcbiAgfVxuXG4gIGltZyB7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgIG1pbi13aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFNhbGVUYWcgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMueHMnLCAnMTInKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLndoaXRlJywgJyNmZmZmZmYnKX07XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cuaG92ZXInLCAnI0ZCQjk3OScpfTtcbiAgcGFkZGluZzogMCAxMHB4O1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgYm9yZGVyLXJhZGl1czogJHt0aGVtZUdldCgncmFkaWkubWVkaXVtJywgJzEycHgnKX07XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDQwcHg7XG4gIHJpZ2h0OiAzMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IERpc2NvdW50UGVyY2VudCA9IHN0eWxlZC5zcGFuYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdMYXRvJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5zbScsICcxMycpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMud2hpdGUnLCAnI2ZmZmZmZicpfTtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy55ZWxsb3cuaG92ZXInLCAnI0ZCQjk3OScpfTtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDMwcHg7XG4gIHJpZ2h0OiAzMHB4O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5tZWRpdW0nLCAnMTJweCcpfTtcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDFweCk7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMXB4KTtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mb1dyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogNTAlO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAke3RoZW1lR2V0KCdjb2xvcnMubGlnaHRNZWRpdW1Db2xvcicsICcjZjNmM2YzJyl9O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1heC13aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAzMHB4IDAgMDtcbiAgICBvcmRlcjogMTtcbiAgICBib3JkZXI6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SW5mbyA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDUwcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgcGFkZGluZzogMDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RUaXRsZVByaWNlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RUaXRsZSA9IHN0eWxlZC5oMWBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmhlYWRpbmcnLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMubGcnLCAnMjEnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnNlbWlCb2xkJywgJzYwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LmJvbGQnLCAnIzBEMTEzNicpfTtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgZGlzcGxheTogZmxleDtcblxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFByaWNlV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtc2hyaW5rOiAwO1xuICBtYXJnaW4tbGVmdDogMjVweDtcbiAgbGluZS1oZWlnaHQ6IDMxcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0UHJpY2UgPSBzdHlsZWQuZGl2YFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdMYXRvJyl9O1xuICBmb250LXNpemU6IGNhbGMoJHt0aGVtZUdldCgnZm9udFNpemVzLmJhc2UnLCAnMTUnKX1weCArIDFweCk7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBTYWxlUHJpY2UgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLnJlZ3VsYXInLCAnNDAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIHBhZGRpbmc6IDAgNXB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuXG4gICY6YmVmb3JlIHtcbiAgICBjb250ZW50OiAnJztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDFweDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnllbGxvdy5ob3ZlcicsICcjRkJCOTc5Jyl9O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDUwJTtcbiAgICBsZWZ0OiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdFdlaWdodCA9IHN0eWxlZC5kaXZgXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ0xhdG8nKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0RGVzY3JpcHRpb24gPSBzdHlsZWQucGBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMucmVndWxhcicsICc0MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5tZWRpdW0nLCAnIzQyNDU2MScpfTtcbiAgbGluZS1oZWlnaHQ6IDI7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdENhcnRCdG4gPSBzdHlsZWQuZGl2YFxuICBtYXJnaW4tdG9wOiA2MHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIG1hcmdpbi10b3A6IDQwcHg7XG4gIH1cblxuICAuY2FydC1idXR0b24ge1xuICAgIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ0xhdG8nKX07XG4gICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICAgIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgIGhlaWdodDogMzZweDtcbiAgICBib3JkZXItcmFkaXVzOiA0cmVtO1xuXG4gICAgLmJ0bi1pY29uIHtcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgIH1cblxuICAgICY6aG92ZXIge1xuICAgICAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnByaW1hcnkucmVndWxhcicsICcjRjM5QzEyJyl9O1xuICAgICAgYm9yZGVyLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gICAgfVxuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQnV0dG9uVGV4dCA9IHN0eWxlZC5zcGFuYFxuICAvKiBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5gO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdENhcnRXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbmA7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0TWV0YSA9IHN0eWxlZC5kaXZgXG4gIG1hcmdpbi10b3A6IDMwcHg7XG5gO1xuXG5leHBvcnQgY29uc3QgTWV0YVNpbmdsZSA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgJjpsYXN0LWNoaWxkIHtcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgTWV0YUl0ZW0gPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnTGF0bycpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuc20nLCAnMTMnKX1weDtcbiAgZm9udC13ZWlnaHQ6ICR7dGhlbWVHZXQoJ2ZvbnRXZWlnaHRzLmJvbGQnLCAnNzAwJyl9O1xuICBjb2xvcjogJHt0aGVtZUdldCgnY29sb3JzLnRleHQuYm9sZCcsICcjMEQxMTM2Jyl9O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5ncmF5LjIwMCcsICcjZjdmN2Y3Jyl9O1xuICBwYWRkaW5nOiAwIDE1cHg7XG4gIGJvcmRlci1yYWRpdXM6ICR7dGhlbWVHZXQoJ3JhZGlpLmJhc2UnLCAnNnB4Jyl9O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGhlaWdodDogMzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5gO1xuXG5leHBvcnQgY29uc3QgTW9kYWxDbG9zZSA9IHN0eWxlZC5idXR0b25gXG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiAyMHB4O1xuICByaWdodDogMTVweDtcbiAgcGFkZGluZzogMTBweCAxNXB4O1xuICB6LWluZGV4OiAxO1xuXG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDA7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgc3ZnIHtcbiAgICB3aWR0aDogMTJweDtcbiAgICBoZWlnaHQ6IDEycHg7XG4gIH1cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgdG9wOiA1cHg7XG4gICAgcmlnaHQ6IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBRdWlja1ZpZXdXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgd2lkdGg6IDEwMjBweDtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG5cbiAgJi5xdWljay12aWV3LW1vYmlsZS13cmFwcGVyIHtcbiAgICAke1Byb2R1Y3RDYXJ0V3JhcHBlcn0ge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG5cbiAgICAke1NhbGVQcmljZX0ge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICAgIH1cblxuICAgICR7UHJvZHVjdFByaWNlfSB7XG4gICAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5sZycsICcyMScpfXB4O1xuICAgIH1cblxuICAgICR7UHJvZHVjdENhcnRCdG59IHtcbiAgICAgIG1hcmdpbi10b3A6IDBweDtcblxuICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAke1Byb2R1Y3RQcmljZX0ge1xuICAgICAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMubGcnLCAnMjEnKX1weDtcbiAgICB9XG5cbiAgICAke1Byb2R1Y3RQcmljZVdyYXBwZXJ9IHtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwO1xuXG4gICAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICB9XG4gICAgfVxuICB9XG5gO1xuIiwiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBsb2NhbEZvcmFnZSBmcm9tICdsb2NhbGZvcmFnZSc7XG5jb25zdCBpc09iamVjdExpa2VkID0gKHZhbHVlKSA9PlxuICB2YWx1ZS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnQXJyYXknIHx8IHZhbHVlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdPYmplY3QnO1xuXG5jb25zdCByZWh5ZHJhdGUgPSAodmFsdWU6IGFueSwgZGVmYXVsdFZhbHVlPzogYW55KSA9PiB7XG4gIGlmICghdmFsdWUpIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gIC8vIGlmICh2YWx1ZSA9PT0gJ2ZhbHNlJykgc3RyID0gZmFsc2U7XG4gIC8vIGlmICh2YWx1ZSA9PT0gJ3RydWUnKSBzdHIgPSB0cnVlO1xuICAvLyBpZiAoIWlzT2JqZWN0TGlrZWQodmFsdWUpKSB7XG4gIC8vICAgcmV0dXJuIHZhbHVlO1xuICAvLyB9XG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2UgPSBKU09OLnBhcnNlKHZhbHVlKTtcbiAgICByZXR1cm4gcGFyc2U7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gIH1cbn07XG5cbmNvbnN0IGh5ZHJhdGUgPSAodmFsdWUpID0+IHtcbiAgaWYgKCFpc09iamVjdExpa2VkKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xufTtcbmNvbnN0IGNyZWF0ZU1pZ3JhdGlvbiA9IChvcHRzLCBkYXRhKSA9PiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3Qga2V5ID0gYCR7b3B0cy5rZXl9LXZlcnNpb25gO1xuICAgIGxvY2FsRm9yYWdlLmdldEl0ZW0oa2V5LCAoZXJyLCB2ZXJzaW9uKSA9PiB7XG4gICAgICBpZiAodmVyc2lvbiAhPT0gb3B0cy52ZXJzaW9uKSB7XG4gICAgICAgIGRhdGEgPSBvcHRzLm1pZ3JhdGUoZGF0YSk7XG4gICAgICAgIGxvY2FsRm9yYWdlLnNldEl0ZW0ob3B0cy5rZXksIHJlaHlkcmF0ZShkYXRhKSwgKGVycikgPT4ge1xuICAgICAgICAgIGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICBsb2NhbEZvcmFnZS5zZXRJdGVtKGtleSwgb3B0cy52ZXJzaW9uLCAoZXJyKSA9PiB7XG4gICAgICAgICAgICBpZiAoZXJyKSByZXR1cm4gcmVqZWN0KGVycik7XG4gICAgICAgICAgICByZXR1cm4gcmVzb2x2ZShkYXRhKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKGRhdGEpO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbn07XG5cbmNvbnN0IGNvbmZpZyA9IHtcbiAga2V5OiAnQHNlc3Npb24nLFxuICB2ZXJzaW9uOiAxLFxuICBtaWdyYXRlOiAoc3RhdGUpID0+IHtcbiAgICByZXR1cm4geyAuLi5zdGF0ZSB9O1xuICB9LFxufTtcblxuZXhwb3J0IGNvbnN0IHVzZVN0b3JhZ2UgPSAoc3RhdGUsIHNldFN0YXRlKSA9PiB7XG4gIGNvbnN0IFtyZWh5ZHJhdGVkLCBzZXRSZWh5ZHJhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFzeW5jIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICBhd2FpdCBsb2NhbEZvcmFnZS5nZXRJdGVtKGNvbmZpZy5rZXksIChlcnIsIHZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICBzZXRSZWh5ZHJhdGVkKHRydWUpO1xuICAgICAgICAgIHJldHVybiBzZXRFcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIE1pZ3JhdGUgcGVyc2lzdGVkIGRhdGFcbiAgICAgICAgY29uc3QgcmVzdG9yZWRWYWx1ZSA9IHJlaHlkcmF0ZSh2YWx1ZSk7XG4gICAgICAgIGlmICh0eXBlb2YgY29uZmlnLm1pZ3JhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICBjcmVhdGVNaWdyYXRpb24oY29uZmlnLCByZXN0b3JlZFZhbHVlKVxuICAgICAgICAgICAgLnRoZW4oKGRhdGEpID0+IHNldFN0YXRlKGRhdGEpKVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4gc2V0UmVoeWRyYXRlZCh0cnVlKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0U3RhdGUocmVzdG9yZWRWYWx1ZSk7XG4gICAgICAgICAgc2V0UmVoeWRyYXRlZCh0cnVlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGluaXQoKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gaWYgKGlzTmlsKHN0YXRlKSB8fCBpc0VtcHR5KHN0YXRlKSkge1xuICAgIC8vICAgbG9jYWxGb3JhZ2UucmVtb3ZlSXRlbShjb25maWcua2V5KTtcbiAgICAvLyB9XG4gICAgbG9jYWxGb3JhZ2Uuc2V0SXRlbShjb25maWcua2V5LCBoeWRyYXRlKHN0YXRlKSk7XG4gIH0sIFtzdGF0ZV0pO1xuXG4gIHJldHVybiB7XG4gICAgcmVoeWRyYXRlZCxcbiAgICBlcnJvcixcbiAgfTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9