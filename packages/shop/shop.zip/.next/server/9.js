exports.ids = [9];
exports.modules = {

/***/ "./src/assets/icons/PlusMinus.tsx":
/*!****************************************!*\
  !*** ./src/assets/icons/PlusMinus.tsx ***!
  \****************************************/
/*! exports provided: Plus, Minus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Plus", function() { return Plus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Minus", function() { return Minus; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\PlusMinus.tsx";
 // SVG plus icon

const Plus = ({
  color = 'currentColor',
  width = '12px',
  height = '12px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 12",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Group_3351",
      "data-name": "Group 3351",
      transform: "translate(-1367 -190)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 520",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1367 195)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        "data-name": "Rectangle 521",
        width: "12",
        height: "2",
        rx: "1",
        transform: "translate(1374 190) rotate(90)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
}; // SVG minus icon

const Minus = ({
  color = 'currentColor',
  width = '12px',
  height = '2px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 2",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
      "data-name": "Rectangle 522",
      width: "12",
      height: "2",
      rx: "1",
      fill: color
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/assets/icons/PlusOutline.tsx":
/*!******************************************!*\
  !*** ./src/assets/icons/PlusOutline.tsx ***!
  \******************************************/
/*! exports provided: PlusOutline */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlusOutline", function() { return PlusOutline; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\assets\\icons\\PlusOutline.tsx";

const PlusOutline = ({
  color = 'currentColor',
  width = '16px',
  height = '16px'
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
      id: "Group_3371",
      "data-name": "Group 3371",
      transform: "translate(-1539 -2317.5)",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        id: "Rectangle_680",
        "data-name": "Rectangle 680",
        width: "16",
        height: "1.5",
        transform: "translate(1539 2325)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
        id: "Rectangle_681",
        "data-name": "Rectangle 681",
        width: "16",
        height: "1.5",
        transform: "translate(1547.5 2317.5) rotate(90)",
        fill: color
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/counter/counter.style.tsx":
/*!**************************************************!*\
  !*** ./src/components/counter/counter.style.tsx ***!
  \**************************************************/
/*! exports provided: CounterBox, CounterButton, CounterValue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterBox", function() { return CounterBox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterButton", function() { return CounterButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CounterValue", function() { return CounterValue; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/css */ "@styled-system/css");
/* harmony import */ var _styled_system_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-system */ "styled-system");
/* harmony import */ var styled_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_system__WEBPACK_IMPORTED_MODULE_2__);



const CounterBox = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "counterstyle__CounterBox",
  componentId: "sc-8iu0h2-0"
})(_styled_system_css__WEBPACK_IMPORTED_MODULE_1___default()({
  display: 'flex',
  backgroundColor: 'primary.regular',
  color: 'white',
  fontSize: 'base',
  fontWeight: 'bold'
}), {
  borderRadius: 200,
  justifyContent: 'space-between',
  alignItems: 'center',
  overflow: 'hidden',
  flexShrink: 0,
  '&:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    horizontal: {
      width: 104,
      height: 36
    },
    vertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse'
    },
    lightHorizontal: {
      width: 104,
      height: 36,
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    lightVertical: {
      width: 30,
      height: 90,
      flexDirection: 'column-reverse',
      backgroundColor: 'gray.200',
      color: 'text.bold'
    },
    altHorizontal: {
      width: 104,
      height: 36,
      borderRadius: '6px'
    },
    altVertical: {
      width: 30,
      height: 90,
      borderRadius: '6px'
    },
    full: {
      width: '100%',
      height: 36,
      borderRadius: '6px'
    }
  }
}));
const CounterButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.button.withConfig({
  displayName: "counterstyle__CounterButton",
  componentId: "sc-8iu0h2-1"
})({
  border: 'none',
  backgroundColor: 'transparent',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  padding: 10,
  cursor: 'pointer',
  '&:hover, &:focus': {
    outline: 'none'
  }
}, Object(styled_system__WEBPACK_IMPORTED_MODULE_2__["variant"])({
  variants: {
    lightHorizontal: {
      color: 'text.regular'
    },
    lightVertical: {
      color: 'text.regular'
    }
  }
}));
const CounterValue = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "counterstyle__CounterValue",
  componentId: "sc-8iu0h2-2"
})({
  pointerEvents: 'none'
});
CounterValue.displayName = 'CounterValue';
CounterButton.displayName = 'CounterButton';
CounterBox.displayName = 'CounterBox';
CounterBox.defaultProps = {
  variant: 'horizontal'
};

/***/ }),

/***/ "./src/components/counter/counter.tsx":
/*!********************************************!*\
  !*** ./src/components/counter/counter.tsx ***!
  \********************************************/
/*! exports provided: Counter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Counter", function() { return Counter; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! assets/icons/PlusMinus */ "./src/assets/icons/PlusMinus.tsx");
/* harmony import */ var _counter_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./counter.style */ "./src/components/counter/counter.style.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\counter\\counter.tsx";



const Counter = ({
  onDecrement,
  onIncrement,
  value,
  variant,
  className
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterBox"], {
    variant: variant,
    className: className,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onDecrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Minus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterValue"], {
      children: value
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_counter_style__WEBPACK_IMPORTED_MODULE_3__["CounterButton"], {
      onClick: onIncrement,
      variant: variant,
      className: "control-button",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusMinus__WEBPACK_IMPORTED_MODULE_2__["Plus"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/image/image.tsx":
/*!****************************************!*\
  !*** ./src/components/image/image.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image */ "react-image");
/* harmony import */ var react_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-placeholder.png */ "./src/components/image/product-placeholder.png");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\image\\image.tsx";




const Placeholder = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
  src: _product_placeholder_png__WEBPACK_IMPORTED_MODULE_3__["default"],
  alt: "product img loader"
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 27
}, undefined);

function Image({
  url,
  alt = "placeholder",
  unloader,
  loader,
  className,
  style
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_image__WEBPACK_IMPORTED_MODULE_2__["Img"], {
    draggable: false,
    style: style,
    src: url,
    alt: alt,
    loader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 15
    }, this),
    unloader: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Placeholder, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 17
    }, this),
    className: className
  }, url, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./src/components/image/product-placeholder.png":
/*!******************************************************!*\
  !*** ./src/components/image/product-placeholder.png ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAADwCAYAAADxXop4AAAHPElEQVR4Xu3d23La2BaGUREOPpTf/0mNwYCsvthFtoMdix+WxBIZ46qrsjpxutpfNOXlmVnXdV0DEPjVdwDglHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcQWfQco53A4/P7n+XzezGazH89DrYRjQF3XNbvdrtntdk3btl9+fD6fN4vFonl8fBQRJmXWdV3Xd4jcfr9v3t7emnP+885ms+bh4aF5fHzsOwpVEI4BbDab5v39ve/YF8vlsnl+fvb0QfW8HC3s0mg0n55SoHbCUdB+v784Gkf7/b7Zbrd9x+CmhKOgzWbTd+Qs7+/vZ70bgVsRjkJ2u13z8fHRd+wsXdd56qBqwlHIfr/vOxIp/fNBScJRSOlP9I+PD+MK1RKOin13aQxqIBwFeDL40+er9dwn4SjAha3/a9u2Wa/X7qPcOeEoZIh4zOfzviNV6bru9zX74/focJ+Eo5Dlctl3JDLF755dr9d/vJd5e3szttwp4SikdDhWq1XfkapsNptvI7Fer4vdb6EewlHIcrksNlrMZrNJhWO32/31qn3Xdc16vfYC+c4IR0FPT099R87y9PQ0mTGlbdveq/bnnGFahKOgxWLRPD8/9x370Wq1mszTRtd1zevr61lPE7vdzjX6OyIcha1Wq4vj8fDwcPG/ewvnRuNou90Wv2HLbVjkM5DD4dBsNpuzbn/++vWreXp6Kv6CdUhvb28Xfbl1Nps1Ly8vxd4HcRvCMbDdbtccDodmv99/+dN5uVw2y+VyMqPJ0W63u+qC13w+b15eXibzHoevhGNkbdtO+k/bw+HQvL6+9h3rtVgsmpeXl75jVMo7jpFNORofHx/Ner3uO3aW4yjHNAkHZxniPsb7+/tF70m4PeGoWMlP0mud+6I3NdTPy7CEo1Kl3iWUsN1uB3sySO6CUA/hqNDxu0zbtr35pakxtq4f48F0CEeFttvt728M2263N3uUb9v2qi+7Jsb8tbiecFTmcDh8+YaxW3xCfd6tMRY7PKZDOCpy/GQ9dYuR5XS3xljs8JgG4ajI5xHlux8b6xP5b7s1xmKHR/2EoxLfjSinxhhZftqtMZYh7oxQlnBU4G8jyqmhR5aa9mbU9LHwlXBU4KcR5dRQI0uN9yns8KiXcNzYOSPKqXOeTlK1RePIDo86CccNnTuinCo9shwvm9Wq9o/vXyQcN5SMKKdKjSxTuDtxizsl/Ew4buSSEeXUJU8rnx0Oh6t/jrEc/4Y46iAcN3DpiHLqmpGl5G6NsdjhUQ/huIFrRpRTl4wsU74nYYdHHYRjZCVGlFPp08vUd2BM/eO/B8IxolIjyqlkZBlyt8ZYarxz8q8RjhGVHFFOnTOyjLFbYyx2eNyWcIykbdviI8qpn55m7nHfxT3+nqZCOEYyxv/gfxtZ7vkexBTuodwj4RjBOWNEKd/9WrfarTEWOzzGJxwDS15clvL56ebWuzXGYofHuIRjYGOMKKeOsapht8ZYpnw3ZYr8FZAD2m63oz9tfDabzf65T6TVatU8Pz/3HeNKnjgGcosR5dS/Fo3GDo/RCMdAbjGi8D92eAxPOAYw5ldR+J4dHsMSjsJqGFG477srNRCOwowo9bDDYzjCUZARpT52eAxDOAoxotTLDo/yhKMQI0rd7PAoSzgKMKLUzw6PsoTjSkaU6bDDoxzhuJIRZVrs8ChDOK5gRJkmOzyuJxwXMqJMmx0e1xGOC3ncnT47PC4nHBcwotwHOzwuJxwhI8p9advWzdILCEfIiHJ/7PDICUfAiHK/7PDILPoO8KfHx8e+I0yUF6Xns3MUiBlVgJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOICQcQEw4gJhxATDiAmHAAMeEAYsIBxIQDiAkHEBMOICYcQEw4gJhwADHhAGLCAcSEA4gJBxATDiAmHEBMOICYcAAx4QBiwgHEhAOI/Qe0gyoTzEMWZQAAAABJRU5ErkJggg==");

/***/ }),

/***/ "./src/components/product-card/product-card-five/product-card-five.style.tsx":
/*!***********************************************************************************!*\
  !*** ./src/components/product-card/product-card-five/product-card-five.style.tsx ***!
  \***********************************************************************************/
/*! exports provided: CardWrapper, ImageWrapper, InfoWrapper, Title, Unit, Price, CartButton, Counter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardWrapper", function() { return CardWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageWrapper", function() { return ImageWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoWrapper", function() { return InfoWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Title", function() { return Title; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Unit", function() { return Unit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Price", function() { return Price; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartButton", function() { return CartButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Counter", function() { return Counter; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @styled-system/theme-get */ "@styled-system/theme-get");
/* harmony import */ var _styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_button_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/button/button */ "./src/components/button/button.tsx");
/* harmony import */ var components_counter_counter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/counter/counter */ "./src/components/counter/counter.tsx");




const CardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-card-fivestyle__CardWrapper",
  componentId: "sjuhwu-0"
})(["height:100%;width:100%;position:relative;font-family:", ";display:flex;flex-direction:column;"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'));
const ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-card-fivestyle__ImageWrapper",
  componentId: "sjuhwu-1"
})(["width:auto;height:auto;position:relative;text-align:center;display:flex;align-items:center;justify-content:center;margin-bottom:15px;background-color:", ";img{max-width:100%;max-height:100%;display:inline-block;}&.overlay{&:after{content:'';width:100%;height:100%;display:inline-block;position:absolute;top:0;left:0;background-color:rgba(255,255,255,0.75);}}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'));
const InfoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.div.withConfig({
  displayName: "product-card-fivestyle__InfoWrapper",
  componentId: "sjuhwu-2"
})(["padding:0;width:100%;display:flex;flex-direction:column;margin-top:auto;@media (max-width:990px){padding:15px 20px;}"]);
const Title = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.h3.withConfig({
  displayName: "product-card-fivestyle__Title",
  componentId: "sjuhwu-3"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin:0 0 4px 0;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;@media (max-width:767px){font-size:14px;margin:0 0 5px 0;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'));
const Unit = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-card-fivestyle__Unit",
  componentId: "sjuhwu-4"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";@media (max-width:767px){font-size:", "px;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.regular', '400'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.regular', '#77798c'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.xs', '12'));
const Price = styled_components__WEBPACK_IMPORTED_MODULE_0___default.a.span.withConfig({
  displayName: "product-card-fivestyle__Price",
  componentId: "sjuhwu-5"
})(["font-family:", ";font-size:", "px;font-weight:", ";color:", ";margin-bottom:10px;@media (max-width:767px){font-size:calc(", "px - 1px);}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fonts.body', 'sans-serif'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.text.bold', '#0D1136'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.base', '15'));
const CartButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(components_button_button__WEBPACK_IMPORTED_MODULE_2__["Button"]).withConfig({
  displayName: "product-card-fivestyle__CartButton",
  componentId: "sjuhwu-6"
})(["background-color:", ";border:0;color:", ";border-radius:", ";width:40px;height:40px;border-radius:50%;padding-left:0;padding-right:0;font-size:", "px;font-weight:", ";position:absolute;bottom:20px;right:15px;box-shadow:0px 0px 12px rgba(0,0,0,0.3);z-index:1;@media (max-width:767px){width:32px;height:32px;padding:0;border-radius:50%;}.btn-text{padding:0 0 0 6px;@media (max-width:767px){display:none;}}&:hover{background-color:", ";}svg{fill:currentColor;}"], Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.white', '#ffffff'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('radii.big', '18px'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontSizes.sm', '13'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('fontWeights.bold', '700'), Object(_styled_system_theme_get__WEBPACK_IMPORTED_MODULE_1__["themeGet"])('colors.primary.regular', '#F39C12'));
const Counter = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(components_counter_counter__WEBPACK_IMPORTED_MODULE_3__["Counter"]).withConfig({
  displayName: "product-card-fivestyle__Counter",
  componentId: "sjuhwu-7"
})(["position:absolute;width:calc(100% - 60px);height:36px;bottom:30px;left:30px;z-index:1;box-shadow:0 0 8px rgba(0,0,0,0.2);"]);

/***/ }),

/***/ "./src/components/product-card/product-card-five/product-card-five.tsx":
/*!*****************************************************************************!*\
  !*** ./src/components/product-card/product-card-five/product-card-five.tsx ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_image_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! components/image/image */ "./src/components/image/image.tsx");
/* harmony import */ var assets_icons_PlusOutline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! assets/icons/PlusOutline */ "./src/assets/icons/PlusOutline.tsx");
/* harmony import */ var _product_card_five_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./product-card-five.style */ "./src/components/product-card/product-card-five/product-card-five.style.tsx");
/* harmony import */ var contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! contexts/cart/use-cart */ "./src/contexts/cart/use-cart.tsx");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\components\\product-card\\product-card-five\\product-card-five.tsx";

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const ProductCard = (_ref) => {
  let {
    title,
    image,
    weight,
    price,
    salePrice,
    discountInPercent,
    cartProducts,
    addToCart,
    updateCart,
    value,
    currency,
    onChange,
    increment,
    decrement,
    data,
    deviceType,
    onClick
  } = _ref,
      props = _objectWithoutProperties(_ref, ["title", "image", "weight", "price", "salePrice", "discountInPercent", "cartProducts", "addToCart", "updateCart", "value", "currency", "onChange", "increment", "decrement", "data", "deviceType", "onClick"]);

  const {
    addItem,
    removeItem,
    getItem,
    isInCart
  } = Object(contexts_cart_use_cart__WEBPACK_IMPORTED_MODULE_5__["useCart"])();

  const handleAddClick = e => {
    e.stopPropagation();
    addItem(data);
  };

  const handleRemoveClick = e => {
    e.stopPropagation();
    removeItem(data);
  }; // console.log(items, 'product-card');


  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["CardWrapper"], {
    onClick: onClick,
    className: "medicine-card",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["ImageWrapper"], {
      className: isInCart(data === null || data === void 0 ? void 0 : data.id) && 'overlay',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_image_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
        url: image,
        className: "product-image",
        style: {
          position: 'relative'
        },
        alt: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, undefined), !isInCart(data === null || data === void 0 ? void 0 : data.id) ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["CartButton"], {
        className: "cart-button",
        onClick: handleAddClick,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(assets_icons_PlusOutline__WEBPACK_IMPORTED_MODULE_3__["PlusOutline"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["Counter"], {
        value: getItem(data === null || data === void 0 ? void 0 : data.id).quantity,
        onDecrement: handleRemoveClick,
        onIncrement: handleAddClick
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["InfoWrapper"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["Price"], {
        children: [currency, price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["Title"], {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 98,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_product_card_five_style__WEBPACK_IMPORTED_MODULE_4__["Unit"], {
        children: weight
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 71,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ProductCard);

/***/ }),

/***/ "./src/contexts/cart/cart.reducer.tsx":
/*!********************************************!*\
  !*** ./src/contexts/cart/cart.reducer.tsx ***!
  \********************************************/
/*! exports provided: cartItemsTotalPrice, reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cartItemsTotalPrice", function() { return cartItemsTotalPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// export const cartItemsTotalPrice = (items, { discountInPercent = 0 } = {}) => {
const cartItemsTotalPrice = (items, coupon = null) => {
  if (items === null || items.length === 0) return 0;
  const itemCost = items.reduce((total, item) => {
    if (item.salePrice) {
      return total + item.salePrice * item.quantity;
    }

    return total + item.price * item.quantity;
  }, 0); // const discountRate = 1 - discountInPercent;

  const discount = coupon ? itemCost * Number(coupon.discountInPercent) / 100 : 0; // itemCost * discountRate * TAX_RATE + shipping;
  // return itemCost * discountRate;

  return itemCost - discount;
}; // cartItems, cartItemToAdd

const addItemToCart = (state, action) => {
  const existingCartItemIndex = state.items.findIndex(item => item.id === action.payload.id);

  if (existingCartItemIndex > -1) {
    const newState = [...state.items];
    newState[existingCartItemIndex].quantity += action.payload.quantity;
    return newState;
  }

  return [...state.items, action.payload];
}; // cartItems, cartItemToRemove


const removeItemFromCart = (state, action) => {
  return state.items.reduce((acc, item) => {
    if (item.id === action.payload.id) {
      const newQuantity = item.quantity - action.payload.quantity;
      return newQuantity > 0 ? [...acc, _objectSpread(_objectSpread({}, item), {}, {
        quantity: newQuantity
      })] : [...acc];
    }

    return [...acc, item];
  }, []);
};

const clearItemFromCart = (state, action) => {
  return state.items.filter(item => item.id !== action.payload.id);
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'REHYDRATE':
      return _objectSpread(_objectSpread({}, state), action.payload);

    case 'TOGGLE_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        isOpen: !state.isOpen
      });

    case 'ADD_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: addItemToCart(state, action)
      });

    case 'REMOVE_ITEM':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: removeItemFromCart(state, action)
      });

    case 'CLEAR_ITEM_FROM_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: clearItemFromCart(state, action)
      });

    case 'CLEAR_CART':
      return _objectSpread(_objectSpread({}, state), {}, {
        items: []
      });

    case 'APPLY_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: action.payload
      });

    case 'REMOVE_COUPON':
      return _objectSpread(_objectSpread({}, state), {}, {
        coupon: null
      });

    case 'TOGGLE_RESTAURANT':
      return _objectSpread(_objectSpread({}, state), {}, {
        isRestaurant: !state.isRestaurant
      });

    default:
      throw new Error(`Unknown action: ${action.type}`);
  }
};

/***/ }),

/***/ "./src/contexts/cart/use-cart.tsx":
/*!****************************************!*\
  !*** ./src/contexts/cart/use-cart.tsx ***!
  \****************************************/
/*! exports provided: CartProvider, useCart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartProvider", function() { return CartProvider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useCart", function() { return useCart; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _cart_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cart.reducer */ "./src/contexts/cart/cart.reducer.tsx");
/* harmony import */ var utils_use_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! utils/use-storage */ "./src/utils/use-storage.ts");

var _jsxFileName = "D:\\laravel projects\\new website\\update\\Pickbazar - React GraphQL Ecommerce Template\\pickbazar\\packages\\shop\\src\\contexts\\cart\\use-cart.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const CartContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])({});
const INITIAL_STATE = {
  isOpen: false,
  items: [],
  isRestaurant: false,
  coupon: null
};

const useCartActions = (initialCart = INITIAL_STATE) => {
  var _state$items3;

  const {
    0: state,
    1: dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useReducer"])(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["reducer"], initialCart);

  const addItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const removeItemHandler = (item, quantity = 1) => {
    dispatch({
      type: 'REMOVE_ITEM',
      payload: _objectSpread(_objectSpread({}, item), {}, {
        quantity
      })
    });
  };

  const clearItemFromCartHandler = item => {
    dispatch({
      type: 'CLEAR_ITEM_FROM_CART',
      payload: item
    });
  };

  const clearCartHandler = () => {
    dispatch({
      type: 'CLEAR_CART'
    });
  };

  const toggleCartHandler = () => {
    dispatch({
      type: 'TOGGLE_CART'
    });
  };

  const couponHandler = coupon => {
    dispatch({
      type: 'APPLY_COUPON',
      payload: coupon
    });
  };

  const removeCouponHandler = () => {
    dispatch({
      type: 'REMOVE_COUPON'
    });
  };

  const rehydrateLocalState = payload => {
    dispatch({
      type: 'REHYDRATE',
      payload
    });
  };

  const toggleRestaurant = () => {
    dispatch({
      type: 'TOGGLE_RESTAURANT'
    });
  };

  const isInCartHandler = id => {
    var _state$items;

    return (_state$items = state.items) === null || _state$items === void 0 ? void 0 : _state$items.some(item => item.id === id);
  };

  const getItemHandler = id => {
    var _state$items2;

    return (_state$items2 = state.items) === null || _state$items2 === void 0 ? void 0 : _state$items2.find(item => item.id === id);
  };

  const getCartItemsPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items).toFixed(2);

  const getCartItemsTotalPrice = () => Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items, state.coupon).toFixed(2);

  const getDiscount = () => {
    var _state$coupon;

    const total = Object(_cart_reducer__WEBPACK_IMPORTED_MODULE_2__["cartItemsTotalPrice"])(state.items);
    const discount = state.coupon ? total * Number((_state$coupon = state.coupon) === null || _state$coupon === void 0 ? void 0 : _state$coupon.discountInPercent) / 100 : 0;
    return discount.toFixed(2);
  };

  const getItemsCount = (_state$items3 = state.items) === null || _state$items3 === void 0 ? void 0 : _state$items3.reduce((acc, item) => acc + item.quantity, 0);
  return {
    state,
    getItemsCount,
    rehydrateLocalState,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    getCartItemsPrice,
    couponHandler,
    removeCouponHandler,
    getDiscount,
    toggleRestaurant
  };
};

const CartProvider = ({
  children
}) => {
  var _state$items4;

  const {
    state,
    rehydrateLocalState,
    getItemsCount,
    addItemHandler,
    removeItemHandler,
    clearItemFromCartHandler,
    clearCartHandler,
    isInCartHandler,
    getItemHandler,
    toggleCartHandler,
    getCartItemsTotalPrice,
    couponHandler,
    removeCouponHandler,
    getCartItemsPrice,
    getDiscount,
    toggleRestaurant
  } = useCartActions();
  const {
    rehydrated,
    error
  } = Object(utils_use_storage__WEBPACK_IMPORTED_MODULE_3__["useStorage"])(state, rehydrateLocalState);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CartContext.Provider, {
    value: {
      isOpen: state.isOpen,
      items: state.items,
      coupon: state.coupon,
      isRestaurant: state.isRestaurant,
      cartItemsCount: (_state$items4 = state.items) === null || _state$items4 === void 0 ? void 0 : _state$items4.length,
      itemsCount: getItemsCount,
      addItem: addItemHandler,
      removeItem: removeItemHandler,
      removeItemFromCart: clearItemFromCartHandler,
      clearCart: clearCartHandler,
      isInCart: isInCartHandler,
      getItem: getItemHandler,
      toggleCart: toggleCartHandler,
      calculatePrice: getCartItemsTotalPrice,
      calculateSubTotalPrice: getCartItemsPrice,
      applyCoupon: couponHandler,
      removeCoupon: removeCouponHandler,
      calculateDiscount: getDiscount,
      toggleRestaurant
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 108,
    columnNumber: 5
  }, undefined);
};
const useCart = () => Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(CartContext);

/***/ }),

/***/ "./src/utils/use-storage.ts":
/*!**********************************!*\
  !*** ./src/utils/use-storage.ts ***!
  \**********************************/
/*! exports provided: useStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useStorage", function() { return useStorage; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! localforage */ "localforage");
/* harmony import */ var localforage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(localforage__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const isObjectLiked = value => value.constructor.name === 'Array' || value.constructor.name === 'Object';

const rehydrate = (value, defaultValue) => {
  if (!value) return defaultValue; // if (value === 'false') str = false;
  // if (value === 'true') str = true;
  // if (!isObjectLiked(value)) {
  //   return value;
  // }

  try {
    const parse = JSON.parse(value);
    return parse;
  } catch (err) {
    return defaultValue;
  }
};

const hydrate = value => {
  if (!isObjectLiked(value)) {
    return value;
  }

  return JSON.stringify(value);
};

const createMigration = (opts, data) => {
  return new Promise((resolve, reject) => {
    const key = `${opts.key}-version`;
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(key, (err, version) => {
      if (version !== opts.version) {
        data = opts.migrate(data);
        localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(opts.key, rehydrate(data), err => {
          if (err) return reject(err);
          localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(key, opts.version, err => {
            if (err) return reject(err);
            return resolve(data);
          });
        });
      } else {
        resolve(data);
      }
    });
  });
};

const config = {
  key: '@session',
  version: 1,
  migrate: state => {
    return _objectSpread({}, state);
  }
};
const useStorage = (state, setState) => {
  const {
    0: rehydrated,
    1: setRehydrated
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const {
    0: error,
    1: setError
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function init() {
      await localforage__WEBPACK_IMPORTED_MODULE_1___default.a.getItem(config.key, (err, value) => {
        if (err) {
          setRehydrated(true);
          return setError(err);
        } // Migrate persisted data


        const restoredValue = rehydrate(value);

        if (typeof config.migrate === 'function') {
          createMigration(config, restoredValue).then(data => setState(data)).then(() => setRehydrated(true));
        } else {
          setState(restoredValue);
          setRehydrated(true);
        }
      });
    }

    init();
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    // if (isNil(state) || isEmpty(state)) {
    //   localForage.removeItem(config.key);
    // }
    localforage__WEBPACK_IMPORTED_MODULE_1___default.a.setItem(config.key, hydrate(state));
  }, [state]);
  return {
    rehydrated,
    error
  };
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvYXNzZXRzL2ljb25zL1BsdXNNaW51cy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2Fzc2V0cy9pY29ucy9QbHVzT3V0bGluZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvY291bnRlci9jb3VudGVyLnN0eWxlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jb3VudGVyL2NvdW50ZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2ltYWdlL2ltYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbWFnZS9wcm9kdWN0LXBsYWNlaG9sZGVyLnBuZyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wcm9kdWN0LWNhcmQvcHJvZHVjdC1jYXJkLWZpdmUvcHJvZHVjdC1jYXJkLWZpdmUuc3R5bGUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL3Byb2R1Y3QtY2FyZC9wcm9kdWN0LWNhcmQtZml2ZS9wcm9kdWN0LWNhcmQtZml2ZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRleHRzL2NhcnQvY2FydC5yZWR1Y2VyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGV4dHMvY2FydC91c2UtY2FydC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3V0aWxzL3VzZS1zdG9yYWdlLnRzIl0sIm5hbWVzIjpbIlBsdXMiLCJjb2xvciIsIndpZHRoIiwiaGVpZ2h0IiwiTWludXMiLCJQbHVzT3V0bGluZSIsIkNvdW50ZXJCb3giLCJzdHlsZWQiLCJkaXYiLCJjc3MiLCJkaXNwbGF5IiwiYmFja2dyb3VuZENvbG9yIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiYm9yZGVyUmFkaXVzIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwib3ZlcmZsb3ciLCJmbGV4U2hyaW5rIiwib3V0bGluZSIsInZhcmlhbnQiLCJ2YXJpYW50cyIsImhvcml6b250YWwiLCJ2ZXJ0aWNhbCIsImZsZXhEaXJlY3Rpb24iLCJsaWdodEhvcml6b250YWwiLCJsaWdodFZlcnRpY2FsIiwiYWx0SG9yaXpvbnRhbCIsImFsdFZlcnRpY2FsIiwiZnVsbCIsIkNvdW50ZXJCdXR0b24iLCJidXR0b24iLCJib3JkZXIiLCJwYWRkaW5nIiwiY3Vyc29yIiwiQ291bnRlclZhbHVlIiwic3BhbiIsInBvaW50ZXJFdmVudHMiLCJkaXNwbGF5TmFtZSIsImRlZmF1bHRQcm9wcyIsIkNvdW50ZXIiLCJvbkRlY3JlbWVudCIsIm9uSW5jcmVtZW50IiwidmFsdWUiLCJjbGFzc05hbWUiLCJQbGFjZWhvbGRlciIsInBsYWNlaG9sZGVyIiwiSW1hZ2UiLCJ1cmwiLCJhbHQiLCJ1bmxvYWRlciIsImxvYWRlciIsInN0eWxlIiwiQ2FyZFdyYXBwZXIiLCJ0aGVtZUdldCIsIkltYWdlV3JhcHBlciIsIkluZm9XcmFwcGVyIiwiVGl0bGUiLCJoMyIsIlVuaXQiLCJQcmljZSIsIkNhcnRCdXR0b24iLCJCdXR0b24iLCJDb3VudGVycyIsIlByb2R1Y3RDYXJkIiwidGl0bGUiLCJpbWFnZSIsIndlaWdodCIsInByaWNlIiwic2FsZVByaWNlIiwiZGlzY291bnRJblBlcmNlbnQiLCJjYXJ0UHJvZHVjdHMiLCJhZGRUb0NhcnQiLCJ1cGRhdGVDYXJ0IiwiY3VycmVuY3kiLCJvbkNoYW5nZSIsImluY3JlbWVudCIsImRlY3JlbWVudCIsImRhdGEiLCJkZXZpY2VUeXBlIiwib25DbGljayIsInByb3BzIiwiYWRkSXRlbSIsInJlbW92ZUl0ZW0iLCJnZXRJdGVtIiwiaXNJbkNhcnQiLCJ1c2VDYXJ0IiwiaGFuZGxlQWRkQ2xpY2siLCJlIiwic3RvcFByb3BhZ2F0aW9uIiwiaGFuZGxlUmVtb3ZlQ2xpY2siLCJpZCIsInBvc2l0aW9uIiwicXVhbnRpdHkiLCJjYXJ0SXRlbXNUb3RhbFByaWNlIiwiaXRlbXMiLCJjb3Vwb24iLCJsZW5ndGgiLCJpdGVtQ29zdCIsInJlZHVjZSIsInRvdGFsIiwiaXRlbSIsImRpc2NvdW50IiwiTnVtYmVyIiwiYWRkSXRlbVRvQ2FydCIsInN0YXRlIiwiYWN0aW9uIiwiZXhpc3RpbmdDYXJ0SXRlbUluZGV4IiwiZmluZEluZGV4IiwicGF5bG9hZCIsIm5ld1N0YXRlIiwicmVtb3ZlSXRlbUZyb21DYXJ0IiwiYWNjIiwibmV3UXVhbnRpdHkiLCJjbGVhckl0ZW1Gcm9tQ2FydCIsImZpbHRlciIsInJlZHVjZXIiLCJ0eXBlIiwiaXNPcGVuIiwiaXNSZXN0YXVyYW50IiwiRXJyb3IiLCJDYXJ0Q29udGV4dCIsImNyZWF0ZUNvbnRleHQiLCJJTklUSUFMX1NUQVRFIiwidXNlQ2FydEFjdGlvbnMiLCJpbml0aWFsQ2FydCIsImRpc3BhdGNoIiwidXNlUmVkdWNlciIsImFkZEl0ZW1IYW5kbGVyIiwicmVtb3ZlSXRlbUhhbmRsZXIiLCJjbGVhckl0ZW1Gcm9tQ2FydEhhbmRsZXIiLCJjbGVhckNhcnRIYW5kbGVyIiwidG9nZ2xlQ2FydEhhbmRsZXIiLCJjb3Vwb25IYW5kbGVyIiwicmVtb3ZlQ291cG9uSGFuZGxlciIsInJlaHlkcmF0ZUxvY2FsU3RhdGUiLCJ0b2dnbGVSZXN0YXVyYW50IiwiaXNJbkNhcnRIYW5kbGVyIiwic29tZSIsImdldEl0ZW1IYW5kbGVyIiwiZmluZCIsImdldENhcnRJdGVtc1ByaWNlIiwidG9GaXhlZCIsImdldENhcnRJdGVtc1RvdGFsUHJpY2UiLCJnZXREaXNjb3VudCIsImdldEl0ZW1zQ291bnQiLCJDYXJ0UHJvdmlkZXIiLCJjaGlsZHJlbiIsInJlaHlkcmF0ZWQiLCJlcnJvciIsInVzZVN0b3JhZ2UiLCJjYXJ0SXRlbXNDb3VudCIsIml0ZW1zQ291bnQiLCJjbGVhckNhcnQiLCJ0b2dnbGVDYXJ0IiwiY2FsY3VsYXRlUHJpY2UiLCJjYWxjdWxhdGVTdWJUb3RhbFByaWNlIiwiYXBwbHlDb3Vwb24iLCJyZW1vdmVDb3Vwb24iLCJjYWxjdWxhdGVEaXNjb3VudCIsInVzZUNvbnRleHQiLCJpc09iamVjdExpa2VkIiwiY29uc3RydWN0b3IiLCJuYW1lIiwicmVoeWRyYXRlIiwiZGVmYXVsdFZhbHVlIiwicGFyc2UiLCJKU09OIiwiZXJyIiwiaHlkcmF0ZSIsInN0cmluZ2lmeSIsImNyZWF0ZU1pZ3JhdGlvbiIsIm9wdHMiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImtleSIsImxvY2FsRm9yYWdlIiwidmVyc2lvbiIsIm1pZ3JhdGUiLCJzZXRJdGVtIiwiY29uZmlnIiwic2V0U3RhdGUiLCJzZXRSZWh5ZHJhdGVkIiwidXNlU3RhdGUiLCJzZXRFcnJvciIsInVzZUVmZmVjdCIsImluaXQiLCJyZXN0b3JlZFZhbHVlIiwidGhlbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FDQTs7QUFDTyxNQUFNQSxJQUFJLEdBQUcsQ0FBQztBQUNuQkMsT0FBSyxHQUFHLGNBRFc7QUFFbkJDLE9BQUssR0FBRyxNQUZXO0FBR25CQyxRQUFNLEdBQUc7QUFIVSxDQUFELEtBSWQ7QUFDSixzQkFDRTtBQUNFLFNBQUssRUFBQyw0QkFEUjtBQUVFLFNBQUssRUFBRUQsS0FGVDtBQUdFLFVBQU0sRUFBRUMsTUFIVjtBQUlFLFdBQU8sRUFBQyxXQUpWO0FBQUEsMkJBTUU7QUFDRSxRQUFFLEVBQUMsWUFETDtBQUVFLG1CQUFVLFlBRlo7QUFHRSxlQUFTLEVBQUMsdUJBSFo7QUFBQSw4QkFLRTtBQUNFLHFCQUFVLGVBRFo7QUFFRSxhQUFLLEVBQUMsSUFGUjtBQUdFLGNBQU0sRUFBQyxHQUhUO0FBSUUsVUFBRSxFQUFDLEdBSkw7QUFLRSxpQkFBUyxFQUFDLHFCQUxaO0FBTUUsWUFBSSxFQUFFRjtBQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFhRTtBQUNFLHFCQUFVLGVBRFo7QUFFRSxhQUFLLEVBQUMsSUFGUjtBQUdFLGNBQU0sRUFBQyxHQUhUO0FBSUUsVUFBRSxFQUFDLEdBSkw7QUFLRSxpQkFBUyxFQUFDLGdDQUxaO0FBTUUsWUFBSSxFQUFFQTtBQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBK0JELENBcENNLEMsQ0FzQ1A7O0FBQ08sTUFBTUcsS0FBSyxHQUFHLENBQUM7QUFDcEJILE9BQUssR0FBRyxjQURZO0FBRXBCQyxPQUFLLEdBQUcsTUFGWTtBQUdwQkMsUUFBTSxHQUFHO0FBSFcsQ0FBRCxLQUlmO0FBQ0osc0JBQ0U7QUFDRSxTQUFLLEVBQUMsNEJBRFI7QUFFRSxTQUFLLEVBQUVELEtBRlQ7QUFHRSxVQUFNLEVBQUVDLE1BSFY7QUFJRSxXQUFPLEVBQUMsVUFKVjtBQUFBLDJCQU1FO0FBQ0UsbUJBQVUsZUFEWjtBQUVFLFdBQUssRUFBQyxJQUZSO0FBR0UsWUFBTSxFQUFDLEdBSFQ7QUFJRSxRQUFFLEVBQUMsR0FKTDtBQUtFLFVBQUksRUFBRUY7QUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0JELENBckJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekNQO0FBQ08sTUFBTUksV0FBVyxHQUFHLENBQUM7QUFDMUJKLE9BQUssR0FBRyxjQURrQjtBQUUxQkMsT0FBSyxHQUFHLE1BRmtCO0FBRzFCQyxRQUFNLEdBQUc7QUFIaUIsQ0FBRCxLQUlyQjtBQUNKLHNCQUNFO0FBQ0UsU0FBSyxFQUFDLDRCQURSO0FBRUUsU0FBSyxFQUFFRCxLQUZUO0FBR0UsVUFBTSxFQUFFQyxNQUhWO0FBSUUsV0FBTyxFQUFDLFdBSlY7QUFBQSwyQkFNRTtBQUNFLFFBQUUsRUFBQyxZQURMO0FBRUUsbUJBQVUsWUFGWjtBQUdFLGVBQVMsRUFBQywwQkFIWjtBQUFBLDhCQUtFO0FBQ0UsVUFBRSxFQUFDLGVBREw7QUFFRSxxQkFBVSxlQUZaO0FBR0UsYUFBSyxFQUFDLElBSFI7QUFJRSxjQUFNLEVBQUMsS0FKVDtBQUtFLGlCQUFTLEVBQUMsc0JBTFo7QUFNRSxZQUFJLEVBQUVGO0FBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQWFFO0FBQ0UsVUFBRSxFQUFDLGVBREw7QUFFRSxxQkFBVSxlQUZaO0FBR0UsYUFBSyxFQUFDLElBSFI7QUFJRSxjQUFNLEVBQUMsS0FKVDtBQUtFLGlCQUFTLEVBQUMscUNBTFo7QUFNRSxZQUFJLEVBQUVBO0FBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUErQkQsQ0FwQ00sQzs7Ozs7Ozs7Ozs7O0FDRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDTyxNQUFNSyxVQUFVLEdBQUdDLHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsR0FDckJDLHlEQUFHLENBQUM7QUFDRkMsU0FBTyxFQUFFLE1BRFA7QUFFRkMsaUJBQWUsRUFBRSxpQkFGZjtBQUdGVixPQUFLLEVBQUUsT0FITDtBQUlGVyxVQUFRLEVBQUUsTUFKUjtBQUtGQyxZQUFVLEVBQUU7QUFMVixDQUFELENBRGtCLEVBUXJCO0FBQ0VDLGNBQVksRUFBRSxHQURoQjtBQUVFQyxnQkFBYyxFQUFFLGVBRmxCO0FBR0VDLFlBQVUsRUFBRSxRQUhkO0FBSUVDLFVBQVEsRUFBRSxRQUpaO0FBS0VDLFlBQVUsRUFBRSxDQUxkO0FBTUUsYUFBVztBQUNUQyxXQUFPLEVBQUU7QUFEQTtBQU5iLENBUnFCLEVBa0JyQkMsNkRBQU8sQ0FBQztBQUNOQyxVQUFRLEVBQUU7QUFDUkMsY0FBVSxFQUFFO0FBQ1ZwQixXQUFLLEVBQUUsR0FERztBQUVWQyxZQUFNLEVBQUU7QUFGRSxLQURKO0FBS1JvQixZQUFRLEVBQUU7QUFDUnJCLFdBQUssRUFBRSxFQURDO0FBRVJDLFlBQU0sRUFBRSxFQUZBO0FBR1JxQixtQkFBYSxFQUFFO0FBSFAsS0FMRjtBQVVSQyxtQkFBZSxFQUFFO0FBQ2Z2QixXQUFLLEVBQUUsR0FEUTtBQUVmQyxZQUFNLEVBQUUsRUFGTztBQUdmUSxxQkFBZSxFQUFFLFVBSEY7QUFJZlYsV0FBSyxFQUFFO0FBSlEsS0FWVDtBQWdCUnlCLGlCQUFhLEVBQUU7QUFDYnhCLFdBQUssRUFBRSxFQURNO0FBRWJDLFlBQU0sRUFBRSxFQUZLO0FBR2JxQixtQkFBYSxFQUFFLGdCQUhGO0FBSWJiLHFCQUFlLEVBQUUsVUFKSjtBQUtiVixXQUFLLEVBQUU7QUFMTSxLQWhCUDtBQXVCUjBCLGlCQUFhLEVBQUU7QUFDYnpCLFdBQUssRUFBRSxHQURNO0FBRWJDLFlBQU0sRUFBRSxFQUZLO0FBR2JXLGtCQUFZLEVBQUU7QUFIRCxLQXZCUDtBQTRCUmMsZUFBVyxFQUFFO0FBQ1gxQixXQUFLLEVBQUUsRUFESTtBQUVYQyxZQUFNLEVBQUUsRUFGRztBQUdYVyxrQkFBWSxFQUFFO0FBSEgsS0E1Qkw7QUFpQ1JlLFFBQUksRUFBRTtBQUNKM0IsV0FBSyxFQUFFLE1BREg7QUFFSkMsWUFBTSxFQUFFLEVBRko7QUFHSlcsa0JBQVksRUFBRTtBQUhWO0FBakNFO0FBREosQ0FBRCxDQWxCYyxDQUFoQjtBQTZEQSxNQUFNZ0IsYUFBYSxHQUFHdkIsd0RBQU0sQ0FBQ3dCLE1BQVY7QUFBQTtBQUFBO0FBQUEsR0FDeEI7QUFDRUMsUUFBTSxFQUFFLE1BRFY7QUFFRXJCLGlCQUFlLEVBQUUsYUFGbkI7QUFHRVYsT0FBSyxFQUFFLE9BSFQ7QUFJRVMsU0FBTyxFQUFFLE1BSlg7QUFLRU0sWUFBVSxFQUFFLFFBTGQ7QUFNRUQsZ0JBQWMsRUFBRSxRQU5sQjtBQU9FWixRQUFNLEVBQUUsTUFQVjtBQVFFOEIsU0FBTyxFQUFFLEVBUlg7QUFTRUMsUUFBTSxFQUFFLFNBVFY7QUFVRSxzQkFBb0I7QUFDbEJmLFdBQU8sRUFBRTtBQURTO0FBVnRCLENBRHdCLEVBZXhCQyw2REFBTyxDQUFDO0FBQ05DLFVBQVEsRUFBRTtBQUNSSSxtQkFBZSxFQUFFO0FBQ2Z4QixXQUFLLEVBQUU7QUFEUSxLQURUO0FBSVJ5QixpQkFBYSxFQUFFO0FBQ2J6QixXQUFLLEVBQUU7QUFETTtBQUpQO0FBREosQ0FBRCxDQWZpQixDQUFuQjtBQTJCQSxNQUFNa0MsWUFBWSxHQUFHNUIsd0RBQU0sQ0FBQzZCLElBQVY7QUFBQTtBQUFBO0FBQUEsR0FBZTtBQUN0Q0MsZUFBYSxFQUFFO0FBRHVCLENBQWYsQ0FBbEI7QUFHUEYsWUFBWSxDQUFDRyxXQUFiLEdBQTJCLGNBQTNCO0FBQ0FSLGFBQWEsQ0FBQ1EsV0FBZCxHQUE0QixlQUE1QjtBQUNBaEMsVUFBVSxDQUFDZ0MsV0FBWCxHQUF5QixZQUF6QjtBQUNBaEMsVUFBVSxDQUFDaUMsWUFBWCxHQUEwQjtBQUN4Qm5CLFNBQU8sRUFBRTtBQURlLENBQTFCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqR0E7QUFDQTtBQUNBO0FBU08sTUFBTW9CLE9BQXdCLEdBQUcsQ0FBQztBQUN2Q0MsYUFEdUM7QUFFdkNDLGFBRnVDO0FBR3ZDQyxPQUh1QztBQUl2Q3ZCLFNBSnVDO0FBS3ZDd0I7QUFMdUMsQ0FBRCxLQU1sQztBQUNKLHNCQUNFLHFFQUFDLHlEQUFEO0FBQVksV0FBTyxFQUFFeEIsT0FBckI7QUFBOEIsYUFBUyxFQUFFd0IsU0FBekM7QUFBQSw0QkFDRSxxRUFBQyw0REFBRDtBQUNFLGFBQU8sRUFBRUgsV0FEWDtBQUVFLGFBQU8sRUFBRXJCLE9BRlg7QUFHRSxlQUFTLEVBQUMsZ0JBSFo7QUFBQSw2QkFLRSxxRUFBQyw0REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVFFLHFFQUFDLDJEQUFEO0FBQUEsZ0JBQWV1QjtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkYsZUFTRSxxRUFBQyw0REFBRDtBQUNFLGFBQU8sRUFBRUQsV0FEWDtBQUVFLGFBQU8sRUFBRXRCLE9BRlg7QUFHRSxlQUFTLEVBQUMsZ0JBSFo7QUFBQSw2QkFLRSxxRUFBQywyREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQTFCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hQO0FBQ0E7QUFDQTs7QUFDQSxNQUFNeUIsV0FBVyxHQUFHLG1CQUFNO0FBQUssS0FBRyxFQUFFQyxnRUFBVjtBQUF1QixLQUFHLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUExQjs7QUFDZSxTQUFTQyxLQUFULENBQWU7QUFDNUJDLEtBRDRCO0FBRTVCQyxLQUFHLEdBQUcsYUFGc0I7QUFHNUJDLFVBSDRCO0FBSTVCQyxRQUo0QjtBQUs1QlAsV0FMNEI7QUFNNUJRO0FBTjRCLENBQWYsRUFjWjtBQUNELHNCQUNFLHFFQUFDLCtDQUFEO0FBQ0UsYUFBUyxFQUFFLEtBRGI7QUFFRSxTQUFLLEVBQUVBLEtBRlQ7QUFHRSxPQUFHLEVBQUVKLEdBSFA7QUFLRSxPQUFHLEVBQUVDLEdBTFA7QUFNRSxVQUFNLGVBQUUscUVBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTlY7QUFPRSxZQUFRLGVBQUUscUVBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUFo7QUFRRSxhQUFTLEVBQUVMO0FBUmIsS0FJT0ksR0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFZRCxDOzs7Ozs7Ozs7Ozs7QUMvQkQ7QUFBZSwrRUFBZ0IsNC9FOzs7Ozs7Ozs7Ozs7QUNBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFTyxNQUFNSyxXQUFXLEdBQUc5Qyx3REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLHNHQUlQOEMseUVBQVEsQ0FBQyxZQUFELEVBQWUsWUFBZixDQUpELENBQWpCO0FBU0EsTUFBTUMsWUFBWSxHQUFHaEQsd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSwrV0FTSDhDLHlFQUFRLENBQUMsY0FBRCxFQUFpQixTQUFqQixDQVRMLENBQWxCO0FBK0JBLE1BQU1FLFdBQVcsR0FBR2pELHdEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsNEhBQWpCO0FBWUEsTUFBTWlELEtBQUssR0FBR2xELHdEQUFNLENBQUNtRCxFQUFWO0FBQUE7QUFBQTtBQUFBLHVOQUNESix5RUFBUSxDQUFDLFlBQUQsRUFBZSxZQUFmLENBRFAsRUFFSEEseUVBQVEsQ0FBQyxnQkFBRCxFQUFtQixJQUFuQixDQUZMLEVBR0RBLHlFQUFRLENBQUMscUJBQUQsRUFBd0IsS0FBeEIsQ0FIUCxFQUlQQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLFNBQXhCLENBSkQsQ0FBWDtBQWlCQSxNQUFNSyxJQUFJLEdBQUdwRCx3REFBTSxDQUFDNkIsSUFBVjtBQUFBO0FBQUE7QUFBQSxrSEFDQWtCLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FEUixFQUVGQSx5RUFBUSxDQUFDLGNBQUQsRUFBaUIsSUFBakIsQ0FGTixFQUdBQSx5RUFBUSxDQUFDLHFCQUFELEVBQXdCLEtBQXhCLENBSFIsRUFJTkEseUVBQVEsQ0FBQyxxQkFBRCxFQUF3QixTQUF4QixDQUpGLEVBT0FBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQVBSLENBQVY7QUFXQSxNQUFNTSxLQUFLLEdBQUdyRCx3REFBTSxDQUFDNkIsSUFBVjtBQUFBO0FBQUE7QUFBQSxpSkFDRGtCLHlFQUFRLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FEUCxFQUVIQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBRkwsRUFHREEseUVBQVEsQ0FBQyxrQkFBRCxFQUFxQixLQUFyQixDQUhQLEVBSVBBLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsU0FBckIsQ0FKRCxFQVFJQSx5RUFBUSxDQUFDLGdCQUFELEVBQW1CLElBQW5CLENBUlosQ0FBWDtBQVlBLE1BQU1PLFVBQVUsR0FBR3RELHdEQUFNLENBQUN1RCwrREFBRCxDQUFUO0FBQUE7QUFBQTtBQUFBLGtkQUNEUix5RUFBUSxDQUFDLHdCQUFELEVBQTJCLFNBQTNCLENBRFAsRUFHWkEseUVBQVEsQ0FBQyxjQUFELEVBQWlCLFNBQWpCLENBSEksRUFJSkEseUVBQVEsQ0FBQyxXQUFELEVBQWMsTUFBZCxDQUpKLEVBVVJBLHlFQUFRLENBQUMsY0FBRCxFQUFpQixJQUFqQixDQVZBLEVBV05BLHlFQUFRLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsQ0FYRixFQStCQ0EseUVBQVEsQ0FBQyx3QkFBRCxFQUEyQixTQUEzQixDQS9CVCxDQUFoQjtBQXNDQSxNQUFNZCxPQUFPLEdBQUdqQyx3REFBTSxDQUFDd0Qsa0VBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxpSUFBYixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdklQO0FBQ0E7QUFDQTtBQUNBO0FBVUE7O0FBdUJBLE1BQU1DLFdBQXVDLEdBQUcsVUFtQjFDO0FBQUEsTUFuQjJDO0FBQy9DQyxTQUQrQztBQUUvQ0MsU0FGK0M7QUFHL0NDLFVBSCtDO0FBSS9DQyxTQUorQztBQUsvQ0MsYUFMK0M7QUFNL0NDLHFCQU4rQztBQU8vQ0MsZ0JBUCtDO0FBUS9DQyxhQVIrQztBQVMvQ0MsY0FUK0M7QUFVL0M5QixTQVYrQztBQVcvQytCLFlBWCtDO0FBWS9DQyxZQVorQztBQWEvQ0MsYUFiK0M7QUFjL0NDLGFBZCtDO0FBZS9DQyxRQWYrQztBQWdCL0NDLGNBaEIrQztBQWlCL0NDO0FBakIrQyxHQW1CM0M7QUFBQSxNQUREQyxLQUNDOztBQUNKLFFBQU07QUFBRUMsV0FBRjtBQUFXQyxjQUFYO0FBQXVCQyxXQUF2QjtBQUFnQ0M7QUFBaEMsTUFBNkNDLHNFQUFPLEVBQTFEOztBQUVBLFFBQU1DLGNBQWMsR0FBSUMsQ0FBRCxJQUFPO0FBQzVCQSxLQUFDLENBQUNDLGVBQUY7QUFDQVAsV0FBTyxDQUFDSixJQUFELENBQVA7QUFDRCxHQUhEOztBQUtBLFFBQU1ZLGlCQUFpQixHQUFJRixDQUFELElBQU87QUFDL0JBLEtBQUMsQ0FBQ0MsZUFBRjtBQUNBTixjQUFVLENBQUNMLElBQUQsQ0FBVjtBQUNELEdBSEQsQ0FSSSxDQVlKOzs7QUFFQSxzQkFDRSxxRUFBQyxvRUFBRDtBQUFhLFdBQU8sRUFBRUUsT0FBdEI7QUFBK0IsYUFBUyxFQUFDLGVBQXpDO0FBQUEsNEJBQ0UscUVBQUMscUVBQUQ7QUFBYyxlQUFTLEVBQUVLLFFBQVEsQ0FBQ1AsSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUVhLEVBQVAsQ0FBUixJQUFzQixTQUEvQztBQUFBLDhCQUNFLHFFQUFDLDhEQUFEO0FBQ0UsV0FBRyxFQUFFekIsS0FEUDtBQUVFLGlCQUFTLEVBQUMsZUFGWjtBQUdFLGFBQUssRUFBRTtBQUFFMEIsa0JBQVEsRUFBRTtBQUFaLFNBSFQ7QUFJRSxXQUFHLEVBQUUzQjtBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFRRyxDQUFDb0IsUUFBUSxDQUFDUCxJQUFELGFBQUNBLElBQUQsdUJBQUNBLElBQUksQ0FBRWEsRUFBUCxDQUFULGdCQUNDLHFFQUFDLG1FQUFEO0FBQVksaUJBQVMsRUFBQyxhQUF0QjtBQUFvQyxlQUFPLEVBQUVKLGNBQTdDO0FBQUEsK0JBQ0UscUVBQUMsb0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREQsZ0JBS0MscUVBQUMsZ0VBQUQ7QUFDRSxhQUFLLEVBQUVILE9BQU8sQ0FBQ04sSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUVhLEVBQVAsQ0FBUCxDQUFrQkUsUUFEM0I7QUFFRSxtQkFBVyxFQUFFSCxpQkFGZjtBQUdFLG1CQUFXLEVBQUVIO0FBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFxQkUscUVBQUMsb0VBQUQ7QUFBQSw4QkFDRSxxRUFBQyw4REFBRDtBQUFBLG1CQUNHYixRQURILEVBRUdOLEtBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBTUUscUVBQUMsOERBQUQ7QUFBQSxrQkFBUUg7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GLGVBT0UscUVBQUMsNkRBQUQ7QUFBQSxrQkFBT0U7QUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQ0QsQ0FsRUQ7O0FBb0VlSCwwRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4R0E7QUFDTyxNQUFNOEIsbUJBQW1CLEdBQUcsQ0FBQ0MsS0FBRCxFQUFRQyxNQUFNLEdBQUcsSUFBakIsS0FBMEI7QUFDM0QsTUFBSUQsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssQ0FBQ0UsTUFBTixLQUFpQixDQUF2QyxFQUEwQyxPQUFPLENBQVA7QUFDMUMsUUFBTUMsUUFBUSxHQUFHSCxLQUFLLENBQUNJLE1BQU4sQ0FBYSxDQUFDQyxLQUFELEVBQVFDLElBQVIsS0FBaUI7QUFDN0MsUUFBSUEsSUFBSSxDQUFDaEMsU0FBVCxFQUFvQjtBQUNsQixhQUFPK0IsS0FBSyxHQUFHQyxJQUFJLENBQUNoQyxTQUFMLEdBQWlCZ0MsSUFBSSxDQUFDUixRQUFyQztBQUNEOztBQUNELFdBQU9PLEtBQUssR0FBR0MsSUFBSSxDQUFDakMsS0FBTCxHQUFhaUMsSUFBSSxDQUFDUixRQUFqQztBQUNELEdBTGdCLEVBS2QsQ0FMYyxDQUFqQixDQUYyRCxDQVEzRDs7QUFDQSxRQUFNUyxRQUFRLEdBQUdOLE1BQU0sR0FDbEJFLFFBQVEsR0FBR0ssTUFBTSxDQUFDUCxNQUFNLENBQUMxQixpQkFBUixDQUFsQixHQUFnRCxHQUQ3QixHQUVuQixDQUZKLENBVDJELENBWTNEO0FBQ0E7O0FBQ0EsU0FBTzRCLFFBQVEsR0FBR0ksUUFBbEI7QUFDRCxDQWZNLEMsQ0FnQlA7O0FBQ0EsTUFBTUUsYUFBYSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUN2QyxRQUFNQyxxQkFBcUIsR0FBR0YsS0FBSyxDQUFDVixLQUFOLENBQVlhLFNBQVosQ0FDM0JQLElBQUQsSUFBVUEsSUFBSSxDQUFDVixFQUFMLEtBQVllLE1BQU0sQ0FBQ0csT0FBUCxDQUFlbEIsRUFEVCxDQUE5Qjs7QUFJQSxNQUFJZ0IscUJBQXFCLEdBQUcsQ0FBQyxDQUE3QixFQUFnQztBQUM5QixVQUFNRyxRQUFRLEdBQUcsQ0FBQyxHQUFHTCxLQUFLLENBQUNWLEtBQVYsQ0FBakI7QUFDQWUsWUFBUSxDQUFDSCxxQkFBRCxDQUFSLENBQWdDZCxRQUFoQyxJQUE0Q2EsTUFBTSxDQUFDRyxPQUFQLENBQWVoQixRQUEzRDtBQUNBLFdBQU9pQixRQUFQO0FBQ0Q7O0FBQ0QsU0FBTyxDQUFDLEdBQUdMLEtBQUssQ0FBQ1YsS0FBVixFQUFpQlcsTUFBTSxDQUFDRyxPQUF4QixDQUFQO0FBQ0QsQ0FYRCxDLENBYUE7OztBQUNBLE1BQU1FLGtCQUFrQixHQUFHLENBQUNOLEtBQUQsRUFBUUMsTUFBUixLQUFtQjtBQUM1QyxTQUFPRCxLQUFLLENBQUNWLEtBQU4sQ0FBWUksTUFBWixDQUFtQixDQUFDYSxHQUFELEVBQU1YLElBQU4sS0FBZTtBQUN2QyxRQUFJQSxJQUFJLENBQUNWLEVBQUwsS0FBWWUsTUFBTSxDQUFDRyxPQUFQLENBQWVsQixFQUEvQixFQUFtQztBQUNqQyxZQUFNc0IsV0FBVyxHQUFHWixJQUFJLENBQUNSLFFBQUwsR0FBZ0JhLE1BQU0sQ0FBQ0csT0FBUCxDQUFlaEIsUUFBbkQ7QUFFQSxhQUFPb0IsV0FBVyxHQUFHLENBQWQsR0FDSCxDQUFDLEdBQUdELEdBQUosa0NBQWNYLElBQWQ7QUFBb0JSLGdCQUFRLEVBQUVvQjtBQUE5QixTQURHLEdBRUgsQ0FBQyxHQUFHRCxHQUFKLENBRko7QUFHRDs7QUFDRCxXQUFPLENBQUMsR0FBR0EsR0FBSixFQUFTWCxJQUFULENBQVA7QUFDRCxHQVRNLEVBU0osRUFUSSxDQUFQO0FBVUQsQ0FYRDs7QUFhQSxNQUFNYSxpQkFBaUIsR0FBRyxDQUFDVCxLQUFELEVBQVFDLE1BQVIsS0FBbUI7QUFDM0MsU0FBT0QsS0FBSyxDQUFDVixLQUFOLENBQVlvQixNQUFaLENBQW9CZCxJQUFELElBQVVBLElBQUksQ0FBQ1YsRUFBTCxLQUFZZSxNQUFNLENBQUNHLE9BQVAsQ0FBZWxCLEVBQXhELENBQVA7QUFDRCxDQUZEOztBQUlPLE1BQU15QixPQUFPLEdBQUcsQ0FBQ1gsS0FBRCxFQUFRQyxNQUFSLEtBQW1CO0FBQ3hDLFVBQVFBLE1BQU0sQ0FBQ1csSUFBZjtBQUNFLFNBQUssV0FBTDtBQUNFLDZDQUFZWixLQUFaLEdBQXNCQyxNQUFNLENBQUNHLE9BQTdCOztBQUNGLFNBQUssYUFBTDtBQUNFLDZDQUFZSixLQUFaO0FBQW1CYSxjQUFNLEVBQUUsQ0FBQ2IsS0FBSyxDQUFDYTtBQUFsQzs7QUFDRixTQUFLLFVBQUw7QUFDRSw2Q0FBWWIsS0FBWjtBQUFtQlYsYUFBSyxFQUFFUyxhQUFhLENBQUNDLEtBQUQsRUFBUUMsTUFBUjtBQUF2Qzs7QUFDRixTQUFLLGFBQUw7QUFDRSw2Q0FBWUQsS0FBWjtBQUFtQlYsYUFBSyxFQUFFZ0Isa0JBQWtCLENBQUNOLEtBQUQsRUFBUUMsTUFBUjtBQUE1Qzs7QUFDRixTQUFLLHNCQUFMO0FBQ0UsNkNBQVlELEtBQVo7QUFBbUJWLGFBQUssRUFBRW1CLGlCQUFpQixDQUFDVCxLQUFELEVBQVFDLE1BQVI7QUFBM0M7O0FBQ0YsU0FBSyxZQUFMO0FBQ0UsNkNBQVlELEtBQVo7QUFBbUJWLGFBQUssRUFBRTtBQUExQjs7QUFDRixTQUFLLGNBQUw7QUFDRSw2Q0FBWVUsS0FBWjtBQUFtQlQsY0FBTSxFQUFFVSxNQUFNLENBQUNHO0FBQWxDOztBQUNGLFNBQUssZUFBTDtBQUNFLDZDQUFZSixLQUFaO0FBQW1CVCxjQUFNLEVBQUU7QUFBM0I7O0FBQ0YsU0FBSyxtQkFBTDtBQUNFLDZDQUFZUyxLQUFaO0FBQW1CYyxvQkFBWSxFQUFFLENBQUNkLEtBQUssQ0FBQ2M7QUFBeEM7O0FBQ0Y7QUFDRSxZQUFNLElBQUlDLEtBQUosQ0FBVyxtQkFBa0JkLE1BQU0sQ0FBQ1csSUFBSyxFQUF6QyxDQUFOO0FBcEJKO0FBc0JELENBdkJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pEUDtBQUNBO0FBQ0E7QUFDQSxNQUFNSSxXQUFXLGdCQUFHQywyREFBYSxDQUFDLEVBQUQsQ0FBakM7QUFDQSxNQUFNQyxhQUFhLEdBQUc7QUFDcEJMLFFBQU0sRUFBRSxLQURZO0FBRXBCdkIsT0FBSyxFQUFFLEVBRmE7QUFHcEJ3QixjQUFZLEVBQUUsS0FITTtBQUlwQnZCLFFBQU0sRUFBRTtBQUpZLENBQXRCOztBQU9BLE1BQU00QixjQUFjLEdBQUcsQ0FBQ0MsV0FBVyxHQUFHRixhQUFmLEtBQWlDO0FBQUE7O0FBQ3RELFFBQU07QUFBQSxPQUFDbEIsS0FBRDtBQUFBLE9BQVFxQjtBQUFSLE1BQW9CQyx3REFBVSxDQUFDWCxxREFBRCxFQUFVUyxXQUFWLENBQXBDOztBQUVBLFFBQU1HLGNBQWMsR0FBRyxDQUFDM0IsSUFBRCxFQUFPUixRQUFRLEdBQUcsQ0FBbEIsS0FBd0I7QUFDN0NpQyxZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLFVBQVI7QUFBb0JSLGFBQU8sa0NBQU9SLElBQVA7QUFBYVI7QUFBYjtBQUEzQixLQUFELENBQVI7QUFDRCxHQUZEOztBQUlBLFFBQU1vQyxpQkFBaUIsR0FBRyxDQUFDNUIsSUFBRCxFQUFPUixRQUFRLEdBQUcsQ0FBbEIsS0FBd0I7QUFDaERpQyxZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLGFBQVI7QUFBdUJSLGFBQU8sa0NBQU9SLElBQVA7QUFBYVI7QUFBYjtBQUE5QixLQUFELENBQVI7QUFDRCxHQUZEOztBQUlBLFFBQU1xQyx3QkFBd0IsR0FBSTdCLElBQUQsSUFBVTtBQUN6Q3lCLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUUsc0JBQVI7QUFBZ0NSLGFBQU8sRUFBRVI7QUFBekMsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFJQSxRQUFNOEIsZ0JBQWdCLEdBQUcsTUFBTTtBQUM3QkwsWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWUsaUJBQWlCLEdBQUcsTUFBTTtBQUM5Qk4sWUFBUSxDQUFDO0FBQUVULFVBQUksRUFBRTtBQUFSLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTWdCLGFBQWEsR0FBSXJDLE1BQUQsSUFBWTtBQUNoQzhCLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUUsY0FBUjtBQUF3QlIsYUFBTyxFQUFFYjtBQUFqQyxLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU1zQyxtQkFBbUIsR0FBRyxNQUFNO0FBQ2hDUixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFO0FBQVIsS0FBRCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNa0IsbUJBQW1CLEdBQUkxQixPQUFELElBQWE7QUFDdkNpQixZQUFRLENBQUM7QUFBRVQsVUFBSSxFQUFFLFdBQVI7QUFBcUJSO0FBQXJCLEtBQUQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTTJCLGdCQUFnQixHQUFHLE1BQU07QUFDN0JWLFlBQVEsQ0FBQztBQUFFVCxVQUFJLEVBQUU7QUFBUixLQUFELENBQVI7QUFDRCxHQUZEOztBQUdBLFFBQU1vQixlQUFlLEdBQUk5QyxFQUFELElBQVE7QUFBQTs7QUFDOUIsMkJBQU9jLEtBQUssQ0FBQ1YsS0FBYixpREFBTyxhQUFhMkMsSUFBYixDQUFtQnJDLElBQUQsSUFBVUEsSUFBSSxDQUFDVixFQUFMLEtBQVlBLEVBQXhDLENBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU1nRCxjQUFjLEdBQUloRCxFQUFELElBQVE7QUFBQTs7QUFDN0IsNEJBQU9jLEtBQUssQ0FBQ1YsS0FBYixrREFBTyxjQUFhNkMsSUFBYixDQUFtQnZDLElBQUQsSUFBVUEsSUFBSSxDQUFDVixFQUFMLEtBQVlBLEVBQXhDLENBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU1rRCxpQkFBaUIsR0FBRyxNQUFNL0MseUVBQW1CLENBQUNXLEtBQUssQ0FBQ1YsS0FBUCxDQUFuQixDQUFpQytDLE9BQWpDLENBQXlDLENBQXpDLENBQWhDOztBQUNBLFFBQU1DLHNCQUFzQixHQUFHLE1BQzdCakQseUVBQW1CLENBQUNXLEtBQUssQ0FBQ1YsS0FBUCxFQUFjVSxLQUFLLENBQUNULE1BQXBCLENBQW5CLENBQStDOEMsT0FBL0MsQ0FBdUQsQ0FBdkQsQ0FERjs7QUFHQSxRQUFNRSxXQUFXLEdBQUcsTUFBTTtBQUFBOztBQUN4QixVQUFNNUMsS0FBSyxHQUFHTix5RUFBbUIsQ0FBQ1csS0FBSyxDQUFDVixLQUFQLENBQWpDO0FBQ0EsVUFBTU8sUUFBUSxHQUFHRyxLQUFLLENBQUNULE1BQU4sR0FDWkksS0FBSyxHQUFHRyxNQUFNLGtCQUFDRSxLQUFLLENBQUNULE1BQVAsa0RBQUMsY0FBYzFCLGlCQUFmLENBQWYsR0FBb0QsR0FEdkMsR0FFYixDQUZKO0FBR0EsV0FBT2dDLFFBQVEsQ0FBQ3dDLE9BQVQsQ0FBaUIsQ0FBakIsQ0FBUDtBQUNELEdBTkQ7O0FBT0EsUUFBTUcsYUFBYSxvQkFBR3hDLEtBQUssQ0FBQ1YsS0FBVCxrREFBRyxjQUFhSSxNQUFiLENBQ3BCLENBQUNhLEdBQUQsRUFBTVgsSUFBTixLQUFlVyxHQUFHLEdBQUdYLElBQUksQ0FBQ1IsUUFETixFQUVwQixDQUZvQixDQUF0QjtBQUlBLFNBQU87QUFDTFksU0FESztBQUVMd0MsaUJBRks7QUFHTFYsdUJBSEs7QUFJTFAsa0JBSks7QUFLTEMscUJBTEs7QUFNTEMsNEJBTks7QUFPTEMsb0JBUEs7QUFRTE0sbUJBUks7QUFTTEUsa0JBVEs7QUFVTFAscUJBVks7QUFXTFcsMEJBWEs7QUFZTEYscUJBWks7QUFhTFIsaUJBYks7QUFjTEMsdUJBZEs7QUFlTFUsZUFmSztBQWdCTFI7QUFoQkssR0FBUDtBQWtCRCxDQXhFRDs7QUEwRU8sTUFBTVUsWUFBWSxHQUFHLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWtCO0FBQUE7O0FBQzVDLFFBQU07QUFDSjFDLFNBREk7QUFFSjhCLHVCQUZJO0FBR0pVLGlCQUhJO0FBSUpqQixrQkFKSTtBQUtKQyxxQkFMSTtBQU1KQyw0QkFOSTtBQU9KQyxvQkFQSTtBQVFKTSxtQkFSSTtBQVNKRSxrQkFUSTtBQVVKUCxxQkFWSTtBQVdKVywwQkFYSTtBQVlKVixpQkFaSTtBQWFKQyx1QkFiSTtBQWNKTyxxQkFkSTtBQWVKRyxlQWZJO0FBZ0JKUjtBQWhCSSxNQWlCRlosY0FBYyxFQWpCbEI7QUFrQkEsUUFBTTtBQUFFd0IsY0FBRjtBQUFjQztBQUFkLE1BQXdCQyxvRUFBVSxDQUFDN0MsS0FBRCxFQUFROEIsbUJBQVIsQ0FBeEM7QUFFQSxzQkFDRSxxRUFBQyxXQUFELENBQWEsUUFBYjtBQUNFLFNBQUssRUFBRTtBQUNMakIsWUFBTSxFQUFFYixLQUFLLENBQUNhLE1BRFQ7QUFFTHZCLFdBQUssRUFBRVUsS0FBSyxDQUFDVixLQUZSO0FBR0xDLFlBQU0sRUFBRVMsS0FBSyxDQUFDVCxNQUhUO0FBSUx1QixrQkFBWSxFQUFFZCxLQUFLLENBQUNjLFlBSmY7QUFLTGdDLG9CQUFjLG1CQUFFOUMsS0FBSyxDQUFDVixLQUFSLGtEQUFFLGNBQWFFLE1BTHhCO0FBTUx1RCxnQkFBVSxFQUFFUCxhQU5QO0FBT0wvRCxhQUFPLEVBQUU4QyxjQVBKO0FBUUw3QyxnQkFBVSxFQUFFOEMsaUJBUlA7QUFTTGxCLHdCQUFrQixFQUFFbUIsd0JBVGY7QUFVTHVCLGVBQVMsRUFBRXRCLGdCQVZOO0FBV0w5QyxjQUFRLEVBQUVvRCxlQVhMO0FBWUxyRCxhQUFPLEVBQUV1RCxjQVpKO0FBYUxlLGdCQUFVLEVBQUV0QixpQkFiUDtBQWNMdUIsb0JBQWMsRUFBRVosc0JBZFg7QUFlTGEsNEJBQXNCLEVBQUVmLGlCQWZuQjtBQWdCTGdCLGlCQUFXLEVBQUV4QixhQWhCUjtBQWlCTHlCLGtCQUFZLEVBQUV4QixtQkFqQlQ7QUFrQkx5Qix1QkFBaUIsRUFBRWYsV0FsQmQ7QUFtQkxSO0FBbkJLLEtBRFQ7QUFBQSxjQXVCR1c7QUF2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBMkJELENBaERNO0FBa0RBLE1BQU03RCxPQUFPLEdBQUcsTUFBTTBFLHdEQUFVLENBQUN2QyxXQUFELENBQWhDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZJUDtBQUNBOztBQUNBLE1BQU13QyxhQUFhLEdBQUl0SCxLQUFELElBQ3BCQSxLQUFLLENBQUN1SCxXQUFOLENBQWtCQyxJQUFsQixLQUEyQixPQUEzQixJQUFzQ3hILEtBQUssQ0FBQ3VILFdBQU4sQ0FBa0JDLElBQWxCLEtBQTJCLFFBRG5FOztBQUdBLE1BQU1DLFNBQVMsR0FBRyxDQUFDekgsS0FBRCxFQUFhMEgsWUFBYixLQUFvQztBQUNwRCxNQUFJLENBQUMxSCxLQUFMLEVBQVksT0FBTzBILFlBQVAsQ0FEd0MsQ0FFcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFJO0FBQ0YsVUFBTUMsS0FBSyxHQUFHQyxJQUFJLENBQUNELEtBQUwsQ0FBVzNILEtBQVgsQ0FBZDtBQUNBLFdBQU8ySCxLQUFQO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaLFdBQU9ILFlBQVA7QUFDRDtBQUNGLENBYkQ7O0FBZUEsTUFBTUksT0FBTyxHQUFJOUgsS0FBRCxJQUFXO0FBQ3pCLE1BQUksQ0FBQ3NILGFBQWEsQ0FBQ3RILEtBQUQsQ0FBbEIsRUFBMkI7QUFDekIsV0FBT0EsS0FBUDtBQUNEOztBQUNELFNBQU80SCxJQUFJLENBQUNHLFNBQUwsQ0FBZS9ILEtBQWYsQ0FBUDtBQUNELENBTEQ7O0FBTUEsTUFBTWdJLGVBQWUsR0FBRyxDQUFDQyxJQUFELEVBQU85RixJQUFQLEtBQWdCO0FBQ3RDLFNBQU8sSUFBSStGLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDdEMsVUFBTUMsR0FBRyxHQUFJLEdBQUVKLElBQUksQ0FBQ0ksR0FBSSxVQUF4QjtBQUNBQyxzREFBVyxDQUFDN0YsT0FBWixDQUFvQjRGLEdBQXBCLEVBQXlCLENBQUNSLEdBQUQsRUFBTVUsT0FBTixLQUFrQjtBQUN6QyxVQUFJQSxPQUFPLEtBQUtOLElBQUksQ0FBQ00sT0FBckIsRUFBOEI7QUFDNUJwRyxZQUFJLEdBQUc4RixJQUFJLENBQUNPLE9BQUwsQ0FBYXJHLElBQWIsQ0FBUDtBQUNBbUcsMERBQVcsQ0FBQ0csT0FBWixDQUFvQlIsSUFBSSxDQUFDSSxHQUF6QixFQUE4QlosU0FBUyxDQUFDdEYsSUFBRCxDQUF2QyxFQUFnRDBGLEdBQUQsSUFBUztBQUN0RCxjQUFJQSxHQUFKLEVBQVMsT0FBT08sTUFBTSxDQUFDUCxHQUFELENBQWI7QUFDVFMsNERBQVcsQ0FBQ0csT0FBWixDQUFvQkosR0FBcEIsRUFBeUJKLElBQUksQ0FBQ00sT0FBOUIsRUFBd0NWLEdBQUQsSUFBUztBQUM5QyxnQkFBSUEsR0FBSixFQUFTLE9BQU9PLE1BQU0sQ0FBQ1AsR0FBRCxDQUFiO0FBQ1QsbUJBQU9NLE9BQU8sQ0FBQ2hHLElBQUQsQ0FBZDtBQUNELFdBSEQ7QUFJRCxTQU5EO0FBT0QsT0FURCxNQVNPO0FBQ0xnRyxlQUFPLENBQUNoRyxJQUFELENBQVA7QUFDRDtBQUNGLEtBYkQ7QUFjRCxHQWhCTSxDQUFQO0FBaUJELENBbEJEOztBQW9CQSxNQUFNdUcsTUFBTSxHQUFHO0FBQ2JMLEtBQUcsRUFBRSxVQURRO0FBRWJFLFNBQU8sRUFBRSxDQUZJO0FBR2JDLFNBQU8sRUFBRzFFLEtBQUQsSUFBVztBQUNsQiw2QkFBWUEsS0FBWjtBQUNEO0FBTFksQ0FBZjtBQVFPLE1BQU02QyxVQUFVLEdBQUcsQ0FBQzdDLEtBQUQsRUFBUTZFLFFBQVIsS0FBcUI7QUFDN0MsUUFBTTtBQUFBLE9BQUNsQyxVQUFEO0FBQUEsT0FBYW1DO0FBQWIsTUFBOEJDLHNEQUFRLENBQUMsS0FBRCxDQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDbkMsS0FBRDtBQUFBLE9BQVFvQztBQUFSLE1BQW9CRCxzREFBUSxDQUFDLElBQUQsQ0FBbEM7QUFFQUUseURBQVMsQ0FBQyxNQUFNO0FBQ2QsbUJBQWVDLElBQWYsR0FBc0I7QUFDcEIsWUFBTVYsa0RBQVcsQ0FBQzdGLE9BQVosQ0FBb0JpRyxNQUFNLENBQUNMLEdBQTNCLEVBQWdDLENBQUNSLEdBQUQsRUFBTTdILEtBQU4sS0FBZ0I7QUFDcEQsWUFBSTZILEdBQUosRUFBUztBQUNQZSx1QkFBYSxDQUFDLElBQUQsQ0FBYjtBQUNBLGlCQUFPRSxRQUFRLENBQUNqQixHQUFELENBQWY7QUFDRCxTQUptRCxDQUtwRDs7O0FBQ0EsY0FBTW9CLGFBQWEsR0FBR3hCLFNBQVMsQ0FBQ3pILEtBQUQsQ0FBL0I7O0FBQ0EsWUFBSSxPQUFPMEksTUFBTSxDQUFDRixPQUFkLEtBQTBCLFVBQTlCLEVBQTBDO0FBQ3hDUix5QkFBZSxDQUFDVSxNQUFELEVBQVNPLGFBQVQsQ0FBZixDQUNHQyxJQURILENBQ1MvRyxJQUFELElBQVV3RyxRQUFRLENBQUN4RyxJQUFELENBRDFCLEVBRUcrRyxJQUZILENBRVEsTUFBTU4sYUFBYSxDQUFDLElBQUQsQ0FGM0I7QUFHRCxTQUpELE1BSU87QUFDTEQsa0JBQVEsQ0FBQ00sYUFBRCxDQUFSO0FBQ0FMLHVCQUFhLENBQUMsSUFBRCxDQUFiO0FBQ0Q7QUFDRixPQWZLLENBQU47QUFnQkQ7O0FBQ0RJLFFBQUk7QUFDTCxHQXBCUSxFQW9CTixFQXBCTSxDQUFUO0FBc0JBRCx5REFBUyxDQUFDLE1BQU07QUFDZDtBQUNBO0FBQ0E7QUFDQVQsc0RBQVcsQ0FBQ0csT0FBWixDQUFvQkMsTUFBTSxDQUFDTCxHQUEzQixFQUFnQ1AsT0FBTyxDQUFDaEUsS0FBRCxDQUF2QztBQUNELEdBTFEsRUFLTixDQUFDQSxLQUFELENBTE0sQ0FBVDtBQU9BLFNBQU87QUFDTDJDLGNBREs7QUFFTEM7QUFGSyxHQUFQO0FBSUQsQ0FyQ00sQyIsImZpbGUiOiI5LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0Jztcbi8vIFNWRyBwbHVzIGljb25cbmV4cG9ydCBjb25zdCBQbHVzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMTJweCcsXG4gIGhlaWdodCA9ICcxMnB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHdpZHRoPXt3aWR0aH1cbiAgICAgIGhlaWdodD17aGVpZ2h0fVxuICAgICAgdmlld0JveD1cIjAgMCAxMiAxMlwiXG4gICAgPlxuICAgICAgPGdcbiAgICAgICAgaWQ9XCJHcm91cF8zMzUxXCJcbiAgICAgICAgZGF0YS1uYW1lPVwiR3JvdXAgMzM1MVwiXG4gICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtMTM2NyAtMTkwKVwiXG4gICAgICA+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDUyMFwiXG4gICAgICAgICAgd2lkdGg9XCIxMlwiXG4gICAgICAgICAgaGVpZ2h0PVwiMlwiXG4gICAgICAgICAgcng9XCIxXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMTM2NyAxOTUpXCJcbiAgICAgICAgICBmaWxsPXtjb2xvcn1cbiAgICAgICAgLz5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgNTIxXCJcbiAgICAgICAgICB3aWR0aD1cIjEyXCJcbiAgICAgICAgICBoZWlnaHQ9XCIyXCJcbiAgICAgICAgICByeD1cIjFcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgxMzc0IDE5MCkgcm90YXRlKDkwKVwiXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICA8L2c+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuXG4vLyBTVkcgbWludXMgaWNvblxuZXhwb3J0IGNvbnN0IE1pbnVzID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMTJweCcsXG4gIGhlaWdodCA9ICcycHgnLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PVwiMCAwIDEyIDJcIlxuICAgID5cbiAgICAgIDxyZWN0XG4gICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSA1MjJcIlxuICAgICAgICB3aWR0aD1cIjEyXCJcbiAgICAgICAgaGVpZ2h0PVwiMlwiXG4gICAgICAgIHJ4PVwiMVwiXG4gICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFBsdXNPdXRsaW5lID0gKHtcbiAgY29sb3IgPSAnY3VycmVudENvbG9yJyxcbiAgd2lkdGggPSAnMTZweCcsXG4gIGhlaWdodCA9ICcxNnB4Jyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnXG4gICAgICB3aWR0aD17d2lkdGh9XG4gICAgICBoZWlnaHQ9e2hlaWdodH1cbiAgICAgIHZpZXdCb3g9JzAgMCAxNiAxNidcbiAgICA+XG4gICAgICA8Z1xuICAgICAgICBpZD0nR3JvdXBfMzM3MSdcbiAgICAgICAgZGF0YS1uYW1lPSdHcm91cCAzMzcxJ1xuICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgtMTUzOSAtMjMxNy41KSdcbiAgICAgID5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBpZD0nUmVjdGFuZ2xlXzY4MCdcbiAgICAgICAgICBkYXRhLW5hbWU9J1JlY3RhbmdsZSA2ODAnXG4gICAgICAgICAgd2lkdGg9JzE2J1xuICAgICAgICAgIGhlaWdodD0nMS41J1xuICAgICAgICAgIHRyYW5zZm9ybT0ndHJhbnNsYXRlKDE1MzkgMjMyNSknXG4gICAgICAgICAgZmlsbD17Y29sb3J9XG4gICAgICAgIC8+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgaWQ9J1JlY3RhbmdsZV82ODEnXG4gICAgICAgICAgZGF0YS1uYW1lPSdSZWN0YW5nbGUgNjgxJ1xuICAgICAgICAgIHdpZHRoPScxNidcbiAgICAgICAgICBoZWlnaHQ9JzEuNSdcbiAgICAgICAgICB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgxNTQ3LjUgMjMxNy41KSByb3RhdGUoOTApJ1xuICAgICAgICAgIGZpbGw9e2NvbG9yfVxuICAgICAgICAvPlxuICAgICAgPC9nPlxuICAgIDwvc3ZnPlxuICApO1xufTtcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xuaW1wb3J0IGNzcyBmcm9tICdAc3R5bGVkLXN5c3RlbS9jc3MnO1xuaW1wb3J0IHsgdmFyaWFudCB9IGZyb20gJ3N0eWxlZC1zeXN0ZW0nO1xuZXhwb3J0IGNvbnN0IENvdW50ZXJCb3ggPSBzdHlsZWQuZGl2PGFueT4oXG4gIGNzcyh7XG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGJhY2tncm91bmRDb2xvcjogJ3ByaW1hcnkucmVndWxhcicsXG4gICAgY29sb3I6ICd3aGl0ZScsXG4gICAgZm9udFNpemU6ICdiYXNlJyxcbiAgICBmb250V2VpZ2h0OiAnYm9sZCcsXG4gIH0pLFxuICB7XG4gICAgYm9yZGVyUmFkaXVzOiAyMDAsXG4gICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgZmxleFNocmluazogMCxcbiAgICAnJjpmb2N1cyc6IHtcbiAgICAgIG91dGxpbmU6ICdub25lJyxcbiAgICB9LFxuICB9LFxuICB2YXJpYW50KHtcbiAgICB2YXJpYW50czoge1xuICAgICAgaG9yaXpvbnRhbDoge1xuICAgICAgICB3aWR0aDogMTA0LFxuICAgICAgICBoZWlnaHQ6IDM2LFxuICAgICAgfSxcbiAgICAgIHZlcnRpY2FsOiB7XG4gICAgICAgIHdpZHRoOiAzMCxcbiAgICAgICAgaGVpZ2h0OiA5MCxcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbi1yZXZlcnNlJyxcbiAgICAgIH0sXG4gICAgICBsaWdodEhvcml6b250YWw6IHtcbiAgICAgICAgd2lkdGg6IDEwNCxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnZ3JheS4yMDAnLFxuICAgICAgICBjb2xvcjogJ3RleHQuYm9sZCcsXG4gICAgICB9LFxuICAgICAgbGlnaHRWZXJ0aWNhbDoge1xuICAgICAgICB3aWR0aDogMzAsXG4gICAgICAgIGhlaWdodDogOTAsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4tcmV2ZXJzZScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ2dyYXkuMjAwJyxcbiAgICAgICAgY29sb3I6ICd0ZXh0LmJvbGQnLFxuICAgICAgfSxcbiAgICAgIGFsdEhvcml6b250YWw6IHtcbiAgICAgICAgd2lkdGg6IDEwNCxcbiAgICAgICAgaGVpZ2h0OiAzNixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcbiAgICAgIH0sXG4gICAgICBhbHRWZXJ0aWNhbDoge1xuICAgICAgICB3aWR0aDogMzAsXG4gICAgICAgIGhlaWdodDogOTAsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzZweCcsXG4gICAgICB9LFxuICAgICAgZnVsbDoge1xuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgICAgICBoZWlnaHQ6IDM2LFxuICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KVxuKTtcblxuZXhwb3J0IGNvbnN0IENvdW50ZXJCdXR0b24gPSBzdHlsZWQuYnV0dG9uPGFueT4oXG4gIHtcbiAgICBib3JkZXI6ICdub25lJyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgY29sb3I6ICd3aGl0ZScsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICBwYWRkaW5nOiAxMCxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAnJjpob3ZlciwgJjpmb2N1cyc6IHtcbiAgICAgIG91dGxpbmU6ICdub25lJyxcbiAgICB9LFxuICB9LFxuICB2YXJpYW50KHtcbiAgICB2YXJpYW50czoge1xuICAgICAgbGlnaHRIb3Jpem9udGFsOiB7XG4gICAgICAgIGNvbG9yOiAndGV4dC5yZWd1bGFyJyxcbiAgICAgIH0sXG4gICAgICBsaWdodFZlcnRpY2FsOiB7XG4gICAgICAgIGNvbG9yOiAndGV4dC5yZWd1bGFyJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSlcbik7XG5cbmV4cG9ydCBjb25zdCBDb3VudGVyVmFsdWUgPSBzdHlsZWQuc3Bhbih7XG4gIHBvaW50ZXJFdmVudHM6ICdub25lJyxcbn0pO1xuQ291bnRlclZhbHVlLmRpc3BsYXlOYW1lID0gJ0NvdW50ZXJWYWx1ZSc7XG5Db3VudGVyQnV0dG9uLmRpc3BsYXlOYW1lID0gJ0NvdW50ZXJCdXR0b24nO1xuQ291bnRlckJveC5kaXNwbGF5TmFtZSA9ICdDb3VudGVyQm94JztcbkNvdW50ZXJCb3guZGVmYXVsdFByb3BzID0ge1xuICB2YXJpYW50OiAnaG9yaXpvbnRhbCcsXG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFBsdXMsIE1pbnVzIH0gZnJvbSAnYXNzZXRzL2ljb25zL1BsdXNNaW51cyc7XG5pbXBvcnQgeyBDb3VudGVyQm94LCBDb3VudGVyQnV0dG9uLCBDb3VudGVyVmFsdWUgfSBmcm9tICcuL2NvdW50ZXIuc3R5bGUnO1xuaW50ZXJmYWNlIFByb3BzIHtcbiAgb25EZWNyZW1lbnQ6IChlOiBFdmVudCkgPT4gdm9pZDtcbiAgb25JbmNyZW1lbnQ6IChlOiBFdmVudCkgPT4gdm9pZDtcbiAgdmFsdWU6IG51bWJlcjtcbiAgdmFyaWFudD86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgQ291bnRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHtcbiAgb25EZWNyZW1lbnQsXG4gIG9uSW5jcmVtZW50LFxuICB2YWx1ZSxcbiAgdmFyaWFudCxcbiAgY2xhc3NOYW1lLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxDb3VudGVyQm94IHZhcmlhbnQ9e3ZhcmlhbnR9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfT5cbiAgICAgIDxDb3VudGVyQnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9e29uRGVjcmVtZW50fVxuICAgICAgICB2YXJpYW50PXt2YXJpYW50fVxuICAgICAgICBjbGFzc05hbWU9J2NvbnRyb2wtYnV0dG9uJ1xuICAgICAgPlxuICAgICAgICA8TWludXMgLz5cbiAgICAgIDwvQ291bnRlckJ1dHRvbj5cbiAgICAgIDxDb3VudGVyVmFsdWU+e3ZhbHVlfTwvQ291bnRlclZhbHVlPlxuICAgICAgPENvdW50ZXJCdXR0b25cbiAgICAgICAgb25DbGljaz17b25JbmNyZW1lbnR9XG4gICAgICAgIHZhcmlhbnQ9e3ZhcmlhbnR9XG4gICAgICAgIGNsYXNzTmFtZT0nY29udHJvbC1idXR0b24nXG4gICAgICA+XG4gICAgICAgIDxQbHVzIC8+XG4gICAgICA8L0NvdW50ZXJCdXR0b24+XG4gICAgPC9Db3VudGVyQm94PlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltZyB9IGZyb20gXCJyZWFjdC1pbWFnZVwiO1xuaW1wb3J0IHBsYWNlaG9sZGVyIGZyb20gXCIuL3Byb2R1Y3QtcGxhY2Vob2xkZXIucG5nXCI7XG5jb25zdCBQbGFjZWhvbGRlciA9ICgpID0+IDxpbWcgc3JjPXtwbGFjZWhvbGRlcn0gYWx0PVwicHJvZHVjdCBpbWcgbG9hZGVyXCIgLz47XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbWFnZSh7XG4gIHVybCxcbiAgYWx0ID0gXCJwbGFjZWhvbGRlclwiLFxuICB1bmxvYWRlcixcbiAgbG9hZGVyLFxuICBjbGFzc05hbWUsXG4gIHN0eWxlLFxufToge1xuICB1cmw/OiBzdHJpbmc7XG4gIGFsdD86IHN0cmluZztcbiAgdW5sb2FkZXI/OiBzdHJpbmc7XG4gIGxvYWRlcj86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8SW1nXG4gICAgICBkcmFnZ2FibGU9e2ZhbHNlfVxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgICAgc3JjPXt1cmx9XG4gICAgICBrZXk9e3VybH1cbiAgICAgIGFsdD17YWx0fVxuICAgICAgbG9hZGVyPXs8UGxhY2Vob2xkZXIgLz59XG4gICAgICB1bmxvYWRlcj17PFBsYWNlaG9sZGVyIC8+fVxuICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XG4gICAgLz5cbiAgKTtcbn1cbiIsImV4cG9ydCBkZWZhdWx0IFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFRNEFBQUR3Q0FZQUFBRHhYb3A0QUFBSFBFbEVRVlI0WHUzZDIzTGEyQmFHVVJFT1BwVGYvMG1Od1lDc3Z0aEZ0b01kaXgrV3hCSVo0NnFyc2pweHV0cGZOT1hsbVZuWGRWMERFUGpWZHdEZ2xIQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNRV2ZRY281M0E0L1A3bitYemV6R2F6SDg5RHJZUmpRRjNYTmJ2ZHJ0bnRkazNidGw5K2ZENmZONHZGb25sOGZCUVJKbVhXZFYzWGQ0amNmcjl2M3Q3ZW1uUCs4ODVtcytiaDRhRjVmSHpzT3dwVkVJNEJiRGFiNXYzOXZlL1lGOHZsc25sK2Z2YjBRZlc4SEMzczBtZzBuNTVTb0hiQ1VkQit2Nzg0R2tmNy9iN1picmQ5eCtDbWhLT2d6V2JUZCtRczcrL3ZaNzBiZ1ZzUmprSjJ1MTN6OGZIUmQrd3NYZGQ1NnFCcXdsSElmci92T3hJcC9mTkJTY0pSU09sUDlJK1BEK01LMVJLT2luMTNhUXhxSUJ3RmVETDQwK2VyOWR3bjRTakFoYTMvYTl1MldhL1g3cVBjT2VFb1pJaDR6T2Z6dmlOVjZicnU5elg3NC9mb2NKK0VvNURsY3RsM0pETEY3NTVkcjlkL3ZKZDVlM3N6dHR3cDRTaWtkRGhXcTFYZmthcHNOcHR2STdGZXI0dmRiNkVld2xISWNya3NObHJNWnJOSmhXTzMyLzMxcW4zWGRjMTZ2ZllDK2M0SVIwRlBUMDk5Ujg3eTlQUTBtVEdsYmR2ZXEvYm5uR0ZhaEtPZ3hXTFJQRDgvOXgzNzBXcTFtc3pUUnRkMXpldnI2MWxQRTd2ZHpqWDZPeUljaGExV3E0dmo4ZkR3Y1BHL2V3dm5SdU5vdTkwV3YySExiVmprTTVERDRkQnNOcHV6Ym4vKyt2V3JlWHA2S3Y2Q2RVaHZiMjhYZmJsMU5wczFMeTh2eGQ0SGNSdkNNYkRkYnRjY0RvZG12OTkvK2RONXVWdzJ5K1Z5TXFQSjBXNjN1K3FDMTN3K2IxNWVYaWJ6SG9ldmhHTmtiZHRPK2svYncrSFF2TDYrOWgzcnRWZ3NtcGVYbDc1alZNbzdqcEZOT1JvZkh4L05lcjN1TzNhVzR5akhOQWtIWnhuaVBzYjcrL3RGNzBtNFBlR29XTWxQMG11ZCs2STNOZFRQeTdDRW8xS2wzaVdVc04xdUIzc3lTTzZDVUEvaHFORHh1MHpidHIzNXBha3h0cTRmNDhGMENFZUZ0dHZ0NzI4TTIyNjNOM3VVYjl2MnFpKzdKc2I4dGJpZWNGVG1jRGg4K1lheFczeENmZDZ0TVJZN1BLWkRPQ3B5L0dROWRZdVI1WFMzeGxqczhKZ0c0YWpJNXhIbHV4OGI2eFA1YjdzMXhtS0hSLzJFb3hMZmpTaW54aGhaZnRxdE1aWWg3b3hRbG5CVTRHOGp5cW1oUjVhYTltYlU5TEh3bFhCVTRLY1I1ZFJRSTB1Tjl5bnM4S2lYY056WU9TUEtxWE9lVGxLMVJlUElEbzg2Q2NjTm5UdWluQ285c2h3dm05V3E5by92WHlRY041U01LS2RLalN4VHVEdHhpenNsL0V3NGJ1U1NFZVhVSlU4cm54ME9oNnQvanJFYy80WTQ2aUFjTjNEcGlITHFtcEdsNUc2TnNkamhVUS9odUlGclJwUlRsNHdzVTc0bllZZEhIWVJqWkNWR2xGUHAwOHZVZDJCTS9lTy9COEl4b2xJanlxbGtaQmx5dDhaWWFyeHo4cThSamhHVkhGRk9uVE95akxGYll5eDJlTnlXY0l5a2JkdmlJOHFwbjU1bTduSGZ4VDMrbnFaQ09FWXl4di9nZnh0Wjd2a2V4QlR1b2R3ajRSakJPV05FS2QvOVdyZmFyVEVXT3p6R0p4d0RTMTVjbHZMNTZlYld1elhHWW9mSHVJUmpZR09NS0tlT3NhcGh0OFpZcG53M1pZcjhGWkFEMm02M296OXRmRGFiemY2NVQ2VFZhdFU4UHovM0hlTktuamdHY29zUjVkUy9GbzNHRG8vUkNNZEFiakdpOEQ5MmVBeFBPQVl3NWxkUitKNGRIc01TanNKcUdGRzQ3N3NyTlJDT3dvd285YkREWXpqQ1VaQVJwVDUyZUF4RE9Bb3hvdFRMRG8veWhLTVFJMHJkN1BBb1N6Z0tNS0xVenc2UHNvVGpTa2FVNmJERG94emh1SklSWlZyczhDaERPSzVnUkprbU96eXVKeHdYTXFKTW14MGUxeEdPQzNuY25UNDdQQzRuSEJjd290d0hPend1Snh3aEk4cDlhZHZXemRJTENFZklpSEovN1BESUNVZkFpSEsvN1BESUxQb084S2ZIeDhlK0kweVVGNlhuczNNVWlCbFZnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JQ1FjUUV3NGdKaHhBVERpQW1IQUFNZUVBWXNJQnhJUURpQWtIRUJNT0lDWWNRRXc0Z0pod0FESGhBR0xDQWNTRUE0Z0pCeEFURGlBbUhFQk1PSUNZY0FBeDRRQml3Z0hFaEFPSUNRY1FFdzRnSmh4QVREaUFtSEFBTWVFQVlzSUJ4SVFEaUFrSEVCTU9JQ1ljUUV3NGdKaHdBREhoQUdMQ0FjU0VBNGdKQnhBVERpQW1IRUJNT0lDWWNBQXg0UUJpd2dIRWhBT0lDUWNRRXc0Z0poeEFURGlBbUhBQU1lRUFZc0lCeElRRGlBa0hFQk1PSUNZY1FFdzRnSmh3QURIaEFHTENBY1NFQTRnSkJ4QVREaUFtSEVCTU9JQ1ljQUF4NFFCaXdnSEVoQU9JL1FlMGd5b1R6RU1XWlFBQUFBQkpSVTVFcmtKZ2dnPT1cIiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnO1xuaW1wb3J0IHsgdGhlbWVHZXQgfSBmcm9tICdAc3R5bGVkLXN5c3RlbS90aGVtZS1nZXQnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnY29tcG9uZW50cy9idXR0b24vYnV0dG9uJztcbmltcG9ydCB7IENvdW50ZXIgYXMgQ291bnRlcnMgfSBmcm9tICdjb21wb25lbnRzL2NvdW50ZXIvY291bnRlcic7XG5cbmV4cG9ydCBjb25zdCBDYXJkV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbmA7XG5cbmV4cG9ydCBjb25zdCBJbWFnZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogYXV0bztcbiAgaGVpZ2h0OiBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuXG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIG1heC1oZWlnaHQ6IDEwMCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB9XG5cbiAgJi5vdmVybGF5IHtcbiAgICAmOmFmdGVyIHtcbiAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB0b3A6IDA7XG4gICAgICBsZWZ0OiAwO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjc1KTtcbiAgICB9XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBJbmZvV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHBhZGRpbmc6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBtYXJnaW4tdG9wOiBhdXRvO1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgIHBhZGRpbmc6IDE1cHggMjBweDtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IFRpdGxlID0gc3R5bGVkLmgzYFxuICBmb250LWZhbWlseTogJHt0aGVtZUdldCgnZm9udHMuYm9keScsICdzYW5zLXNlcmlmJyl9O1xuICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcbiAgbWFyZ2luOiAwIDAgNHB4IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcblxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbWFyZ2luOiAwIDAgNXB4IDA7XG4gIH1cbmA7XG5cbmV4cG9ydCBjb25zdCBVbml0ID0gc3R5bGVkLnNwYW5gXG4gIGZvbnQtZmFtaWx5OiAke3RoZW1lR2V0KCdmb250cy5ib2R5JywgJ3NhbnMtc2VyaWYnKX07XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5yZWd1bGFyJywgJzQwMCcpfTtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy50ZXh0LnJlZ3VsYXInLCAnIzc3Nzk4YycpfTtcblxuICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICBmb250LXNpemU6ICR7dGhlbWVHZXQoJ2ZvbnRTaXplcy54cycsICcxMicpfXB4O1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgUHJpY2UgPSBzdHlsZWQuc3BhbmBcbiAgZm9udC1mYW1pbHk6ICR7dGhlbWVHZXQoJ2ZvbnRzLmJvZHknLCAnc2Fucy1zZXJpZicpfTtcbiAgZm9udC1zaXplOiAke3RoZW1lR2V0KCdmb250U2l6ZXMuYmFzZScsICcxNScpfXB4O1xuICBmb250LXdlaWdodDogJHt0aGVtZUdldCgnZm9udFdlaWdodHMuYm9sZCcsICc3MDAnKX07XG4gIGNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMudGV4dC5ib2xkJywgJyMwRDExMzYnKX07XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gICAgZm9udC1zaXplOiBjYWxjKCR7dGhlbWVHZXQoJ2ZvbnRTaXplcy5iYXNlJywgJzE1Jyl9cHggLSAxcHgpO1xuICB9XG5gO1xuXG5leHBvcnQgY29uc3QgQ2FydEJ1dHRvbiA9IHN0eWxlZChCdXR0b24pYFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAke3RoZW1lR2V0KCdjb2xvcnMucHJpbWFyeS5yZWd1bGFyJywgJyNGMzlDMTInKX07XG4gIGJvcmRlcjogMDtcbiAgY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy53aGl0ZScsICcjZmZmZmZmJyl9O1xuICBib3JkZXItcmFkaXVzOiAke3RoZW1lR2V0KCdyYWRpaS5iaWcnLCAnMThweCcpfTtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIHBhZGRpbmctcmlnaHQ6IDA7XG4gIGZvbnQtc2l6ZTogJHt0aGVtZUdldCgnZm9udFNpemVzLnNtJywgJzEzJyl9cHg7XG4gIGZvbnQtd2VpZ2h0OiAke3RoZW1lR2V0KCdmb250V2VpZ2h0cy5ib2xkJywgJzcwMCcpfTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDIwcHg7XG4gIHJpZ2h0OiAxNXB4O1xuICBib3gtc2hhZG93OiAwcHggMHB4IDEycHggcmdiYSgwLCAwLCAwLCAwLjMpO1xuICB6LWluZGV4OiAxO1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIHdpZHRoOiAzMnB4O1xuICAgIGhlaWdodDogMzJweDtcbiAgICBwYWRkaW5nOiAwO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgfVxuICAuYnRuLXRleHQge1xuICAgIHBhZGRpbmc6IDAgMCAwIDZweDtcbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuICB9XG4gICY6aG92ZXIge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICR7dGhlbWVHZXQoJ2NvbG9ycy5wcmltYXJ5LnJlZ3VsYXInLCAnI0YzOUMxMicpfTtcbiAgfVxuICBzdmcge1xuICAgIGZpbGw6IGN1cnJlbnRDb2xvcjtcbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IENvdW50ZXIgPSBzdHlsZWQoQ291bnRlcnMpYFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSA2MHB4KTtcbiAgaGVpZ2h0OiAzNnB4O1xuICBib3R0b206IDMwcHg7XG4gIGxlZnQ6IDMwcHg7XG4gIHotaW5kZXg6IDE7XG4gIGJveC1zaGFkb3c6IDAgMCA4cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuYDtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgSW1hZ2UgZnJvbSAnY29tcG9uZW50cy9pbWFnZS9pbWFnZSc7XG5pbXBvcnQgeyBQbHVzT3V0bGluZSB9IGZyb20gJ2Fzc2V0cy9pY29ucy9QbHVzT3V0bGluZSc7XG5pbXBvcnQge1xuICBDYXJkV3JhcHBlcixcbiAgSW1hZ2VXcmFwcGVyLFxuICBJbmZvV3JhcHBlcixcbiAgVGl0bGUsXG4gIFByaWNlLFxuICBVbml0LFxuICBDYXJ0QnV0dG9uLFxuICBDb3VudGVyLFxufSBmcm9tICcuL3Byb2R1Y3QtY2FyZC1maXZlLnN0eWxlJztcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICdjb250ZXh0cy9jYXJ0L3VzZS1jYXJ0JztcblxudHlwZSBQcm9kdWN0Q2FyZFByb3BzID0ge1xuICB0aXRsZTogc3RyaW5nO1xuICBpbWFnZTogYW55O1xuICB3ZWlnaHQ6IHN0cmluZztcbiAgY3VycmVuY3k/OiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICBwcmljZTogbnVtYmVyO1xuICBzYWxlUHJpY2U/OiBudW1iZXI7XG4gIGRpc2NvdW50SW5QZXJjZW50PzogbnVtYmVyO1xuICBkYXRhPzogYW55O1xuICBvbkNsaWNrPzogKGU6IGFueSkgPT4gdm9pZDtcbiAgb25DaGFuZ2U/OiAoZTogYW55KSA9PiB2b2lkO1xuICBpbmNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBkZWNyZW1lbnQ/OiAoZTogYW55KSA9PiB2b2lkO1xuICBjYXJ0UHJvZHVjdHM/OiBhbnk7XG4gIGFkZFRvQ2FydD86IGFueTtcbiAgdXBkYXRlQ2FydD86IGFueTtcbiAgdmFsdWU/OiBhbnk7XG4gIGRldmljZVR5cGU/OiBhbnk7XG59O1xuXG5jb25zdCBQcm9kdWN0Q2FyZDogUmVhY3QuRkM8UHJvZHVjdENhcmRQcm9wcz4gPSAoe1xuICB0aXRsZSxcbiAgaW1hZ2UsXG4gIHdlaWdodCxcbiAgcHJpY2UsXG4gIHNhbGVQcmljZSxcbiAgZGlzY291bnRJblBlcmNlbnQsXG4gIGNhcnRQcm9kdWN0cyxcbiAgYWRkVG9DYXJ0LFxuICB1cGRhdGVDYXJ0LFxuICB2YWx1ZSxcbiAgY3VycmVuY3ksXG4gIG9uQ2hhbmdlLFxuICBpbmNyZW1lbnQsXG4gIGRlY3JlbWVudCxcbiAgZGF0YSxcbiAgZGV2aWNlVHlwZSxcbiAgb25DbGljayxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3QgeyBhZGRJdGVtLCByZW1vdmVJdGVtLCBnZXRJdGVtLCBpc0luQ2FydCB9ID0gdXNlQ2FydCgpO1xuXG4gIGNvbnN0IGhhbmRsZUFkZENsaWNrID0gKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGFkZEl0ZW0oZGF0YSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVtb3ZlQ2xpY2sgPSAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgcmVtb3ZlSXRlbShkYXRhKTtcbiAgfTtcbiAgLy8gY29uc29sZS5sb2coaXRlbXMsICdwcm9kdWN0LWNhcmQnKTtcblxuICByZXR1cm4gKFxuICAgIDxDYXJkV3JhcHBlciBvbkNsaWNrPXtvbkNsaWNrfSBjbGFzc05hbWU9XCJtZWRpY2luZS1jYXJkXCI+XG4gICAgICA8SW1hZ2VXcmFwcGVyIGNsYXNzTmFtZT17aXNJbkNhcnQoZGF0YT8uaWQpICYmICdvdmVybGF5J30+XG4gICAgICAgIDxJbWFnZVxuICAgICAgICAgIHVybD17aW1hZ2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicHJvZHVjdC1pbWFnZVwiXG4gICAgICAgICAgc3R5bGU9e3sgcG9zaXRpb246ICdyZWxhdGl2ZScgfX1cbiAgICAgICAgICBhbHQ9e3RpdGxlfVxuICAgICAgICAvPlxuXG4gICAgICAgIHshaXNJbkNhcnQoZGF0YT8uaWQpID8gKFxuICAgICAgICAgIDxDYXJ0QnV0dG9uIGNsYXNzTmFtZT1cImNhcnQtYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQWRkQ2xpY2t9PlxuICAgICAgICAgICAgPFBsdXNPdXRsaW5lIC8+XG4gICAgICAgICAgPC9DYXJ0QnV0dG9uPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxDb3VudGVyXG4gICAgICAgICAgICB2YWx1ZT17Z2V0SXRlbShkYXRhPy5pZCkucXVhbnRpdHl9XG4gICAgICAgICAgICBvbkRlY3JlbWVudD17aGFuZGxlUmVtb3ZlQ2xpY2t9XG4gICAgICAgICAgICBvbkluY3JlbWVudD17aGFuZGxlQWRkQ2xpY2t9XG4gICAgICAgICAgLz5cbiAgICAgICAgKX1cbiAgICAgIDwvSW1hZ2VXcmFwcGVyPlxuICAgICAgPEluZm9XcmFwcGVyPlxuICAgICAgICA8UHJpY2U+XG4gICAgICAgICAge2N1cnJlbmN5fVxuICAgICAgICAgIHtwcmljZX1cbiAgICAgICAgPC9QcmljZT5cblxuICAgICAgICA8VGl0bGU+e3RpdGxlfTwvVGl0bGU+XG4gICAgICAgIDxVbml0Pnt3ZWlnaHR9PC9Vbml0PlxuICAgICAgPC9JbmZvV3JhcHBlcj5cbiAgICA8L0NhcmRXcmFwcGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvZHVjdENhcmQ7XG4iLCIvLyBleHBvcnQgY29uc3QgY2FydEl0ZW1zVG90YWxQcmljZSA9IChpdGVtcywgeyBkaXNjb3VudEluUGVyY2VudCA9IDAgfSA9IHt9KSA9PiB7XG5leHBvcnQgY29uc3QgY2FydEl0ZW1zVG90YWxQcmljZSA9IChpdGVtcywgY291cG9uID0gbnVsbCkgPT4ge1xuICBpZiAoaXRlbXMgPT09IG51bGwgfHwgaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgY29uc3QgaXRlbUNvc3QgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0uc2FsZVByaWNlKSB7XG4gICAgICByZXR1cm4gdG90YWwgKyBpdGVtLnNhbGVQcmljZSAqIGl0ZW0ucXVhbnRpdHk7XG4gICAgfVxuICAgIHJldHVybiB0b3RhbCArIGl0ZW0ucHJpY2UgKiBpdGVtLnF1YW50aXR5O1xuICB9LCAwKTtcbiAgLy8gY29uc3QgZGlzY291bnRSYXRlID0gMSAtIGRpc2NvdW50SW5QZXJjZW50O1xuICBjb25zdCBkaXNjb3VudCA9IGNvdXBvblxuICAgID8gKGl0ZW1Db3N0ICogTnVtYmVyKGNvdXBvbi5kaXNjb3VudEluUGVyY2VudCkpIC8gMTAwXG4gICAgOiAwO1xuICAvLyBpdGVtQ29zdCAqIGRpc2NvdW50UmF0ZSAqIFRBWF9SQVRFICsgc2hpcHBpbmc7XG4gIC8vIHJldHVybiBpdGVtQ29zdCAqIGRpc2NvdW50UmF0ZTtcbiAgcmV0dXJuIGl0ZW1Db3N0IC0gZGlzY291bnQ7XG59O1xuLy8gY2FydEl0ZW1zLCBjYXJ0SXRlbVRvQWRkXG5jb25zdCBhZGRJdGVtVG9DYXJ0ID0gKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgY29uc3QgZXhpc3RpbmdDYXJ0SXRlbUluZGV4ID0gc3RhdGUuaXRlbXMuZmluZEluZGV4KFxuICAgIChpdGVtKSA9PiBpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZC5pZFxuICApO1xuXG4gIGlmIChleGlzdGluZ0NhcnRJdGVtSW5kZXggPiAtMSkge1xuICAgIGNvbnN0IG5ld1N0YXRlID0gWy4uLnN0YXRlLml0ZW1zXTtcbiAgICBuZXdTdGF0ZVtleGlzdGluZ0NhcnRJdGVtSW5kZXhdLnF1YW50aXR5ICs9IGFjdGlvbi5wYXlsb2FkLnF1YW50aXR5O1xuICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgfVxuICByZXR1cm4gWy4uLnN0YXRlLml0ZW1zLCBhY3Rpb24ucGF5bG9hZF07XG59O1xuXG4vLyBjYXJ0SXRlbXMsIGNhcnRJdGVtVG9SZW1vdmVcbmNvbnN0IHJlbW92ZUl0ZW1Gcm9tQ2FydCA9IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gIHJldHVybiBzdGF0ZS5pdGVtcy5yZWR1Y2UoKGFjYywgaXRlbSkgPT4ge1xuICAgIGlmIChpdGVtLmlkID09PSBhY3Rpb24ucGF5bG9hZC5pZCkge1xuICAgICAgY29uc3QgbmV3UXVhbnRpdHkgPSBpdGVtLnF1YW50aXR5IC0gYWN0aW9uLnBheWxvYWQucXVhbnRpdHk7XG5cbiAgICAgIHJldHVybiBuZXdRdWFudGl0eSA+IDBcbiAgICAgICAgPyBbLi4uYWNjLCB7IC4uLml0ZW0sIHF1YW50aXR5OiBuZXdRdWFudGl0eSB9XVxuICAgICAgICA6IFsuLi5hY2NdO1xuICAgIH1cbiAgICByZXR1cm4gWy4uLmFjYywgaXRlbV07XG4gIH0sIFtdKTtcbn07XG5cbmNvbnN0IGNsZWFySXRlbUZyb21DYXJ0ID0gKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgcmV0dXJuIHN0YXRlLml0ZW1zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gYWN0aW9uLnBheWxvYWQuaWQpO1xufTtcblxuZXhwb3J0IGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgY2FzZSAnUkVIWURSQVRFJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCAuLi5hY3Rpb24ucGF5bG9hZCB9O1xuICAgIGNhc2UgJ1RPR0dMRV9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpc09wZW46ICFzdGF0ZS5pc09wZW4gfTtcbiAgICBjYXNlICdBRERfSVRFTSc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXRlbXM6IGFkZEl0ZW1Ub0NhcnQoc3RhdGUsIGFjdGlvbikgfTtcbiAgICBjYXNlICdSRU1PVkVfSVRFTSc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXRlbXM6IHJlbW92ZUl0ZW1Gcm9tQ2FydChzdGF0ZSwgYWN0aW9uKSB9O1xuICAgIGNhc2UgJ0NMRUFSX0lURU1fRlJPTV9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogY2xlYXJJdGVtRnJvbUNhcnQoc3RhdGUsIGFjdGlvbikgfTtcbiAgICBjYXNlICdDTEVBUl9DQVJUJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBpdGVtczogW10gfTtcbiAgICBjYXNlICdBUFBMWV9DT1VQT04nOlxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGNvdXBvbjogYWN0aW9uLnBheWxvYWQgfTtcbiAgICBjYXNlICdSRU1PVkVfQ09VUE9OJzpcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjb3Vwb246IG51bGwgfTtcbiAgICBjYXNlICdUT0dHTEVfUkVTVEFVUkFOVCc6XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgaXNSZXN0YXVyYW50OiAhc3RhdGUuaXNSZXN0YXVyYW50IH07XG4gICAgZGVmYXVsdDpcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3Rpb246ICR7YWN0aW9uLnR5cGV9YCk7XG4gIH1cbn07XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlUmVkdWNlciwgdXNlQ29udGV4dCwgY3JlYXRlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHJlZHVjZXIsIGNhcnRJdGVtc1RvdGFsUHJpY2UgfSBmcm9tICcuL2NhcnQucmVkdWNlcic7XG5pbXBvcnQgeyB1c2VTdG9yYWdlIH0gZnJvbSAndXRpbHMvdXNlLXN0b3JhZ2UnO1xuY29uc3QgQ2FydENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9IGFzIGFueSk7XG5jb25zdCBJTklUSUFMX1NUQVRFID0ge1xuICBpc09wZW46IGZhbHNlLFxuICBpdGVtczogW10sXG4gIGlzUmVzdGF1cmFudDogZmFsc2UsXG4gIGNvdXBvbjogbnVsbCxcbn07XG5cbmNvbnN0IHVzZUNhcnRBY3Rpb25zID0gKGluaXRpYWxDYXJ0ID0gSU5JVElBTF9TVEFURSkgPT4ge1xuICBjb25zdCBbc3RhdGUsIGRpc3BhdGNoXSA9IHVzZVJlZHVjZXIocmVkdWNlciwgaW5pdGlhbENhcnQpO1xuXG4gIGNvbnN0IGFkZEl0ZW1IYW5kbGVyID0gKGl0ZW0sIHF1YW50aXR5ID0gMSkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ0FERF9JVEVNJywgcGF5bG9hZDogeyAuLi5pdGVtLCBxdWFudGl0eSB9IH0pO1xuICB9O1xuXG4gIGNvbnN0IHJlbW92ZUl0ZW1IYW5kbGVyID0gKGl0ZW0sIHF1YW50aXR5ID0gMSkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1JFTU9WRV9JVEVNJywgcGF5bG9hZDogeyAuLi5pdGVtLCBxdWFudGl0eSB9IH0pO1xuICB9O1xuXG4gIGNvbnN0IGNsZWFySXRlbUZyb21DYXJ0SGFuZGxlciA9IChpdGVtKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnQ0xFQVJfSVRFTV9GUk9NX0NBUlQnLCBwYXlsb2FkOiBpdGVtIH0pO1xuICB9O1xuXG4gIGNvbnN0IGNsZWFyQ2FydEhhbmRsZXIgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnQ0xFQVJfQ0FSVCcgfSk7XG4gIH07XG4gIGNvbnN0IHRvZ2dsZUNhcnRIYW5kbGVyID0gKCkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1RPR0dMRV9DQVJUJyB9KTtcbiAgfTtcbiAgY29uc3QgY291cG9uSGFuZGxlciA9IChjb3Vwb24pID0+IHtcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdBUFBMWV9DT1VQT04nLCBwYXlsb2FkOiBjb3Vwb24gfSk7XG4gIH07XG4gIGNvbnN0IHJlbW92ZUNvdXBvbkhhbmRsZXIgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnUkVNT1ZFX0NPVVBPTicgfSk7XG4gIH07XG4gIGNvbnN0IHJlaHlkcmF0ZUxvY2FsU3RhdGUgPSAocGF5bG9hZCkgPT4ge1xuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1JFSFlEUkFURScsIHBheWxvYWQgfSk7XG4gIH07XG4gIGNvbnN0IHRvZ2dsZVJlc3RhdXJhbnQgPSAoKSA9PiB7XG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnVE9HR0xFX1JFU1RBVVJBTlQnIH0pO1xuICB9O1xuICBjb25zdCBpc0luQ2FydEhhbmRsZXIgPSAoaWQpID0+IHtcbiAgICByZXR1cm4gc3RhdGUuaXRlbXM/LnNvbWUoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGlkKTtcbiAgfTtcbiAgY29uc3QgZ2V0SXRlbUhhbmRsZXIgPSAoaWQpID0+IHtcbiAgICByZXR1cm4gc3RhdGUuaXRlbXM/LmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGlkKTtcbiAgfTtcbiAgY29uc3QgZ2V0Q2FydEl0ZW1zUHJpY2UgPSAoKSA9PiBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zKS50b0ZpeGVkKDIpO1xuICBjb25zdCBnZXRDYXJ0SXRlbXNUb3RhbFByaWNlID0gKCkgPT5cbiAgICBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zLCBzdGF0ZS5jb3Vwb24pLnRvRml4ZWQoMik7XG5cbiAgY29uc3QgZ2V0RGlzY291bnQgPSAoKSA9PiB7XG4gICAgY29uc3QgdG90YWwgPSBjYXJ0SXRlbXNUb3RhbFByaWNlKHN0YXRlLml0ZW1zKTtcbiAgICBjb25zdCBkaXNjb3VudCA9IHN0YXRlLmNvdXBvblxuICAgICAgPyAodG90YWwgKiBOdW1iZXIoc3RhdGUuY291cG9uPy5kaXNjb3VudEluUGVyY2VudCkpIC8gMTAwXG4gICAgICA6IDA7XG4gICAgcmV0dXJuIGRpc2NvdW50LnRvRml4ZWQoMik7XG4gIH07XG4gIGNvbnN0IGdldEl0ZW1zQ291bnQgPSBzdGF0ZS5pdGVtcz8ucmVkdWNlKFxuICAgIChhY2MsIGl0ZW0pID0+IGFjYyArIGl0ZW0ucXVhbnRpdHksXG4gICAgMFxuICApO1xuICByZXR1cm4ge1xuICAgIHN0YXRlLFxuICAgIGdldEl0ZW1zQ291bnQsXG4gICAgcmVoeWRyYXRlTG9jYWxTdGF0ZSxcbiAgICBhZGRJdGVtSGFuZGxlcixcbiAgICByZW1vdmVJdGVtSGFuZGxlcixcbiAgICBjbGVhckl0ZW1Gcm9tQ2FydEhhbmRsZXIsXG4gICAgY2xlYXJDYXJ0SGFuZGxlcixcbiAgICBpc0luQ2FydEhhbmRsZXIsXG4gICAgZ2V0SXRlbUhhbmRsZXIsXG4gICAgdG9nZ2xlQ2FydEhhbmRsZXIsXG4gICAgZ2V0Q2FydEl0ZW1zVG90YWxQcmljZSxcbiAgICBnZXRDYXJ0SXRlbXNQcmljZSxcbiAgICBjb3Vwb25IYW5kbGVyLFxuICAgIHJlbW92ZUNvdXBvbkhhbmRsZXIsXG4gICAgZ2V0RGlzY291bnQsXG4gICAgdG9nZ2xlUmVzdGF1cmFudCxcbiAgfTtcbn07XG5cbmV4cG9ydCBjb25zdCBDYXJ0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IHtcbiAgICBzdGF0ZSxcbiAgICByZWh5ZHJhdGVMb2NhbFN0YXRlLFxuICAgIGdldEl0ZW1zQ291bnQsXG4gICAgYWRkSXRlbUhhbmRsZXIsXG4gICAgcmVtb3ZlSXRlbUhhbmRsZXIsXG4gICAgY2xlYXJJdGVtRnJvbUNhcnRIYW5kbGVyLFxuICAgIGNsZWFyQ2FydEhhbmRsZXIsXG4gICAgaXNJbkNhcnRIYW5kbGVyLFxuICAgIGdldEl0ZW1IYW5kbGVyLFxuICAgIHRvZ2dsZUNhcnRIYW5kbGVyLFxuICAgIGdldENhcnRJdGVtc1RvdGFsUHJpY2UsXG4gICAgY291cG9uSGFuZGxlcixcbiAgICByZW1vdmVDb3Vwb25IYW5kbGVyLFxuICAgIGdldENhcnRJdGVtc1ByaWNlLFxuICAgIGdldERpc2NvdW50LFxuICAgIHRvZ2dsZVJlc3RhdXJhbnQsXG4gIH0gPSB1c2VDYXJ0QWN0aW9ucygpO1xuICBjb25zdCB7IHJlaHlkcmF0ZWQsIGVycm9yIH0gPSB1c2VTdG9yYWdlKHN0YXRlLCByZWh5ZHJhdGVMb2NhbFN0YXRlKTtcblxuICByZXR1cm4gKFxuICAgIDxDYXJ0Q29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgaXNPcGVuOiBzdGF0ZS5pc09wZW4sXG4gICAgICAgIGl0ZW1zOiBzdGF0ZS5pdGVtcyxcbiAgICAgICAgY291cG9uOiBzdGF0ZS5jb3Vwb24sXG4gICAgICAgIGlzUmVzdGF1cmFudDogc3RhdGUuaXNSZXN0YXVyYW50LFxuICAgICAgICBjYXJ0SXRlbXNDb3VudDogc3RhdGUuaXRlbXM/Lmxlbmd0aCxcbiAgICAgICAgaXRlbXNDb3VudDogZ2V0SXRlbXNDb3VudCxcbiAgICAgICAgYWRkSXRlbTogYWRkSXRlbUhhbmRsZXIsXG4gICAgICAgIHJlbW92ZUl0ZW06IHJlbW92ZUl0ZW1IYW5kbGVyLFxuICAgICAgICByZW1vdmVJdGVtRnJvbUNhcnQ6IGNsZWFySXRlbUZyb21DYXJ0SGFuZGxlcixcbiAgICAgICAgY2xlYXJDYXJ0OiBjbGVhckNhcnRIYW5kbGVyLFxuICAgICAgICBpc0luQ2FydDogaXNJbkNhcnRIYW5kbGVyLFxuICAgICAgICBnZXRJdGVtOiBnZXRJdGVtSGFuZGxlcixcbiAgICAgICAgdG9nZ2xlQ2FydDogdG9nZ2xlQ2FydEhhbmRsZXIsXG4gICAgICAgIGNhbGN1bGF0ZVByaWNlOiBnZXRDYXJ0SXRlbXNUb3RhbFByaWNlLFxuICAgICAgICBjYWxjdWxhdGVTdWJUb3RhbFByaWNlOiBnZXRDYXJ0SXRlbXNQcmljZSxcbiAgICAgICAgYXBwbHlDb3Vwb246IGNvdXBvbkhhbmRsZXIsXG4gICAgICAgIHJlbW92ZUNvdXBvbjogcmVtb3ZlQ291cG9uSGFuZGxlcixcbiAgICAgICAgY2FsY3VsYXRlRGlzY291bnQ6IGdldERpc2NvdW50LFxuICAgICAgICB0b2dnbGVSZXN0YXVyYW50LFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9DYXJ0Q29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCB1c2VDYXJ0ID0gKCkgPT4gdXNlQ29udGV4dChDYXJ0Q29udGV4dCk7XG4iLCJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGxvY2FsRm9yYWdlIGZyb20gJ2xvY2FsZm9yYWdlJztcbmNvbnN0IGlzT2JqZWN0TGlrZWQgPSAodmFsdWUpID0+XG4gIHZhbHVlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdBcnJheScgfHwgdmFsdWUuY29uc3RydWN0b3IubmFtZSA9PT0gJ09iamVjdCc7XG5cbmNvbnN0IHJlaHlkcmF0ZSA9ICh2YWx1ZTogYW55LCBkZWZhdWx0VmFsdWU/OiBhbnkpID0+IHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgLy8gaWYgKHZhbHVlID09PSAnZmFsc2UnKSBzdHIgPSBmYWxzZTtcbiAgLy8gaWYgKHZhbHVlID09PSAndHJ1ZScpIHN0ciA9IHRydWU7XG4gIC8vIGlmICghaXNPYmplY3RMaWtlZCh2YWx1ZSkpIHtcbiAgLy8gICByZXR1cm4gdmFsdWU7XG4gIC8vIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZSA9IEpTT04ucGFyc2UodmFsdWUpO1xuICAgIHJldHVybiBwYXJzZTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgfVxufTtcblxuY29uc3QgaHlkcmF0ZSA9ICh2YWx1ZSkgPT4ge1xuICBpZiAoIWlzT2JqZWN0TGlrZWQodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG59O1xuY29uc3QgY3JlYXRlTWlncmF0aW9uID0gKG9wdHMsIGRhdGEpID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBrZXkgPSBgJHtvcHRzLmtleX0tdmVyc2lvbmA7XG4gICAgbG9jYWxGb3JhZ2UuZ2V0SXRlbShrZXksIChlcnIsIHZlcnNpb24pID0+IHtcbiAgICAgIGlmICh2ZXJzaW9uICE9PSBvcHRzLnZlcnNpb24pIHtcbiAgICAgICAgZGF0YSA9IG9wdHMubWlncmF0ZShkYXRhKTtcbiAgICAgICAgbG9jYWxGb3JhZ2Uuc2V0SXRlbShvcHRzLmtleSwgcmVoeWRyYXRlKGRhdGEpLCAoZXJyKSA9PiB7XG4gICAgICAgICAgaWYgKGVycikgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgICAgICAgIGxvY2FsRm9yYWdlLnNldEl0ZW0oa2V5LCBvcHRzLnZlcnNpb24sIChlcnIpID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICAgIHJldHVybiByZXNvbHZlKGRhdGEpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmUoZGF0YSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xufTtcblxuY29uc3QgY29uZmlnID0ge1xuICBrZXk6ICdAc2Vzc2lvbicsXG4gIHZlcnNpb246IDEsXG4gIG1pZ3JhdGU6IChzdGF0ZSkgPT4ge1xuICAgIHJldHVybiB7IC4uLnN0YXRlIH07XG4gIH0sXG59O1xuXG5leHBvcnQgY29uc3QgdXNlU3RvcmFnZSA9IChzdGF0ZSwgc2V0U3RhdGUpID0+IHtcbiAgY29uc3QgW3JlaHlkcmF0ZWQsIHNldFJlaHlkcmF0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgIGF3YWl0IGxvY2FsRm9yYWdlLmdldEl0ZW0oY29uZmlnLmtleSwgKGVyciwgdmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIHNldFJlaHlkcmF0ZWQodHJ1ZSk7XG4gICAgICAgICAgcmV0dXJuIHNldEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gTWlncmF0ZSBwZXJzaXN0ZWQgZGF0YVxuICAgICAgICBjb25zdCByZXN0b3JlZFZhbHVlID0gcmVoeWRyYXRlKHZhbHVlKTtcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcubWlncmF0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIGNyZWF0ZU1pZ3JhdGlvbihjb25maWcsIHJlc3RvcmVkVmFsdWUpXG4gICAgICAgICAgICAudGhlbigoZGF0YSkgPT4gc2V0U3RhdGUoZGF0YSkpXG4gICAgICAgICAgICAudGhlbigoKSA9PiBzZXRSZWh5ZHJhdGVkKHRydWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRTdGF0ZShyZXN0b3JlZFZhbHVlKTtcbiAgICAgICAgICBzZXRSZWh5ZHJhdGVkKHRydWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgaW5pdCgpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBpZiAoaXNOaWwoc3RhdGUpIHx8IGlzRW1wdHkoc3RhdGUpKSB7XG4gICAgLy8gICBsb2NhbEZvcmFnZS5yZW1vdmVJdGVtKGNvbmZpZy5rZXkpO1xuICAgIC8vIH1cbiAgICBsb2NhbEZvcmFnZS5zZXRJdGVtKGNvbmZpZy5rZXksIGh5ZHJhdGUoc3RhdGUpKTtcbiAgfSwgW3N0YXRlXSk7XG5cbiAgcmV0dXJuIHtcbiAgICByZWh5ZHJhdGVkLFxuICAgIGVycm9yLFxuICB9O1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=